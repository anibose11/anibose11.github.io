"""Scorer tests on tiny synthetic fixtures (not study data)."""
import json

import pytest

from ema import config as C
from ema.score import norm_ws, parse_response, score_answer, token_f1

ARTICLE = ("TITLE: Fixture trial\n\nABSTRACT.RESULTS:\nPain was lower with drug A than placebo\n(P = 0.01). "
           "Nausea did not differ between groups (P = 0.62).\n")
P1_START = ARTICLE.index("Pain")
P1_END = ARTICLE.index("(P = 0.01).") + len("(P = 0.01).")
P2_START = ARTICLE.index("Nausea")
P2_END = ARTICLE.index("(P = 0.62).") + len("(P = 0.62).")
PASSAGES = [{"pid": "P1", "start": P1_START, "end": P1_END, "text": ARTICLE[P1_START:P1_END]},
            {"pid": "P2", "start": P2_START, "end": P2_END, "text": ARTICLE[P2_START:P2_END]}]
GOLD = [(P1_START, P1_END)]


def ans(label, quote, pid):
    return json.dumps({"label": label, "evidence_quote": quote, "passage_id": pid})


@pytest.mark.parametrize("raw,status", [
    (ans("significantly decreased", "x", "P1"), "valid"),
    ("```json\n" + ans("significantly decreased", "x", "P1") + "\n```", "valid"),
    ("<think>\n\n</think>\n" + ans("no significant difference", "x", "P2"), "valid"),
    ('{"label": "significantly lower", "evidence_quote": "x", "passage_id": "P1"}', "schema_error"),
    ('{"label": "significantly decreased", "evidence_quote": "x"}', "schema_error"),
    ('{"label": "significantly decreased", "evidence_quote": "x", "passage_id": "P1", "extra": 1}', "schema_error"),
    ('{"label": "significantly decreased", "evidence_quote": "unterminated', "invalid_json"),
    ("The answer is decreased.", "no_json_object"),
    ("", "empty"),
    (None, "runtime_error"),
])
def test_parse_status(raw, status):
    assert parse_response(raw)[0] == status


def test_trailing_text_still_valid_but_noted():
    st, obj, detail = parse_response(ans("significantly decreased", "x", "P1") + " I hope this helps.")
    assert st == "valid" and detail == "trailing text"


def test_quote_valid_and_correct_is_success():
    s = score_answer(ans("significantly decreased", "Pain was lower with drug A than placebo (P = 0.01).", "P1"),
                     "eos", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert s.answered and s.quote_exists and s.locator_valid and s.label_correct and s.task_success
    # the quote spans a hard line wrap in the article; offsets map back exactly
    assert (s.quote_start, s.quote_end) == (P1_START, P1_END)
    assert s.gold_overlap is True and s.gold_token_f1 == 1.0


def test_quote_valid_but_label_wrong_is_the_target_case():
    s = score_answer(ans("no significant difference", "Pain was lower with drug A than placebo", "P1"),
                     "eos", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert s.quote_exists and s.locator_valid and s.label_correct is False and not s.task_success


def test_strict_versus_normalized_existence():
    # displayed passages have the line wrap collapsed, so this is an exact copy of what the model saw
    s = score_answer(ans("significantly decreased", "Pain was lower with drug A than placebo (P = 0.01).", "P1"),
                     "eos", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert s.quote_exists_strict
    s2 = score_answer(ans("significantly decreased", "Pain  was lower with\tdrug A", "P1"),
                      "eos", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert s2.quote_exists and not s2.quote_exists_strict


def test_paraphrase_is_not_an_existing_quote():
    s = score_answer(ans("significantly decreased", "Drug A reduced pain compared with placebo", "P1"),
                     "eos", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert not s.quote_exists and not s.locator_valid and s.label_correct and not s.task_success
    assert s.gold_overlap is False


def test_short_quote_does_not_count():
    s = score_answer(ans("significantly decreased", "drug A", "P1"), "eos", PASSAGES, "significantly decreased",
                     GOLD, ARTICLE)
    assert s.quote_too_short and not s.quote_exists and s.quote_start is not None


def test_wrong_locator():
    s = score_answer(ans("no significant difference", "Nausea did not differ between groups", "P1"),
                     "eos", PASSAGES, "no significant difference", [(P2_START, P2_END)], ARTICLE)
    assert s.quote_exists and not s.locator_valid and s.label_correct and not s.task_success


def test_quote_across_two_passages_is_not_an_existing_quote():
    s = score_answer(ans("significantly decreased", "(P = 0.01). Nausea did not differ", "P1"), "eos",
                     PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert not s.quote_exists


def test_abstention_is_not_no_significant_difference():
    s = score_answer(ans(C.ABSTAIN, "", None), "eos", PASSAGES, "no significant difference", GOLD, ARTICLE)
    assert s.abstained and not s.answered and s.label_correct is None and not s.task_success


def test_invalid_output_counts_as_failure():
    s = score_answer('{"label": "decreased"', "length", PASSAGES, "significantly decreased", GOLD, ARTICLE)
    assert s.parse_status == "invalid_json" and "truncated" in s.parse_detail and not s.task_success


def test_disagreement_prompt_has_no_correctness():
    s = score_answer(ans("significantly decreased", "Pain was lower with drug A than placebo", "P1"), "eos",
                     PASSAGES, None, GOLD, ARTICLE)
    assert s.label_correct is None and not s.task_success


def test_token_f1_and_norm():
    assert token_f1("a b c", "a b c") == 1.0
    assert token_f1("a b", "c d") == 0.0
    assert norm_ws("  a \n b\t") == "a b"
