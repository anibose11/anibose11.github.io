"""Arithmetic of the headline estimand, bootstrap, macro-F1, and rejection analysis on synthetic fixtures."""
import numpy as np
import pandas as pd

from ema.analyze import headline, paired_diff_ci, ratio_ci, rejection
from ema.evaluate import NO_ANSWER, macro_f1


def frame(rows):
    cols = ["pmcid", "prompt_id", "answered", "quote_exists", "quote_exists_strict", "locator_valid", "label_correct",
            "gold_label", "label_pred"]
    df = pd.DataFrame(rows, columns=cols)
    df["pred_or_none"] = np.where(df.answered, df.label_pred, NO_ANSWER)
    return df


INC, NS, DEC = "significantly increased", "no significant difference", "significantly decreased"
ROWS = [
    # article 1: two quote-valid answers, one wrong
    (1, 1, True, True, True, True, True, INC, INC),
    (1, 2, True, True, True, True, False, NS, INC),
    # article 2: quote invalid answer (excluded from headline), abstention
    (2, 3, True, False, False, False, True, DEC, DEC),
    (2, 4, False, False, False, False, None, NS, None),
    # article 3: quote-valid wrong
    (3, 5, True, True, False, True, False, DEC, NS),
]


def test_headline_counts():
    h = headline(frame(ROWS))
    assert (h["numerator"], h["denominator"]) == (2, 3)
    assert abs(h["estimate"] - 2 / 3) < 1e-12
    assert h["per_gold_class"][NS] == {"numerator": 1, "denominator": 1}
    assert h["per_pred_class"][INC] == {"numerator": 1, "denominator": 2}
    assert h["ci_low"] <= h["estimate"] <= h["ci_high"]


def test_headline_undefined_when_no_quote_valid_answer():
    rows = [(1, 1, True, False, False, False, False, INC, NS), (2, 2, False, False, False, False, None, NS, None)]
    h = headline(frame(rows))
    assert h["estimate"] is None and h["denominator"] == 0 and "undefined" in h["note"]


def test_ratio_ci_deterministic_and_clustered():
    df = frame(ROWS)
    a = ratio_ci(df, df.answered.astype(float), pd.Series(np.ones(len(df))), reps=500)
    b = ratio_ci(df, df.answered.astype(float), pd.Series(np.ones(len(df))), reps=500)
    assert a == b and a["articles"] == 3 and a["estimate"] == 4 / 5


def test_paired_diff_zero_for_identical_systems():
    df = frame(ROWS)
    d = paired_diff_ci(df, df, "answered", reps=300)
    assert d["diff"] == 0 and d["ci_low"] == 0 and d["ci_high"] == 0


def test_macro_f1_counts_no_answer_as_wrong():
    df = frame(ROWS)
    m = macro_f1(df)
    # NS: tp 0 (prompt 4 abstained, prompt 2 predicted INC) -> f1 0
    assert m[f"f1::{NS}"] == 0.0
    assert m[f"recall::{INC}"] == 1.0 and m[f"precision::{INC}"] == 0.5


def test_rejection_rule_and_random_comparator():
    df = frame(ROWS)
    r = rejection(df, draws=200)
    assert r["answered"] == 4 and r["kept_by_filter"] == 3
    assert r["unfiltered"]["retained_error"] == 0.5
    assert abs(r["quote_filter"]["retained_error"] - 2 / 3) < 1e-12
    assert r["quote_filter"]["rejected_correct"] == 1
    assert abs(r["quote_filter"]["coverage"] - 3 / 5) < 1e-12
    assert r["random_same_coverage"]["draws"] == 200
