"""Label contract, offset location, abstract delimiting, and chunking on synthetic fixtures."""
import pytest

from ema.contexts import chunk_article, paragraphs, evidence_recall, Context, Passage
from ema.data import abstract_region, label_contract, locate_span, parse_title

TEXT = ("TITLE: \nA fixture randomized trial\n\n\n\n  ABSTRACT.BACKGROUND:\nWe tested drug A against placebo in "
        "adults after minor surgery, measuring pain at 24 hours as the primary outcome and nausea as a secondary "
        "outcome in both groups.\n\n"
        "ABSTRACT.RESULTS::\nPain was lower with\ndrug A (P = 0.01). Nausea was similar.\n\n"
        "BODY.METHODS:\n" + " ".join(f"word{i}" for i in range(150)) + ".\n\nBODY.RESULTS:\nThe end.\n")


def test_label_contract():
    assert label_contract([], 0) == ("no_annotation", None)
    assert label_contract([], 2) == ("no_accepted_annotation", None)
    assert label_contract([1, 1], 2) == ("unanimous", "significantly increased")
    assert label_contract([0], 1) == ("unanimous", "no significant difference")
    assert label_contract([-1, 0], 2) == ("accepted_disagreement", None)


def test_locate_span_half_open_offsets():
    s = TEXT.index("Pain")
    ev = "Pain was lower with\ndrug A"
    assert locate_span(TEXT, ev, s, s + len(ev)) == (s, s + len(ev), "exact")
    # inclusive end (README convention) does not reproduce the string; whitespace variant is tolerated
    assert locate_span(TEXT, "Pain was lower with drug A", s, s + len(ev))[2] == "exact_ws"
    assert locate_span(TEXT, ev, -1, -1)[2] == "recovered_from_missing"
    assert locate_span(TEXT, "absent string", 5, 9)[2] == "offset_text_mismatch"
    assert locate_span(TEXT, "absent string", -1, -1)[2] == "unavailable"
    assert locate_span(None, ev, 0, 1)[2] == "no_text"


def test_abstract_region_and_title():
    end, status = abstract_region(TEXT)
    assert status == "ok"
    assert TEXT[:end].rstrip().endswith("Nausea was similar.")
    assert "BODY" not in TEXT[:end]
    assert parse_title(TEXT) == "A fixture randomized trial"
    assert abstract_region("TITLE: x\n\nBODY.INTRO:\ntext")[1] == "no_abstract_header"
    assert abstract_region("ABSTRACT:\nshort\n\nBODY.X:\nmore")[1] == "abstract_too_short"


def test_chunks_preserve_offsets_and_limits():
    chunks = chunk_article(TEXT)
    assert all(TEXT[a:b] == t for a, b, _, t in chunks)
    assert all(len(t.split()) <= 60 for _, _, _, t in chunks)
    assert not any(t.startswith(("TITLE", "ABSTRACT", "BODY")) for *_, t in chunks)
    secs = {sec for _, _, sec, _ in chunks}
    assert "ABSTRACT.RESULTS" in secs and "BODY.METHODS" in secs
    # the hard-wrapped abstract paragraph is one paragraph
    paras = paragraphs(TEXT)
    assert any("Pain was lower with\ndrug A" in TEXT[a:b] for a, b, _ in paras)


def test_evidence_recall():
    ctx = Context(1, 1, "retrieved", [Passage("P1", 10, 20, "x" * 10)], 1024, 5, False)
    assert evidence_recall(ctx, [(15, 30)]) == {"gold_available": True, "any_overlap": True, "full_cover": False}
    assert evidence_recall(ctx, [(12, 18)])["full_cover"] is True
    assert evidence_recall(ctx, [])["gold_available"] is False


def test_locate_span_html_entities_and_unlocatable():
    text = "Pain was lower (P < 0.01) with drug A."
    s = text.index("(P")
    ev = "(P &lt; 0.01)"
    assert locate_span(text, ev, s, s + len("(P < 0.01)")) == (s, s + len("(P < 0.01)"), "exact_after_unescape")
    assert locate_span(text, ev, 0, 3)[2] == "recovered_unique_unescaped"
    # offsets given but the string is nowhere in the text: not used as evidence
    assert locate_span(text, "absent string", 5, 9) == (-1, -1, "offset_text_mismatch")
