"""Scorer: separated validity checks for one structured answer.

Each check is reported on its own. None of them is treated as proof of the
others: an existing quote is a syntactic support check, not entailment, and
overlap with benchmark evidence can miss other valid evidence.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass

import jsonschema

from . import config as C
from .prompts import ANSWER_SCHEMA

MIN_QUOTE_WORDS = 4
FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.S)
THINK_RE = re.compile(r"<think>.*?</think>", re.S)


def norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def parse_response(text: str | None, finish_reason: str | None = None) -> tuple[str, dict | None, str]:
    """Return (status, answer, detail). status is one of
    valid, empty, no_json_object, invalid_json, schema_error, runtime_error."""
    if text is None:
        return "runtime_error", None, "no response recorded"
    t = THINK_RE.sub("", text).strip()
    t = FENCE_RE.sub("", t).strip()
    if not t:
        return "empty", None, ""
    i = t.find("{")
    if i < 0:
        return "no_json_object", None, "truncated" if finish_reason == "length" else ""
    try:
        obj, end = json.JSONDecoder().raw_decode(t[i:])
    except json.JSONDecodeError as e:
        return "invalid_json", None, ("truncated: " if finish_reason == "length" else "") + str(e)[:120]
    try:
        jsonschema.validate(obj, ANSWER_SCHEMA)
    except jsonschema.ValidationError as e:
        return "schema_error", obj if isinstance(obj, dict) else None, e.message[:160]
    trailing = t[i + end:].strip()
    return "valid", obj, ("trailing text" if trailing else "")


@dataclass
class Scored:
    parse_status: str
    parse_detail: str
    label_pred: str | None
    abstained: bool
    answered: bool              # parse valid and not abstained
    quote: str
    quote_words: int
    quote_too_short: bool
    quote_exists_strict: bool   # exact substring of the passages as displayed to the model
    quote_exists: bool          # whitespace-normalized substring, at least MIN_QUOTE_WORDS words (primary)
    locator_valid: bool         # passage_id names a supplied passage that contains the quote
    quote_start: int | None     # article offsets of the located quote
    quote_end: int | None
    gold_overlap: bool | None   # located quote overlaps any accepted benchmark span
    gold_token_f1: float | None
    label_correct: bool | None  # among answered prompts with a unanimous benchmark label
    task_success: bool          # answered, quote exists, locator valid, label correct

    def to_dict(self) -> dict:
        return asdict(self)


def _find_in_passages(quote_n: str, passages: list[dict]) -> list[tuple[str, int, int]]:
    hits = []
    for p in passages:
        pt = p["text"]
        pn, idx_map = _norm_with_map(pt)
        j = pn.find(quote_n)
        if j >= 0:
            s = p["start"] + idx_map[j]
            e = p["start"] + idx_map[j + len(quote_n) - 1] + 1
            hits.append((p["pid"], s, e))
    return hits


def _norm_with_map(s: str) -> tuple[str, list[int]]:
    """Whitespace-normalize s, returning the normalized string and a map from its indices to s indices."""
    out, idx = [], []
    prev_space = True
    for i, ch in enumerate(s):
        if ch.isspace():
            if not prev_space:
                out.append(" ")
                idx.append(i)
            prev_space = True
        else:
            out.append(ch)
            idx.append(i)
            prev_space = False
    if out and out[-1] == " ":
        out.pop()
        idx.pop()
    return "".join(out), idx


def _tokens(s: str) -> list[str]:
    return re.findall(r"\w+", s.lower())


def token_f1(a: str, b: str) -> float:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    from collections import Counter

    common = sum((Counter(ta) & Counter(tb)).values())
    if common == 0:
        return 0.0
    p, r = common / len(ta), common / len(tb)
    return 2 * p * r / (p + r)


def score_answer(raw: str | None, finish_reason: str | None, passages: list[dict], gold_label: str | None,
                 gold_spans: list[tuple[int, int]], article: str | None) -> Scored:
    status, ans, detail = parse_response(raw, finish_reason)
    valid = status == "valid"
    label = ans.get("label") if valid else None
    abstained = valid and label == C.ABSTAIN
    answered = valid and not abstained
    quote = (ans.get("evidence_quote") or "") if valid else ""
    qn = norm_ws(quote)
    words = len(qn.split()) if qn else 0
    too_short = words < MIN_QUOTE_WORDS
    ctx_join = "\n".join(norm_ws(p["text"]) for p in passages)  # the displayed passages
    strict = bool(quote) and quote in ctx_join
    hits = _find_in_passages(qn, passages) if qn else []
    exists = bool(hits) and not too_short
    pid = ans.get("passage_id") if valid else None
    loc_hits = [h for h in hits if h[0] == pid]
    locator_valid = exists and bool(loc_hits)
    chosen = loc_hits[0] if loc_hits else (hits[0] if hits else None)
    qs, qe = (chosen[1], chosen[2]) if chosen else (None, None)
    if chosen and gold_spans:
        ov = any(max(0, min(qe, e) - max(qs, s)) > 0 for s, e in gold_spans)
        f1 = max(token_f1(qn, article[s:e]) for s, e in gold_spans) if article else None
    elif gold_spans and answered and qn and article:
        ov = False
        f1 = max(token_f1(qn, article[s:e]) for s, e in gold_spans)
    else:
        ov, f1 = (None, None)
    correct = (label == gold_label) if (answered and gold_label is not None) else None
    success = bool(answered and exists and locator_valid and correct)
    return Scored(status, detail, label, abstained, answered, quote, words, too_short and bool(qn), strict, exists,
                  locator_valid, qs, qe, ov, None if f1 is None else round(f1, 4), correct, success)
