"""Frozen test runs (docs/analysis_plan.md, section 5).

Articles are processed in the fixed hash order. For each article every planned
condition is run before the next article starts, so that a time-budget stop
leaves the same article prefix in every condition.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone

from . import config as C
from .infer import GenConfig, LocalModel, ResponseCache, run_items
from .run import build_contexts, make_items, predictions_path, test_items_frame


def frozen() -> dict:
    return json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())


def gen_from_frozen(fz: dict, device: str | None = None) -> GenConfig:
    g = fz["gen"]
    return GenConfig(max_new_tokens=g["max_new_tokens"], do_sample=g["do_sample"], temperature=g.get("temperature"),
                     top_p=g.get("top_p"), top_k=g.get("top_k"), seed=g["seed"], device=device or g["device"],
                     dtype=g["dtype"], enable_thinking=g["enable_thinking"])


def run(model_name: str, conditions: list[str], budget_hours: float, run_id: str, log=print,
        device: str | None = None) -> dict:
    fz = frozen()
    frame = test_items_frame()
    gen = gen_from_frozen(fz, device)
    variant, decoding = fz["variant"], fz["decoding"]
    ctxs = {c: build_contexts(frame, c, "test") for c in conditions}
    caches = {c: ResponseCache(predictions_path("test", model_name, c, variant, decoding)) for c in conditions}
    model = LocalModel(model_name, gen)
    t0 = time.perf_counter()
    done, n_items, stopped = [], {c: 0 for c in conditions}, False
    for rank, g in frame.groupby("article_rank", sort=True):
        for c in conditions:
            items = make_items(g, ctxs[c], c, variant, "test")
            if items:
                run_items(model, items, caches[c], run_id)
                n_items[c] += len(items)
        done.append(int(g.pmcid.iloc[0]))
        el = time.perf_counter() - t0
        if len(done) % 10 == 0:
            log(f"[{model_name}] {len(done)} articles, items {n_items}, {el / 60:.1f} min")
        if el > budget_hours * 3600:
            stopped = True
            log(f"[{model_name}] time budget reached after {len(done)} articles")
            break
    summary = {"model": model_name, "conditions": conditions, "variant": variant, "decoding": decoding,
               "run_id": run_id, "articles_completed": len(done), "articles_in_sample": int(frame.article_rank.nunique()),
               "items": n_items, "stopped_by_time_budget": stopped, "budget_hours": budget_hours,
               "elapsed_s": round(time.perf_counter() - t0, 1), "completed_pmcids": done, "gen_config": gen.key_part(),
               "device": gen.device, "dtype": gen.dtype, "env": model.env,
               "utc_end": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    p = C.RESULTS / "runs" / f"{run_id}__{model_name}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(summary, indent=2))
    return summary


def main(log=print) -> list[dict]:
    fz = frozen()
    b = fz["time_budgets_hours"]
    out = [run("qwen3-1.7b", ["retrieved", "abstract", "oracle"], b["qwen3-1.7b"], "test-main", log),
           run("qwen3-0.6b", ["retrieved", "abstract", "oracle"], b["qwen3-0.6b"], "test-main", log),
           run("qwen3-4b-instruct-2507", fz["4b_conditions"], b["qwen3-4b-instruct-2507"], "test-main", log)]
    return out


if __name__ == "__main__":
    main(log=lambda m: print(m, flush=True))
