"""Journal submission package, DOI deposit package, and the delivery guide.

Figures are exported from the SVG sources with headless Google Chrome (vector
PDF and a 4x PNG), and the PNG is converted to a 600-dpi TIFF with macOS sips.
The journal package holds the files to upload in upload order, reference copies
for form fields, and records for the author. The DOI deposit package holds the
analysis archive (the same file as Supplementary File 2) with Zenodo metadata.
Guide texts are kept in manuscript/submission/package/, outside the public
archive, because they carry contact details and journal-only statements.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from pathlib import Path

from . import config as C

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
ORDER = [("Figure1", "fig2_answer_outcomes"), ("Figure2", "fig1_quote_valid_wrong"),
         ("Figure3", "fig3_rejection_rule"), ("Figure4", "fig4_risk_coverage")]
SUB = C.ROOT / "manuscript" / "submission"
OUT = SUB / "figures"
TEXTS = SUB / "package"
SLUG = "evidence-model-audit"
JOURNAL_ZIP = f"03-{SLUG}-JOURNAL-SUBMISSION-JAMIA-OPEN.zip"
DOI_ZIP = f"03-{SLUG}-DOI-DEPOSIT.zip"
BUNDLE_ZIP = f"03-{SLUG}-PROJECT-BUNDLE.zip"
FIXED = (2026, 10, 7, 0, 0, 0)


def _run_until_file(cmd: list[str], out: Path, timeout: float = 90) -> None:
    """Run headless Chrome until the output file exists and stops growing, then end the process.
    (Headless Chrome sometimes keeps running after writing its output.)"""
    import time

    if out.exists():
        out.unlink()
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    t0, last = time.time(), -1
    try:
        while time.time() - t0 < timeout:
            if proc.poll() is not None and out.exists():
                return
            if out.exists():
                size = out.stat().st_size
                if size > 0 and size == last:
                    return
                last = size
            time.sleep(1.0)
        raise TimeoutError(f"no output from Chrome for {out.name}")
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()


def export_figures(log=print) -> list[Path]:
    OUT.mkdir(parents=True, exist_ok=True)
    made = []
    if not Path(CHROME).exists():
        log("Google Chrome not found; figure files not exported (SVG sources remain in results/figures)")
        return made
    for name, src in ORDER:
        svg = (C.RESULTS / "figures" / f"{src}.svg").read_text(encoding="utf-8")
        w = int(re.search(r'width="(\d+)"', svg).group(1))
        h = int(re.search(r'height="(\d+)"', svg).group(1))
        html = OUT / f"{name}.html"
        html.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>@page{{size:{w}px {h}px;margin:0}}"
                        f"html,body{{margin:0;padding:0;background:#fff}}svg{{display:block}}</style></head><body>{svg}"
                        f"</body></html>", encoding="utf-8")
        png, pdf, tif = OUT / f"{name}.png", OUT / f"{name}.pdf", OUT / f"{name}.tiff"
        base = [CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
                "--no-default-browser-check", f"--user-data-dir={OUT / '.chrome'}"]
        _run_until_file(base + [f"--screenshot={png}", f"--window-size={w},{h}", "--force-device-scale-factor=4",
                                html.as_uri()], png)
        _run_until_file(base + [f"--print-to-pdf={pdf}", "--no-pdf-header-footer", html.as_uri()], pdf)
        subprocess.run(["sips", "-s", "format", "tiff", "-s", "formatOptions", "lzw", "-s", "dpiWidth", "600", "-s", "dpiHeight", "600", str(png),
                        "--out", str(tif)], check=True, capture_output=True, timeout=120)
        html.unlink()
        made += [pdf, png, tif]
        log(f"figure files: {name} ({w}x{h} px source)")
    shutil.rmtree(OUT / ".chrome", ignore_errors=True)
    return made


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write_zip(dest: Path, members: list[tuple[str, bytes]]) -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for arc, data in members:
            zi = zipfile.ZipInfo(arc, date_time=FIXED)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, data)
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
    h = _sha(dest)
    (dest.parent / (dest.name + ".sha256")).write_text(f"{h}  {dest.name}\n")
    return {"path": str(dest), "bytes": dest.stat().st_size, "sha256": h, "members": len(members)}


def _text(name: str, vals: dict[str, str]) -> str:
    t = (TEXTS / name).read_text(encoding="utf-8")
    t = re.sub(r"\{\{([a-zA-Z0-9_]+)\}\}", lambda m: vals.get(m.group(1), m.group(0)), t)
    left = re.findall(r"\{\{[a-zA-Z0-9_]+\}\}", t)
    if left:
        raise KeyError(f"unfilled placeholders in {name}: {sorted(set(left))}")
    return t


def _contents(rows: list[tuple[str, int]]) -> str:
    return "| File | Size |\n|---|---:|\n" + "\n".join(f"| `{a}` | {n:,} bytes |" for a, n in rows)


def build_journal(vals: dict[str, str], source_zip: Path, log=print) -> dict:
    from .manuscript import to_docx

    to_docx((SUB / "declarations.md").read_text(encoding="utf-8"), SUB / "declarations.docx")
    upload = [("1_upload/01_Manuscript.docx", SUB / "manuscript_submission.docx"),
              ("1_upload/02_Cover_letter.docx", SUB / "cover_letter.docx")]
    upload += [(f"1_upload/{i + 3:02d}_{name}.tiff", OUT / f"{name}.tiff") for i, (name, _) in enumerate(ORDER)]
    upload += [("1_upload/07_Supplementary_File_1.docx", C.ROOT / "manuscript" / "supplement.docx"),
               ("1_upload/08_Supplementary_File_2.zip", source_zip)]
    ref = [("2_reference_copies/title_page.docx", SUB / "title_page.docx"),
           ("2_reference_copies/title_page.md", SUB / "title_page.md"),
           ("2_reference_copies/manuscript_submission.md", SUB / "manuscript_submission.md"),
           ("2_reference_copies/cover_letter.md", SUB / "cover_letter.md"),
           ("2_reference_copies/declarations.md", SUB / "declarations.md"),
           ("2_reference_copies/declarations.docx", SUB / "declarations.docx"),
           ("2_reference_copies/author_information.md", SUB / "author_information.md")]
    ref += [(f"2_reference_copies/figures_other_formats/{name}.{ext}", OUT / f"{name}.{ext}")
            for name, _ in ORDER for ext in ("pdf", "png")]
    att = _text("author_attestations.md", vals)
    to_docx(att, SUB / "author_attestations.docx")
    records = [("3_keep_for_your_records/author_attestations.docx", SUB / "author_attestations.docx"),
               ("3_keep_for_your_records/journal_fit.md", C.DOCS / "journal_fit.md"),
               ("3_keep_for_your_records/clean_room_record.json", C.RESULTS / "validation" / "clean_room.json")]
    sample = C.ROOT / "private" / "validation_sample_20.csv"
    if sample.exists():
        records.append(("3_keep_for_your_records/author_check_sample_20.csv", sample))
    for arc, p in upload + ref + records:
        if not p.exists():
            raise FileNotFoundError(p)
    files = [(a, p.read_bytes()) for a, p in upload + ref + records]
    files += [("2_reference_copies/ai_use_statement.txt", _text("ai_use_statement.txt", vals).encode()),
              ("3_keep_for_your_records/author_attestations.md", att.encode()),
              ("3_keep_for_your_records/submission_checklist.md", _text("submission_checklist.md", vals).encode())]
    files.sort(key=lambda x: x[0])
    guide = _text("submission_guide.md", vals).rstrip() + "\n\n## Contents\n\n" + _contents([(a, len(b)) for a, b in files]) + "\n"
    rec = _write_zip(C.ROOT / "deliverables" / JOURNAL_ZIP, [("00_READ_FIRST_SUBMISSION_GUIDE.md", guide.encode())] + files)
    log(f"journal package: {rec['path']} {rec['bytes']:,} bytes sha256 {rec['sha256']}")
    return rec


def build_deposit(vals: dict[str, str], source_zip: Path, log=print) -> dict:
    desc = _text("zenodo_description.txt", vals).strip()
    meta = json.loads(_text("zenodo_metadata.json", vals))
    meta["description"] = desc
    files = [("upload_these_files/" + source_zip.name, source_zip.read_bytes()),
             ("upload_these_files/README.md", (C.ROOT / "README.md").read_bytes()),
             ("metadata/zenodo_metadata.json", (json.dumps(meta, indent=2, ensure_ascii=False) + "\n").encode()),
             ("metadata/description.txt", (desc + "\n").encode())]
    guide = _text("deposit_guide.md", vals)
    rec = _write_zip(C.ROOT / "deliverables" / DOI_ZIP, [("00_READ_FIRST_DEPOSIT_GUIDE.md", guide.encode())] + files)
    log(f"DOI deposit package: {rec['path']} {rec['bytes']:,} bytes sha256 {rec['sha256']}")
    return rec


def write_guide(vals: dict[str, str], log=print) -> Path:
    v = dict(vals)
    for key, name in (("bundle", BUNDLE_ZIP), ("journal", JOURNAL_ZIP), ("deposit", DOI_ZIP)):
        p = C.ROOT / "deliverables" / name
        v[f"{key}_bytes"], v[f"{key}_sha256"] = f"{p.stat().st_size:,}", _sha(p)
    out = C.ROOT / "deliverables" / "WHAT_GOES_WHERE.md"
    out.write_text(_text("what_goes_where.md", v), encoding="utf-8")
    log(f"delivery guide: {out}")
    return out


def main(log=print) -> dict:
    from .manuscript import values

    if not TEXTS.exists():
        log("guide texts not found; journal and DOI packages skipped")
        return {}
    export_figures(log)
    source_zip = C.ROOT / "site" / "projects" / SLUG / "downloads" / f"{SLUG}-source.zip"
    old = C.ROOT / "deliverables" / f"03-{SLUG}-JAMIA-OPEN-SUBMISSION.zip"
    for p in (old, old.with_name(old.name + ".sha256")):
        p.unlink(missing_ok=True)
    vals = values()
    pv = C.ROOT / "manuscript" / "placeholder_values.json"  # adds the word counts computed at render time
    if pv.exists():
        vals.update(json.loads(pv.read_text(encoding="utf-8")))
    tp = (SUB / "title_page.md").read_text(encoding="utf-8")
    vals["wc_line"] = re.search(r"\*\*Word count:\*\* (.*)", tp).group(1)
    vals["source_zip_name"] = source_zip.name
    vals["source_zip_bytes"] = f"{source_zip.stat().st_size:,}"
    vals["source_zip_mb"] = f"{source_zip.stat().st_size / 1e6:.1f}"
    vals["source_zip_sha256"] = _sha(source_zip)
    refs = (C.ROOT / "manuscript" / "manuscript.md").read_text(encoding="utf-8").split("## References")[1].split("## Figure legends")[0]
    vals["n_references"] = str(len(re.findall(r"(?m)^\d+\. ", refs)))
    recs = {"journal": build_journal(vals, source_zip, log), "deposit": build_deposit(vals, source_zip, log)}
    write_guide(vals, log)
    return recs
