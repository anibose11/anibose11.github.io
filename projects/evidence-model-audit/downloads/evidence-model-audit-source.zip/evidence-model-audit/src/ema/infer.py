"""Local LLM inference with an append-only response cache.

Every call records the rendered prompt hash, token counts, wall-clock latency,
finish reason, device, library versions, and the raw response. A cached record
is reused only when the model revision, rendered prompt, and generation
settings all match. Runtime errors are recorded as records with error set so
that they stay in the evaluation denominator.
"""
from __future__ import annotations

import hashlib
import json
import platform
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from . import config as C


@dataclass(frozen=True)
class GenConfig:
    max_new_tokens: int = 256
    do_sample: bool = False
    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    seed: int = 20261007
    device: str = "cpu"
    dtype: str = "float32"
    enable_thinking: bool = False

    def key_part(self) -> dict:
        return {"max_new_tokens": self.max_new_tokens, "do_sample": self.do_sample, "temperature": self.temperature,
                "top_p": self.top_p, "top_k": self.top_k, "seed": self.seed if self.do_sample else None,
                "enable_thinking": self.enable_thinking}


class LocalModel:
    def __init__(self, name: str, gen: GenConfig):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.name = name
        self.spec = C.MODELS[name]
        self.gen = gen
        path = C.MODELS_DIR / name
        if not (path / "config.json").exists():
            raise FileNotFoundError(f"model {name} not acquired at {path}; run `ema acquire --models {name}`")
        self.torch = torch
        import os

        if os.environ.get("EMA_THREADS"):
            torch.set_num_threads(int(os.environ["EMA_THREADS"]))
        dtype = getattr(torch, gen.dtype)
        self.tok = AutoTokenizer.from_pretrained(str(path))
        self.tok.padding_side = "left"
        self.model = AutoModelForCausalLM.from_pretrained(str(path), dtype=dtype).to(gen.device)
        self.model.eval()
        import transformers

        self.env = {"torch": torch.__version__, "transformers": transformers.__version__, "device": gen.device,
                    "dtype": gen.dtype, "machine": platform.machine(), "processor": platform.processor(),
                    "threads": torch.get_num_threads()}

    def render(self, messages: list[dict]) -> str:
        kwargs = {}
        if self.spec.get("thinking_switch"):
            kwargs["enable_thinking"] = self.gen.enable_thinking
        return self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True, **kwargs)

    def generate(self, prompts: list[str]) -> list[dict]:
        torch = self.torch
        enc = self.tok(prompts, return_tensors="pt", padding=True, add_special_tokens=False).to(self.gen.device)
        kw = dict(max_new_tokens=self.gen.max_new_tokens, do_sample=self.gen.do_sample,
                  pad_token_id=self.tok.pad_token_id or self.tok.eos_token_id)
        if self.gen.do_sample:
            torch.manual_seed(self.gen.seed)
            kw.update(temperature=self.gen.temperature, top_p=self.gen.top_p, top_k=self.gen.top_k)
        else:
            kw.update(temperature=None, top_p=None, top_k=None)
        t0 = time.perf_counter()
        with torch.inference_mode():
            out = self.model.generate(**enc, **kw)
        dt = time.perf_counter() - t0
        res = []
        in_len = enc["input_ids"].shape[1]
        eos = set([self.tok.eos_token_id] + list(getattr(self.model.generation_config, "eos_token_id", []) or []))
        for i in range(len(prompts)):
            gen_ids = out[i, in_len:].tolist()
            n_gen = len(gen_ids)
            # strip padding after EOS
            stop = next((j for j, t in enumerate(gen_ids) if t in eos), None)
            finish = "eos" if stop is not None else "length"
            kept = gen_ids[: stop] if stop is not None else gen_ids
            res.append({"response": self.tok.decode(kept, skip_special_tokens=True),
                        "prompt_tokens": int(enc["attention_mask"][i].sum().item()),
                        "gen_tokens": len(kept) + (1 if stop is not None else 0), "finish_reason": finish,
                        "latency_s": round(dt / len(prompts), 4), "batch_size": len(prompts), "batch_wall_s": round(dt, 4)})
        return res


def cache_key(model: str, revision: str, rendered: str, gen: GenConfig) -> str:
    h = hashlib.sha256()
    h.update(json.dumps({"model": model, "revision": revision, "gen": gen.key_part()}, sort_keys=True).encode())
    h.update(rendered.encode("utf-8"))
    return h.hexdigest()


class ResponseCache:
    def __init__(self, path: Path):
        self.path = path
        self.records: dict[str, dict] = {}
        if path.exists():
            for line in path.read_text(encoding="utf-8").split("\n"):
                if line.strip():
                    r = json.loads(line)
                    self.records[r["cache_key"]] = r

    def get(self, key: str) -> dict | None:
        r = self.records.get(key)
        return r if r and not r.get("error") else None

    def add(self, rec: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        self.records[rec["cache_key"]] = rec


def run_items(model: LocalModel, items: list[dict], cache: ResponseCache, run_id: str, batch_size: int = 1,
              log_every: int = 10, progress=None) -> list[dict]:
    """items: dicts with prompt_id, pmcid, condition, variant, messages. Returns records in item order."""
    spec = C.MODELS[model.name]
    todo, out = [], {}
    for it in items:
        rendered = model.render(it["messages"])
        key = cache_key(model.name, spec["revision"], rendered, model.gen)
        it = {**it, "rendered": rendered, "cache_key": key}
        hit = cache.get(key)
        if hit:
            out[key] = hit
        else:
            todo.append(it)
    done = 0
    t_start = time.perf_counter()
    for b in range(0, len(todo), batch_size):
        batch = todo[b:b + batch_size]
        try:
            gens = model.generate([x["rendered"] for x in batch])
            errs = [None] * len(batch)
        except Exception as e:  # recorded, never silently dropped
            gens = [{"response": None, "prompt_tokens": None, "gen_tokens": None, "finish_reason": "error",
                     "latency_s": None, "batch_size": len(batch), "batch_wall_s": None}] * len(batch)
            errs = [f"{type(e).__name__}: {e}"[:500]] * len(batch)
        for x, g, err in zip(batch, gens, errs):
            rec = {"cache_key": x["cache_key"], "run_id": run_id, "model": model.name, "repo_id": spec["repo_id"],
                   "revision": spec["revision"], "prompt_id": int(x["prompt_id"]), "pmcid": int(x["pmcid"]),
                   "condition": x["condition"], "variant": x["variant"], "split": x.get("split"),
                   "rendered_sha256": hashlib.sha256(x["rendered"].encode("utf-8")).hexdigest(),
                   "gen_config": model.gen.key_part(), "env": model.env, **g, "error": err,
                   "utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
            cache.add(rec)
            out[x["cache_key"]] = rec
        done += len(batch)
        if progress and (done % log_every < batch_size or done == len(todo)):
            el = time.perf_counter() - t_start
            progress(f"{model.name} {done}/{len(todo)} new calls, {el:.0f}s elapsed, {el / max(1, done):.2f}s per call")
    keys = []
    for it in items:
        rendered = model.render(it["messages"])
        keys.append(cache_key(model.name, spec["revision"], rendered, model.gen))
    return [out[k] for k in keys]
