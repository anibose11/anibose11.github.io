"""source_manifest.json: resolved sources, versions, sizes, checksums, and permitted uses."""
from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from . import config as C
from .acquire import sha256

ACCESS_DATE = "2026-10-07"


def dir_digest(d: Path, pattern: str) -> dict:
    files = sorted(d.glob(pattern))
    h = hashlib.sha256()
    total = 0
    for f in files:
        b = f.read_bytes()
        total += len(b)
        h.update(f.name.encode() + b"\0" + hashlib.sha256(b).digest())
    return {"files": len(files), "bytes": total, "digest_sha256": h.hexdigest(),
            "digest_rule": "sha256 over sorted (file name, NUL, sha256(file bytes)) records"}


def build() -> dict:
    ann = C.EI_ANN_DIR
    repo_head = subprocess.run(["git", "-C", str(C.EI_REPO_DIR), "rev-parse", "HEAD"], capture_output=True,
                               text=True).stdout.strip()
    commit_date = subprocess.run(["git", "-C", str(C.EI_REPO_DIR), "log", "-1", "--format=%cI"], capture_output=True,
                                 text=True).stdout.strip()
    acq = json.loads((C.DATA_INTERIM / "acquire_record.json").read_text())
    files = {}
    for rel in ["annotations/annotations_merged.csv", "annotations/prompts_merged.csv",
                "annotations/splits/train_article_ids.txt", "annotations/splits/validation_article_ids.txt",
                "annotations/splits/test_article_ids.txt", "annotations/README.md", "LICENSE", "README.md",
                "README.annotation_process.md"]:
        p = C.EI_REPO_DIR / rel
        files[rel] = {"bytes": p.stat().st_size, "sha256": sha256(p)}
    manifest = {
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sources": [
            {
                "id": "evidence-inference-repo",
                "role": "primary corpus (prompts, annotations, splits, article texts)",
                "resolved_url": C.EI_REPO_URL, "commit": repo_head, "commit_date": commit_date,
                "access_date": ACCESS_DATE,
                "release": "Evidence Inference 2.0 data as merged into the repository master branch (pull request 16, "
                           "February 2021); the last commit is dated 2021-06-18",
                "reference_period": "annotation rounds 2018 to 2020 on PubMed Central Open Access trial reports",
                "permitted_use": "Repository code under the MIT License. Article texts are PubMed Central Open Access "
                                 "articles with per-article licenses; they are not redistributed in this project's "
                                 "public archive. Short excerpts appear only for articles whose license was checked.",
                "files": files,
                "txt_files": dir_digest(ann / "txt_files", "*.txt"),
                "abstracts": dir_digest(ann / "abstracts", "*.abst"),
                "citation": ["DeYoung J, Lehman E, Nye B, Marshall IJ, Wallace BC. Evidence Inference 2.0: More Data, "
                             "Better Models. Proceedings of the 19th SIGBioMed Workshop on Biomedical Language "
                             "Processing (BioNLP 2020), pages 123-132. doi:10.18653/v1/2020.bionlp-1.13",
                             "Lehman E, DeYoung J, Barzilay R, Wallace BC. Inferring Which Medical Treatments Work from "
                             "Reports of Clinical Trials. NAACL-HLT 2019, pages 3705-3717. doi:10.18653/v1/N19-1371"],
            },
            {
                "id": "evidence-inference-official-v2.0",
                "role": "reconciliation reference (not used for scoring)",
                "resolved_url": C.EI_OFFICIAL_TARBALL_URL, "last_modified_header": "Tue, 12 May 2020 01:43:58 GMT",
                "access_date": ACCESS_DATE, **{k: acq["corpus"]["official_tarball"][k] for k in ("sha256", "bytes")},
                "notes": "Prompts and split files identical to the pinned repository; annotation rows identical except "
                         "693 rows labelled 'significantly increase' (Label Code 1) and re-aligned offsets for a "
                         "different text rendering (no TITLE line, CRLF line endings). See docs/data_provenance.md.",
            },
            {
                "id": "evidence-inference-official-test-answers",
                "role": "reconciliation reference (not used for scoring)",
                "resolved_url": C.EI_OFFICIAL_ANSWERS_URL, "access_date": ACCESS_DATE,
                **{k: acq["corpus"]["official_test_answers"][k] for k in ("sha256", "bytes")},
            },
        ],
        "rejected_urls": [
            {"url": "https://evidence-inference.ebm-nlp.com/media/annotations_merged.cbdb3024.csv",
             "reason": "served text/html (1,419 bytes, the site's application page) instead of CSV"},
            {"url": "https://evidence-inference.ebm-nlp.com/media/prompts_merged.a58d3944.csv",
             "reason": "served text/html (1,419 bytes, the site's application page) instead of CSV"},
        ],
        "models": [],
        "rebuild_limits": "The repository and Hugging Face snapshots are pinned by commit hash, so the inputs can be "
                          "fetched again exactly while those hosts keep them. The project site tarball has no "
                          "version pin beyond its checksum.",
    }
    for name, rec in acq.get("models", {}).items():
        spec = C.MODELS[name]
        manifest["models"].append({
            "name": name, "repo_id": spec["repo_id"], "revision": spec["revision"], "role": spec["role"],
            "resolved_url": f"https://huggingface.co/{spec['repo_id']}/tree/{spec['revision']}",
            "license": "Apache-2.0", "access_date": ACCESS_DATE, "files": rec["files"],
        })
    out = C.ROOT / "source_manifest.json"
    out.write_text(json.dumps(manifest, indent=2))
    return manifest


if __name__ == "__main__":
    build()
