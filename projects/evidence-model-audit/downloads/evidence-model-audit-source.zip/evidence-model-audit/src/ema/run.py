"""Sample definitions, item construction, context storage, and model runs."""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from . import config as C
from . import contexts as X
from . import prompts as PR
from .data import load_processed

BUDGET_TOKENS = 1024
CONDITIONS = ("retrieved", "abstract", "oracle")
TEST_ORDER_SALT = "ema-2026-10-07:"
DEV_ORDER_SALT = "ema-dev-2026-10-07:"
DEV_N_ARTICLES = 100


def article_order(pmcids, salt: str) -> list[int]:
    return sorted(set(int(p) for p in pmcids), key=lambda p: hashlib.sha256(f"{salt}{p}".encode()).hexdigest())


def test_items_frame(prompts: pd.DataFrame | None = None) -> pd.DataFrame:
    """All model items in the frozen test sample, in processing order. Uses no labels:
    membership depends on annotation status and the corpus flag list only."""
    if prompts is None:
        _, prompts = load_processed()
    t = prompts[(prompts.split == "test") & prompts.ico_nonempty & prompts.flag.ne("incorrect")
                & prompts.label_status.isin(["unanimous", "accepted_disagreement"])].copy()
    order = {p: i for i, p in enumerate(article_order(prompts[prompts.split == "test"].pmcid, TEST_ORDER_SALT))}
    t["article_rank"] = t.pmcid.map(order)
    return t.sort_values(["article_rank", "prompt_id"]).reset_index(drop=True)


def dev_items_frame(prompts: pd.DataFrame | None = None, n_articles: int = DEV_N_ARTICLES) -> pd.DataFrame:
    if prompts is None:
        _, prompts = load_processed()
    v = prompts[(prompts.split == "validation") & prompts.eligible_primary].copy()
    order = article_order(v.pmcid, DEV_ORDER_SALT)[:n_articles]
    rank = {p: i for i, p in enumerate(order)}
    v = v[v.pmcid.isin(rank)].copy()
    v["article_rank"] = v.pmcid.map(rank)
    return v.sort_values(["article_rank", "prompt_id"]).reset_index(drop=True)


def contexts_path(split_tag: str, condition: str) -> Path:
    return C.RESULTS / "contexts" / f"{split_tag}_{condition}.jsonl"


def build_contexts(frame: pd.DataFrame, condition: str, split_tag: str, count=None, budget: int = BUDGET_TOKENS,
                   force: bool = False) -> dict[int, X.Context]:
    path = contexts_path(split_tag, condition)
    have: dict[int, X.Context] = {}
    if path.exists() and not force:
        for line in path.read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            d = json.loads(line)
            d["passages"] = [X.Passage(**p) for p in d["passages"]]
            have[d["prompt_id"]] = X.Context(**d)
    need = [r for r in frame.itertuples() if int(r.prompt_id) not in have]
    if need:
        count = count or X.TokenCounter()
        bm = X.load_bm25()
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            for r in need:
                ctx = X.build_context(r, condition, count, budget, bm)
                ctx.prompt_id, ctx.pmcid = int(ctx.prompt_id), int(ctx.pmcid)
                f.write(json.dumps(ctx.to_json(), ensure_ascii=False) + "\n")
                have[ctx.prompt_id] = ctx
    return have


def make_items(frame: pd.DataFrame, ctxs: dict[int, X.Context], condition: str, variant: str, split_tag: str) -> list[dict]:
    items = []
    for r in frame.itertuples():
        ctx = ctxs[int(r.prompt_id)]
        if not ctx.available:
            continue
        items.append({"prompt_id": int(r.prompt_id), "pmcid": int(r.pmcid), "condition": condition,
                      "variant": variant, "split": split_tag, "messages": PR.messages(r, ctx, variant)})
    return items


def predictions_path(split_tag: str, model: str, condition: str, variant: str, decoding: str) -> Path:
    return C.RESULTS / "predictions" / split_tag / f"{model}__{condition}__{variant}__{decoding}.jsonl"


def run_model(model_name: str, frame: pd.DataFrame, condition: str, variant: str, split_tag: str, gen, decoding: str,
              run_id: str, time_budget_s: float | None = None, log=print) -> dict:
    """Run one model on one condition, whole articles in frame order, stopping at an article boundary
    when the time budget is exhausted. Returns a summary."""
    from .infer import LocalModel, ResponseCache, run_items

    ctxs = build_contexts(frame, condition, split_tag)
    cache = ResponseCache(predictions_path(split_tag, model_name, condition, variant, decoding))
    model = LocalModel(model_name, gen)
    t0 = time.perf_counter()
    done_articles, n_items, stopped = [], 0, False
    for pmcid, g in frame.groupby("article_rank", sort=True):
        items = make_items(g, ctxs, condition, variant, split_tag)
        if items:
            run_items(model, items, cache, run_id)
            n_items += len(items)
        done_articles.append(int(g.pmcid.iloc[0]))
        el = time.perf_counter() - t0
        if len(done_articles) % 10 == 0:
            log(f"[{model_name} {condition}] {len(done_articles)} articles, {n_items} items, {el / 60:.1f} min")
        if time_budget_s is not None and el > time_budget_s:
            stopped = True
            break
    summary = {"model": model_name, "condition": condition, "variant": variant, "split": split_tag,
               "decoding": decoding, "run_id": run_id, "articles_completed": len(done_articles),
               "articles_in_frame": int(frame.article_rank.nunique()), "items": n_items,
               "stopped_by_time_budget": stopped, "elapsed_s": round(time.perf_counter() - t0, 1),
               "completed_pmcids": done_articles, "gen_config": gen.key_part(), "device": gen.device,
               "dtype": gen.dtype, "utc_end": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    p = C.RESULTS / "runs" / f"{run_id}__{model_name}__{condition}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(summary, indent=2))
    return summary


def budget_recall(budgets=(512, 1024, 1536)) -> dict:
    """Evidence recall of the retrieved context on eligible validation prompts with located evidence, by budget."""
    from .contexts import TokenCounter, build_context, evidence_recall, load_bm25

    _, prompts = load_processed()
    va = prompts[(prompts.split == "validation") & prompts.eligible_primary & prompts.n_gold_spans.gt(0)]
    cnt, bm = TokenCounter(), load_bm25()
    out = {"prompts": int(len(va)), "budgets": {}}
    for b in budgets:
        anyo = full = 0
        for r in va.itertuples():
            ev = evidence_recall(build_context(r, "retrieved", cnt, b, bm), [tuple(s) for s in json.loads(r.gold_spans)])
            anyo += ev["any_overlap"]
            full += ev["full_cover"]
        out["budgets"][str(b)] = {"any_overlap": anyo / len(va), "full_cover": full / len(va)}
    p = C.RESULTS / "dev" / "retrieval_budget_recall.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out, indent=2))
    return out
