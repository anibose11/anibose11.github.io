"""Pinned sources, paths, and fixed study settings.

Every value that affects a result lives here or in config/frozen_config.json so
that a rerun can be compared with the original run.
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(os.environ.get("EMA_ROOT", Path(__file__).resolve().parents[2]))
DATA_RAW = ROOT / "data" / "raw"
DATA_INTERIM = ROOT / "data" / "interim"
DATA_PROCESSED = ROOT / "data" / "processed"
MODELS_DIR = Path(os.environ.get("EMA_MODELS", ROOT / "models"))
RESULTS = ROOT / "results"
CONFIG_DIR = ROOT / "config"
DOCS = ROOT / "docs"
EVIDENCE = ROOT / "evidence"
CACHE = ROOT / "data" / "cache"

# Primary corpus: the Evidence Inference repository at a pinned commit. The
# official project tarball (v2.0, 2020-05-12) is downloaded as a reconciliation
# reference; see docs/data_provenance.md for the comparison.
EI_REPO_URL = "https://github.com/jayded/evidence-inference.git"
EI_REPO_COMMIT = "a661e8c14f973398380c8865cf2f27a535aaaf6d"
EI_REPO_DIR = DATA_RAW / "evidence-inference-repo"
EI_ANN_DIR = EI_REPO_DIR / "annotations"
EI_OFFICIAL_TARBALL_URL = "https://evidence-inference.ebm-nlp.com/v2.0.tar.gz"
EI_OFFICIAL_TARBALL_SHA256 = "6abe0d4ec0d331834981c0171c3c79d47515761867f82f1dc6066e43863a1586"
EI_OFFICIAL_ANSWERS_URL = "https://evidence-inference.ebm-nlp.com/answers/test_annotations_merged.csv"
EI_OFFICIAL_ANSWERS_SHA256 = "9b545ae24250fe501856743b27644544f8100abededce769307f4baee2dcf446"
EI_OFFICIAL_DIR = DATA_RAW / "official"

MODELS = {
    "qwen3-1.7b": {
        "repo_id": "Qwen/Qwen3-1.7B",
        "revision": "70d244cc86ccca08cf5af4e1e306ecf908b1ad5e",
        "role": "primary",
        "thinking_switch": True,
    },
    "qwen3-0.6b": {
        "repo_id": "Qwen/Qwen3-0.6B",
        "revision": "c1899de289a04d12100db370d81485cdf75e47ca",
        "role": "lower-capacity comparison",
        "thinking_switch": True,
    },
    "qwen3-4b-instruct-2507": {
        "repo_id": "Qwen/Qwen3-4B-Instruct-2507",
        "revision": "cdbee75f17c01a7cc42f958dc650907174af0554",
        "role": "larger extension",
        "thinking_switch": False,
    },
}

LABELS = ["significantly increased", "no significant difference", "significantly decreased"]
LABEL_CODE = {1: "significantly increased", 0: "no significant difference", -1: "significantly decreased"}
ABSTAIN = "cannot determine"

# Flagged prompt IDs copied from annotations/README.md at the pinned commit.
FLAGGED_INCORRECT = [911, 912, 1262, 1261, 3044, 3248, 3111, 3620, 4308, 4490, 4491, 4324, 4325, 4492,
                     4824, 5000, 5001, 5002, 5046, 5047, 4948, 5639, 5710, 5752, 5775, 5782, 5841, 5843,
                     5861, 5862, 5863, 5964, 5965, 5966, 5975, 4807, 5776, 5777, 5778, 5779, 5780, 5781,
                     6034, 6065, 6066, 6666, 6667, 6668, 6669, 7040, 7042, 7944, 8590, 8605, 8606, 8639,
                     8640, 8745, 8747, 8749, 8877, 8878, 8593, 8631, 8635, 8884, 8886, 8773, 10032, 10035,
                     8876, 8875, 8885, 8917, 8921, 8118, 10885, 10886, 10887, 10888, 10889, 10890]
FLAGGED_QUESTIONABLE = [7811, 7812, 7813, 7814, 7815, 8197, 8198, 8199, 8200, 8201, 9429, 9430, 9431, 8536, 9432]
FLAGGED_MALFORMED = [3514, 346, 5037, 4715, 8767, 9295, 9297, 8870, 9862]
