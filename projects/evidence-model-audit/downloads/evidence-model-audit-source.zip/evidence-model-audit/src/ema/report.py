"""Render stage: figures, tables, workbook, Tableau exports, data dictionary, public viewer, manuscript, report."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import pandas as pd

from . import config as C
from . import figures as F

OUT = C.RESULTS / "figures"


def _res() -> dict:
    return json.loads((C.RESULTS / "analysis" / "results.json").read_text())


LLM_ORDER = [("qwen3-1.7b", "retrieved"), ("qwen3-0.6b", "retrieved"), ("qwen3-4b-instruct-2507", "retrieved"),
             ("tfidf-lr", "retrieved"), ("qwen3-1.7b", "abstract"), ("qwen3-0.6b", "abstract"), ("tfidf-lr", "abstract"),
             ("qwen3-1.7b", "oracle"), ("qwen3-0.6b", "oracle"), ("tfidf-lr", "oracle")]


def fig_headline(res: dict) -> tuple[str, pd.DataFrame]:
    rows, tab = [], []
    for m, c in LLM_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"]:
            continue
        h = res["systems"][k]["metrics"]["headline_qvwr"]
        est = h["estimate"]
        lab = f"{h['numerator']} of {h['denominator']}" if h["denominator"] else "0 quote-valid"
        tip = (f"{F.LABEL[m]}, {F.COND[c]}: {h['numerator']} of {h['denominator']} quote-valid answers had the wrong label"
               + (f" ({est * 100:.1f}%, 95% CI {h['ci_low'] * 100:.1f}% to {h['ci_high'] * 100:.1f}%)" if est is not None else ""))
        rows.append({"group": c, "model": m, "est": est, "lo": h["ci_low"], "hi": h["ci_high"], "label": lab, "tip": tip})
        tab.append({"condition": c, "system": F.LABEL[m], "wrong": h["numerator"], "quote_valid_answers": h["denominator"],
                    "share_wrong": est, "ci_low": h["ci_low"], "ci_high": h["ci_high"]})
    svg = F.dot_ci(rows, "Quote-valid answers with the wrong label",
                   "Eligible test prompts, Evidence Inference 2.0. Dots: share wrong. Lines: 95% article-clustered bootstrap interval.",
                   "Dot and interval chart. For each system and context, the share of answers whose quote exists in the "
                   "supplied source but whose label disagrees with the benchmark label.",
                   "share of quote-valid answers with the wrong label")
    return svg, pd.DataFrame(tab)


CATS = [("qv_ok", "quote valid, label right", "--s1"), ("qv_wrong", "quote valid, label wrong", "--s2"),
        ("nq_ok", "no valid quote, label right", "--light1"), ("nq_wrong", "no valid quote, label wrong", "--light2"),
        ("abst", "abstained", "--neutral"), ("inv", "invalid output", "--base")]


def fig_decomposition(res: dict) -> tuple[str, pd.DataFrame]:
    rows, tab = [], []
    for m, c in LLM_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"] or not m.startswith("qwen"):
            continue
        p = C.RESULTS / "scored" / f"primary__{m}__{c}.csv"
        df = pd.read_csv(p)
        valid = df.parse_status.eq("valid")
        ans = df.answered.astype(bool)
        qv = ans & df.quote_exists.astype(bool)
        ok = df.label_correct.fillna(False).astype(bool)
        counts = {"qv_ok": int((qv & ok).sum()), "qv_wrong": int((qv & ~ok).sum()),
                  "nq_ok": int((ans & ~qv & ok).sum()), "nq_wrong": int((ans & ~qv & ~ok).sum()),
                  "abst": int(df.abstained.astype(bool).sum()), "inv": int((~valid).sum())}
        rows.append({"label": F.LABEL[m], "group": c, "counts": counts, "total": len(df)})
        tab.append({"condition": c, "system": F.LABEL[m], "items": len(df), **counts})
    svg = F.stacked(rows, CATS, "Where each answer ends up",
                    "Every eligible test prompt, including abstentions and invalid outputs, by quote validity and label.",
                    "Stacked bars. For each model and context, the share of eligible prompts in six outcome groups.")
    return svg, pd.DataFrame(tab)


def fig_rejection(res: dict) -> tuple[str, pd.DataFrame]:
    rows, tab = [], []
    for m, c in LLM_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"] or not m.startswith("qwen"):
            continue
        r = res["systems"][k]["rejection"]
        rows.append({"label": f"{F.LABEL[m]}, {c}", "model": m, "unf": r["unfiltered"]["retained_error"],
                     "flt": r["quote_filter"]["retained_error"], "rlo": r["random_same_coverage"]["p2_5"],
                     "rhi": r["random_same_coverage"]["p97_5"], "rmean": r["random_same_coverage"]["mean_error"],
                     "cov_unf": r["unfiltered"]["coverage"], "cov_flt": r["quote_filter"]["coverage"]})
        tab.append({"system": F.LABEL[m], "condition": c, "error_all_answers": r["unfiltered"]["retained_error"],
                    "coverage_all_answers": r["unfiltered"]["coverage"], "error_quote_valid_only": r["quote_filter"]["retained_error"],
                    "coverage_quote_valid_only": r["quote_filter"]["coverage"],
                    "random_mean_error": r["random_same_coverage"]["mean_error"],
                    "random_2_5": r["random_same_coverage"]["p2_5"], "random_97_5": r["random_same_coverage"]["p97_5"],
                    "difference_filter_minus_all": r["filter_minus_unfiltered_error"]["diff"],
                    "difference_ci_low": r["filter_minus_unfiltered_error"]["ci_low"],
                    "difference_ci_high": r["filter_minus_unfiltered_error"]["ci_high"]})
    svg = F.rejection_chart(rows, "Error before and after the quote-validity rule",
                            "Error among retained answers with all answers and with quote and locator valid only, against random rejection.",
                            "Dumbbell chart. For each model and context: error among all answers, error among quote-valid "
                            "answers, and the range of errors from random rejection keeping the same number of answers.")
    return svg, pd.DataFrame(tab)


def fig_risk(res: dict) -> tuple[str, pd.DataFrame] | None:
    rc = res.get("risk_coverage")
    if not rc:
        return None
    r = res["systems"]["qwen3-1.7b::retrieved"]["rejection"]
    filt = (r["quote_filter"]["coverage"], r["quote_filter"]["retained_error"])
    svg = F.risk_curve(rc["curve"], rc["overall_error"], filt, "Risk and coverage for Qwen3-1.7B, retrieved passages",
                       "Answers ordered by a scoring rule fitted on development predictions only; test answers shown.",
                       "Line chart of error among kept answers against coverage, with the random-order reference and the "
                       "quote-validity rule's single operating point.")
    return svg, pd.DataFrame(rc["curve"])


DEFINITIONS = [
    ("items", "count", "Eligible test prompts in the analysis population (unanimous accepted benchmark label, not on the corpus 'Incorrect' list)."),
    ("parse_valid", "count", "Responses that parse as one JSON object matching the answer schema (code fences stripped; no other repair)."),
    ("abstained", "count", "Parse-valid responses with label 'cannot determine'. Not the same as 'no significant difference'."),
    ("answered", "count", "Parse-valid responses that did not abstain."),
    ("quote_exists", "count", "Answered prompts whose quote, after collapsing whitespace, is a substring of one supplied passage and has at least 4 words."),
    ("quote_exists_strict", "count", "Answered prompts whose quote is an exact substring of the passages as displayed to the model, any length (sensitivity S1 adds the 4-word minimum)."),
    ("locator_valid", "count", "Answered prompts whose returned passage ID names a supplied passage containing the quote."),
    ("gold_overlap", "count", "Answered prompts whose located quote overlaps an accepted benchmark evidence span by at least one character."),
    ("label_correct", "count", "Answered prompts whose label equals the benchmark label."),
    ("task_success", "count", "Answered, quote exists, locator valid, and label correct. Denominator: all items."),
    ("qvwr", "proportion", "Label-error rate among quote-valid answers: label_wrong / answered prompts with an existing quote."),
    ("ci_low, ci_high", "proportion", "95% percentile interval from 10,000 bootstrap resamples of articles (seed 20261007)."),
    ("coverage", "proportion", "Retained answers / items."),
    ("macro_f1", "proportion", "Mean F1 over the three benchmark classes; abstentions and invalid outputs count as a wrong 'no answer'."),
    ("retained_error", "proportion", "Wrong labels / retained answers under a rejection policy."),
    ("random_*", "proportion", "Coverage-matched random rejection: 2,000 seeded draws keeping the same number of answered prompts."),
]


def write_workbook(res: dict, tables: dict[str, pd.DataFrame]) -> Path:
    path = C.RESULTS / "evidence_model_audit_results.xlsx"
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        d = pd.DataFrame(DEFINITIONS, columns=["field", "unit", "definition"])
        notes = pd.DataFrame({"field": ["grain", "scope", "source", "not included"], "unit": ["", "", "", ""],
                              "definition": ["One row per system (model or baseline) and context condition, unless a sheet says otherwise.",
                                             "Evidence Inference 2.0 test split; 'model sample' = articles completed by the primary model; 'full official test split' rows are labelled.",
                                             "results/analysis/results.json; tables in results/tables/.",
                                             "No item-level article text or quotes; aggregates only."]})
        pd.concat([notes, d]).to_excel(xw, sheet_name="definitions", index=False)
        for name, df in tables.items():
            df.to_excel(xw, sheet_name=name[:31], index=False)
    return path


TABLEAU_SPEC = """# Tableau import and interaction specification

A Tableau workbook was not built or tested. These files are prepared for import.

File: `tableau-system-metrics.csv` in the site downloads (`results/tables/tableau_system_metrics.csv` in the source archive); one row per system x condition x scope x metric.

* Grain: one precomputed estimate. Columns: system, condition, scope, metric, numerator, denominator, estimate, ci_low, ci_high, unit, suppressed.
* Units: estimate, ci_low, ci_high are proportions from 0 to 1; numerator and denominator are counts of prompts.
* Confidence bounds: 95% percentile intervals from 10,000 article-level bootstrap resamples. They cannot be recombined.
* Suppression: `suppressed` is true when the denominator is 0 (estimate undefined). No small-cell suppression is needed because no person-level data are involved.
* Permitted filtering: filter rows by system, condition, scope, or metric only. Do not aggregate, sum, or average estimates across rows, and do not recompute a rate from filtered numerators and denominators across systems or conditions: rows come from different, overlapping prompt sets, and intervals are cluster-bootstrap results.
* Suggested views: (1) dot-and-interval of metric = qvwr by system, coloured by system and faceted by condition; (2) bars of metric = task_success with interval whiskers; (3) a filter on scope.
"""


def tableau_export(res: dict) -> pd.DataFrame:
    rows = []
    mets = {"qvwr": "headline_qvwr", "task_success": "task_success", "parse_validity": "parse_validity",
            "coverage": "coverage", "quote_exists_among_answered": "quote_exists_among_answered",
            "locator_valid_among_answered": "locator_valid_among_answered",
            "gold_overlap_among_answered": "gold_overlap_among_answered", "accuracy_among_answered": "accuracy_among_answered",
            "abstention": "abstention"}
    for key, e in res["systems"].items():
        parts = key.split("::")
        for name, k in mets.items():
            v = e["metrics"][k]
            rows.append({"system": parts[0], "condition": parts[1],
                         "scope": "full official test split" if len(parts) > 2 else "model sample", "metric": name,
                         "numerator": v["numerator"], "denominator": v["denominator"], "estimate": v["estimate"],
                         "ci_low": v["ci_low"], "ci_high": v["ci_high"], "unit": "proportion",
                         "suppressed": v["denominator"] == 0})
    return pd.DataFrame(rows)


def data_dictionary() -> str:
    from .evaluate import score_frame  # noqa: F401  (documentation only)

    rows = [
        ("data/processed/articles.csv", "pmcid", "PubMed Central article number (identifier used by the corpus)"),
        ("data/processed/articles.csv", "split", "official split: train, validation, test, or unassigned"),
        ("data/processed/articles.csv", "abstract_status / abstract_end", "whether a title-plus-abstract region was delimited, and its end offset"),
        ("data/processed/articles.csv", "abst_file_contains_body", "the repository's .abst file contains BODY sections"),
        ("data/processed/prompts.csv", "prompt_id", "corpus PromptID (stable key)"),
        ("data/processed/prompts.csv", "intervention, comparator, outcome", "prompt fields as distributed"),
        ("data/processed/prompts.csv", "label_status", "unanimous, accepted_disagreement, no_accepted_annotation, no_annotation"),
        ("data/processed/prompts.csv", "gold_label", "benchmark label when label_status is unanimous; empty otherwise"),
        ("data/processed/prompts.csv", "accepted_labels", "JSON list of distinct accepted labels"),
        ("data/processed/prompts.csv", "gold_spans", "JSON list of located accepted evidence spans [start, end) in article text offsets"),
        ("data/processed/prompts.csv", "flag", "corpus authors' list: incorrect, questionable, malformed, or empty"),
        ("data/processed/prompts.csv", "eligible_primary", "meets the primary eligibility rule"),
        ("data/processed/annotations.csv", "accepted", "Valid Label = 1, Valid Reasoning = 1, non-empty evidence, label not 'invalid prompt'"),
        ("data/processed/annotations.csv", "span_start, span_end, span_status", "located evidence span and how it was located"),
        ("results/contexts/*.jsonl", "passages", "supplied passages: pid, start, end (article offsets), text, section, BM25 score"),
        ("results/contexts/*.jsonl", "budget_tokens, context_tokens, truncated", "token budget, tokens used (Qwen3 tokenizer), whether truncated"),
        ("results/predictions/**.jsonl", "response, finish_reason, prompt_tokens, gen_tokens, latency_s", "raw model output and call metadata"),
        ("results/predictions/**.jsonl", "cache_key, rendered_sha256, revision, gen_config, env", "provenance of each call"),
        ("results/scored/**.csv", "parse_status", "valid, schema_error, invalid_json, no_json_object, empty, runtime_error, not_run"),
        ("results/scored/**.csv", "quote_exists, quote_exists_strict, locator_valid, gold_overlap, gold_token_f1", "separated validity checks (see definitions)"),
        ("results/scored/**.csv", "label_pred, label_correct, task_success", "predicted label and correctness"),
    ]
    out = ["# Data dictionary", "", "Source-to-analysis fields. Offsets are character offsets into the pinned repository's "
           "plain-text article rendering, half-open [start, end).", "", "| File | Field | Meaning |", "|---|---|---|"]
    out += [f"| `{a}` | `{b}` | {c} |" for a, b, c in rows]
    out += ["", "## Metric definitions", "", "| Field | Unit | Definition |", "|---|---|---|"]
    out += [f"| `{a}` | {b} | {c} |" for a, b, c in DEFINITIONS]
    return "\n".join(out) + "\n"


def main(log=print) -> dict:
    res = _res()
    OUT.mkdir(parents=True, exist_ok=True)
    tables = {}
    made = {}
    for name, fn in (("fig1_quote_valid_wrong", fig_headline), ("fig2_answer_outcomes", fig_decomposition),
                     ("fig3_rejection_rule", fig_rejection), ("fig4_risk_coverage", fig_risk)):
        r = fn(res)
        if r is None:
            continue
        svg, tab = r
        (OUT / f"{name}.svg").write_text(svg, encoding="utf-8")
        tab.to_csv(OUT / f"{name}_data.csv", index=False)
        made[name] = str((OUT / f"{name}.svg").relative_to(C.ROOT))
        log(f"figure {name}")
    for t in ("system_metrics", "rejection_rule", "per_class", "paired_comparisons", "sensitivity", "evidence_recall",
              "parse_status"):
        p = C.RESULTS / "tables" / f"{t}.csv"
        if p.exists():
            tables[t] = pd.read_csv(p)
    tab = tableau_export(res)
    tab.to_csv(C.RESULTS / "tables" / "tableau_system_metrics.csv", index=False)
    (C.DOCS / "tableau_spec.md").write_text(TABLEAU_SPEC)
    tables["tableau_long"] = tab
    if (C.RESULTS / "analysis" / "error_taxonomy_items.csv").exists():
        tx = pd.read_csv(C.RESULTS / "analysis" / "error_taxonomy_items.csv")
        tables["error_taxonomy_counts"] = tx.groupby(["system", "error_type", "evidence_relation"]).size().reset_index(name="count")
    wb = write_workbook(res, tables)
    (C.DOCS / "data_dictionary.md").write_text(data_dictionary())
    log(f"workbook {wb}")
    from . import examples_build, manuscript
    examples_build.main(log=log)
    manuscript.main(log=log)
    return made
