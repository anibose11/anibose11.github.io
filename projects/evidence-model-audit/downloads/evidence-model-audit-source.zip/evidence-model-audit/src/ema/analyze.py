"""Analysis stage: headline estimand, separated metrics, rejection analysis, comparisons, sensitivity.

All intervals resample articles (clusters) with replacement. Ratio statistics
are computed from per-article numerators and denominators so that a bootstrap
replicate is a weighted sum.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C
from .evaluate import NO_ANSWER, load_predictions, macro_f1, primary_mask, score_frame, summarize
from .run import predictions_path, test_items_frame, dev_items_frame

SEED = 20261007
REPS = 10000
DRAWS = 2000

SIG_RE = re.compile(r"\b(?:p\s*[<=>≤≥]|p-value|signific|95%\s*ci|confidence interval)", re.I)
NS_RE = re.compile(r"\b(?:not\s+(?:statistically\s+)?significant|no\s+(?:statistically\s+)?significant|non-?significant|"
                   r"did\s+not\s+differ|no\s+(?:significant\s+)?difference|similar|comparable|n\.?s\.?\b)", re.I)


# ---------------------------------------------------------------- bootstrap helpers
def article_weights(n_articles: int, reps: int = REPS, seed: int = SEED) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.multinomial(n_articles, np.full(n_articles, 1.0 / n_articles), size=reps).astype(np.float64)


def ratio_ci(df: pd.DataFrame, num: pd.Series, den: pd.Series, reps: int = REPS, seed: int = SEED) -> dict:
    """Point estimate and percentile CI for sum(num)/sum(den), clustering on df.pmcid."""
    g = pd.DataFrame({"pmcid": df.pmcid.values, "num": num.astype(float).values, "den": den.astype(float).values})
    agg = g.groupby("pmcid")[["num", "den"]].sum()
    N, D = agg.num.sum(), agg.den.sum()
    if D == 0:
        return {"estimate": None, "numerator": int(N), "denominator": 0, "ci_low": None, "ci_high": None,
                "articles": int(len(agg)), "note": "undefined: zero denominator"}
    W = article_weights(len(agg), reps, seed)
    nums, dens = W @ agg.num.values, W @ agg.den.values
    ok = dens > 0
    vals = nums[ok] / dens[ok]
    return {"estimate": N / D, "numerator": int(N), "denominator": int(D), "ci_low": float(np.percentile(vals, 2.5)),
            "ci_high": float(np.percentile(vals, 97.5)), "articles": int(len(agg)), "reps_defined": int(ok.sum())}


def paired_diff_ci(a: pd.DataFrame, b: pd.DataFrame, num_col: str, den_col: str | None = None,
                   reps: int = REPS, seed: int = SEED) -> dict:
    """Difference in ratio (a minus b) on the same prompts, article-clustered paired bootstrap.
    a and b are aligned on prompt_id; den_col None means a mean over items."""
    m = a.merge(b, on=["prompt_id", "pmcid"], suffixes=("_a", "_b"))
    if den_col is None:
        m["den_a"] = 1.0
        m["den_b"] = 1.0
    else:
        m["den_a"] = m[f"{den_col}_a"].astype(float)
        m["den_b"] = m[f"{den_col}_b"].astype(float)
    m["num_a"] = m[f"{num_col}_a"].astype(float)
    m["num_b"] = m[f"{num_col}_b"].astype(float)
    agg = m.groupby("pmcid")[["num_a", "den_a", "num_b", "den_b"]].sum()
    if agg.den_a.sum() == 0 or agg.den_b.sum() == 0:
        return {"diff": None, "n_prompts": int(len(m))}
    W = article_weights(len(agg), reps, seed)
    ra = (W @ agg.num_a.values) / np.maximum(W @ agg.den_a.values, 1e-12)
    rb = (W @ agg.num_b.values) / np.maximum(W @ agg.den_b.values, 1e-12)
    d = ra - rb
    est = agg.num_a.sum() / agg.den_a.sum() - agg.num_b.sum() / agg.den_b.sum()
    return {"a": agg.num_a.sum() / agg.den_a.sum(), "b": agg.num_b.sum() / agg.den_b.sum(), "diff": float(est),
            "ci_low": float(np.percentile(d, 2.5)), "ci_high": float(np.percentile(d, 97.5)),
            "n_prompts": int(len(m)), "articles": int(len(agg))}


# ---------------------------------------------------------------- loading
@dataclass
class System:
    model: str
    condition: str
    variant: str
    decoding: str
    split: str = "test"

    @property
    def key(self) -> str:
        return f"{self.model}::{self.condition}"


def scored(system: System, frame: pd.DataFrame, completed: set[int] | None = None) -> pd.DataFrame:
    path = C.RESULTS / "scored" / system.split / f"{system.model}__{system.condition}__{system.variant}__{system.decoding}.csv"
    df = score_frame(frame, system.split, system.model, system.condition, system.variant, system.decoding,
                     completed_pmcids=completed)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return df


def completed_articles(run_glob: str) -> set[int] | None:
    files = sorted((C.RESULTS / "runs").glob(run_glob))
    if not files:
        return None
    s: set[int] = set()
    for f in files:
        s |= set(json.loads(f.read_text())["completed_pmcids"])
    return s


# ---------------------------------------------------------------- headline and metrics
def headline(df: pd.DataFrame, quote_col: str = "quote_exists", correct_col: str = "label_correct") -> dict:
    pop = df[df.answered & df[quote_col].astype(bool) & df[correct_col].notna()]
    wrong = ~pop[correct_col].astype(bool)
    res = ratio_ci(pop, wrong, pd.Series(np.ones(len(pop))))
    res["per_gold_class"] = {lab: {"numerator": int(wrong[pop.gold_label == lab].sum()),
                                   "denominator": int((pop.gold_label == lab).sum())} for lab in C.LABELS}
    res["per_pred_class"] = {lab: {"numerator": int(wrong[pop.label_pred == lab].sum()),
                                   "denominator": int((pop.label_pred == lab).sum())} for lab in C.LABELS}
    res["confusion"] = pd.crosstab(pop.gold_label, pop.label_pred).to_dict()
    return res


def separated_metrics(df: pd.DataFrame) -> dict:
    s = summarize(df)
    n = len(df)
    ones = pd.Series(np.ones(n), index=df.index)
    ans = df.answered.astype(float)
    out = {"summary": s,
           "parse_validity": ratio_ci(df, df.parse_status.eq("valid"), ones),
           "abstention": ratio_ci(df, df.abstained.astype(float), ones),
           "coverage": ratio_ci(df, ans, ones),
           "quote_exists_among_answered": ratio_ci(df, df.answered & df.quote_exists, ans),
           "quote_exists_strict_among_answered": ratio_ci(df, df.answered & df.quote_exists_strict, ans),
           "locator_valid_among_answered": ratio_ci(df, df.answered & df.locator_valid, ans),
           "gold_overlap_among_answered": ratio_ci(df, df.answered & df.gold_overlap.fillna(False).astype(bool),
                                                   df.answered & df.gold_overlap.notna()),
           "accuracy_among_answered": ratio_ci(df, df.answered & df.label_correct.fillna(False).astype(bool), ans),
           "task_success": ratio_ci(df, df.task_success.astype(float), ones),
           "headline_qvwr": headline(df)}
    return out


# ---------------------------------------------------------------- rejection analysis
def rejection(df: pd.DataFrame, draws: int = DRAWS, seed: int = SEED) -> dict:
    n = len(df)
    ans = df[df.answered & df.label_correct.notna()]
    kept = ans[ans.quote_exists & ans.locator_valid]
    err_unf = float((~ans.label_correct.astype(bool)).mean()) if len(ans) else None
    err_flt = float((~kept.label_correct.astype(bool)).mean()) if len(kept) else None
    rng = np.random.default_rng(seed)
    wrong = (~ans.label_correct.astype(bool)).values.astype(float)
    k = len(kept)
    rand = np.array([wrong[rng.choice(len(ans), size=k, replace=False)].mean() for _ in range(draws)]) if 0 < k <= len(ans) else np.array([])
    # paired bootstrap of (filtered error - unfiltered error) by article
    g = ans.assign(wrong=~ans.label_correct.astype(bool), keep=ans.quote_exists & ans.locator_valid)
    agg = g.groupby("pmcid").apply(lambda x: pd.Series({"w_all": x.wrong.sum(), "n_all": len(x),
                                                        "w_keep": (x.wrong & x.keep).sum(), "n_keep": x.keep.sum()}),
                                   include_groups=False)
    W = article_weights(len(agg), REPS, seed)
    e_all = (W @ agg.w_all.values) / np.maximum(W @ agg.n_all.values, 1e-12)
    e_keep = (W @ agg.w_keep.values) / np.maximum(W @ agg.n_keep.values, 1e-12)
    d = e_keep - e_all
    return {
        "items": n, "answered": int(len(ans)), "kept_by_filter": int(k),
        "unfiltered": {"retained_error": err_unf, "coverage": len(ans) / n if n else None,
                       "wrong": int((~ans.label_correct.astype(bool)).sum())},
        "quote_filter": {"retained_error": err_flt, "coverage": k / n if n else None,
                         "wrong": int((~kept.label_correct.astype(bool)).sum()),
                         "lost_coverage": (len(ans) - k) / n if n else None,
                         "rejected_answers": int(len(ans) - k),
                         "rejected_correct": int(ans[~(ans.quote_exists & ans.locator_valid)].label_correct.astype(bool).sum())},
        "random_same_coverage": {"draws": int(len(rand)), "mean_error": float(rand.mean()) if len(rand) else None,
                                 "p2_5": float(np.percentile(rand, 2.5)) if len(rand) else None,
                                 "p97_5": float(np.percentile(rand, 97.5)) if len(rand) else None,
                                 "share_draws_error_le_filter": float((rand <= err_flt + 1e-12).mean()) if len(rand) else None},
        "filter_minus_unfiltered_error": {"diff": (err_flt - err_unf) if (err_flt is not None and err_unf is not None) else None,
                                          "ci_low": float(np.nanpercentile(d, 2.5)), "ci_high": float(np.nanpercentile(d, 97.5))},
    }


# ---------------------------------------------------------------- risk-coverage
def answer_features(df: pd.DataFrame) -> pd.DataFrame:
    q = df.quote.fillna("")
    sig = q.str.contains(SIG_RE)
    ns = q.str.contains(NS_RE)
    pred_ns = df.label_pred.eq("no significant difference")
    consistent = (pred_ns & ns) | (~pred_ns & sig & ~ns)
    def overlap(row):
        a = set(re.findall(r"\w+", str(row.quote).lower()))
        b = set(re.findall(r"\w+", str(row.outcome).lower())) - {"the", "of", "and", "in", "to", "a"}
        return len(a & b) / len(b) if b else 0.0
    return pd.DataFrame({
        "quote_exists": df.quote_exists.astype(float), "locator_valid": df.locator_valid.astype(float),
        "log_words": np.log1p(df.quote_words.astype(float)), "sig_wording": sig.astype(float),
        "label_wording_consistent": consistent.astype(float),
        "outcome_overlap": df.apply(overlap, axis=1).astype(float)}, index=df.index)


def fit_score_rule(dev: pd.DataFrame):
    from sklearn.linear_model import LogisticRegression

    d = dev[dev.answered & dev.label_correct.notna()]
    X, y = answer_features(d), d.label_correct.astype(int)
    m = LogisticRegression(C=1.0, max_iter=2000).fit(X, y)
    return m, list(X.columns), {c: float(w) for c, w in zip(X.columns, m.coef_[0])}, float(m.intercept_[0])


def risk_coverage(df: pd.DataFrame, model) -> dict:
    n = len(df)
    d = df[df.answered & df.label_correct.notna()].copy()
    d["score"] = model.predict_proba(answer_features(d))[:, 1]
    d = d.sort_values("score", ascending=False)
    wrong = (~d.label_correct.astype(bool)).values.astype(float)
    cum = np.cumsum(wrong)
    k = np.arange(1, len(d) + 1)
    cov = k / n
    risk = cum / k
    aurc = float(np.trapezoid(risk, cov)) if len(d) > 1 else None
    base = float(wrong.mean()) if len(d) else None
    pts = [{"coverage": float(cov[i]), "risk": float(risk[i])} for i in np.linspace(0, len(d) - 1, min(60, len(d))).astype(int)]
    return {"aurc": aurc, "aurc_random_expected": (base * (cov[-1] - cov[0])) if len(d) > 1 else None,
            "max_coverage": float(cov[-1]) if len(d) else None, "overall_error": base, "curve": pts}


# ---------------------------------------------------------------- error taxonomy
def taxonomy(df: pd.DataFrame) -> pd.DataFrame:
    w = df[df.answered & df.quote_exists & df.label_correct.notna() & ~df.label_correct.astype(bool)].copy()
    def kind(r):
        g, p = r.gold_label, r.label_pred
        if "no significant" in g or "no significant" in p:
            return "significance error" + (" (model said significant)" if "no significant" in g else " (model said not significant)")
        return "direction reversal"
    w["error_type"] = w.apply(kind, axis=1) if len(w) else []
    w["evidence_relation"] = np.where(w.gold_overlap.fillna(False).astype(bool), "quote overlaps benchmark evidence",
                                      np.where(w.gold_overlap.isna(), "benchmark evidence not located",
                                               "quote outside benchmark evidence"))
    return w


# ---------------------------------------------------------------- sensitivity analyses
def sensitivity(df_all: pd.DataFrame) -> dict:
    prim = df_all[primary_mask(df_all)]
    out = {}
    out["S0_primary"] = headline(prim)
    s1 = prim.copy()
    # S1 swaps whitespace-normalized matching for exact matching and keeps the 4-word minimum of definition Q
    s1["quote_exists_strict_min"] = s1.quote_exists_strict.astype(bool) & ~s1.quote_too_short.astype(bool) & \
        s1.quote_words.ge(4)
    out["S1_strict_quote"] = headline(s1, quote_col="quote_exists_strict_min")
    inc = df_all[primary_mask(df_all, include_disagreement=True)].copy()
    inc["any_ok"] = inc.label_matches_any_accepted
    out["S2_include_disagreement_any_label"] = headline(inc, correct_col="any_ok")
    out["S3_exclude_flagged"] = headline(df_all[primary_mask(df_all, exclude_flagged=True)])
    s4 = prim.copy()
    s4["quote_exists_any_len"] = s4.answered & s4.quote_start.notna()
    out["S4_min_quote_1_word"] = headline(s4, quote_col="quote_exists_any_len")
    if (prim.condition == "retrieved").all():
        out["S5_retrieval_supplied_evidence"] = headline(prim[prim.ctx_gold_any.fillna(False).astype(bool)])
    for k, v in out.items():
        v.pop("confusion", None)
    return out
