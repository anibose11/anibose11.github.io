"""Analysis orchestration: score every system, compute all planned quantities, write tables and results.json."""
from __future__ import annotations

import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from . import config as C
from .analyze import (System, completed_articles, fit_score_rule, paired_diff_ci, ratio_ci, rejection, risk_coverage,
                      scored, sensitivity, separated_metrics, taxonomy)
from .contexts import evidence_recall
from .data import load_processed
from .evaluate import primary_mask, score_frame
from .run import build_contexts, dev_items_frame, test_items_frame

LLM_RUNS = [("qwen3-1.7b", ("retrieved", "abstract", "oracle")), ("qwen3-0.6b", ("retrieved", "abstract", "oracle")),
            ("qwen3-4b-instruct-2507", ("retrieved",))]
BASELINES = ("tfidf-lr", "majority")
TABLES = C.RESULTS / "tables"


def _frozen() -> dict:
    return json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())


def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if np.isnan(o) else float(o)
    if isinstance(o, float) and np.isnan(o):
        return None
    return o


def add_unconditional_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["correct_all"] = (df.answered & df.label_correct.fillna(False).astype(bool)).astype(float)
    df["quote_valid_all"] = (df.answered & df.quote_exists & df.locator_valid).astype(float)
    df["task_success_f"] = df.task_success.astype(float)
    return df


def analyze(log=print) -> dict:
    fz = _frozen()
    variant, decoding = fz["variant"], fz["decoding"]
    frame = test_items_frame()
    res: dict = {"generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "frozen_config": fz,
                 "systems": {}, "comparisons": {}, "runs": {}}
    scored_all: dict[str, pd.DataFrame] = {}

    # ---- language models
    for model, conds in LLM_RUNS:
        runf = C.RESULTS / "runs" / f"test-main__{model}.json"
        if not runf.exists():
            log(f"no run record for {model}; skipped")
            continue
        run = json.loads(runf.read_text())
        res["runs"][model] = {k: v for k, v in run.items() if k != "completed_pmcids"}
        done = set(run["completed_pmcids"])
        for cond in conds:
            sysm = System(model, cond, variant, decoding)
            df = add_unconditional_cols(scored(sysm, frame, done))
            scored_all[sysm.key] = df
            log(f"scored {sysm.key}: {len(df)} items")

    # ---- baselines on the model sample (articles completed by the primary model) and the full split
    primary_done = set(json.loads((C.RESULTS / "runs" / "test-main__qwen3-1.7b.json").read_text())["completed_pmcids"]) \
        if (C.RESULTS / "runs" / "test-main__qwen3-1.7b.json").exists() else None
    for b in BASELINES:
        for cond in ("retrieved", "abstract", "oracle"):
            full = add_unconditional_cols(scored(System(b, cond, "baseline", "deterministic"), frame, None))
            scored_all[f"{b}::{cond}::full_split"] = full
            if primary_done is not None:
                scored_all[f"{b}::{cond}"] = full[full.pmcid.isin(primary_done)].copy()

    # ---- per-system metrics
    for key, df in scored_all.items():
        prim = df[primary_mask(df)]
        entry = {"items_all": int(len(df)), "items_primary": int(len(prim)), "articles": int(prim.pmcid.nunique()),
                 "metrics": separated_metrics(prim), "rejection": rejection(prim)}
        if not key.endswith("full_split"):
            entry["sensitivity"] = sensitivity(df)
        res["systems"][key] = entry
        prim.to_csv(C.RESULTS / "scored" / f"primary__{key.replace('::', '__')}.csv", index=False)

    # ---- taxonomy for every language-model system
    tax_rows = []
    for key, df in scored_all.items():
        if key.split("::")[0].startswith("qwen"):
            t = taxonomy(df[primary_mask(df)])
            if len(t):
                t = t.assign(system=key)
                tax_rows.append(t)
    tax = pd.concat(tax_rows) if tax_rows else pd.DataFrame()
    if len(tax):
        res["taxonomy"] = {k: g.groupby(["error_type", "evidence_relation"]).size().to_dict()
                           for k, g in tax.groupby("system")}
        res["taxonomy"] = {k: {" / ".join(kk): int(vv) for kk, vv in v.items()} for k, v in res["taxonomy"].items()}

    # ---- paired comparisons (unconditional metrics only)
    def pair(a, b, label, restrict=None):
        if a not in scored_all or b not in scored_all:
            return
        da = scored_all[a][primary_mask(scored_all[a])]
        db = scored_all[b][primary_mask(scored_all[b])]
        if restrict is not None:
            da, db = da[da.prompt_id.isin(restrict)], db[db.prompt_id.isin(restrict)]
        common = set(da.prompt_id) & set(db.prompt_id)
        da, db = da[da.prompt_id.isin(common)], db[db.prompt_id.isin(common)]
        res["comparisons"][label] = {m: paired_diff_ci(da, db, m) for m in ("task_success_f", "correct_all",
                                                                             "quote_valid_all")}
        res["comparisons"][label]["systems"] = [a, b]

    for cond in ("retrieved", "abstract", "oracle"):
        pair(f"qwen3-1.7b::{cond}", f"qwen3-0.6b::{cond}", f"1.7b_vs_0.6b::{cond}")
        pair(f"qwen3-1.7b::{cond}", f"tfidf-lr::{cond}", f"1.7b_vs_tfidf::{cond}")
    pair("qwen3-4b-instruct-2507::retrieved", "qwen3-1.7b::retrieved", "4b_vs_1.7b::retrieved")
    for m in ("qwen3-1.7b", "qwen3-0.6b"):
        pair(f"{m}::abstract", f"{m}::retrieved", f"{m}::abstract_vs_retrieved")
        pair(f"{m}::oracle", f"{m}::retrieved", f"{m}::oracle_vs_retrieved")

    # ---- retrieval and abstract evidence recall at the actual budget (test, primary prompts with located spans)
    _, prompts = load_processed()
    pm = frame[frame.label_status.eq("unanimous") & frame.n_gold_spans.gt(0)]
    if primary_done is not None:
        pm = pm[pm.pmcid.isin(primary_done)]
    recall = {}
    for cond in ("retrieved", "abstract"):
        ctxs = build_contexts(frame, cond, "test")
        recs = []
        for r in pm.itertuples():
            ctx = ctxs[int(r.prompt_id)]
            if not ctx.available:
                continue
            ev = evidence_recall(ctx, [tuple(s) for s in json.loads(r.gold_spans)])
            recs.append({"pmcid": r.pmcid, "any": float(ev["any_overlap"]), "full": float(ev["full_cover"]),
                         "tokens": ctx.context_tokens, "trunc": float(ctx.truncated)})
        d = pd.DataFrame(recs)
        one = pd.Series(np.ones(len(d)))
        recall[cond] = {"prompts": int(len(d)), "any_overlap": ratio_ci(d, d["any"], one),
                        "full_cover": ratio_ci(d, d["full"], one), "median_context_tokens": float(d.tokens.median()),
                        "truncated_share": float(d.trunc.mean())}
    res["evidence_recall_at_budget"] = recall

    # ---- risk-coverage with the development-fitted rule
    dev = dev_items_frame()
    ddf = score_frame(dev, "dev", "qwen3-1.7b", "retrieved", variant, decoding)
    if len(ddf) and "qwen3-1.7b::retrieved" in scored_all:
        rule, feats, coefs, icpt = fit_score_rule(ddf[primary_mask(ddf)])
        t = scored_all["qwen3-1.7b::retrieved"]
        rc = risk_coverage(t[primary_mask(t)], rule)
        res["risk_coverage"] = {"fitted_on": "development predictions, qwen3-1.7b retrieved", "features": feats,
                                "coefficients": coefs, "intercept": icpt, "dev_items": int(len(ddf)), **rc}

    # ---- development decisions and baseline training record
    for name in ("dev_decisions.json",):
        p = C.RESULTS / "dev" / name
        if p.exists():
            res["development"] = json.loads(p.read_text())
    bs = C.RESULTS / "baselines_summary.json"
    if bs.exists():
        res["baselines_training"] = json.loads(bs.read_text())

    out = C.RESULTS / "analysis" / "results.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(_jsonable(res), indent=2, default=str))
    if len(tax):
        tax.to_csv(C.RESULTS / "analysis" / "error_taxonomy_items.csv", index=False)
    write_tables(res)
    log(f"wrote {out}")
    return res


def _fmt_ci(d: dict) -> str:
    if not d or d.get("estimate") is None:
        return "undefined"
    return f"{d['estimate']:.3f} ({d['ci_low']:.3f} to {d['ci_high']:.3f})"


def write_tables(res: dict) -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    rows = []
    for key, e in res["systems"].items():
        m, s = e["metrics"], e["metrics"]["summary"]
        h = m["headline_qvwr"]
        parts = key.split("::")
        rows.append({
            "system": parts[0], "condition": parts[1], "scope": "full official test split" if len(parts) > 2 else "model sample",
            "items": e["items_primary"], "articles": e["articles"],
            "parse_valid": s["parse_valid"], "abstained": s["abstained"], "answered": s["answered"],
            "quote_exists": s["quote_exists"], "quote_exists_strict": s["quote_exists_strict"],
            "locator_valid": s["locator_valid"], "gold_overlap": s["gold_overlap"],
            "label_correct": s["label_correct"], "task_success": s["task_success"],
            "qvwr_numerator": h["numerator"], "qvwr_denominator": h["denominator"], "qvwr": h["estimate"],
            "qvwr_ci_low": h["ci_low"], "qvwr_ci_high": h["ci_high"],
            "accuracy_answered": s["accuracy_answered"], "task_success_rate": s["task_success_rate"],
            "task_success_ci_low": m["task_success"]["ci_low"], "task_success_ci_high": m["task_success"]["ci_high"],
            "macro_f1": s["macro_f1"], "coverage": s["coverage"], "invalid_output_rate": s["invalid_output_rate"],
            "length_stops": s["length_stops"],
        })
    pd.DataFrame(rows).to_csv(TABLES / "system_metrics.csv", index=False)
    rej = []
    for key, e in res["systems"].items():
        r = e["rejection"]
        rej.append({"system": key, "items": r["items"], "answered": r["answered"], "kept_by_filter": r["kept_by_filter"],
                    "unfiltered_error": r["unfiltered"]["retained_error"], "unfiltered_coverage": r["unfiltered"]["coverage"],
                    "filter_error": r["quote_filter"]["retained_error"], "filter_coverage": r["quote_filter"]["coverage"],
                    "lost_coverage": r["quote_filter"]["lost_coverage"], "rejected_correct": r["quote_filter"]["rejected_correct"],
                    "random_mean_error": r["random_same_coverage"]["mean_error"],
                    "random_p2_5": r["random_same_coverage"]["p2_5"], "random_p97_5": r["random_same_coverage"]["p97_5"],
                    "share_random_le_filter": r["random_same_coverage"]["share_draws_error_le_filter"],
                    "filter_minus_unfiltered": r["filter_minus_unfiltered_error"]["diff"],
                    "diff_ci_low": r["filter_minus_unfiltered_error"]["ci_low"],
                    "diff_ci_high": r["filter_minus_unfiltered_error"]["ci_high"]})
    pd.DataFrame(rej).to_csv(TABLES / "rejection_rule.csv", index=False)
    cls = []
    for key, e in res["systems"].items():
        s = e["metrics"]["summary"]
        h = e["metrics"]["headline_qvwr"]
        for lab in C.LABELS:
            cls.append({"system": key, "class": lab, "precision": s[f"precision::{lab}"], "recall": s[f"recall::{lab}"],
                        "f1": s[f"f1::{lab}"], "support": s[f"support::{lab}"],
                        "qv_wrong_by_gold": h["per_gold_class"][lab]["numerator"],
                        "qv_total_by_gold": h["per_gold_class"][lab]["denominator"],
                        "qv_wrong_by_pred": h["per_pred_class"][lab]["numerator"],
                        "qv_total_by_pred": h["per_pred_class"][lab]["denominator"]})
    pd.DataFrame(cls).to_csv(TABLES / "per_class.csv", index=False)
    comp = []
    for label, c in res["comparisons"].items():
        for metric in ("task_success_f", "correct_all", "quote_valid_all"):
            d = c[metric]
            comp.append({"comparison": label, "system_a": c["systems"][0], "system_b": c["systems"][1], "metric": metric,
                         "a": d.get("a"), "b": d.get("b"), "difference": d.get("diff"), "ci_low": d.get("ci_low"),
                         "ci_high": d.get("ci_high"), "prompts": d.get("n_prompts"), "articles": d.get("articles")})
    pd.DataFrame(comp).to_csv(TABLES / "paired_comparisons.csv", index=False)
    sens = []
    for key, e in res["systems"].items():
        for s_name, h in (e.get("sensitivity") or {}).items():
            sens.append({"system": key, "analysis": s_name, "numerator": h["numerator"], "denominator": h["denominator"],
                         "estimate": h["estimate"], "ci_low": h["ci_low"], "ci_high": h["ci_high"]})
    pd.DataFrame(sens).to_csv(TABLES / "sensitivity.csv", index=False)
    if res.get("evidence_recall_at_budget"):
        er = [{"condition": c, "prompts": v["prompts"], "any_overlap": v["any_overlap"]["estimate"],
               "any_ci_low": v["any_overlap"]["ci_low"], "any_ci_high": v["any_overlap"]["ci_high"],
               "full_cover": v["full_cover"]["estimate"], "full_ci_low": v["full_cover"]["ci_low"],
               "full_ci_high": v["full_cover"]["ci_high"], "median_context_tokens": v["median_context_tokens"],
               "truncated_share": v["truncated_share"]} for c, v in res["evidence_recall_at_budget"].items()]
        pd.DataFrame(er).to_csv(TABLES / "evidence_recall.csv", index=False)
    inv = []
    for key, e in res["systems"].items():
        for st, n in e["metrics"]["summary"]["parse_status_counts"].items():
            inv.append({"system": key, "parse_status": st, "count": n})
    pd.DataFrame(inv).to_csv(TABLES / "parse_status.csv", index=False)
