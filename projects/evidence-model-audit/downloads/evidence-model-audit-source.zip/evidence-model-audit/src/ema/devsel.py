"""Development-only decisions (docs/analysis_plan.md, section 6), applied by fixed rules."""
from __future__ import annotations

import json
from datetime import datetime, timezone

from . import config as C
from .evaluate import score_frame, summarize
from .infer import GenConfig
from .run import dev_items_frame, run_model

SAMPLING = {"temperature": 0.7, "top_p": 0.8, "top_k": 20}  # model card, non-thinking mode


def main(device: str = "mps", log=print) -> dict:
    dev = dev_items_frame()
    model = "qwen3-1.7b"
    log(f"dev sample: {dev.pmcid.nunique()} articles, {len(dev)} prompts")
    greedy = GenConfig(max_new_tokens=256, device=device, dtype="float32")
    res = {"dev_articles": int(dev.pmcid.nunique()), "dev_prompts": int(len(dev))}
    for v in ("v1", "v2"):
        run_model(model, dev, "retrieved", v, "dev", greedy, "greedy", f"dev-{v}-greedy", log=log)
        res[f"{v}_greedy"] = summarize(score_frame(dev, "dev", model, "retrieved", v, "greedy"))
    s1, s2 = res["v1_greedy"]["task_success_rate"], res["v2_greedy"]["task_success_rate"]
    variant = "v2" if (s2 - s1) >= 0.02 else "v1"
    res["variant_rule"] = f"v1 success {s1:.4f}, v2 success {s2:.4f}; v2 kept only if at least 0.02 higher"
    res["variant"] = variant

    sampled = GenConfig(max_new_tokens=256, do_sample=True, device=device, dtype="float32", **SAMPLING)
    run_model(model, dev, "retrieved", variant, "dev", sampled, "sampled", f"dev-{variant}-sampled", log=log)
    res[f"{variant}_sampled"] = summarize(score_frame(dev, "dev", model, "retrieved", variant, "sampled"))
    inv_g = res[f"{variant}_greedy"]["invalid_output_rate"]
    inv_s = res[f"{variant}_sampled"]["invalid_output_rate"]
    decoding = "sampled" if (inv_g - inv_s) >= 0.05 else "greedy"
    res["decoding_rule"] = f"greedy invalid {inv_g:.4f}, sampled invalid {inv_s:.4f}; sampling only if greedy worse by >= 0.05"
    res["decoding"] = decoding

    chosen = res[f"{variant}_{decoding}"]
    length_rate = chosen["length_stops"] / chosen["items"]
    max_new = 384 if length_rate > 0.02 else 256
    res["length_rule"] = f"length stops {chosen['length_stops']} of {chosen['items']} ({length_rate:.4f}); limit {max_new}"
    res["max_new_tokens"] = max_new

    # device parity on the first 40 development prompts
    par = dev.head(40).copy()
    gen_cpu = GenConfig(max_new_tokens=256, device="cpu", dtype="float32",
                        **({"do_sample": True, **SAMPLING} if decoding == "sampled" else {}))
    run_model(model, par, "retrieved", variant, "dev-cpu", gen_cpu, decoding, f"dev-{variant}-{decoding}-cpu", log=log)
    a = score_frame(par, "dev", model, "retrieved", variant, decoding).set_index("prompt_id")
    b = score_frame(par, "dev-cpu", model, "retrieved", variant, decoding).set_index("prompt_id")
    from .evaluate import load_predictions
    from .run import predictions_path
    ra = load_predictions(predictions_path("dev", model, "retrieved", variant, decoding))
    rb = load_predictions(predictions_path("dev-cpu", model, "retrieved", variant, decoding))
    same_text = sum(ra[p]["response"] == rb[p]["response"] for p in b.index if p in ra and p in rb)
    same_label = int((a.loc[b.index, "label_pred"].fillna("NA") == b.label_pred.fillna("NA")).sum())
    res["parity"] = {"n": int(len(b)), "identical_response": int(same_text), "same_label": same_label,
                     "label_agreement": same_label / len(b)}
    res["device"] = device if same_label / len(b) >= 0.95 else "cpu"
    res["utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")

    frozen = {
        "frozen_utc": res["utc"], "primary_model": model, "models": C.MODELS,
        "variant": variant, "decoding": decoding,
        "gen": {"max_new_tokens": max_new, "do_sample": decoding == "sampled",
                **(SAMPLING if decoding == "sampled" else {}), "seed": 20261007, "dtype": "float32",
                "device": res["device"], "enable_thinking": False},
        "budget_tokens": 1024, "conditions": ["retrieved", "abstract", "oracle"],
        "test_order_salt": "ema-2026-10-07:", "time_budgets_hours": {"qwen3-1.7b": 6, "qwen3-0.6b": 3,
                                                                     "qwen3-4b-instruct-2507": 3},
        "4b_conditions": ["retrieved"], "min_quote_words": 4, "bootstrap_reps": 10000, "random_reject_draws": 2000,
        "seed": 20261007,
    }
    (C.RESULTS / "dev").mkdir(parents=True, exist_ok=True)
    (C.RESULTS / "dev" / "dev_decisions.json").write_text(json.dumps(res, indent=2, default=str))
    (C.CONFIG_DIR / "frozen_config.json").write_text(json.dumps(frozen, indent=2))
    return res


if __name__ == "__main__":
    main()
