"""Evidence model audit: citation validity versus answer correctness on Evidence Inference 2.0."""

__version__ = "1.0.0"
