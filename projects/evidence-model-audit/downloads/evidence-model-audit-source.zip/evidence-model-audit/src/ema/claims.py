"""evidence/claims.json: every headline number mapped to its output path, key, denominator, scope, and run."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

from . import config as C


def _sha(p) -> str:
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def _get(d, path):
    for k in path:
        d = d[k]
    return d


def build_and_check() -> dict:
    rpath = C.RESULTS / "analysis" / "results.json"
    res = json.loads(rpath.read_text())
    man = json.loads((C.ROOT / "source_manifest.json").read_text())
    src_hashes = {"annotations_merged.csv": man["sources"][0]["files"]["annotations/annotations_merged.csv"]["sha256"],
                  "prompts_merged.csv": man["sources"][0]["files"]["annotations/prompts_merged.csv"]["sha256"],
                  "txt_files_digest": man["sources"][0]["txt_files"]["digest_sha256"]}
    fz = res["frozen_config"]
    runs = res.get("runs", {})
    claims = []

    def add(cid, text, path, scope, system=None, kind="rate"):
        v = _get(res, path)
        rec = {"id": cid, "statement": text, "output_path": str(rpath.relative_to(C.ROOT)), "json_key": " > ".join(map(str, path)), "json_path": list(path),
               "scope": scope, "configuration": {"variant": fz["variant"], "decoding": fz["decoding"],
                                                  "budget_tokens": fz["budget_tokens"], "gen": fz["gen"]},
               "source_hashes": src_hashes}
        if isinstance(v, dict):
            rec.update({k: v.get(k) for k in ("estimate", "numerator", "denominator", "ci_low", "ci_high", "articles")})
        else:
            rec["value"] = v
        if system:
            m = system.split("::")[0]
            rec["system"] = system
            rec["run_id"] = runs.get(m, {}).get("run_id", "baselines" if not m.startswith("qwen") else None)
            rec["model_revision"] = C.MODELS.get(m, {}).get("revision")
        claims.append(rec)

    prim = "qwen3-1.7b::retrieved"
    if prim in res["systems"]:
        add("headline_qvwr", "Quote-valid answers with the wrong direction label, Qwen3-1.7B, retrieved context",
            ["systems", prim, "metrics", "headline_qvwr"], "eligible test prompts in completed articles", prim)
        add("task_success_primary", "End-to-end task success, Qwen3-1.7B, retrieved context",
            ["systems", prim, "metrics", "task_success"], "all eligible items including invalid outputs", prim)
        add("quote_exists_primary", "Answered prompts whose quote exists in the supplied passages, Qwen3-1.7B, retrieved",
            ["systems", prim, "metrics", "quote_exists_among_answered"], "answered prompts", prim)
        add("accuracy_answered_primary", "Direction-label accuracy among answered prompts, Qwen3-1.7B, retrieved",
            ["systems", prim, "metrics", "accuracy_among_answered"], "answered prompts", prim)
        add("parse_validity_primary", "Parse-valid answers, Qwen3-1.7B, retrieved",
            ["systems", prim, "metrics", "parse_validity"], "all eligible items", prim)
        add("filter_error_primary", "Retained error after quote-validity rejection, Qwen3-1.7B, retrieved",
            ["systems", prim, "rejection", "quote_filter", "retained_error"], "answered prompts kept by the filter", prim)
        add("unfiltered_error_primary", "Retained error without rejection, Qwen3-1.7B, retrieved",
            ["systems", prim, "rejection", "unfiltered", "retained_error"], "answered prompts", prim)
        add("random_error_primary", "Mean retained error under coverage-matched random rejection, Qwen3-1.7B, retrieved",
            ["systems", prim, "rejection", "random_same_coverage", "mean_error"], "2,000 seeded draws", prim)
        add("filter_coverage_primary", "Coverage after quote-validity rejection, Qwen3-1.7B, retrieved",
            ["systems", prim, "rejection", "quote_filter", "coverage"], "all eligible items", prim)
    for key in res["systems"]:
        if key == prim:
            continue
        add(f"qvwr::{key}", f"Quote-valid wrong-direction rate, {key}", ["systems", key, "metrics", "headline_qvwr"],
            "full official test split" if key.endswith("full_split") else "eligible test prompts in completed articles", key)
        add(f"task_success::{key}", f"End-to-end task success, {key}", ["systems", key, "metrics", "task_success"],
            "all eligible items", key)
    if "evidence_recall_at_budget" in res:
        for cond in res["evidence_recall_at_budget"]:
            add(f"evidence_recall_any::{cond}", f"Supplied passages overlap benchmark evidence, {cond} condition",
                ["evidence_recall_at_budget", cond, "any_overlap"], "eligible test prompts with located evidence")
    counts = {}
    qa = json.loads((C.DATA_PROCESSED / "build_qa.json").read_text())
    counts["source_prompt_rows"] = qa["prompts"]["rows"]
    counts["source_annotation_rows"] = qa["annotations"]["rows"]
    counts["test_split_articles_with_prompts"] = qa["prompts"]["articles_with_prompts_by_split"]["test"]
    counts["eligible_test_prompts_full_split"] = qa["prompts"]["eligible_primary_by_split"]["test"]
    if prim in res["systems"]:
        counts["eligible_test_prompts_primary_model_sample"] = res["systems"][prim]["items_primary"]
        counts["test_articles_with_eligible_prompts_analyzed"] = res["systems"][prim]["articles"]
    if "qwen3-1.7b" in res.get("runs", {}):
        counts["test_articles_in_model_sample_run"] = res["runs"]["qwen3-1.7b"]["articles_completed"]
    calls = rerun = 0
    for p in (C.RESULTS / "predictions" / "test").glob("qwen*.jsonl"):
        for line in p.read_text(encoding="utf-8").split("\n"):
            if line.strip():
                calls += 1
                rerun += json.loads(line).get("run_id") == "test-oracle-a3"
    counts["test_model_calls_recorded"] = calls
    counts["test_model_calls_oracle_rerun_after_amendment_a3"] = rerun
    out = {"generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "results_sha256": _sha(rpath), "counts_kept_separate": counts, "claims": claims}
    p = C.EVIDENCE / "claims.json"
    p.write_text(json.dumps(out, indent=2, default=str))
    # check: every claim value re-read from results.json equals the recorded value
    ok = all((_get(res, c["json_path"]) == c.get("value")) if "value" in c else
             (_get(res, c["json_path"])["numerator"] == c["numerator"]
              and _get(res, c["json_path"])["denominator"] == c["denominator"]) for c in claims)
    return {"claims": len(claims), "all_reproduce_from_results": ok, "path": str(p.relative_to(C.ROOT))}
