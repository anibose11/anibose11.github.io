"""Build examples/demo_items.json and examples/demo_cached_outputs.json from the frozen test run.

Selection rule (fixed): among primary test prompts answered by Qwen3-1.7B in the
retrieved condition from articles that Europe PMC reports as CC BY or CC0, take
the lowest prompt ID in each failure type, one prompt per article. The items
carry the supplied passages (with article offsets), the benchmark label and
evidence spans, the license, and attribution.
"""
from __future__ import annotations

import json

import pandas as pd

from . import config as C
from .evaluate import load_predictions, primary_mask
from .licenses import public_ok
from .run import build_contexts, predictions_path, test_items_frame
from .viewer import FAILURE_ORDER, failure_type


def main(log=print) -> dict:
    fz = json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())
    lic = json.loads((C.DATA_INTERIM / "licenses_europepmc.json").read_text())
    df = pd.read_csv(C.RESULTS / "scored" / "test" / f"qwen3-1.7b__retrieved__{fz['variant']}__{fz['decoding']}.csv")
    df = df[primary_mask(df)].copy()
    df = df[df.pmcid.map(lambda p: public_ok(lic.get(f"PMC{p}", {})))]
    df["ft"] = [failure_type(r) for r in df.to_dict("records")]
    used, picks = set(), []
    for ft in FAILURE_ORDER:
        for r in df[df.ft == ft].sort_values("prompt_id").itertuples():
            if r.pmcid not in used:
                picks.append(r)
                used.add(r.pmcid)
                break
    frame = test_items_frame()
    ctxs = build_contexts(frame, "retrieved", "test")
    raw = load_predictions(predictions_path("test", "qwen3-1.7b", "retrieved", fz["variant"], fz["decoding"]))
    fr = frame.set_index("prompt_id")
    items, outs = [], {}
    for r in picks:
        ctx = ctxs[int(r.prompt_id)]
        L = lic[f"PMC{r.pmcid}"]
        items.append({
            "prompt_id": int(r.prompt_id), "pmcid": int(r.pmcid), "condition": "retrieved",
            "intervention": fr.loc[r.prompt_id, "intervention"], "comparator": fr.loc[r.prompt_id, "comparator"],
            "outcome": fr.loc[r.prompt_id, "outcome"], "gold_label": r.gold_label,
            "gold_spans": json.loads(fr.loc[r.prompt_id, "gold_spans"]), "context_tokens": ctx.context_tokens,
            "passages": [{"pid": p.pid, "start": p.start, "end": p.end, "text": p.text, "section": p.section}
                         for p in ctx.passages],
            "license": L["license"], "attribution": {k: L.get(k) for k in ("authors", "title", "journal", "year", "doi")},
            "failure_type_in_study": r.ft,
        })
        rec = raw[int(r.prompt_id)]
        outs[str(int(r.prompt_id))] = {"response": rec["response"], "finish_reason": rec["finish_reason"],
                                       "cache_key": rec["cache_key"]}
    ex = C.ROOT / "examples"
    ex.mkdir(exist_ok=True)
    (ex / "demo_items.json").write_text(json.dumps({
        "description": "Demonstration items from the Evidence Inference 2.0 test split, chosen by the fixed rule in "
                       "src/ema/examples_build.py from CC BY or CC0 articles. Passages are excerpts of the source "
                       "articles with attribution. Labels and evidence spans come from the Evidence Inference 2.0 "
                       "annotations (DeYoung et al. 2020).", "items": items}, indent=1, ensure_ascii=False))
    (ex / "demo_cached_outputs.json").write_text(json.dumps({
        "model": "qwen3-1.7b", "revision": C.MODELS["qwen3-1.7b"]["revision"], "run_id": "test-main",
        "variant": fz["variant"], "decoding": fz["decoding"], "outputs": outs}, indent=1, ensure_ascii=False))
    log(f"demo items: {len(items)} ({', '.join(i['failure_type_in_study'] for i in items)})")
    return {"items": len(items)}
