"""Validate stage: source reconciliation, deterministic reruns, model rerun sample, R cross-check, claims.

Three kinds of checking are kept apart in the report:
  * software testing (pytest, synthetic fixtures),
  * source reconciliation and reruns (this module), and
  * external scientific validation, which none of these steps provides.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone

import numpy as np
import pandas as pd

from . import config as C

TOL = 1e-9


def _sha(p) -> str:
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def reconcile_sources() -> dict:
    from .data import load_annotations, load_prompts, split_map

    smap = split_map()
    A = load_annotations()
    O = pd.read_csv(C.EI_OFFICIAL_DIR / "v2.0" / "annotations_merged.csv")
    T = pd.read_csv(C.EI_OFFICIAL_DIR / "test_annotations_merged.csv")
    P = load_prompts()
    PO = pd.read_csv(C.EI_OFFICIAL_DIR / "v2.0" / "prompts_merged.csv")
    out = {"annotation_rows": {"repo": int(len(A)), "official_v2_0": int(len(O))}}
    out["annotation_rows_by_split"] = {s: {"repo": int((A.pmcid.map(smap) == s).sum()),
                                           "official_v2_0": int((O.PMCID.map(smap) == s).sum())}
                                       for s in ("train", "validation", "test")}
    out["test_rows_official_answers_file"] = int(len(T))
    key = ["UserID", "PromptID", "PMCID", "Label Code", "Valid Label", "Valid Reasoning", "In Abstract"]
    a_test = A[A.pmcid.map(smap) == "test"].rename(columns={"user_id": "UserID", "prompt_id": "PromptID", "pmcid": "PMCID",
                                                             "label_code": "Label Code", "valid_label": "Valid Label",
                                                             "valid_reasoning": "Valid Reasoning", "in_abstract": "In Abstract"})
    m1 = a_test[key].astype(str).value_counts().sort_index()
    m2 = T[key].astype(str).value_counts().sort_index()
    out["test_rows_match_official_answers"] = bool(m1.equals(m2))
    out["label_code_match_official_v2_0"] = bool((A.label_code.values == O["Label Code"].values).all())
    out["prompts_identical_to_official"] = bool(P.shape[0] == PO.shape[0] and _sha(C.EI_ANN_DIR / "prompts_merged.csv")
                                                == _sha(C.EI_OFFICIAL_DIR / "v2.0" / "prompts_merged.csv"))
    # reconciliation figures quoted in the documentation
    out["official_label_str_variant_rows"] = int(((O["Label"] == "significantly increase") & (O["Label Code"] == 1)).sum())
    import os
    otxt = C.EI_OFFICIAL_DIR / "v2.0" / "txt_files"
    files = sorted(os.listdir(otxt))
    same = other = 0
    other_ids = set()
    for f in files:
        a = (otxt / f).read_bytes().decode("utf-8").replace("\r\n", "\n")
        b = (C.EI_ANN_DIR / "txt_files" / f).read_text(encoding="utf-8")
        if a == b:
            same += 1
        else:
            other += 1
            other_ids.add(int(f[3:-4]))
    out["official_txt_files"] = len(files)
    out["official_txt_identical_after_crlf"] = same
    out["official_txt_other_rendering"] = other
    R = pd.read_csv(C.EI_ANN_DIR / "annotations_merged.csv").drop(columns=["Unnamed: 0"])
    diff = (O["Evidence Start"] != R["Evidence Start"]) | (O["Evidence End"] != R["Evidence End"])
    out["offset_rows_differing"] = int(diff.sum())
    out["offset_differing_articles"] = int(O[diff].PMCID.nunique())
    out["offset_differing_articles_all_in_other_rendering"] = bool(set(O[diff].PMCID) <= other_ids)
    # offset convention: seeded 3,000-row training samples (random_state=0), exclusive versus inclusive ends
    tr = set(i for i, sp in smap.items() if sp == "train")
    def sample_check(ann, txt_dir, newline):
        d = ann[ann.PMCID.isin(tr) & (ann["Evidence Start"] >= 0)].sample(3000, random_state=0)
        ex = inc = 0
        for r in d.itertuples():
            raw = (txt_dir / f"PMC{r.PMCID}.txt").read_bytes().decode("utf-8")
            t = raw.replace("\r\n", "\n") if newline else raw
            s0, e0, ev = int(r._10), int(r._11), str(r.Annotations)
            ex += t[s0:e0] == ev
            inc += t[s0:e0 + 1] == ev
        return {"n": 3000, "seed": 0, "exclusive_exact": ex, "inclusive_exact": inc}
    out["offset_sample_repo"] = sample_check(R, C.EI_ANN_DIR / "txt_files", False)
    out["offset_sample_official"] = sample_check(O, otxt, True)
    out["split_files_identical_to_official"] = all(
        _sha(C.EI_ANN_DIR / "splits" / f"{s}_article_ids.txt") == _sha(C.EI_OFFICIAL_DIR / "v2.0" / "splits" / f"{s}_article_ids.txt")
        for s in ("train", "validation", "test"))
    return out


def rerun_deterministic(log=print) -> dict:
    """Rebuild data, contexts, scores, and analysis from cached inputs; compare with stored outputs."""
    from . import data
    from .contexts import TokenCounter, build_context, load_bm25
    from .run import test_items_frame

    res = {}
    out = data.build()
    for name, df in (("articles", out.articles), ("prompts", out.prompts)):
        stored = pd.read_csv(C.DATA_PROCESSED / f"{name}.csv")
        fresh = pd.read_csv(pd.io.common.StringIO(df.to_csv(index=False)))
        res[f"data_{name}_identical"] = bool(stored.equals(fresh))
    frame = test_items_frame()
    cnt, bm = TokenCounter(), load_bm25()
    for cond in ("retrieved", "abstract", "oracle"):
        stored = {}
        for line in (C.RESULTS / "contexts" / f"test_{cond}.jsonl").read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            d = json.loads(line)
            stored[d["prompt_id"]] = d
        diff = 0
        for r in frame.itertuples():
            fresh = build_context(r, cond, cnt, 1024, bm).to_json()
            s = stored[int(r.prompt_id)]
            fp = [(p["pid"], p["start"], p["end"]) for p in fresh["passages"]]
            sp = [(p["pid"], p["start"], p["end"]) for p in s["passages"]]
            diff += fp != sp
        res[f"contexts_{cond}_items_differing"] = diff
        log(f"contexts {cond}: {diff} differing")
    # re-score and re-analyze into a scratch copy, then compare numbers
    before = json.loads((C.RESULTS / "analysis" / "results.json").read_text())
    scored_before = {p.name: pd.read_csv(p) for p in (C.RESULTS / "scored" / "test").glob("*.csv")}
    from . import pipeline
    after = pipeline.analyze(log=lambda m: None)
    after = json.loads((C.RESULTS / "analysis" / "results.json").read_text())
    nb, na = _numbers(before), _numbers(after)
    keys = set(nb) | set(na)
    bad = [k for k in keys if k not in nb or k not in na or not _close(nb[k], na[k])
           and not k.startswith(("generated_utc",))]
    res["analysis_numbers_compared"] = len(keys)
    res["analysis_numbers_differing"] = [k for k in bad if "utc" not in k][:20]
    sdiff = 0
    for name, df in scored_before.items():
        d2 = pd.read_csv(C.RESULTS / "scored" / "test" / name)
        sdiff += not df.equals(d2)
    res["scored_files_compared"] = len(scored_before)
    res["scored_files_differing"] = sdiff
    res["tolerance"] = TOL
    return res


def _numbers(d, prefix="") -> dict:
    out = {}
    if isinstance(d, dict):
        for k, v in d.items():
            out.update(_numbers(v, f"{prefix}{k}."))
    elif isinstance(d, list):
        for i, v in enumerate(d):
            out.update(_numbers(v, f"{prefix}{i}."))
    elif isinstance(d, (int, float)) and not isinstance(d, bool):
        out[prefix.rstrip(".")] = d
    return out


def _close(a, b) -> bool:
    return abs(float(a) - float(b)) <= TOL * max(1.0, abs(float(a)))


def model_rerun_sample(n: int = 40, log=print) -> dict:
    """Generate n test items again (cache bypassed) with the frozen configuration and compare responses."""
    from .evaluate import load_predictions
    from .infer import LocalModel
    from .prompts import messages
    from .run import build_contexts, predictions_path, test_items_frame
    from .testrun import frozen, gen_from_frozen

    fz = frozen()
    frame = test_items_frame()
    ctxs = build_contexts(frame, "retrieved", "test")
    saved = load_predictions(predictions_path("test", "qwen3-1.7b", "retrieved", fz["variant"], fz["decoding"]))
    sample = [r for r in frame.itertuples() if int(r.prompt_id) in saved][:n]
    m = LocalModel("qwen3-1.7b", gen_from_frozen(fz))
    same = same_label = 0
    rows = []
    for r in sample:
        g = m.generate([m.render(messages(r, ctxs[int(r.prompt_id)], fz["variant"]))])[0]
        s = saved[int(r.prompt_id)]["response"]
        same += g["response"] == s
        lab = lambda t: (json.loads(t[t.find("{"):t.rfind("}") + 1]).get("label") if "{" in (t or "") else None)
        try:
            sl = lab(g["response"]) == lab(s)
        except Exception:
            sl = False
        same_label += sl
        rows.append({"prompt_id": int(r.prompt_id), "identical": g["response"] == s, "same_label": sl})
    log(f"model rerun: {same}/{len(sample)} identical responses")
    return {"n": len(sample), "identical_responses": same, "same_label": same_label, "device": m.env["device"],
            "items": rows}


def r_crosscheck() -> dict:
    p = C.ROOT / "scripts" / "crosscheck.R"
    r = subprocess.run(["Rscript", str(p), str(C.RESULTS / "scored")], capture_output=True, text=True)
    out = {"returncode": r.returncode, "stderr": r.stderr[-500:]}
    try:
        rr = json.loads(r.stdout)
    except Exception:
        out["stdout"] = r.stdout[-500:]
        return out
    py = json.loads((C.RESULTS / "analysis" / "results.json").read_text())["systems"]
    cmp = []
    for key, v in rr.items():
        h = py[key]["metrics"]["headline_qvwr"]
        s = py[key]["metrics"]["summary"]
        cmp.append({"system": key, "r_num": v["num"], "py_num": h["numerator"], "r_den": v["den"],
                    "py_den": h["denominator"], "r_success": v["success"], "py_success": s["task_success"],
                    "r_items": v["items"], "py_items": s["items"],
                    "match": v["num"] == h["numerator"] and v["den"] == h["denominator"] and
                    v["success"] == s["task_success"] and v["items"] == s["items"]})
    out["comparisons"] = cmp
    out["all_match"] = all(c["match"] for c in cmp)
    return out


def main(log=print, model_rerun: bool = True) -> dict:
    res = {"utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    log("reconciling sources")
    res["source_reconciliation"] = reconcile_sources()
    log("deterministic reruns")
    res["deterministic_rerun"] = rerun_deterministic(log)
    log("R cross-check")
    res["r_crosscheck"] = r_crosscheck()
    if model_rerun:
        log("model rerun sample")
        res["model_rerun_sample"] = model_rerun_sample(log=log)
    from . import claims
    res["claims"] = claims.build_and_check()
    out = C.RESULTS / "validation" / "validation.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=2, default=str))
    log(f"wrote {out}")
    return res
