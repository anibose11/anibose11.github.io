"""Context construction for the three matched conditions.

retrieved  BM25 over sentence-packed chunks of the article text, queried with
           intervention + comparator + outcome only. Top chunks are added in
           score order until the token budget is reached, then presented in
           article order. IDF statistics come from training-split chunks only.
abstract   The title-plus-abstract region of the same article text, split at
           section headers, truncated at the same token budget.
oracle     The accepted benchmark evidence spans for the prompt (an upper
           bound that a deployed system could not use).

Every passage keeps its article character offsets so that a returned quote
can be mapped back to the article and compared with benchmark evidence.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import asdict, dataclass, field
from functools import lru_cache

from . import config as C
from .data import abstract_region, article_text

STOP = set("""a an and are as at be by for from has have in is it its of on or that the to was were with
which this these those than then patients patient receiving received group groups versus vs compared
between after before during their there been not no""".split())
TOKEN_RE = re.compile(r"[a-z0-9]+(?:[.\-][a-z0-9]+)*")
HEADER_RE = re.compile(r"^[ \t]*(ABSTRACT|BODY)[^\n]*:[ \t]*$")
TITLE_RE = re.compile(r"^TITLE:[ \t]*")
SENT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z(\[])")
CHUNK_MAX_WORDS = 60


def tokenize(s: str) -> list[str]:
    return [t for t in TOKEN_RE.findall(s.lower()) if t not in STOP]


@dataclass
class Passage:
    pid: str
    start: int
    end: int
    text: str
    section: str = ""
    score: float | None = None


@dataclass
class Context:
    prompt_id: int
    pmcid: int
    condition: str
    passages: list[Passage]
    budget_tokens: int
    context_tokens: int
    truncated: bool
    available: bool = True
    unavailable_reason: str = ""
    extra: dict = field(default_factory=dict)

    def to_json(self) -> dict:
        d = asdict(self)
        return d


def paragraphs(text: str, end: int | None = None) -> list[tuple[int, int, str]]:
    """(start, end, section) for paragraphs: maximal runs of non-blank, non-header lines.

    Hard line wraps inside a paragraph are kept in the slice; the TITLE: prefix is
    excluded from the title paragraph.
    """
    end = len(text) if end is None else end
    out, section = [], ""
    pos, cur_s, cur_e = 0, None, None
    for line in text[:end].split("\n"):
        lstart, pos = pos, pos + len(line) + 1
        st = line.strip()
        is_header = bool(HEADER_RE.match(line))
        if not st or is_header:
            if cur_s is not None:
                out.append((cur_s, cur_e, section))
                cur_s = None
            if is_header:
                section = st.rstrip(":").rstrip(":")
            continue
        m = TITLE_RE.match(line)
        if m and lstart == 0:
            section = "TITLE"
            lead = m.end()
            if not line[lead:].strip():
                continue
        else:
            lead = len(line) - len(line.lstrip())
        if cur_s is None:
            cur_s = lstart + lead
        cur_e = lstart + len(line.rstrip())
    if cur_s is not None:
        out.append((cur_s, cur_e, section))
    return out


def chunk_article(text: str, end: int | None = None, max_words: int = CHUNK_MAX_WORDS) -> list[tuple[int, int, str, str]]:
    """Split into (start, end, section, text) chunks of whole sentences, at most ~max_words words, within paragraphs."""
    out = []
    for ps, pe, sec in paragraphs(text, end):
        para = text[ps:pe].replace("\n", " ")  # same length, so offsets are preserved
        bounds = [0] + [m.end() for m in SENT_RE.finditer(para)] + [len(para)]
        sents = []
        for i in range(len(bounds) - 1):
            s0, e0 = bounds[i], bounds[i + 1]
            if not para[s0:e0].strip():
                continue
            # a "sentence" longer than max_words (tables, run-on text) is cut at word boundaries
            words_pos = [m.span() for m in re.finditer(r"\S+", para[s0:e0])]
            if len(words_pos) <= max_words:
                sents.append((s0, e0))
            else:
                for k in range(0, len(words_pos), max_words):
                    grp = words_pos[k:k + max_words]
                    sents.append((s0 + grp[0][0], s0 + grp[-1][1]))
        cur_s, cur_e, words = None, None, 0
        pieces = []
        for s, e in sents:
            w = len(para[s:e].split())
            if cur_s is not None and words + w > max_words:
                pieces.append((cur_s, cur_e))
                cur_s, words = None, 0
            if cur_s is None:
                cur_s = s
            cur_e, words = e, words + w
        if cur_s is not None:
            pieces.append((cur_s, cur_e))
        for s, e in pieces:
            seg = para[s:e]
            ls = len(seg) - len(seg.lstrip())
            rs = len(seg.rstrip())
            a, b = ps + s + ls, ps + s + rs
            out.append((a, b, sec, text[a:b]))
    return out


class BM25:
    def __init__(self, df: Counter, n_docs: int, avgdl: float, k1: float = 1.2, b: float = 0.75):
        self.df, self.n, self.avgdl, self.k1, self.b = df, n_docs, avgdl, k1, b

    @classmethod
    def fit(cls, chunk_token_lists: list[list[str]]) -> "BM25":
        df = Counter()
        for toks in chunk_token_lists:
            df.update(set(toks))
        avgdl = sum(len(t) for t in chunk_token_lists) / max(1, len(chunk_token_lists))
        return cls(df, len(chunk_token_lists), avgdl)

    def idf(self, t: str) -> float:
        n = self.df.get(t, 0)
        return math.log(1 + (self.n - n + 0.5) / (n + 0.5))

    def score(self, query: list[str], doc: list[str]) -> float:
        tf = Counter(doc)
        dl = len(doc)
        s = 0.0
        for q in set(query):
            f = tf.get(q, 0)
            if f:
                s += self.idf(q) * f * (self.k1 + 1) / (f + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
        return s

    def to_json(self) -> dict:
        return {"n_docs": self.n, "avgdl": self.avgdl, "k1": self.k1, "b": self.b, "df": dict(self.df)}

    @classmethod
    def from_json(cls, d: dict) -> "BM25":
        return cls(Counter(d["df"]), d["n_docs"], d["avgdl"], d["k1"], d["b"])


def fit_bm25(train_pmcids: list[int]) -> BM25:
    lists = []
    for p in train_pmcids:
        t = article_text(p)
        if t is None:
            continue
        lists.extend(tokenize(c[3]) for c in chunk_article(t))
    return BM25.fit(lists)


@lru_cache(maxsize=1)
def load_bm25() -> BM25:
    return BM25.from_json(json.loads((C.DATA_INTERIM / "bm25_train_stats.json").read_text()))


class TokenCounter:
    """Counts tokens with the Qwen3 tokenizer (shared by all three evaluated models)."""

    def __init__(self, model_dir=None):
        from transformers import AutoTokenizer

        self.tok = AutoTokenizer.from_pretrained(str(model_dir or (C.MODELS_DIR / "qwen3-1.7b")))

    def __call__(self, s: str) -> int:
        return len(self.tok(s, add_special_tokens=False)["input_ids"])

    def truncate(self, s: str, n: int) -> str:
        ids = self.tok(s, add_special_tokens=False, return_offsets_mapping=True)
        if len(ids["input_ids"]) <= n:
            return s
        end = ids["offset_mapping"][n - 1][1]
        return s[:end]


def query_text(intervention: str, comparator: str, outcome: str) -> str:
    return f"{intervention} {comparator} {outcome}"


def retrieved_context(row, text: str, bm25: BM25, count, budget: int) -> Context:
    chunks = chunk_article(text)
    q = tokenize(query_text(row.intervention, row.comparator, row.outcome))
    scored = sorted(((bm25.score(q, tokenize(c[3])), i) for i, c in enumerate(chunks)), key=lambda x: (-x[0], x[1]))
    chosen, used = [], 0
    for sc, i in scored:
        n = count(chunks[i][3])
        if used + n > budget:
            continue  # skip chunks that would overflow; smaller later chunks may still fit
        chosen.append((i, sc))
        used += n
        if used >= budget:
            break
    chosen.sort()
    passages = [Passage(f"P{k + 1}", chunks[i][0], chunks[i][1], chunks[i][3], chunks[i][2], round(sc, 4))
                for k, (i, sc) in enumerate(chosen)]
    return Context(row.prompt_id, row.pmcid, "retrieved", passages, budget, used, False,
                   extra={"n_chunks": len(chunks), "query_tokens": q})


def abstract_context(row, text: str, count, budget: int) -> Context:
    end, status = abstract_region(text)
    if status != "ok":
        return Context(row.prompt_id, row.pmcid, "abstract", [], budget, 0, False, False, status)
    passages, used, truncated = [], 0, False
    k = 0
    for s, e, sec, t in chunk_abstract(text, end):
        n = count(t)
        if used + n > budget:
            remaining = budget - used
            if remaining > 20:
                t2 = count.truncate(t, remaining)
                k += 1
                passages.append(Passage(f"P{k}", s, s + len(t2), t2, sec))
                used += count(t2)
            truncated = True
            break
        k += 1
        passages.append(Passage(f"P{k}", s, e, t, sec))
        used += n
    return Context(row.prompt_id, row.pmcid, "abstract", passages, budget, used, truncated)


def chunk_abstract(text: str, end: int) -> list[tuple[int, int, str, str]]:
    """Title and abstract paragraphs as passages."""
    return [(a, b, sec, text[a:b]) for a, b, sec in paragraphs(text, end)]


def oracle_context(row, text: str, count, budget: int) -> Context:
    spans = [tuple(x) for x in json.loads(row.gold_spans)]
    if not spans:
        return Context(row.prompt_id, row.pmcid, "oracle", [], budget, 0, False, False, "no_located_gold_span")
    # merge overlapping spans so that the same text is not shown twice
    spans.sort()
    merged = []
    for s, e in spans:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], e))
        else:
            merged.append((s, e))
    passages, used, truncated = [], 0, False
    for k, (s, e) in enumerate(merged):
        t = text[s:e]
        n = count(t)
        if used + n > budget:
            truncated = True
            break
        passages.append(Passage(f"P{k + 1}", s, e, t, "benchmark evidence"))
        used += n
    return Context(row.prompt_id, row.pmcid, "oracle", passages, budget, used, truncated)


def build_context(row, condition: str, count, budget: int, bm25: BM25 | None = None) -> Context:
    text = article_text(int(row.pmcid))
    if text is None:
        return Context(row.prompt_id, row.pmcid, condition, [], budget, 0, False, False, "no_text")
    if condition == "retrieved":
        return retrieved_context(row, text, bm25 or load_bm25(), count, budget)
    if condition == "abstract":
        return abstract_context(row, text, count, budget)
    if condition == "oracle":
        return oracle_context(row, text, count, budget)
    raise ValueError(condition)


def span_overlap(a: tuple[int, int], b: tuple[int, int]) -> int:
    return max(0, min(a[1], b[1]) - max(a[0], b[0]))


def evidence_recall(ctx: Context, gold_spans: list[tuple[int, int]]) -> dict:
    """Whether supplied passages cover benchmark evidence: any overlap, and full containment of at least one span."""
    if not gold_spans:
        return {"gold_available": False, "any_overlap": None, "full_cover": None}
    cover = [(p.start, p.end) for p in ctx.passages]
    any_ov = any(span_overlap(g, c) > 0 for g in gold_spans for c in cover)
    full = any(sum(span_overlap(g, c) for c in cover) >= (g[1] - g[0]) for g in gold_spans)
    return {"gold_available": True, "any_overlap": any_ov, "full_cover": full}
