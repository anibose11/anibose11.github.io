"""SVG figures written directly, with CSS variables for colour so a host site can re-theme them.

Conventions: <title id="t"> and <desc id="d"> for accessibility, a native
<title> on every data mark for hover, one value axis per chart, thin marks,
hairline grid, series told apart by shape as well as colour, and direct labels
only where they carry the story. Each figure has a companion CSV/HTML table.
"""
from __future__ import annotations

import html

FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif"
STYLE = """<style>
.viz-root{--surface:#fcfcfb;--ink:#1d1d1b;--muted:#5b5a56;--grid:#e6e5e1;--axis:#a9a8a3;--s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;--base:#77766f;--light1:#9ec5f4;--light2:#f6b99f;--neutral:#c9c8c3}
.title{font-size:15px;font-weight:600;fill:var(--ink)}.sub{font-size:12.5px;fill:var(--muted)}.lab{font-size:12.5px;fill:var(--ink)}
.tick{font-size:11.5px;fill:var(--muted)}.val{font-size:11.5px;fill:var(--ink)}.note{font-size:11.5px;fill:var(--muted)}.grp{font-size:12px;font-weight:600;fill:var(--muted)}
.grid{stroke:var(--grid);stroke-width:1}.axis{stroke:var(--axis);stroke-width:1}
</style>"""

SERIES = {  # model -> (css var, marker)
    "qwen3-1.7b": ("--s1", "circle"), "qwen3-0.6b": ("--s2", "triangle"), "qwen3-4b-instruct-2507": ("--s3", "square"),
    "tfidf-lr": ("--base", "ring"), "majority": ("--base", "diamond"),
}
LABEL = {"qwen3-1.7b": "Qwen3-1.7B", "qwen3-0.6b": "Qwen3-0.6B", "qwen3-4b-instruct-2507": "Qwen3-4B-Instruct-2507",
         "tfidf-lr": "TF-IDF + logistic regression", "majority": "Majority class"}
COND = {"retrieved": "Retrieved passages (1,024 tokens)", "abstract": "Title and abstract", "oracle": "Benchmark evidence (oracle)"}


def esc(s) -> str:
    return html.escape(str(s), quote=True)


def head(w: int, h: int, title: str, desc: str) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" class="viz-root" width="{w}" height="{h}" viewBox="0 0 {w} {h}" '
            f'role="img" aria-labelledby="t d" font-family="{FONT}">{STYLE}<title id="t">{esc(title)}</title>'
            f'<desc id="d">{esc(desc)}</desc><rect width="{w}" height="{h}" fill="var(--surface)"/>')


def marker(kind: str, x: float, y: float, var: str, tip: str, r: float = 5.0) -> str:
    t = f"<title>{esc(tip)}</title>"
    ring = 'stroke="var(--surface)" stroke-width="2"'
    if kind == "circle":
        return f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="var({var})" {ring}>{t}</circle>'
    if kind == "triangle":
        p = f"{x:.1f},{y - r - 1:.1f} {x + r + 1:.1f},{y + r:.1f} {x - r - 1:.1f},{y + r:.1f}"
        return f'<polygon points="{p}" fill="var({var})" {ring}>{t}</polygon>'
    if kind == "square":
        return f'<rect x="{x - r:.1f}" y="{y - r:.1f}" width="{2 * r}" height="{2 * r}" fill="var({var})" {ring}>{t}</rect>'
    if kind == "diamond":
        p = f"{x:.1f},{y - r - 1:.1f} {x + r + 1:.1f},{y:.1f} {x:.1f},{y + r + 1:.1f} {x - r - 1:.1f},{y:.1f}"
        return f'<polygon points="{p}" fill="var({var})" {ring}>{t}</polygon>'
    return (f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="var(--surface)" stroke="var({var})" stroke-width="2">{t}'
            f'</circle>')


def xaxis(x0: float, x1: float, y: float, ticks, fmt, top: float, label: str = "") -> str:
    out = []
    for v in ticks:
        x = x0 + (x1 - x0) * v
        out.append(f'<line class="grid" x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{y}"/>')
        out.append(f'<text class="tick" x="{x:.1f}" y="{y + 16}" text-anchor="middle">{fmt(v)}</text>')
    out.append(f'<line class="axis" x1="{x0}" y1="{y}" x2="{x1}" y2="{y}"/>')
    if label:
        out.append(f'<text class="note" x="{(x0 + x1) / 2:.1f}" y="{y + 34}" text-anchor="middle">{esc(label)}</text>')
    return "".join(out)


def pct(v: float) -> str:
    return f"{v * 100:.0f}%"


def dot_ci(rows: list[dict], title: str, sub: str, desc: str, xlabel: str, w: int = 760) -> str:
    """rows: dicts with group, model, est, lo, hi, label (right-hand text), tip. Grouped by condition."""
    groups = []
    for r in rows:
        if r["group"] not in groups:
            groups.append(r["group"])
    row_h, grp_h = 26, 30
    top = 70
    h = top + sum(grp_h + row_h * sum(1 for r in rows if r["group"] == g) for g in groups) + 70
    x0, x1 = 250, w - 150
    out = [head(w, h, title, desc), f'<text class="title" x="16" y="26">{esc(title)}</text>',
           f'<text class="sub" x="16" y="46">{esc(sub)}</text>']
    y = top
    body = []
    for g in groups:
        body.append(f'<text class="grp" x="16" y="{y + 18}">{esc(COND.get(g, g))}</text>')
        y += grp_h
        for r in [r for r in rows if r["group"] == g]:
            cy = y + row_h / 2
            var, kind = SERIES[r["model"]]
            body.append(f'<text class="lab" x="28" y="{cy + 4:.1f}">{esc(LABEL[r["model"]])}</text>')
            if r["est"] is None:
                body.append(f'<text class="note" x="{x0}" y="{cy + 4:.1f}">undefined (no quote-valid answers)</text>')
            else:
                lo, hi = x0 + (x1 - x0) * r["lo"], x0 + (x1 - x0) * r["hi"]
                body.append(f'<line x1="{lo:.1f}" y1="{cy:.1f}" x2="{hi:.1f}" y2="{cy:.1f}" stroke="var({var})" '
                            f'stroke-width="2" stroke-linecap="round"><title>{esc(r["tip"])}</title></line>')
                body.append(marker(kind, x0 + (x1 - x0) * r["est"], cy, var, r["tip"]))
            body.append(f'<text class="val" x="{x1 + 12}" y="{cy + 4:.1f}">{esc(r["label"])}</text>')
            y += row_h
    out.append(xaxis(x0, x1, y + 6, [0, 0.25, 0.5, 0.75, 1.0], pct, top, xlabel))
    out.extend(body)
    out.append("</svg>")
    return "".join(out)


def stacked(rows: list[dict], cats: list[tuple[str, str, str]], title: str, sub: str, desc: str, w: int = 760) -> str:
    """rows: dicts with label, group, counts {cat: n}, total. cats: (key, legend label, css var)."""
    row_h = 30
    # legend items wrap onto as many lines as needed
    leg, lx, ly = [], 16, 60
    for key, lab, var in cats:
        wtxt = 17 + 6.4 * len(lab) + 18
        if lx + wtxt > w - 16:
            lx, ly = 16, ly + 20
        leg.append(f'<rect x="{lx}" y="{ly}" width="12" height="12" fill="var({var})"/>'
                   f'<text class="tick" x="{lx + 17}" y="{ly + 10}">{esc(lab)}</text>')
        lx += wtxt
    top = ly + 36
    groups = []
    for r in rows:
        if r["group"] not in groups:
            groups.append(r["group"])
    h = top + len(rows) * row_h + len(groups) * 26 + 60
    x0, x1 = 250, w - 24
    out = [head(w, h, title, desc), f'<text class="title" x="16" y="26">{esc(title)}</text>',
           f'<text class="sub" x="16" y="46">{esc(sub)}</text>']
    out.extend(leg)
    y = top
    for g in groups:
        out.append(f'<text class="grp" x="16" y="{y + 14}">{esc(COND.get(g, g))}</text>')
        y += 26
        for r in [r for r in rows if r["group"] == g]:
            out.append(f'<text class="lab" x="28" y="{y + 15}">{esc(r["label"])}</text>')
            xs = x0
            for key, lab, var in cats:
                n = r["counts"].get(key, 0)
                if n == 0:
                    continue
                wseg = (x1 - x0) * n / r["total"]
                out.append(f'<rect x="{xs:.1f}" y="{y + 4}" width="{max(0.5, wseg - 2):.1f}" height="16" fill="var({var})">'
                           f'<title>{esc(r["label"])}, {esc(COND.get(g, g))}: {esc(lab)} {n} of {r["total"]} '
                           f'({n / r["total"] * 100:.1f}%)</title></rect>')
                xs += wseg
            y += row_h
    out.append(xaxis(x0, x1, y + 4, [0, 0.25, 0.5, 0.75, 1.0], pct, top + 26, "share of eligible test prompts"))
    out.append("</svg>")
    return "".join(out)


def rejection_chart(rows: list[dict], title: str, sub: str, desc: str, w: int = 760) -> str:
    """rows: label, model, unf, flt, rlo, rhi, rmean, cov_unf, cov_flt. Retained error on the x axis."""
    row_h, top = 34, 96
    h = top + len(rows) * row_h + 70
    x0, x1 = 250, w - 150
    import math
    vals = [v for r in rows for v in (r["unf"], r["flt"], r["rlo"], r["rhi"]) if v is not None]
    lo_all = max(0.0, math.floor((min(vals) - 0.05) * 10) / 10) if vals else 0.0
    hi_all = min(1.0, math.ceil((max(vals) + 0.05) * 10) / 10) if vals else 1.0
    sx = lambda v: x0 + (x1 - x0) * (v - lo_all) / (hi_all - lo_all)
    step = 0.05 if hi_all - lo_all <= 0.4 else 0.1
    nt = int(round((hi_all - lo_all) / step))
    ticks = [round(lo_all + i * step, 4) for i in range(nt + 1)]
    out = [head(w, h, title, desc), f'<text class="title" x="16" y="26">{esc(title)}</text>',
           f'<text class="sub" x="16" y="46">{esc(sub)}</text>']
    out.append('<circle cx="22" cy="66" r="5" fill="var(--surface)" stroke="var(--ink)" stroke-width="2"/>'
               '<text class="tick" x="32" y="70">all answers</text>'
               '<polygon points="130,60 136,71 124,71" fill="var(--ink)"/><text class="tick" x="142" y="70">quote and locator valid only</text>'
               '<line x1="300" y1="66" x2="330" y2="66" stroke="var(--neutral)" stroke-width="8"/>'
               '<text class="tick" x="338" y="70">random rejection at the same coverage, middle 95% of 2,000 draws</text>')
    y = top
    body = []
    for r in rows:
        cy = y + row_h / 2
        var, _ = SERIES[r["model"]]
        body.append(f'<text class="lab" x="16" y="{cy + 4:.1f}">{esc(r["label"])}</text>')
        if r["rlo"] is not None:
            body.append(f'<line x1="{sx(r["rlo"]):.1f}" y1="{cy:.1f}" x2="{sx(r["rhi"]):.1f}" y2="{cy:.1f}" '
                        f'stroke="var(--neutral)" stroke-width="8"><title>Random rejection keeping the same number of '
                        f'answers: mean error {r["rmean"] * 100:.1f}%, middle 95% {r["rlo"] * 100:.1f}% to '
                        f'{r["rhi"] * 100:.1f}%</title></line>')
        if r["unf"] is not None and r["flt"] is not None:
            body.append(f'<line x1="{sx(r["unf"]):.1f}" y1="{cy:.1f}" x2="{sx(r["flt"]):.1f}" y2="{cy:.1f}" '
                        f'stroke="var({var})" stroke-width="2"/>')
        if r["unf"] is not None:
            body.append(marker("ring", sx(r["unf"]), cy, var, f"All answers: error {r['unf'] * 100:.1f}%, coverage "
                                                              f"{r['cov_unf'] * 100:.1f}%"))
        if r["flt"] is not None:
            body.append(marker("triangle", sx(r["flt"]), cy, var, f"Quote and locator valid only: error {r['flt'] * 100:.1f}%, "
                                                                  f"coverage {r['cov_flt'] * 100:.1f}%"))
        body.append(f'<text class="val" x="{x1 + 12}" y="{cy + 4:.1f}">coverage {r["cov_unf"] * 100:.0f}% to '
                    f'{r["cov_flt"] * 100:.0f}%</text>')
        y += row_h
    out.append(xaxis(x0, x1, y + 6, [(t - lo_all) / (hi_all - lo_all) for t in ticks],
                     lambda u: pct(lo_all + u * (hi_all - lo_all)), top,
                     f"share of retained answers with the wrong label (axis starts at {pct(lo_all)})"))
    out.extend(body)
    out.append("</svg>")
    return "".join(out)


def risk_curve(curve: list[dict], overall: float, filt: tuple[float, float] | None, title: str, sub: str, desc: str,
               w: int = 760, h: int = 400) -> str:
    x0, x1, y0, y1 = 70, w - 30, h - 60, 70
    ymax = max(0.6, max(p["risk"] for p in curve) + 0.05) if curve else 1
    sx = lambda c: x0 + (x1 - x0) * c
    sy = lambda r: y0 - (y0 - y1) * r / ymax
    out = [head(w, h, title, desc), f'<text class="title" x="16" y="26">{esc(title)}</text>',
           f'<text class="sub" x="16" y="46">{esc(sub)}</text>']
    for v in [0, 0.2, 0.4, 0.6, 0.8, 1.0]:
        if v <= ymax:
            out.append(f'<line class="grid" x1="{x0}" y1="{sy(v):.1f}" x2="{x1}" y2="{sy(v):.1f}"/>'
                       f'<text class="tick" x="{x0 - 8}" y="{sy(v) + 4:.1f}" text-anchor="end">{pct(v)}</text>')
    for v in [0, 0.25, 0.5, 0.75, 1.0]:
        out.append(f'<text class="tick" x="{sx(v):.1f}" y="{y0 + 18}" text-anchor="middle">{pct(v)}</text>')
    out.append(f'<line class="axis" x1="{x0}" y1="{y0}" x2="{x1}" y2="{y0}"/>')
    out.append(f'<text class="note" x="{(x0 + x1) / 2}" y="{y0 + 38}" text-anchor="middle">coverage (share of eligible '
               f'prompts kept, best-scored first)</text>')
    out.append(f'<text class="note" x="{x0}" y="{y1 - 10}">error among kept answers</text>')
    if curve:
        cmax = curve[-1]["coverage"]
        out.append(f'<line x1="{sx(0):.1f}" y1="{sy(overall):.1f}" x2="{sx(cmax):.1f}" y2="{sy(overall):.1f}" '
                   f'stroke="var(--base)" stroke-width="1.5" stroke-dasharray="5 4"><title>Random ordering: expected error '
                   f'{overall * 100:.1f}% at every coverage</title></line>')
        out.append(f'<text class="note" x="{sx(cmax) - 4:.1f}" y="{sy(overall) - 6:.1f}" text-anchor="end">random order</text>')
        pts = " ".join(f"{sx(p['coverage']):.1f},{sy(p['risk']):.1f}" for p in curve if p["coverage"] >= 0.02)
        out.append(f'<polyline points="{pts}" fill="none" stroke="var(--s1)" stroke-width="2" stroke-linejoin="round" '
                   f'stroke-linecap="round"><title>Development-fitted scoring rule applied to test answers</title></polyline>')
    if filt:
        out.append(marker("triangle", sx(filt[0]), sy(filt[1]), "--ink", f"Quote-validity rule: coverage "
                                                                          f"{filt[0] * 100:.1f}%, error {filt[1] * 100:.1f}%"))
        out.append(f'<text class="val" x="{sx(filt[0]) - 10:.1f}" y="{sy(filt[1]) - 12:.1f}" text-anchor="end">quote-validity rule</text>')
    out.append("</svg>")
    return "".join(out)
