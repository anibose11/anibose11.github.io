"""Command-line interface: `ema <stage>`.

Stages, in order:
  acquire    pinned corpus, official release reference, model snapshots
  build      corpus ingestion, label contract, QA tables, BM25 statistics, source manifest
  devselect  development-only prompt, decoding, and device decisions (writes config/frozen_config.json)
  baselines  majority class and TF-IDF + logistic regression per context condition
  infer      frozen test runs for the local models (cached; resumable)
  analyze    separated metrics, headline estimand, rejection analysis, comparisons, sensitivity
  validate   reconciliation checks, rerun comparison, claims mapping
  render     figures, tables, workbook, viewer, report, manuscript
  package    source archive, site pages, handoff files, outer bundle
  demo       real local inference on bundled permitted examples (or --cached to view saved outputs)
  view       build the local source-and-prediction viewer for any scored run
"""
from __future__ import annotations

import argparse
import json
import sys


def _log(m: str) -> None:
    print(m, flush=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ema", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="stage", required=True)
    a = sub.add_parser("acquire")
    a.add_argument("--models", nargs="*", default=None, help="model names (default all)")
    a.add_argument("--no-models", action="store_true")
    a.add_argument("--no-corpus", action="store_true")
    sub.add_parser("build")
    d = sub.add_parser("devselect")
    d.add_argument("--device", default="mps")
    sub.add_parser("baselines")
    i = sub.add_parser("infer")
    i.add_argument("--model", default=None, help="run one model only")
    i.add_argument("--device", default=None)
    sub.add_parser("analyze")
    sub.add_parser("validate")
    sub.add_parser("render")
    sub.add_parser("package")
    de = sub.add_parser("demo")
    de.add_argument("--cached", action="store_true", help="view saved outputs without loading a model")
    de.add_argument("--model", default="qwen3-0.6b")
    de.add_argument("--device", default="cpu")
    v = sub.add_parser("view")
    v.add_argument("--model", default="qwen3-1.7b")
    v.add_argument("--condition", default="retrieved")
    v.add_argument("--out", default="results/viewer_local.html")
    args = ap.parse_args(argv)

    if args.stage == "acquire":
        from . import acquire
        acquire.main(models=not args.no_models, corpus=not args.no_corpus, model_names=args.models)
    elif args.stage == "build":
        from . import config as C, contexts as X, data, provenance
        out = data.build()
        data.write(out)
        train = out.articles[(out.articles.split == "train") & out.articles.has_text].pmcid.tolist()
        bm = X.fit_bm25(train)
        (C.DATA_INTERIM / "bm25_train_stats.json").write_text(json.dumps(bm.to_json()))
        provenance.build()
        from . import licenses
        from .run import budget_recall
        ids = out.prompts[out.prompts.split.isin(["validation", "test"])].pmcid.unique().tolist()
        licenses.lookup(ids)  # Europe PMC license per article (cached)
        budget_recall()        # development evidence recall at three retrieval budgets
        _log(json.dumps(out.qa["prompts"]["eligible_primary_by_split"]))
    elif args.stage == "devselect":
        from . import devsel
        devsel.main(device=args.device, log=_log)
    elif args.stage == "baselines":
        from . import baselines
        baselines.main(log=_log)
    elif args.stage == "infer":
        from . import testrun
        if args.model:
            fz = testrun.frozen()
            conds = fz["4b_conditions"] if args.model.startswith("qwen3-4b") else ["retrieved", "abstract", "oracle"]
            testrun.run(args.model, conds, fz["time_budgets_hours"][args.model], "test-main", _log, args.device)
        else:
            testrun.main(log=_log)
    elif args.stage == "analyze":
        from . import pipeline
        pipeline.analyze(log=_log)
    elif args.stage == "validate":
        from . import validate
        validate.main(log=_log)
    elif args.stage == "render":
        from . import report
        report.main(log=_log)
    elif args.stage == "package":
        from . import package
        package.main(log=_log)
    elif args.stage == "demo":
        from . import demo
        demo.main(cached=args.cached, model=args.model, device=args.device, log=_log)
    elif args.stage == "view":
        from . import viewer
        viewer.local_view(args.model, args.condition, args.out, log=_log)
    return 0


if __name__ == "__main__":
    sys.exit(main())
