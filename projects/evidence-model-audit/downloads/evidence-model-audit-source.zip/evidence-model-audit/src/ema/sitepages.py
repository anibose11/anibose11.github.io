"""Static portfolio pages for /projects/evidence-model-audit/ and the handoff files."""
from __future__ import annotations

import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from . import config as C
from .manuscript import escape_prompt_placeholders, fill, values
from .package import HANDOFF, SITE, SLUG, sha256

TEMPLATES = C.ROOT / "site_templates"

CSS = """:root{--bg:#fbfbfa;--ink:#1d1d1b;--muted:#55544f;--rule:#d9d8d3;--accent:#1f5fae;--plate:#f2f1ee}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
a{color:var(--accent);text-underline-offset:2px}a:hover{color:#123f78}
:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.skip{position:absolute;left:-9999px;top:0}.skip:focus{left:16px;top:8px;background:#fff;padding:8px 12px;z-index:10}
header.top{border-bottom:1px solid var(--rule)}header.top div{max-width:1000px;margin:0 auto;padding:14px 16px;font-size:.92rem;color:var(--muted)}
main{max-width:1000px;margin:0 auto;padding:24px 16px 80px}
.measure{max-width:680px;min-width:0}
p,li,code{overflow-wrap:anywhere}
.table-wrap,.fig-scroll,pre{max-width:100%}
h1{font-size:clamp(1.6rem,3.6vw,2.3rem);line-height:1.2;margin:.6em 0 .4em;letter-spacing:-.01em;text-wrap:balance}
h2{font-size:1.3rem;line-height:1.3;margin:2.2em 0 .6em;text-wrap:balance}h3{font-size:1.05rem;margin:1.6em 0 .4em}
p{text-wrap:pretty}.lede{font-size:1.12rem;color:var(--ink)}.muted{color:var(--muted)}
figure{margin:1.6em 0;max-width:960px}figure img{width:100%;height:auto;display:block;border:1px solid var(--rule);background:#fcfcfb}
.fig-scroll{overflow-x:auto;max-width:960px}.fig-scroll img{min-width:620px;width:100%;height:auto;display:block}
.fig-scroll:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
figcaption{font-size:.9rem;color:var(--muted);margin-top:.5em;max-width:680px}
.facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px 24px;margin:1.4em 0;padding:16px 0;border-top:1px solid var(--rule);border-bottom:1px solid var(--rule)}
.facts div{font-size:.92rem}.facts b{display:block;font-size:.8rem;font-weight:600;color:var(--muted);text-transform:none;letter-spacing:.01em}
.result{font-size:1.05rem;border-left:3px solid var(--accent);padding:4px 0 4px 14px;margin:1.2em 0}
.table-wrap{overflow-x:auto;max-width:960px;margin:1em 0}table{border-collapse:collapse;font-size:.88rem;min-width:560px}
th,td{border-bottom:1px solid var(--rule);padding:6px 10px;text-align:left;vertical-align:top}th{font-weight:600;color:var(--muted);font-size:.82rem}
td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
code,pre{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.86em;background:var(--plate)}code{padding:0 3px}
pre{padding:12px;overflow-x:auto;max-width:960px}
ul.files{padding-left:1.1em}ul.files li{margin:.3em 0}
footer{max-width:1000px;margin:0 auto;padding:24px 16px 48px;border-top:1px solid var(--rule);font-size:.88rem;color:var(--muted)}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
"""


def build_assets(log=print) -> None:
    assets = SITE / "assets"
    (assets / "figures").mkdir(parents=True, exist_ok=True)
    for p in (C.RESULTS / "figures").glob("*.svg"):
        shutil.copy2(p, assets / "figures" / p.name)
    (assets / "site.css").write_text(CSS)
    dl = SITE / "downloads"
    dl.mkdir(parents=True, exist_ok=True)
    copies = {
        C.RESULTS / "tables" / "system_metrics.csv": "system-metrics.csv",
        C.RESULTS / "tables" / "rejection_rule.csv": "rejection-rule.csv",
        C.RESULTS / "tables" / "paired_comparisons.csv": "paired-comparisons.csv",
        C.RESULTS / "tables" / "sensitivity.csv": "sensitivity-analyses.csv",
        C.RESULTS / "tables" / "per_class.csv": "per-class.csv",
        C.RESULTS / "tables" / "tableau_system_metrics.csv": "tableau-system-metrics.csv",
        C.RESULTS / "evidence_model_audit_results.xlsx": "evidence-model-audit-results.xlsx",
        C.ROOT / "manuscript" / "manuscript.docx": "manuscript-draft.docx",
        C.ROOT / "manuscript" / "supplement.html": "supplementary-material.html",
        C.EVIDENCE / "claims.json": "claims.json",
    }
    for src, name in copies.items():
        if src.exists():
            shutil.copy2(src, dl / name)
    from .manuscript import to_html
    dd = (C.DOCS / "data_dictionary.md").read_text()
    (dl / "data-dictionary.html").write_text(to_html(dd, "Data dictionary"))
    (dl / "tableau-spec.html").write_text(to_html((C.DOCS / "tableau_spec.md").read_text(), "Tableau specification"))
    build_public_viewer(dl / "prediction-viewer.html", log)
    readme = ("Downloads for the evidence model audit.\n\n"
              "system-metrics.csv          one row per system and context: counts, rates, intervals\n"
              "rejection-rule.csv          quote-validity rule versus all answers and random rejection\n"
              "paired-comparisons.csv      paired article-bootstrap differences\n"
              "sensitivity-analyses.csv    fixed sensitivity analyses S0 to S5\n"
              "per-class.csv               per-class precision, recall, and quote-valid errors\n"
              "tableau-system-metrics.csv  long format for Tableau (see tableau-spec.html)\n"
              "evidence-model-audit-results.xlsx  the same aggregates with a definitions sheet\n"
              "data-dictionary.html        source-to-analysis fields and metric definitions\n"
              "tableau-spec.html           Tableau import and interaction specification\n"
              "prediction-viewer.html      examples from CC BY or CC0 articles with highlighted quotes\n"
              "manuscript-draft.docx       manuscript draft generated from the results\n"
              "supplementary-material.html supplementary tables and methods detail\n"
              "claims.json                 headline numbers mapped to output files and keys\n"
              "evidence-model-audit-source.zip  code, tests, configuration, predictions, results\n")
    (dl / "README.txt").write_text(readme)
    log("site assets and downloads written")


def build_public_viewer(path: Path, log=print, per_type: int = 6) -> None:
    from .evaluate import load_predictions, primary_mask
    from .licenses import public_ok
    from .run import predictions_path, test_items_frame
    from .viewer import FAILURE_ORDER, failure_type, records, render_page

    fz = json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())
    lic = json.loads((C.DATA_INTERIM / "licenses_europepmc.json").read_text())
    df = pd.read_csv(C.RESULTS / "scored" / "test" / f"qwen3-1.7b__retrieved__{fz['variant']}__{fz['decoding']}.csv")
    df = df[primary_mask(df)].copy()
    df = df[df.pmcid.map(lambda p: public_ok(lic.get(f"PMC{p}", {})))]
    df["ft"] = [failure_type(r) for r in df.to_dict("records")]
    picks = []
    for ft in FAILURE_ORDER:
        sub = df[df.ft == ft].sort_values("prompt_id")
        # spread over articles: at most one prompt per article per type
        picks.append(sub.drop_duplicates("pmcid").head(per_type))
    sel = pd.concat(picks)
    raw = load_predictions(predictions_path("test", "qwen3-1.7b", "retrieved", fz["variant"], fz["decoding"]))
    recs = records(sel, "retrieved", "test", test_items_frame(), licenses=lic, public=True, raw=raw)
    path.write_text(render_page(recs, "Prediction viewer: Qwen3-1.7B, retrieved passages",
                                "Examples from the frozen test run, chosen by fixed rule (the lowest prompt IDs per failure "
                                "type, one per article) among articles whose license is CC BY or CC0. Passages are trimmed "
                                "to those holding the returned quote or benchmark evidence."), encoding="utf-8")
    log(f"public viewer: {len(recs)} examples")


def _tpl(name: str, vals: dict) -> str:
    return fill((TEMPLATES / name).read_text(encoding="utf-8"), vals)


def build_pages(src: dict, log=print) -> None:
    vals = values()
    vals["source_zip_mb"] = f"{src['bytes'] / 1e6:.1f}"
    vals["source_zip_files"] = f"{src['files']:,}"
    import hashlib as _h
    vals["css"] = "assets/site.css?v=" + _h.sha256(CSS.encode()).hexdigest()[:10]
    sec = TEMPLATES / "sections"
    vals["site_models_paragraph"] = fill((sec / "site_models_paragraph.html").read_text(encoding="utf-8"), vals) \
        if (sec / "site_models_paragraph.html").exists() else ""
    for f in ("headline_sentence.html", "results_section.html", "rejection_section.html", "fig1_alt.txt"):
        vals[f.split(".")[0]] = fill((sec / f).read_text(encoding="utf-8"), vals).strip()
    (SITE / "index.html").write_text(_tpl("index_template.html", vals), encoding="utf-8")
    report_md = (C.ROOT / "manuscript" / "manuscript.md").read_text(encoding="utf-8")
    supp_md = (C.ROOT / "manuscript" / "supplement.md").read_text(encoding="utf-8") if (C.ROOT / "manuscript" / "supplement.md").exists() else ""
    import markdown
    body = markdown.markdown(escape_prompt_placeholders(report_md + "\n\n" + supp_md), extensions=["tables", "toc", "attr_list"])
    body = body.replace('src="../results/figures/', 'src="assets/figures/')
    body = re.sub(r"<table>", '<div class="table-wrap" tabindex="0" role="region" aria-label="Table, scrollable">'
                  '<table>', body).replace("</table>", "</table></div>")
    body = re.sub(r'<p>(<img [^>]*alt="([^"]*)"[^>]*>)</p>',
                  lambda m: f'<div class="fig-scroll" tabindex="0" role="region" aria-label="{m.group(2)}, scrollable">'
                            f'{m.group(1)}</div>', body)
    vals["report_body"] = body
    (SITE / "report.html").write_text(_tpl("report_template.html", vals), encoding="utf-8")
    log("index.html and report.html written")


def build_handoff(src: dict, files: list[dict], log=print) -> None:
    HANDOFF.mkdir(parents=True, exist_ok=True)
    res = json.loads((C.RESULTS / "analysis" / "results.json").read_text())
    claims = json.loads((C.EVIDENCE / "claims.json").read_text())
    val = json.loads((C.RESULTS / "validation" / "validation.json").read_text()) if (C.RESULTS / "validation" / "validation.json").exists() else {}
    status = json.loads((C.CONFIG_DIR / "status.json").read_text()) if (C.CONFIG_DIR / "status.json").exists() else {}
    crp = C.RESULTS / "validation" / "clean_room.json"
    cr = json.loads(crp.read_text()) if crp.exists() else None
    if cr is not None and cr.get("archive_sha256") != src["sha256"]:
        log("clean-room record is for a different source archive; rerun the clean-room check on this archive")
        cr = {**cr, "matches_shipped_archive": False}
    elif cr is not None:
        cr = {**cr, "matches_shipped_archive": True}
    findings = []
    for c in claims["claims"]:
        if c["id"] in ("headline_qvwr", "task_success_primary", "quote_exists_primary", "accuracy_answered_primary",
                       "filter_error_primary", "unfiltered_error_primary", "random_error_primary", "filter_coverage_primary") \
                or c["id"].startswith(("qvwr::", "evidence_recall_any::")):
            findings.append({k: c.get(k) for k in ("id", "statement", "estimate", "numerator", "denominator", "ci_low",
                                                   "ci_high", "value", "scope", "system", "run_id", "json_key")}
                            | {"evidence_path": c["output_path"]})
    man = json.loads((C.ROOT / "source_manifest.json").read_text())
    rec = {
        "slug": SLUG,
        "title": status.get("title", "Clinical Evidence Models: Citation Validity versus Answer Correctness"),
        "featured": True,
        "summary": status.get("summary", ""),
        "computational_completion_status": status.get("computational_completion_status"),
        "manuscript_status": status.get("manuscript_status"),
        "unresolved_prerequisites": status.get("unresolved_prerequisites", []),
        "data_versions": {"evidence_inference_repo_commit": man["sources"][0]["commit"],
                          "evidence_inference_release": man["sources"][0]["release"],
                          "official_tarball_sha256": man["sources"][1]["sha256"],
                          "models": {m["name"]: m["revision"] for m in man["models"]}},
        "key_limitations": status.get("key_limitations", []),
        "entry_page": f"site/projects/{SLUG}/index.html", "report_page": f"site/projects/{SLUG}/report.html",
        "source_archive": src,
        "executed_commands": status.get("executed_commands", []),
        "measured_findings": findings,
        "counts_kept_separate": claims["counts_kept_separate"],
        "validation_summary": {**{k: val.get(k) for k in ("source_reconciliation", "r_crosscheck") if k in val},
                               "clean_room": cr},
        "public_files": files, "public_file_count": len(files), "public_bytes_total": sum(f["bytes"] for f in files),
        "generated_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    (HANDOFF / f"{SLUG}.json").write_text(json.dumps(rec, indent=2, default=str))
    for name in (f"{SLUG}-validation.md", "verified_results.md"):
        tpl = TEMPLATES / name.replace(".md", "_template.md")
        if tpl.exists():
            vals = values()
            vals["bundle_public_files"] = str(len(files))
            vals["clean_room_archive_sha256"] = (cr or {}).get("archive_sha256", "not recorded")
            vals["clean_room_status"] = ("matches the shipped source archive" if (cr or {}).get("matches_shipped_archive")
                                         else "was run on an earlier build and must be repeated")
            hm = TEMPLATES / "sections" / "handoff_models_lines.md"
            vals["handoff_models_lines"] = fill(hm.read_text(encoding="utf-8"), vals).strip() if hm.exists() else ""
            (HANDOFF / name).write_text(fill(tpl.read_text(encoding="utf-8"), vals), encoding="utf-8")
    log("handoff files written")
