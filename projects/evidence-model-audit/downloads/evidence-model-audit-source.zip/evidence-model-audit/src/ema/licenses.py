"""Per-article license lookup through the Europe PMC REST API (cached).

The legacy NCBI PMC OA web service URL (www.ncbi.nlm.nih.gov/pmc/utils/oa/oa.fcgi)
returned HTTP 404 on 2026-10-07, so licenses are taken from Europe PMC's
`license` field. Only articles reported as CC BY or CC0 are used for public
excerpts, always with attribution.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone

import requests

from . import config as C

API = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
PUBLIC_OK = {"cc by", "cc0"}


def cache_path():
    return C.DATA_INTERIM / "licenses_europepmc.json"


def lookup(pmcids: list[int], batch: int = 20) -> dict[str, dict]:
    path = cache_path()
    cache = json.loads(path.read_text()) if path.exists() else {}
    todo = [p for p in sorted(set(pmcids)) if f"PMC{p}" not in cache]
    for i in range(0, len(todo), batch):
        ids = todo[i:i + batch]
        q = " OR ".join(f"PMCID:PMC{p}" for p in ids)
        for attempt in range(3):
            try:
                r = requests.get(API, params={"query": q, "resultType": "core", "format": "json", "pageSize": 100},
                                 timeout=60)
                r.raise_for_status()
                if "json" not in r.headers.get("content-type", ""):
                    raise ValueError("non-JSON response")
                res = r.json()["resultList"]["result"]
                break
            except Exception:
                time.sleep(2 * (attempt + 1))
        else:
            continue
        got = {x.get("pmcid"): x for x in res if x.get("pmcid")}
        for p in ids:
            x = got.get(f"PMC{p}")
            cache[f"PMC{p}"] = {
                "license": (x or {}).get("license"), "is_open_access": (x or {}).get("isOpenAccess"),
                "title": (x or {}).get("title"), "journal": ((x or {}).get("journalInfo") or {}).get("journal", {}).get("title"),
                "year": (x or {}).get("pubYear"), "authors": (x or {}).get("authorString"), "doi": (x or {}).get("doi"),
                "pmid": (x or {}).get("pmid"), "found": x is not None,
                "checked_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "source": API,
            }
        path.write_text(json.dumps(cache, indent=1))
        time.sleep(0.3)
    return {f"PMC{p}": cache.get(f"PMC{p}", {"found": False}) for p in pmcids}


def public_ok(rec: dict) -> bool:
    return bool(rec and rec.get("license") and rec["license"].lower() in PUBLIC_OK)
