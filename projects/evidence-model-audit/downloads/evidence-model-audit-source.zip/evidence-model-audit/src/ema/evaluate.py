"""Join predictions with contexts and benchmark labels, and compute the separated metrics."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C
from .data import article_text
from .run import build_contexts, predictions_path
from .score import score_answer

NO_ANSWER = "no answer"


def load_predictions(path: Path) -> dict[int, dict]:
    out = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").split("\n"):
            if line.strip():
                r = json.loads(line)
                # the most recent record for a prompt wins (errors are retried by later runs)
                out[int(r["prompt_id"])] = r
    return out


def score_frame(frame: pd.DataFrame, split_tag: str, model: str, condition: str, variant: str, decoding: str,
                preds: dict[int, dict] | None = None, completed_pmcids: set[int] | None = None) -> pd.DataFrame:
    """One row per item whose context is available. Items without a recorded response inside the
    completed articles are counted as runtime failures ("not_run")."""
    ctxs = build_contexts(frame, condition, split_tag)
    if preds is None:
        preds = load_predictions(predictions_path(split_tag, model, condition, variant, decoding))
    rows = []
    art_cache: dict[int, str] = {}
    for r in frame.itertuples():
        pid = int(r.prompt_id)
        ctx = ctxs[pid]
        if not ctx.available:
            continue
        if completed_pmcids is not None and int(r.pmcid) not in completed_pmcids:
            continue
        rec = preds.get(pid)
        passages = [{"pid": p.pid, "start": p.start, "end": p.end, "text": p.text} for p in ctx.passages]
        gold_spans = [tuple(s) for s in json.loads(r.gold_spans)]
        if r.pmcid not in art_cache:
            art_cache[r.pmcid] = article_text(int(r.pmcid))
        raw = rec.get("response") if rec else None
        fin = rec.get("finish_reason") if rec else None
        sc = score_answer(raw, fin, passages, r.gold_label if r.label_status == "unanimous" else None, gold_spans,
                          art_cache[r.pmcid])
        d = sc.to_dict()
        if rec is None:
            d["parse_status"] = "not_run"
        elif rec.get("error"):
            d["parse_status"] = "runtime_error"
            d["parse_detail"] = rec["error"][:200]
        accepted = json.loads(r.accepted_labels)
        d.update({
            "prompt_id": pid, "pmcid": int(r.pmcid), "model": model, "condition": condition, "variant": variant,
            "decoding": decoding, "split": split_tag, "gold_label": r.gold_label, "label_status": r.label_status,
            "accepted_labels": "|".join(accepted), "flag": r.flag,
            "label_matches_any_accepted": (d["label_pred"] in accepted) if d["answered"] else None,
            "n_passages": len(passages), "context_tokens": ctx.context_tokens, "truncated": ctx.truncated,
            "ctx_gold_any": _ctx_gold_overlap(passages, gold_spans), "finish_reason": fin,
            "prompt_tokens": rec.get("prompt_tokens") if rec else None,
            "gen_tokens": rec.get("gen_tokens") if rec else None,
            "latency_s": rec.get("latency_s") if rec else None,
            "run_id": rec.get("run_id") if rec else None, "cache_key": rec.get("cache_key") if rec else None,
            "outcome": r.outcome, "intervention": r.intervention, "comparator": r.comparator,
        })
        rows.append(d)
    df = pd.DataFrame(rows)
    if len(df):
        df["pred_or_none"] = np.where(df.answered, df.label_pred, NO_ANSWER)
    return df


def _ctx_gold_overlap(passages, gold_spans) -> bool | None:
    if not gold_spans:
        return None
    return any(max(0, min(p["end"], e) - max(p["start"], s)) > 0 for p in passages for s, e in gold_spans)


def primary_mask(df: pd.DataFrame, include_disagreement: bool = False, exclude_flagged: bool = False) -> pd.Series:
    m = df.label_status.eq("unanimous")
    if include_disagreement:
        m = m | df.label_status.eq("accepted_disagreement")
    if exclude_flagged:
        m = m & ~df.flag.isin(["questionable", "malformed"])
    return m


def headline_counts(df: pd.DataFrame, quote_col: str = "quote_exists", correct_col: str = "label_correct") -> dict:
    """Quote-valid wrong-direction counts on a scored frame restricted to the analysis population."""
    qv = df[df.answered & df[quote_col].astype(bool) & df[correct_col].notna()]
    wrong = qv[~qv[correct_col].astype(bool)]
    return {"denominator": int(len(qv)), "numerator": int(len(wrong)),
            "rate": (len(wrong) / len(qv)) if len(qv) else None}


def summarize(df: pd.DataFrame) -> dict:
    n = len(df)
    if n == 0:
        return {"items": 0}
    ans = df[df.answered]
    out = {
        "items": n,
        "articles": int(df.pmcid.nunique()),
        "parse_valid": int((df.parse_status == "valid").sum()),
        "parse_status_counts": df.parse_status.value_counts().to_dict(),
        "abstained": int(df.abstained.sum()),
        "answered": int(len(ans)),
        "coverage": len(ans) / n,
        "quote_exists_strict": int(ans.quote_exists_strict.sum()),
        "quote_exists": int(ans.quote_exists.sum()),
        "quote_too_short": int(ans.quote_too_short.sum()),
        "locator_valid": int(ans.locator_valid.sum()),
        "gold_overlap": int(ans.gold_overlap.fillna(False).astype(bool).sum()),
        "gold_overlap_evaluable": int(ans.gold_overlap.notna().sum()),
        "mean_gold_token_f1": float(ans.gold_token_f1.dropna().mean()) if ans.gold_token_f1.notna().any() else None,
        "label_correct": int(ans.label_correct.fillna(False).astype(bool).sum()),
        "accuracy_answered": float(ans.label_correct.astype(float).mean()) if len(ans) else None,
        "task_success": int(df.task_success.sum()),
        "task_success_rate": float(df.task_success.mean()),
        "length_stops": int((df.finish_reason == "length").sum()),
    }
    out["invalid_output_rate"] = 1 - out["parse_valid"] / n
    out["qvwr"] = headline_counts(df)
    out.update(macro_f1(df))
    return out


def macro_f1(df: pd.DataFrame) -> dict:
    """Macro-F1 over the three benchmark classes; abstentions and invalid outputs count as a wrong 'no answer'."""
    res = {}
    f1s = []
    for lab in C.LABELS:
        tp = int(((df.pred_or_none == lab) & (df.gold_label == lab)).sum())
        fp = int(((df.pred_or_none == lab) & (df.gold_label != lab)).sum())
        fn = int(((df.pred_or_none != lab) & (df.gold_label == lab)).sum())
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        f = 2 * p * r / (p + r) if p + r else 0.0
        res[f"precision::{lab}"], res[f"recall::{lab}"], res[f"f1::{lab}"] = p, r, f
        res[f"support::{lab}"] = tp + fn
        f1s.append(f)
    res["macro_f1"] = float(np.mean(f1s))
    return res
