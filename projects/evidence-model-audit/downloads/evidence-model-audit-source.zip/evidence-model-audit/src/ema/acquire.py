"""Acquire stage: pinned corpus checkout, official release reference, and model snapshots.

Downloads are cached. A file already present with the expected checksum is not
fetched again. Responses are checked for content type so that an HTML error
page cannot be saved as a data file.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

from . import config as C


def sha256(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def _download(url: str, dest: Path, expected_sha: str | None, allowed_types: tuple[str, ...], retries: int = 3) -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and expected_sha and sha256(dest) == expected_sha:
        return {"url": url, "path": str(dest.relative_to(C.ROOT)), "status": "cached", "sha256": expected_sha,
                "bytes": dest.stat().st_size}
    last = None
    for attempt in range(1, retries + 1):
        try:
            with requests.get(url, stream=True, timeout=120) as r:
                r.raise_for_status()
                ctype = r.headers.get("content-type", "").split(";")[0].strip()
                if not any(ctype.startswith(t) for t in allowed_types):
                    raise ValueError(f"unexpected content type {ctype!r} for {url}")
                tmp = dest.with_suffix(dest.suffix + ".part")
                with open(tmp, "wb") as f:
                    for b in r.iter_content(1 << 20):
                        f.write(b)
                tmp.replace(dest)
            got = sha256(dest)
            if expected_sha and got != expected_sha:
                raise ValueError(f"checksum mismatch for {url}: {got}")
            return {"url": url, "path": str(dest.relative_to(C.ROOT)), "status": "downloaded", "sha256": got,
                    "bytes": dest.stat().st_size, "content_type": ctype,
                    "last_modified": r.headers.get("last-modified")}
        except Exception as e:  # bounded retry, then surface the error
            last = e
            time.sleep(2 * attempt)
    raise RuntimeError(f"download failed after {retries} attempts: {url}: {last}")


def safe_extract(tar_path: Path, out_dir: Path) -> int:
    with tarfile.open(tar_path) as t:
        members = t.getmembers()
        for m in members:
            parts = m.name.split("/")
            if m.name.startswith("/") or ".." in parts or m.issym() or m.islnk() or not (m.isfile() or m.isdir()):
                raise ValueError(f"unsafe archive member {m.name!r}")
        t.extractall(out_dir, filter="data")
    return len(members)


def acquire_corpus() -> dict:
    repo = C.EI_REPO_DIR
    if not (repo / ".git").exists():
        subprocess.run(["git", "clone", "-q", C.EI_REPO_URL, str(repo)], check=True)
    subprocess.run(["git", "-C", str(repo), "checkout", "-q", C.EI_REPO_COMMIT], check=True)
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], check=True, capture_output=True,
                          text=True).stdout.strip()
    if head != C.EI_REPO_COMMIT:
        raise RuntimeError(f"repo at {head}, expected {C.EI_REPO_COMMIT}")
    tar = _download(C.EI_OFFICIAL_TARBALL_URL, C.EI_OFFICIAL_DIR / "v2.0.tar.gz", C.EI_OFFICIAL_TARBALL_SHA256,
                    ("application/gzip", "application/x-gzip", "application/octet-stream"))
    ans = _download(C.EI_OFFICIAL_ANSWERS_URL, C.EI_OFFICIAL_DIR / "test_annotations_merged.csv",
                    C.EI_OFFICIAL_ANSWERS_SHA256, ("text/csv",))
    if not (C.EI_OFFICIAL_DIR / "v2.0" / "annotations_merged.csv").exists():
        safe_extract(C.EI_OFFICIAL_DIR / "v2.0.tar.gz", C.EI_OFFICIAL_DIR / "v2.0")
    return {"repo_commit": head, "official_tarball": tar, "official_test_answers": ans}


def acquire_models(names: list[str] | None = None) -> dict:
    from huggingface_hub import snapshot_download

    out = {}
    for name in names or list(C.MODELS):
        spec = C.MODELS[name]
        local = C.MODELS_DIR / name
        path = snapshot_download(repo_id=spec["repo_id"], revision=spec["revision"], local_dir=str(local),
                                 token=False)
        files = sorted(p for p in Path(path).rglob("*") if p.is_file() and ".cache" not in p.parts)
        out[name] = {
            "repo_id": spec["repo_id"], "revision": spec["revision"], "local_dir": str(local.relative_to(C.ROOT))
            if local.is_relative_to(C.ROOT) else str(local),
            "files": {p.name: {"bytes": p.stat().st_size, "sha256": sha256(p)} for p in files},
            "acquired_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
    return out


def main(models: bool = True, corpus: bool = True, model_names: list[str] | None = None) -> dict:
    rec = {}
    if corpus:
        rec["corpus"] = acquire_corpus()
    if models:
        rec["models"] = acquire_models(model_names)
    out = C.DATA_INTERIM / "acquire_record.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    prev = json.loads(out.read_text()) if out.exists() else {}
    prev.update(rec)
    out.write_text(json.dumps(prev, indent=2))
    return rec


if __name__ == "__main__":
    import sys
    main(models="--no-models" not in sys.argv, corpus="--no-corpus" not in sys.argv)
