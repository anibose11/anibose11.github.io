"""Fast demo on bundled permitted examples.

`ema demo` runs real local inference (default Qwen3-0.6B on CPU, or any acquired
model) on the small set of examples in examples/demo_items.json, scores the
answers with the study scorer, prints a table, and writes demo_output.html.
These examples are a software demonstration; they are not evidence that the
full study ran.

`ema demo --cached` loads the study's saved outputs for the same examples
(examples/demo_cached_outputs.json) and renders them without loading a model.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from types import SimpleNamespace

from . import config as C
from .contexts import Context, Passage
from .prompts import messages
from .score import score_answer
from .viewer import failure_type, render_page, _mark

EXAMPLES = C.ROOT / "examples"


def load_items() -> list[dict]:
    return json.loads((EXAMPLES / "demo_items.json").read_text(encoding="utf-8"))["items"]


def _ctx(it: dict) -> Context:
    ps = [Passage(p["pid"], p["start"], p["end"], p["text"], p.get("section", "")) for p in it["passages"]]
    return Context(it["prompt_id"], it["pmcid"], it["condition"], ps, 1024, it.get("context_tokens", 0), False)


def _score(it: dict, raw: str | None, finish: str | None):
    passages = [{"pid": p["pid"], "start": p["start"], "end": p["end"], "text": p["text"]} for p in it["passages"]]
    # article text is not bundled; overlap is computed from the passages, which carry article offsets
    art = None
    sc = score_answer(raw, finish, passages, it["gold_label"], [tuple(s) for s in it["gold_spans"]], art)
    return sc


def _record(it, sc, raw, model_label_source):
    d = sc.to_dict()
    spans_q = [(d["quote_start"], d["quote_end"])] if d["quote_start"] is not None else []
    spans_g = [tuple(s) for s in it["gold_spans"]]
    return {
        "prompt_id": it["prompt_id"], "pmcid": it["pmcid"],
        "question": {k: it[k] for k in ("intervention", "comparator", "outcome")},
        "model_label": d["label_pred"] if d["answered"] else ("cannot determine" if d["abstained"] else "no valid answer"),
        "benchmark_label": it["gold_label"], "failure_type": failure_type(d), "quote": d["quote"],
        "quote_exists": d["quote_exists"], "locator_valid": d["locator_valid"], "gold_overlap": d["gold_overlap"],
        "passages": [{"pid": p["pid"], "html": _mark(p["text"], p["start"], spans_q, spans_g), "start": p["start"],
                      "end": p["end"], "section": p.get("section", "")} for p in it["passages"]],
        "passages_shown": "all supplied passages for this example (CC BY or CC0 source)",
        "license": it["license"], "attribution": it["attribution"], "raw_response": raw,
        "source_of_output": model_label_source,
    }


def main(cached: bool = False, model: str = "qwen3-0.6b", device: str = "cpu", log=print) -> Path:
    items = load_items()
    recs = []
    if cached:
        saved = json.loads((EXAMPLES / "demo_cached_outputs.json").read_text(encoding="utf-8"))
        for it in items:
            o = saved["outputs"][str(it["prompt_id"])]
            sc = _score(it, o["response"], o["finish_reason"])
            recs.append(_record(it, sc, o["response"], f"saved study output ({saved['model']}, run {saved['run_id']})"))
        title = f"Demo (cached study outputs): {saved['model']}"
    else:
        from .infer import GenConfig, LocalModel

        fz = json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())
        gen = GenConfig(max_new_tokens=fz["gen"]["max_new_tokens"], device=device, dtype="float32")
        m = LocalModel(model, gen)
        for it in items:
            row = SimpleNamespace(**{k: it[k] for k in ("intervention", "comparator", "outcome")})
            rendered = m.render(messages(row, _ctx(it), fz["variant"]))
            t = time.perf_counter()
            g = m.generate([rendered])[0]
            sc = _score(it, g["response"], g["finish_reason"])
            recs.append(_record(it, sc, g["response"], f"live local inference ({model}, {device}, "
                                                       f"{time.perf_counter() - t:.1f} s)"))
        title = f"Demo (live local inference): {model} on {device}"
    log(f"{'prompt':>7}  {'model label':<26} {'benchmark label':<26} {'quote exists':<12} failure type")
    for r in recs:
        log(f"{r['prompt_id']:>7}  {r['model_label']:<26} {r['benchmark_label']:<26} {str(r['quote_exists']):<12} {r['failure_type']}")
    out = C.ROOT / "demo_output.html"
    out.write_text(render_page(recs, title, "Bundled demonstration examples from CC BY or CC0 articles. These show "
                                            "the software working; they are not the study results."), encoding="utf-8")
    log(f"wrote {out}")
    return out
