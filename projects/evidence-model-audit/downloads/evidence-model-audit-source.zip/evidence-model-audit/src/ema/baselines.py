"""Majority-class reference and TF-IDF + logistic regression baselines (one per context condition).

Trained on training-split prompts only; hyperparameters chosen on validation
macro-F1. Each baseline answer is written as a structured answer so that the
same scorer applies: the evidence quote is the highest-ranked supplied passage
(BM25 against the question), which exists in the source by construction.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score

from . import config as C
from . import contexts as X
from .data import load_processed
from .prompts import display_text
from .run import build_contexts, predictions_path

GRID_C = (0.1, 1.0, 10.0)
GRID_W = (None, "balanced")


def ico_text(r) -> str:
    return f"intervention {r.intervention} comparator {r.comparator} outcome {r.outcome}"


def ctx_text(ctx: X.Context) -> str:
    return " ".join(display_text(p.text) for p in ctx.passages)


def top_passage(ctx: X.Context, r, bm25: X.BM25):
    if not ctx.passages:
        return None
    q = X.tokenize(X.query_text(r.intervention, r.comparator, r.outcome))
    scores = [(bm25.score(q, X.tokenize(p.text)), -k) for k, p in enumerate(ctx.passages)]
    k = -max(scores)[1]
    return ctx.passages[k]


def _frame_texts(frame, ctxs):
    keep = [r for r in frame.itertuples() if ctxs[int(r.prompt_id)].available]
    return keep, [ctx_text(ctxs[int(r.prompt_id)]) for r in keep], [ico_text(r) for r in keep]


def train_condition(condition: str, prompts: pd.DataFrame, log=print) -> dict:
    tr = prompts[(prompts.split == "train") & prompts.eligible_primary]
    va = prompts[(prompts.split == "validation") & prompts.eligible_primary]
    ctr = build_contexts(tr, condition, "train")
    cva = build_contexts(va, condition, "validation")
    rtr, ttr, itr = _frame_texts(tr, ctr)
    rva, tva, iva = _frame_texts(va, cva)
    ytr = np.array([r.gold_label for r in rtr])
    yva = np.array([r.gold_label for r in rva])
    v_ctx = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=200000, sublinear_tf=True)
    v_ico = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=50000, sublinear_tf=True)
    Xtr = sp.hstack([v_ctx.fit_transform(ttr), v_ico.fit_transform(itr)]).tocsr()
    Xva = sp.hstack([v_ctx.transform(tva), v_ico.transform(iva)]).tocsr()
    grid = []
    for c in GRID_C:
        for w in GRID_W:
            m = LogisticRegression(C=c, class_weight=w, max_iter=3000)
            m.fit(Xtr, ytr)
            f = f1_score(yva, m.predict(Xva), average="macro")
            grid.append({"C": c, "class_weight": w or "none", "val_macro_f1": float(f)})
            log(f"  {condition} C={c} w={w} val macro-F1 {f:.4f}")
    best = max(grid, key=lambda g: (g["val_macro_f1"], -g["C"]))
    m = LogisticRegression(C=best["C"], class_weight=None if best["class_weight"] == "none" else "balanced",
                           max_iter=3000).fit(Xtr, ytr)
    return {"model": m, "v_ctx": v_ctx, "v_ico": v_ico, "grid": grid, "best": best,
            "n_train": len(rtr), "n_val": len(rva), "train_label_counts": pd.Series(ytr).value_counts().to_dict()}


def predict_records(fitted: dict | None, frame: pd.DataFrame, condition: str, split_tag: str, name: str,
                    majority_label: str | None = None) -> list[dict]:
    ctxs = build_contexts(frame, condition, split_tag)
    bm = X.load_bm25()
    keep, texts, icos = _frame_texts(frame, ctxs)
    if fitted is not None:
        Xm = sp.hstack([fitted["v_ctx"].transform(texts), fitted["v_ico"].transform(icos)]).tocsr()
        preds = fitted["model"].predict(Xm)
    else:
        preds = [majority_label] * len(keep)
    recs = []
    for r, y in zip(keep, preds):
        tp = top_passage(ctxs[int(r.prompt_id)], r, bm)
        ans = {"label": str(y), "evidence_quote": display_text(tp.text) if tp else "",
               "passage_id": tp.pid if tp else None}
        recs.append({"prompt_id": int(r.prompt_id), "pmcid": int(r.pmcid), "condition": condition, "variant": "baseline",
                     "split": split_tag, "model": name, "response": json.dumps(ans), "finish_reason": "eos",
                     "error": None, "run_id": "baselines", "cache_key": None})
    return recs


def write_records(recs: list[dict], split_tag: str, name: str, condition: str) -> None:
    p = predictions_path(split_tag, name, condition, "baseline", "deterministic")
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        for r in recs:
            f.write(json.dumps(r) + "\n")


def main(log=print) -> dict:
    from .run import test_items_frame

    _, prompts = load_processed()
    tr = prompts[(prompts.split == "train") & prompts.eligible_primary]
    majority = tr.gold_label.value_counts().idxmax()
    test_items = test_items_frame(prompts)
    va = prompts[(prompts.split == "validation") & prompts.eligible_primary]
    summary = {"majority_label": majority, "train_label_counts": tr.gold_label.value_counts().to_dict(),
               "utc": datetime.now(timezone.utc).isoformat(timespec="seconds"), "conditions": {}}
    for cond in ("retrieved", "abstract", "oracle"):
        log(f"baseline: {cond}")
        fit = train_condition(cond, prompts, log)
        for frame, tag in ((va, "validation"), (test_items, "test")):
            write_records(predict_records(fit, frame, cond, tag, "tfidf-lr"), tag, "tfidf-lr", cond)
            write_records(predict_records(None, frame, cond, tag, "majority", majority), tag, "majority", cond)
        summary["conditions"][cond] = {k: v for k, v in fit.items() if k in ("grid", "best", "n_train", "n_val",
                                                                            "train_label_counts")}
    out = C.RESULTS / "baselines_summary.json"
    out.write_text(json.dumps(summary, indent=2, default=str))
    return summary


if __name__ == "__main__":
    main()
