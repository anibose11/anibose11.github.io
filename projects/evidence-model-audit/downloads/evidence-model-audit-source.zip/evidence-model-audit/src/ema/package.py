"""Package stage: allowlisted source archive, static site pages, handoff files, and the outer bundle."""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import config as C

SLUG = "evidence-model-audit"
BUNDLE_NAME = "03-evidence-model-audit-PROJECT-BUNDLE.zip"
SITE = C.ROOT / "site" / "projects" / SLUG
HANDOFF = C.ROOT / "handoff"
FIXED_TIME = (2026, 10, 7, 0, 0, 0)  # stable ZIP member timestamps

ALLOW = [
    "README.md", "LICENSE", "NOTICE.md", "CITATION.cff", "pyproject.toml", "requirements.lock.txt",
    "source_manifest.json", "config/frozen_config.json", "config/status.json",
    "src/ema/*.py", "tests/*.py", "scripts/crosscheck.R", "scripts/preflight_timing.py", "scripts/check_site.py",
    "scripts/clean_room_check.sh",
    "docs/*.md", "docs/prior_art.csv", "docs/research/search_log.csv", "docs/research/inclusion_decisions.csv",
    "docs/research/references.bib", "docs/research/verified_references.json",
    "manuscript/*.md", "manuscript/*.docx", "manuscript/*.html",
    "site_templates/*.html", "site_templates/*.md", "site_templates/sections/*.html", "site_templates/sections/*.md",
    "site_templates/sections/*.txt",
    "evidence/claims.json", "evidence/plan_timestamps.jsonl",
    "examples/*.json",
    "results/analysis/results.json", "results/analysis/error_taxonomy_items.csv",
    "results/tables/*.csv", "results/figures/*.svg", "results/figures/*.csv",
    "results/dev/dev_decisions.json", "results/runs/*.json", "results/preflight/timing.jsonl",
    "results/validation/validation.json", "results/baselines_summary.json", "results/evidence_model_audit_results.xlsx",
    "results/predictions/test/*.jsonl", "results/predictions/dev/*.jsonl", "results/predictions/dev-cpu/*.jsonl",
    "results/predictions/validation/*.jsonl",
    "results/scored/test/*.csv", "results/scored/primary__*.csv",
    "results/contexts_public/*.jsonl",
    "data/processed/build_qa.json", "data/interim/near_duplicate_pairs.csv", "data/interim/licenses_europepmc.json",
]
DENY_PARTS = {".venv", "models", ".local", "handoff", "deliverables", "site", "__pycache__", ".git", "raw"}


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def public_contexts() -> None:
    """Context files without article text: passage IDs, offsets, sections, scores, budgets."""
    out = C.RESULTS / "contexts_public"
    out.mkdir(parents=True, exist_ok=True)
    for p in sorted((C.RESULTS / "contexts").glob("test_*.jsonl")) + sorted((C.RESULTS / "contexts").glob("dev_*.jsonl")):
        with open(out / p.name, "w", encoding="utf-8") as f:
            for line in p.read_text(encoding="utf-8").split("\n"):
                if not line.strip():
                    continue
                d = json.loads(line)
                for ps in d["passages"]:
                    ps.pop("text", None)
                f.write(json.dumps(d) + "\n")


def collect() -> list[Path]:
    files = set()
    for pat in ALLOW:
        for p in C.ROOT.glob(pat):
            if p.is_file() and not (set(p.relative_to(C.ROOT).parts) & DENY_PARTS):
                files.add(p)
    return sorted(files)


def write_zip(path: Path, members: list[tuple[Path, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src, arc in sorted(members, key=lambda x: x[1]):
            zi = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, src.read_bytes())
    with zipfile.ZipFile(path) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"corrupt member {bad} in {path}")


SECRET_PATTERNS = [r"/Users/[A-Za-z0-9_.-]+", r"/home/[A-Za-z0-9_.-]+/", r"hf_[A-Za-z0-9]{30,}", r"sk-ant-[A-Za-z0-9-]{10,}",
                   "OPENAI" + "_API_KEY", r"-----BEGIN [A-Z ]*PRIVATE KEY-----"]


def check_no_secrets(files: list[Path]) -> list[str]:
    import re

    hits = []
    for p in files:
        if p.suffix in (".xlsx", ".docx"):
            continue
        t = p.read_text(encoding="utf-8", errors="ignore")
        for pat in SECRET_PATTERNS:
            m = re.search(pat, t)
            if m:
                hits.append(f"{p.relative_to(C.ROOT)}: {m.group(0)[:40]}")
    return hits


def build_source_zip(log=print) -> dict:
    public_contexts()
    files = collect()
    leaks = check_no_secrets(files)
    if leaks:
        raise RuntimeError("possible machine-specific path or secret in: " + "; ".join(leaks[:10]))
    dest = SITE / "downloads" / f"{SLUG}-source.zip"
    write_zip(dest, [(p, f"{SLUG}/{p.relative_to(C.ROOT)}") for p in files])
    log(f"source zip: {len(files)} files, {dest.stat().st_size:,} bytes")
    return {"path": str(dest.relative_to(C.ROOT)), "files": len(files), "bytes": dest.stat().st_size, "sha256": sha256(dest)}


def public_files() -> list[dict]:
    out = []
    for p in sorted(SITE.rglob("*")):
        if p.is_file():
            out.append({"path": str(p.relative_to(C.ROOT)), "bytes": p.stat().st_size, "sha256": sha256(p)})
    return out


def build_bundle(log=print) -> dict:
    members = [(p, str(p.relative_to(C.ROOT))) for p in sorted(SITE.rglob("*")) if p.is_file()]
    members += [(p, str(p.relative_to(C.ROOT))) for p in sorted(HANDOFF.glob("*")) if p.is_file()]
    dest = C.ROOT / "deliverables" / BUNDLE_NAME
    write_zip(dest, members)
    rec = {"path": str(dest), "bytes": dest.stat().st_size, "sha256": sha256(dest), "members": len(members),
           "utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    (C.ROOT / "deliverables" / (BUNDLE_NAME + ".sha256")).write_text(f"{rec['sha256']}  {BUNDLE_NAME}\n")
    log(f"bundle: {dest} {rec['bytes']:,} bytes sha256 {rec['sha256']}")
    return rec


def main(log=print) -> dict:
    from . import sitepages

    SITE.mkdir(parents=True, exist_ok=True)
    sitepages.build_assets(log)          # figures, css, downloads other than the source zip
    src = build_source_zip(log)          # needs manuscript and results in place
    sitepages.build_pages(src, log)      # index.html and report.html
    sitepages.build_handoff(src, public_files(), log)
    rec = build_bundle(log)
    from . import submission
    rec["submission_package"] = submission.main(log)
    return rec
