"""Inference prompts and the structured answer schema.

Two prompt variants were written before any model output was seen. Variant
selection uses development articles only (docs/analysis_plan.md, section 6).
"""
from __future__ import annotations

import re

from . import config as C

ANSWER_SCHEMA = {
    "type": "object",
    "properties": {
        "label": {"type": "string", "enum": C.LABELS + [C.ABSTAIN]},
        "evidence_quote": {"type": "string"},
        "passage_id": {"type": ["string", "null"]},
    },
    "required": ["label", "evidence_quote", "passage_id"],
    "additionalProperties": False,
}

QUESTION_TEMPLATE = ("With respect to {outcome}, characterize the reported difference between patients receiving "
                     "{intervention} and those receiving {comparator}.")

LABEL_GUIDE = (
    'Label meanings. "significantly increased": the report says the outcome was statistically significantly higher '
    'with the intervention than with the comparator. "significantly decreased": statistically significantly lower. '
    '"no significant difference": the report says the difference was not statistically significant. '
    '"cannot determine": the passages do not report this comparison. Increased and decreased describe the value '
    'of the outcome measure, not whether the result is good or bad for patients.'
)

FORMAT_GUIDE = (
    "Answer with one JSON object and nothing else, using exactly these keys:\n"
    '{"label": "significantly increased" | "significantly decreased" | "no significant difference" | "cannot determine", '
    '"evidence_quote": "<text copied character for character from one passage>", '
    '"passage_id": "<the passage ID the quote comes from, for example P2>"}\n'
    'If the label is "cannot determine", use "" for evidence_quote and null for passage_id. '
    "Copy the quote exactly; do not paraphrase, shorten words, or join text from different passages."
)

# A short invented example (not taken from the corpus) used only by variant v2.
EXAMPLE = (
    "Example.\nQuestion: With respect to pain score at 24 hours, characterize the reported difference between "
    "patients receiving drug A and those receiving placebo.\n"
    "[P1] Pain scores at 24 hours were lower with drug A than with placebo (2.1 versus 3.4, P = 0.01).\n"
    "[P2] Nausea occurred in 12% and 10% of patients, respectively (P = 0.62).\n"
    'Answer: {"label": "significantly decreased", "evidence_quote": "Pain scores at 24 hours were lower with drug A '
    'than with placebo (2.1 versus 3.4, P = 0.01).", "passage_id": "P1"}'
)

VARIANTS = ("v1", "v2")


def display_text(text: str) -> str:
    """What the model sees: the passage with hard line wraps and runs of spaces collapsed."""
    return re.sub(r"\s+", " ", text).strip()


def format_passages(ctx) -> str:
    return "\n".join(f"[{p.pid}] {display_text(p.text)}" for p in ctx.passages)


def user_message(row, ctx, variant: str = "v1") -> str:
    q = QUESTION_TEMPLATE.format(outcome=row.outcome.strip(), intervention=row.intervention.strip(),
                                 comparator=row.comparator.strip())
    parts = ["You are reading passages from a report of a clinical trial and answering one question about it.",
             f"Question: {q}", "Passages:\n" + format_passages(ctx), LABEL_GUIDE, FORMAT_GUIDE]
    if variant == "v2":
        parts.insert(-1, EXAMPLE)
    elif variant != "v1":
        raise ValueError(variant)
    return "\n\n".join(parts)


def messages(row, ctx, variant: str = "v1") -> list[dict]:
    return [{"role": "user", "content": user_message(row, ctx, variant)}]
