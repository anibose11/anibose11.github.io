"""Build stage: corpus ingestion, label contract, split checks, and QA tables.

Label contract (docs/analysis_plan.md, section 3):
  * An annotation row is "accepted" when the verifier accepted both its label
    and its reasoning (Valid Label = 1 and Valid Reasoning = 1), its evidence
    string is non-empty, and its label is not "invalid prompt". This is the
    filter used by the corpus authors' own preprocessing code.
  * Label Code is authoritative. The Label string is checked against it.
  * A prompt's benchmark label is the label shared by all of its accepted
    annotations. Prompts whose accepted annotations disagree keep every label
    and are reported separately instead of being collapsed to a consensus.
  * Benchmark evidence is the set of all accepted evidence spans.
"""
from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import config as C

SPLITS = ("train", "validation", "test")


def _ids(split: str) -> list[int]:
    txt = (C.EI_ANN_DIR / "splits" / f"{split}_article_ids.txt").read_text()
    return [int(x) for x in txt.split()]


def split_map() -> dict[int, str]:
    out: dict[int, str] = {}
    for s in SPLITS:
        for i in _ids(s):
            if i in out:
                raise ValueError(f"article {i} appears in {out[i]} and {s}")
            out[i] = s
    return out


def article_text(pmcid: int) -> str | None:
    """Plain-text rendering of an article, or None when the file is missing or empty."""
    p = C.EI_ANN_DIR / "txt_files" / f"PMC{pmcid}.txt"
    if not p.exists():
        return None
    t = p.read_text(encoding="utf-8")
    return t if t.strip() else None


def article_abstract(pmcid: int) -> str | None:
    p = C.EI_ANN_DIR / "abstracts" / f"PMC{pmcid}.abst"
    if not p.exists():
        return None
    return p.read_text(encoding="utf-8")


ABSTRACT_MIN_CHARS = 200


HEADER_LINE_RE = re.compile(r"^[ \t]*(ABSTRACT|BODY)[^\n]*:[ \t]*$", re.M)
ABSTRACT_HEADER_RE = re.compile(r"^[ \t]*ABSTRACT[^\n]*:[ \t]*$", re.M)
BODY_HEADER_RE = re.compile(r"^[ \t]*BODY[^\n]*:[ \t]*$", re.M)


def abstract_region(text: str) -> tuple[int, str]:
    """Return (end_offset, status) for the title-plus-abstract region of an article text.

    The region runs from offset 0 to the first BODY header line that follows an
    ABSTRACT header line. Offsets are therefore identical to full-text offsets.
    """
    if text is None:
        return 0, "no_text"
    a = ABSTRACT_HEADER_RE.search(text)
    if not a:
        return 0, "no_abstract_header"
    b = BODY_HEADER_RE.search(text, a.end())
    if not b:
        return 0, "no_body_header_after_abstract"
    end = len(text[: b.start()].rstrip())
    content = HEADER_LINE_RE.sub("", text[:end])
    content = re.sub(r"^TITLE:", "", content)
    if len(re.sub(r"\s+", " ", content).strip()) < ABSTRACT_MIN_CHARS:
        return 0, "abstract_too_short"
    return end, "ok"


def parse_title(text: str | None) -> str | None:
    if text is None:
        return None
    m = re.match(r"TITLE:[ \t]*([^\n]*)\n?([^\n]*)", text)
    if not m:
        return None
    t = m.group(1).strip() or m.group(2).strip()
    if not t or re.match(r"[ \t]*(ABSTRACT|BODY)[^\n]*:", t):
        return None
    return t


def load_prompts() -> pd.DataFrame:
    p = pd.read_csv(C.EI_ANN_DIR / "prompts_merged.csv", dtype={"Outcome": str, "Intervention": str, "Comparator": str})
    p = p.rename(columns={"PromptID": "prompt_id", "PMCID": "pmcid", "Outcome": "outcome",
                          "Intervention": "intervention", "Comparator": "comparator"})
    for c in ("outcome", "intervention", "comparator"):
        p[c] = p[c].fillna("")
    return p


def load_annotations() -> pd.DataFrame:
    a = pd.read_csv(C.EI_ANN_DIR / "annotations_merged.csv", dtype={"Annotations": str, "Label": str})
    a = a.drop(columns=[c for c in a.columns if c.startswith("Unnamed")])
    a = a.rename(columns={"UserID": "user_id", "PromptID": "prompt_id", "PMCID": "pmcid", "Valid Label": "valid_label",
                          "Valid Reasoning": "valid_reasoning", "Label": "label_str", "Annotations": "evidence_text",
                          "Label Code": "label_code", "In Abstract": "in_abstract", "Evidence Start": "ev_start",
                          "Evidence End": "ev_end"})
    a["row_id"] = np.arange(len(a))
    a["evidence_text"] = a["evidence_text"].fillna("")
    a["label"] = a["label_code"].map(C.LABEL_CODE)
    a["label_str_matches_code"] = a.apply(lambda r: str(r.label_str).strip() == r.label
                                          or (r.label_code == 1 and str(r.label_str).strip() == "significantly increase"),
                                          axis=1)
    a["accepted"] = (a.valid_label.astype(bool) & a.valid_reasoning.astype(bool)
                     & a.evidence_text.str.strip().str.len().gt(0) & (a.label_str != "invalid prompt"))
    return a


def _norm_ws(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


def locate_span(text: str, ev_text: str, start: int, end: int) -> tuple[int, int, str]:
    """Return (start, end, status) of an annotation's evidence in the article text.

    Offsets are treated as half-open [start, end). This was established on the
    training split: exclusive ends reproduce the annotation string exactly for
    about nine in ten rows, inclusive ends never do (docs/data_provenance.md).
    Annotation strings sometimes carry HTML entities (for example &lt;), so they
    are also compared after unescaping. A span that cannot be found is returned
    as (-1, -1) and is not used as benchmark evidence.
    """
    import html as _html

    if text is None:
        return -1, -1, "no_text"
    has_off = start >= 0 and end > start
    if has_off and text[start:end] == ev_text:
        return start, end, "exact"
    if has_off and _norm_ws(text[start:end]) == _norm_ws(ev_text):
        return start, end, "exact_ws"
    un = _html.unescape(ev_text)
    if has_off and un != ev_text and _norm_ws(text[start:end]) == _norm_ws(un):
        return start, end, "exact_after_unescape"
    for cand, tag in ((ev_text, ""), (un, "_unescaped")):
        if not cand:
            continue
        hits = [m.start() for m in re.finditer(re.escape(cand), text)]
        if len(hits) == 1:
            base = "recovered_unique" if has_off else "recovered_from_missing"
            return hits[0], hits[0] + len(cand), base + tag
        if len(hits) > 1:
            best = min(hits, key=lambda h: abs(h - start)) if has_off else hits[0]
            return best, best + len(cand), "recovered_ambiguous" + tag
    if has_off:
        return -1, -1, "offset_text_mismatch"
    return -1, -1, "unavailable"


def near_duplicates(arts: pd.DataFrame, texts: dict, threshold: float = 0.9) -> pd.DataFrame:
    """Pairs of articles whose opening 4,000 characters have TF-IDF cosine >= threshold."""
    from sklearn.feature_extraction.text import TfidfVectorizer

    sub = arts[arts.has_text].reset_index(drop=True)
    docs = [texts[p][:4000] for p in sub.pmcid]
    X = TfidfVectorizer(min_df=2, sublinear_tf=True).fit_transform(docs)
    S = (X @ X.T).tocoo()
    m = (S.row < S.col) & (S.data >= threshold)
    out = pd.DataFrame({"pmcid_a": sub.pmcid.values[S.row[m]], "pmcid_b": sub.pmcid.values[S.col[m]],
                        "cosine": S.data[m].round(4)})
    out["split_a"] = out.pmcid_a.map(sub.set_index("pmcid").split)
    out["split_b"] = out.pmcid_b.map(sub.set_index("pmcid").split)
    return out.sort_values("cosine", ascending=False)


def label_contract(accepted_codes: list[int], n_annotations: int) -> tuple[str, str | None]:
    """(label_status, benchmark label) for one prompt from its accepted Label Codes."""
    codes = sorted(set(int(c) for c in accepted_codes))
    if n_annotations == 0:
        return "no_annotation", None
    if not codes:
        return "no_accepted_annotation", None
    if len(codes) == 1:
        return "unanimous", C.LABEL_CODE[codes[0]]
    return "accepted_disagreement", None


@dataclass
class BuildOutputs:
    articles: pd.DataFrame
    prompts: pd.DataFrame
    annotations: pd.DataFrame
    qa: dict


def build() -> BuildOutputs:
    smap = split_map()
    P = load_prompts()
    A = load_annotations()
    qa: dict = {"source": {"repo_commit": C.EI_REPO_COMMIT}}

    # ---------------- articles ----------------
    pmcids = sorted(set(smap) | set(P.pmcid) | set(A.pmcid))
    rows = []
    texts: dict[int, str | None] = {}
    for pid in pmcids:
        t = article_text(pid)
        ab = article_abstract(pid)
        texts[pid] = t
        title = parse_title(t)
        ab_end, ab_status = abstract_region(t)
        rows.append({
            "pmcid": pid, "split": smap.get(pid, "unassigned"), "has_text": t is not None,
            "text_file_empty": bool((C.EI_ANN_DIR / "txt_files" / f"PMC{pid}.txt").exists() and t is None),
            "text_chars": len(t) if t is not None else 0,
            "text_sha256": hashlib.sha256(t.encode("utf-8")).hexdigest() if t is not None else None,
            "has_abstract": ab is not None, "abstract_chars": len(ab) if ab is not None else 0,
            "abst_file_contains_body": bool(ab is not None and re.search(r"(?m)^BODY", ab)),
            "abstract_end": ab_end, "abstract_status": ab_status,
            "title": title,
        })
    arts = pd.DataFrame(rows)

    # duplicate and overlap checks across splits
    dup_text = arts[arts.has_text].groupby("text_sha256").filter(lambda g: len(g) > 1)
    norm_title = arts.title.fillna("").str.lower().str.replace(r"[^a-z0-9]+", " ", regex=True).str.strip()
    arts["title_norm"] = norm_title
    dup_title = arts[(norm_title != "")].groupby("title_norm").filter(lambda g: len(g) > 1)
    canon = lambda x: re.sub(r"\s+", " ", HEADER_LINE_RE.sub("", re.sub(r"(?m)^TITLE[:.][ \t]*", "", x))).strip()
    cmp_n = cmp_eq = 0
    for r in arts.itertuples():
        if r.has_abstract and not r.abst_file_contains_body and r.abstract_status == "ok":
            ab = article_abstract(r.pmcid)
            ab = re.sub(r"(?m)^(ABSTRACT[^\n]*)\.[ \t]*$", r"\1:", ab)  # the abstract files end headers with '.'
            cmp_n += 1
            cmp_eq += canon(ab) == canon(texts[r.pmcid][: r.abstract_end])
    nd = near_duplicates(arts, texts)
    nd.to_csv(C.DATA_INTERIM / "near_duplicate_pairs.csv", index=False) if C.DATA_INTERIM.exists() else None
    qa["articles"] = {
        "near_duplicate_pairs_cos_ge_0_9": int(len(nd)),
        "near_duplicate_pairs_cross_split": int((nd.split_a != nd.split_b).sum()),
        "split_files": {s: len(_ids(s)) for s in SPLITS},
        "split_article_overlap": 0,  # split_map raises on overlap
        "articles_total": int(len(arts)),
        "articles_unassigned_with_prompts": int(arts[(arts.split == "unassigned") & arts.pmcid.isin(P.pmcid)].shape[0]),
        "missing_text_in_splits": int((~arts.has_text & (arts.split != "unassigned")).sum()),
        "empty_text_files": sorted(int(x) for x in arts[arts.text_file_empty].pmcid),
        "texts_under_500_chars": sorted(int(x) for x in arts[arts.has_text & (arts.text_chars < 500)].pmcid),
        "abst_files": int(arts.has_abstract.sum()),
        "abst_files_containing_body_sections": int(arts.abst_file_contains_body.sum()),
        "abstract_only_files_with_delimitable_region": cmp_n,
        "abstract_only_files_matching_region_after_normalization": cmp_eq,
        "abstract_region_status_by_split": {s: g.abstract_status.value_counts().to_dict()
                                            for s, g in arts.groupby("split")},
        "duplicate_text_groups": int(dup_text.text_sha256.nunique()),
        "duplicate_text_cross_split_groups": int(dup_text.groupby("text_sha256").split.nunique().gt(1).sum()),
        "duplicate_title_groups": int(dup_title.title_norm.nunique()),
        "duplicate_title_cross_split_groups": int(dup_title.groupby("title_norm").split.nunique().gt(1).sum()),
        "duplicate_title_cross_split_pmcids": sorted(int(x) for x in dup_title[dup_title.groupby("title_norm").split
                                                     .transform("nunique").gt(1)].pmcid),
    }

    # ---------------- annotations: locate spans ----------------
    loc = [locate_span(texts.get(r.pmcid), r.evidence_text, int(r.ev_start), int(r.ev_end)) for r in A.itertuples()]
    A["span_start"], A["span_end"], A["span_status"] = zip(*loc)
    ab_len = arts.set_index("pmcid").abstract_end
    A["span_in_abstract"] = A.apply(lambda r: bool(r.span_start >= 0 and r.span_end <= ab_len.get(r.pmcid, 0)), axis=1)
    A["split"] = A.pmcid.map(smap).fillna("unassigned")
    qa["annotations"] = {
        "rows": int(len(A)), "accepted_rows": int(A.accepted.sum()),
        "label_str_code_mismatch": int((~A.label_str_matches_code).sum()),
        "label_str_variant_significantly_increase": int((A.label_str == "significantly increase").sum()),
        "span_status_accepted": A[A.accepted].span_status.value_counts().to_dict(),
        "span_status_by_split_accepted": {s: g.span_status.value_counts().to_dict()
                                          for s, g in A[A.accepted].groupby("split")},
    }

    # ---------------- prompts: label contract ----------------
    flagged = {**{i: "incorrect" for i in C.FLAGGED_INCORRECT}, **{i: "questionable" for i in C.FLAGGED_QUESTIONABLE},
               **{i: "malformed" for i in C.FLAGGED_MALFORMED}}
    acc = A[A.accepted]
    g_all = A.groupby("prompt_id")
    g_acc = acc.groupby("prompt_id")
    prow = []
    for r in P.itertuples():
        n_all = len(g_all.groups.get(r.prompt_id, []))
        sub = acc.loc[g_acc.groups[r.prompt_id]] if r.prompt_id in g_acc.groups else acc.iloc[0:0]
        codes = sorted(set(sub.label_code))
        status, gold = label_contract(codes, n_all)
        spans = [(int(s), int(e)) for s, e, st in zip(sub.span_start, sub.span_end, sub.span_status) if s >= 0]
        ico_ok = all(str(x).strip() for x in (r.intervention, r.comparator, r.outcome))
        prow.append({
            "prompt_id": r.prompt_id, "pmcid": r.pmcid, "split": smap.get(r.pmcid, "unassigned"),
            "intervention": r.intervention, "comparator": r.comparator, "outcome": r.outcome, "ico_nonempty": ico_ok,
            "n_annotations": n_all, "n_accepted": int(len(sub)), "n_accepted_users": int(sub.user_id.nunique()),
            "label_status": status, "gold_label": gold,
            "accepted_labels": json.dumps([C.LABEL_CODE[c] for c in codes]),
            "gold_spans": json.dumps(sorted(set(spans))), "n_gold_spans": len(set(spans)),
            "gold_in_abstract": bool(sub.span_in_abstract.any()) if len(sub) else False,
            "annotator_says_in_abstract": bool(sub.in_abstract.astype(bool).any()) if len(sub) else False,
            "flag": flagged.get(r.prompt_id, ""),
        })
    prompts = pd.DataFrame(prow)
    prompts["eligible_primary"] = (prompts.label_status.eq("unanimous") & prompts.ico_nonempty
                                   & prompts.flag.ne("incorrect") & prompts.split.ne("unassigned")
                                   & prompts.pmcid.map(arts.set_index("pmcid").has_text))
    qa["prompts"] = {
        "rows": int(len(prompts)),
        "by_split": prompts.split.value_counts().to_dict(),
        "label_status_by_split": {s: g.label_status.value_counts().to_dict() for s, g in prompts.groupby("split")},
        "flag_by_split": {s: g.flag.value_counts().to_dict() for s, g in prompts.groupby("split")},
        "ico_empty": int((~prompts.ico_nonempty).sum()),
        "eligible_primary_by_split": prompts[prompts.eligible_primary].split.value_counts().to_dict(),
        "articles_with_prompts_by_split": prompts.groupby("split").pmcid.nunique().to_dict(),
        "test_articles_with_prompts_abstract_ok": int(arts[arts.pmcid.isin(prompts[prompts.split == "test"].pmcid)
                                                          & arts.abstract_status.eq("ok")].shape[0]),
    }
    return BuildOutputs(arts, prompts, A, qa)


def write(out: BuildOutputs) -> None:
    C.DATA_PROCESSED.mkdir(parents=True, exist_ok=True)
    out.articles.to_csv(C.DATA_PROCESSED / "articles.csv", index=False)
    out.prompts.to_csv(C.DATA_PROCESSED / "prompts.csv", index=False)
    out.annotations.to_csv(C.DATA_PROCESSED / "annotations.csv", index=False)
    (C.DATA_PROCESSED / "build_qa.json").write_text(json.dumps(out.qa, indent=2, default=int))


def load_processed() -> tuple[pd.DataFrame, pd.DataFrame]:
    arts = pd.read_csv(C.DATA_PROCESSED / "articles.csv")
    prompts = pd.read_csv(C.DATA_PROCESSED / "prompts.csv", keep_default_na=False,
                          dtype={"intervention": str, "comparator": str, "outcome": str, "flag": str})
    prompts["gold_label"] = prompts.gold_label.replace("", None)
    return arts, prompts
