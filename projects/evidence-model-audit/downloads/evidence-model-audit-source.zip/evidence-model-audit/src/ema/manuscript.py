"""Result-generated manuscript.

The prose lives in manuscript/manuscript_template.md with {{name}} placeholders.
values() computes every placeholder from results/analysis/results.json and the
build QA file, so each number in the manuscript comes from an analysis output.
An unknown placeholder stops the build.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from . import config as C

MS = C.ROOT / "manuscript"
LABEL = {"qwen3-1.7b": "Qwen3-1.7B", "qwen3-0.6b": "Qwen3-0.6B", "qwen3-4b-instruct-2507": "Qwen3-4B-Instruct-2507",
         "tfidf-lr": "TF-IDF + LR", "majority": "Majority class"}
CONDS = ("retrieved", "abstract", "oracle")


def pct(x, d=1) -> str:
    return "undefined" if x is None else f"{x * 100:.{d}f}%"


def ci(e: dict, d=1) -> str:
    if e.get("estimate") is None:
        return "undefined"
    return f"{pct(e['estimate'], d)}, 95% CI {pct(e['ci_low'], d)} to {pct(e['ci_high'], d)}"


def frac(e: dict) -> str:
    return f"{e['numerator']:,} of {e['denominator']:,}"


def num(n) -> str:
    return f"{n:,}"


def values() -> dict[str, str]:
    res = json.loads((C.RESULTS / "analysis" / "results.json").read_text())
    qa = json.loads((C.DATA_PROCESSED / "build_qa.json").read_text())
    v: dict[str, str] = {}
    for key, e in res["systems"].items():
        tag = key.replace("::", "_").replace("-", "").replace(".", "")
        m, s = e["metrics"], e["metrics"]["summary"]
        h = m["headline_qvwr"]
        v[f"{tag}_qvwr"] = ci(h)
        v[f"{tag}_qvwr_frac"] = frac(h) if h["denominator"] else "0 of 0"
        v[f"{tag}_qvwr_numerator"] = num(h["numerator"])
        v[f"{tag}_qvwr_denominator"] = num(h["denominator"])
        v[f"{tag}_qvwr_pct"] = pct(h["estimate"])
        v[f"{tag}_qvwr_ci"] = (f"95% CI {pct(h['ci_low'])} to {pct(h['ci_high'])}" if h["estimate"] is not None else "undefined")
        nq_den = s["answered"] - h["denominator"]
        nq_num = (s["answered"] - s["label_correct"]) - h["numerator"]
        v[f"{tag}_noquote_wrong"] = f"{nq_num:,} of {nq_den:,}, {pct(nq_num / nq_den)}" if nq_den else "0 of 0"
        v[f"{tag}_success_ci"] = f"95% CI {pct(m['task_success']['ci_low'])} to {pct(m['task_success']['ci_high'])}"
        v[f"{tag}_items"] = num(e["items_primary"])
        v[f"{tag}_answered"] = num(s["answered"])
        v[f"{tag}_articles"] = num(e["articles"])
        v[f"{tag}_success"] = ci(m["task_success"])
        v[f"{tag}_success_frac"] = frac(m["task_success"])
        v[f"{tag}_success_pct"] = pct(m["task_success"]["estimate"])
        v[f"{tag}_parse"] = ci(m["parse_validity"])
        v[f"{tag}_parse_frac"] = frac(m["parse_validity"])
        v[f"{tag}_abstain_frac"] = frac(m["abstention"])
        inv = s["items"] - s["parse_valid"]
        v[f"{tag}_invalid_frac"] = f"{inv:,} of {s['items']:,}"
        v[f"{tag}_invalid_pct"] = pct(inv / s["items"]) if s["items"] else "undefined"
        v[f"{tag}_abstain_pct"] = pct(m["abstention"]["estimate"])
        v[f"{tag}_coverage_pct"] = pct(m["coverage"]["estimate"])
        v[f"{tag}_quote"] = ci(m["quote_exists_among_answered"])
        v[f"{tag}_quote_frac"] = frac(m["quote_exists_among_answered"])
        v[f"{tag}_quote_pct"] = pct(m["quote_exists_among_answered"]["estimate"])
        v[f"{tag}_quote_numerator"] = num(m["quote_exists_among_answered"]["numerator"])
        v[f"{tag}_strict_frac"] = frac(m["quote_exists_strict_among_answered"])
        v[f"{tag}_locator_frac"] = frac(m["locator_valid_among_answered"])
        v[f"{tag}_locator_pct"] = pct(m["locator_valid_among_answered"]["estimate"])
        v[f"{tag}_gold_frac"] = frac(m["gold_overlap_among_answered"])
        v[f"{tag}_gold_pct"] = pct(m["gold_overlap_among_answered"]["estimate"])
        v[f"{tag}_acc"] = ci(m["accuracy_among_answered"])
        v[f"{tag}_acc_frac"] = frac(m["accuracy_among_answered"])
        v[f"{tag}_acc_pct"] = pct(m["accuracy_among_answered"]["estimate"])
        v[f"{tag}_macro_f1"] = f"{s['macro_f1']:.3f}"
        v[f"{tag}_length_stops"] = num(s["length_stops"])
        r = e["rejection"]
        v[f"{tag}_rej_unf"] = pct(r["unfiltered"]["retained_error"])
        v[f"{tag}_rej_flt"] = pct(r["quote_filter"]["retained_error"])
        v[f"{tag}_rej_cov_unf"] = pct(r["unfiltered"]["coverage"])
        v[f"{tag}_rej_cov_flt"] = pct(r["quote_filter"]["coverage"])
        v[f"{tag}_rej_lost"] = pct(r["quote_filter"]["lost_coverage"])
        v[f"{tag}_rej_rejected"] = num(r["quote_filter"]["rejected_answers"])
        v[f"{tag}_rej_rejected_correct"] = num(r["quote_filter"]["rejected_correct"])
        v[f"{tag}_rej_rand"] = pct(r["random_same_coverage"]["mean_error"])
        v[f"{tag}_rej_rand_range"] = (f"{pct(r['random_same_coverage']['p2_5'])} to {pct(r['random_same_coverage']['p97_5'])}"
                                      if r["random_same_coverage"]["p2_5"] is not None else "undefined")
        v[f"{tag}_rej_share_le"] = pct(r["random_same_coverage"]["share_draws_error_le_filter"])
        d = r["filter_minus_unfiltered_error"]
        v[f"{tag}_rej_diff"] = (f"{d['diff'] * 100:+.1f} percentage points (95% CI {d['ci_low'] * 100:+.1f} to "
                                f"{d['ci_high'] * 100:+.1f})") if d["diff"] is not None else "undefined"
        v[f"{tag}_rej_diff_bare"] = (f"{d['diff'] * 100:+.1f} percentage points, 95% CI {d['ci_low'] * 100:+.1f} to "
                                     f"{d['ci_high'] * 100:+.1f}") if d["diff"] is not None else "undefined"
        for lab, short in (("significantly increased", "inc"), ("no significant difference", "ns"),
                           ("significantly decreased", "dec")):
            g, p = h["per_gold_class"][lab], h["per_pred_class"][lab]
            v[f"{tag}_qv_gold_{short}"] = f"{g['numerator']} of {g['denominator']}"
            v[f"{tag}_qv_pred_{short}"] = f"{p['numerator']} of {p['denominator']}"
        v[f"{tag}_ns_recall"] = f"{s['recall::no significant difference']:.3f}"
        v[f"{tag}_ns_precision"] = f"{s['precision::no significant difference']:.3f}"
        cm = h.get("confusion") or {}  # predicted label -> benchmark label, quote-valid answers
        v[f"{tag}_rev_inc_for_dec"] = num(cm.get("significantly increased", {}).get("significantly decreased", 0))
        v[f"{tag}_rev_dec_for_inc"] = num(cm.get("significantly decreased", {}).get("significantly increased", 0))
        v[f"{tag}_inc_recall"] = f"{s['recall::significantly increased']:.3f}"
        v[f"{tag}_inc_precision"] = f"{s['precision::significantly increased']:.3f}"
        v[f"{tag}_token_f1"] = f"{s['mean_gold_token_f1']:.3f}" if s.get("mean_gold_token_f1") is not None else "undefined"
        for sname, sh in (e.get("sensitivity") or {}).items():
            v[f"{tag}_{sname.split('_')[0]}"] = (f"{frac(sh)} ({ci(sh)})" if sh["denominator"] else "undefined (no quote-valid answers)")
    for label, c in res.get("comparisons", {}).items():
        tag = re.sub(r"[^a-z0-9]+", "_", label.lower()).strip("_")
        for met in ("task_success_f", "correct_all", "quote_valid_all"):
            d = c[met]
            if d.get("diff") is None:
                continue
            v[f"cmp_{tag}_{met}"] = (f"{d['diff'] * 100:+.1f} percentage points, 95% CI {d['ci_low'] * 100:+.1f} to "
                                     f"{d['ci_high'] * 100:+.1f}, {num(d['n_prompts'])} prompts")
    for cond, e in res.get("evidence_recall_at_budget", {}).items():
        v[f"recall_{cond}_any"] = ci(e["any_overlap"])
        v[f"recall_{cond}_any_frac"] = frac(e["any_overlap"])
        v[f"recall_{cond}_full"] = ci(e["full_cover"])
        v[f"recall_{cond}_median_tokens"] = f"{e['median_context_tokens']:.0f}"
        v[f"recall_{cond}_prompts"] = num(e["prompts"])
    rc = res.get("risk_coverage")
    if rc:
        v["rc_aurc"] = f"{rc['aurc']:.3f}"
        v["rc_aurc_random"] = f"{rc['aurc_random_expected']:.3f}"
        v["rc_dev_items"] = num(rc["dev_items"])
        v["table_rc_coefficients"] = _md(["Term", "Coefficient"], [["Intercept", f"{rc['intercept']:+.3f}"]] + [
            [RC_FEATURES.get(f, f), f"{rc['coefficients'][f]:+.3f}"] for f in rc["features"]], ["l", "r"])
    dv = res.get("development", {})
    if dv:
        v["dev_articles"] = num(dv["dev_articles"])
        v["dev_prompts"] = num(dv["dev_prompts"])
        for k in ("v1_greedy", "v2_greedy"):
            if k in dv:
                v[f"dev_{k}_success"] = pct(dv[k]["task_success_rate"])
        sk = f"{dv['variant']}_sampled"
        if sk in dv:
            v["dev_sampled_invalid"] = pct(dv[sk]["invalid_output_rate"])
            v["dev_greedy_invalid"] = pct(dv[f"{dv['variant']}_greedy"]["invalid_output_rate"])
        for k in ("v1_greedy", "v2_greedy"):
            if k in dv:
                q = dv[k]["qvwr"]
                v[f"dev_{k}_qvwr"] = f"{pct(q['rate'])} ({q['numerator']} of {q['denominator']})"
                v[f"dev_{k}_acc"] = pct(dv[k]["accuracy_answered"])
                v[f"dev_{k}_quote"] = num(dv[k]["quote_exists"])
        v["dev_variant"] = dv["variant"]
        v["dev_decoding"] = dv["decoding"]
        v["dev_parity"] = f"{dv['parity']['same_label']} of {dv['parity']['n']}"
        v["dev_parity_identical"] = f"{dv['parity']['identical_response']} of {dv['parity']['n']}"
    bt = res.get("baselines_training", {})
    for cond, c in bt.get("conditions", {}).items():
        v[f"bl_{cond}_val_f1"] = f"{c['best']['val_macro_f1']:.3f}"
        v[f"bl_{cond}_C"] = str(c["best"]["C"])
        v[f"bl_{cond}_w"] = c["best"]["class_weight"]
    for m, r in res.get("runs", {}).items():
        tag = m.replace("-", "").replace(".", "")
        v[f"run_{tag}_articles"] = num(r["articles_completed"])
        v[f"run_{tag}_hours"] = f"{r['elapsed_s'] / 3600:.1f}"
        v[f"run_{tag}_calls"] = num(sum(r["items"].values()))
    p = qa["prompts"]
    v["n_prompts_all"] = num(p["rows"])
    v["n_test_prompts"] = num(p["by_split"]["test"])
    v["n_test_articles"] = num(p["articles_with_prompts_by_split"]["test"])
    v["n_test_eligible"] = num(p["eligible_primary_by_split"]["test"])
    v["test_abstract_ok"] = num(p.get("test_articles_with_prompts_abstract_ok", 0))
    v["n_train_eligible"] = num(p["eligible_primary_by_split"]["train"])
    v["n_val_eligible"] = num(p["eligible_primary_by_split"]["validation"])
    v["n_ann_rows"] = num(qa["annotations"]["rows"])
    for st, n in qa["annotations"]["span_status_accepted"].items():
        v[f"span_{st}"] = num(n)
    for st in ("exact", "exact_ws", "exact_after_unescape", "recovered_unique", "recovered_unique_unescaped",
               "recovered_from_missing", "recovered_from_missing_unescaped", "recovered_ambiguous", "offset_text_mismatch",
               "unavailable", "no_text"):
        v.setdefault(f"span_{st}", "0")
    v["abst_cmp_n"] = num(qa["articles"]["abstract_only_files_with_delimitable_region"])
    v["abst_cmp_eq"] = num(qa["articles"]["abstract_only_files_matching_region_after_normalization"])
    v["n_ann_accepted"] = num(qa["annotations"]["accepted_rows"])
    tstat = p["label_status_by_split"]["test"]
    v["n_test_unanimous"] = num(tstat.get("unanimous", 0))
    v["n_test_disagree"] = num(tstat.get("accepted_disagreement", 0))
    v["n_test_noaccepted"] = num(tstat.get("no_accepted_annotation", 0))
    v["n_test_noann"] = num(tstat.get("no_annotation", 0))
    trailing = total_calls = 0
    for pf in sorted((C.RESULTS / "predictions" / "test").glob("qwen*.jsonl")):
        for line in pf.read_text(encoding="utf-8").split("\n"):
            if not line.strip():
                continue
            rec = json.loads(line)
            total_calls += 1
            t = re.sub(r"^\s*```(?:json)?\s*|\s*```\s*$", "", (rec.get("response") or "")).strip()
            i = t.find("{")
            if i >= 0:
                try:
                    _, end = json.JSONDecoder().raw_decode(t[i:])
                    trailing += bool(t[i + end:].strip())
                except json.JSONDecodeError:
                    pass
    v["n_model_calls_test"] = num(total_calls)
    rr = 0
    for pf in sorted((C.RESULTS / "predictions" / "test").glob("qwen*.jsonl")):
        rr += sum(1 for line in pf.read_text(encoding="utf-8").split("\n") if line.strip() and json.loads(line).get("run_id") == "test-oracle-a3")
    v["n_oracle_rerun_calls"] = num(rr)
    v["n_oracle_rerun_per_model"] = num(rr // 2) if rr else "0"
    v["n_trailing_text"] = num(trailing)
    v.update(tables(res))
    inside, outside = [], []
    for key, e in res["systems"].items():
        m0 = key.split("::")[0]
        if not m0.startswith("qwen") or key.endswith("full_split"):
            continue
        r = e["rejection"]
        flt, lo, hi = r["quote_filter"]["retained_error"], r["random_same_coverage"]["p2_5"], r["random_same_coverage"]["p97_5"]
        if flt is None or lo is None:
            continue
        name = f"{LABEL[m0]} with {dict(retrieved='retrieved passages', abstract='the abstract', oracle='annotated evidence')[key.split('::')[1]]}"
        (inside if lo <= flt <= hi else outside).append((name, flt, lo, hi))
    if outside:
        ex = "; ".join(f"for {n} the triangle lies {'below' if f < lo else 'above'} the band ({pct(f)} against {pct(lo)} to {pct(hi)})"
                       for n, f, lo, hi in outside)
        v["fig_rejection_alt"] = (f"dumbbell chart; for {len(inside)} of the {len(inside) + len(outside)} model and context "
                                  f"combinations the triangle lies inside the grey band, close to the ring; {ex}.")
    else:
        v["fig_rejection_alt"] = "dumbbell chart; for every model and context the triangle lies inside the grey band, close to the ring."
    v["n_rule_inside"], v["n_rule_total"] = str(len(inside)), str(len(inside) + len(outside))
    v["n_rule_beat"] = str(sum(1 for _, f, lo, _ in outside if f < lo))
    words = {0: "none", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven"}
    v["n_rule_beat_word"] = words.get(int(v["n_rule_beat"]), v["n_rule_beat"])
    v["fig_rejection_alt_capital"] = v["fig_rejection_alt"][0].upper() + v["fig_rejection_alt"][1:]
    for key, d in (res.get("taxonomy") or {}).items():
        tag = key.replace("::", "_").replace("-", "").replace(".", "")
        tot = sum(d.values())
        said_sig = sum(n for k, n in d.items() if k.startswith("significance error (model said significant)"))
        said_ns = sum(n for k, n in d.items() if k.startswith("significance error (model said not significant)"))
        rev = sum(n for k, n in d.items() if k.startswith("direction reversal"))
        ov = sum(n for k, n in d.items() if k.endswith("quote overlaps benchmark evidence"))
        rev_ov = sum(n for k, n in d.items() if k.startswith("direction reversal") and k.endswith("overlaps benchmark evidence"))
        v[f"tax_{tag}_total"] = num(tot)
        v[f"tax_{tag}_said_sig"] = f"{said_sig:,} ({said_sig / tot * 100:.1f}%)" if tot else "0"
        v[f"tax_{tag}_said_ns"] = f"{said_ns:,} ({said_ns / tot * 100:.1f}%)" if tot else "0"
        v[f"tax_{tag}_reversal"] = f"{rev:,} ({rev / tot * 100:.1f}%)" if tot else "0"
        v[f"tax_{tag}_overlap"] = f"{ov:,} ({ov / tot * 100:.1f}%)" if tot else "0"
        v[f"tax_{tag}_reversal_overlap"] = num(rev_ov)
        v[f"tax_{tag}_reversal_n"] = num(rev)
    from .prompts import EXAMPLE, FORMAT_GUIDE, LABEL_GUIDE, QUESTION_TEMPLATE
    v["prompt_question"] = QUESTION_TEMPLATE
    v["prompt_label_guide"] = LABEL_GUIDE
    v["prompt_format_guide"] = FORMAT_GUIDE.replace("\n", " ")
    v["prompt_example"] = EXAMPLE.replace("\n", " ")
    lic_path = C.DATA_INTERIM / "licenses_europepmc.json"
    if lic_path.exists():
        import statistics
        from .data import load_processed
        lic = json.loads(lic_path.read_text())
        _, pr = load_processed()
        ids = pr[(pr.split == "test") & pr.eligible_primary].pmcid.unique()
        yrs = [int(lic[f"PMC{x}"]["year"]) for x in ids if lic.get(f"PMC{x}", {}).get("year")]
        v["test_pub_year_min"], v["test_pub_year_max"] = str(min(yrs)), str(max(yrs))
        v["test_pub_year_median"] = f"{statistics.median(yrs):.0f}"
        v["test_pub_year_n"] = num(len(yrs))
    br = C.RESULTS / "dev" / "retrieval_budget_recall.json"
    if br.exists():
        b = json.loads(br.read_text())
        v["dev_recall_prompts"] = num(b["prompts"])
        for k, x in b["budgets"].items():
            v[f"dev_recall_{k}"] = pct(x["any_overlap"])
    # figure alt texts from the plotted data
    fig1 = {k: e["metrics"]["headline_qvwr"]["estimate"] for k, e in res["systems"].items()
            if not k.endswith("full_split") and not k.startswith("majority") and e["metrics"]["headline_qvwr"]["estimate"] is not None}
    if fig1:
        lo_k, hi_k = min(fig1, key=fig1.get), max(fig1, key=fig1.get)
        nm = lambda k: f"{LABEL[k.split('::')[0]]} with {dict(retrieved='retrieved passages', abstract='the title and abstract', oracle='annotated evidence')[k.split('::')[1]]}"
        v["fig1_alt_range"] = f"from {pct(fig1[lo_k])} ({nm(lo_k)}) to {pct(fig1[hi_k])} ({nm(hi_k)})"
    seg = {}
    for k, e in res["systems"].items():
        if k.split("::")[0].startswith("qwen") and not k.endswith("full_split"):
            sm = e["metrics"]["summary"]
            seg[k] = e["metrics"]["headline_qvwr"]["numerator"] / sm["items"]  # quote valid, label wrong, share of all prompts
    if seg:
        lo_k, hi_k = min(seg, key=seg.get), max(seg, key=seg.get)
        v["fig_outcomes_alt_range"] = f"from {pct(seg[lo_k])} of prompts ({nm(lo_k)}) to {pct(seg[hi_k])} ({nm(hi_k)})"
    for f in sorted(MS.glob("*_draft.md")):
        v[f.name[:-len("_draft.md")]] = f.read_text(encoding="utf-8").strip()
    for name in ("background", "methods", "models_paragraph", "abstract_models_sentence", "fourb_paragraph",
                 "rejection_models_sentence", "fourb_rejection_sentence"):
        v.setdefault(name, "")
    val = C.RESULTS / "validation" / "validation.json"
    if val.exists():
        vv = json.loads(val.read_text())
        mr = vv.get("model_rerun_sample")
        if mr:
            v["rerun_identical"] = f"{mr['identical_responses']} of {mr['n']}"
            v["rerun_same_label"] = f"{mr['same_label']} of {mr['n']}"
        sr = vv.get("source_reconciliation", {})
        for k in ("official_label_str_variant_rows", "official_txt_files", "official_txt_identical_after_crlf",
                  "official_txt_other_rendering", "offset_rows_differing", "offset_differing_articles"):
            if k in sr:
                v[f"recon_{k}"] = num(sr[k])
        for k in ("offset_sample_repo", "offset_sample_official"):
            if k in sr:
                v[f"recon_{k}_ex"] = num(sr[k]["exclusive_exact"])
                v[f"recon_{k}_inc"] = num(sr[k]["inclusive_exact"])
        dr = vv.get("deterministic_rerun", {})
        v["rerun_numbers_compared"] = num(dr.get("analysis_numbers_compared", 0))
    # the 20 quote-valid wrong answers drawn for the author's check against the source articles
    sc = C.RESULTS / "scored" / "primary__qwen3-1.7b__retrieved.csv"
    if sc.exists():
        import numpy as np
        import pandas as pd
        df = pd.read_csv(sc)
        wrong = df[df.answered & df.quote_exists & ~df.label_correct.astype(bool)]
        pick = np.random.default_rng(20261007).choice(len(wrong), size=20, replace=False)
        v["validation_sample_ids"] = ", ".join(str(i) for i in sorted(wrong.iloc[pick].prompt_id.astype(int)))
    return v


def fill(template: str, vals: dict[str, str]) -> str:
    # draft fragments may themselves contain placeholders: expand until stable
    for _ in range(4):
        new = re.sub(r"\{\{([a-zA-Z0-9_]+)\}\}", lambda m: vals.get(m.group(1), m.group(0)) if "{{" in vals.get(m.group(1), "")
                     else m.group(0), template)
        if new == template:
            break
        template = new
    missing = sorted(set(re.findall(r"\{\{([a-zA-Z0-9_]+)\}\}", template)) - set(vals) - {"references"})
    if missing:
        raise KeyError(f"unknown manuscript placeholders: {missing[:20]}")
    return re.sub(r"\{\{([a-zA-Z0-9_]+)\}\}", lambda m: vals.get(m.group(1), m.group(0)), template)


def escape_prompt_placeholders(md_text: str) -> str:
    """Keep prompt placeholders visible when Markdown is rendered as HTML."""
    import html

    for placeholder in (
        "<text copied character for character from one passage>",
        "<the passage ID the quote comes from, for example P2>",
    ):
        md_text = md_text.replace(placeholder, html.escape(placeholder))
    return md_text


def to_html(md_text: str, title: str) -> str:
    import markdown

    body = markdown.markdown(escape_prompt_placeholders(md_text), extensions=["tables", "footnotes", "toc", "attr_list"])
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title><style>body{{margin:0;background:#fbfbfa;color:#1d1d1b;font:17px/1.6 Georgia,'Times New Roman',serif}}
main{{max-width:760px;margin:0 auto;padding:32px 16px 80px}}h1{{font-size:1.6rem;line-height:1.3}}h2{{font-size:1.25rem;margin-top:2em}}h3{{font-size:1.05rem}}
table{{border-collapse:collapse;font:14px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;margin:1em 0;display:block;overflow-x:auto}}
th,td{{border-bottom:1px solid #d9d8d3;padding:4px 8px;text-align:left;vertical-align:top}}td{{font-variant-numeric:tabular-nums}}
img{{max-width:100%;height:auto}}code{{font-size:.88em;background:#f0efec;padding:0 3px}}a{{color:#1f5fae}}</style></head>
<body><main>{body}</main></body></html>"""


def to_docx(md_text: str, path: Path, title_page: str | None = None) -> None:
    """Word file in the journal's layout: double spacing, 12-point Times New Roman, no headers or footers,
    headings as BOLD CAPS (level 1), bold lower case (level 2), plain (level 3), tables in Word format."""
    import datetime as _dt

    import docx
    from docx.enum.text import WD_LINE_SPACING
    from docx.shared import Pt
    from docx.oxml import OxmlElement

    d = docx.Document()
    cp = d.core_properties
    head = title_page if title_page and title_page.strip() else md_text
    first = head.splitlines()[0] if head.strip() else ""
    cp.title = re.sub(r"^#+\s*", "", first).strip()
    cp.author = "Animesh Bose"
    cp.last_modified_by = "Animesh Bose"
    cp.comments = ""
    cp.keywords = ""
    cp.revision = 1
    cp.created = cp.modified = _dt.datetime(2026, 10, 7, tzinfo=_dt.timezone.utc)
    st = d.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
    st.paragraph_format.space_after = Pt(0)

    def para(text: str, bold=False, italic=False, caps=False, style=None):
        par = d.add_paragraph(style=style)
        for chunk in re.split(r"(\*\*[^*]+\*\*|(?<![\\*])\*[^*\s][^*]*?\*)", text):
            if not chunk:
                continue
            is_b = chunk.startswith("**") and chunk.endswith("**")
            is_i = not is_b and len(chunk) > 2 and chunk[0] == "*" and chunk[-1] == "*"
            run = par.add_run(_plain(chunk[2:-2] if is_b else chunk[1:-1] if is_i else chunk))
            run.bold = bold or is_b
            run.italic = italic or is_i
            run.font.all_caps = caps
        return par

    def body(src: str):
        lines = src.splitlines()
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("|") and i + 1 < len(lines) and re.match(r"^\|[\s:|-]+\|$", lines[i + 1]):
                rows = []
                while i < len(lines) and lines[i].startswith("|"):
                    if not re.match(r"^\|[\s:|-]+\|$", lines[i]):
                        rows.append([c.strip() for c in lines[i].strip("|").split("|")])
                    i += 1
                t = d.add_table(rows=len(rows), cols=len(rows[0]))
                t.style = "Table Grid"
                if d.paragraphs and d.paragraphs[-1].text:
                    d.paragraphs[-1].paragraph_format.keep_with_next = True
                for ri, row in enumerate(t.rows):
                    trpr = row._tr.get_or_add_trPr()
                    trpr.append(OxmlElement("w:cantSplit"))
                    if ri == 0:
                        trpr.append(OxmlElement("w:tblHeader"))
                for r, row in enumerate(rows):
                    for c, cell in enumerate(row[:len(rows[0])]):
                        t.cell(r, c).text = _plain(cell)
                        for pp in t.cell(r, c).paragraphs:
                            pp.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
                            for run in pp.runs:
                                run.font.size = Pt(9)
                                run.bold = r == 0
                d.add_paragraph()
                continue
            m = re.match(r"^(#{1,4})\s+(.*)", line)
            if m:
                level, text = len(m.group(1)), m.group(2)
                if level == 1:
                    para(text, bold=True)
                elif level == 2:
                    para(text, bold=True, caps=True)
                elif level == 3:
                    para(text, bold=True)
                else:
                    para(text)
                d.paragraphs[-1].paragraph_format.keep_with_next = True
            elif line.strip().startswith(("* ", "- ")):
                para(line.strip()[2:], style="List Bullet")
            elif re.match(r"^\d+\.\s", line.strip()):
                para(line.strip())
            elif line.strip() and not line.startswith("!["):
                para(line)
            i += 1

    if title_page:
        body(title_page)
        d.add_page_break()
    body(md_text)
    for sec in d.sections:  # no headers or footers
        sec.header.is_linked_to_previous = True
        sec.footer.is_linked_to_previous = True
    d.save(path)


def _plain(s: str) -> str:
    s = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", s)
    s = re.sub(r"\{#[^}]+\}", "", s)
    return s.replace("**", "").replace("`", "").replace("\\*", "*")


def main(log=print) -> dict:
    tpl = MS / "manuscript_template.md"
    if not tpl.exists():
        log("manuscript template not written yet; skipped")
        return {}
    vals = values()
    bib = parse_bib((C.DOCS / "research" / "references.bib").read_text(encoding="utf-8"))
    out = {}
    for name in sorted(MS.glob("*_template.md")):
        text = fill(name.read_text(encoding="utf-8"), vals)
        if "[@" in text:
            text = apply_citations(text, bib)
        stem = name.name.replace("_template.md", "")
        (MS / f"{stem}.md").write_text(text, encoding="utf-8")
        (MS / f"{stem}.html").write_text(to_html(text, stem.replace("_", " ").capitalize()), encoding="utf-8")
        to_docx(text, MS / f"{stem}.docx")
        out[stem] = str((MS / f"{stem}.md").relative_to(C.ROOT))
        log(f"rendered {stem}")
    t = (MS / "manuscript.md").read_text(encoding="utf-8")
    sec = lambda a, b: t[t.find(a) + len(a):t.find(b, t.find(a) + len(a))]
    # journal rule: the count excludes title page, abstract, references, figures, and tables (rows and captions)
    # counted as Word counts words (whitespace-separated, headings and citations included)
    wc = lambda x: len("\n".join(ln for ln in x.splitlines() if not ln.startswith("|") and not ln.startswith("**Table "))
                       .replace("#", " ").split())
    vals["wc_abstract"] = str(wc(sec("## Abstract", "## Lay summary")))
    vals["wc_lay"] = str(wc(sec("## Lay summary", "## Background")))
    main_end = t.find("## Acknowledgments") if "## Acknowledgments" in t else t.find("## Competing interests")
    vals["wc_main"] = f"{wc(t[t.find('## Background and Significance'):main_end]):,}"
    for name in sorted((MS / "submission").glob("*_template.md")):
        text = fill(name.read_text(encoding="utf-8"), vals)
        stem = name.name.replace("_template.md", "")
        (MS / "submission" / f"{stem}.md").write_text(text, encoding="utf-8")
        to_docx(text, MS / "submission" / f"{stem}.docx")
        log(f"rendered submission/{stem}.md and .docx")
    # submission manuscript: the title page (with contact details) replaces the short author block
    tp = MS / "submission" / "title_page.md"
    if tp.exists():
        body = re.sub(r"(?s)\A# [^\n]*\n.*?(?=^## Abstract)", "", t, flags=re.M)
        body = re.sub(r"(?m)^!\[[^\]]*\]\([^)]*\)\n?", "", body)  # figures are uploaded as separate files
        ack = MS / "submission" / "acknowledgments.md"
        if ack.exists() and "## Acknowledgments" not in body:
            body = body.replace("## Competing interests", ack.read_text(encoding="utf-8").strip() + "\n\n## Competing interests", 1)
        to_docx(body, MS / "submission" / "manuscript_submission.docx",
                title_page=tp.read_text(encoding="utf-8"))
        (MS / "submission" / "manuscript_submission.md").write_text(tp.read_text(encoding="utf-8").rstrip() + "\n\n" + body,
                                                                   encoding="utf-8")
        log("rendered submission/manuscript_submission.docx")
    (MS / "placeholder_values.json").write_text(json.dumps(vals, indent=1))
    return out


# ---------------------------------------------------------------- citations
TEX = {r'{\"a}': "ä", r'{\"o}': "ö", r'{\"u}': "ü", r"{\'e}": "é", r"{\'a}": "á", r"{\'i}": "í", r"{\'o}": "ó",
       r"{\`e}": "è", r"{\~n}": "ñ", r'\"a': "ä", r'\"o': "ö", r'\"u': "ü", r"\'e": "é", r"{\c c}": "ç", r"{\ss}": "ß"}


def _detex(s: str) -> str:
    for k, v in TEX.items():
        s = s.replace(k, v)
    return re.sub(r"[{}]", "", s).replace("--", "-").replace("\\&", "&").strip()


def parse_bib(text: str) -> dict[str, dict]:
    out = {}
    for m in re.finditer(r"@(\w+)\s*\{\s*([^,\s]+)\s*,", text):
        typ, key = m.group(1).lower(), m.group(2)
        i, depth = m.end(), 1
        while depth and i < len(text):
            depth += {"{": 1, "}": -1}.get(text[i], 0)
            i += 1
        body = text[m.end():i - 1]
        fields = {}
        for fm in re.finditer(r"(\w+)\s*=\s*", body):
            j = fm.end()
            if j < len(body) and body[j] == "{":
                d, k = 1, j + 1
                while d and k < len(body):
                    d += {"{": 1, "}": -1}.get(body[k], 0)
                    k += 1
                val = body[j + 1:k - 1]
            else:
                val = re.match(r"[^,\n]*", body[j:]).group(0)
            fields.setdefault(fm.group(1).lower(), _detex(val))
        out[key] = {"type": typ, **fields}
    return out


def _authors(a: str) -> str:
    names = [x.strip() for x in a.split(" and ") if x.strip()]
    fm = []
    for n in names:
        if n.lower() == "others":
            fm.append("et al")
            continue
        if "," in n:
            last, first = [p.strip() for p in n.split(",", 1)]
        else:
            parts = n.split()
            last, first = (parts[-1], " ".join(parts[:-1])) if len(parts) > 1 else (n, "")
        initials = "".join(w[0] for w in re.split(r"[\s.-]+", first) if w and w[0].isalpha())
        fm.append(f"{last} {initials}".strip())
    if len(fm) > 3:
        fm = fm[:3] + ["et al"]
    return ", ".join(fm)


MEDLINE = {"Computational Linguistics": "Comput Linguist", "Nature Communications": "Nat Commun", "Cureus": "Cureus",
           "Nature Medicine": "Nat Med", "Journal of the American Medical Informatics Association": "J Am Med Inform Assoc",
           "JAMIA Open": "JAMIA Open", "Journal of Biomedical Informatics": "J Biomed Inform",
           "Transactions of the Association for Computational Linguistics": "Trans Assoc Comput Linguist",
           "BMC Medical Informatics and Decision Making": "BMC Med Inform Decis Mak"}


def format_ref(e: dict) -> str:
    au = _authors(e.get("author", "")) if e.get("author") else ""
    title = e.get("title", "").rstrip(".")
    yr = e.get("year", "")
    doi = f" doi:{e['doi']}" if e.get("doi") else ""
    if e["type"] == "article":
        vol = e.get("volume", "")
        no = f"({e['number']})" if e.get("number") else ""
        pg = f":{e['pages']}" if e.get("pages") else ""
        jn = MEDLINE.get(e.get("journal", ""), e.get("journal", ""))
        core = f"{jn}. {yr};{vol}{no}{pg}."
    elif e["type"] in ("inproceedings", "incollection"):
        pg = f":{e['pages']}" if e.get("pages") else ""
        vol = (f";{e['volume']}" + (f"({e['number']})" if e.get("number") else "")) if e.get("volume") else ""
        core = f"In: {e.get('booktitle', '')}. {yr}{vol}{pg}."
    else:
        if e.get("archiveprefix", "").lower() == "arxiv" or e.get("eprint"):
            core = f"arXiv:{e.get('eprint', '')}. Preprint posted {yr}."
        else:
            core = f"{e.get('howpublished', e.get('publisher', ''))} {yr}.".strip()
    url = "" if doi else (f" {e['url']}" if e.get("url") else "")
    return f"{au}. {title}. {core}{doi}{url}".replace("..", ".").strip()


def apply_citations(text: str, bib: dict[str, dict]) -> str:
    order: list[str] = []

    def rep(m):
        keys = [k.strip().lstrip("@") for k in m.group(1).split(";")]
        nums = []
        for k in keys:
            if k not in bib:
                raise KeyError(f"citation key not in bibliography: {k}")
            if k not in order:
                order.append(k)
            nums.append(order.index(k) + 1)
        nums = sorted(set(nums))
        # compress runs: 1,2,3 -> 1-3
        parts, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            parts.append(f"{nums[i]}-{nums[j]}" if j - i >= 2 else ",".join(str(n) for n in nums[i:j + 1]))
            i = j + 1
        return "[" + ",".join(parts) + "]"

    body = re.sub(r"\[(@[^\]]+)\]", rep, text)
    body = re.sub(r"\s*(\[[\d,\-]+\])([.,;:])", r"\2\1", body)
    refs = "\n".join(f"{i + 1}. {format_ref(bib[k])}" for i, k in enumerate(order))
    return body.replace("{{references}}", refs) if "{{references}}" in body else body + "\n\n## References\n\n" + refs


# ---------------------------------------------------------------- generated tables
SYS_ORDER = [("qwen3-1.7b", "retrieved"), ("qwen3-0.6b", "retrieved"), ("qwen3-4b-instruct-2507", "retrieved"),
             ("tfidf-lr", "retrieved"), ("majority", "retrieved"), ("qwen3-1.7b", "abstract"), ("qwen3-0.6b", "abstract"),
             ("tfidf-lr", "abstract"), ("majority", "abstract"), ("qwen3-1.7b", "oracle"), ("qwen3-0.6b", "oracle"),
             ("tfidf-lr", "oracle"), ("majority", "oracle")]
CLAB = {"retrieved": "Retrieved", "abstract": "Abstract", "oracle": "Oracle"}
RC_FEATURES = {"quote_exists": "Quote exists (0 or 1)", "locator_valid": "Passage identifier valid (0 or 1)",
               "log_words": "Quote length, log(1 + words)", "sig_wording": "Quote contains significance wording (0 or 1)",
               "label_wording_consistent": "Label agrees with the quote's significance wording (0 or 1)",
               "outcome_overlap": "Share of outcome words that appear in the quote"}


def _md(header: list[str], rows: list[list], align: list[str] | None = None) -> str:
    align = align or ["l"] * len(header)
    sep = ["---:" if a == "r" else "---" for a in align]
    out = ["| " + " | ".join(header) + " |", "| " + " | ".join(sep) + " |"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def _p(n, d):
    return f"{n:,} ({n / d * 100:.1f}%)" if d else f"{n:,}"


def tables(res: dict) -> dict[str, str]:
    t = {}
    rows = []
    for m, c in SYS_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"]:
            continue
        s = res["systems"][k]["metrics"]["summary"]
        h = res["systems"][k]["metrics"]["headline_qvwr"]
        n, a = s["items"], s["answered"]
        rows.append([CLAB[c], LABEL[m], f"{n:,}", _p(s["parse_valid"], n), _p(s["abstained"], n), _p(s["quote_exists"], a),
                     _p(s["locator_valid"], a), _p(s["label_correct"], a),
                     f"{h['numerator']:,} of {h['denominator']:,} ({pct(h['estimate'])})" if h["denominator"] else "undefined",
                     _p(s["task_success"], n), f"{s['macro_f1']:.3f}"])
    t["table_main"] = _md(["Context", "System", "Prompts", "Parse valid", "Abstained", "Quote exists (of answered)",
                           "Locator valid (of answered)", "Label correct (of answered)", "Quote valid, label wrong",
                           "Task success", "Macro-F1"], rows, ["l", "l"] + ["r"] * 9)
    rows = []
    for m, c in SYS_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"] or not m.startswith("qwen"):
            continue
        r = res["systems"][k]["rejection"]
        d = r["filter_minus_unfiltered_error"]
        rows.append([CLAB[c], LABEL[m], f"{pct(r['unfiltered']['retained_error'])} at {pct(r['unfiltered']['coverage'])}",
                     f"{pct(r['quote_filter']['retained_error'])} at {pct(r['quote_filter']['coverage'])}",
                     f"{d['diff'] * 100:+.1f} ({d['ci_low'] * 100:+.1f} to {d['ci_high'] * 100:+.1f})" if d["diff"] is not None else "undefined",
                     f"{pct(r['random_same_coverage']['mean_error'])} ({pct(r['random_same_coverage']['p2_5'])} to {pct(r['random_same_coverage']['p97_5'])})",
                     pct(r["random_same_coverage"]["share_draws_error_le_filter"]),
                     f"{r['quote_filter']['rejected_answers']:,} ({r['quote_filter']['rejected_correct']:,} correct)"])
    t["table_rejection"] = _md(["Context", "Model", "Error, all answers (at coverage)", "Error, quote and locator valid only (at coverage)",
                                "Difference, points (95% CI)", "Random rejection, same coverage: mean (middle 95%)",
                                "Random draws with error at or below the rule", "Answers rejected by the rule"], rows,
                               ["l", "l", "r", "r", "r", "r", "r", "r"])
    rows = []
    names = {"S0_primary": "Primary (definition Q)", "S1_strict_quote": "S1 strict quote existence",
             "S2_include_disagreement_any_label": "S2 include label disagreements", "S3_exclude_flagged": "S3 exclude flagged prompts",
             "S4_min_quote_1_word": "S4 one-word minimum quote", "S5_retrieval_supplied_evidence": "S5 retrieved passages hold benchmark evidence"}
    for m, c in SYS_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"] or not m.startswith("qwen"):
            continue
        for sname, h in (res["systems"][k].get("sensitivity") or {}).items():
            rows.append([CLAB[c], LABEL[m], names.get(sname, sname),
                         f"{h['numerator']:,} of {h['denominator']:,}" if h["denominator"] else "0 of 0", ci(h)])
    t["table_sensitivity"] = _md(["Context", "Model", "Analysis", "Wrong of quote-valid", "Rate (95% CI)"], rows,
                                 ["l", "l", "l", "r", "r"])
    rows = []
    mlab = {"task_success_f": "Task success", "correct_all": "Correct label (all prompts)", "quote_valid_all": "Quote valid and locator valid (all prompts)"}
    for label, c in res.get("comparisons", {}).items():
        a, b = c["systems"]
        for met in ("task_success_f", "correct_all", "quote_valid_all"):
            d = c[met]
            if d.get("diff") is None:
                continue
            rows.append([_syslab(a), _syslab(b), mlab[met], f"{d['n_prompts']:,}", pct(d["a"]), pct(d["b"]),
                         f"{d['diff'] * 100:+.1f} ({d['ci_low'] * 100:+.1f} to {d['ci_high'] * 100:+.1f})"])
    t["table_comparisons"] = _md(["System A", "System B", "Quantity", "Shared prompts", "A", "B", "A minus B, points (95% CI)"],
                                 rows, ["l", "l", "l", "r", "r", "r", "r"])
    rows = []
    for m, c in SYS_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"]:
            continue
        s = res["systems"][k]["metrics"]["summary"]
        h = res["systems"][k]["metrics"]["headline_qvwr"]
        for lab in C.LABELS:
            g, pr = h["per_gold_class"][lab], h["per_pred_class"][lab]
            rows.append([CLAB[c], LABEL[m], lab, f"{s[f'support::{lab}']:,}", f"{s[f'precision::{lab}']:.3f}",
                         f"{s[f'recall::{lab}']:.3f}", f"{g['numerator']} of {g['denominator']}", f"{pr['numerator']} of {pr['denominator']}"])
    t["table_per_class"] = _md(["Context", "System", "Benchmark class", "Support", "Precision", "Recall",
                                "Quote-valid wrong, by benchmark class", "Quote-valid wrong, by predicted class"], rows,
                               ["l", "l", "l", "r", "r", "r", "r", "r"])
    rows = []
    for cond, e in res.get("evidence_recall_at_budget", {}).items():
        rows.append([CLAB[cond], f"{e['prompts']:,}", ci(e["any_overlap"]), ci(e["full_cover"]),
                     f"{e['median_context_tokens']:.0f}", pct(e["truncated_share"])])
    t["table_recall"] = _md(["Context", "Prompts with located evidence", "Passages overlap evidence (95% CI)",
                             "Passages contain a full span (95% CI)", "Median context tokens", "Truncated"], rows,
                            ["l", "r", "r", "r", "r", "r"])
    rows = []
    for m, c in SYS_ORDER:
        k = f"{m}::{c}"
        if k not in res["systems"] or not m.startswith("qwen"):
            continue
        sc = res["systems"][k]["metrics"]["summary"]["parse_status_counts"]
        rows.append([CLAB[c], LABEL[m]] + [f"{sc.get(x, 0):,}" for x in ("valid", "schema_error", "invalid_json",
                                                                       "no_json_object", "empty", "runtime_error", "not_run")]
                    + [f"{res['systems'][k]['metrics']['summary']['length_stops']:,}"])
    t["table_parse"] = _md(["Context", "Model", "Valid", "Schema error", "Invalid JSON", "No JSON object", "Empty",
                            "Runtime error", "Not run", "Stopped at length limit"], rows, ["l", "l"] + ["r"] * 8)
    rows = []
    for k, d in (res.get("taxonomy") or {}).items():
        m, c = k.split("::")[:2]
        for cat, n in sorted(d.items(), key=lambda x: -x[1]):
            et, rel = cat.split(" / ")
            rows.append([CLAB[c], LABEL[m], et, rel, f"{n:,}"])
    t["table_taxonomy"] = _md(["Context", "Model", "Error type", "Quote relation to benchmark evidence", "Count"], rows,
                              ["l", "l", "l", "l", "r"])
    rows = [[LABEL[n], C.MODELS[n]["repo_id"], f"`{C.MODELS[n]['revision']}`", C.MODELS[n]["role"]] for n in C.MODELS]
    t["table_models"] = _md(["Model", "Repository", "Pinned revision", "Role"], rows)
    bt = res.get("baselines_training", {}).get("conditions", {})
    rows = [[CLAB[c], f"{v['n_train']:,}", f"{v['n_val']:,}", str(v["best"]["C"]), v["best"]["class_weight"],
             f"{v['best']['val_macro_f1']:.3f}"] for c, v in bt.items()]
    t["table_baseline_training"] = _md(["Context", "Training prompts", "Validation prompts", "C", "Class weight",
                                        "Validation macro-F1"], rows, ["l", "r", "r", "r", "l", "r"])
    return t


def _syslab(k: str) -> str:
    m, c = k.split("::")[:2]
    return f"{LABEL[m]}, {c}"
