"""Source-and-prediction viewer.

Each record shows the article ID, the question, the model's label and the
benchmark label, the failure type, and the supplied passages with the returned
quote highlighted and benchmark evidence underlined. The local viewer can show
any article; the public viewer only includes articles whose license (Europe
PMC) is CC BY or CC0, with attribution, and trims passages to those that hold
the quote or benchmark evidence.
"""
from __future__ import annotations

import html
import json
from pathlib import Path

import pandas as pd

from . import config as C
from .run import build_contexts

FAILURE_ORDER = ["correct with an existing quote", "existing quote, wrong label", "label right, quote not found",
                 "label wrong, quote not found", "abstained", "invalid output"]


def failure_type(r) -> str:
    if r["parse_status"] != "valid":
        return "invalid output"
    if r["abstained"]:
        return "abstained"
    q = bool(r["quote_exists"])
    ok = bool(r["label_correct"])
    if q and ok:
        return "correct with an existing quote"
    if q and not ok:
        return "existing quote, wrong label"
    return "label right, quote not found" if ok else "label wrong, quote not found"


def _mark(text: str, start: int, spans_q: list, spans_g: list) -> str:
    """Return HTML for text (article offsets start..) with quote spans <mark> and gold spans <u>."""
    n = len(text)
    q = [0] * n
    g = [0] * n
    for s, e in spans_q:
        for i in range(max(0, s - start), min(n, e - start)):
            q[i] = 1
    for s, e in spans_g:
        for i in range(max(0, s - start), min(n, e - start)):
            g[i] = 1
    out, cur, buf = [], (0, 0), []
    for i, ch in enumerate(text):
        st = (q[i], g[i])
        if st != cur:
            out.append(_wrap("".join(buf), cur))
            buf, cur = [], st
        buf.append(ch)
    out.append(_wrap("".join(buf), cur))
    return "".join(out)


def _wrap(s: str, st) -> str:
    s = html.escape(" ".join(s.split("\n")))
    if not s:
        return ""
    if st == (1, 1):
        return f'<mark class="q"><u class="g">{s}</u></mark>'
    if st == (1, 0):
        return f'<mark class="q">{s}</mark>'
    if st == (0, 1):
        return f'<u class="g">{s}</u>'
    return s


def records(scored: pd.DataFrame, condition: str, split_tag: str, frame: pd.DataFrame, licenses: dict | None = None,
            public: bool = False, raw: dict | None = None) -> list[dict]:
    ctxs = build_contexts(frame, condition, split_tag)
    gold = frame.set_index("prompt_id").gold_spans.to_dict()
    out = []
    for r in scored.to_dict("records"):
        ctx = ctxs[int(r["prompt_id"])]
        spans_g = [tuple(s) for s in json.loads(gold[r["prompt_id"]])]
        spans_q = [(int(r["quote_start"]), int(r["quote_end"]))] if pd.notna(r.get("quote_start")) else []
        lic = (licenses or {}).get(f"PMC{r['pmcid']}", {})
        ps = []
        for p in ctx.passages:
            hit = any(max(0, min(p.end, e) - max(p.start, s)) > 0 for s, e in spans_q + spans_g)
            if public and not hit:
                continue
            ps.append({"pid": p.pid, "html": _mark(p.text, p.start, spans_q, spans_g), "start": p.start, "end": p.end,
                       "section": p.section})
        out.append({
            "prompt_id": int(r["prompt_id"]), "pmcid": int(r["pmcid"]), "question": {
                "intervention": r["intervention"], "comparator": r["comparator"], "outcome": r["outcome"]},
            "model_label": r["label_pred"] if r["answered"] else ("cannot determine" if r["abstained"] else "no valid answer"),
            "benchmark_label": r["gold_label"], "failure_type": failure_type(r),
            "quote": r["quote"] if isinstance(r["quote"], str) else "",
            "passage_id_returned": (json.loads(raw[r["prompt_id"]]["response"]).get("passage_id")
                                    if raw and r["parse_status"] == "valid" else None),
            "quote_exists": bool(r["quote_exists"]), "locator_valid": bool(r["locator_valid"]),
            "gold_overlap": None if pd.isna(r["gold_overlap"]) else bool(r["gold_overlap"]),
            "passages": ps, "passages_shown": "Only passages holding the quote or benchmark evidence" if public else "All supplied passages",
            "license": lic.get("license"), "attribution": {k: lic.get(k) for k in ("authors", "title", "journal", "year", "doi")},
            "raw_response": (raw or {}).get(r["prompt_id"], {}).get("response") if not public else None,
        })
    return out


PAGE = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
:root{{--bg:#fbfbfa;--ink:#1d1d1b;--muted:#5b5a56;--rule:#d9d8d3;--accent:#1f5fae;--q:#fde7b0;--g:#1f5fae;--plate:#f2f1ee}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}}
main{{max-width:980px;margin:0 auto;padding:24px 16px 64px}}h1{{font-size:1.5rem;margin:0 0 8px}}p.lede{{color:var(--muted);max-width:70ch}}
.controls{{display:flex;flex-wrap:wrap;gap:12px;align-items:center;margin:16px 0;padding:12px 0;border-top:1px solid var(--rule);border-bottom:1px solid var(--rule)}}
label{{font-size:.9rem;color:var(--muted)}}select{{font:inherit;padding:6px 8px;border:1px solid var(--rule);background:#fff;border-radius:4px}}
article{{border-bottom:1px solid var(--rule);padding:16px 0}}h2{{font-size:1.05rem;margin:0 0 6px}}
dl{{display:grid;grid-template-columns:max-content 1fr;gap:2px 12px;margin:8px 0;font-size:.92rem}}dt{{color:var(--muted)}}dd{{margin:0}}
.ft{{display:inline-block;font-size:.85rem;padding:1px 8px;border:1px solid var(--rule);border-radius:999px}}
.p{{background:var(--plate);padding:8px 10px;margin:6px 0;font-size:.92rem;overflow-wrap:anywhere}}.pid{{font-family:ui-monospace,Menlo,monospace;color:var(--muted);margin-right:6px}}
mark.q{{background:var(--q);color:inherit;padding:0 1px}}u.g{{text-decoration:underline 2px var(--g);text-underline-offset:3px}}
.key{{font-size:.9rem;color:var(--muted)}}.attr{{font-size:.82rem;color:var(--muted)}}pre{{white-space:pre-wrap;font-size:.8rem;background:var(--plate);padding:8px}}
a{{color:var(--accent)}}:focus-visible{{outline:2px solid var(--accent);outline-offset:2px}}
</style></head><body><main>
<h1>{title}</h1>
<p class="lede">{lede}</p>
<p class="key"><mark class="q">Highlighted</mark> text is the quote the model returned, located in the supplied passages. <u class="g">Underlined</u> text is accepted benchmark evidence from the Evidence Inference 2.0 annotations. Failure types are rule-based, not expert judgments.</p>
<div class="controls"><label for="ft">Failure type</label><select id="ft"><option value="">All ({n})</option>{options}</select>
<span id="count" class="key" aria-live="polite"></span></div>
<div id="list"></div>
</main>
<script id="data" type="application/json">{data}</script>
<script>
const D=JSON.parse(document.getElementById('data').textContent);const L=document.getElementById('list');const S=document.getElementById('ft');const N=document.getElementById('count');
const e=s=>String(s??'').replace(/[&<>"]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}})[c]);
function render(){{const f=S.value;const rows=D.filter(r=>!f||r.failure_type===f);N.textContent=rows.length+' shown';
L.innerHTML=rows.map(r=>`<article><h2>PMC${{r.pmcid}}, prompt ${{r.prompt_id}}</h2>
<dl><dt>Question</dt><dd>With respect to <b>${{e(r.question.outcome)}}</b>, ${{e(r.question.intervention)}} versus ${{e(r.question.comparator)}}</dd>
<dt>Model label</dt><dd>${{e(r.model_label)}}</dd><dt>Benchmark label</dt><dd>${{e(r.benchmark_label)}}</dd>
<dt>Failure type</dt><dd><span class="ft">${{e(r.failure_type)}}</span></dd>
<dt>Checks</dt><dd>quote exists: ${{r.quote_exists?'yes':'no'}}; locator valid: ${{r.locator_valid?'yes':'no'}}; overlaps benchmark evidence: ${{r.gold_overlap===null?'not evaluable':(r.gold_overlap?'yes':'no')}}</dd>
<dt>Returned quote</dt><dd>${{e(r.quote)||'<i>none</i>'}}</dd></dl>
${{r.passages.map(p=>`<div class="p"><span class="pid">${{p.pid}}</span>${{p.html}}</div>`).join('')}}
<p class="attr">${{e(r.passages_shown)}}. ${{r.license?`Source: ${{e(r.attribution.authors)}} ${{e(r.attribution.title)}} ${{e(r.attribution.journal)}} ${{e(r.attribution.year)}}. License ${{e(r.license.toUpperCase())}}. `:''}}<a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC${{r.pmcid}}/">PMC${{r.pmcid}}</a></p>
${{r.raw_response?`<details><summary>Raw response</summary><pre>${{e(r.raw_response)}}</pre></details>`:''}}</article>`).join('');}}
S.addEventListener('change',render);render();
</script></body></html>"""


def _clean(o):
    """Replace float NaN (pandas missing values) with None so the page data is valid JSON."""
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_clean(v) for v in o]
    if isinstance(o, float) and o != o:
        return None
    return o


def render_page(recs: list[dict], title: str, lede: str) -> str:
    recs = _clean(recs)
    counts = pd.Series([r["failure_type"] for r in recs]).value_counts().to_dict()
    opts = "".join(f'<option value="{html.escape(k)}">{html.escape(k)} ({counts[k]})</option>'
                   for k in FAILURE_ORDER if k in counts)
    data = json.dumps(recs, ensure_ascii=False, allow_nan=False).replace("</", "<\\/")
    return PAGE.format(title=html.escape(title), lede=html.escape(lede), n=len(recs), options=opts, data=data)


def local_view(model: str, condition: str, out: str, log=print) -> Path:
    from .evaluate import load_predictions, primary_mask
    from .run import predictions_path, test_items_frame

    fz = json.loads((C.CONFIG_DIR / "frozen_config.json").read_text())
    p = C.RESULTS / "scored" / "test" / f"{model}__{condition}__{fz['variant']}__{fz['decoding']}.csv"
    df = pd.read_csv(p)
    df = df[primary_mask(df)]
    frame = test_items_frame()
    raw = load_predictions(predictions_path("test", model, condition, fz["variant"], fz["decoding"]))
    recs = records(df, condition, "test", frame, raw=raw)
    path = C.ROOT / out
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_page(recs, f"Local viewer: {model}, {condition} condition",
                                "All scored test items. This file contains article text and stays local."), encoding="utf-8")
    log(f"wrote {path} ({len(recs)} records)")
    return path
