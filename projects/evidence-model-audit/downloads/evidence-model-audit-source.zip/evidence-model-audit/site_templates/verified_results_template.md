# Verified results

Only measured results with their evidence paths. Scope: Evidence Inference 2.0 official test split, eligible prompts (unanimous accepted label, not on the corpus "Incorrect" list).

## What was built and run

* A command-line evaluation harness (Python package `ema`) that ingests the Evidence Inference schema, builds retrieved, abstract, and oracle contexts, runs cached local inference, and scores parse validity, quote existence, locator validity, evidence overlap, label correctness, and end-to-end success separately. Evidence: src/ema/, tests/.
* Local inference with Qwen3-1.7B, Qwen3-0.6B (three contexts each), and Qwen3-4B-Instruct-2507 (retrieved context) on the {{run_qwen317b_articles}} articles of the frozen test sample ({{qwen317b_retrieved_articles}} enter the analysis after amendment A2): {{n_model_calls_test}} recorded model calls, including {{n_oracle_rerun_calls}} oracle re-runs after amendment A3. Evidence: results/predictions/test/, results/runs/.
* A trained TF-IDF + logistic regression baseline per context and a majority-class reference. Evidence: results/baselines_summary.json.

## Measured results

* Qwen3-1.7B, retrieved passages: {{qwen317b_retrieved_qvwr_frac}} quote-valid answers had the wrong label, {{qwen317b_retrieved_qvwr}}. Evidence: results/analysis/results.json, systems["qwen3-1.7b::retrieved"].metrics.headline_qvwr.
* Same system: end-to-end task success {{qwen317b_retrieved_success_frac}}, {{qwen317b_retrieved_success}}. Evidence: results/analysis/results.json, systems["qwen3-1.7b::retrieved"].metrics.task_success.
* Quote-validity rule: retained error {{qwen317b_retrieved_rej_unf}} to {{qwen317b_retrieved_rej_flt}}, coverage {{qwen317b_retrieved_rej_cov_unf}} to {{qwen317b_retrieved_rej_cov_flt}}; random rejection at the same coverage {{qwen317b_retrieved_rej_rand}}. Evidence: results/analysis/results.json, systems["qwen3-1.7b::retrieved"].rejection; results/tables/rejection_rule.csv.
* With annotated evidence supplied (oracle): {{qwen317b_oracle_qvwr_frac}} quote-valid answers wrong, {{qwen317b_oracle_qvwr}}. Evidence: results/analysis/results.json, systems["qwen3-1.7b::oracle"].metrics.headline_qvwr.
{{handoff_models_lines}}

## Wording limits

Do not describe this as a deployed tool, a clinical decision aid, a first-of-its-kind result, peer-reviewed, or published. The labels are an existing expert benchmark; model outputs were not re-labelled by experts (I spot-checked 20 quote-valid wrong answers against the source articles).
