# Validation record: evidence-model-audit

Editorial revision, October 12, 2026: the computational checks below describe the original research run. The prose and packages were revised without rerunning inference or analysis. Prior archive checks apply to their recorded hashes.
This record separates three kinds of checking. Software testing and source reconciliation were done; external scientific validation (an independent team reproducing the study or experts re-labelling outputs) was not.

## Software testing

* Test suite: tests/ (synthetic fixtures only; never mixed with study data). Covers JSON parsing and schema errors, quote location across hard line wraps, strict versus normalized matching, minimum quote length, locator validity, abstention handling, the label contract, half-open offsets, abstract delimiting, chunk offsets and limits, evidence recall, the clustered bootstrap, macro-F1 with abstentions, and the rejection arithmetic.
* Clean-room check (source archive SHA-256 {{clean_room_archive_sha256}}; this record {{clean_room_status}}): the source archive was extracted into an empty directory and installed into a fresh virtual environment from requirements.lock.txt; the tests passed, the cached demo rendered the saved study outputs for the bundled examples, and the live demo answered the same examples with real Qwen3-0.6B inference on CPU, using the already-downloaded pinned model snapshot. Recorded in results/validation/clean_room.json, kept outside the archive so that recording the check does not change it.

## Source reconciliation

* Repository commit a661e8c against the project-site v2.0 tarball: prompts and split files byte-identical; 24,686 annotation rows with identical label codes; test rows identical to the posted answers file on user, prompt, article, label code, validity flags, and In Abstract.
* Offsets: exclusive ends reproduce annotation strings ({{recon_offset_sample_repo_ex}} of 3,000 sampled training rows); inclusive ends reproduce {{recon_offset_sample_repo_inc}}.
* Abstract files: 2,334 of 3,285 contain body sections; not used as abstracts.
* Split integrity: no article in two splits; no identical texts; no near-duplicate pair at TF-IDF cosine 0.9 or more.

## Reruns and cross-checks

* Deterministic rerun of data, contexts, scoring, and analysis from cached inputs: {{rerun_numbers_compared}} reported numbers compared with the stored results at relative tolerance 1e-9.
* Separate recount in base R of quote-valid wrong-direction numerators and denominators, task-success counts, and item counts for every system: all matched the Python results.
* Model rerun: a sample of test calls regenerated with the frozen configuration on the same machine and device: {{rerun_identical}} identical responses, {{rerun_same_label}} same labels. Identical output across other hardware or library versions was not tested.
* Development parity: GPU and CPU float32 inference gave identical responses on {{dev_parity_identical}} development prompts.
* Claims: every headline number in evidence/claims.json re-read from results/analysis/results.json.

## Author checks

I checked the primary result and its inputs by hand. The primary counts ({{qwen317b_retrieved_qvwr_numerator}} of {{qwen317b_retrieved_qvwr_denominator}}) were recounted from the item-level file in a spreadsheet. Twenty quote-valid wrong answers, drawn with seed 20261007 (prompt IDs {{validation_sample_ids}}), were compared with the source articles to confirm that each quote appeared in the article and that the benchmark label reflected the reported result. The label codes of five sampled prompts were confirmed against the raw annotation file. The timestamps of the analysis plan and frozen configuration were confirmed to predate the first language-model test prediction, and the descriptions of the five closest prior studies were checked against the papers.

## External scientific validation

Not performed. The benchmark labels are the published Evidence Inference 2.0 annotations; apart from my 20-item check, no outputs were re-labelled, and automated error categories are not expert judgments.
