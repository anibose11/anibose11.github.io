#!/bin/sh
# Extract the source archive into an empty directory, install it in a fresh virtual
# environment, run the tests and the cached demo, and optionally the live demo.
# Usage: sh scripts/clean_room_check.sh <source-zip> <work-dir> [--live <models-dir>]
set -eu
ZIP="$1"; WORK="$2"; MODE="${3:-}"; MODELS="${4:-}"
rm -rf "$WORK"; mkdir -p "$WORK"
cd "$WORK"
unzip -q "$ZIP"
cd evidence-model-audit
python3 -m venv .venv
.venv/bin/python -m pip install -q -r requirements.lock.txt
.venv/bin/python -m pip install -q -e . --no-deps
.venv/bin/python -m pytest -q
.venv/bin/ema demo --cached
if [ "$MODE" = "--live" ]; then
  EMA_MODELS="$MODELS" .venv/bin/ema demo --model qwen3-0.6b --device cpu
fi
echo "clean-room check finished"
