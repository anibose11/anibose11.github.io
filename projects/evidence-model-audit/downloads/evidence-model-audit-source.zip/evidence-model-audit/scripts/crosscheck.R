# Independent recount of the headline counts in base R, from the scored item files.
# This is a second implementation (a software cross-check), not expert validation.
# Usage: Rscript scripts/crosscheck.R results/scored
args <- commandArgs(trailingOnly = TRUE)
dir <- if (length(args) > 0) args[1] else "results/scored"
files <- list.files(dir, pattern = "^primary__.*\\.csv$", full.names = TRUE)
as_bool <- function(x) {
  x <- toupper(as.character(x))
  ifelse(x %in% c("TRUE", "T", "1"), TRUE, ifelse(x %in% c("FALSE", "F", "0"), FALSE, NA))
}
out <- list()
for (f in files) {
  d <- read.csv(f, stringsAsFactors = FALSE, na.strings = c("", "NA"))
  key <- sub("^primary__", "", sub("\\.csv$", "", basename(f)))
  key <- gsub("__", "::", key)
  # recompute answered and correctness from the raw fields rather than the precomputed flags
  valid <- d$parse_status == "valid"
  abstained <- valid & d$label_pred == "cannot determine"
  answered <- valid & !abstained
  correct <- answered & !is.na(d$gold_label) & d$label_pred == d$gold_label
  quote_ok <- answered & as_bool(d$quote_exists) %in% TRUE
  qv <- quote_ok & !is.na(d$gold_label)
  num <- sum(qv & !correct)
  den <- sum(qv)
  success <- sum(correct & quote_ok & as_bool(d$locator_valid) %in% TRUE)
  out[[key]] <- list(num = num, den = den, success = success, items = nrow(d))
}
# minimal JSON writer (base R only)
items <- vapply(names(out), function(k) {
  v <- out[[k]]
  sprintf('"%s": {"num": %d, "den": %d, "success": %d, "items": %d}', k, v$num, v$den, v$success, v$items)
}, character(1))
cat("{", paste(items, collapse = ", "), "}\n")
