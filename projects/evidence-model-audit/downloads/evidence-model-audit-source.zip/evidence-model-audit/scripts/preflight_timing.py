"""Development-only resource preflight: latency per call by model, device, and dtype.

Uses validation-split prompts only. Writes results/preflight/timing.json.
"""
import json, sys, time, statistics
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from ema import config as C, contexts as X, data, prompts as PR
from ema.infer import GenConfig, LocalModel

model, device, dtype, n, bs = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5]) if len(sys.argv) > 5 else 1
arts, P = data.load_processed()
import hashlib
dev = P[(P.split == "validation") & P.eligible_primary].copy()
dev["h"] = [hashlib.sha256(f"preflight:{i}".encode()).hexdigest() for i in dev.prompt_id]
dev = dev.sort_values("h").drop_duplicates("pmcid").head(n)
cnt = X.TokenCounter(); bm = X.load_bm25()
gen = GenConfig(max_new_tokens=256, device=device, dtype=dtype)
t0 = time.perf_counter(); m = LocalModel(model, gen); load_s = time.perf_counter() - t0
rendered = [m.render(PR.messages(r, X.build_context(r, "retrieved", cnt, 1024, bm), "v1")) for r in dev.itertuples()]
m.generate(rendered[:1])  # warm-up, excluded
lat, recs = [], []
for i in range(0, len(rendered), bs):
    t = time.perf_counter(); g = m.generate(rendered[i:i + bs]); lat.append((time.perf_counter() - t) / len(g)); recs += g
out = {"model": model, "device": device, "dtype": dtype, "batch_size": bs, "n": len(recs), "load_s": round(load_s, 1),
       "median_s_per_call": round(statistics.median(lat), 2), "mean_s_per_call": round(statistics.mean(lat), 2),
       "mean_prompt_tokens": round(statistics.mean(r["prompt_tokens"] for r in recs)),
       "mean_gen_tokens": round(statistics.mean(r["gen_tokens"] for r in recs), 1),
       "finish": {k: sum(r["finish_reason"] == k for r in recs) for k in ("eos", "length")}, "env": m.env,
       "sample_response": recs[0]["response"][:400]}
p = C.RESULTS / "preflight" / "timing.jsonl"; p.parent.mkdir(parents=True, exist_ok=True)
with open(p, "a") as f: f.write(json.dumps(out) + "\n")
print(json.dumps(out, indent=1))
