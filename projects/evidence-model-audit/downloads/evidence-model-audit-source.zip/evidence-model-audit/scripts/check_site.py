"""Check a built static site: local links, images, anchors, and download targets resolve; report sizes.

Usage: python scripts/check_site.py <site-root> [base-url]
With a base URL (for example http://127.0.0.1:8770/), each local target is also fetched over HTTP.
"""
from __future__ import annotations

import sys
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from pathlib import Path


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.ids = [], set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.add(a["id"])
        for k in ("href", "src"):
            if k in a and a[k]:
                self.refs.append((tag, k, a[k]))


def check(root: Path, base: str | None = None) -> int:
    pages = sorted(root.rglob("*.html"))
    ids = {}
    parsed = {}
    for p in pages:
        lp = Links()
        lp.feed(p.read_text(encoding="utf-8", errors="ignore"))
        parsed[p] = lp
        ids[p.resolve()] = lp.ids
    bad = 0
    checked = 0
    for p, lp in parsed.items():
        for tag, attr, ref in lp.refs:
            u = urllib.parse.urlparse(ref)
            if u.scheme in ("http", "https", "mailto", "tel", "data", "javascript"):
                continue
            path, frag = u.path, u.fragment
            target = (p.parent / path).resolve() if path else p.resolve()
            checked += 1
            if path and not target.exists():
                print(f"MISSING  {p.relative_to(root)} -> {ref}")
                bad += 1
                continue
            if frag and target.suffix == ".html" and frag not in ids.get(target, set()):
                print(f"ANCHOR   {p.relative_to(root)} -> {ref}")
                bad += 1
            if base and path:
                url = urllib.parse.urljoin(base, str(target.relative_to(root.resolve())))
                try:
                    with urllib.request.urlopen(url, timeout=10) as r:
                        if r.status != 200:
                            print(f"HTTP {r.status} {url}")
                            bad += 1
                except Exception as e:
                    print(f"HTTPERR  {url}: {e}")
                    bad += 1
    print(f"{len(pages)} pages, {checked} local references checked, {bad} problems")
    return bad


if __name__ == "__main__":
    sys.exit(1 if check(Path(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else None) else 0)
