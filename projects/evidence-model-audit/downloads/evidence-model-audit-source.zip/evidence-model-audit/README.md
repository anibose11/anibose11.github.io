# Evidence model audit

Does a verbatim quote mean the answer is right? This project measures how often small local language models answer an Evidence Inference 2.0 question with a quote that genuinely exists in the supplied trial text while getting the reported direction of the result wrong. It reports parse validity, quote existence, locator validity, overlap with benchmark evidence, label correctness, and end-to-end success as separate quantities, and tests whether rejecting answers whose quote fails the check lowers error more than rejecting the same number of answers at random.

Results, methods, and limitations are in `manuscript/manuscript.md` (rendered as `manuscript/manuscript.html`) and the static report. The analysis plan written before any test prediction is `docs/analysis_plan.md`.

## What is in this archive

| Path | Contents |
|---|---|
| `src/ema/` | the `ema` command-line package |
| `tests/` | software tests on small synthetic fixtures |
| `config/frozen_config.json` | the inference configuration frozen on development data |
| `results/predictions/` | every recorded model and baseline response, with call metadata |
| `results/scored/` | item-level scores for each system |
| `results/analysis/results.json` | all reported numbers |
| `results/tables/`, `results/figures/` | result tables and figures (with the data behind each figure) |
| `results/contexts_public/` | supplied passages as article offsets, BM25 scores, and token budgets (text removed) |
| `evidence/claims.json` | each headline number mapped to its file, key, numerator, denominator, and run |
| `docs/` | analysis plan, contribution decision, data provenance, prior art, journal fit, dictionaries |
| `site_templates/` | templates for the static pages and handoff files that `ema package` builds |
| `examples/` | demo items from CC BY or CC0 articles, and saved study outputs for them |
| `source_manifest.json` | source URLs, versions, sizes, and checksums |

Model weights, the corpus, and article texts are not included. `ema acquire` fetches them at pinned versions.

## Setup

Python 3.11 or later. R is optional (used only for an independent recount). No GPU, paid API, or Hugging Face account is needed.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python -m pip install -e .
.venv/bin/python -m pytest -q
```

## Fast demo

The cached mode renders the study's saved outputs for the bundled examples without a model:

```bash
.venv/bin/ema demo --cached
```

The live mode downloads Qwen3-0.6B (about 1.5 GB) at its pinned revision and runs real local inference on CPU for the same examples:

```bash
.venv/bin/ema acquire --no-corpus --models qwen3-0.6b
.venv/bin/ema demo --model qwen3-0.6b --device cpu
```

Both write `demo_output.html`. The demo shows the software working on a handful of examples; it is not evidence that the full study ran.

## Full pipeline

Each stage caches its outputs and can be rerun.

```bash
.venv/bin/ema acquire      # corpus at commit a661e8c, official v2.0 tarball for reconciliation, three model snapshots
.venv/bin/ema build        # label contract, QA tables, BM25 statistics (training split only), source manifest
.venv/bin/ema devselect    # development-only prompt, decoding, and device decisions
.venv/bin/ema baselines    # majority class and TF-IDF + logistic regression per context
.venv/bin/ema infer        # frozen test runs: Qwen3-1.7B and Qwen3-0.6B (three contexts), Qwen3-4B-Instruct-2507 (retrieved)
.venv/bin/ema analyze      # separated metrics, headline estimand, rejection analysis, comparisons, sensitivity
.venv/bin/ema validate     # source reconciliation, deterministic reruns, model rerun sample, R recount, claims check
.venv/bin/ema render       # figures, workbook, Tableau exports, dictionary, manuscript
.venv/bin/ema package      # source archive, static pages, handoff files, bundle
```

`ema infer` took 2.7 hours for Qwen3-1.7B's 3,592 calls in float32 on an Apple M5 Pro GPU (MPS), about 2.7 seconds per call across the three contexts. The code also runs on CPU (`--device cpu`); in the development timing check, CPU calls took a little over twice as long as GPU calls on the same machine. `ema view` writes a local viewer for any scored run; it contains article text and is meant to stay local.

## Reproducibility notes

* Deterministic stages (build, contexts, baselines, scoring, analysis, bootstrap with fixed seeds) reproduce exactly from cached inputs; `ema validate` compares them with the stored outputs.
* Greedy decoding was selected on development data. Repeating model calls on the same machine and device gave the agreement reported in `results/validation/validation.json`; identical responses across different hardware or library versions are not guaranteed.
* Every model call is cached under a key built from the model revision, the rendered prompt, and the generation settings, so rerunning `ema infer` reuses recorded responses and only fills gaps.

## License and citation

Code: MIT (see LICENSE). Third-party data, articles, and models keep their own terms (NOTICE.md). Please cite the Evidence Inference 2.0 paper when using the benchmark (CITATION.cff).
