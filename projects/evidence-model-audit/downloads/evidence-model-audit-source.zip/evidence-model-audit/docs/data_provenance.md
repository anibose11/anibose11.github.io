# Data provenance and source reconciliation

All facts below were established on 2026-10-07 from the files themselves. Checksums are in source_manifest.json; counts computed by the build are in data/processed/build_qa.json, and the reconciliation counts against the project-site tarball (label variant, text renderings, differing offsets, and the offset sample) are recomputed by the validate stage and stored in results/validation/validation.json under source_reconciliation.

## Which release is used

* **Primary corpus:** the Evidence Inference repository (github.com/jayded/evidence-inference) at commit a661e8c14f973398380c8865cf2f27a535aaaf6d (2021-06-18). This is the current master head and is two commits after the repository's v2.0 tag (b9831b6, 2021-02-26); the only change between them is in model code (evidence_inference/models/bert_model.py). It holds the Evidence Inference 2.0 prompts, annotations, official splits, plain-text and XML article renderings, and an abstracts folder.
* **Reconciliation reference:** the tarball linked from the project site, https://evidence-inference.ebm-nlp.com/v2.0.tar.gz (Last-Modified 12 May 2020, 36,528,800 bytes), and the separately posted test answers file (answers/test_annotations_merged.csv). Neither is used for scoring.
* No official release newer than 2.0 was found. Hugging Face copies (jaydeyoung/evidence_infer_treatment, bigbio/evidence_inference) are derivatives.
* Two links in the project site's JavaScript (media/annotations_merged.cbdb3024.csv and media/prompts_merged.a58d3944.csv) return the site's HTML page with status 200. They were rejected as data.

## Repository versus project-site tarball

| Item | Result |
|---|---|
| prompts_merged.csv | byte-identical (12,865 prompts) |
| train, validation, test split files | identical (3,562, 443, and 449 article IDs; no article in two splits) |
| annotations_merged.csv rows | 24,686 in both, same order, same user, prompt, article, validity flags, Label Code, and In Abstract values |
| Label string | the tarball writes "significantly increase" in 693 rows whose Label Code is 1; the repository writes "significantly increased" |
| Text files | of the tarball's 4,454 plain-text files, 3,525 are identical to the repository's once CRLF line endings are converted; the other 929 use a different rendering, without the TITLE line and with plain section headers such as "Background" |
| Evidence offsets | 4,666 rows differ; all of them belong to 915 of the 929 articles with the different rendering |
| Test answers file | its 2,408 rows match the repository's test rows in order on user, prompt, article, Label Code, validity flags, and In Abstract; like the tarball, it uses the "significantly increase" spelling and the tarball's offsets |

Label Code is treated as authoritative and the Label string is checked against it (0 mismatches after accounting for the spelling variant).

## Offsets are half-open

The annotation README describes Evidence Start and Evidence End as inclusive. On a seeded sample of 3,000 training rows with offsets, slicing the matching text rendering with an exclusive end reproduced the annotation string exactly for 2,759 rows (repository pairing) and 2,705 rows (tarball pairing after newline normalization); an inclusive end reproduced it for none. The study therefore treats offsets as [start, end).

Annotation strings sometimes contain HTML entities (for example "&lt;" where the article has "<"), so the locator also compares the unescaped string. Location status of accepted evidence spans (all splits):

| Status | Accepted rows |
|---|---|
| exact slice | 21,473 |
| exact after whitespace normalization | 934 |
| exact at the recorded offsets after unescaping HTML entities | 685 |
| recorded offsets wrong, string found at one other position | 108 |
| as above, found only after unescaping | 75 |
| offset missing (-1), string found | 25 |
| as above, found only after unescaping | 1 |
| string found at several positions (nearest used) | 1 |
| offsets given, string not found anywhere | 29 |
| offset missing, string not found | 882 |
| article has no text | 29 |

Spans in the last three groups (940 rows) are not used as benchmark evidence. The first version of the locator kept the recorded offsets of the 789 rows whose string did not match the text at those offsets; analysis plan amendment A3 replaced that with the rule above. The README notes that about 2% of v1.1 offsets were set to -1.

## The abstracts folder is not uniformly abstracts

Of the 3,285 files in annotations/abstracts at the pinned commit, 2,334 contain body sections (BODY headers and full text in a different rendering) and 951 contain only a title and abstract. The abstract-only condition therefore does not use these files. It uses the title-plus-abstract region of the same plain-text rendering that the offsets refer to: from offset 0 to the first BODY header that follows an ABSTRACT header, kept when the region holds at least 200 characters of content. Section headers are whole lines ending in a colon, sometimes indented or with a doubled colon; titles sometimes share the TITLE line. Status of this region for the 334 test articles with prompts: 319 delimitable, 11 with no ABSTRACT header, 2 with no BODY header after the abstract, 1 too short, and 1 with no text (PMC2206488, below). For the 818 abstract-only files whose article also had a delimitable region, 745 matched that region exactly after header lines were removed and whitespace collapsed (computed in the build; see build_qa.json).

## Missing and very short texts

One test article, PMC2206488, has an empty plain-text file in both the repository and the project-site tarball, although its XML file exists. Because evidence offsets refer to the plain-text rendering, its 6 eligible prompts are treated as having no text and are excluded (analysis plan amendment A2). Fourteen other articles have texts shorter than 500 characters (twelve in training, one in validation, PMC4721016, and one in the test split, PMC2423497); none of them has a prompt in the corpus, so none enters any analysis.

## Article identity and overlap

* No article ID appears in two splits.
* No two article texts are byte-identical.
* No pair of articles has TF-IDF cosine similarity of 0.9 or more over their first 4,000 characters (data/interim/near_duplicate_pairs.csv is empty).
* Apparent duplicate titles across splits come from titles truncated at inline markup in the text rendering (for example "Effect of"). One genuine same-title pair (PMC4423288 and PMC4424865) is entirely within the training split.
* 29 prompts in 24 articles belong to no split and are not used.

## Label contract counts

Per split: prompts, then label status (unanimous accepted label / accepted labels disagree / no accepted annotation / no annotation).

| Split | Prompts | Unanimous | Disagree | No accepted | None | Primary eligible |
|---|---|---|---|---|---|---|
| train | 10,326 | 10,100 | 16 | 34 | 176 | 10,030 |
| validation | 1,258 | 1,236 | 1 | 1 | 20 | 1,231 |
| test | 1,252 | 1,221 | 3 | 4 | 24 | 1,209 |

Primary eligibility also removes prompts on the corpus authors' "Incorrect" list (71 training, 5 validation, 6 test prompts) and prompts whose article has no usable text (6 test prompts). The test split has no prompts on the "Questionable" or "Somewhat malformed" lists, so sensitivity analysis S3 cannot differ from the primary analysis on test data.

## Article licenses and what the public files contain

Article texts come from the PubMed Central Open Access subset and keep their own licenses; the repository's MIT license covers code only. The NCBI PMC OA web service that used to report per-article licenses was retired in 2026 (its legacy endpoint returned HTTP 404 on 2026-10-07), so licenses were taken from the Europe PMC REST API `license` field (data/interim/licenses_europepmc.json). For the 674 validation and test articles with prompts: CC BY 354, CC0 6, CC BY-NC 141, CC BY-NC-SA 75, CC BY-NC-ND 62, none reported 36.

No full article text is redistributed. The demonstration examples and the public prediction viewer show passages only from CC BY or CC0 articles, with attribution. The prediction and scored files in the source archive are needed to reproduce every reported number, and they contain short quotations from articles under all of the licenses above: the sentence or phrase each model returned as its evidence quote, and, for the two baselines, the single supplied passage returned as the quote (at most 60 words in the retrieved context; a full title or abstract paragraph in the abstract context; a merged evidence span in the oracle context). Each record carries its PubMed Central identifier, and the license of every article is listed in licenses_europepmc.json. The context files in the archive hold passage offsets and scores without text.
