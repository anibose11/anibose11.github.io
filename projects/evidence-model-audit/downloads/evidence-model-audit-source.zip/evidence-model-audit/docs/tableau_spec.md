# Tableau import and interaction specification

A Tableau workbook was not built or tested. These files are prepared for import.

File: `tableau-system-metrics.csv` in the site downloads (`results/tables/tableau_system_metrics.csv` in the source archive); one row per system x condition x scope x metric.

* Grain: one precomputed estimate. Columns: system, condition, scope, metric, numerator, denominator, estimate, ci_low, ci_high, unit, suppressed.
* Units: estimate, ci_low, ci_high are proportions from 0 to 1; numerator and denominator are counts of prompts.
* Confidence bounds: 95% percentile intervals from 10,000 article-level bootstrap resamples. They cannot be recombined.
* Suppression: `suppressed` is true when the denominator is 0 (estimate undefined). No small-cell suppression is needed because no person-level data are involved.
* Permitted filtering: filter rows by system, condition, scope, or metric only. Do not aggregate, sum, or average estimates across rows, and do not recompute a rate from filtered numerators and denominators across systems or conditions: rows come from different, overlapping prompt sets, and intervals are cluster-bootstrap results.
* Suggested views: (1) dot-and-interval of metric = qvwr by system, coloured by system and faceted by condition; (2) bars of metric = task_success with interval whiskers; (3) a filter on scope.
