# Error taxonomy

Categories are assigned by fixed rules from the scored fields. They are not expert judgments and do not add labels to the benchmark.

## Answer outcome (every eligible prompt)

| Outcome | Rule |
|---|---|
| invalid output | the response does not parse as one JSON object matching the schema, or the call failed |
| abstained | parse-valid, label "cannot determine" |
| correct with an existing quote | answered, quote exists (definition Q), label equals the benchmark label |
| existing quote, wrong label | answered, quote exists, label differs from the benchmark label |
| label right, quote not found | answered, quote does not exist, label correct |
| label wrong, quote not found | answered, quote does not exist, label wrong |

End-to-end task success additionally requires a valid locator (the returned passage ID holds the quote).

## Wrong labels with an existing quote

| Error type | Rule |
|---|---|
| significance error (model said significant) | benchmark label is "no significant difference"; model said increased or decreased |
| significance error (model said not significant) | model said "no significant difference"; benchmark label is increased or decreased |
| direction reversal | benchmark and model labels are "significantly increased" and "significantly decreased" in either order |

Each is crossed with the quote's relation to benchmark evidence:

| Evidence relation | Rule |
|---|---|
| quote overlaps benchmark evidence | the located quote shares at least one character with an accepted evidence span |
| quote outside benchmark evidence | no overlap with any located accepted span |
| benchmark evidence not located | the prompt has no locatable accepted span |

A direction reversal with a quote that overlaps the benchmark evidence is consistent with misinterpreting relevant text. It does not establish how the model reached its answer: overlap can be as small as one character, and benchmark annotations may be incomplete or wrong.
