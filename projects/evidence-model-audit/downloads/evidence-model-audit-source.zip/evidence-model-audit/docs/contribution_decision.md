# Contribution decision

Written 2026-10-07, after the literature and software search (docs/research/search_log.csv, 116 recorded searches) and before any test-split model prediction. The analysis plan (docs/analysis_plan.md, first written 09:50 UTC) was drafted while the search was running; reading the prior work did not change its estimand, eligibility rules, or decision rules.

## Who could use the output

People who build or audit tools that extract trial results with language models and then check the answers by matching the cited text against the source: systematic-review and evidence-synthesis teams, clinical informatics groups evaluating local models where documents cannot leave the institution, and developers of evaluation harnesses.

## Decision it supports

Whether a passing verbatim-quote check can be read as evidence that an extracted comparative result is correct, and whether rejecting answers that fail the check is worth the coverage it costs for small local models.

## What is already established

* A citation or quote can be genuinely present while the answer is wrong. General-domain work on attribution separates attribution from correctness (Rashkin et al. 2023; Bohnet et al. 2022; Liu et al. 2023; Menick et al. 2022), and clinical work reports high verbatim compliance with much lower claim support.
* On Evidence Inference itself, Elbakian and Carton (AAAI 2025) asked GPT-4 and Gemini for a JSON label with quoted evidence, checked quotes by substring match, and found that a quarter or more of errors with valid quotes were misreadings of good evidence. Their analysis used 300 development items and frontier models.
* Windisch et al. (Cureus 2026) reported mechanical quote validity and label correctness as separate metrics, with an abstain option, on trial eligibility criteria, and found that filtering on validity barely changed macro-F1.
* Buchmann et al. (EMNLP 2024) showed on long-document tasks including Evidence Inference that an NLI-based attributability signal orders answers better than random for selective prediction.
* Li (arXiv preprint, 4 October 2026) fine-tuned Qwen3-4B-Base for Evidence Inference 2.0 and reported calibrated probabilities on the test split (1,218 prompts in 333 articles).

## Narrow unresolved question

For prompted local instruction models of 0.6B to 4B parameters, answering Evidence Inference 2.0 prompts with a structured label and a verbatim quote, how often is the quote present in the supplied source while the direction label is wrong, across a fixed-budget retrieval context, an abstract-only context, and an expert-evidence oracle? And does rejecting answers whose quote fails the check lower error more than rejecting the same number of answers at random?

No verified record reports this joint rate over the full test split for models of this size, keeps format validity, quote validity, and direction correctness as separate metrics across these three contexts, or compares a fixed quote-validity rule with coverage-matched random rejection.

## Comparators

* Majority class and a TF-IDF + logistic regression model trained on the training split. The TF-IDF baseline returns the top-ranked supplied passage as its quote, so it passes the quote check for almost every prompt (it fails only when that passage is shorter than four words); it shows how little the check says on its own. It is a variant of the bag-of-words baselines in Lehman et al. (2019), not a replication.
* Coverage-matched random rejection, as a diagnostic.
* Lower and higher capacity models from the same family, and the oracle context as an upper bound on evidence access.

## Estimand

The quote-valid wrong-direction rate (docs/analysis_plan.md, section 2) for Qwen3-1.7B in the retrieved condition, with its numerator, denominator, per-class counts, and an article-clustered interval.

## Framing

This is an independent measurement that extends Elbakian and Carton (2025) and Windisch et al. (2026) to small local models, full-text retrieval, and the full official test split, released with a reusable evaluation harness. Quote-valid but direction-wrong answers are not a new failure mode and will not be described as one. Recent preprints among the closest work (Li 2026 and several clinical citation studies) are cited as preprints and no central claim rests on them.

## What counts as a useful negative result

If quote-valid answers are often wrong, the result shows precisely what a quote check does not establish. If the quote-validity rule is no better than random rejection at the same coverage, that is reported as the finding. A small or null difference is acceptable; an unsupported claim is not.

## Not claimed

No claim of being first, no claim about clinical benefit or harm, no claim about larger or proprietary models, and no claim that exact-quote presence measures entailment.
