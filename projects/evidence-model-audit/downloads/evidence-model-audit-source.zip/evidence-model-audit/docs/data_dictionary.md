# Data dictionary

Source-to-analysis fields. Offsets are character offsets into the pinned repository's plain-text article rendering, half-open [start, end).

| File | Field | Meaning |
|---|---|---|
| `data/processed/articles.csv` | `pmcid` | PubMed Central article number (identifier used by the corpus) |
| `data/processed/articles.csv` | `split` | official split: train, validation, test, or unassigned |
| `data/processed/articles.csv` | `abstract_status / abstract_end` | whether a title-plus-abstract region was delimited, and its end offset |
| `data/processed/articles.csv` | `abst_file_contains_body` | the repository's .abst file contains BODY sections |
| `data/processed/prompts.csv` | `prompt_id` | corpus PromptID (stable key) |
| `data/processed/prompts.csv` | `intervention, comparator, outcome` | prompt fields as distributed |
| `data/processed/prompts.csv` | `label_status` | unanimous, accepted_disagreement, no_accepted_annotation, no_annotation |
| `data/processed/prompts.csv` | `gold_label` | benchmark label when label_status is unanimous; empty otherwise |
| `data/processed/prompts.csv` | `accepted_labels` | JSON list of distinct accepted labels |
| `data/processed/prompts.csv` | `gold_spans` | JSON list of located accepted evidence spans [start, end) in article text offsets |
| `data/processed/prompts.csv` | `flag` | corpus authors' list: incorrect, questionable, malformed, or empty |
| `data/processed/prompts.csv` | `eligible_primary` | meets the primary eligibility rule |
| `data/processed/annotations.csv` | `accepted` | Valid Label = 1, Valid Reasoning = 1, non-empty evidence, label not 'invalid prompt' |
| `data/processed/annotations.csv` | `span_start, span_end, span_status` | located evidence span and how it was located |
| `results/contexts/*.jsonl` | `passages` | supplied passages: pid, start, end (article offsets), text, section, BM25 score |
| `results/contexts/*.jsonl` | `budget_tokens, context_tokens, truncated` | token budget, tokens used (Qwen3 tokenizer), whether truncated |
| `results/predictions/**.jsonl` | `response, finish_reason, prompt_tokens, gen_tokens, latency_s` | raw model output and call metadata |
| `results/predictions/**.jsonl` | `cache_key, rendered_sha256, revision, gen_config, env` | provenance of each call |
| `results/scored/**.csv` | `parse_status` | valid, schema_error, invalid_json, no_json_object, empty, runtime_error, not_run |
| `results/scored/**.csv` | `quote_exists, quote_exists_strict, locator_valid, gold_overlap, gold_token_f1` | separated validity checks (see definitions) |
| `results/scored/**.csv` | `label_pred, label_correct, task_success` | predicted label and correctness |

## Metric definitions

| Field | Unit | Definition |
|---|---|---|
| `items` | count | Eligible test prompts in the analysis population (unanimous accepted benchmark label, not on the corpus 'Incorrect' list). |
| `parse_valid` | count | Responses that parse as one JSON object matching the answer schema (code fences stripped; no other repair). |
| `abstained` | count | Parse-valid responses with label 'cannot determine'. Not the same as 'no significant difference'. |
| `answered` | count | Parse-valid responses that did not abstain. |
| `quote_exists` | count | Answered prompts whose quote, after collapsing whitespace, is a substring of one supplied passage and has at least 4 words. |
| `quote_exists_strict` | count | Answered prompts whose quote is an exact substring of the passages as displayed to the model, any length (sensitivity S1 adds the 4-word minimum). |
| `locator_valid` | count | Answered prompts whose returned passage ID names a supplied passage containing the quote. |
| `gold_overlap` | count | Answered prompts whose located quote overlaps an accepted benchmark evidence span by at least one character. |
| `label_correct` | count | Answered prompts whose label equals the benchmark label. |
| `task_success` | count | Answered, quote exists, locator valid, and label correct. Denominator: all items. |
| `qvwr` | proportion | Label-error rate among quote-valid answers: label_wrong / answered prompts with an existing quote. |
| `ci_low, ci_high` | proportion | 95% percentile interval from 10,000 bootstrap resamples of articles (seed 20261007). |
| `coverage` | proportion | Retained answers / items. |
| `macro_f1` | proportion | Mean F1 over the three benchmark classes; abstentions and invalid outputs count as a wrong 'no answer'. |
| `retained_error` | proportion | Wrong labels / retained answers under a rejection policy. |
| `random_*` | proportion | Coverage-matched random rejection: 2,000 seeded draws keeping the same number of answered prompts. |
