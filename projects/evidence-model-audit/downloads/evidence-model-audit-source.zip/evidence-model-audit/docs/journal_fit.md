# Journal fit

Checked 2026-10-07 on the publishers' current pages. No impact factors, acceptance likelihoods, deadlines, or reviewer interest are estimated here. Policies change; recheck each page before submission.

## Recommended target: JAMIA Open (Oxford University Press for AMIA)

* Scope and article type. Data science and evaluation work in biomedical informatics are in scope. A Research and Applications paper allows 4,000 words (excluding acknowledgments, references, and supplements), a structured abstract of up to 250 words (Objectives, Materials and Methods, Results, Discussion, Conclusion), 4 tables, and 6 figures. A lay summary of up to 200 words and alt text for each figure are required. Source: https://academic.oup.com/jamiaopen/pages/General_Instructions
* Charges. Gold open access; open access charge USD 3,625 (subject to change and taxes), 20% discount for AMIA members. Same source.
* Required statements. Funding (or a statement of none), conflicts of interest, CRediT author roles at submission, and ethics approval only for research with human participants or their data. Data deposit with persistent identifiers is encouraged.
* Reporting guidelines. None required for a benchmark evaluation. A voluntary TRIPOD-LLM checklist (Gallifant et al., Nature Medicine 2025) is included as a supplement.
* Closest published comparisons in this journal (none uses Evidence Inference): Weyrich et al. 2026, abstract versus full text as inputs for LLM classification of oncology trial eligibility criteria (doi:10.1093/jamiaopen/ooag179); Stenzl et al. 2026, faithfulness of LLM summaries of oncology literature (doi:10.1093/jamiaopen/ooag078); de Oliveira et al. 2025, calibration of LLMs in biomedical NLP (doi:10.1093/jamiaopen/ooaf058).
* Why it fits. The study is a focused evaluation with one primary error quantity, three context conditions, and a rejection analysis against a random control; the readership builds and evaluates evidence tools.
* Remaining scientific objections to expect. (1) External validity: one public benchmark and small models. (2) The 4,000-word limit pushes model and sensitivity detail into supplements. (3) Precise definition of a valid quote (normalization, minimum length, locator) and its relation to benchmark evidence. (4) Label noise in Evidence Inference and possible pretraining exposure of the public benchmark. (5) Whether a lexical retrieval budget of 1,024 tokens is representative of deployed retrieval.

## Second choice: BMC Medical Informatics and Decision Making (Springer Nature)

* Scope and article type. Evaluation and machine learning are explicitly in scope; decisions rest on scientific soundness rather than perceived impact. Research articles have no main-text word limit; abstract up to 350 words (Background, Methods, Results, Conclusions). Source: https://link.springer.com/journal/12911/submission-guidelines/research-article
* Charges. Gold open access; APC USD 3,090 (GBP 2,390, EUR 2,690) plus applicable taxes; financial-need waivers are considered only if requested at submission. Source: https://link.springer.com/journal/12911/submission-guidelines
* Required statements. A Declarations section with Ethics approval and consent to participate, Consent for publication, Availability of data and materials, Competing interests, Funding, Authors' contributions, and Acknowledgements, each marked "Not applicable" where relevant. Custom code must be available, with an archived version carrying a DOI.
* Closest published comparisons in this journal: Karkera et al. 2025, MelAnalyze, LLM plus NLI checking of claims against PubMed evidence (doi:10.1186/s12911-025-03291-2); Hussain et al. 2024, TECRR benchmark with TF-IDF and LLM baselines (doi:10.1186/s12911-024-02717-7).
* Remaining objections. The same as above, plus the requirement for a DOI-archived code release, which this project does not have yet.

## Considered and not chosen

* Journal of Biomedical Informatics (Elsevier). Its scope asks for a novel method with substantial advance and expects clinician involvement; this study is an evaluation. Subscription publication has no charge (optional open access APC USD 3,550). The Guide for Authors page could not be read directly (HTTP 403), so its limits were not verified.
* JMIR Medical Informatics. Its scope asks AI papers to show utility beyond performance on static datasets. APC USD 2,750.
* Journal of Open Source Software. Not eligible now: JOSS requires at least six months of public development history with releases, issues, and pull requests before submission (https://joss.readthedocs.io/en/latest/submitting.html), and this code has no public repository.

## Submission status

Not submitted. A preprint, repository deposit, or DOI has not been created.
