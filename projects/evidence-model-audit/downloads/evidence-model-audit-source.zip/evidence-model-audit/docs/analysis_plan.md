# Analysis plan

Written 2026-10-07, first written to disk at 09:50 UTC, before any test-split model prediction was generated and before any test-split outcome label or evidence span was viewed. This is an internal, timestamped plan kept with the project files. It is not a formal preregistration in a public registry.

## 1. Prior exposure

Before writing this plan I had:

* read the corpus documentation and the corpus authors' preprocessing code;
* profiled the training and validation splits (label distribution, annotation counts per prompt, verifier acceptance, disagreement, offset alignment);
* viewed test-split article identifiers, the number of test prompts (1,252) and articles with prompts (334), and the availability of a delimitable abstract for test articles (319 of 334);
* run a development-only timing check on 8 validation prompts per model configuration and read one sample response per run.

I had not viewed any test-split label, label distribution, evidence string, or evidence offset, and no model had been run on a test prompt.

## 2. Question and estimand

**Primary question.** When a small local instruction model answers an Evidence Inference prompt with a structured answer that includes a verbatim quote, how often is the quote genuinely present in the supplied source while the direction label is wrong?

**Primary estimand: quote-valid wrong-direction rate (QVWR).** Population: eligible test prompts (section 4) answered by Qwen3-1.7B in the retrieved-context condition. Among answers that (a) parse under the schema, (b) do not abstain, and (c) contain a quote that exists in the supplied passages (section 8, definition Q), QVWR is the proportion whose label differs from the benchmark label.

* Numerator: quote-valid answers with a wrong label.
* Denominator: quote-valid answers.
* Reported with per-class counts (by benchmark label and by predicted label) and a 95% article-clustered percentile bootstrap interval (10,000 resamples of articles with replacement, seed 20261007).
* If the denominator is zero, QVWR is reported as undefined, not as zero.

The unit of analysis is the prompt (one intervention, comparator, outcome question). Prompts are nested in articles, and all uncertainty intervals resample articles.

## 3. Label contract

* An annotation row is accepted when Valid Label = 1, Valid Reasoning = 1, its evidence string is non-empty, and its label is not "invalid prompt". This matches the filter in the corpus authors' preprocessing code.
* Label Code is authoritative. The Label string is checked against it. (The official v2.0 tarball spells one label "significantly increase" in 693 rows; the pinned repository commit spells it correctly; Label Code agrees in both.)
* A prompt's benchmark label is the label shared by all of its accepted annotations ("unanimous"). Prompts whose accepted annotations disagree keep all labels and are excluded from the primary analysis; sensitivity analysis S2 includes them.
* Benchmark evidence is the set of all accepted evidence spans after offset location (half-open offsets, see docs/data_provenance.md). Spans that cannot be located are reported and not imputed.
* "Significantly increased" and "significantly decreased" describe the value of the outcome measure relative to the comparator, not clinical benefit or harm. "No significant difference" is a reported absence of statistical significance; it is not evidence of equivalence and it is not an abstention. The model schema has a separate abstention value ("cannot determine"), and the scorer never maps abstention onto "no significant difference".

## 4. Eligibility

Primary eligible set (per split): prompts whose article is in that official split and has text, with non-empty intervention, comparator, and outcome, a unanimous accepted label, and not on the corpus authors' "Incorrect" list. Prompts on the "Questionable" and "Somewhat malformed" lists stay in the primary set (sensitivity S3 removes them). Prompts with no annotation or no accepted annotation have no benchmark label and are not scored.

## 5. Test sample

All 334 test-split articles with at least one prompt form the frozen evaluation sample. No subset is drawn. Articles are processed in ascending order of SHA-256("ema-2026-10-07:" + PMCID), a fixed order that does not depend on labels.

Model items are every prompt in these articles that is in the primary eligible set or has accepted-label disagreement. Abstract-condition items are restricted to articles with a delimitable abstract; oracle-condition items to prompts with at least one located evidence span.

Runtime bounds, fixed from the development timing check (Qwen3-1.7B about 3.6 s per call on this machine):

* Qwen3-1.7B, all three conditions: up to 6 hours. If exceeded, the run stops at a whole-article boundary and the analysis uses the completed prefix in the fixed order, reported as such. At least 100 articles are required for the planned comparison; otherwise the study is labelled a limited benchmark.
* Qwen3-0.6B, all three conditions, run after Qwen3-1.7B: up to 3 hours, same rule.
* Qwen3-4B-Instruct-2507, retrieved condition only, run last: up to 3 hours, whole articles in the same order. Model comparisons are paired on exactly the prompts both models completed.

The primary model will not be replaced after test results are seen. If Qwen3-1.7B could not run, the scope would be reduced to Qwen3-0.6B before any test output was inspected and labelled a limited small-model evaluation.

## 6. Development-only decisions (fixed rules)

The development sample is the first 100 validation articles in SHA-256("ema-dev-2026-10-07:" + PMCID) order and all of their primary-eligible prompts. These decisions use Qwen3-1.7B in the retrieved condition only.

1. **Prompt variant.** v1 (instructions and label definitions) and v2 (v1 plus one invented example) are both run. The variant with higher end-to-end task success is kept; if the two differ by less than 2 percentage points, v1 is kept.
2. **Decoding.** Greedy decoding is primary because it is deterministic. The model card's recommended non-thinking sampling settings are run on the same prompts with a fixed seed. Sampling replaces greedy only if greedy's invalid-output rate exceeds sampling's by 5 percentage points or more.
3. **Output length.** max_new_tokens = 256. If more than 2% of development outputs stop at the length limit, the limit is raised to 384 before any test run.
4. **Device parity.** Float32 inference on the Apple GPU (MPS) is compared with float32 on CPU for 40 development prompts. If label agreement is below 95%, the test runs use CPU and the runtime bounds in section 5 apply unchanged.
5. **Risk-coverage scoring rule.** A logistic regression on observable answer features (quote exists, locator valid, log quote length in words, quote contains a p-value or significance wording, agreement between significance wording in the quote and the predicted label, token overlap between quote and outcome text) is fitted on development predictions and applied unchanged to test predictions. Model self-reported confidence is not used and is not treated as a probability.

Baseline hyperparameters (inverse regularization C in {0.1, 1, 10}, class weighting none or balanced) are chosen on validation macro-F1 with models trained on the training split only.

## 7. Methods compared

* **Majority class**: the most frequent training-split label.
* **TF-IDF + logistic regression**, one model per context condition, trained on training-split prompts with the same context construction as at test time. Features: TF-IDF of the context passages (word unigrams and bigrams, sublinear tf) concatenated with TF-IDF of the intervention, comparator, and outcome text. Its evidence quote is the highest-ranked supplied passage. The baseline is reported on the same items as the model and, separately, on the full official test split.
* **Local instruction models**: Qwen3-1.7B (primary), Qwen3-0.6B (lower-capacity comparison), Qwen3-4B-Instruct-2507 (extension, retrieved condition only). Pinned revisions are in src/ema/config.py. Each model's documented chat template is used, with thinking disabled for the two hybrid models (enable_thinking=False).

## 8. Context conditions

* **Retrieved**: BM25 (k1 = 1.2, b = 0.75, IDF from training-split chunks only) over sentence-packed chunks of at most 60 words, queried with intervention, comparator, and outcome text only. Chunks are added in score order until 1,024 Qwen3 tokens are filled, then shown in article order. Development evidence recall at this budget (any overlap with a benchmark span) was 0.764 at 1,024 tokens, against 0.577 at 512 and 0.844 at 1,536.
* **Abstract**: the title-plus-abstract region of the same article text (offset 0 to the first BODY header after an ABSTRACT header), split into paragraphs, truncated at 1,024 tokens.
* **Oracle**: the accepted benchmark evidence spans for the prompt, merged where they overlap. This is an upper bound, not a deployable method.

Output limits are identical across conditions. Context lengths differ by design and are reported.

## 9. Separated validity checks

For each answer:

* **Parse validity**: one JSON object matching the schema (label in the four allowed values, string quote, passage ID string or null). Markdown code fences are stripped before parsing; no other repair is attempted.
* **Abstention**: label "cannot determine".
* **Quote existence (definition Q, primary)**: the quote, after collapsing whitespace, is a substring of at least one supplied passage after collapsing whitespace, and has at least 4 words. Strict existence (exact substring of the passages as displayed) is reported as sensitivity S1.
* **Locator validity**: the returned passage ID names a supplied passage that contains the quote.
* **Benchmark evidence overlap**: the located quote overlaps an accepted evidence span by at least one character; mean token F1 against the best-matching span is also reported. Overlap can miss other valid evidence and is not proof of factuality.
* **Direction-label correctness**: predicted label equals the benchmark label, among answered prompts.
* **End-to-end task success**: parse valid, not abstained, quote exists, locator valid, and label correct. The denominator is every item, including runtime failures and invalid outputs.

An existing quote is a syntactic support check. It is not treated as entailment, and a valid record is not treated as a correct one.

## 10. Secondary analyses

* Macro-F1 over the three benchmark classes and per-class precision and recall, with abstentions and invalid outputs counted as wrong (a fourth "no answer" prediction).
* Abstention rate and coverage.
* Retrieval evidence recall at the actual budget (any overlap; full containment of at least one span).
* Invalid-output rates by type.
* **Quote-validity rejection rule**: on the same predictions, the unfiltered policy accepts every answered prompt; the filtered policy accepts only answered prompts with an existing quote and valid locator. For each, report retained error (wrong / accepted), coverage (accepted / all items), and lost coverage. A coverage-matched random rejection comparator keeps the same number of answered prompts uniformly at random (2,000 draws, seed 20261007); its mean retained error, 2.5th to 97.5th percentiles, and the share of draws with error at or below the filtered policy are reported as a diagnostic, not as a deployable method. Conditional error is never compared across differently selected subsets as an overall improvement.
* Paired article-bootstrap intervals for differences between conditions (on prompts available in both) and between models (on prompts both completed).
* Risk-coverage curve for the development-fitted scoring rule on test predictions, with area under the curve compared with random ordering.

## 11. Sensitivity analyses (fixed set)

* S1: strict quote existence in place of definition Q.
* S2: include accepted-disagreement prompts; a label counts as correct if it matches any accepted label.
* S3: exclude prompts on the Questionable and Somewhat malformed lists.
* S4: minimum quote length of 1 word instead of 4.
* S5: restrict the retrieved condition to prompts whose supplied passages overlap benchmark evidence.

## 12. Error taxonomy

Quote-valid wrong-direction answers are assigned automated categories from the label pair and evidence overlap: significance error (significant versus not significant), direction reversal (increased versus decreased), and whether the quote overlaps benchmark evidence. These are rule-based categories, not new expert labels. Source excerpts are provided for inspection.

## 13. Missing data and failures

No imputation. Runtime errors and invalid outputs stay in end-to-end denominators. Conditional metrics state their denominators. Unlocatable evidence spans and unavailable abstracts are counted and reported.

## 14. Interpretation limits

Evidence Inference 2.0 is public and may be in the pretraining data of the evaluated models; a clean train and test split does not rule this out. Results for 0.6B to 4B parameter models are not evidence about larger or proprietary systems. Associations between answer features and correctness are descriptive.

## 15. What would count as a useful negative result

If quote-valid answers are rarely wrong, the quote check is informative for these models and this task. If they are often wrong, the check does not establish answer correctness. Either result is reported. A filter that lowers error mostly by discarding answers, with error no lower than random rejection at the same coverage, would be reported as uninformative.

## Amendments

**A1, 2026-10-07 13:51 UTC (after the primary model's test outputs were scored).** Sensitivity analysis S1 is clarified to mean exact substring matching with the same 4-word minimum as definition Q. As first coded, S1 used exact matching with no length minimum, so short exact quotes made the "strict" count larger than the primary count in the oracle condition (995 against 984), which is the opposite of a stricter check. The descriptive count of exact-substring quotes of any length is still reported in the tables as "quote exists (strict, any length)". No other estimand, rule, or threshold changed.

**A2, 2026-10-07 15:01 UTC (found while building demonstration examples from scored test outputs).** The eligibility rule requires article text. The first build tested only whether each plain-text file existed, and one test article (PMC2206488) has an empty plain-text file in both the repository and the project-site tarball, although its XML file exists. Its 6 eligible test prompts were run with an empty retrieved context. They are now treated as having no text, are excluded from every analysis, and are reported as unavailable full text; their recorded responses stay in the archive. No training or validation article is affected, so development decisions and baselines are unchanged.

**A3, 2026-10-07 15:25 UTC (from an internal review after the primary and lower-capacity test runs).** The plan says unlocatable evidence spans are not imputed. The first span locator kept the recorded offsets of accepted annotations whose string did not match the text at those offsets and could not be found elsewhere (789 accepted rows across splits). Checking them showed that most differ only by HTML entities in the annotation string (for example "&lt;" for "<"). The locator now also compares the unescaped string: 685 rows match at their recorded offsets, 76 are found at a different position and relocated, and 29 still cannot be found and are no longer used as evidence. In the test split this changed the evidence spans of 14 eligible prompts, one of which no longer has a located span. Oracle contexts were rebuilt, the oracle condition was re-run for prompts whose passages changed (all other responses are reused from the cache), the deterministic baselines were retrained, and all analyses were recomputed. Labels, eligibility, and the retrieved and abstract contexts are unchanged.

**Implementation notes, recorded 2026-10-07 15:33 UTC.** Two details of the code frozen before the test runs were not stated in the plan's text: the abstract region is used only when it holds at least 200 characters of content (one test article fell below this), and the parser accepts text after the first valid JSON object, which affected a handful of responses (counted in the manuscript). Neither was changed after test outputs were seen.

