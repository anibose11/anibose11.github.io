# Verbatim evidence quotes and answer correctness: an evaluation of small local language models extracting clinical trial results

**Animesh Bose**

Norlowe Research


Article type: Research and Applications. Keywords: large language models; evidence synthesis; randomized controlled trials; information extraction; selective prediction.

## Abstract

**Objectives:** Language-model tools that extract trial results can be checked by confirming that a quoted sentence appears in the source. This study measured how often small local models give a genuine quote with a wrong result and whether rejecting failed checks reduces error.

**Materials and Methods:** Qwen3-1.7B and Qwen3-0.6B, run locally, answered {{qwen317b_retrieved_items}} eligible Evidence Inference 2.0 test prompts from retrieved passages (1,024 tokens) and, where available, the abstract and annotated evidence; Qwen3-4B-Instruct-2507 used retrieved passages. Answers gave a direction label, a verbatim quote, and a passage identifier. Parse validity, quote existence, locator validity, evidence overlap, and label correctness were scored separately.

**Results:** For Qwen3-1.7B with retrieved passages, {{qwen317b_retrieved_quote_frac}} answers quoted the source verbatim; {{qwen317b_retrieved_qvwr_numerator}} of these ({{qwen317b_retrieved_qvwr_pct}}; {{qwen317b_retrieved_qvwr_ci}}) had the wrong label, mostly reporting significance the trial did not find. With annotated evidence, {{qwen317b_oracle_qvwr_pct}} were wrong. With retrieved passages, the rate was {{qwen306b_retrieved_qvwr_pct}} for Qwen3-0.6B and {{qwen34binstruct2507_retrieved_qvwr_pct}} for Qwen3-4B-Instruct-2507. Keeping only answers with a valid quote and passage identifier changed error by {{qwen317b_retrieved_rej_diff}} as coverage fell from {{qwen317b_retrieved_rej_cov_unf}} to {{qwen317b_retrieved_rej_cov_flt}}, no better than random rejection ({{qwen317b_retrieved_rej_rand}}).

**Discussion:** A present quote confirmed copying but did not show that the label followed from the text. Qwen3-4B-Instruct-2507, a later release, erred less overall, yet the rule again did no better than random.

**Conclusion:** For these small models, passing a quote-presence check did not show that an extracted trial result was correct; the label needs a separate check.

## Lay summary

Artificial intelligence tools that read clinical trial reports often show a quotation beside each answer. A program can confirm that the quotation appears in the report, but does that mean the answer is right? Small language models running locally answered {{qwen317b_retrieved_items}} questions about published trials. Each question asked whether an outcome was significantly higher, significantly lower, or not significantly different with one treatment than with another. Experts had already answered the questions. Among answers with a quotation found in the article, close to half were wrong for the main model and about one in five for the largest model. The most common mistake was reporting a statistically significant difference when the trial found none. For the main model, discarding answers whose quotations could not be found removed many answers without making those retained more accurate. A quotation's presence confirms copying, not that the answer follows from the text. People using these tools still need to check what the quoted evidence supports.

{{background}}

{{methods}}

## Results

### Output validity and evidence availability

The test split contains {{n_test_prompts}} prompts in {{n_test_articles}} articles; {{n_test_eligible}} prompts in {{qwen317b_retrieved_articles}} articles met the eligibility rule after the exclusions listed in Supplementary S1. In the retrieved context, {{qwen317b_retrieved_parse_frac}} responses parsed under the schema and {{qwen317b_retrieved_abstain_frac}} abstained, leaving {{qwen317b_retrieved_answered}} answered prompts (Table 1). The retrieved passages overlapped annotated evidence for {{recall_retrieved_any_frac}} prompts with locatable evidence ({{recall_retrieved_any}}); the title and abstract did so for {{recall_abstract_any_frac}} ({{recall_abstract_any}}).

**Table 1.** Separated validity checks by context and system, eligible test prompts. Percentages for quote existence, locator validity, and label correctness are of answered prompts; task success is of all prompts. Baselines return the top-ranked passage as their quote.

{{table_main}}


Among answered prompts, the quote existed in the supplied passages for {{qwen317b_retrieved_quote_frac}} ({{qwen317b_retrieved_quote}}), the returned passage identifier pointed to the passage holding it for {{qwen317b_retrieved_locator_frac}}, and the located quote overlapped annotated evidence for {{qwen317b_retrieved_gold_frac}} prompts with evaluable evidence (mean token F1 against the best-matching span, {{qwen317b_retrieved_token_f1}}). The label was correct for {{qwen317b_retrieved_acc_frac}} ({{qwen317b_retrieved_acc}}). End-to-end success (an answer, existing quote, valid locator and correct label) was {{qwen317b_retrieved_success_frac}} ({{qwen317b_retrieved_success}}; Figure 1).

### Quote-valid answers with wrong labels

Of the {{qwen317b_retrieved_qvwr_denominator}} answers whose quote existed, {{qwen317b_retrieved_qvwr_numerator}} carried the wrong label ({{qwen317b_retrieved_qvwr_pct}}; {{qwen317b_retrieved_qvwr_ci}}; Figure 2). Answered prompts without an existing quote were wrong about as often ({{qwen317b_retrieved_noquote_wrong}}). The rate depended strongly on the benchmark class. For prompts whose benchmark label was no significant difference, {{qwen317b_retrieved_qv_gold_ns}} quote-valid answers were wrong; for significantly decreased, {{qwen317b_retrieved_qv_gold_dec}}; for significantly increased, {{qwen317b_retrieved_qv_gold_inc}}. The fixed sensitivity analyses gave similar estimates: {{qwen317b_retrieved_S1}} with exact rather than whitespace-normalized matching and {{qwen317b_retrieved_S2}} when prompts with disagreeing accepted labels were included and a match to any accepted label counted as correct (Supplementary S7). Restricted to prompts whose retrieved passages overlapped annotated evidence, the rate was {{qwen317b_retrieved_S5}}.

By the automated categories, {{tax_qwen317b_retrieved_said_sig}} of the {{tax_qwen317b_retrieved_total}} quote-valid wrong answers reported a significant effect where the benchmark recorded no significant difference, {{tax_qwen317b_retrieved_reversal}} reversed the direction ({{qwen317b_retrieved_rev_inc_for_dec}} answered increased for a benchmark decrease and {{qwen317b_retrieved_rev_dec_for_inc}} the reverse), and {{tax_qwen317b_retrieved_said_ns}} reported no significant difference where the benchmark recorded a significant effect. {{tax_qwen317b_retrieved_overlap}} of these wrong answers quoted text that overlapped annotated evidence, including {{tax_qwen317b_retrieved_reversal_overlap}} direction reversals (Supplementary S10).

### Contexts, models, and baselines

With the title and abstract, {{qwen317b_abstract_quote_pct}} of Qwen3-1.7B answers had an existing quote and {{qwen317b_abstract_qvwr_frac}} of these were wrong ({{qwen317b_abstract_qvwr}}). With the annotated evidence supplied, {{qwen317b_oracle_qvwr_frac}} quote-valid answers were wrong ({{qwen317b_oracle_qvwr}}), and end-to-end success was higher than with retrieved passages ({{cmp_qwen3_1_7b_oracle_vs_retrieved_task_success_f}}).

{{models_paragraph}}

The TF-IDF baseline's quote, its top-ranked passage, existed for {{tfidflr_retrieved_quote_frac}} answered prompts; {{tfidflr_retrieved_qvwr_frac}} of these labels were wrong ({{tfidflr_retrieved_qvwr}}). Its share of correct labels over all prompts did not differ clearly from that of Qwen3-1.7B (Qwen3-1.7B minus TF-IDF: {{cmp_1_7b_vs_tfidf_retrieved_correct_all}}). The majority-class label paired with the same passage passed the quote check for {{majority_retrieved_quote_frac}} prompts while being wrong for {{majority_retrieved_qvwr_frac}}.

### The quote-validity rule and random rejection

For Qwen3-1.7B with retrieved passages, accepting every answer gave a retained error of {{qwen317b_retrieved_rej_unf}} at {{qwen317b_retrieved_rej_cov_unf}} coverage. Keeping only answers with an existing quote and a valid locator gave {{qwen317b_retrieved_rej_flt}} at {{qwen317b_retrieved_rej_cov_flt}} coverage, a difference of {{qwen317b_retrieved_rej_diff_bare}} (Table 2, Figure 3). The rule rejected {{qwen317b_retrieved_rej_rejected}} answers, {{qwen317b_retrieved_rej_rejected_correct}} of which had the correct label. Random rejection of the same number of answers gave a mean retained error of {{qwen317b_retrieved_rej_rand}} (middle 95% of draws {{qwen317b_retrieved_rej_rand_range}}). The same held with the abstract ({{qwen317b_abstract_rej_diff_bare}}) and with annotated evidence ({{qwen317b_oracle_rej_diff_bare}}).

{{rejection_models_sentence}}

A logistic scoring rule fitted on development predictions from six observable answer features (Supplementary S13) ordered test answers better than random (area under the risk-coverage curve {{rc_aurc}} against {{rc_aurc_random}}; Figure 4).

**Table 2.** Retained error with all answers and with only answers whose quote exists and whose passage identifier is valid, against random rejection keeping the same number of answers (2,000 draws), with the share of random draws whose error was at or below the rule's. Differences are in percentage points with paired article-bootstrap 95% intervals.

{{table_rejection}}


## Discussion

For a small local model answering questions about trial reports, a quote that genuinely appeared in the source was attached to a wrong answer close to half the time. Rejecting answers without such a quote removed about a quarter of the primary model's answers without lowering the error of the rest, and in {{n_rule_inside}} of the {{n_rule_total}} model and context combinations the rule did no better than random rejection at the same coverage. Qwen3-4B-Instruct-2507, a later and larger release, gave more correct labels than Qwen3-1.7B ({{cmp_4b_vs_1_7b_retrieved_correct_all}}) and about half as many quote-valid wrong answers ({{qwen34binstruct2507_retrieved_qvwr_numerator}} against {{qwen317b_retrieved_qvwr_numerator}}), yet about one in five of its quote-valid answers was still wrong, and quote validity again did not say which. In the primary condition, quote presence did not distinguish correct from incorrect labels. 

The finding matches earlier observations on frontier models, where a substantial share of errors with valid quotes were misreadings of the right evidence [@elbakian2025retrieving] and filtering on mechanical quote validity left macro-F1 essentially unchanged [@windisch2026showwork]. Here the joint rate covers a full test split and laptop-sized models, and the rule is compared with random rejection.

Most quote-valid wrong answers reported a statistically significant effect where the trial reported none, and the model rarely chose "no significant difference" (recall {{qwen317b_retrieved_ns_recall}} for that class, against precision {{qwen317b_retrieved_ns_precision}}). A sentence describing a numerical difference can be quoted correctly while its p-value or confidence interval is ignored. About three in ten errors reversed the direction of a significant effect, and most of these answered an increase where the benchmark recorded a decrease ({{qwen317b_retrieved_rev_inc_for_dec}} of {{tax_qwen317b_retrieved_reversal_n}}), in line with the model's preference for that label (recall {{qwen317b_retrieved_inc_recall}}, precision {{qwen317b_retrieved_inc_precision}}). Confusing the intervention with the comparator may also contribute: a fine-tuned 4-billion-parameter classifier on the same benchmark kept its direction answer for about a third of prompts when the two were exchanged [@li2026fiorillo]. 

Retrieval failure explains only part of the errors. In {{tax_qwen317b_retrieved_overlap}} of the quote-valid wrong answers the quote overlapped the annotators' evidence, and in the oracle condition, where the model was handed the annotated evidence, it still erred on {{qwen317b_oracle_qvwr_pct}} of quote-valid answers.

The baselines illustrate the limits of a presence check. An extractive system passes it almost automatically: a majority-class guess with a retrieved passage attached passed it for {{majority_retrieved_quote_frac}} prompts. Quote presence can therefore be satisfied without reading the evidence at all, and in these results it carried little information about whether the answer was right. Work on attribution treats support as separate from correctness [@rashkin2023measuring; @bohnet2022attributed; @liu2023evaluating], and medical citation checking has warned that verbatim quoting can satisfy source checks trivially [@wu2025automated]. 

The development-fitted scoring rule ordered test answers better than random, which suggests that cheap observable signals beyond quote presence carry some information about correctness, but it was exploratory, was not designed to show which signals matter, and does not give calibrated probabilities. Semantic checks with natural language inference models [@honovich2022true; @zha2023alignscore] or human review are candidates for tools that inform clinical or review decisions, but neither was tested here, and both deserve the same comparison with random rejection.

For developers and reviewers of evidence tools, the practical implication is to report quote validity and answer correctness as separate quantities and to test any validity-based filter against random rejection at the same coverage before relying on it. The released harness supports models that return its specified answer schema.

### Limitations

Evidence Inference 2.0 is public and may be in the pretraining data of the evaluated models; a clean train and test split does not rule this out. Only models of 0.6 to 4 billion parameters from one family were evaluated, with one prompt, greedy decoding, thinking mode disabled for the two hybrid models, and a lexical retriever at one token budget, so the estimates do not describe larger, proprietary, or task-fine-tuned models, reasoning modes, or better retrieval. Qwen3-4B-Instruct-2507 also differs from the other two models in release and post-training, so comparisons with it do not isolate model size. The estimate is sensitive to the prompt: on development data, a variant with a worked example gave a lower label-error rate among quote-valid answers, {{dev_v2_greedy_qvwr}} against {{dev_v1_greedy_qvwr}}, but fewer existing quotes, and it lost on the prespecified success rule. 

Benchmark labels come from physicians with verification, but they contain known noise, and annotators marked one or two evidence spans, so a quote outside them may still be valid evidence. Error categories are rule-based, not expert judgments. The pooled rate depends on the benchmark's mix of labels, so it will differ where null results are more or less common. 

The test articles were published between {{test_pub_year_min}} and {{test_pub_year_max}}, so the benchmark is an older expert-annotated sample, not a sample of current literature. Finally, the benchmark asks for statistical significance in one comparison, which is narrower than the judgments evidence reviewers make.

## Conclusion

For the primary model, answers whose verbatim quote appeared in the trial report were right no more often than answers without one, and keeping only answers with a valid quote and passage identifier performed no better than random rejection in any context. Qwen3-4B-Instruct-2507, a later and larger release, gave more correct labels, but about one in five of its quote-valid answers was still wrong; across all models and contexts the rule beat random rejection in {{n_rule_beat}} of {{n_rule_total}} combinations. Tools that extract trial results need a check on whether the label follows from the quoted evidence, in addition to the check that the quote exists.

## Acknowledgments

I conceived and designed the study, developed the code, conducted the analyses, verified the results, checked the key citations, and reviewed and revised the manuscript. Claude Code (Anthropic) and ChatGPT (OpenAI) were used as tools for software development, data analysis, literature searching, and manuscript drafting and formatting. Codex (OpenAI) assisted with editorial revision and document formatting. I recall using Opus models in Claude Code and models from the GPT-5 and GPT-6 families in ChatGPT and Codex. Exact model version records are unavailable.

## Competing interests

I own Norlowe Research, where I conducted this work. I have no other competing interests to declare.

## Funding

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors. The work was carried out with the resources of Norlowe Research.

## Author contributions

Animesh Bose (sole author): Conceptualization, Methodology, Software, Validation, Formal analysis, Investigation, Data curation, Visualization, Project administration, Writing (original draft), Writing (review and editing).

## Ethics

This study was a secondary analysis of published clinical trial reports and existing, publicly available benchmark annotations. No participants were recruited, and no individual-level or identifiable personal data were used. Institutional review board review was not sought.

## Data availability

The Evidence Inference 2.0 corpus is publicly available from its authors at https://github.com/jayded/evidence-inference (analyzed at commit a661e8c14f973398380c8865cf2f27a535aaaf6d) and https://evidence-inference.ebm-nlp.com/; the underlying articles come from the PubMed Central Open Access subset and remain under their own licenses. The evaluated models are publicly available from Hugging Face at the revisions listed in Supplementary S3. The analysis code, frozen configuration, every model and baseline response, item-level scores, and result tables are provided in the supplementary archive (Supplementary File 2); its workflow downloads the corpus and models from the sources above, so the analysis can be reproduced without redistributing article texts.

## References

{{references}}

## Figure legends

**Figure 1.** Outcome of every eligible test prompt by model and context: quote valid and label right, quote valid and label wrong, no valid quote with the label right or wrong, abstained, and invalid output.

Alt text: stacked bars; the segment with a valid quote and a wrong label ranges {{fig_outcomes_alt_range}}.

![Figure 1](../results/figures/fig2_answer_outcomes.svg)

**Figure 2.** Share of quote-valid answers with the wrong label, by context and system. Dots are point estimates and lines are 95% intervals from 10,000 bootstrap resamples of articles; numbers at right are wrong answers out of quote-valid answers.

Alt text: dot and interval chart; the share of quote-valid answers with a wrong label ranges {{fig1_alt_range}}, and each system run with annotated evidence has its lowest share in that context.

![Figure 2](../results/figures/fig1_quote_valid_wrong.svg)

**Figure 3.** Retained error for each model and context with all answers (ring) and with only answers whose quote exists and whose passage identifier is valid (triangle), against the middle 95% of 2,000 random rejections at the same coverage (grey band).

Alt text: {{fig_rejection_alt}}

![Figure 3](../results/figures/fig3_rejection_rule.svg)

**Figure 4.** Risk-coverage curve for Qwen3-1.7B with retrieved passages, ordering test answers by a scoring rule fitted on development predictions only. The dashed line is the expected error under random ordering; the triangle is the quote-validity rule's single operating point.

Alt text: line chart; the fitted rule's error falls below the random line at most coverages, while the quote-validity rule sits on the random line.

![Figure 4](../results/figures/fig4_risk_coverage.svg)
