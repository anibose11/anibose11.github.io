# Supplementary material (Supplementary File 1)

Verbatim evidence quotes and answer correctness: an evaluation of small local language models extracting clinical trial results. Supplementary File 2 is the analysis archive (code, configuration, model responses, item-level scores, and result tables).

## S1. Data reconciliation

The corpus was used at commit a661e8c14f973398380c8865cf2f27a535aaaf6d of github.com/jayded/evidence-inference and reconciled against the tarball linked from the project site (v2.0.tar.gz, Last-Modified 12 May 2020, SHA-256 6abe0d4e...1586). Prompts and split files were byte-identical. Annotation rows (24,686) matched in order and in user, prompt, article, validity flags, label code, and "In Abstract" values. The tarball writes the label "significantly increase" in {{recon_official_label_str_variant_rows}} rows whose label code is 1. Of its {{recon_official_txt_files}} text files, {{recon_official_txt_identical_after_crlf}} are identical to the repository texts once line endings are converted; the other {{recon_official_txt_other_rendering}} use a different rendering without the title line and with plain section headers, and all {{recon_offset_rows_differing}} annotation rows whose offsets differ between the releases belong to {{recon_offset_differing_articles}} of those articles. The posted test answers file (2,408 rows) matched the repository's test rows in order and in user, prompt, article, validity flags, label code, and "In Abstract" values; like the tarball, it uses the "significantly increase" spelling and the tarball's offsets. Two links in the project site's JavaScript returned the site's HTML page instead of CSV and were rejected.

Offsets were tested on a seeded sample of 3,000 training rows. Exclusive ends reproduced the annotation string for {{recon_offset_sample_repo_ex}} rows with the repository text and {{recon_offset_sample_official_ex}} rows with the tarball text after newline normalization; inclusive ends reproduced {{recon_offset_sample_repo_inc}} and {{recon_offset_sample_official_inc}}. Location status of accepted evidence spans across all splits: exact {{span_exact}}; exact after whitespace normalization {{span_exact_ws}}; exact at the recorded offsets after unescaping HTML entities {{span_exact_after_unescape}}; found at a different position by unique string match {{span_recovered_unique}} (plus {{span_recovered_unique_unescaped}} after unescaping); missing offsets recovered by string match {{span_recovered_from_missing}} (plus {{span_recovered_from_missing_unescaped}} after unescaping); ambiguous match, nearest used {{span_recovered_ambiguous}}; offsets given but string not found {{span_offset_text_mismatch}}; missing offsets and string not found {{span_unavailable}}; article without text {{span_no_text}}. Spans in the last three groups are not used as evidence (analysis plan amendment A3).

The repository's abstracts folder holds 3,285 files, of which 2,334 contain body sections. The abstract condition instead used the title-plus-abstract region of the plain-text rendering, which was delimitable for {{test_abstract_ok}} of the {{n_test_articles}} test articles with prompts. For the {{abst_cmp_n}} abstract-only files whose article also had a delimitable region, {{abst_cmp_eq}} matched that region exactly after header lines were removed and whitespace collapsed. No article appears in two splits, no two texts are identical, and no pair of articles reached TF-IDF cosine 0.9 over their opening 4,000 characters.

The {{test_pub_year_n}} test articles with eligible prompts were published between {{test_pub_year_min}} and {{test_pub_year_max}} (median {{test_pub_year_median}}; Europe PMC metadata). Test prompts by label status: unanimous accepted label {{n_test_unanimous}}, accepted labels disagree {{n_test_disagree}}, no accepted annotation {{n_test_noaccepted}}, no annotation {{n_test_noann}}. Six test prompts are on the corpus authors' "Incorrect" list; none are on the "Questionable" or "Somewhat malformed" lists. One test article (PMC2206488) has an empty plain-text file in the repository and in the tarball; its 6 eligible prompts were run with an empty retrieved context and then excluded under amendment A2. Fourteen other articles have texts shorter than 500 characters (twelve training, one validation, one test); none has a prompt in the corpus, so none enters any analysis.

## S2. Prompt and answer schema

Each request was a single user message containing, in order: a one-sentence task statement ("You are reading passages from a report of a clinical trial and answering one question about it."); the question, built from the template "{{prompt_question}}"; the passages, one per line as "[P*n*] text"; the label guide; and the format guide.

Label guide: {{prompt_label_guide}}

Format guide: {{prompt_format_guide}}

Variant v2 (evaluated on development data only) added this invented example before the format guide: {{prompt_example}}

The answer schema required exactly three keys: `label` (one of the three benchmark labels or "cannot determine"), `evidence_quote` (string), and `passage_id` (string or null); additional keys were not allowed.

## S3. Models and inference settings

{{table_models}}

All models were loaded from local snapshots at these revisions with Hugging Face Transformers 5.19.0 and PyTorch 2.14.1, in float32, on an Apple M5 Pro (Metal Performance Shaders). Chat templates came from each repository; the two hybrid models received `enable_thinking=False`. Decoding was greedy with at most 256 new tokens and no repetition penalty. Prompts were not batched. Development parity between the GPU and CPU paths: same label for {{dev_parity}} prompts, identical responses for {{dev_parity_identical}}.

Runs on the frozen test sample: Qwen3-1.7B completed {{run_qwen317b_articles}} articles in {{run_qwen317b_hours}} hours ({{run_qwen317b_calls}} calls across three contexts); Qwen3-0.6B completed {{run_qwen306b_articles}} articles in {{run_qwen306b_hours}} hours ({{run_qwen306b_calls}} calls); Qwen3-4B-Instruct-2507 completed {{run_qwen34binstruct2507_articles}} articles in {{run_qwen34binstruct2507_hours}} hours ({{run_qwen34binstruct2507_calls}} calls, retrieved context only). After amendment A3, the oracle condition was run again with Qwen3-1.7B and Qwen3-0.6B for the {{n_oracle_rerun_per_model}} prompts per model whose evidence passages had changed ({{n_oracle_rerun_calls}} calls; every other response was reused from the cache), so the prediction files hold {{n_model_calls_test}} recorded test responses, including the superseded original oracle responses for those prompts.

## S4. Baseline training

{{table_baseline_training}}

## S5. Parse status by model and context

{{table_parse}}

## S6. Per-class results

{{table_per_class}}

## S7. Sensitivity analyses

Analysis S1 uses exact substring matching with the same four-word minimum as the primary definition. The minimum was added by amendment A1, recorded after the primary model's test outputs were scored: as first coded, S1 had no length minimum, so short exact quotes made the stricter count larger than the primary count in the oracle condition. The count of exact quotes of any length is reported separately as "quote exists (strict, any length)".

{{table_sensitivity}}

## S8. Paired comparisons

Differences are on the prompts both systems had, with 95% intervals from 10,000 paired bootstrap resamples of articles.

{{table_comparisons}}

## S9. Evidence available in the supplied passages

{{table_recall}}

## S10. Automated error categories for quote-valid wrong answers

{{table_taxonomy}}

## S11. Reproducibility and software checks

* Software tests: synthetic fixtures for parsing, quote location across line breaks, locators, the label contract, offsets, chunking, abstract delimiting, the bootstrap, macro-F1, and the rejection arithmetic.
* Deterministic rerun: data, contexts, scores, and analysis rebuilt from cached inputs; {{rerun_numbers_compared}} reported numbers compared with the stored results at a relative tolerance of 1e-9.
* Separate recount: the headline numerators and denominators and task success counts recomputed from the item-level files in base R.
* Model rerun: a sample of test calls regenerated with the frozen configuration on the same device; {{rerun_identical}} responses were identical and {{rerun_same_label}} had the same label.
* Clean installation: the analysis archive (Supplementary File 2) was extracted into an empty directory and installed into a new virtual environment from requirements.lock.txt; all 34 tests passed and the cached demonstration reproduced the saved outputs for the bundled examples.
* Author check against source articles: 20 quote-valid wrong answers from Qwen3-1.7B with retrieved passages, drawn with seed 20261007 (prompt IDs {{validation_sample_ids}}), were compared with the articles in PubMed Central, and the label codes of five of them were checked against the raw annotation file.
* Claims: every headline number in evidence/claims.json is mapped to its file, key, numerator, denominator, scope, configuration, source hashes, and run identifier, and re-read from the results file.

These checks test the software and its consistency. They are not external scientific validation.

## S12. TRIPOD-LLM checklist

Items are paraphrased from the TRIPOD-LLM reporting guideline (Gallifant et al., Nature Medicine 2025;31:60-69, doi:10.1038/s41591-024-03425-5), main checklist (Table 2) and abstract checklist (Table 3). This study is an LLM evaluation without patient data.

| Item | Section | What is reported (paraphrased) | Where |
|---|---|---|---|
| 1 | Title | Title should state whether the LLM is developed, fine-tuned or evaluated, plus the task, target population and outcome. | Title |
| 2 | Abstract | Abstract should follow the separate TRIPOD-LLM for Abstracts checklist (items 2a-2l). | Abstract (structured; see items 2a to 2l) |
| 3a | Introduction | Explain the healthcare use case and why the LLM is developed or evaluated, citing existing approaches and models. | Background and Significance, paragraphs 1 to 2 |
| 3b | Introduction | Describe the target population, the LLM's intended use within the care pathway, and its intended users. | Background and Significance, paragraphs 1 and 5 (evidence reviewers; local deployment); not a care-pathway tool |
| 4 | Introduction | State study objectives, including whether it covers initial development, fine-tuning, validation, or several stages. | Objective |
| 5a | Methods | Give data sources separately for training, tuning and evaluation, with the rationale for choosing them. | Methods, Data and labels; Context conditions; Models and inference; Baselines (training split for BM25 statistics and baselines; validation for development decisions; test for evaluation) |
| 5b | Methods | Describe the data points and characterize dataset distribution and descriptors (e.g., source, language, country) quantitatively and qualitatively. | Methods, Data and labels; Results, Output validity; Supplementary S1 |
| 5c | Methods | State the earliest and latest dates of text in development data and in evaluation datasets. | Supplementary S1: test articles published {{test_pub_year_min}} to {{test_pub_year_max}}; model training cutoffs are not stated on the model cards |
| 5d | Methods | Describe preprocessing and quality checks, and whether they were consistent across corpora, sites and sociodemographic groups. | Methods, Data and labels; Supplementary S1 (offset convention, abstract delimiting, reconciliation) |
| 5e | Methods | Explain how missing and imbalanced data were handled and justify any data exclusions. | Methods, Data and labels (eligibility, disagreement, unlocatable spans); Supplementary S1 |
| 6a | Methods | Report the LLM's name, version and last training date. | Methods, Models and inference; Supplementary S3 (revisions; training cutoff not stated by the developer) |
| 6b | Methods | Describe how the LLM was built: architecture, training, fine-tuning, alignment approach and alignment goals. | Not applicable (evaluation of existing models; no training or fine-tuning) |
| 6c | Methods | Describe how text was generated: prompt engineering, output consistency, and inference settings such as seed and temperature. | Methods, Models and inference; Supplementary S2 and S3 (prompt, greedy decoding, output limit) |
| 6d | Methods | Specify the raw and post-processed LLM outputs (e.g., probabilities, labels, free text). | Methods, Separated validity checks (raw JSON responses and parsed fields; raw responses released) |
| 6e | Methods | Justify any classification approach and explain how probabilities and decision thresholds were derived. | Methods, Baselines (logistic regression, settings chosen on validation macro-F1); no thresholds on model outputs |
| 7a | Methods | Report metrics of generative output quality (consistency, relevance, accuracy, error types) against gold standards. | Methods, Separated validity checks; Results; Table 1 |
| 7b | Methods | Explain how outcome metrics relate to the downstream deployment task and, where possible, to human judgments. | Discussion, paragraphs 6 and 7 |
| 7c | Methods | Define the outcome, how predictions were computed, inference date for closed-source models, and evaluation metrics. | Methods, Estimand and statistical analysis |
| 7d | Methods | For subjective outcome assessment, describe assessor qualifications, instructions, demographics and inter-assessor agreement. | Not applicable (no subjective assessment; labels from the published benchmark) |
| 7e | Methods | Describe how performance was benchmarked against other LLMs, humans, or other standards. | Methods, Baselines; Results, Contexts, models, and baselines; Table 1 |
| 8a | Methods | If annotation occurred, explain the labeling process and share annotation guidelines with examples. | Not applicable (no new annotation); benchmark annotation process summarized in Methods, Data and labels |
| 8b | Methods | If annotation occurred, report annotator count, share of data multiply annotated, and inter-annotator agreement. | Not applicable (no new annotation); label contract and disagreement handling in Methods, Data and labels |
| 8c | Methods | If annotation occurred, describe annotators' background and experience, or characteristics of any labeling models. | Not applicable (no new annotation) |
| 9a | Methods | If prompting was used, describe how prompts were designed, curated and selected. | Methods, Models and inference (two variants written in advance; selected on development data by a fixed rule) |
| 9b | Methods | If prompting was used, state which data informed prompt development. | Methods, Models and inference (100 validation articles; no test data) |
| 10 | Methods | Describe any data preprocessing performed before summarization. | Not applicable (no summarization) |
| 11 | Methods | If instruction tuning/alignment was used, report instructions, data, evaluation interface and evaluator population characteristics. | Not applicable |
| 12 | Methods | Report compute resources or proxies (hardware, time, cost, inference time, FLOPs) needed for the methods. | Results, Output validity; Supplementary S3 (Apple M5 Pro GPU, float32, run times) |
| 13 | Methods | Name the approving ethics board and describe participant consent or the consent waiver. | Ethics statement (no human participants or individual-level data) |
| 14a | Methods | State funding sources and the funders' role in the study. | Funding statement |
| 14b | Methods | Declare all authors' conflicts of interest and financial disclosures. | Conflict of interest statement |
| 14c | Methods | Say where the study protocol is available, or that none was prepared. | Internal timestamped analysis plan released in the project archive (docs/analysis_plan.md); not a registered protocol |
| 14d | Methods | Give registry name and registration number, or state the study was not registered. | Not registered |
| 14e | Methods | Describe availability of the study data. | Data availability statement |
| 14f | Methods | Describe availability of code needed to reproduce the results. | Data availability statement (code, configuration, responses, scores) |
| 15 | Methods | Describe patient/public involvement across study stages, or state there was none. | Not applicable (no patient or public involvement) |
| 16a | Results | With patient/EHR data, describe data flow through the study, including counts with/without outcome and follow-up. | Not applicable (no patient or EHR data); prompt flow in Results and Supplementary S1 |
| 16b | Results | With patient/EHR data, report characteristics overall, per source/setting and per split, including dates and sample size. | Not applicable (no patient or EHR data); test split size in Results (Output validity and evidence availability) and Supplementary S1; training and validation prompt counts in Supplementary S4 |
| 16c | Results | For evaluations with clinical outcomes, compare distributions of outcome-related clinical variables between development and evaluation data. | Not applicable |
| 16d | Results | With patient/EHR data, give participant and outcome-event counts for each analysis. | Not applicable (no patient or EHR data) |
| 17 | Results | Report performance on prespecified metrics (item 7a) and/or human evaluation (item 7d). | Results; Tables 1 and 2; Figures 1 to 4; Supplementary S5 to S10 |
| 18 | Results | If the LLM was updated, report the updated model and its subsequent performance. | Not applicable (models not updated) |
| 19a | Discussion | Interpret the main results overall, including fairness, relative to objectives and prior studies. | Discussion, paragraphs 1 to 3 |
| 19b | Discussion | Discuss limitations and their effects on bias, statistical uncertainty and generalizability. | Discussion, Limitations |
| 19c | Discussion | Describe known data challenges for the task/domain: representation, missingness, harmonization and bias. | Discussion, Limitations (label noise, partial evidence annotation, possible pretraining exposure) |
| 19d | Discussion | Define intended use: inputs, end users, and level of autonomy or human oversight. | Discussion, paragraphs 6 and 7 (evaluation harness for tool developers; outputs need semantic checks or human review) |
| 19e | Discussion | Where relevant, explain how poor or missing input data should be assessed and handled in clinical implementation. | Not applicable (no clinical implementation) |
| 19f | Discussion | Where relevant, state whether users must interact with inputs or the LLM, and the expertise required. | Discussion, paragraphs 6 and 7 (users are tool developers and reviewers; outputs need human review); Lay summary |
| 19g | Discussion | Discuss next research steps, focusing on the LLM's applicability and generalizability. | Discussion, paragraph 6; Limitations |
| 2a | Abstract | Identify the study as LLM development, fine-tuning and/or evaluation, with task, target population and outcome. | Abstract, title |
| 2b | Abstract | Briefly explain the healthcare context, use case and rationale for developing or evaluating the LLM. | Abstract, Objectives |
| 2c | Abstract | State objectives, including whether the study involves LLM development, tuning and/or evaluation. | Abstract, Objectives |
| 2d | Abstract | Summarize key elements of the study setting. | Abstract, Materials and Methods |
| 2e | Abstract | Describe all data used, the data splits, and any selective data use. | Abstract, Materials and Methods (official test split) |
| 2f | Abstract | Name the LLM(s) and version(s) used. | Abstract, Materials and Methods |
| 2g | Abstract | Briefly summarize LLM-building steps such as fine-tuning, reward modeling and RLHF. | Not applicable |
| 2h | Abstract | Describe the tasks the LLM performs and the key inputs/outputs of the final model. | Abstract, Materials and Methods |
| 2i | Abstract | Specify evaluation datasets/populations, endpoints, whether held out from training/tuning, and performance measures. | Abstract, Materials and Methods and Results |
| 2j | Abstract | Give an overall summary and interpretation of the main results. | Abstract, Results |
| 2k | Abstract | State broader implications or concerns arising from the results. | Abstract, Discussion and Conclusion |
| 2l | Abstract | Give registry/repository name and registration number, if relevant. | Not applicable |

## S13. Development-fitted scoring rule

Logistic regression (scikit-learn, C = 1.0) predicting a correct label from six features of each answer, fitted on the answered prompts among the {{rc_dev_items}} development prompts, using Qwen3-1.7B with retrieved passages, and applied unchanged to test answers. Positive coefficients favor a correct label. The scores are used only to order answers for the risk-coverage curve (Figure 4); they are not calibrated probabilities, and the coefficients are not estimates of feature importance.

{{table_rc_coefficients}}
