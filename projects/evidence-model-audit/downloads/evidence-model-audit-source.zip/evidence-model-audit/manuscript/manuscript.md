# Verbatim evidence quotes and answer correctness: an evaluation of small local language models extracting clinical trial results

**Animesh Bose**

Norlowe Research


Article type: Research and Applications. Keywords: large language models; evidence synthesis; randomized controlled trials; information extraction; selective prediction.

## Abstract

**Objectives:** Language-model tools that extract trial results can be checked by confirming that a quoted sentence appears in the source. This study measured how often small local models give a genuine quote with a wrong result and whether rejecting failed checks reduces error.

**Materials and Methods:** Qwen3-1.7B and Qwen3-0.6B, run locally, answered 1,209 eligible Evidence Inference 2.0 test prompts from retrieved passages (1,024 tokens) and, where available, the abstract and annotated evidence; Qwen3-4B-Instruct-2507 used retrieved passages. Answers gave a direction label, a verbatim quote, and a passage identifier. Parse validity, quote existence, locator validity, evidence overlap, and label correctness were scored separately.

**Results:** For Qwen3-1.7B with retrieved passages, 928 of 1,196 answers quoted the source verbatim; 423 of these (45.6%; 95% CI 41.8% to 49.3%) had the wrong label, mostly reporting significance the trial did not find. With annotated evidence, 29.2% were wrong. With retrieved passages, the rate was 42.8% for Qwen3-0.6B and 20.5% for Qwen3-4B-Instruct-2507. Keeping only answers with a valid quote and passage identifier changed error by +0.1 percentage points (95% CI -1.6 to +1.9) as coverage fell from 98.9% to 72.0%, no better than random rejection (45.6%).

**Discussion:** A present quote confirmed copying but did not show that the label followed from the text. Qwen3-4B-Instruct-2507, a later release, erred less overall, yet the rule again did no better than random.

**Conclusion:** For these small models, passing a quote-presence check did not show that an extracted trial result was correct; the label needs a separate check.

## Lay summary

Artificial intelligence tools that read clinical trial reports often show a quotation beside each answer. A program can confirm that the quotation appears in the report, but does that mean the answer is right? Small language models running locally answered 1,209 questions about published trials. Each question asked whether an outcome was significantly higher, significantly lower, or not significantly different with one treatment than with another. Experts had already answered the questions. Among answers with a quotation found in the article, close to half were wrong for the main model and about one in five for the largest model. The most common mistake was reporting a statistically significant difference when the trial found none. For the main model, discarding answers whose quotations could not be found removed many answers without making those retained more accurate. A quotation's presence confirms copying, not that the answer follows from the text. People using these tools still need to check what the quoted evidence supports.

## Background and Significance

Systematic reviewers spend much of their time reading trial reports to find out what happened to an outcome under one treatment compared with another. Language models are now being used to draft these extractions,[1] and one proposed safeguard is to have the model quote its evidence and then check mechanically that the quote appears in the source.[2] A quote that matches the article is easy to verify and looks reassuring. It does not show that the model read the sentence correctly.

Evidence Inference formalized this task. Given a trial report and a prompt naming an intervention, a comparator, and an outcome, a system must say whether the intervention significantly increased, did not significantly change, or significantly decreased the outcome relative to the comparator, and identify supporting evidence.[3] In the first release, logistic regression over a bag of words reached a macro-F1 of 0.388 on full articles and 0.731 when given the annotated evidence span, which located much of the difficulty in finding evidence. Evidence Inference 2.0 added prompts, released an abstract-only version, and reported that most evidence for the newly collected prompts lay outside the abstract.[4]

Work on attributed generation has shown that support and correctness are different properties. Frameworks for attribution deliberately make no factuality judgment.[5] Human-rated attribution correlated only modestly with exact-match accuracy in attributed question answering,[6] and an audit of generative search engines found about half of generated sentences fully supported by their citations, without judging whether statements were true.[7] A model trained to support answers with verbatim quotes produced false answers that raters judged supported.[8] In medicine, an automated framework for checking whether cited sources support claims warns that verbatim quoting can satisfy source checks trivially.[9]

Three studies come closest to the present question. Elbakian and Carton asked GPT-4 and Gemini 1.5 Pro for a structured label with quoted spans on five datasets including Evidence Inference, checked quotes by substring match, and found that a quarter or more of Evidence Inference errors with valid quotes were misreadings of evidence that overlapped the human rationale.[10] Their analysis used 300 development items and frontier models. Windisch and colleagues required verbatim quotes for classifying oncology trial eligibility criteria and reported that keeping only mechanically valid outputs left macro-F1 essentially unchanged.[2] Buchmann and colleagues included Evidence Inference in a long-document benchmark and showed that ordering answers by an NLI-based attributability score improved selective prediction over a random order.[11] None of these studies evaluated models below about 3 billion parameters, reported the joint rate of valid quotes and wrong labels over a full test split, or compared a fixed quote-validity rule with random rejection at the same coverage.

Small local models matter because restricted documents often cannot be sent to remote services and local tools are cheap to run at scale. The selective prediction literature supplies the frame for asking whether a check is worth applying: a rejection rule is judged by the error it leaves and the coverage it costs.[12,13] This study adds a comparison with random rejection at the same coverage, so that any drop in error can be separated from the effect of simply answering fewer questions.

## Objective

This study measured how often small local instruction models answer Evidence Inference 2.0 prompts with a quote that is present in the supplied source while the direction label is wrong, with each validity check reported separately, across a retrieved context, an abstract-only context, and an annotated-evidence oracle. It also tested whether rejecting answers whose quote fails the check lowers error more than rejecting the same number of answers at random. It extends earlier frontier-model analyses to models of 0.6 to 4 billion parameters and to the full official test split, and it releases the evaluation harness.

## Materials and Methods

### Data and labels

Evidence Inference 2.0 contains randomized trial reports from the PubMed Central Open Access subset with prompts of the form "With respect to *outcome*, characterize the reported difference between patients receiving *intervention* and those receiving *comparator*".[3,4] Physicians wrote each prompt, answered it with one of three labels (significantly increased, no significant difference, significantly decreased) and an evidence span, and verified other annotators' answers. The corpus repository was used at a pinned commit (a661e8c, two commits after its v2.0 tag, differing only in model code) with its official article-level splits, which share no article. The files hold 12,865 prompts and 24,686 annotation rows, and they matched the tarball posted on the project site in prompts, splits, and label codes (Supplementary S1).

Following the corpus authors' preprocessing, an annotation was accepted when the verifier accepted its label and its reasoning and its evidence string was not empty. A prompt's benchmark label was the label shared by all its accepted annotations; prompts whose accepted annotations disagreed were analyzed only in a sensitivity analysis, and prompts on the corpus authors' list of incorrect prompts were excluded. Evidence offsets were treated as half-open intervals, which reproduced the annotated strings (Supplementary S1). Annotation strings were compared with the text after collapsing whitespace and unescaping HTML entities; spans that still could not be found were not used as evidence (Supplementary S1). Increased and decreased refer to the value of the outcome measure, not to benefit or harm, and "no significant difference" is a reported absence of statistical significance, distinct from equivalence and from abstention.

### Context conditions

Every eligible prompt was answered with retrieved passages, and with the abstract and the annotated evidence where those contexts could be built, using identical instructions and output limits. In the retrieved context, each paragraph was split into chunks of at most 60 words built from whole sentences (longer unbroken segments, mostly tables, were cut at word boundaries). Chunks were ranked by BM25 (k1 = 1.2, b = 0.75, each chunk treated as a document, with statistics from training-split chunks only) against the intervention, comparator, and outcome text, added in rank order up to 1,024 tokens, and shown in article order with passage identifiers. The budget was fixed before testing; on the 1,201 eligible validation prompts with located evidence, supplied passages overlapped annotated evidence for 57.9%, 76.4%, and 84.5% of prompts at 512, 1,024, and 1,536 tokens. In the abstract context, the passages were the title and abstract paragraphs of the same text (when at least 200 characters long), truncated at 1,024 tokens; the corpus's folder of abstract files was not used because 2,334 of its 3,285 files contain full articles. In the oracle context, the passages were the located accepted evidence spans, merged where they overlapped. The oracle is an upper bound on evidence access, not a deployable method.

### Models and inference

The primary model was Qwen3-1.7B,[14] with Qwen3-0.6B for lower capacity and Qwen3-4B-Instruct-2507 as a larger extension (retrieved context only), each pinned to a repository revision (Supplementary S3). Models ran locally with Hugging Face Transformers in float32 on an Apple M5 Pro GPU, with no remote service; the same code runs on CPU. Each model's chat template was used with thinking disabled for the hybrid models. The prompt asked for one JSON object with a label (the three benchmark labels or "cannot determine"), a quote copied from one passage, and that passage's identifier, and defined each label, including that increased and decreased describe the outcome value (Supplementary S2).

Three settings were fixed on 347 development prompts from 100 validation articles before any language-model test prediction, by rules written in advance. The prompt without a worked example was kept (45.8% versus 43.2% end-to-end success with the example); greedy decoding was kept because the model card's recommended sampling did not reduce invalid outputs (0.3% with both); and GPU inference was kept because it matched CPU inference on 40 of 40 prompts, with identical responses. Output was limited to 256 new tokens.

All test articles with an eligible prompt were evaluated, with no subset drawn; every call was cached with its prompt hash, token counts, latency, and raw response.

### Baselines

A majority-class reference predicted the most frequent training label. For each context, a logistic regression on TF-IDF features of the passages and prompt text was trained on training prompts built with the same context procedure, with settings chosen on validation macro-F1; it is a variant of the original bag-of-words baselines,[3] not a replication. Both baselines returned the top-ranked passage as their quote, so their quote is always an exact copy of a supplied passage and fails the quote check only when that passage is shorter than four words.

### Separated validity checks

Parse validity required the first JSON object in the response to match the schema after markdown fences were removed; no other repair was made, and text after the object was tolerated (this affected 8 of 8,428 recorded test responses). An answer abstained if its label was "cannot determine" and was answered otherwise. The quote existed if, after collapsing whitespace, it was a substring of one supplied passage and had at least four words. The locator was valid if the returned identifier named the passage holding the quote. Evidence overlap required the located quote to share at least one character with an accepted evidence span. End-to-end task success required an answer, an existing quote, a valid locator, and the correct label, with every eligible prompt in the denominator, including invalid outputs. A present quote is a syntactic check, not a test of entailment, and annotated spans can miss other valid evidence.

### Estimand and statistical analysis

The primary estimand, fixed in a timestamped internal analysis plan before any test prediction, was the label-error rate among quote-valid answers: the proportion of answered prompts with an existing quote whose label was wrong, for Qwen3-1.7B in the retrieved context. All intervals are 95% percentile intervals from 10,000 bootstrap resamples of articles. Secondary measures included macro-F1 (abstentions and invalid outputs counted as wrong), per-class precision and recall, coverage, and evidence recall at the token budget.

The quote check was tested as a rejection rule by comparing, on the same predictions, acceptance of every answer with acceptance of only answers with an existing quote and valid locator (retained error, coverage, paired bootstrap difference), against rejecting the same number of answers uniformly at random 2,000 times. Contexts and models were compared on unconditional quantities (task success, correct labels over all prompts) with paired article-bootstrap intervals on shared prompts. A logistic scoring rule on six observable answer features (Supplementary S13) was fitted on development predictions only and applied to test answers for a risk-coverage curve. Five sensitivity analyses were fixed in advance: exact rather than normalized quote matching, with the same four-word minimum; inclusion of prompts with disagreeing accepted labels; exclusion of prompts flagged as questionable or malformed (none in the test split); a one-word minimum; and restriction to prompts whose retrieved passages overlapped annotated evidence. Quote-valid wrong answers were sorted by fixed rules into significance errors and direction reversals, crossed with evidence overlap; these categories are automated, not expert labels.

### Software checks and reproducibility

Unit tests on synthetic fixtures covered parsing, quote location, the label contract, chunking, and the statistics. A validation stage rebuilt all outputs from cached inputs and compared 4,809 reported numbers with the stored results, recounted the headline aggregates in base R from the item-level files, and regenerated a sample of test calls (40 of 40 identical responses); the final archive was then installed in an empty directory, where its tests passed and its demonstration ran (Supplementary S11). Three amendments to the analysis plan were recorded after test outputs had been generated: the four-word minimum in the exact-match sensitivity analysis, exclusion of the 6 prompts of one test article whose text file is empty, and HTML-entity-aware location of evidence spans, after which the oracle condition was re-run for the 13 prompts per model whose passages changed. None changed the primary estimate (Supplementary S1, S3, and S7). I also checked the primary result and its inputs by hand. I recounted the primary counts (423 of 928) from the item-level file. I compared 20 quote-valid wrong answers, drawn at random with a fixed seed (20261007), with the source articles to confirm that each quote appeared in the article and that the benchmark label reflected the reported result. I checked the label codes of five sampled prompts against the raw annotation file, confirmed that the analysis plan and frozen configuration predated the first language-model test prediction, and checked the descriptions of the five closest prior studies against the papers.

## Results

### Output validity and evidence availability

The test split contains 1,252 prompts in 334 articles; 1,209 prompts in 332 articles met the eligibility rule after the exclusions listed in Supplementary S1. In the retrieved context, 1,205 of 1,209 responses parsed under the schema and 9 of 1,209 abstained, leaving 1,196 answered prompts (Table 1). The retrieved passages overlapped annotated evidence for 916 of 1,202 prompts with locatable evidence (76.2%, 95% CI 72.4% to 79.9%); the title and abstract did so for 581 of 1,158 (50.2%, 95% CI 45.8% to 54.5%).

**Table 1.** Separated validity checks by context and system, eligible test prompts. Percentages for quote existence, locator validity, and label correctness are of answered prompts; task success is of all prompts. Baselines return the top-ranked passage as their quote.

| Context | System | Prompts | Parse valid | Abstained | Quote exists (of answered) | Locator valid (of answered) | Label correct (of answered) | Quote valid, label wrong | Task success | Macro-F1 |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Retrieved | Qwen3-1.7B | 1,209 | 1,205 (99.7%) | 9 (0.7%) | 928 (77.6%) | 871 (72.8%) | 651 (54.4%) | 423 of 928 (45.6%) | 473 (39.1%) | 0.513 |
| Retrieved | Qwen3-0.6B | 1,209 | 1,179 (97.5%) | 6 (0.5%) | 773 (65.9%) | 454 (38.7%) | 671 (57.2%) | 331 of 773 (42.8%) | 260 (21.5%) | 0.480 |
| Retrieved | Qwen3-4B-Instruct-2507 | 1,209 | 1,206 (99.8%) | 46 (3.8%) | 1,039 (89.6%) | 1,029 (88.7%) | 920 (79.3%) | 213 of 1,039 (20.5%) | 818 (67.7%) | 0.774 |
| Retrieved | TF-IDF + LR | 1,209 | 1,209 (100.0%) | 0 (0.0%) | 1,209 (100.0%) | 1,209 (100.0%) | 695 (57.5%) | 514 of 1,209 (42.5%) | 695 (57.5%) | 0.565 |
| Retrieved | Majority class | 1,209 | 1,209 (100.0%) | 0 (0.0%) | 1,209 (100.0%) | 1,209 (100.0%) | 511 (42.3%) | 698 of 1,209 (57.7%) | 511 (42.3%) | 0.198 |
| Abstract | Qwen3-1.7B | 1,165 | 1,156 (99.2%) | 11 (0.9%) | 1,026 (89.6%) | 997 (87.1%) | 586 (51.2%) | 504 of 1,026 (49.1%) | 505 (43.3%) | 0.481 |
| Abstract | Qwen3-0.6B | 1,165 | 994 (85.3%) | 45 (3.9%) | 725 (76.4%) | 358 (37.7%) | 482 (50.8%) | 352 of 725 (48.6%) | 174 (14.9%) | 0.393 |
| Abstract | TF-IDF + LR | 1,165 | 1,165 (100.0%) | 0 (0.0%) | 1,161 (99.7%) | 1,161 (99.7%) | 620 (53.2%) | 543 of 1,161 (46.8%) | 618 (53.0%) | 0.525 |
| Abstract | Majority class | 1,165 | 1,165 (100.0%) | 0 (0.0%) | 1,161 (99.7%) | 1,161 (99.7%) | 492 (42.2%) | 670 of 1,161 (57.7%) | 491 (42.1%) | 0.198 |
| Oracle | Qwen3-1.7B | 1,202 | 1,195 (99.4%) | 47 (3.9%) | 980 (85.4%) | 978 (85.2%) | 816 (71.1%) | 286 of 980 (29.2%) | 692 (57.6%) | 0.683 |
| Oracle | Qwen3-0.6B | 1,202 | 1,187 (98.8%) | 372 (30.9%) | 406 (49.8%) | 393 (48.2%) | 531 (65.2%) | 120 of 406 (29.6%) | 276 (23.0%) | 0.489 |
| Oracle | TF-IDF + LR | 1,202 | 1,202 (100.0%) | 0 (0.0%) | 1,202 (100.0%) | 1,202 (100.0%) | 910 (75.7%) | 292 of 1,202 (24.3%) | 910 (75.7%) | 0.745 |
| Oracle | Majority class | 1,202 | 1,202 (100.0%) | 0 (0.0%) | 1,202 (100.0%) | 1,202 (100.0%) | 508 (42.3%) | 694 of 1,202 (57.7%) | 508 (42.3%) | 0.198 |


Among answered prompts, the quote existed in the supplied passages for 928 of 1,196 (77.6%, 95% CI 74.8% to 80.4%), the returned passage identifier pointed to the passage holding it for 871 of 1,196, and the located quote overlapped annotated evidence for 385 of 1,189 prompts with evaluable evidence (mean token F1 against the best-matching span, 0.548). The label was correct for 651 of 1,196 (54.4%, 95% CI 50.9% to 57.9%). End-to-end success (an answer, existing quote, valid locator and correct label) was 473 of 1,209 (39.1%, 95% CI 35.9% to 42.3%; Figure 1).

### Quote-valid answers with wrong labels

Of the 928 answers whose quote existed, 423 carried the wrong label (45.6%; 95% CI 41.8% to 49.3%; Figure 2). Answered prompts without an existing quote were wrong about as often (122 of 268, 45.5%). The rate depended strongly on the benchmark class. For prompts whose benchmark label was no significant difference, 295 of 385 quote-valid answers were wrong; for significantly decreased, 109 of 233; for significantly increased, 19 of 310. The fixed sensitivity analyses gave similar estimates: 422 of 926 (45.6%, 95% CI 41.8% to 49.3%) with exact rather than whitespace-normalized matching and 423 of 931 (45.4%, 95% CI 41.6% to 49.1%) when prompts with disagreeing accepted labels were included and a match to any accepted label counted as correct (Supplementary S7). Restricted to prompts whose retrieved passages overlapped annotated evidence, the rate was 288 of 698 (41.3%, 95% CI 37.1% to 45.4%).

By the automated categories, 295 (69.7%) of the 423 quote-valid wrong answers reported a significant effect where the benchmark recorded no significant difference, 122 (28.8%) reversed the direction (106 answered increased for a benchmark decrease and 16 the reverse), and 6 (1.4%) reported no significant difference where the benchmark recorded a significant effect. 123 (29.1%) of these wrong answers quoted text that overlapped annotated evidence, including 47 direction reversals (Supplementary S10).

### Contexts, models, and baselines

With the title and abstract, 89.6% of Qwen3-1.7B answers had an existing quote and 504 of 1,026 of these were wrong (49.1%, 95% CI 45.1% to 53.2%). With the annotated evidence supplied, 286 of 980 quote-valid answers were wrong (29.2%, 95% CI 25.7% to 32.9%), and end-to-end success was higher than with retrieved passages (+18.5 percentage points, 95% CI +14.6 to +22.3, 1,202 prompts).

With retrieved passages, Qwen3-0.6B's label accuracy did not differ clearly from that of Qwen3-1.7B (671 of 1,173 answered prompts correct, 57.2%; Qwen3-1.7B minus Qwen3-0.6B in correct labels over all prompts: -1.7 percentage points, 95% CI -6.1 to +2.9, 1,209 prompts), but it quoted less reliably: the quote existed for 65.9% of its answers and the locator was valid for 454 of 1,173, so end-to-end success was 21.5% against 39.1% for Qwen3-1.7B. Among its quote-valid answers, 331 of 773 were wrong (42.8%, 95% CI 38.5% to 47.3%). With the annotated evidence it abstained on 372 of 1,202 prompts. Qwen3-4B-Instruct-2507, run with retrieved passages only, gave more correct labels than Qwen3-1.7B (920 of 1,160 answered prompts correct, 79.3%; Qwen3-4B-Instruct-2507 minus Qwen3-1.7B in correct labels over all prompts: +22.2 percentage points, 95% CI +18.5 to +26.0, 1,209 prompts) and returned an existing quote for 89.6% of its answers; 213 of 1,039 of those were still wrong (20.5%, 95% CI 17.4% to 23.7%). Its end-to-end success exceeded that of Qwen3-1.7B on the same prompts (+28.5 percentage points, 95% CI +24.6 to +32.4, 1,209 prompts).

The TF-IDF baseline's quote, its top-ranked passage, existed for 1,209 of 1,209 answered prompts; 514 of 1,209 of these labels were wrong (42.5%, 95% CI 39.2% to 45.8%). Its share of correct labels over all prompts did not differ clearly from that of Qwen3-1.7B (Qwen3-1.7B minus TF-IDF: -3.6 percentage points, 95% CI -8.1 to +0.7, 1,209 prompts). The majority-class label paired with the same passage passed the quote check for 1,209 of 1,209 prompts while being wrong for 698 of 1,209.

### The quote-validity rule and random rejection

For Qwen3-1.7B with retrieved passages, accepting every answer gave a retained error of 45.6% at 98.9% coverage. Keeping only answers with an existing quote and a valid locator gave 45.7% at 72.0% coverage, a difference of +0.1 percentage points, 95% CI -1.6 to +1.9 (Table 2, Figure 3). The rule rejected 325 answers, 178 of which had the correct label. Random rejection of the same number of answers gave a mean retained error of 45.6% (middle 95% of draws 44.0% to 47.3%). The same held with the abstract (+0.5 percentage points, 95% CI -0.8 to +1.8) and with annotated evidence (+0.3 percentage points, 95% CI -0.8 to +1.4).

For Qwen3-0.6B the rule did not detectably beat random rejection with retrieved passages (-0.1 percentage points, 95% CI -4.1 to +3.9, coverage falling to 37.6%) or with the abstract (+2.2 percentage points, 95% CI -2.8 to +7.1). The one exception was Qwen3-0.6B with annotated evidence, where the rule lowered retained error from 34.8% to 29.8% (-5.1 percentage points, 95% CI -8.6 to -1.6), below the middle 95% of random rejections (31.3% to 38.4%; 0.2% of draws at or below the rule), at 32.7% coverage. For Qwen3-4B-Instruct-2507 the rule changed retained error by -0.2 percentage points (95% CI -1.1 to +0.7) as coverage fell from 95.9% to 85.1%, again within the random-rejection range (19.8% to 21.5%).

A logistic scoring rule fitted on development predictions from six observable answer features (Supplementary S13) ordered test answers better than random (area under the risk-coverage curve 0.337 against 0.450; Figure 4).

**Table 2.** Retained error with all answers and with only answers whose quote exists and whose passage identifier is valid, against random rejection keeping the same number of answers (2,000 draws), with the share of random draws whose error was at or below the rule's. Differences are in percentage points with paired article-bootstrap 95% intervals.

| Context | Model | Error, all answers (at coverage) | Error, quote and locator valid only (at coverage) | Difference, points (95% CI) | Random rejection, same coverage: mean (middle 95%) | Random draws with error at or below the rule | Answers rejected by the rule |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Retrieved | Qwen3-1.7B | 45.6% at 98.9% | 45.7% at 72.0% | +0.1 (-1.6 to +1.9) | 45.6% (44.0% to 47.3%) | 55.4% | 325 (178 correct) |
| Retrieved | Qwen3-0.6B | 42.8% at 97.0% | 42.7% at 37.6% | -0.1 (-4.1 to +3.9) | 42.8% (39.2% to 46.5%) | 49.8% | 719 (411 correct) |
| Retrieved | Qwen3-4B-Instruct-2507 | 20.7% at 95.9% | 20.5% at 85.1% | -0.2 (-1.1 to +0.7) | 20.7% (19.8% to 21.5%) | 37.0% | 131 (102 correct) |
| Abstract | Qwen3-1.7B | 48.8% at 98.3% | 49.3% at 85.6% | +0.5 (-0.8 to +1.8) | 48.8% (47.7% to 49.9%) | 85.6% | 148 (81 correct) |
| Abstract | Qwen3-0.6B | 49.2% at 81.5% | 51.4% at 30.7% | +2.2 (-2.8 to +7.1) | 49.2% (45.0% to 53.4%) | 86.4% | 591 (308 correct) |
| Oracle | Qwen3-1.7B | 28.9% at 95.5% | 29.2% at 81.4% | +0.3 (-0.8 to +1.4) | 28.9% (27.7% to 30.0%) | 74.7% | 170 (124 correct) |
| Oracle | Qwen3-0.6B | 34.8% at 67.8% | 29.8% at 32.7% | -5.1 (-8.6 to -1.6) | 34.8% (31.3% to 38.4%) | 0.2% | 422 (255 correct) |


## Discussion

For a small local model answering questions about trial reports, a quote that genuinely appeared in the source was attached to a wrong answer close to half the time. Rejecting answers without such a quote removed about a quarter of the primary model's answers without lowering the error of the rest, and in 6 of the 7 model and context combinations the rule did no better than random rejection at the same coverage. Qwen3-4B-Instruct-2507, a later and larger release, gave more correct labels than Qwen3-1.7B (+22.2 percentage points, 95% CI +18.5 to +26.0, 1,209 prompts) and about half as many quote-valid wrong answers (213 against 423), yet about one in five of its quote-valid answers was still wrong, and quote validity again did not say which. In the primary condition, quote presence did not distinguish correct from incorrect labels. 

The finding matches earlier observations on frontier models, where a substantial share of errors with valid quotes were misreadings of the right evidence [10] and filtering on mechanical quote validity left macro-F1 essentially unchanged.[2] Here the joint rate covers a full test split and laptop-sized models, and the rule is compared with random rejection.

Most quote-valid wrong answers reported a statistically significant effect where the trial reported none, and the model rarely chose "no significant difference" (recall 0.219 for that class, against precision 0.918). A sentence describing a numerical difference can be quoted correctly while its p-value or confidence interval is ignored. About three in ten errors reversed the direction of a significant effect, and most of these answered an increase where the benchmark recorded a decrease (106 of 122), in line with the model's preference for that label (recall 0.926, precision 0.488). Confusing the intervention with the comparator may also contribute: a fine-tuned 4-billion-parameter classifier on the same benchmark kept its direction answer for about a third of prompts when the two were exchanged.[15] 

Retrieval failure explains only part of the errors. In 123 (29.1%) of the quote-valid wrong answers the quote overlapped the annotators' evidence, and in the oracle condition, where the model was handed the annotated evidence, it still erred on 29.2% of quote-valid answers.

The baselines illustrate the limits of a presence check. An extractive system passes it almost automatically: a majority-class guess with a retrieved passage attached passed it for 1,209 of 1,209 prompts. Quote presence can therefore be satisfied without reading the evidence at all, and in these results it carried little information about whether the answer was right. Work on attribution treats support as separate from correctness,[5-7] and medical citation checking has warned that verbatim quoting can satisfy source checks trivially.[9] 

The development-fitted scoring rule ordered test answers better than random, which suggests that cheap observable signals beyond quote presence carry some information about correctness, but it was exploratory, was not designed to show which signals matter, and does not give calibrated probabilities. Semantic checks with natural language inference models [16,17] or human review are candidates for tools that inform clinical or review decisions, but neither was tested here, and both deserve the same comparison with random rejection.

For developers and reviewers of evidence tools, the practical implication is to report quote validity and answer correctness as separate quantities and to test any validity-based filter against random rejection at the same coverage before relying on it. The released harness supports models that return its specified answer schema.

### Limitations

Evidence Inference 2.0 is public and may be in the pretraining data of the evaluated models; a clean train and test split does not rule this out. Only models of 0.6 to 4 billion parameters from one family were evaluated, with one prompt, greedy decoding, thinking mode disabled for the two hybrid models, and a lexical retriever at one token budget, so the estimates do not describe larger, proprietary, or task-fine-tuned models, reasoning modes, or better retrieval. Qwen3-4B-Instruct-2507 also differs from the other two models in release and post-training, so comparisons with it do not isolate model size. The estimate is sensitive to the prompt: on development data, a variant with a worked example gave a lower label-error rate among quote-valid answers, 35.3% (83 of 235) against 41.7% (120 of 288), but fewer existing quotes, and it lost on the prespecified success rule. 

Benchmark labels come from physicians with verification, but they contain known noise, and annotators marked one or two evidence spans, so a quote outside them may still be valid evidence. Error categories are rule-based, not expert judgments. The pooled rate depends on the benchmark's mix of labels, so it will differ where null results are more or less common. 

The test articles were published between 1993 and 2018, so the benchmark is an older expert-annotated sample, not a sample of current literature. Finally, the benchmark asks for statistical significance in one comparison, which is narrower than the judgments evidence reviewers make.

## Conclusion

For the primary model, answers whose verbatim quote appeared in the trial report were right no more often than answers without one, and keeping only answers with a valid quote and passage identifier performed no better than random rejection in any context. Qwen3-4B-Instruct-2507, a later and larger release, gave more correct labels, but about one in five of its quote-valid answers was still wrong; across all models and contexts the rule beat random rejection in 1 of 7 combinations. Tools that extract trial results need a check on whether the label follows from the quoted evidence, in addition to the check that the quote exists.

## Acknowledgments

I conceived and designed the study, developed the code, conducted the analyses, verified the results, checked the key citations, and reviewed and revised the manuscript. Claude Code (Anthropic) and ChatGPT (OpenAI) were used as tools for software development, data analysis, literature searching, and manuscript drafting and formatting. Codex (OpenAI) assisted with editorial revision and document formatting. I recall using Opus models in Claude Code and models from the GPT-5 and GPT-6 families in ChatGPT and Codex. Exact model version records are unavailable.

## Competing interests

I own Norlowe Research, where I conducted this work. I have no other competing interests to declare.

## Funding

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors. The work was carried out with the resources of Norlowe Research.

## Author contributions

Animesh Bose (sole author): Conceptualization, Methodology, Software, Validation, Formal analysis, Investigation, Data curation, Visualization, Project administration, Writing (original draft), Writing (review and editing).

## Ethics

This study was a secondary analysis of published clinical trial reports and existing, publicly available benchmark annotations. No participants were recruited, and no individual-level or identifiable personal data were used. Institutional review board review was not sought.

## Data availability

The Evidence Inference 2.0 corpus is publicly available from its authors at https://github.com/jayded/evidence-inference (analyzed at commit a661e8c14f973398380c8865cf2f27a535aaaf6d) and https://evidence-inference.ebm-nlp.com/; the underlying articles come from the PubMed Central Open Access subset and remain under their own licenses. The evaluated models are publicly available from Hugging Face at the revisions listed in Supplementary S3. The analysis code, frozen configuration, every model and baseline response, item-level scores, and result tables are provided in the supplementary archive (Supplementary File 2); its workflow downloads the corpus and models from the sources above, so the analysis can be reproduced without redistributing article texts.

## References

1. Wadhwa S, DeYoung J, Nye B, et al. Jointly Extracting Interventions, Outcomes, and Findings from RCT Reports with LLMs. In: Proceedings of the 8th Machine Learning for Healthcare Conference. 2023;219:754-771. https://proceedings.mlr.press/v219/wadhwa23a.html
2. Windisch P, Weyrich J, Dennstädt F, et al. Show Your Work: Verbatim Evidence Requirements and Automated Assessment of Large Language Models for Biomedical Text Processing of Trial Eligibility Criteria. Cureus. 2026;18(5):e108666. doi:10.7759/cureus.108666
3. Lehman E, DeYoung J, Barzilay R, et al. Inferring Which Medical Treatments Work from Reports of Clinical Trials. In: Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long and Short Papers). 2019:3705-3717. doi:10.18653/v1/N19-1371
4. DeYoung J, Lehman E, Nye B, et al. Evidence Inference 2.0: More Data, Better Models. In: Proceedings of the 19th SIGBioMed Workshop on Biomedical Language Processing. 2020:123-132. doi:10.18653/v1/2020.bionlp-1.13
5. Rashkin H, Nikolaev V, Lamm M, et al. Measuring Attribution in Natural Language Generation Models. Comput Linguist. 2023;49(4):777-840. doi:10.1162/coli_a_00486
6. Bohnet B, Tran VQ, Verga P, et al. Attributed Question Answering: Evaluation and Modeling for Attributed Large Language Models. arXiv:2212.08037. Preprint posted 2022. https://arxiv.org/abs/2212.08037
7. Liu NF, Zhang T, Liang P. Evaluating Verifiability in Generative Search Engines. In: Findings of the Association for Computational Linguistics: EMNLP 2023. 2023:7001-7025. doi:10.18653/v1/2023.findings-emnlp.467
8. Menick J, Trebacz M, Mikulik V, et al. Teaching language models to support answers with verified quotes. arXiv:2203.11147. Preprint posted 2022. doi:10.48550/arXiv.2203.11147
9. Wu K, Wu E, Wei K, et al. An automated framework for assessing how well LLMs cite relevant medical references. Nat Commun. 2025;16(1):3615. doi:10.1038/s41467-025-58551-6
10. Elbakian K, Carton S. Retrieving Versus Understanding Extractive Evidence in Few-Shot Learning. In: Proceedings of the AAAI Conference on Artificial Intelligence. 2025;39(26):27268-27276. doi:10.1609/aaai.v39i26.34936
11. Buchmann J, Liu X, Gurevych I. Attribute or Abstain: Large Language Models as Long Document Assistants. In: Proceedings of the 2024 Conference on Empirical Methods in Natural Language Processing. 2024:8113-8140. doi:10.18653/v1/2024.emnlp-main.463
12. Geifman Y, El-Yaniv R. Selective Classification for Deep Neural Networks. In: Advances in Neural Information Processing Systems. 2017;30. https://proceedings.neurips.cc/paper_files/paper/2017/file/4a8423d5e91fda00bb7e46540e2b0cf1-Paper.pdf
13. Kamath A, Jia R, Liang P. Selective Question Answering under Domain Shift. In: Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics. 2020:5684-5696. doi:10.18653/v1/2020.acl-main.503
14. Yang A, Li A, Yang B, et al. Qwen3 Technical Report. arXiv:2505.09388. Preprint posted 2025. doi:10.48550/arXiv.2505.09388
15. Li JE. Calibrated Answers About Randomized Trials From a 4-Billion-Parameter Open Model: A Registered Test and a License-Clean Release. arXiv:2610.07019. Preprint posted 2026. doi:10.48550/arXiv.2610.07019
16. Honovich O, Aharoni R, Herzig J, et al. TRUE: Re-evaluating Factual Consistency Evaluation. In: Proceedings of the 2022 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies. 2022:3905-3920. doi:10.18653/v1/2022.naacl-main.287
17. Zha Y, Yang Y, Li R, et al. AlignScore: Evaluating Factual Consistency with A Unified Alignment Function. In: Proceedings of the 61st Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers). 2023:11328-11348. doi:10.18653/v1/2023.acl-long.634

## Figure legends

**Figure 1.** Outcome of every eligible test prompt by model and context: quote valid and label right, quote valid and label wrong, no valid quote with the label right or wrong, abstained, and invalid output.

Alt text: stacked bars; the segment with a valid quote and a wrong label ranges from 10.0% of prompts (Qwen3-0.6B with annotated evidence) to 43.3% (Qwen3-1.7B with the title and abstract).

![Figure 1](../results/figures/fig2_answer_outcomes.svg)

**Figure 2.** Share of quote-valid answers with the wrong label, by context and system. Dots are point estimates and lines are 95% intervals from 10,000 bootstrap resamples of articles; numbers at right are wrong answers out of quote-valid answers.

Alt text: dot and interval chart; the share of quote-valid answers with a wrong label ranges from 20.5% (Qwen3-4B-Instruct-2507 with retrieved passages) to 49.1% (Qwen3-1.7B with the title and abstract), and each system run with annotated evidence has its lowest share in that context.

![Figure 2](../results/figures/fig1_quote_valid_wrong.svg)

**Figure 3.** Retained error for each model and context with all answers (ring) and with only answers whose quote exists and whose passage identifier is valid (triangle), against the middle 95% of 2,000 random rejections at the same coverage (grey band).

Alt text: dumbbell chart; for 6 of the 7 model and context combinations the triangle lies inside the grey band, close to the ring; for Qwen3-0.6B with annotated evidence the triangle lies below the band (29.8% against 31.3% to 38.4%).

![Figure 3](../results/figures/fig3_rejection_rule.svg)

**Figure 4.** Risk-coverage curve for Qwen3-1.7B with retrieved passages, ordering test answers by a scoring rule fitted on development predictions only. The dashed line is the expected error under random ordering; the triangle is the quote-validity rule's single operating point.

Alt text: line chart; the fitted rule's error falls below the random line at most coverages, while the quote-validity rule sits on the random line.

![Figure 4](../results/figures/fig4_risk_coverage.svg)
