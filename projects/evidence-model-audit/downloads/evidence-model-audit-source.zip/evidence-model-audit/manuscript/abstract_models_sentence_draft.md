The rate was {{qwen306b_retrieved_qvwr_pct}} for Qwen3-0.6B and {{qwen34binstruct2507_retrieved_qvwr_pct}} for Qwen3-4B-Instruct-2507.
