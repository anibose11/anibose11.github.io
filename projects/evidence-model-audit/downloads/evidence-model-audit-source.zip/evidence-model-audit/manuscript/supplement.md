# Supplementary material (Supplementary File 1)

Verbatim evidence quotes and answer correctness: an evaluation of small local language models extracting clinical trial results. Supplementary File 2 is the analysis archive (code, configuration, model responses, item-level scores, and result tables).

## S1. Data reconciliation

The corpus was used at commit a661e8c14f973398380c8865cf2f27a535aaaf6d of github.com/jayded/evidence-inference and reconciled against the tarball linked from the project site (v2.0.tar.gz, Last-Modified 12 May 2020, SHA-256 6abe0d4e...1586). Prompts and split files were byte-identical. Annotation rows (24,686) matched in order and in user, prompt, article, validity flags, label code, and "In Abstract" values. The tarball writes the label "significantly increase" in 693 rows whose label code is 1. Of its 4,454 text files, 3,525 are identical to the repository texts once line endings are converted; the other 929 use a different rendering without the title line and with plain section headers, and all 4,666 annotation rows whose offsets differ between the releases belong to 915 of those articles. The posted test answers file (2,408 rows) matched the repository's test rows in order and in user, prompt, article, validity flags, label code, and "In Abstract" values; like the tarball, it uses the "significantly increase" spelling and the tarball's offsets. Two links in the project site's JavaScript returned the site's HTML page instead of CSV and were rejected.

Offsets were tested on a seeded sample of 3,000 training rows. Exclusive ends reproduced the annotation string for 2,759 rows with the repository text and 2,705 rows with the tarball text after newline normalization; inclusive ends reproduced 0 and 0. Location status of accepted evidence spans across all splits: exact 21,473; exact after whitespace normalization 934; exact at the recorded offsets after unescaping HTML entities 685; found at a different position by unique string match 108 (plus 75 after unescaping); missing offsets recovered by string match 25 (plus 1 after unescaping); ambiguous match, nearest used 1; offsets given but string not found 29; missing offsets and string not found 882; article without text 29. Spans in the last three groups are not used as evidence (analysis plan amendment A3).

The repository's abstracts folder holds 3,285 files, of which 2,334 contain body sections. The abstract condition instead used the title-plus-abstract region of the plain-text rendering, which was delimitable for 319 of the 334 test articles with prompts. For the 818 abstract-only files whose article also had a delimitable region, 745 matched that region exactly after header lines were removed and whitespace collapsed. No article appears in two splits, no two texts are identical, and no pair of articles reached TF-IDF cosine 0.9 over their opening 4,000 characters.

The 332 test articles with eligible prompts were published between 1993 and 2018 (median 2014; Europe PMC metadata). Test prompts by label status: unanimous accepted label 1,221, accepted labels disagree 3, no accepted annotation 4, no annotation 24. Six test prompts are on the corpus authors' "Incorrect" list; none are on the "Questionable" or "Somewhat malformed" lists. One test article (PMC2206488) has an empty plain-text file in the repository and in the tarball; its 6 eligible prompts were run with an empty retrieved context and then excluded under amendment A2. Fourteen other articles have texts shorter than 500 characters (twelve training, one validation, one test); none has a prompt in the corpus, so none enters any analysis.

## S2. Prompt and answer schema

Each request was a single user message containing, in order: a one-sentence task statement ("You are reading passages from a report of a clinical trial and answering one question about it."); the question, built from the template "With respect to {outcome}, characterize the reported difference between patients receiving {intervention} and those receiving {comparator}."; the passages, one per line as "[P*n*] text"; the label guide; and the format guide.

Label guide: Label meanings. "significantly increased": the report says the outcome was statistically significantly higher with the intervention than with the comparator. "significantly decreased": statistically significantly lower. "no significant difference": the report says the difference was not statistically significant. "cannot determine": the passages do not report this comparison. Increased and decreased describe the value of the outcome measure, not whether the result is good or bad for patients.

Format guide: Answer with one JSON object and nothing else, using exactly these keys: {"label": "significantly increased" | "significantly decreased" | "no significant difference" | "cannot determine", "evidence_quote": "<text copied character for character from one passage>", "passage_id": "<the passage ID the quote comes from, for example P2>"} If the label is "cannot determine", use "" for evidence_quote and null for passage_id. Copy the quote exactly; do not paraphrase, shorten words, or join text from different passages.

Variant v2 (evaluated on development data only) added this invented example before the format guide: Example. Question: With respect to pain score at 24 hours, characterize the reported difference between patients receiving drug A and those receiving placebo. [P1] Pain scores at 24 hours were lower with drug A than with placebo (2.1 versus 3.4, P = 0.01). [P2] Nausea occurred in 12% and 10% of patients, respectively (P = 0.62). Answer: {"label": "significantly decreased", "evidence_quote": "Pain scores at 24 hours were lower with drug A than with placebo (2.1 versus 3.4, P = 0.01).", "passage_id": "P1"}

The answer schema required exactly three keys: `label` (one of the three benchmark labels or "cannot determine"), `evidence_quote` (string), and `passage_id` (string or null); additional keys were not allowed.

## S3. Models and inference settings

| Model | Repository | Pinned revision | Role |
| --- | --- | --- | --- |
| Qwen3-1.7B | Qwen/Qwen3-1.7B | `70d244cc86ccca08cf5af4e1e306ecf908b1ad5e` | primary |
| Qwen3-0.6B | Qwen/Qwen3-0.6B | `c1899de289a04d12100db370d81485cdf75e47ca` | lower-capacity comparison |
| Qwen3-4B-Instruct-2507 | Qwen/Qwen3-4B-Instruct-2507 | `cdbee75f17c01a7cc42f958dc650907174af0554` | larger extension |

All models were loaded from local snapshots at these revisions with Hugging Face Transformers 5.19.0 and PyTorch 2.14.1, in float32, on an Apple M5 Pro (Metal Performance Shaders). Chat templates came from each repository; the two hybrid models received `enable_thinking=False`. Decoding was greedy with at most 256 new tokens and no repetition penalty. Prompts were not batched. Development parity between the GPU and CPU paths: same label for 40 of 40 prompts, identical responses for 40 of 40.

Runs on the frozen test sample: Qwen3-1.7B completed 333 articles in 2.7 hours (3,592 calls across three contexts); Qwen3-0.6B completed 333 articles in 1.2 hours (3,592 calls); Qwen3-4B-Instruct-2507 completed 333 articles in 2.4 hours (1,218 calls, retrieved context only). After amendment A3, the oracle condition was run again with Qwen3-1.7B and Qwen3-0.6B for the 13 prompts per model whose evidence passages had changed (26 calls; every other response was reused from the cache), so the prediction files hold 8,428 recorded test responses, including the superseded original oracle responses for those prompts.

## S4. Baseline training

| Context | Training prompts | Validation prompts | C | Class weight | Validation macro-F1 |
| --- | ---: | ---: | ---: | --- | ---: |
| Retrieved | 10,030 | 1,231 | 1.0 | balanced | 0.550 |
| Abstract | 9,701 | 1,174 | 1.0 | balanced | 0.517 |
| Oracle | 9,829 | 1,201 | 1.0 | balanced | 0.780 |

## S5. Parse status by model and context

| Context | Model | Valid | Schema error | Invalid JSON | No JSON object | Empty | Runtime error | Not run | Stopped at length limit |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Retrieved | Qwen3-1.7B | 1,205 | 1 | 3 | 0 | 0 | 0 | 0 | 2 |
| Retrieved | Qwen3-0.6B | 1,179 | 27 | 3 | 0 | 0 | 0 | 0 | 3 |
| Retrieved | Qwen3-4B-Instruct-2507 | 1,206 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| Abstract | Qwen3-1.7B | 1,156 | 6 | 3 | 0 | 0 | 0 | 0 | 2 |
| Abstract | Qwen3-0.6B | 994 | 137 | 34 | 0 | 0 | 0 | 0 | 34 |
| Oracle | Qwen3-1.7B | 1,195 | 2 | 5 | 0 | 0 | 0 | 0 | 3 |
| Oracle | Qwen3-0.6B | 1,187 | 14 | 1 | 0 | 0 | 0 | 0 | 0 |

## S6. Per-class results

| Context | System | Benchmark class | Support | Precision | Recall | Quote-valid wrong, by benchmark class | Quote-valid wrong, by predicted class |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Retrieved | Qwen3-1.7B | significantly increased | 407 | 0.488 | 0.926 | 19 of 310 | 309 of 600 |
| Retrieved | Qwen3-1.7B | no significant difference | 511 | 0.918 | 0.219 | 295 of 385 | 6 of 96 |
| Retrieved | Qwen3-1.7B | significantly decreased | 291 | 0.536 | 0.557 | 109 of 233 | 108 of 232 |
| Retrieved | Qwen3-0.6B | significantly increased | 407 | 0.485 | 0.742 | 59 of 259 | 218 of 418 |
| Retrieved | Qwen3-0.6B | no significant difference | 511 | 0.674 | 0.659 | 107 of 326 | 101 of 320 |
| Retrieved | Qwen3-0.6B | significantly decreased | 291 | 0.640 | 0.110 | 165 of 188 | 12 of 35 |
| Retrieved | Qwen3-4B-Instruct-2507 | significantly increased | 407 | 0.809 | 0.740 | 89 of 358 | 64 of 333 |
| Retrieved | Qwen3-4B-Instruct-2507 | no significant difference | 511 | 0.910 | 0.716 | 92 of 426 | 33 of 367 |
| Retrieved | Qwen3-4B-Instruct-2507 | significantly decreased | 291 | 0.655 | 0.869 | 32 of 255 | 116 of 339 |
| Retrieved | TF-IDF + LR | significantly increased | 407 | 0.574 | 0.541 | 187 of 407 | 163 of 383 |
| Retrieved | TF-IDF + LR | no significant difference | 511 | 0.620 | 0.628 | 190 of 511 | 197 of 518 |
| Retrieved | TF-IDF + LR | significantly decreased | 291 | 0.500 | 0.529 | 137 of 291 | 154 of 308 |
| Retrieved | Majority class | significantly increased | 407 | 0.000 | 0.000 | 407 of 407 | 0 of 0 |
| Retrieved | Majority class | no significant difference | 511 | 0.423 | 1.000 | 0 of 511 | 698 of 1209 |
| Retrieved | Majority class | significantly decreased | 291 | 0.000 | 0.000 | 291 of 291 | 0 of 0 |
| Abstract | Qwen3-1.7B | significantly increased | 396 | 0.478 | 0.843 | 52 of 348 | 328 of 624 |
| Abstract | Qwen3-1.7B | no significant difference | 492 | 0.828 | 0.205 | 343 of 437 | 19 of 113 |
| Abstract | Qwen3-1.7B | significantly decreased | 277 | 0.466 | 0.545 | 109 of 241 | 157 of 289 |
| Abstract | Qwen3-0.6B | significantly increased | 396 | 0.463 | 0.558 | 66 of 241 | 212 of 387 |
| Abstract | Qwen3-0.6B | no significant difference | 492 | 0.562 | 0.478 | 119 of 297 | 115 of 293 |
| Abstract | Qwen3-0.6B | significantly decreased | 277 | 0.481 | 0.094 | 167 of 187 | 25 of 45 |
| Abstract | TF-IDF + LR | significantly increased | 396 | 0.529 | 0.508 | 194 of 394 | 179 of 379 |
| Abstract | TF-IDF + LR | no significant difference | 492 | 0.584 | 0.563 | 214 of 491 | 197 of 474 |
| Abstract | TF-IDF + LR | significantly decreased | 277 | 0.457 | 0.513 | 135 of 276 | 167 of 308 |
| Abstract | Majority class | significantly increased | 396 | 0.000 | 0.000 | 394 of 394 | 0 of 0 |
| Abstract | Majority class | no significant difference | 492 | 0.422 | 1.000 | 0 of 491 | 670 of 1161 |
| Abstract | Majority class | significantly decreased | 277 | 0.000 | 0.000 | 276 of 276 | 0 of 0 |
| Oracle | Qwen3-1.7B | significantly increased | 404 | 0.617 | 0.931 | 22 of 332 | 200 of 510 |
| Oracle | Qwen3-1.7B | no significant difference | 508 | 0.992 | 0.518 | 170 of 404 | 1 of 235 |
| Oracle | Qwen3-1.7B | significantly decreased | 290 | 0.646 | 0.610 | 94 of 244 | 85 of 235 |
| Oracle | Qwen3-0.6B | significantly increased | 404 | 0.680 | 0.579 | 16 of 195 | 86 of 265 |
| Oracle | Qwen3-0.6B | no significant difference | 508 | 0.600 | 0.474 | 14 of 79 | 26 of 91 |
| Oracle | Qwen3-0.6B | significantly decreased | 290 | 0.812 | 0.193 | 90 of 132 | 8 of 50 |
| Oracle | TF-IDF + LR | significantly increased | 404 | 0.706 | 0.733 | 108 of 404 | 123 of 419 |
| Oracle | TF-IDF + LR | no significant difference | 508 | 0.876 | 0.805 | 99 of 508 | 58 of 467 |
| Oracle | TF-IDF + LR | significantly decreased | 290 | 0.649 | 0.707 | 85 of 290 | 111 of 316 |
| Oracle | Majority class | significantly increased | 404 | 0.000 | 0.000 | 404 of 404 | 0 of 0 |
| Oracle | Majority class | no significant difference | 508 | 0.423 | 1.000 | 0 of 508 | 694 of 1202 |
| Oracle | Majority class | significantly decreased | 290 | 0.000 | 0.000 | 290 of 290 | 0 of 0 |

## S7. Sensitivity analyses

Analysis S1 uses exact substring matching with the same four-word minimum as the primary definition. The minimum was added by amendment A1, recorded after the primary model's test outputs were scored: as first coded, S1 had no length minimum, so short exact quotes made the stricter count larger than the primary count in the oracle condition. The count of exact quotes of any length is reported separately as "quote exists (strict, any length)".

| Context | Model | Analysis | Wrong of quote-valid | Rate (95% CI) |
| --- | --- | --- | ---: | ---: |
| Retrieved | Qwen3-1.7B | Primary (definition Q) | 423 of 928 | 45.6%, 95% CI 41.8% to 49.3% |
| Retrieved | Qwen3-1.7B | S1 strict quote existence | 422 of 926 | 45.6%, 95% CI 41.8% to 49.3% |
| Retrieved | Qwen3-1.7B | S2 include label disagreements | 423 of 931 | 45.4%, 95% CI 41.6% to 49.1% |
| Retrieved | Qwen3-1.7B | S3 exclude flagged prompts | 423 of 928 | 45.6%, 95% CI 41.8% to 49.3% |
| Retrieved | Qwen3-1.7B | S4 one-word minimum quote | 423 of 928 | 45.6%, 95% CI 41.8% to 49.3% |
| Retrieved | Qwen3-1.7B | S5 retrieved passages hold benchmark evidence | 288 of 698 | 41.3%, 95% CI 37.1% to 45.4% |
| Retrieved | Qwen3-0.6B | Primary (definition Q) | 331 of 773 | 42.8%, 95% CI 38.5% to 47.3% |
| Retrieved | Qwen3-0.6B | S1 strict quote existence | 331 of 773 | 42.8%, 95% CI 38.5% to 47.3% |
| Retrieved | Qwen3-0.6B | S2 include label disagreements | 331 of 776 | 42.7%, 95% CI 38.4% to 47.1% |
| Retrieved | Qwen3-0.6B | S3 exclude flagged prompts | 331 of 773 | 42.8%, 95% CI 38.5% to 47.3% |
| Retrieved | Qwen3-0.6B | S4 one-word minimum quote | 341 of 793 | 43.0%, 95% CI 38.7% to 47.3% |
| Retrieved | Qwen3-0.6B | S5 retrieved passages hold benchmark evidence | 244 of 584 | 41.8%, 95% CI 36.9% to 46.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | Primary (definition Q) | 213 of 1,039 | 20.5%, 95% CI 17.4% to 23.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | S1 strict quote existence | 213 of 1,038 | 20.5%, 95% CI 17.5% to 23.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | S2 include label disagreements | 213 of 1,042 | 20.4%, 95% CI 17.4% to 23.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | S3 exclude flagged prompts | 213 of 1,039 | 20.5%, 95% CI 17.4% to 23.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | S4 one-word minimum quote | 213 of 1,039 | 20.5%, 95% CI 17.4% to 23.7% |
| Retrieved | Qwen3-4B-Instruct-2507 | S5 retrieved passages hold benchmark evidence | 142 of 808 | 17.6%, 95% CI 14.5% to 20.9% |
| Abstract | Qwen3-1.7B | Primary (definition Q) | 504 of 1,026 | 49.1%, 95% CI 45.1% to 53.2% |
| Abstract | Qwen3-1.7B | S1 strict quote existence | 504 of 1,026 | 49.1%, 95% CI 45.1% to 53.2% |
| Abstract | Qwen3-1.7B | S2 include label disagreements | 504 of 1,029 | 49.0%, 95% CI 45.0% to 53.0% |
| Abstract | Qwen3-1.7B | S3 exclude flagged prompts | 504 of 1,026 | 49.1%, 95% CI 45.1% to 53.2% |
| Abstract | Qwen3-1.7B | S4 one-word minimum quote | 504 of 1,026 | 49.1%, 95% CI 45.1% to 53.2% |
| Abstract | Qwen3-0.6B | Primary (definition Q) | 352 of 725 | 48.6%, 95% CI 43.9% to 53.3% |
| Abstract | Qwen3-0.6B | S1 strict quote existence | 352 of 725 | 48.6%, 95% CI 43.9% to 53.3% |
| Abstract | Qwen3-0.6B | S2 include label disagreements | 352 of 727 | 48.4%, 95% CI 43.7% to 53.1% |
| Abstract | Qwen3-0.6B | S3 exclude flagged prompts | 352 of 725 | 48.6%, 95% CI 43.9% to 53.3% |
| Abstract | Qwen3-0.6B | S4 one-word minimum quote | 361 of 740 | 48.8%, 95% CI 44.1% to 53.4% |
| Oracle | Qwen3-1.7B | Primary (definition Q) | 286 of 980 | 29.2%, 95% CI 25.7% to 32.9% |
| Oracle | Qwen3-1.7B | S1 strict quote existence | 286 of 980 | 29.2%, 95% CI 25.7% to 32.9% |
| Oracle | Qwen3-1.7B | S2 include label disagreements | 286 of 983 | 29.1%, 95% CI 25.6% to 32.7% |
| Oracle | Qwen3-1.7B | S3 exclude flagged prompts | 286 of 980 | 29.2%, 95% CI 25.7% to 32.9% |
| Oracle | Qwen3-1.7B | S4 one-word minimum quote | 289 of 991 | 29.2%, 95% CI 25.7% to 32.8% |
| Oracle | Qwen3-0.6B | Primary (definition Q) | 120 of 406 | 29.6%, 95% CI 24.9% to 34.2% |
| Oracle | Qwen3-0.6B | S1 strict quote existence | 120 of 406 | 29.6%, 95% CI 24.9% to 34.2% |
| Oracle | Qwen3-0.6B | S2 include label disagreements | 120 of 409 | 29.3%, 95% CI 24.9% to 34.0% |
| Oracle | Qwen3-0.6B | S3 exclude flagged prompts | 120 of 406 | 29.6%, 95% CI 24.9% to 34.2% |
| Oracle | Qwen3-0.6B | S4 one-word minimum quote | 123 of 412 | 29.9%, 95% CI 25.4% to 34.5% |

## S8. Paired comparisons

Differences are on the prompts both systems had, with 95% intervals from 10,000 paired bootstrap resamples of articles.

| System A | System B | Quantity | Shared prompts | A | B | A minus B, points (95% CI) |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Qwen3-1.7B, retrieved | Qwen3-0.6B, retrieved | Task success | 1,209 | 39.1% | 21.5% | +17.6 (+13.8 to +21.5) |
| Qwen3-1.7B, retrieved | Qwen3-0.6B, retrieved | Correct label (all prompts) | 1,209 | 53.8% | 55.5% | -1.7 (-6.1 to +2.9) |
| Qwen3-1.7B, retrieved | Qwen3-0.6B, retrieved | Quote valid and locator valid (all prompts) | 1,209 | 72.0% | 37.6% | +34.5 (+30.1 to +39.0) |
| Qwen3-1.7B, retrieved | TF-IDF + LR, retrieved | Task success | 1,209 | 39.1% | 57.5% | -18.4 (-22.7 to -14.0) |
| Qwen3-1.7B, retrieved | TF-IDF + LR, retrieved | Correct label (all prompts) | 1,209 | 53.8% | 57.5% | -3.6 (-8.1 to +0.7) |
| Qwen3-1.7B, retrieved | TF-IDF + LR, retrieved | Quote valid and locator valid (all prompts) | 1,209 | 72.0% | 100.0% | -28.0 (-30.9 to -25.0) |
| Qwen3-1.7B, abstract | Qwen3-0.6B, abstract | Task success | 1,165 | 43.3% | 14.9% | +28.4 (+24.1 to +32.7) |
| Qwen3-1.7B, abstract | Qwen3-0.6B, abstract | Correct label (all prompts) | 1,165 | 50.3% | 41.4% | +8.9 (+4.0 to +13.7) |
| Qwen3-1.7B, abstract | Qwen3-0.6B, abstract | Quote valid and locator valid (all prompts) | 1,165 | 85.6% | 30.7% | +54.8 (+49.3 to +60.3) |
| Qwen3-1.7B, abstract | TF-IDF + LR, abstract | Task success | 1,165 | 43.3% | 53.0% | -9.7 (-14.6 to -4.9) |
| Qwen3-1.7B, abstract | TF-IDF + LR, abstract | Correct label (all prompts) | 1,165 | 50.3% | 53.2% | -2.9 (-7.7 to +1.9) |
| Qwen3-1.7B, abstract | TF-IDF + LR, abstract | Quote valid and locator valid (all prompts) | 1,165 | 85.6% | 99.7% | -14.1 (-17.0 to -11.3) |
| Qwen3-1.7B, oracle | Qwen3-0.6B, oracle | Task success | 1,202 | 57.6% | 23.0% | +34.6 (+30.9 to +38.2) |
| Qwen3-1.7B, oracle | Qwen3-0.6B, oracle | Correct label (all prompts) | 1,202 | 67.9% | 44.2% | +23.7 (+19.6 to +27.7) |
| Qwen3-1.7B, oracle | Qwen3-0.6B, oracle | Quote valid and locator valid (all prompts) | 1,202 | 81.4% | 32.7% | +48.7 (+45.0 to +52.2) |
| Qwen3-1.7B, oracle | TF-IDF + LR, oracle | Task success | 1,202 | 57.6% | 75.7% | -18.1 (-22.0 to -14.4) |
| Qwen3-1.7B, oracle | TF-IDF + LR, oracle | Correct label (all prompts) | 1,202 | 67.9% | 75.7% | -7.8 (-11.4 to -4.3) |
| Qwen3-1.7B, oracle | TF-IDF + LR, oracle | Quote valid and locator valid (all prompts) | 1,202 | 81.4% | 100.0% | -18.6 (-21.2 to -16.2) |
| Qwen3-4B-Instruct-2507, retrieved | Qwen3-1.7B, retrieved | Task success | 1,209 | 67.7% | 39.1% | +28.5 (+24.6 to +32.4) |
| Qwen3-4B-Instruct-2507, retrieved | Qwen3-1.7B, retrieved | Correct label (all prompts) | 1,209 | 76.1% | 53.8% | +22.2 (+18.5 to +26.0) |
| Qwen3-4B-Instruct-2507, retrieved | Qwen3-1.7B, retrieved | Quote valid and locator valid (all prompts) | 1,209 | 85.1% | 72.0% | +13.1 (+9.5 to +16.5) |
| Qwen3-1.7B, abstract | Qwen3-1.7B, retrieved | Task success | 1,165 | 43.3% | 39.2% | +4.1 (+0.4 to +7.9) |
| Qwen3-1.7B, abstract | Qwen3-1.7B, retrieved | Correct label (all prompts) | 1,165 | 50.3% | 54.1% | -3.8 (-6.9 to -0.6) |
| Qwen3-1.7B, abstract | Qwen3-1.7B, retrieved | Quote valid and locator valid (all prompts) | 1,165 | 85.6% | 71.8% | +13.7 (+9.5 to +17.7) |
| Qwen3-1.7B, oracle | Qwen3-1.7B, retrieved | Task success | 1,202 | 57.6% | 39.1% | +18.5 (+14.6 to +22.3) |
| Qwen3-1.7B, oracle | Qwen3-1.7B, retrieved | Correct label (all prompts) | 1,202 | 67.9% | 53.9% | +14.0 (+10.4 to +17.4) |
| Qwen3-1.7B, oracle | Qwen3-1.7B, retrieved | Quote valid and locator valid (all prompts) | 1,202 | 81.4% | 72.0% | +9.3 (+5.9 to +12.8) |
| Qwen3-0.6B, abstract | Qwen3-0.6B, retrieved | Task success | 1,165 | 14.9% | 21.6% | -6.7 (-10.4 to -2.9) |
| Qwen3-0.6B, abstract | Qwen3-0.6B, retrieved | Correct label (all prompts) | 1,165 | 41.4% | 56.1% | -14.7 (-18.7 to -10.7) |
| Qwen3-0.6B, abstract | Qwen3-0.6B, retrieved | Quote valid and locator valid (all prompts) | 1,165 | 30.7% | 37.1% | -6.4 (-12.0 to -0.6) |
| Qwen3-0.6B, oracle | Qwen3-0.6B, retrieved | Task success | 1,202 | 23.0% | 21.4% | +1.6 (-1.9 to +5.1) |
| Qwen3-0.6B, oracle | Qwen3-0.6B, retrieved | Correct label (all prompts) | 1,202 | 44.2% | 55.4% | -11.2 (-15.2 to -7.3) |
| Qwen3-0.6B, oracle | Qwen3-0.6B, retrieved | Quote valid and locator valid (all prompts) | 1,202 | 32.7% | 37.5% | -4.8 (-9.5 to -0.2) |

## S9. Evidence available in the supplied passages

| Context | Prompts with located evidence | Passages overlap evidence (95% CI) | Passages contain a full span (95% CI) | Median context tokens | Truncated |
| --- | ---: | ---: | ---: | ---: | ---: |
| Retrieved | 1,202 | 76.2%, 95% CI 72.4% to 79.9% | 70.0%, 95% CI 66.2% to 73.7% | 1021 | 0.0% |
| Abstract | 1,158 | 50.2%, 95% CI 45.8% to 54.5% | 50.1%, 95% CI 45.7% to 54.4% | 429 | 2.1% |

## S10. Automated error categories for quote-valid wrong answers

| Context | Model | Error type | Quote relation to benchmark evidence | Count |
| --- | --- | --- | --- | ---: |
| Abstract | Qwen3-0.6B | significance error (model said significant) | quote outside benchmark evidence | 105 |
| Abstract | Qwen3-0.6B | significance error (model said not significant) | quote outside benchmark evidence | 80 |
| Abstract | Qwen3-0.6B | direction reversal | quote outside benchmark evidence | 66 |
| Abstract | Qwen3-0.6B | direction reversal | quote overlaps benchmark evidence | 52 |
| Abstract | Qwen3-0.6B | significance error (model said not significant) | quote overlaps benchmark evidence | 35 |
| Abstract | Qwen3-0.6B | significance error (model said significant) | quote overlaps benchmark evidence | 13 |
| Abstract | Qwen3-0.6B | significance error (model said significant) | benchmark evidence not located | 1 |
| Oracle | Qwen3-0.6B | direction reversal | quote overlaps benchmark evidence | 80 |
| Oracle | Qwen3-0.6B | significance error (model said not significant) | quote overlaps benchmark evidence | 26 |
| Oracle | Qwen3-0.6B | significance error (model said significant) | quote overlaps benchmark evidence | 14 |
| Retrieved | Qwen3-0.6B | significance error (model said significant) | quote outside benchmark evidence | 85 |
| Retrieved | Qwen3-0.6B | significance error (model said not significant) | quote outside benchmark evidence | 84 |
| Retrieved | Qwen3-0.6B | direction reversal | quote outside benchmark evidence | 80 |
| Retrieved | Qwen3-0.6B | direction reversal | quote overlaps benchmark evidence | 42 |
| Retrieved | Qwen3-0.6B | significance error (model said significant) | quote overlaps benchmark evidence | 22 |
| Retrieved | Qwen3-0.6B | significance error (model said not significant) | quote overlaps benchmark evidence | 17 |
| Retrieved | Qwen3-0.6B | direction reversal | benchmark evidence not located | 1 |
| Abstract | Qwen3-1.7B | significance error (model said significant) | quote outside benchmark evidence | 288 |
| Abstract | Qwen3-1.7B | direction reversal | quote outside benchmark evidence | 88 |
| Abstract | Qwen3-1.7B | direction reversal | quote overlaps benchmark evidence | 53 |
| Abstract | Qwen3-1.7B | significance error (model said significant) | quote overlaps benchmark evidence | 52 |
| Abstract | Qwen3-1.7B | significance error (model said not significant) | quote outside benchmark evidence | 15 |
| Abstract | Qwen3-1.7B | significance error (model said not significant) | quote overlaps benchmark evidence | 4 |
| Abstract | Qwen3-1.7B | significance error (model said significant) | benchmark evidence not located | 3 |
| Abstract | Qwen3-1.7B | direction reversal | benchmark evidence not located | 1 |
| Oracle | Qwen3-1.7B | significance error (model said significant) | quote overlaps benchmark evidence | 170 |
| Oracle | Qwen3-1.7B | direction reversal | quote overlaps benchmark evidence | 115 |
| Oracle | Qwen3-1.7B | significance error (model said not significant) | quote overlaps benchmark evidence | 1 |
| Retrieved | Qwen3-1.7B | significance error (model said significant) | quote outside benchmark evidence | 218 |
| Retrieved | Qwen3-1.7B | significance error (model said significant) | quote overlaps benchmark evidence | 76 |
| Retrieved | Qwen3-1.7B | direction reversal | quote outside benchmark evidence | 74 |
| Retrieved | Qwen3-1.7B | direction reversal | quote overlaps benchmark evidence | 47 |
| Retrieved | Qwen3-1.7B | significance error (model said not significant) | quote outside benchmark evidence | 6 |
| Retrieved | Qwen3-1.7B | direction reversal | benchmark evidence not located | 1 |
| Retrieved | Qwen3-1.7B | significance error (model said significant) | benchmark evidence not located | 1 |
| Retrieved | Qwen3-4B-Instruct-2507 | significance error (model said significant) | quote outside benchmark evidence | 58 |
| Retrieved | Qwen3-4B-Instruct-2507 | direction reversal | quote overlaps benchmark evidence | 48 |
| Retrieved | Qwen3-4B-Instruct-2507 | direction reversal | quote outside benchmark evidence | 39 |
| Retrieved | Qwen3-4B-Instruct-2507 | significance error (model said significant) | quote overlaps benchmark evidence | 32 |
| Retrieved | Qwen3-4B-Instruct-2507 | significance error (model said not significant) | quote outside benchmark evidence | 30 |
| Retrieved | Qwen3-4B-Instruct-2507 | significance error (model said not significant) | quote overlaps benchmark evidence | 3 |
| Retrieved | Qwen3-4B-Instruct-2507 | significance error (model said significant) | benchmark evidence not located | 2 |
| Retrieved | Qwen3-4B-Instruct-2507 | direction reversal | benchmark evidence not located | 1 |

## S11. Reproducibility and software checks

* Software tests: synthetic fixtures for parsing, quote location across line breaks, locators, the label contract, offsets, chunking, abstract delimiting, the bootstrap, macro-F1, and the rejection arithmetic.
* Deterministic rerun: data, contexts, scores, and analysis rebuilt from cached inputs; 4,809 reported numbers compared with the stored results at a relative tolerance of 1e-9.
* Separate recount: the headline numerators and denominators and task success counts recomputed from the item-level files in base R.
* Model rerun: a sample of test calls regenerated with the frozen configuration on the same device; 40 of 40 responses were identical and 40 of 40 had the same label.
* Clean installation: the analysis archive (Supplementary File 2) was extracted into an empty directory and installed into a new virtual environment from requirements.lock.txt; all 34 tests passed and the cached demonstration reproduced the saved outputs for the bundled examples.
* Author check against source articles: 20 quote-valid wrong answers from Qwen3-1.7B with retrieved passages, drawn with seed 20261007 (prompt IDs 572, 770, 1461, 2826, 3950, 4353, 4458, 5216, 5362, 7727, 7931, 9354, 11214, 11896, 12175, 12355, 13005, 13492, 13837, 13876), were compared with the articles in PubMed Central, and the label codes of five of them were checked against the raw annotation file.
* Claims: every headline number in evidence/claims.json is mapped to its file, key, numerator, denominator, scope, configuration, source hashes, and run identifier, and re-read from the results file.

These checks test the software and its consistency. They are not external scientific validation.

## S12. TRIPOD-LLM checklist

Items are paraphrased from the TRIPOD-LLM reporting guideline (Gallifant et al., Nature Medicine 2025;31:60-69, doi:10.1038/s41591-024-03425-5), main checklist (Table 2) and abstract checklist (Table 3). This study is an LLM evaluation without patient data.

| Item | Section | What is reported (paraphrased) | Where |
|---|---|---|---|
| 1 | Title | Title should state whether the LLM is developed, fine-tuned or evaluated, plus the task, target population and outcome. | Title |
| 2 | Abstract | Abstract should follow the separate TRIPOD-LLM for Abstracts checklist (items 2a-2l). | Abstract (structured; see items 2a to 2l) |
| 3a | Introduction | Explain the healthcare use case and why the LLM is developed or evaluated, citing existing approaches and models. | Background and Significance, paragraphs 1 to 2 |
| 3b | Introduction | Describe the target population, the LLM's intended use within the care pathway, and its intended users. | Background and Significance, paragraphs 1 and 5 (evidence reviewers; local deployment); not a care-pathway tool |
| 4 | Introduction | State study objectives, including whether it covers initial development, fine-tuning, validation, or several stages. | Objective |
| 5a | Methods | Give data sources separately for training, tuning and evaluation, with the rationale for choosing them. | Methods, Data and labels; Context conditions; Models and inference; Baselines (training split for BM25 statistics and baselines; validation for development decisions; test for evaluation) |
| 5b | Methods | Describe the data points and characterize dataset distribution and descriptors (e.g., source, language, country) quantitatively and qualitatively. | Methods, Data and labels; Results, Output validity; Supplementary S1 |
| 5c | Methods | State the earliest and latest dates of text in development data and in evaluation datasets. | Supplementary S1: test articles published 1993 to 2018; model training cutoffs are not stated on the model cards |
| 5d | Methods | Describe preprocessing and quality checks, and whether they were consistent across corpora, sites and sociodemographic groups. | Methods, Data and labels; Supplementary S1 (offset convention, abstract delimiting, reconciliation) |
| 5e | Methods | Explain how missing and imbalanced data were handled and justify any data exclusions. | Methods, Data and labels (eligibility, disagreement, unlocatable spans); Supplementary S1 |
| 6a | Methods | Report the LLM's name, version and last training date. | Methods, Models and inference; Supplementary S3 (revisions; training cutoff not stated by the developer) |
| 6b | Methods | Describe how the LLM was built: architecture, training, fine-tuning, alignment approach and alignment goals. | Not applicable (evaluation of existing models; no training or fine-tuning) |
| 6c | Methods | Describe how text was generated: prompt engineering, output consistency, and inference settings such as seed and temperature. | Methods, Models and inference; Supplementary S2 and S3 (prompt, greedy decoding, output limit) |
| 6d | Methods | Specify the raw and post-processed LLM outputs (e.g., probabilities, labels, free text). | Methods, Separated validity checks (raw JSON responses and parsed fields; raw responses released) |
| 6e | Methods | Justify any classification approach and explain how probabilities and decision thresholds were derived. | Methods, Baselines (logistic regression, settings chosen on validation macro-F1); no thresholds on model outputs |
| 7a | Methods | Report metrics of generative output quality (consistency, relevance, accuracy, error types) against gold standards. | Methods, Separated validity checks; Results; Table 1 |
| 7b | Methods | Explain how outcome metrics relate to the downstream deployment task and, where possible, to human judgments. | Discussion, paragraphs 6 and 7 |
| 7c | Methods | Define the outcome, how predictions were computed, inference date for closed-source models, and evaluation metrics. | Methods, Estimand and statistical analysis |
| 7d | Methods | For subjective outcome assessment, describe assessor qualifications, instructions, demographics and inter-assessor agreement. | Not applicable (no subjective assessment; labels from the published benchmark) |
| 7e | Methods | Describe how performance was benchmarked against other LLMs, humans, or other standards. | Methods, Baselines; Results, Contexts, models, and baselines; Table 1 |
| 8a | Methods | If annotation occurred, explain the labeling process and share annotation guidelines with examples. | Not applicable (no new annotation); benchmark annotation process summarized in Methods, Data and labels |
| 8b | Methods | If annotation occurred, report annotator count, share of data multiply annotated, and inter-annotator agreement. | Not applicable (no new annotation); label contract and disagreement handling in Methods, Data and labels |
| 8c | Methods | If annotation occurred, describe annotators' background and experience, or characteristics of any labeling models. | Not applicable (no new annotation) |
| 9a | Methods | If prompting was used, describe how prompts were designed, curated and selected. | Methods, Models and inference (two variants written in advance; selected on development data by a fixed rule) |
| 9b | Methods | If prompting was used, state which data informed prompt development. | Methods, Models and inference (100 validation articles; no test data) |
| 10 | Methods | Describe any data preprocessing performed before summarization. | Not applicable (no summarization) |
| 11 | Methods | If instruction tuning/alignment was used, report instructions, data, evaluation interface and evaluator population characteristics. | Not applicable |
| 12 | Methods | Report compute resources or proxies (hardware, time, cost, inference time, FLOPs) needed for the methods. | Results, Output validity; Supplementary S3 (Apple M5 Pro GPU, float32, run times) |
| 13 | Methods | Name the approving ethics board and describe participant consent or the consent waiver. | Ethics statement (no human participants or individual-level data) |
| 14a | Methods | State funding sources and the funders' role in the study. | Funding statement |
| 14b | Methods | Declare all authors' conflicts of interest and financial disclosures. | Conflict of interest statement |
| 14c | Methods | Say where the study protocol is available, or that none was prepared. | Internal timestamped analysis plan released in the project archive (docs/analysis_plan.md); not a registered protocol |
| 14d | Methods | Give registry name and registration number, or state the study was not registered. | Not registered |
| 14e | Methods | Describe availability of the study data. | Data availability statement |
| 14f | Methods | Describe availability of code needed to reproduce the results. | Data availability statement (code, configuration, responses, scores) |
| 15 | Methods | Describe patient/public involvement across study stages, or state there was none. | Not applicable (no patient or public involvement) |
| 16a | Results | With patient/EHR data, describe data flow through the study, including counts with/without outcome and follow-up. | Not applicable (no patient or EHR data); prompt flow in Results and Supplementary S1 |
| 16b | Results | With patient/EHR data, report characteristics overall, per source/setting and per split, including dates and sample size. | Not applicable (no patient or EHR data); test split size in Results (Output validity and evidence availability) and Supplementary S1; training and validation prompt counts in Supplementary S4 |
| 16c | Results | For evaluations with clinical outcomes, compare distributions of outcome-related clinical variables between development and evaluation data. | Not applicable |
| 16d | Results | With patient/EHR data, give participant and outcome-event counts for each analysis. | Not applicable (no patient or EHR data) |
| 17 | Results | Report performance on prespecified metrics (item 7a) and/or human evaluation (item 7d). | Results; Tables 1 and 2; Figures 1 to 4; Supplementary S5 to S10 |
| 18 | Results | If the LLM was updated, report the updated model and its subsequent performance. | Not applicable (models not updated) |
| 19a | Discussion | Interpret the main results overall, including fairness, relative to objectives and prior studies. | Discussion, paragraphs 1 to 3 |
| 19b | Discussion | Discuss limitations and their effects on bias, statistical uncertainty and generalizability. | Discussion, Limitations |
| 19c | Discussion | Describe known data challenges for the task/domain: representation, missingness, harmonization and bias. | Discussion, Limitations (label noise, partial evidence annotation, possible pretraining exposure) |
| 19d | Discussion | Define intended use: inputs, end users, and level of autonomy or human oversight. | Discussion, paragraphs 6 and 7 (evaluation harness for tool developers; outputs need semantic checks or human review) |
| 19e | Discussion | Where relevant, explain how poor or missing input data should be assessed and handled in clinical implementation. | Not applicable (no clinical implementation) |
| 19f | Discussion | Where relevant, state whether users must interact with inputs or the LLM, and the expertise required. | Discussion, paragraphs 6 and 7 (users are tool developers and reviewers; outputs need human review); Lay summary |
| 19g | Discussion | Discuss next research steps, focusing on the LLM's applicability and generalizability. | Discussion, paragraph 6; Limitations |
| 2a | Abstract | Identify the study as LLM development, fine-tuning and/or evaluation, with task, target population and outcome. | Abstract, title |
| 2b | Abstract | Briefly explain the healthcare context, use case and rationale for developing or evaluating the LLM. | Abstract, Objectives |
| 2c | Abstract | State objectives, including whether the study involves LLM development, tuning and/or evaluation. | Abstract, Objectives |
| 2d | Abstract | Summarize key elements of the study setting. | Abstract, Materials and Methods |
| 2e | Abstract | Describe all data used, the data splits, and any selective data use. | Abstract, Materials and Methods (official test split) |
| 2f | Abstract | Name the LLM(s) and version(s) used. | Abstract, Materials and Methods |
| 2g | Abstract | Briefly summarize LLM-building steps such as fine-tuning, reward modeling and RLHF. | Not applicable |
| 2h | Abstract | Describe the tasks the LLM performs and the key inputs/outputs of the final model. | Abstract, Materials and Methods |
| 2i | Abstract | Specify evaluation datasets/populations, endpoints, whether held out from training/tuning, and performance measures. | Abstract, Materials and Methods and Results |
| 2j | Abstract | Give an overall summary and interpretation of the main results. | Abstract, Results |
| 2k | Abstract | State broader implications or concerns arising from the results. | Abstract, Discussion and Conclusion |
| 2l | Abstract | Give registry/repository name and registration number, if relevant. | Not applicable |

## S13. Development-fitted scoring rule

Logistic regression (scikit-learn, C = 1.0) predicting a correct label from six features of each answer, fitted on the answered prompts among the 347 development prompts, using Qwen3-1.7B with retrieved passages, and applied unchanged to test answers. Positive coefficients favor a correct label. The scores are used only to order answers for the risk-coverage curve (Figure 4); they are not calibrated probabilities, and the coefficients are not estimates of feature importance.

| Term | Coefficient |
| --- | ---: |
| Intercept | -1.740 |
| Quote exists (0 or 1) | +0.795 |
| Passage identifier valid (0 or 1) | -0.336 |
| Quote length, log(1 + words) | +0.176 |
| Quote contains significance wording (0 or 1) | -0.303 |
| Label agrees with the quote's significance wording (0 or 1) | +0.822 |
| Share of outcome words that appear in the quote | +1.301 |
