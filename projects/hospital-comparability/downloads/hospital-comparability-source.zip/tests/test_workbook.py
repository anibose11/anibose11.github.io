"""Checks for the Excel review workbook layout. The static checks need no
database; checks against real outputs are skipped when those files are absent."""

from __future__ import annotations

import csv
import re
from pathlib import Path

import pytest

from hospcomp import workbook as wbk

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
WORKBOOK = ROOT / "outputs" / "hospital-comparability-review.xlsx"
HAVE_OUTPUTS = all(p.exists() for p in wbk.CSV_SOURCES.values())
HAVE_WORKBOOK = WORKBOOK.exists() and HAVE_OUTPUTS


def test_every_written_column_has_a_definition():
    assert wbk.undefined_columns() == []
    rows = wbk.definition_rows()
    assert all(len(r) == 5 and all(r) for r in rows)
    defined = {r[0] for r in rows}
    for cols in wbk.sheet_columns().values():
        assert set(cols) <= defined


def test_sheet_order_and_names():
    names = wbk.SHEET_NAMES
    assert names[0] == "Read me" and names[1] == "Definitions" and names[-1] == "Source evidence"
    assert names.index("Records primary") < names.index("Records current HF") < names.index("Pair summary")
    assert len(names) == len(set(names))
    assert all(len(n) <= 31 for n in names)
    assert set(wbk.SHEET_GUIDE) == set(names)
    for _, blocks in wbk.SHEETS:
        for b in blocks:
            assert b in wbk.BLOCK_COLUMNS
            if len(blocks) > 1:
                assert b in wbk.BLOCK_TITLES


def test_record_layout_carries_sources_gates_and_ranks():
    cols = wbk.RECORD_COLUMNS
    for c in ("score_src", "lower_src", "upper_src", "denominator_src", "compared_to_national_src", "footnote_src",
              "start_date_src", "end_date_src", "score_num", "lower_num", "upper_num", "availability_state",
              *wbk.GATES, "first_failed_gate", "reason_code", "compatible", "caution_flag", "point_rank", "best_rank",
              "worst_rank", "n"):
        assert c in cols
    assert len(cols) == len(set(cols))


def test_gate_labels_match_analysis_stage():
    from hospcomp.analyze import GATE_LABELS, GATES

    assert wbk.GATES == GATES
    assert wbk.GATE_LABELS == GATE_LABELS
    assert set(wbk.GATE_RULES) == set(GATES)


def test_number_formats():
    assert wbk.number_format("compatible_share_of_requested", 0.3) == "0.0%"
    assert wbk.number_format("q1", 0.25) == "0.0%"
    assert wbk.number_format("requested_records", 4792) == "#,##0"
    assert wbk.number_format("denominator_num", 473.0) == "#,##0"
    assert wbk.number_format("score_num", 17.9) is None
    assert wbk.number_format("same_unit", True) is None
    assert wbk.number_format("facility_id", "010001") is None


def test_csv_values_keep_identifiers_as_text():
    assert wbk.typed("facility_id", "010001") == "010001"
    assert wbk.typed("only_in_a_ids", "010018") == "010018"
    assert wbk.typed("release_key", "2026-05-13") == "2026-05-13"
    assert wbk.typed("cms_aggregate_src", "278") == "278"
    assert wbk.typed("cms_aggregate", "278.0") == 278
    assert wbk.typed("difference", "-2.0") == -2
    assert wbk.typed("comparable", "False") is False
    assert wbk.typed("sep_r1_share", "0.25") == 0.25
    assert wbk.typed("difference", "") is None


def test_gate_flow_labels_are_readable():
    assert wbk.gate_flow_label("pass_through_g3_window") == "Remaining after G3 (observation window)"
    assert wbk.gate_flow_label("independent_pass_g5_interval") == "Passing G5 (usable interval) on its own"
    for col in wbk.BLOCK_COLUMNS["gate_flow_state"]:
        assert wbk.gate_flow_label(col) != col


def _prose() -> list[str]:
    texts = [wbk.TITLE, *wbk.SHEET_GUIDE.values(), *wbk.GATE_RULES.values(), *wbk.STUDY_EFFECT.values(),
             *wbk.BLOCK_TITLES.values()]
    for d in list(wbk.DEFINITIONS.values()) + list(wbk.SHEET_DEFINITIONS.values()):
        texts += list(d)
    return texts


def test_prose_has_no_dashes_or_placeholders():
    banned = re.compile("[\u2013\u2014]|\\bTODO\\b|\\bTBD\\b|pending", re.I)
    for t in _prose():
        assert not banned.search(t), t


@pytest.mark.skipif(not HAVE_OUTPUTS, reason="output tables not present")
def test_csv_headers_match_declared_columns():
    for key, path in wbk.CSV_SOURCES.items():
        with open(path, newline="", encoding="utf-8") as fh:
            header = next(csv.reader(fh))
        assert header == wbk.BLOCK_COLUMNS[key], key


@pytest.mark.skipif(not HAVE_WORKBOOK, reason="workbook not built")
def test_built_workbook_matches_outputs():
    import openpyxl

    wb = openpyxl.load_workbook(WORKBOOK, read_only=True)
    try:
        assert wb.sheetnames == wbk.SHEET_NAMES
        assert wb.properties.creator == wbk.CREATOR
        for sheet, key, header_row in (("Pair summary", "pair_summary", 1), ("Gate flow", "gate_flow", 2),
                                       ("Reconciliation", "reconciliation", 1)):
            with open(wbk.CSV_SOURCES[key], newline="", encoding="utf-8") as fh:
                n_csv = sum(1 for _ in csv.reader(fh)) - 1
            ws = wb[sheet]
            assert ws.max_row - header_row == n_csv, sheet
            header = [c.value for c in next(ws.iter_rows(min_row=header_row, max_row=header_row))]
            assert header == wbk.BLOCK_COLUMNS[key]
        import tomllib

        with open(ROOT / "config" / "releases.toml", "rb") as fh:
            notes = {r["key"]: r["status_note"] for r in tomllib.load(fh)["release"]}
        cols = wbk.BLOCK_COLUMNS["releases"]
        rows = list(wb["Releases"].iter_rows(min_row=3, max_row=2 + len(notes), values_only=True))
        assert {r[0]: r[cols.index("status_note")] for r in rows} == notes
        ws = wb["Records primary"]
        assert [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))] == wbk.RECORD_COLUMNS
        first = next(ws.iter_rows(min_row=2, max_row=2, values_only=True))
        assert isinstance(first[0], str) and isinstance(first[3], str) and len(first[3]) == 6
    finally:
        wb.close()
