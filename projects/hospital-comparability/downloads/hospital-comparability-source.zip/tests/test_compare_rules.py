from hospcomp.compare import Est, interval_better, rank_range, separated_r1, separated_r2, separated_r3


def E(fid, s, lo, hi):
    return Est(fid, s, lo, hi)


def test_touching_endpoints_are_not_separated():
    a, b = E("A", 200, 180, 220), E("B", 250, 220, 280)
    assert not separated_r1(a, b)
    assert not separated_r2(a, b)


def test_gap_of_one_unit_separates_r1_but_not_r2():
    a, b = E("A", 200, 180, 220), E("B", 260, 221, 290)
    assert separated_r1(a, b)
    assert not separated_r2(a, b)
    c = E("C", 260, 222, 290)
    assert separated_r2(a, c)


def test_r3_is_lenient_and_contains_r1():
    a, b = E("A", 200, 150, 240), E("B", 250, 210, 300)
    assert not separated_r1(a, b)
    assert separated_r3(a, b)
    x, y = E("X", 200, 180, 220), E("Y", 300, 280, 320)
    assert separated_r1(x, y) and separated_r3(x, y)


def test_equal_scores_are_ties_even_with_different_intervals():
    a, b = E("A", 200, 180, 220), E("B", 200, 190, 210)
    assert a.score == b.score
    assert not separated_r1(a, b)


def test_direction_higher_is_better_mirrors_lower_is_better():
    a, b = E("A", 800, 780, 820), E("B", 900, 880, 920)
    assert separated_r1(a, b, "higher") == separated_r1(a, b, "lower")
    assert interval_better(a, b, "lower") and not interval_better(a, b, "higher")
    assert interval_better(b, a, "higher")


def test_rank_range_arithmetic_lower_is_better():
    u = [E("A", 100, 90, 110), E("B", 150, 120, 180), E("C", 200, 185, 215), E("D", 205, 100, 300)]
    # A: nobody surely better; B (120>110) and C (185>110) surely worse -> worst = 4-2 = 2; D overlaps A
    assert rank_range(u[0], u) == (1, 1, 2)
    # C: A (110<185) and B (180<185) surely better -> best 3; nobody surely worse -> worst 4
    assert rank_range(u[2], u) == (3, 3, 4)
    # D overlaps everyone -> full range
    assert rank_range(u[3], u) == (4, 1, 4)


def test_rank_range_higher_is_better():
    u = [E("A", 100, 90, 110), E("B", 200, 190, 210)]
    assert rank_range(u[1], u, "higher") == (1, 1, 1)
    assert rank_range(u[0], u, "higher") == (2, 2, 2)


def test_point_rank_ties_share_best_rank():
    u = [E("A", 100, 90, 110), E("B", 100, 95, 105), E("C", 120, 80, 160)]
    assert rank_range(u[0], u)[0] == 1 and rank_range(u[1], u)[0] == 1 and rank_range(u[2], u)[0] == 3
