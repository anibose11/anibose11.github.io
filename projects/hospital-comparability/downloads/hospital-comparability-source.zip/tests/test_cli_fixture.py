"""Command-line validator tests on the SYNTHETIC fixture database."""

import json
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run_cli(fixture_root, *args):
    env = dict(os.environ, HOSPCOMP_ROOT=str(fixture_root), PYTHONPATH=str(ROOT / "src"))
    return subprocess.run([sys.executable, "-m", "hospcomp.cli", *args], env=env, capture_output=True, text=True)


def test_compare_lists_compatible_and_excluded(fixture_root, fixture_db):
    res = run_cli(fixture_root, "compare", "--measure", "READM_30_HF", "--state", "ZZ", "--format", "json")
    assert res.returncode == 0, res.stderr
    out = json.loads(res.stdout)
    ids = {c["facility_id"] for c in out["compared"]}
    assert ids == {"ZZ0001", "ZZ0002", "ZZ0003", "ZZ0004", "ZZ0005", "ZZ0010"}
    reasons = {e["facility_id"]: e["reason"] for e in out["not_compared"]}
    assert reasons["ZZ0006"] == "too_few_cases" and reasons["ZZ0009"] == "partial_or_short_period_footnote"
    assert out["requested_records"] == 20
    assert reasons["ZZ0019"] == "population_or_data_source_differs"


def test_strict_subset_drops_caution_record(fixture_root, fixture_db):
    res = run_cli(fixture_root, "compare", "--measure", "READM_30_HF", "--state", "ZZ", "--subset", "strict", "--format", "json")
    out = json.loads(res.stdout)
    assert "ZZ0010" not in {c["facility_id"] for c in out["compared"]}


def test_check_request_rejects_lookalike(fixture_root, fixture_db):
    res = run_cli(fixture_root, "check-request", "--measure-a", "READM_30_HF", "--measure-b", "READM-30-HF-HRRP")
    assert res.returncode == 2
    assert "FAIL  same quantity" in res.stdout and "FAIL  same unit" in res.stdout


def test_check_request_rejects_different_endpoints(fixture_root, fixture_db):
    res = run_cli(fixture_root, "check-request", "--measure-a", "READM_30_HF", "--measure-b", "MORT_30_HF")
    assert res.returncode == 2 and "FAIL  same measure ID" in res.stdout


def test_check_pair_reports_separation(fixture_root, fixture_db):
    res = run_cli(fixture_root, "check-pair", "--measure", "READM_30_HF", "--facility-a", "ZZ0001", "--facility-b", "ZZ0005")
    assert res.returncode == 0 and "R1 separated: True" in res.stdout


def test_suppressed_release_fails_g0_for_every_record(fixture_root, fixture_db, tmp_path):
    db = tmp_path / "copy.sqlite"
    shutil.copy2(fixture_root / "data" / "interim" / "hospcomp.sqlite", db)
    con = sqlite3.connect(db)
    con.execute("UPDATE releases SET interval_status='suppressed_by_cms_notice'")
    con.executescript((ROOT / "sql" / "02_gates.sql").read_text())
    rows = con.execute("SELECT DISTINCT first_failed_gate, reason_code FROM gate_results").fetchall()
    assert rows == [("G0", "release_intervals_suppressed_by_cms")]
    assert con.execute("SELECT SUM(compatible) FROM gate_results").fetchone()[0] == 0
