from hospcomp.parse import (
    availability_state, months_inclusive, normalize_facility_id, parse_date, parse_footnotes, parse_numeric,
)


def test_numeric_and_text_states():
    assert parse_numeric("20.4") == (20.4, "numeric", 1)
    assert parse_numeric("20") == (20.0, "numeric", 0)
    assert parse_numeric("-12.3") == (-12.3, "numeric", 1)
    assert parse_numeric("Not Available")[:2] == (None, "not_available")
    assert parse_numeric("Not Applicable")[:2] == (None, "not_applicable")
    assert parse_numeric("Too Few to Report")[:2] == (None, "too_few_to_report")
    assert parse_numeric("N/A")[:2] == (None, "not_available_na")
    assert parse_numeric("")[:2] == (None, "blank")
    assert parse_numeric("12,3")[:2] == (None, "other_text")
    assert parse_numeric("nan")[:2] == (None, "other_text")


def test_zero_is_a_value_not_missing():
    assert parse_numeric("0") == (0.0, "numeric", 0)
    assert parse_numeric("0.0") == (0.0, "numeric", 1)


def test_facility_id_normalization():
    assert normalize_facility_id("10001") == ("010001", True)
    assert normalize_facility_id(" 010001 ") == ("010001", True)
    assert normalize_facility_id("05012f") == ("05012F", True)
    assert normalize_facility_id("12345678") == ("12345678", False)
    assert normalize_facility_id("") == ("", False)


def test_footnotes():
    assert parse_footnotes("1, 28") == ["1", "28"]
    assert parse_footnotes("28,1") == ["1", "28"]
    assert parse_footnotes("") == []
    assert parse_footnotes("a") == ["a"]


def test_dates_and_months():
    assert parse_date("07/01/2023") == "2023-07-01"
    assert parse_date("13/01/2023") is None
    assert parse_date("2023-07-01") is None
    assert months_inclusive("2023-07-01", "2025-06-30") == 24
    assert months_inclusive("2022-07-01", "2025-06-30") == 36


def test_availability_precedence():
    prec = ["19", "12", "7", "1", "4", "13", "5"]
    states = {"19": "not_eligible_program", "12": "not_applicable_to_hospital", "7": "no_eligible_cases",
              "1": "too_few_cases", "4": "suppressed_by_cms", "13": "cannot_be_calculated", "5": "not_available_this_period"}
    assert availability_state("numeric", ["1"], prec, states) == "reported"
    assert availability_state("not_available", ["1", "28"], prec, states) == "too_few_cases"
    assert availability_state("not_available", ["5", "19"], prec, states) == "not_eligible_program"
    assert availability_state("not_available", [], prec, states) == "missing_unspecified"
    assert availability_state("not_available", ["4"], prec, states) == "suppressed_by_cms"
