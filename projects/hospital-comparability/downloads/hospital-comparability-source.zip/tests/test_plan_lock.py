"""The plan lock history can be checked against the plan files."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_current_plan_matches_lock():
    lock = json.loads((DOCS / "analysis_plan.lock.json").read_text())
    assert _sha(DOCS / "analysis_plan.md") == lock["sha256"]


def test_first_lock_text_matches_first_lock_and_current_plan():
    lock = json.loads((DOCS / "analysis_plan.lock.json").read_text())
    first = DOCS / "analysis_plan_first_lock.md"
    assert _sha(first) == lock["previous_locks"][0]["sha256"]
    head = first.read_text(encoding="utf-8").split("## Amendments")[0]
    assert (DOCS / "analysis_plan.md").read_text(encoding="utf-8").startswith(head + "## Amendments")
