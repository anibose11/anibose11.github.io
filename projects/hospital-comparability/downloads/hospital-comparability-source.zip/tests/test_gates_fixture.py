"""Gate, pair and rank-range SQL run on the SYNTHETIC fixture. A deliberate
fixture shows the software handles a case; it says nothing about real hospitals."""

from hospcomp.compare import Est, rank_range, separated_r1, separated_r2, separated_r3, to_units


def reasons(con, measure):
    return {r["facility_id"]: r["reason_code"] for r in con.execute(
        "SELECT facility_id, reason_code FROM gate_results WHERE measure_id=?", (measure,))}


def test_each_engineered_row_gets_the_expected_reason(fixture_db):
    r = reasons(fixture_db, "READM_30_HF")
    assert r["ZZ0001"] == "compatible"
    assert r["ZZ0006"] == "too_few_cases"
    assert r["ZZ0007"] == "interval_limit_missing"
    assert r["ZZ0008"] == "interval_reversed"
    assert r["ZZ0009"] == "partial_or_short_period_footnote"
    assert r["ZZ0010"] == "compatible"
    assert r["ZZ0011"] == "suppressed_by_cms"
    assert r["ZZ0012"] == "not_eligible_program"
    assert r["ZZ0013"] == "observation_window_mismatch"
    assert r["ZZ0014"] == "interval_zero_width"
    assert r["ZZ0015"] == "score_outside_interval"
    assert r["ZZ0016"] == "not_available_this_period"
    assert r["ZZ0017"] == "no_eligible_cases"
    assert r["ZZ0018"] == "missing_unspecified"


def test_caution_footnote_flagged_but_compatible(fixture_db):
    row = fixture_db.execute("SELECT compatible, caution_flag FROM gate_results WHERE measure_id='READM_30_HF' "
                             "AND facility_id='ZZ0010'").fetchone()
    assert tuple(row) == (1, 1)


def test_tie_and_touching_pairs(fixture_db):
    def pair(a, b):
        return fixture_db.execute("SELECT * FROM pairs WHERE measure_id='READM_30_HF' AND facility_a=? AND facility_b=?",
                                  (a, b)).fetchone()
    assert pair("ZZ0001", "ZZ0002")["point_ordered"] == 0          # "20.0" vs "20"
    assert pair("ZZ0001", "ZZ0003")["sep_r1"] == 0                 # touching at 22.0
    p = pair("ZZ0001", "ZZ0004")
    assert (p["sep_r1"], p["sep_r2"]) == (1, 0)                    # gap of 0.1
    p = pair("ZZ0001", "ZZ0005")
    assert (p["sep_r1"], p["sep_r2"], p["sep_r3"], p["official_opposite"]) == (1, 1, 1, 0)


def test_single_hospital_state_has_no_pairs(fixture_db):
    n = fixture_db.execute("SELECT COUNT(*) FROM pairs WHERE state='ZY'").fetchone()[0]
    assert n == 0


def test_negative_edac_values_parse_and_compare(fixture_db):
    row = fixture_db.execute("SELECT * FROM pairs WHERE measure_id='EDAC_30_HF' AND facility_a='ZZ0001' "
                             "AND facility_b='ZZ0002'").fetchone()
    # ZZ0001 [-20.0, -1.0] vs ZZ0002 [0.0, 10.0]: separated by a gap of 1.0
    assert row["sep_r1"] == 1 and row["sep_r2"] == 1


def test_sql_matches_python_reference(fixture_db):
    for measure in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
        comp = fixture_db.execute("SELECT * FROM gate_results WHERE compatible=1 AND measure_id=?", (measure,)).fetchall()
        by_state = {}
        for r in comp:
            d = r["reported_decimals"]
            by_state.setdefault(r["state"], []).append(
                Est(r["facility_id"], to_units(r["score_num"], d), to_units(r["lower_num"], d), to_units(r["upper_num"], d)))
        for state, ests in by_state.items():
            for e in ests:
                row = fixture_db.execute("SELECT point_rank, best_rank, worst_rank FROM rank_ranges WHERE subset='primary' "
                                         "AND measure_id=? AND facility_id=?", (measure, e.facility_id)).fetchone()
                assert tuple(row) == rank_range(e, ests)
            for i, a in enumerate(ests):
                for b in ests[i + 1:]:
                    lo, hi = sorted([a, b], key=lambda x: x.facility_id)
                    row = fixture_db.execute("SELECT sep_r1, sep_r2, sep_r3 FROM pairs WHERE measure_id=? AND facility_a=? "
                                             "AND facility_b=?", (measure, lo.facility_id, hi.facility_id)).fetchone()
                    assert tuple(row) == (int(separated_r1(lo, hi)), int(separated_r2(lo, hi)), int(separated_r3(lo, hi)))


def test_higher_is_better_direction_in_sql(fixture_db):
    import sqlite3
    from pathlib import Path

    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row
    con.execute("CREATE TABLE measure_windows (release_key TEXT, measure_id TEXT, reported_decimals INTEGER)")
    con.execute("INSERT INTO measure_windows VALUES ('X', 'HIGH', 1)")
    con.execute("""CREATE TABLE gate_results (record_id TEXT, release_key TEXT, measure_id TEXT, state TEXT, facility_id TEXT,
        facility_name TEXT, hospital_type TEXT, compared_to_national_src TEXT, caution_flag INTEGER,
        favorable TEXT, reported_decimals INTEGER, score_num REAL, lower_num REAL, upper_num REAL,
        denominator_num REAL, compatible INTEGER)""")
    rows = [("r1", "A", 80.0, 78.0, 82.0), ("r2", "B", 90.0, 88.0, 92.0), ("r3", "C", 85.0, 79.0, 91.0)]
    for rid, f, s, lo, hi in rows:
        con.execute("INSERT INTO gate_results VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (rid, "X", "HIGH", "XX", f, f, "t", "", 0, "higher", 1, s, lo, hi, 100, 1))
    sql = (Path(__file__).resolve().parents[1] / "sql" / "03_pairs_ranks.sql").read_text()
    con.executescript(sql)
    rr = {r["facility_id"]: (r["point_rank"], r["best_rank"], r["worst_rank"])
          for r in con.execute("SELECT * FROM rank_ranges WHERE subset='primary'")}
    assert rr["B"] == (1, 1, 2)   # highest score is best; A is surely worse than B
    assert rr["A"] == (3, 2, 3)
    assert rr["C"] == (2, 1, 3)


def test_population_gate_sends_va_records_to_their_own_comparison(fixture_db):
    r = reasons(fixture_db, "READM_30_HF")
    assert r["ZZ0019"] == "population_or_data_source_differs"
    assert r["ZZ0020"] == "population_or_data_source_differs"
    general = fixture_db.execute("SELECT COUNT(*) FROM pairs WHERE measure_id='READM_30_HF' AND "
                                 "(facility_a IN ('ZZ0019','ZZ0020') OR facility_b IN ('ZZ0019','ZZ0020'))").fetchone()[0]
    assert general == 0
    va = fixture_db.execute("SELECT point_ordered, sep_r1 FROM separate_group_pairs WHERE measure_id='READM_30_HF' "
                            "AND facility_a='ZZ0019' AND facility_b='ZZ0020'").fetchone()
    assert tuple(va) == (1, 1)
