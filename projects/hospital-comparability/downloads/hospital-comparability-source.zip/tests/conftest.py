"""Shared test fixtures. Everything here uses the SYNTHETIC fixture in
tests/fixtures/demo; no real CMS record is read by the tests."""

from __future__ import annotations

import json
import os
import shutil
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "tests" / "fixtures" / "demo"
FIXTURE_RELEASES = """# SYNTHETIC FIXTURE release configuration (tests and demo only)
[[release]]
key = "fixture"
source = "live"
role = "primary"
label = "SYNTHETIC FIXTURE"
interval_status = "published"
status_note = "synthetic"
notice = ""
notice_url = ""
"""


def _sha(path: Path) -> str:
    import hashlib

    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture(scope="session")
def fixture_root(tmp_path_factory) -> Path:
    tmp = tmp_path_factory.mktemp("fixture_root")
    for d in ("config", "sql"):
        shutil.copytree(ROOT / d, tmp / d)
    shutil.copytree(FIXTURE, tmp / "data" / "raw")
    ids = {"unplanned_visits": "632h-zaca", "complications_deaths": "ynj2-r877", "general_info": "xubh-q36u",
           "footnotes": "y9us-9xdf", "measure_dates": "4j6d-yzce", "hrrp": "9n3s-kdb3",
           "unplanned_national": "cvcs-xecj", "complications_national": "qqw3-t4ie",
           "unplanned_state": "4gkm-5ypv", "complications_state": "bs2r-24vh"}
    datasets = {}
    for key, did in ids.items():
        path = next((tmp / "data" / "raw" / key).glob("*.csv"))
        n = sum(1 for _ in path.open(encoding="utf-8")) - 1
        datasets[key] = {"id": did, "title": f"SYNTHETIC {key}", "released": "2000-01-01", "modified": "2000-01-01",
                         "distribution_file_version": "fixture", "download_url": "fixture://" + path.name,
                         "local_path": f"data/raw/{key}/{path.name}", "sha256": _sha(path), "data_rows": n}
    (tmp / "source_manifest.json").write_text(json.dumps({"datasets": datasets, "documents": {}}))
    (tmp / "config" / "releases.toml").write_text(FIXTURE_RELEASES)
    env = dict(os.environ, HOSPCOMP_ROOT=str(tmp), PYTHONPATH=str(ROOT / "src"))
    res = subprocess.run([sys.executable, "-m", "hospcomp.build"], env=env, capture_output=True, text=True)
    assert res.returncode == 0, res.stderr
    return tmp


@pytest.fixture(scope="session")
def fixture_db(fixture_root) -> sqlite3.Connection:
    con = sqlite3.connect(fixture_root / "data" / "interim" / "hospcomp.sqlite")
    con.row_factory = sqlite3.Row
    con.executescript((ROOT / "sql" / "02_gates.sql").read_text())
    con.executescript((ROOT / "sql" / "03_pairs_ranks.sql").read_text())
    con.executescript((ROOT / "sql" / "04_population_groups.sql").read_text())
    return con
