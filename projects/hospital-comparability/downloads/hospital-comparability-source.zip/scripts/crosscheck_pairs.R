# Second implementation of the pair counts (software cross-check, base R only).
#
# Reads outputs/tables/compatible_records.csv, recomputes for every release and
# measure the number of within-state pairs, point-ordered pairs and pairs
# separated under strict non-overlap (R1), and writes
# outputs/tables/r_crosscheck_pairs.csv. Integers in units of the last reported
# decimal are used, as in the SQL. This checks the arithmetic of the main
# pipeline with independent code; it is not external scientific validation.
#
# Usage: Rscript scripts/crosscheck_pairs.R [project_root]

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1) args[[1]] else "."
infile <- file.path(root, "outputs", "tables", "compatible_records.csv")
outfile <- file.path(root, "outputs", "tables", "r_crosscheck_pairs.csv")

d <- read.csv(infile, colClasses = c(facility_id = "character", state = "character"),
              stringsAsFactors = FALSE)

scale_of <- function(dec) 10^dec
d$s <- round(d$score_num * scale_of(d$reported_decimals))
d$lo <- round(d$lower_num * scale_of(d$reported_decimals))
d$hi <- round(d$upper_num * scale_of(d$reported_decimals))
flip <- d$favorable == "higher"
tmp_lo <- ifelse(flip, -d$hi, d$lo)
tmp_hi <- ifelse(flip, -d$lo, d$hi)
d$s <- ifelse(flip, -d$s, d$s)
d$lo <- tmp_lo
d$hi <- tmp_hi

out <- list()
for (key in unique(paste(d$release_key, d$measure_id, sep = "|"))) {
  parts <- strsplit(key, "|", fixed = TRUE)[[1]]
  sub <- d[d$release_key == parts[1] & d$measure_id == parts[2], ]
  pairs <- 0; ordered <- 0; sep <- 0
  for (st in unique(sub$state)) {
    g <- sub[sub$state == st, ]
    n <- nrow(g)
    if (n < 2) next
    # all unordered pairs via outer comparisons
    s_diff <- outer(g$s, g$s, "!=")
    sep_mat <- outer(g$hi, g$lo, "<") | t(outer(g$hi, g$lo, "<"))
    upper <- upper.tri(s_diff)
    pairs <- pairs + sum(upper)
    ordered <- ordered + sum(s_diff[upper])
    sep <- sep + sum((s_diff & sep_mat)[upper])
  }
  out[[key]] <- data.frame(release_key = parts[1], measure_id = parts[2], pairs = pairs,
                           point_ordered_pairs = ordered, sep_r1_count = sep)
}
res <- do.call(rbind, out)
res <- res[order(res$release_key, res$measure_id), ]
write.csv(res, outfile, row.names = FALSE)
cat(sprintf("wrote %s (%d rows) with %s\n", outfile, nrow(res), R.version.string))
