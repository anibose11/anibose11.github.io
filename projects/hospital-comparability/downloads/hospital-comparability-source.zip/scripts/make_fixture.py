"""Write the SYNTHETIC demo/test fixture under tests/fixtures/demo/.

Every row is invented to exercise one edge case. Facility names start with
'SYNTHETIC' and states use the fictional codes ZZ and ZY, so fixture rows can
never be mistaken for, or mixed with, real CMS records.

Run: python scripts/make_fixture.py
"""

from __future__ import annotations

import csv
from pathlib import Path

OUT = Path(__file__).resolve().parents[1] / "tests" / "fixtures" / "demo"

UV_HEADER = ["Facility ID", "Facility Name", "Address", "City/Town", "State", "ZIP Code", "County/Parish",
             "Telephone Number", "Measure ID", "Measure Name", "Compared to National", "Denominator", "Score",
             "Lower Estimate", "Higher Estimate", "Number of Patients", "Number of Patients Returned", "Footnote",
             "Start Date", "End Date"]
CD_HEADER = [h for h in UV_HEADER if h not in ("Number of Patients", "Number of Patients Returned")]

W24 = ("07/01/2023", "06/30/2025")
W36 = ("07/01/2022", "06/30/2025")
NA = "Not Available"
NDN = "No Different Than the National Rate"

# (facility, state, score, lower, upper, footnote, category, window, note)
READM = [
    ("ZZ0001", "ZZ", "20.0", "18.0", "22.0", "", NDN, W24, "valid"),
    ("ZZ0002", "ZZ", "20", "19.0", "21.0", "", NDN, W24, "exact tie with ZZ0001 (20 vs 20.0)"),
    ("ZZ0003", "ZZ", "25.0", "22.0", "28.0", "", NDN, W24, "touches ZZ0001 at 22.0"),
    ("ZZ0004", "ZZ", "26.0", "22.1", "29.0", "", NDN, W24, "gap 0.1 from ZZ0001"),
    ("ZZ0005", "ZZ", "30.0", "28.0", "32.0", "", "Worse Than the National Rate", W24, "clear gap from ZZ0001"),
    ("ZZ0006", "ZZ", NA, NA, NA, "1", "Number of Cases Too Small", W24, "too few cases"),
    ("ZZ0007", "ZZ", "21.0", NA, "23.0", "", NDN, W24, "missing lower limit"),
    ("ZZ0008", "ZZ", "21.0", "23.0", "19.0", "", NDN, W24, "reversed bounds"),
    ("ZZ0009", "ZZ", "21.0", "18.0", "22.0", "29", NDN, W24, "partial performance period"),
    ("ZZ0010", "ZZ", "21.5", "19.0", "24.0", "23", NDN, W24, "caution footnote"),
    ("ZZ0011", "ZZ", NA, NA, NA, "4", NA, W24, "suppressed"),
    ("ZZ0012", "ZZ", NA, NA, NA, "19", NA, W24, "not in reporting program"),
    ("ZZ0013", "ZZ", "22.0", "20.0", "24.0", "", NDN, ("07/01/2022", "06/30/2025"), "window mismatch"),
    ("ZZ0014", "ZZ", "24.0", "24.0", "24.0", "", NDN, W24, "zero-width interval"),
    ("ZZ0015", "ZZ", "23.0", "18.0", "22.0", "", NDN, W24, "score outside interval"),
    ("ZZ0016", "ZZ", NA, NA, NA, "5", NA, W24, "not available this period"),
    ("ZZ0017", "ZZ", NA, NA, NA, "7", NA, W24, "no eligible cases"),
    ("ZZ0018", "ZZ", NA, NA, NA, "", NA, W24, "missing without footnote"),
    ("ZY0001", "ZY", "19.5", "17.0", "22.0", "", NDN, W24, "only hospital in its state"),
    ("ZZ0019", "ZZ", "18.0", "16.0", "20.0", "", NDN, W24, "VA hospital, compared only with VA"),
    ("ZZ0020", "ZZ", "25.0", "23.0", "27.0", "", NDN, W24, "VA hospital, separated from ZZ0019"),
]
VA = {"ZZ0019", "ZZ0020"}
MORT = [
    ("ZZ0001", "ZZ", "11.0", "9.0", "13.0", "", NDN, W36, ""),
    ("ZZ0002", "ZZ", "14.0", "13.5", "14.5", "", "Worse Than the National Rate", W36, ""),
    ("ZZ0003", "ZZ", "8.0", "6.0", "8.9", "", "Better Than the National Rate", W36, ""),
    ("ZZ0004", "ZZ", NA, NA, NA, "1", "Number of Cases Too Small", W36, ""),
]
EDAC = [
    ("ZZ0001", "ZZ", "-10.5", "-20.0", "-1.0", "", NDN, W36, "negative values are favorable"),
    ("ZZ0002", "ZZ", "5.0", "0.0", "10.0", "", NDN, W36, ""),
    ("ZZ0003", "ZZ", "12.0", "-0.9", "25.0", "", NDN, W36, ""),
]
NAMES = {
    "READM_30_HF": "Heart failure (HF) 30-Day Readmission Rate",
    "EDAC_30_HF": "Hospital return days for heart failure patients",
    "MORT_30_HF": "Death rate for heart failure patients",
    "READM_30_AMI": "Acute Myocardial Infarction (AMI) 30-Day Readmission Rate",
    "EDAC_30_AMI": "Hospital return days for heart attack patients",
    "MORT_30_AMI": "Death rate for heart attack patients",
}
FACILITIES = sorted({r[0] for r in READM})


def write(path: Path, header: list[str], rows: list[list[str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def measure_rows(measure: str, spec: list, header: list[str]) -> list[list[str]]:
    rows = []
    present = {s[0] for s in spec}
    full = list(spec) + [(f, f[:2], NA, NA, NA, "5", NA, spec[0][7], "") for f in FACILITIES if f not in present]
    for fid, st, sc, lo, hi, fn, cat, (sd, ed), _ in sorted(full):
        base = {"Facility ID": fid, "Facility Name": f"SYNTHETIC HOSPITAL {fid}", "Address": "1 TEST WAY",
                "City/Town": "NOWHERE", "State": st, "ZIP Code": "00000", "County/Parish": "NONE",
                "Telephone Number": "(000) 000-0000", "Measure ID": measure, "Measure Name": NAMES[measure],
                "Compared to National": cat, "Denominator": "100" if sc != NA else NA, "Score": sc,
                "Lower Estimate": lo, "Higher Estimate": hi, "Number of Patients": "Not Applicable",
                "Number of Patients Returned": "Not Applicable", "Footnote": fn, "Start Date": sd, "End Date": ed}
        rows.append([base[h] for h in header])
    return rows


def main() -> None:
    uv = (measure_rows("READM_30_HF", READM, UV_HEADER) + measure_rows("EDAC_30_HF", EDAC, UV_HEADER)
          + measure_rows("READM_30_AMI", READM[:5], UV_HEADER) + measure_rows("EDAC_30_AMI", EDAC, UV_HEADER))
    cd = measure_rows("MORT_30_HF", MORT, CD_HEADER) + measure_rows("MORT_30_AMI", MORT, CD_HEADER)
    write(OUT / "unplanned_visits" / "Unplanned_Hospital_Visits-Hospital.csv", UV_HEADER, uv)
    write(OUT / "complications_deaths" / "Complications_and_Deaths-Hospital.csv", CD_HEADER, cd)

    gi_header = ["Facility ID", "Facility Name", "Address", "City/Town", "State", "ZIP Code", "County/Parish",
                 "Telephone Number", "Hospital Type", "Hospital Ownership", "Emergency Services"]
    gi = [[f, f"SYNTHETIC HOSPITAL {f}", "1 TEST WAY", "NOWHERE", f[:2], "00000", "NONE", "(000) 000-0000",
           "Acute Care - Veterans Administration" if f in VA else "Acute Care Hospitals", "Synthetic", "Yes"]
          for f in FACILITIES]
    gi.append(["ZZ0099", "SYNTHETIC PSYCHIATRIC ZZ0099", "1 TEST WAY", "NOWHERE", "ZZ", "00000", "NONE",
               "(000) 000-0000", "Psychiatric", "Synthetic", "No"])
    write(OUT / "general_info" / "Hospital_General_Information.csv", gi_header, gi)

    write(OUT / "footnotes" / "Footnote_Crosswalk.csv", ["Footnote", "Footnote Text"], [
        ["1", "The number of cases/patients is too few to report."],
        ["3", "Results are based on a shorter time period than required."],
        ["4", "Data suppressed by CMS for one or more quarters."],
        ["5", "Results are not available for this reporting period."],
        ["7", "No cases met the criteria for this measure."],
        ["11", "There were discrepancies in the data collection process."],
        ["12", "This measure does not apply to this hospital for this reporting period."],
        ["13", "Results cannot be calculated for this reporting period."],
        ["19", "Data are shown only for hospitals that participate in the Inpatient Quality Reporting (IQR) and Outpatient Quality Reporting (OQR) programs."],
        ["23", "The data are based on claims that the hospital or facility submitted to CMS. The hospital or facility has reported discrepancies in their claims data."],
        ["28", "The results are based on the hospital or facility's data submissions. CMS approved the hospital or facility's Extraordinary Circumstances Exception request suggesting that results may be impacted."],
        ["29", "This measure was calculated using partial performance period data due to a CMS-approved exception."],
    ])
    md_header = ["Measure ID", "Measure Name", "Measure Start Quarter", "Start Date", "Measure End Quarter", "End Date"]
    write(OUT / "measure_dates" / "Measure_Dates.csv", md_header, [
        ["READM_30_HF", NAMES["READM_30_HF"], "3Q2023", *W24[:1], "2Q2025", W24[1]],
        ["READM_30_AMI", NAMES["READM_30_AMI"], "3Q2023", *W24[:1], "2Q2025", W24[1]],
        ["MORT_30_HF", NAMES["MORT_30_HF"], "3Q2022", *W36[:1], "2Q2025", W36[1]],
        ["MORT_30_AMI", NAMES["MORT_30_AMI"], "3Q2022", *W36[:1], "2Q2025", W36[1]],
        ["EDAC_30_HF", NAMES["EDAC_30_HF"], "3Q2022", *W36[:1], "2Q2025", W36[1]],
        ["EDAC_30_AMI", NAMES["EDAC_30_AMI"], "3Q2022", *W36[:1], "2Q2025", W36[1]],
        ["READM_30_HF_HRRP", "HRRP HF", "3Q2021", "07/01/2021", "2Q2024", "06/30/2024"],
        ["READM_30_AMI_HRRP", "HRRP AMI", "3Q2021", "07/01/2021", "2Q2024", "06/30/2024"],
    ])
    hrrp_header = ["Facility Name", "Facility ID", "State", "Measure Name", "Number of Discharges", "Footnote",
                   "Excess Readmission Ratio", "Predicted Readmission Rate", "Expected Readmission Rate",
                   "Number of Readmissions", "Start Date", "End Date"]
    write(OUT / "hrrp" / "FY_2026_Hospital_Readmissions_Reduction_Program_Hospital.csv", hrrp_header, [
        ["SYNTHETIC HOSPITAL ZZ0001", "ZZ0001", "ZZ", "READM-30-HF-HRRP", "300", "", "1.0123", "20.1234", "19.8790", "60", "07/01/2021", "06/30/2024"],
        ["SYNTHETIC HOSPITAL ZZ0001", "ZZ0001", "ZZ", "READM-30-AMI-HRRP", "120", "", "0.9876", "14.1000", "14.2770", "17", "07/01/2021", "06/30/2024"],
    ])
    nat_header = ["Measure ID", "Measure Name", "National Rate", "Number of Hospitals Worse", "Number of Hospitals Same",
                  "Number of Hospitals Better", "Number of Hospitals Too Few", "Footnote", "Start Date", "End Date"]
    st_header = ["State"] + [h for h in nat_header if h != "National Rate"]
    write(OUT / "unplanned_national" / "Unplanned_Hospital_Visits-National.csv", nat_header,
          [["READM_30_HF", NAMES["READM_30_HF"], "20.0", "1", "13", "0", "1", "", *W24]])
    write(OUT / "complications_national" / "Complications_and_Deaths-National.csv", nat_header,
          [["MORT_30_HF", NAMES["MORT_30_HF"], "11.0", "1", "1", "1", "1", "", *W36]])
    write(OUT / "unplanned_state" / "Unplanned_Hospital_Visits-State.csv", st_header,
          [["ZZ", "READM_30_HF", NAMES["READM_30_HF"], "1", "12", "0", "1", "", *W24]])
    write(OUT / "complications_state" / "Complications_and_Deaths-State.csv", st_header,
          [["ZZ", "MORT_30_HF", NAMES["MORT_30_HF"], "1", "1", "1", "1", "", *W36]])
    print(f"wrote synthetic fixture to {OUT}")


if __name__ == "__main__":
    main()
