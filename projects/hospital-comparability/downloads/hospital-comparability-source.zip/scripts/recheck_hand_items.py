"""Re-derive every item of the hand-check list from the raw sources.

The checks here do not import the hospcomp package. Raw records are read from
the archive ZIP with the csv module, the lead-example rank range and the
passing-pair gap are recomputed from the raw file, document statements are
searched in the saved PDFs and Federal Register HTML, references are compared
with Crossref and PubMed (with --network), and every number in the abstract,
Tables 1 to 3 and the figure legends is matched against evidence/claims.json.

Usage:
    python scripts/recheck_hand_items.py [--network]

Writes outputs/verification/hand_recheck.json and fills the script_recheck
columns of outputs/verification/hand_check.csv. The author's columns are never
changed.
"""

from __future__ import annotations

import argparse
import csv
import html
import io
import json
import re
import sys
import time
import urllib.parse
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HAND = ROOT / "outputs" / "verification" / "hand_check.csv"
OUT = ROOT / "outputs" / "verification" / "hand_recheck.json"
DOCS = ROOT / "data" / "raw" / "documents"
ARCHIVE = ROOT / "data" / "raw" / "archives" / "pdc_2026_05_13" / "hospitals_2026-05-13.zip"
WORKBOOK = ROOT / "outputs" / "hospital-comparability-review.xlsx"
FILES = {"unplanned_visits": "Unplanned_Hospital_Visits-Hospital.csv",
         "complications_deaths": "Complications_and_Deaths-Hospital.csv"}
CAUTION_FOOTNOTES = {"11", "23", "28"}
NA = "Not Available"


# ----------------------------------------------------------------------------- raw files

def read_member(name: str) -> list[dict]:
    with zipfile.ZipFile(ARCHIVE) as z:
        members = [m for m in z.namelist() if m.rsplit("/", 1)[-1].endswith(name) and "__MACOSX" not in m
                   and not m.rsplit("/", 1)[-1].startswith("REH_")]
        if len(members) != 1:
            raise SystemExit(f"expected one member ending in {name}, found {members}")
        text = z.read(members[0]).decode("utf-8-sig")
    return list(csv.DictReader(io.StringIO(text)))


def parse_expected(s: str) -> dict:
    out = {}
    for part in s.split("; "):
        k, _, v = part.partition("=")
        out[k] = v.strip("'")
    return out


def num(s: str) -> float | None:
    try:
        return float(s)
    except (TypeError, ValueError):
        return None


def workbook_rows() -> dict:
    if not WORKBOOK.exists():
        return {}
    import openpyxl
    wb = openpyxl.load_workbook(WORKBOOK, read_only=True)
    ws = wb["Records primary"]
    it = ws.iter_rows(values_only=True)
    head = next(it)
    rid = head.index("record_id")
    return {r[rid]: dict(zip(head, r)) for r in it}


def check_raw_record(row: dict, raw: dict, wb: dict) -> tuple[bool, str]:
    release, dataset, fac, measure = row["target"].split("|")
    rows = raw[dataset]
    k = int(re.search(r"data row (\d+)", row["what_to_compare"]).group(1))
    r = rows[k - 1]
    if (r["Facility ID"], r["Measure ID"]) != (fac, measure):
        return False, f"data row {k} holds {r['Facility ID']} {r['Measure ID']}"
    exp = parse_expected(row["expected"])
    got = {"score": r["Score"], "lower": r["Lower Estimate"], "upper": r["Higher Estimate"],
           "footnote": r["Footnote"], "start": r["Start Date"], "end": r["End Date"]}
    bad = [f for f in got if got[f] != exp[f]]
    if bad:
        return False, f"raw file differs from the list on {bad}"
    w = wb.get(row["target"])
    if wb and w is None:
        return False, "record not found in the review workbook"
    if w is not None:
        wmap = {"score": "score_src", "lower": "lower_src", "upper": "upper_src", "footnote": "footnote_src",
                "start": "start_date_src", "end": "end_date_src"}
        wbad = [f for f, c in wmap.items() if (w[c] or "") != got[f]]
        if wbad:
            return False, f"review workbook differs from the raw file on {wbad}"
    return True, f"raw data row {k} and the review workbook agree on all 6 fields"


# ----------------------------------------------------------------------------- examples

def window(measure_dates: list[dict], measure: str) -> tuple[str, str]:
    r = next(r for r in measure_dates if r["Measure ID"] == measure)
    return r["Start Date"], r["End Date"]


def compatible(raw_rows, gi_type, state, measure, win) -> list[dict]:
    """Independent restatement of the gates for one state and measure in the primary release."""
    out = []
    seen = set()
    for r in raw_rows:
        if r["State"] != state or r["Measure ID"] != measure:
            continue
        key = r["Facility ID"]
        if key in seen:
            continue
        seen.add(key)
        if gi_type.get(key) == "Acute Care - Veterans Administration":
            continue
        if (r["Start Date"], r["End Date"]) != win:
            continue
        fns = {f.strip() for f in r["Footnote"].split(",") if f.strip()}
        if fns - CAUTION_FOOTNOTES:
            continue
        s, lo, hi = num(r["Score"]), num(r["Lower Estimate"]), num(r["Higher Estimate"])
        if s is None or lo is None or hi is None or not (lo <= s <= hi and lo < hi):
            continue
        out.append({"facility_id": key, "score": s, "lower": lo, "upper": hi})
    return out


def check_example(row, raw, gi_type, md) -> tuple[bool, str]:
    measure, state, fac = row["target"].split()
    dataset = "unplanned_visits" if measure.startswith(("READM", "EDAC")) else "complications_deaths"
    r = next((r for r in raw[dataset] if r["Facility ID"] == fac and r["Measure ID"] == measure), None)
    if r is None:
        return False, "not found in the raw file"
    got = f"{num(r['Score'])} [{num(r['Lower Estimate'])}, {num(r['Higher Estimate'])}]"
    ok = got == row["expected"] and r["State"] == state
    return ok, f"raw file: {r['Score']} [{r['Lower Estimate']}, {r['Higher Estimate']}], state {r['State']}"


def check_rank_range(row, raw, gi_type, md, examples) -> tuple[bool, str]:
    ex = examples
    fac = row["target"].split()[-1]
    comp = compatible(raw["unplanned_visits"], gi_type, ex["state"], ex["measure_id"], window(md, ex["measure_id"]))
    me = next(c for c in comp if c["facility_id"] == fac)
    n = len(comp)
    scale = 10  # one published decimal place
    lo, hi = round(me["lower"] * scale), round(me["upper"] * scale)
    best = 1 + sum(1 for c in comp if round(c["upper"] * scale) < lo)
    worst = n - sum(1 for c in comp if round(c["lower"] * scale) > hi)
    got = f"ranks {best} to {worst} of {n}"
    return got == row["expected"], f"recomputed from {n} compatible raw records: {got}"


def check_gap(row, raw, gi_type, md) -> tuple[bool, str]:
    a, b = re.findall(r"\b(\d{6})\b", row["target"])
    measure = json.loads((ROOT / "outputs" / "tables" / "examples.json").read_text())["passing_pair"]["measure_id"]
    rows = {r["Facility ID"]: r for r in raw["complications_deaths"] if r["Measure ID"] == measure and r["Facility ID"] in (a, b)}
    la, ua = round(float(rows[a]["Lower Estimate"]) * 10), round(float(rows[a]["Higher Estimate"]) * 10)
    lb, ub = round(float(rows[b]["Lower Estimate"]) * 10), round(float(rows[b]["Higher Estimate"]) * 10)
    gap = max(la - ub, lb - ua)
    got = f"gap {gap / 10} percentage points (separated under R1)" if gap > 0 else f"gap {gap / 10} (not separated)"
    return got == row["expected"], f"recomputed from the raw limits: {got}"


# ----------------------------------------------------------------------------- documents

_PDF_CACHE: dict = {}


def pdf_page(name: str, page: int) -> str:
    from pypdf import PdfReader
    if name not in _PDF_CACHE:
        _PDF_CACHE[name] = PdfReader(str(DOCS / name))
    text = _PDF_CACHE[name].pages[page - 1].extract_text() or ""
    return re.sub(r"\s+", " ", text)


def fr_pages() -> dict:
    t = (DOCS / "FR-2025-08-04-2025-14681.htm").read_text(encoding="utf-8", errors="replace")
    t = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", t)))
    marks = [(int(m.group(1)), m.start()) for m in re.finditer(r"\[\[Page (\d+)\]\]", t)]
    return {p: t[s:(marks[i + 1][1] if i + 1 < len(marks) else len(t))] for i, (p, s) in enumerate(marks)}


def all_in(text: str, phrases: list[str]) -> list[str]:
    return [p for p in phrases if p.lower() not in text.lower()]


def check_documents(check_id: str, row: dict) -> tuple[bool, str]:
    target = row["target"]
    if target.startswith("CMS listserve"):
        text = " ".join(pdf_page("2026-89-ip-508.pdf", p) for p in (1, 2))
        measures = re.findall(r"• ((?:MORT|READM|EDAC|COMP|Hybrid)[-\w ]*?)(?= •| The|$)", text)
        missing = all_in(text, ["July 2027", "Individual hospital measure rates were not impacted",
                                "confidence intervals will be suppressed"])
        ok = len(measures) == 18 and not missing
        return ok, f"{len(measures)} measures listed; missing phrases: {missing or 'none'}"
    if target.startswith("FY 2026 IPPS"):
        pages = fr_pages()
        need = {36537: ["MA beneficiaries", "3-years to 2-years", "remove the COVID-19 exclusion from all six readmission measures"],
                36931: ["MA beneficiaries", "2-year", "COVID-19"], 36932: ["MA beneficiaries", "2-year"],
                36949: ["COVID-19"]}
        miss = {p: all_in(pages[p], ph) for p, ph in need.items()}
        miss = {p: m for p, m in miss.items() if m}
        return not miss, f"phrases found on 90 FR {', '.join(map(str, need))}" if not miss else f"missing {miss}"
    if target.startswith("QualityNet reports"):
        res = {"2025 readmission p. 10": all_in(pdf_page("2025_CSR_AUS_Report_v2.0.pdf", 10), ["not applicable to VA hospitalizations"]),
               "2025 readmission p. 15": all_in(pdf_page("2025_CSR_AUS_Report_v2.0.pdf", 15), ["VA administrative data in the case of VA beneficiaries"]),
               "2025 mortality p. 11": all_in(pdf_page("2025_CSM_AUS_Report_v1.0.pdf", 11), ["not applicable to VA hospitalizations"]),
               "2025 mortality p. 16": all_in(pdf_page("2025_CSM_AUS_Report_v1.0.pdf", 16), ["VA administrative data"]),
               "2025 EDAC p. 10": all_in(pdf_page("2025_EDAC_AUS_Report.pdf", 10), ["not applicable to VA hospitalizations"]),
               "2025 EDAC p. 75": all_in(pdf_page("2025_EDAC_AUS_Report.pdf", 75), ["not applicable to VA"]),
               "2025 EDAC p. 77": all_in(pdf_page("2025_EDAC_AUS_Report.pdf", 77), ["not applicable to VA"])}
        bad = {k: v for k, v in res.items() if v}
        return not bad, "statements found on " + ", ".join(res) if not bad else f"missing {bad}"
    if target.startswith("2025 EDAC report"):
        text = pdf_page("2025_EDAC_AUS_Report.pdf", 37)
        miss = all_in(text, ["278", "736", "551", "2,149"])
        return not miss, "counts 278, 736, 551 and 2,149 found on PDF p. 37" if not miss else f"missing {miss}"
    return False, "no rule for this document"


def definition_change_sources() -> dict:
    """Sources for the cross-release definition changes (not part of the author's checklist)."""
    out = {}
    try:
        faq4, faq8 = pdf_page("2026_CBM_FAQ.pdf", 4), pdf_page("2026_CBM_FAQ.pdf", 8) + " " + pdf_page("2026_CBM_FAQ.pdf", 9)
        out["2026 CBM FAQ p. 4 (FAQ 1, Table 2)"] = all_in(faq4, [
            "all Excess D", "Removed the previous changes to the measures made due to the coronavirus disease 2019",
            "Added Medicare Advantage (MA) patients to the cohorts", "July 1, 2022 - June 30, 2025", "July 1, 2023 - June 30, 2025"])
        out["2026 CBM FAQ pp. 8-9 (FAQ 7)"] = all_in(faq8, ["now INCLUDED in the cohorts", "History of COVID-19",
                                                           "observation stays"])
        out["2026 CBM FAQ p. 2 (scope)"] = all_in(pdf_page("2026_CBM_FAQ.pdf", 2), ["refreshed on Medicare.gov in Summer 2026"])
    except FileNotFoundError as e:
        out["FAQ"] = [f"not run: {Path(e.filename).name} missing"]
    try:
        p37014 = fr_pages()[37014]
        out["90 FR 37014"] = all_in(p37014, ["HF Excess Days", "AMI Excess Days", "remove the COVID-19 exclusion"])
    except FileNotFoundError:
        out["90 FR 37014"] = ["not run: Federal Register copy missing"]
    return {k: ("matched" if not v else f"missing {v}") for k, v in out.items()}


# ----------------------------------------------------------------------------- references

def get_json(url: str) -> dict:
    import requests
    r = requests.get(url, headers={"User-Agent": "hospcomp-recheck/1.0 (reference check)"}, timeout=30)
    r.raise_for_status()
    return r.json()


def check_references(network: bool) -> tuple[bool | None, str, list]:
    sys.path.insert(0, str(ROOT / "src"))
    from hospcomp.references import REFERENCES  # reference strings only
    ms = (ROOT / "manuscript" / "manuscript.md").read_text(encoding="utf-8")
    listed = ms.split("## References")[1].split("## Figure legends")[0]
    cited = [k for k, v in REFERENCES.items() if v.split(" [Internet]")[0][:60] in listed or v[:60] in listed]
    if not network:
        return None, "not rechecked (run with --network)", []
    rows = []
    for key in cited:
        ref = REFERENCES[key]
        doi = re.search(r"doi:(10\.\S+?)\.?$", ref)
        if doi:
            msg = get_json("https://api.crossref.org/works/" + urllib.parse.quote(doi.group(1)))["message"]
            year = str((msg.get("published-print") or msg.get("published-online") or msg.get("issued"))["date-parts"][0][0])
            fam = (msg.get("author") or [{}])[0].get("family", "")
            vol, page = msg.get("volume", ""), (msg.get("page") or msg.get("article-number") or "").split("-")[0]
            checks = {"year": year in ref, "first author": fam.split()[-1].lower() in ref.lower() if fam else True,
                      "volume": (f";{vol}(" in ref or f";{vol}:" in ref) if vol else True,
                      "first page": page in ref if page else True}
            rows.append({"key": key, "via": "Crossref", "doi": doi.group(1), **checks,
                         "ok": all(checks.values())})
            time.sleep(0.2)
        elif re.search(r"\.\s\d{4}(?:\s\w{3})?;\d+", ref):  # journal article without DOI
            title = re.sub(r"[^\w\s-]", " ", ref.split(". ")[1])
            first_author = ref.split(",")[0]
            q = urllib.parse.quote(f"{first_author}[au] AND ({title})[ti]")
            ids = get_json(f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&term={q}")
            idl = ids["esearchresult"]["idlist"]
            ok = False
            if idl:
                s = get_json(f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id={idl[0]}")
                d = s["result"][idl[0]]
                ok = d["pubdate"][:4] in ref and f";{d['volume']}(" in ref and d["pages"].split("-")[0] in ref
            rows.append({"key": key, "via": "PubMed", "pmid": idl[0] if idl else None, "ok": ok})
            time.sleep(0.4)
        else:
            url = re.search(r"Available from: (\S+)$", ref)
            status = None
            if url and "qualitynet.cms.gov" not in url.group(1):
                import requests
                try:
                    status = requests.get(url.group(1), headers={"User-Agent": "Mozilla/5.0"}, timeout=60).status_code
                except requests.RequestException as e:
                    status = str(e)[:60]
            local = None
            if url and "qualitynet.cms.gov" in url.group(1):
                man = json.loads((ROOT / "source_manifest.json").read_text())["documents_browser"]
                local = any(d["url"] == url.group(1) and d.get("present") and d.get("is_pdf") for d in man.values())
            rows.append({"key": key, "via": "saved copy listed in source_manifest.json" if local is not None else "HTTP",
                         "status": status, "ok": bool(local) if local is not None else status == 200})
    bad = [r["key"] for r in rows if not r["ok"]]
    return not bad, f"{len(rows)} cited references checked; differing: {bad or 'none'}", rows


# ----------------------------------------------------------------------------- numbers

def formatted_claims() -> set[str]:
    claims = json.loads((ROOT / "evidence" / "claims.json").read_text())["claims"]
    out: set[str] = set()

    def add(v):
        if isinstance(v, bool) or v is None:
            return
        if isinstance(v, dict):
            for x in v.values():
                add(x)
            return
        if isinstance(v, (list, tuple)):
            for x in v:
                add(x)
            return
        if isinstance(v, str):
            out.update(re.findall(r"\d[\d,.\-]*\d|\d", v))
            return
        f = float(v)
        out.update({f"{round(f):,}", f"{f:.1f}", f"{f:.2f}", str(v)})
        if 0 <= f <= 1:
            for d in (0, 1, 2, 3):
                out.add(f"{f * 100:.{d}f}")
    for c in claims:
        add(c["value"])
        for k in ("numerator", "denominator"):
            add(c.get(k))
    for a, b in [(c["numerator"], c["denominator"]) for c in claims if c.get("numerator") and c.get("denominator")]:
        out.add(f"{round(b / a):,}")
    return out


FIXED = {"30", "95", "10", "25", "50", "1", "2", "3", "6", "S1", "S2", "S3", "R1", "R2", "R3", "G0", "G2b", "G3",
         "G4", "G5", "G6", "2021", "2024", "2026", "2026-09-30", "2026-08-13", "2026-05-13", "2026-89-IP",
         "18", "36", "24"}


def check_numbers() -> tuple[bool, str, list]:
    ms = (ROOT / "manuscript" / "manuscript.md").read_text(encoding="utf-8")
    abstract = ms.split("## Abstract")[1].split("**Keywords:**")[0]
    tables = "\n".join(l for l in ms.splitlines() if l.startswith("|"))
    legends = ms.split("## Figure legends")[1].split("## Additional files")[0]
    allowed = formatted_claims()
    unmatched = []
    for name, text in (("abstract", abstract), ("tables", tables), ("figure legends", legends)):
        text = re.sub(r"\*\*(Background|Methods|Results|Conclusions|Figure \d+|Table \d+)[.:]?\*\*", " ", text)
        text = re.sub(r"Figure \d|Table \d|Table S\d+", " ", text)
        for tok in re.findall(r"\d{4}-\d{2}-\d{2}|\d{4}-\d{2}-[A-Z]{2}|[GRS]\d+b?|\d[\d,]*(?:\.\d+)?", text):
            t = tok.rstrip(".,")
            if t in FIXED or t in allowed or t.rstrip("%") in allowed:
                continue
            unmatched.append((name, t))
    return not unmatched, (f"every number matched a claim value or a fixed design constant"
                           if not unmatched else f"unmatched: {unmatched}"), unmatched


# ----------------------------------------------------------------------------- main

def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--network", action="store_true", help="check references against Crossref, PubMed and the cited pages")
    args = ap.parse_args()
    with open(HAND, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    raw = {k: read_member(v) for k, v in FILES.items()}
    gi_type = {r["Facility ID"]: r["Hospital Type"] for r in read_member("Hospital_General_Information.csv")}
    md = read_member("Measure_Dates.csv")
    examples = json.loads((ROOT / "outputs" / "tables" / "examples.json").read_text())
    wb = workbook_rows()
    results = []
    extra = {}
    for row in rows:
        t = row["check_type"]
        if t == "raw_record":
            ok, detail = check_raw_record(row, raw, wb)
        elif t == "example":
            ok, detail = check_example(row, raw, gi_type, md)
        elif t == "recalculation" and row["target"].startswith("rank range"):
            ok, detail = check_rank_range(row, raw, gi_type, md, examples)
        elif t == "recalculation":
            ok, detail = check_gap(row, raw, gi_type, md)
        elif t == "document":
            try:
                ok, detail = check_documents(row["check_id"], row)
            except FileNotFoundError as e:
                ok, detail = None, f"not run: {Path(e.filename).name} has not been saved locally (see README)"
        elif t == "references":
            ok, detail, extra["references"] = check_references(args.network)
        elif t == "numbers":
            ok, detail, extra["numbers_unmatched"] = check_numbers()
        else:
            ok, detail = False, "unknown check type"
        result = "matched" if ok else ("not run" if ok is None else "differs")
        row["script_recheck"] = result
        row["script_recheck_detail"] = detail
        row["script_recheck_date"] = date.today().isoformat()
        results.append({"check_id": row["check_id"], "result": result, "detail": detail})
        print(f"{row['check_id']} {result}: {detail}")
    fields = list(rows[0].keys())
    with open(HAND, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    summary = {"items": len(results), "matched": sum(r["result"] == "matched" for r in results),
               "differs": [r["check_id"] for r in results if r["result"] == "differs"],
               "not_run": [r["check_id"] for r in results if r["result"] == "not run"]}
    extra["definition_change_sources"] = definition_change_sources()
    print("definition-change sources:", extra["definition_change_sources"])
    OUT.write_text(json.dumps({"script": "scripts/recheck_hand_items.py", "date": date.today().isoformat(),
                               "network": args.network, "summary": summary, "results": results, **extra},
                              indent=1), encoding="utf-8")
    print(json.dumps(summary))
    if summary["differs"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
