"""Verify the delivered bundle end to end.

1. Extract the source archive into a clean directory, create a fresh virtual
   environment, install from requirements.lock, run the tests and the demo.
2. Extract the outer ZIP, check its layout, serve site/ over local HTTP and
   request every local href and src on every HTML page, including anchors.

Writes outputs/verification/clean_install.json and outputs/verification/site_check.json.
Usage: python scripts/verify_bundle.py <scratch_dir>
"""

from __future__ import annotations

import html.parser
import json
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLUG = "hospital-comparability"
OUTER = ROOT / "deliverables" / "07-hospital-comparability-PROJECT-BUNDLE.zip"
VERIF = ROOT / "outputs" / "verification"


def sh(cmd: list[str], cwd: Path, timeout: int = 1800) -> tuple[int, str]:
    res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return res.returncode, (res.stdout + res.stderr)[-4000:]


def clean_install(scratch: Path) -> dict:
    src_zip = ROOT / "site" / "projects" / SLUG / "downloads" / f"{SLUG}-source.zip"
    target = scratch / "clean_source"
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    with zipfile.ZipFile(src_zip) as zf:
        names = zf.namelist()
        bad = [n for n in names if n.startswith("/") or ".." in Path(n).parts]
        zf.extractall(target)
    forbidden = [n for n in names if n.startswith((".venv/", "data/", ".local/", "deliverables/", "submission/"))
                 or n.endswith((".sqlite", ".pyc"))]
    import hashlib
    out = {"recorded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
           "archive": src_zip.relative_to(ROOT).as_posix(), "archive_sha256": hashlib.sha256(src_zip.read_bytes()).hexdigest(),
           "members": len(names), "unsafe_members": bad, "forbidden_members": forbidden}
    py = sys.executable
    code, log = sh([py, "-m", "venv", ".venv"], target)
    out["venv"] = "ok" if code == 0 else log
    pip = str(target / ".venv" / "bin" / "pip")
    code, log = sh([pip, "install", "-q", "-r", "requirements.lock", "-e", "."], target)
    out["install"] = "ok" if code == 0 else log
    code, log = sh([str(target / ".venv" / "bin" / "python"), "-m", "pytest", "-q"], target)
    out["tests_exit"] = code
    out["tests_summary"] = log.strip().splitlines()[-1] if log.strip() else ""
    code, log = sh([str(target / ".venv" / "bin" / "hospcomp"), "demo"], target)
    out["demo_exit"] = code
    out["demo_excerpt"] = "\n".join(line for line in log.splitlines() if "compatible" in line or "pairs" in line)[:800]
    out["passed"] = (not bad and not forbidden and out["venv"] == "ok" and out["install"] == "ok"
                     and out["tests_exit"] == 0 and out["demo_exit"] == 0)
    out["note"] = "The demo uses only the synthetic fixture; it is not evidence that the full study ran."
    return out


class LinkParser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.ids = [], set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.add(a["id"])
        for key in ("href", "src"):
            if key in a and a[key]:
                self.links.append(a[key])


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def site_check(scratch: Path) -> dict:
    target = scratch / "outer"
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    with zipfile.ZipFile(OUTER) as zf:
        bad = zf.testzip()
        names = zf.namelist()
        zf.extractall(target)
    required = [f"site/projects/{SLUG}/index.html", f"site/projects/{SLUG}/report.html",
                f"site/projects/{SLUG}/downloads/{SLUG}-source.zip", f"handoff/{SLUG}.json",
                f"handoff/{SLUG}-validation.md", "handoff/verified_results.md"]
    missing = [r for r in required if r not in names]
    top = sorted({n.split("/")[0] for n in names})
    outside_slug = [n for n in names if n.startswith("site/") and not n.startswith(f"site/projects/{SLUG}/")]
    port = free_port()
    handler = partial(SimpleHTTPRequestHandler, directory=str(target / "site"))
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *args, **kwargs):
            pass
    handler = partial(Quiet, directory=str(target / "site"))
    httpd = ThreadingHTTPServer(("127.0.0.1", port), handler)
    th = threading.Thread(target=httpd.serve_forever, daemon=True)
    th.start()
    base = f"http://127.0.0.1:{port}/projects/{SLUG}/"
    pages = sorted((target / "site" / "projects" / SLUG).glob("*.html"))
    checked, broken, external, anchors_bad = 0, [], set(), []
    try:
        for page in pages:
            url = base + page.name
            body = urllib.request.urlopen(url, timeout=20).read().decode("utf-8")
            p = LinkParser()
            p.feed(body)
            for link in p.links:
                if link.startswith(("http://", "https://", "mailto:")):
                    external.add(link)
                    continue
                full = urllib.parse.urljoin(url, link)
                path, _, frag = full.partition("#")
                if path.rstrip("/") == f"http://127.0.0.1:{port}":
                    continue  # breadcrumb to the combined-site root, outside this project
                if frag and path == url:
                    if frag not in p.ids:
                        anchors_bad.append(f"{page.name}#{frag}")
                    continue
                checked += 1
                try:
                    urllib.request.urlopen(path, timeout=20).read(64)
                except Exception as exc:  # noqa: BLE001
                    broken.append(f"{page.name} -> {link} ({exc})")
        # viewer data files referenced from the index JSON
        data_dir = target / "site" / "projects" / SLUG / "assets" / "data"
        if data_dir.exists():
            for f in sorted(data_dir.glob("*.json")):
                checked += 1
                try:
                    json.loads(urllib.request.urlopen(base + "assets/data/" + f.name, timeout=20).read())
                except Exception as exc:  # noqa: BLE001
                    broken.append(f"assets/data/{f.name} ({exc})")
    finally:
        httpd.shutdown()
    size = OUTER.stat().st_size
    import hashlib
    site_root = target / "site" / "projects" / SLUG
    lines = [f"site/projects/{SLUG}/{p.relative_to(site_root).as_posix()} {hashlib.sha256(p.read_bytes()).hexdigest()}"
             for p in sorted(site_root.rglob("*")) if p.is_file() and p.name != ".DS_Store"]
    digest = hashlib.sha256("\n".join(lines).encode()).hexdigest()
    src_zip = site_root / "downloads" / f"{SLUG}-source.zip"
    additional = [n for n in names if n.startswith("handoff/submission/additional_files/")]
    if len(additional) != 6:
        missing.append(f"handoff/submission/additional_files/ holds {len(additional)} files, expected 6")
    # The outer ZIP's own checksum cannot be stored inside it; the site digest and the
    # source-archive checksum identify what was checked.
    return {"recorded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "outer_zip": OUTER.relative_to(ROOT).as_posix(), "bundle_mib_at_check": round(size / 1024 / 1024, 2),
            "source_zip_sha256": hashlib.sha256(src_zip.read_bytes()).hexdigest(), "site_files_digest": digest,
            "additional_files": sorted(n.rsplit("/", 1)[-1] for n in additional),
            "zip_integrity": "ok" if bad is None else f"corrupt member {bad}", "top_level": top,
            "missing_required": missing, "files_outside_slug": outside_slug, "pages": [p.name for p in pages],
            "local_links_checked": checked, "broken": broken, "bad_anchors": anchors_bad,
            "external_links": sorted(external),
            "passed": bad is None and not missing and not outside_slug and not broken and not anchors_bad
            and size < 28 * 1024 * 1024}


def main() -> None:
    scratch = Path(sys.argv[1]).resolve()
    scratch.mkdir(parents=True, exist_ok=True)
    VERIF.mkdir(parents=True, exist_ok=True)
    ci = clean_install(scratch)
    (VERIF / "clean_install.json").write_text(json.dumps(ci, indent=2) + "\n")
    sc = site_check(scratch)
    (VERIF / "site_check.json").write_text(json.dumps(sc, indent=2) + "\n")
    print(json.dumps({"clean_install": ci["passed"], "site_check": sc["passed"], "broken": sc["broken"][:10],
                      "missing": sc["missing_required"], "tests": ci["tests_summary"], "mib": sc["bundle_mib_at_check"]},
                     indent=1))


if __name__ == "__main__":
    main()
