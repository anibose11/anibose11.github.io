# Supplementary tables S1 to S12

Run hc-20261007T214017-783661a110. Primary release 2026-05-13. All tables are generated from the output files listed under each heading; the CSV files are included in the source archive.

## Table S1. Gate flow by release and measure

Source: outputs/tables/gate_flow_national.csv

| Release | Measure | Requested | After G0 | After G2b | After G3 | After G4 | After G5 | Compatible | Compatible, strict | Numeric score, no usable interval |
|---|---|---|---|---|---|---|---|---|---|---|
| 2026-05-13 | AMI excess days | 4792 | 4792 | 4660 | 4621 | 1445 | 1445 | 1445 | 1445 | 0 |
| 2026-05-13 | HF excess days | 4792 | 4792 | 4660 | 4601 | 2975 | 2975 | 2975 | 2975 | 0 |
| 2026-05-13 | AMI mortality | 4792 | 4792 | 4660 | 4615 | 1826 | 1826 | 1826 | 1811 | 0 |
| 2026-05-13 | HF mortality | 4792 | 4792 | 4660 | 4601 | 2926 | 2926 | 2926 | 2910 | 0 |
| 2026-05-13 | AMI readmission | 4792 | 4792 | 4660 | 4616 | 1699 | 1699 | 1699 | 1685 | 0 |
| 2026-05-13 | HF readmission | 4792 | 4792 | 4660 | 4601 | 2975 | 2975 | 2975 | 2960 | 0 |
| 2026-08-13 | AMI excess days | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-08-13 | HF excess days | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-08-13 | AMI mortality | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-08-13 | HF mortality | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-08-13 | AMI readmission | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-08-13 | HF readmission | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| 2026-09-30 | AMI excess days | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1532 |
| 2026-09-30 | HF excess days | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3108 |
| 2026-09-30 | AMI mortality | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1935 |
| 2026-09-30 | HF mortality | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3049 |
| 2026-09-30 | AMI readmission | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1971 |
| 2026-09-30 | HF readmission | 4790 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 3253 |

## Table S2. First failing gate and reason, primary release

Source: outputs/tables/failure_reasons.csv

| Measure | First failed gate | Reason | Records |
|---|---|---|---|
| AMI excess days | G4 | too_few_cases | 1977 |
| AMI excess days | none | compatible | 1445 |
| AMI excess days | G4 | not_available_this_period | 821 |
| AMI excess days | G4 | no_eligible_cases | 208 |
| AMI excess days | G4 | not_eligible_program | 170 |
| AMI excess days | G2b | population_or_data_source_differs | 132 |
| AMI excess days | G3 | partial_or_short_period_footnote | 39 |
| HF excess days | none | compatible | 2975 |
| HF excess days | G4 | too_few_cases | 1118 |
| HF excess days | G4 | not_available_this_period | 323 |
| HF excess days | G4 | not_eligible_program | 170 |
| HF excess days | G2b | population_or_data_source_differs | 132 |
| HF excess days | G3 | partial_or_short_period_footnote | 59 |
| HF excess days | G4 | no_eligible_cases | 15 |
| AMI mortality | none | compatible | 1826 |
| AMI mortality | G4 | too_few_cases | 1761 |
| AMI mortality | G4 | not_available_this_period | 774 |
| AMI mortality | G4 | not_eligible_program | 170 |
| AMI mortality | G2b | population_or_data_source_differs | 132 |
| AMI mortality | G4 | no_eligible_cases | 84 |
| AMI mortality | G3 | partial_or_short_period_footnote | 45 |
| HF mortality | none | compatible | 2926 |
| HF mortality | G4 | too_few_cases | 1161 |
| HF mortality | G4 | not_available_this_period | 321 |
| HF mortality | G4 | not_eligible_program | 170 |
| HF mortality | G2b | population_or_data_source_differs | 132 |
| HF mortality | G3 | partial_or_short_period_footnote | 59 |
| HF mortality | G4 | no_eligible_cases | 23 |
| AMI readmission | G4 | too_few_cases | 1718 |
| AMI readmission | none | compatible | 1699 |
| AMI readmission | G4 | not_available_this_period | 821 |
| AMI readmission | G4 | no_eligible_cases | 208 |
| AMI readmission | G4 | not_eligible_program | 170 |
| AMI readmission | G2b | population_or_data_source_differs | 132 |
| AMI readmission | G3 | partial_or_short_period_footnote | 44 |
| HF readmission | none | compatible | 2975 |
| HF readmission | G4 | too_few_cases | 1118 |
| HF readmission | G4 | not_available_this_period | 323 |
| HF readmission | G4 | not_eligible_program | 170 |
| HF readmission | G2b | population_or_data_source_differs | 132 |
| HF readmission | G3 | partial_or_short_period_footnote | 59 |
| HF readmission | G4 | no_eligible_cases | 15 |

## Table S3. Pairwise separation, primary and strict subsets (S1, S2)

Source: outputs/tables/pair_summary_national.csv. Shares are of point-ordered pairs.

| Subset | Measure | Pairs | Point-ordered | Tied | Separated R1 | R1 share | R2 share | R3 share | CMS categories opposite | Not separated R1 |
|---|---|---|---|---|---|---|---|---|---|---|
| primary | AMI excess days | 38980 | 38942 | 38 | 13542 | 34.77% | 34.63% | 58.56% | 12.99% | 65.23% |
| primary | HF excess days | 145041 | 144898 | 143 | 55129 | 38.05% | 37.90% | 58.18% | 13.22% | 61.95% |
| primary | AMI mortality | 60910 | 59433 | 1477 | 133 | 0.22% | 0.19% | 4.65% | 0.02% | 99.78% |
| primary | HF mortality | 140339 | 138228 | 2111 | 4102 | 2.97% | 2.73% | 16.25% | 0.40% | 97.03% |
| primary | AMI readmission | 53384 | 51440 | 1944 | 3 | 0.01% | 0.01% | 1.55% | 0.00% | 99.99% |
| primary | HF readmission | 145041 | 141219 | 3822 | 549 | 0.39% | 0.34% | 5.35% | 0.05% | 99.61% |
| strict | AMI excess days | 38980 | 38942 | 38 | 13542 | 34.77% | 34.63% | 58.56% | 12.99% | 65.23% |
| strict | HF excess days | 145041 | 144898 | 143 | 55129 | 38.05% | 37.90% | 58.18% | 13.22% | 61.95% |
| strict | AMI mortality | 59618 | 58170 | 1448 | 132 | 0.23% | 0.19% | 4.69% | 0.02% | 99.77% |
| strict | HF mortality | 138327 | 136247 | 2080 | 4076 | 2.99% | 2.75% | 16.32% | 0.40% | 97.01% |
| strict | AMI readmission | 52250 | 50347 | 1903 | 3 | 0.01% | 0.01% | 1.57% | 0.00% | 99.99% |
| strict | HF readmission | 143107 | 139329 | 3778 | 544 | 0.39% | 0.35% | 5.35% | 0.05% | 99.61% |

## Table S4. State-weighted and hospital-level summaries

Sources: outputs/tables/state_weighted_summary.csv and outputs/tables/hospital_level_summary.csv.

| Subset | Measure | States | Median state share not separated | Q1 | Q3 | Minimum | Maximum |
|---|---|---|---|---|---|---|---|
| primary | AMI excess days | 51 | 65.9% | 59.9% | 74.6% | 33.3% | 100.0% |
| primary | HF excess days | 53 | 62.2% | 58.3% | 70.4% | 46.7% | 100.0% |
| primary | AMI mortality | 52 | 100.0% | 100.0% | 100.0% | 97.7% | 100.0% |
| primary | HF mortality | 53 | 99.0% | 97.6% | 100.0% | 91.4% | 100.0% |
| primary | AMI readmission | 52 | 100.0% | 100.0% | 100.0% | 99.4% | 100.0% |
| primary | HF readmission | 53 | 100.0% | 99.7% | 100.0% | 95.8% | 100.0% |
| strict | AMI excess days | 51 | 65.9% | 59.9% | 74.6% | 33.3% | 100.0% |
| strict | HF excess days | 53 | 62.2% | 58.3% | 70.4% | 46.7% | 100.0% |
| strict | AMI mortality | 52 | 100.0% | 100.0% | 100.0% | 97.7% | 100.0% |
| strict | HF mortality | 53 | 99.0% | 97.6% | 100.0% | 91.4% | 100.0% |
| strict | AMI readmission | 52 | 100.0% | 100.0% | 100.0% | 99.4% | 100.0% |
| strict | HF readmission | 53 | 100.0% | 99.7% | 100.0% | 95.8% | 100.0% |

| Subset | Measure | Hospitals | Median share of peers separated | Q1 | Q3 | Separated from none | Share separated from none |
|---|---|---|---|---|---|---|---|
| primary | AMI excess days | 1442 | 29.0% | 18.6% | 44.7% | 20 | 1.4% |
| primary | HF excess days | 2973 | 35.0% | 22.4% | 48.8% | 20 | 0.7% |
| primary | AMI mortality | 1824 | 0.0% | 0.0% | 0.0% | 1682 | 92.2% |
| primary | HF mortality | 2924 | 0.0% | 0.0% | 2.2% | 1584 | 54.2% |
| primary | AMI readmission | 1697 | 0.0% | 0.0% | 0.0% | 1693 | 99.8% |
| primary | HF readmission | 2973 | 0.0% | 0.0% | 0.0% | 2596 | 87.3% |
| strict | AMI excess days | 1442 | 29.0% | 18.6% | 44.7% | 20 | 1.4% |
| strict | HF excess days | 2973 | 35.0% | 22.4% | 48.8% | 20 | 0.7% |
| strict | AMI mortality | 1809 | 0.0% | 0.0% | 0.0% | 1668 | 92.2% |
| strict | HF mortality | 2908 | 0.0% | 0.0% | 2.2% | 1575 | 54.2% |
| strict | AMI readmission | 1683 | 0.0% | 0.0% | 0.0% | 1679 | 99.8% |
| strict | HF readmission | 2958 | 0.0% | 0.0% | 0.0% | 2584 | 87.4% |

## Table S5. Interval-compatible rank ranges

Source: outputs/tables/rank_range_summary.csv.

| Subset | Measure | Hospitals | Median width / n | Width over half of n | Full range | States with 10 or more | First-ranked: median worst rank / n | First-ranked: worst rank in bottom half (states) |
|---|---|---|---|---|---|---|---|---|
| primary | AMI excess days | 1442 | 72.0% | 81.6% | 1.4% | 39 | 32.0% | 7 |
| primary | HF excess days | 2973 | 65.7% | 77.1% | 0.7% | 48 | 21.2% | 7 |
| primary | AMI mortality | 1824 | 100.0% | 99.9% | 92.2% | 41 | 100.0% | 40 |
| primary | HF mortality | 2924 | 100.0% | 99.6% | 54.2% | 48 | 91.7% | 44 |
| primary | AMI readmission | 1697 | 100.0% | 100.0% | 99.8% | 40 | 100.0% | 40 |
| primary | HF readmission | 2973 | 100.0% | 100.0% | 87.3% | 48 | 98.9% | 48 |
| strict | AMI excess days | 1442 | 72.0% | 81.6% | 1.4% | 39 | 32.0% | 7 |
| strict | HF excess days | 2973 | 65.7% | 77.1% | 0.7% | 48 | 21.2% | 7 |
| strict | AMI mortality | 1809 | 100.0% | 99.9% | 92.2% | 41 | 100.0% | 40 |
| strict | HF mortality | 2908 | 100.0% | 99.6% | 54.2% | 48 | 91.7% | 44 |
| strict | AMI readmission | 1683 | 100.0% | 100.0% | 99.8% | 40 | 100.0% | 40 |
| strict | HF readmission | 2958 | 100.0% | 100.0% | 87.4% | 48 | 98.9% | 48 |

## Table S6. Definitional compatibility matrix, primary release

Source: outputs/tables/compatibility_matrix.csv.

| Measure A | Measure B | Same ID | Same quantity | Same unit | Same window | Same condition | Same program | Checks failed | First failure |
|---|---|---|---|---|---|---|---|---|---|
| EDAC_30_AMI | EDAC_30_HF | False | True | True | True | False | True | 2 | same_measure_id |
| EDAC_30_AMI | MORT_30_AMI | False | False | False | True | True | True | 3 | same_measure_id |
| EDAC_30_AMI | MORT_30_HF | False | False | False | True | False | True | 4 | same_measure_id |
| EDAC_30_AMI | READM-30-AMI-HRRP | False | False | False | True | True | False | 4 | same_measure_id |
| EDAC_30_AMI | READM-30-HF-HRRP | False | False | False | True | False | False | 5 | same_measure_id |
| EDAC_30_AMI | READM_30_AMI | False | False | False | True | True | True | 3 | same_measure_id |
| EDAC_30_AMI | READM_30_HF | False | False | False | True | False | True | 4 | same_measure_id |
| EDAC_30_HF | MORT_30_AMI | False | False | False | True | False | True | 4 | same_measure_id |
| EDAC_30_HF | MORT_30_HF | False | False | False | True | True | True | 3 | same_measure_id |
| EDAC_30_HF | READM-30-AMI-HRRP | False | False | False | True | False | False | 5 | same_measure_id |
| EDAC_30_HF | READM-30-HF-HRRP | False | False | False | True | True | False | 4 | same_measure_id |
| EDAC_30_HF | READM_30_AMI | False | False | False | True | False | True | 4 | same_measure_id |
| EDAC_30_HF | READM_30_HF | False | False | False | True | True | True | 3 | same_measure_id |
| MORT_30_AMI | MORT_30_HF | False | True | True | True | False | True | 2 | same_measure_id |
| MORT_30_AMI | READM-30-AMI-HRRP | False | False | False | True | True | False | 4 | same_measure_id |
| MORT_30_AMI | READM-30-HF-HRRP | False | False | False | True | False | False | 5 | same_measure_id |
| MORT_30_AMI | READM_30_AMI | False | False | True | True | True | True | 2 | same_measure_id |
| MORT_30_AMI | READM_30_HF | False | False | True | True | False | True | 3 | same_measure_id |
| MORT_30_HF | READM-30-AMI-HRRP | False | False | False | True | False | False | 5 | same_measure_id |
| MORT_30_HF | READM-30-HF-HRRP | False | False | False | True | True | False | 4 | same_measure_id |
| MORT_30_HF | READM_30_AMI | False | False | True | True | False | True | 3 | same_measure_id |
| MORT_30_HF | READM_30_HF | False | False | True | True | True | True | 2 | same_measure_id |
| READM-30-AMI-HRRP | READM-30-HF-HRRP | False | True | True | True | False | True | 2 | same_measure_id |
| READM-30-AMI-HRRP | READM_30_AMI | False | False | False | True | True | False | 4 | same_measure_id |
| READM-30-AMI-HRRP | READM_30_HF | False | False | False | True | False | False | 5 | same_measure_id |
| READM-30-HF-HRRP | READM_30_AMI | False | False | False | True | False | False | 5 | same_measure_id |
| READM-30-HF-HRRP | READM_30_HF | False | False | False | True | True | False | 4 | same_measure_id |
| READM_30_AMI | READM_30_HF | False | True | True | True | False | True | 2 | same_measure_id |

## Table S7. Observation windows across releases

Source: outputs/tables/cross_release_windows.csv. Interval status describes the Care Compare release; the HRRP payment file has no interval columns and is the same file in all three releases. Definition changes are taken from the FY 2026 IPPS final rule and the CMS answers to frequently asked questions for Summer 2026 public reporting (config/releases.toml gives the pages).

| Measure ID | Release | Interval status | Start | End | Months | Months shared with primary | Documented definition change |
|---|---|---|---|---|---|---|---|
| EDAC_30_AMI | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| EDAC_30_AMI | 2026-08-13 | flagged_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, COVID-19 readmissions, emergency department visits and observation stays now count in the outcome, the history of COVID-19 risk variable was removed, and code sets, crosswalks and risk-adjustment data sources were updated. |
| EDAC_30_AMI | 2026-09-30 | suppressed_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, COVID-19 readmissions, emergency department visits and observation stays now count in the outcome, the history of COVID-19 risk variable was removed, and code sets, crosswalks and risk-adjustment data sources were updated. |
| EDAC_30_HF | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| EDAC_30_HF | 2026-08-13 | flagged_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, COVID-19 readmissions, emergency department visits and observation stays now count in the outcome, the history of COVID-19 risk variable was removed, and code sets, crosswalks and risk-adjustment data sources were updated. |
| EDAC_30_HF | 2026-09-30 | suppressed_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, COVID-19 readmissions, emergency department visits and observation stays now count in the outcome, the history of COVID-19 risk variable was removed, and code sets, crosswalks and risk-adjustment data sources were updated. |
| MORT_30_AMI | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| MORT_30_AMI | 2026-08-13 | flagged_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, the history of COVID-19 risk variable was removed, ICD-10 code sets and condition-category crosswalks were updated, and physician/carrier claim header diagnoses were added to risk adjustment. |
| MORT_30_AMI | 2026-09-30 | suppressed_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, the history of COVID-19 risk variable was removed, ICD-10 code sets and condition-category crosswalks were updated, and physician/carrier claim header diagnoses were added to risk adjustment. |
| MORT_30_HF | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| MORT_30_HF | 2026-08-13 | flagged_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, the history of COVID-19 risk variable was removed, ICD-10 code sets and condition-category crosswalks were updated, and physician/carrier claim header diagnoses were added to risk adjustment. |
| MORT_30_HF | 2026-09-30 | suppressed_by_cms_notice | 2022-07-01 | 2025-06-30 | 36 | 24 | The 3-year window advanced by one year (July 1, 2022 to June 30, 2025). COVID-19 index admissions are now included in the cohort, the history of COVID-19 risk variable was removed, ICD-10 code sets and condition-category crosswalks were updated, and physician/carrier claim header diagnoses were added to risk adjustment. |
| READM-30-AMI-HRRP | 2026-05-13 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM-30-AMI-HRRP | 2026-08-13 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM-30-AMI-HRRP | 2026-09-30 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM-30-HF-HRRP | 2026-05-13 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM-30-HF-HRRP | 2026-08-13 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM-30-HF-HRRP | 2026-09-30 | not applicable (HRRP file; no intervals; not covered by the notice) | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM_30_AMI | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM_30_AMI | 2026-08-13 | flagged_by_cms_notice | 2023-07-01 | 2025-06-30 | 24 | 12 | Cohort expanded to include Medicare Advantage beneficiaries, measurement period shortened from 3 years to 2 years (July 1, 2023 to June 30, 2025, matching the newer files), risk models updated, and the COVID-19 exclusion and history of COVID-19 risk variable removed. |
| READM_30_AMI | 2026-09-30 | suppressed_by_cms_notice | 2023-07-01 | 2025-06-30 | 24 | 12 | Cohort expanded to include Medicare Advantage beneficiaries, measurement period shortened from 3 years to 2 years (July 1, 2023 to June 30, 2025, matching the newer files), risk models updated, and the COVID-19 exclusion and history of COVID-19 risk variable removed. |
| READM_30_HF | 2026-05-13 | published | 2021-07-01 | 2024-06-30 | 36 | 36 |  |
| READM_30_HF | 2026-08-13 | flagged_by_cms_notice | 2023-07-01 | 2025-06-30 | 24 | 12 | Cohort expanded to include Medicare Advantage beneficiaries, measurement period shortened from 3 years to 2 years (July 1, 2023 to June 30, 2025, matching the newer files), risk models updated, and the COVID-19 exclusion and history of COVID-19 risk variable removed. |
| READM_30_HF | 2026-09-30 | suppressed_by_cms_notice | 2023-07-01 | 2025-06-30 | 24 | 12 | Cohort expanded to include Medicare Advantage beneficiaries, measurement period shortened from 3 years to 2 years (July 1, 2023 to June 30, 2025, matching the newer files), risk models updated, and the COVID-19 exclusion and history of COVID-19 risk variable removed. |

## Table S8. Category counts from hospital rows compared with CMS national files

Source: outputs/validation/reconciliation_categories.csv. Difference is hospital rows minus the CMS count.

| Release | Measure ID | Category | Hospital rows | CMS national file | Difference |
|---|---|---|---|---|---|
| 2026-05-13 | EDAC_30_AMI | fewer | 276 | 278 | -2 |
| 2026-05-13 | EDAC_30_AMI | average | 731 | 736 | -5 |
| 2026-05-13 | EDAC_30_AMI | more | 546 | 551 | -5 |
| 2026-05-13 | EDAC_30_AMI | too_small | 2024 | 2149 | -125 |
| 2026-05-13 | EDAC_30_HF | fewer | 746 | 767 | -21 |
| 2026-05-13 | EDAC_30_HF | average | 1399 | 1432 | -33 |
| 2026-05-13 | EDAC_30_HF | more | 1006 | 1034 | -28 |
| 2026-05-13 | EDAC_30_HF | too_small | 1124 | 1271 | -147 |
| 2026-05-13 | MORT_30_AMI | better | 29 | 29 | 0 |
| 2026-05-13 | MORT_30_AMI | no_different | 1910 | 1935 | -25 |
| 2026-05-13 | MORT_30_AMI | worse | 13 | 13 | 0 |
| 2026-05-13 | MORT_30_AMI | too_small | 1796 | 1916 | -120 |
| 2026-05-13 | MORT_30_HF | better | 300 | 305 | -5 |
| 2026-05-13 | MORT_30_HF | no_different | 2674 | 2743 | -69 |
| 2026-05-13 | MORT_30_HF | worse | 128 | 130 | -2 |
| 2026-05-13 | MORT_30_HF | too_small | 1167 | 1317 | -150 |
| 2026-05-13 | READM_30_AMI | better | 6 | 6 | 0 |
| 2026-05-13 | READM_30_AMI | no_different | 1806 | 1827 | -21 |
| 2026-05-13 | READM_30_AMI | worse | 11 | 11 | 0 |
| 2026-05-13 | READM_30_AMI | too_small | 1754 | 1870 | -116 |
| 2026-05-13 | READM_30_HF | better | 56 | 56 | 0 |
| 2026-05-13 | READM_30_HF | no_different | 3038 | 3120 | -82 |
| 2026-05-13 | READM_30_HF | worse | 57 | 57 | 0 |
| 2026-05-13 | READM_30_HF | too_small | 1124 | 1271 | -147 |
| 2026-08-13 | EDAC_30_AMI | fewer | 31 | 31 | 0 |
| 2026-08-13 | EDAC_30_AMI | average | 1455 | 1463 | -8 |
| 2026-08-13 | EDAC_30_AMI | more | 46 | 47 | -1 |
| 2026-08-13 | EDAC_30_AMI | too_small | 1973 | 2085 | -112 |
| 2026-08-13 | EDAC_30_HF | fewer | 304 | 310 | -6 |
| 2026-08-13 | EDAC_30_HF | average | 2524 | 2566 | -42 |
| 2026-08-13 | EDAC_30_HF | more | 280 | 298 | -18 |
| 2026-08-13 | EDAC_30_HF | too_small | 1168 | 1324 | -156 |
| 2026-08-13 | MORT_30_AMI | better | 9 | 9 | 0 |
| 2026-08-13 | MORT_30_AMI | no_different | 1923 | 1941 | -18 |
| 2026-08-13 | MORT_30_AMI | worse | 3 | 3 | 0 |
| 2026-08-13 | MORT_30_AMI | too_small | 1732 | 1841 | -109 |
| 2026-08-13 | MORT_30_HF | better | 105 | 106 | -1 |
| 2026-08-13 | MORT_30_HF | no_different | 2907 | 2964 | -57 |
| 2026-08-13 | MORT_30_HF | worse | 37 | 38 | -1 |
| 2026-08-13 | MORT_30_HF | too_small | 1233 | 1388 | -155 |
| 2026-08-13 | READM_30_AMI | better | 2 | 2 | 0 |
| 2026-08-13 | READM_30_AMI | no_different | 1967 | 1984 | -17 |
| 2026-08-13 | READM_30_AMI | worse | 2 | 2 | 0 |
| 2026-08-13 | READM_30_AMI | too_small | 1531 | 1608 | -77 |
| 2026-08-13 | READM_30_HF | better | 21 | 21 | 0 |
| 2026-08-13 | READM_30_HF | no_different | 3194 | 3253 | -59 |
| 2026-08-13 | READM_30_HF | worse | 38 | 38 | 0 |
| 2026-08-13 | READM_30_HF | too_small | 1020 | 1121 | -101 |
| 2026-09-30 | EDAC_30_AMI | fewer | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_AMI | average | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_AMI | more | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_AMI | too_small | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_HF | fewer | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_HF | average | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_HF | more | 0 | Not Available |  |
| 2026-09-30 | EDAC_30_HF | too_small | 0 | Not Available |  |
| 2026-09-30 | MORT_30_AMI | better | 0 | Not Available |  |
| 2026-09-30 | MORT_30_AMI | no_different | 0 | Not Available |  |
| 2026-09-30 | MORT_30_AMI | worse | 0 | Not Available |  |
| 2026-09-30 | MORT_30_AMI | too_small | 0 | Not Available |  |
| 2026-09-30 | MORT_30_HF | better | 0 | Not Available |  |
| 2026-09-30 | MORT_30_HF | no_different | 0 | Not Available |  |
| 2026-09-30 | MORT_30_HF | worse | 0 | Not Available |  |
| 2026-09-30 | MORT_30_HF | too_small | 0 | Not Available |  |
| 2026-09-30 | READM_30_AMI | better | 0 | Not Available |  |
| 2026-09-30 | READM_30_AMI | no_different | 0 | Not Available |  |
| 2026-09-30 | READM_30_AMI | worse | 0 | Not Available |  |
| 2026-09-30 | READM_30_AMI | too_small | 0 | Not Available |  |
| 2026-09-30 | READM_30_HF | better | 0 | Not Available |  |
| 2026-09-30 | READM_30_HF | no_different | 0 | Not Available |  |
| 2026-09-30 | READM_30_HF | worse | 0 | Not Available |  |
| 2026-09-30 | READM_30_HF | too_small | 0 | Not Available |  |

## Table S9. Raw-record reconstruction

Source: outputs/validation/raw_reconstruction.csv. Each record was re-read from the raw CSV bytes with an independent parser and 14 fields were compared.

| Measure ID | Selection | Facility ID | File | Row | Score | Lower | Upper | Footnote | Matched |
|---|---|---|---|---|---|---|---|---|---|
| READM_30_HF | compatible_first | 010001 | Unplanned_Hospital_Visits-Hospital.csv | 12 | 20.1 | 17.9 | 22.6 |  | True |
| READM_30_HF | compatible_middle | 250104 | Unplanned_Hospital_Visits-Hospital.csv | 32772 | 19.5 | 16.8 | 22.4 |  | True |
| READM_30_HF | compatible_last | 670309 | Unplanned_Hospital_Visits-Hospital.csv | 66764 | 18.8 | 15.3 | 22.9 |  | True |
| READM_30_HF | too_few_first | 010021 | Unplanned_Hospital_Visits-Hospital.csv | 138 | Not Available | Not Available | Not Available | 1 | True |
| MORT_30_HF | compatible_first | 010001 | Complications_and_Deaths-Hospital.csv | 6 | 10.2 | 8.3 | 12.6 |  | True |
| MORT_30_HF | compatible_middle | 251315 | Complications_and_Deaths-Hospital.csv | 47506 | 14.5 | 9.0 | 22.3 |  | True |
| MORT_30_HF | compatible_last | 670309 | Complications_and_Deaths-Hospital.csv | 95366 | 9.2 | 5.4 | 14.6 |  | True |
| MORT_30_HF | too_few_first | 010021 | Complications_and_Deaths-Hospital.csv | 186 | Not Available | Not Available | Not Available | 1 | True |
| EDAC_30_HF | compatible_first | 010001 | Unplanned_Hospital_Visits-Hospital.csv | 2 | -1.1 | -10 | 7.9 |  | True |
| EDAC_30_HF | compatible_middle | 250104 | Unplanned_Hospital_Visits-Hospital.csv | 32762 | -1 | -13.2 | 11.8 |  | True |
| EDAC_30_HF | compatible_last | 670309 | Unplanned_Hospital_Visits-Hospital.csv | 66754 | -30.5 | -55.7 | 3.3 |  | True |
| EDAC_30_HF | too_few_first | 010021 | Unplanned_Hospital_Visits-Hospital.csv | 128 | Not Available | Not Available | Not Available | 1 | True |
| READM_30_AMI | compatible_first | 010001 | Unplanned_Hospital_Visits-Hospital.csv | 9 | 13 | 10.8 | 15.6 |  | True |
| READM_30_AMI | compatible_middle | 250104 | Unplanned_Hospital_Visits-Hospital.csv | 32769 | 13.4 | 10.9 | 16.5 |  | True |
| READM_30_AMI | compatible_last | 670260 | Unplanned_Hospital_Visits-Hospital.csv | 66677 | 13.9 | 11.0 | 17.4 |  | True |
| READM_30_AMI | too_few_first | 010005 | Unplanned_Hospital_Visits-Hospital.csv | 23 | Not Available | Not Available | Not Available | 1 | True |
| MORT_30_AMI | compatible_first | 010001 | Complications_and_Deaths-Hospital.csv | 3 | 11.4 | 9.1 | 14.3 |  | True |
| MORT_30_AMI | compatible_middle | 260005 | Complications_and_Deaths-Hospital.csv | 47923 | 11.4 | 8.5 | 15.3 |  | True |
| MORT_30_AMI | compatible_last | 670260 | Complications_and_Deaths-Hospital.csv | 95243 | 12.2 | 8.7 | 16.6 |  | True |
| MORT_30_AMI | too_few_first | 010005 | Complications_and_Deaths-Hospital.csv | 23 | Not Available | Not Available | Not Available | 1 | True |
| EDAC_30_AMI | compatible_first | 010001 | Unplanned_Hospital_Visits-Hospital.csv | 1 | -15.6 | -25.9 | -4.2 |  | True |
| EDAC_30_AMI | compatible_middle | 250094 | Unplanned_Hospital_Visits-Hospital.csv | 32663 | 29.9 | 7 | 57.9 |  | True |
| EDAC_30_AMI | compatible_last | 670122 | Unplanned_Hospital_Visits-Hospital.csv | 66543 | -11.9 | -25.1 | 3.7 |  | True |
| EDAC_30_AMI | too_few_first | 010005 | Unplanned_Hospital_Visits-Hospital.csv | 15 | Not Available | Not Available | Not Available | 1 | True |

## Table S10. Validation checks and records

Source: outputs/validation/validation_report.json. Checks have a pass condition; records document a comparison or count and have none.

| Type | Kind | Entry | Result | Detail |
|---|---|---|---|---|
| check | data | compatible records have lower <= score <= upper and lower < upper | passed | {"violations": 0, "compatible_records": 13846} |
| check | data | compatible rate records lie within 0 to 100 percent | passed | {"violations": 0, "compatible_percent_records": 9426} |
| check | data | every study record's window equals its release's official Measure Dates window | passed | {"records_with_other_windows": 0} |
| check | data | no numeric score carries an availability footnote (1, 4, 5, 7, 12, 13, 19) | passed | {"records": 0} |
| check | data | 'Number of Cases Too Small' rows have no numeric score | passed | {"records": 0} |
| check | data | score strings are numeric or the documented 'Not Available' text | passed | {"states": ["not_available", "numeric"]} |
| check | data | 2026-05-13: interval presence matches documented status 'published' | passed | {"numeric_scores": 14732, "numeric_scores_with_both_limits": 14732} |
| check | data | 2026-08-13: interval presence matches documented status 'flagged_by_cms_notice' | passed | {"numeric_scores": 14848, "numeric_scores_with_both_limits": 14848} |
| check | data | 2026-09-30: interval presence matches documented status 'suppressed_by_cms_notice' | passed | {"numeric_scores": 14848, "numeric_scores_with_both_limits": 0} |
| record | data | partial-period (footnote 29) records with numeric scores in the primary release | recorded | {"primary_release_records": 305} |
| check | data | every compatible record joins to a same-release hospital type | passed | {"missing": 0} |
| record | reconciliation | 2026-05-13: hospital-row category counts compared with the CMS national and state files | recorded | {"national_cells_published": 24, "national_cells_equal": 6, "national_cells_unpublished": 0, "max_abs_national_difference": 150, "state_cells_published": 1248, "state_cells_equal": 862} |
| record | reconciliation | 2026-08-13: hospital-row category counts compared with the CMS national and state files | recorded | {"national_cells_published": 24, "national_cells_equal": 7, "national_cells_unpublished": 0, "max_abs_national_difference": 156, "state_cells_published": 1248, "state_cells_equal": 912} |
| record | reconciliation | 2026-09-30: hospital-row category counts compared with the CMS national and state files | recorded | {"national_cells_published": 0, "national_cells_equal": 0, "national_cells_unpublished": 24, "max_abs_national_difference": null, "state_cells_published": 0, "state_cells_equal": 0} |
| check | reconciliation | national and state file windows equal the hospital file windows in every release | passed | {"mismatching_reference_rows": 0} |
| check | reconstruction | 24 prespecified records reconstructed from raw CSV bytes with an independent parser | passed | {"records": 24, "matched": 24} |
| check | software_crosscheck | R reimplementation reproduces pair, point-ordered and R1-separated counts | passed | {"rows": 6, "r_version": "R version 4.5.1 (2025-06-13)"} |
| check | software_crosscheck | full rebuild and reanalysis from cached inputs reproduces all 24 outputs (tolerance 1e-12) | passed | {"tables": 24, "differing": []} |

## Table S11. Requested, numeric and compatible records by hospital type, primary release

Source: outputs/tables/compatible_by_hospital_type.csv. VA records are compared only among VA hospitals (Table S12).

| Measure | Hospital type | Requested | Numeric score | Compatible |
|---|---|---|---|---|
| AMI excess days | Acute Care - Department of Defense | 32 | 0 | 0 |
| AMI excess days | Acute Care - Veterans Administration | 132 | 69 | 0 |
| AMI excess days | Acute Care Hospitals | 3115 | 1482 | 1443 |
| AMI excess days | Childrens | 94 | 0 | 0 |
| AMI excess days | Critical Access Hospitals | 1378 | 2 | 2 |
| AMI excess days | Rural Emergency Hospital | 41 | 0 | 0 |
| HF excess days | Acute Care - Department of Defense | 32 | 0 | 0 |
| HF excess days | Acute Care - Veterans Administration | 132 | 117 | 0 |
| HF excess days | Acute Care Hospitals | 3115 | 2622 | 2563 |
| HF excess days | Childrens | 94 | 0 | 0 |
| HF excess days | Critical Access Hospitals | 1378 | 412 | 412 |
| HF excess days | Rural Emergency Hospital | 41 | 0 | 0 |
| AMI mortality | Acute Care - Department of Defense | 32 | 0 | 0 |
| AMI mortality | Acute Care - Veterans Administration | 132 | 81 | 0 |
| AMI mortality | Acute Care Hospitals | 3115 | 1859 | 1814 |
| AMI mortality | Childrens | 94 | 0 | 0 |
| AMI mortality | Critical Access Hospitals | 1378 | 12 | 12 |
| AMI mortality | Rural Emergency Hospital | 41 | 0 | 0 |
| HF mortality | Acute Care - Department of Defense | 32 | 0 | 0 |
| HF mortality | Acute Care - Veterans Administration | 132 | 117 | 0 |
| HF mortality | Acute Care Hospitals | 3115 | 2600 | 2541 |
| HF mortality | Childrens | 94 | 0 | 0 |
| HF mortality | Critical Access Hospitals | 1378 | 385 | 385 |
| HF mortality | Rural Emergency Hospital | 41 | 0 | 0 |
| AMI readmission | Acute Care - Department of Defense | 32 | 0 | 0 |
| AMI readmission | Acute Care - Veterans Administration | 132 | 80 | 0 |
| AMI readmission | Acute Care Hospitals | 3115 | 1740 | 1696 |
| AMI readmission | Childrens | 94 | 0 | 0 |
| AMI readmission | Critical Access Hospitals | 1378 | 3 | 3 |
| AMI readmission | Rural Emergency Hospital | 41 | 0 | 0 |
| HF readmission | Acute Care - Department of Defense | 32 | 0 | 0 |
| HF readmission | Acute Care - Veterans Administration | 132 | 117 | 0 |
| HF readmission | Acute Care Hospitals | 3115 | 2622 | 2563 |
| HF readmission | Childrens | 94 | 0 | 0 |
| HF readmission | Critical Access Hospitals | 1378 | 412 | 412 |
| HF readmission | Rural Emergency Hospital | 41 | 0 | 0 |

## Table S12. VA hospitals compared only with each other, primary release

Source: outputs/tables/separate_group_summary.csv. Records that passed every gate except G2b, paired within the same state; R1 rule. This descriptive comparison was added after Amendment 2 so that G2b was applied as written (analysis plan, note on the record of 11:27Z).

| Measure | VA records | States | States with 2 or more | Pairs | Point-ordered | Separated R1 | Not separated |
|---|---|---|---|---|---|---|---|
| AMI excess days | 69 | 38 | 17 | 62 | 62 | 23 | 62.9% |
| HF excess days | 117 | 49 | 30 | 156 | 155 | 89 | 42.6% |
| AMI mortality | 81 | 42 | 20 | 86 | 81 | 0 | 100.0% |
| HF mortality | 117 | 49 | 30 | 156 | 156 | 5 | 96.8% |
| AMI readmission | 80 | 43 | 19 | 75 | 71 | 0 | 100.0% |
| HF readmission | 117 | 49 | 30 | 156 | 152 | 0 | 100.0% |
