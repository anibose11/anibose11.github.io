# Notice

This file states the rights that apply to the material used by hospcomp. The MIT license in `LICENSE` applies only to the project's own code, as described in the last section.

## CMS Provider Data Catalog data

The hospital files analyzed here are published by the Centers for Medicare & Medicaid Services (CMS) in the Provider Data Catalog (https://data.cms.gov/provider-data/). They are U.S. federal government data published for public use. The catalog metadata saved under `data/raw/metastore/` records `accessLevel` as `public` and CMS as publisher for every dataset used:

| Dataset ID | Title |
|---|---|
| 632h-zaca | Unplanned Hospital Visits - Hospital |
| ynj2-r877 | Complications and Deaths - Hospital |
| xubh-q36u | Hospital General Information |
| y9us-9xdf | Footnote Crosswalk |
| 4j6d-yzce | Measure Dates |
| 9n3s-kdb3 | Hospital Readmissions Reduction Program |
| cvcs-xecj | Unplanned Hospital Visits - National |
| qqw3-t4ie | Complications and Deaths - National |
| 4gkm-5ypv | Unplanned Hospital Visits - State |
| bs2r-24vh | Complications and Deaths - State |

The archived releases dated 2026-05-13 and 2026-08-13 are the official hospital-theme archive snapshots of the same catalog (https://data.cms.gov/provider-data/api/1/archive/aggregate/theme/hospitals/relative).

The project asserts no license or other rights over these files or over values copied from them into the study database and output tables. CMS should be cited as the source. Download URLs, release dates, file versions and SHA-256 checksums for every file are recorded in `source_manifest.json`.

## Cited documents

The project cites the documents below by title and URL. It does not redistribute them. Local copies under `data/raw/documents/` are kept only to verify the citations and their checksums, and they are not covered by the project's license.

- QualityNet methodology reports and factsheet (Yale New Haven Health Services Corporation, Center for Outcomes Research and Evaluation, for CMS):
  - 2025 Condition-Specific Readmission Measures Updates and Specifications Report, in the archived measure methodology package https://qualitynet.cms.gov/files/6a0b7d2db58870567d25f40b?filename=2025_Rdmsn_MeasureMethodology.zip
  - 2026 Condition-Specific Readmission Measures Updates and Specifications Report, https://qualitynet.cms.gov/files/6a03778f0bc8b455c239e213?filename=2026_CSR_AUS_Report.pdf_v2.0
  - 2025 Condition-Specific Mortality Measures Updates and Specifications Report, https://qualitynet.cms.gov/files/67ff9f8575ffca0f7fb8d062?filename=2025_CSM_AUS_Report_v1.0.pdf
  - 2025 Condition-Specific EDAC Measures Updates and Specifications Report, https://qualitynet.cms.gov/files/6826495a662c6b68b52c49ba?filename=2025_EDAC_AUS_Report_.pdf
  - FAQ for Publicly Reported Claims-Based Outcome Measures, Summer 2026, https://qualitynet.cms.gov/files/69c59e5d4110de9e75d8df9e?filename=2026_CBM_FAQ.pdf
  - 2026 Mortality Measures Factsheet, https://qualitynet.cms.gov/files/69cd3521346406199a227137?filename=2026-MortMeasFactsheet.pdf
- Federal Register: FY 2026 IPPS/LTCH PPS final rule, 90 FR 36536, FR Doc. 2025-14681, 4 August 2025, https://www.govinfo.gov/content/pkg/FR-2025-08-04/html/2025-14681.htm
- CMS Hospital Downloadable Database Data Dictionary (July 2026), https://data.cms.gov/provider-data/sites/default/files/data_dictionaries/hospital/HOSPITAL_Data_Dictionary.pdf
- CMS listserve 2026-89-IP, Data Suppression for National Compare Values & Confidence Intervals (2026-09-18), https://www.qualityreportingcenter.com/globalassets/listserves/2026/iqr/2026-89-ip-508.pdf

## Third-party software

Python, R and the Python packages below keep their own licenses; the MIT license of this project does not change them. Licence names are as recorded in each installed package's metadata (read with `importlib.metadata`: the `License-Expression` field where present, otherwise the `License` field, otherwise the license classifier). Versions are those pinned in `requirements.lock`.

Direct dependencies (declared in `pyproject.toml`):

| Package | Version | Use | Licence (package metadata) |
|---|---|---|---|
| pandas | 3.0.6 | tables and summaries | BSD 3-Clause License |
| numpy | 2.5.3 | numerical arrays | BSD-3-Clause AND 0BSD AND MIT AND Zlib AND CC0-1.0 |
| requests | 2.34.2 | data acquisition | Apache-2.0 |
| openpyxl | 3.1.5 | spreadsheet workbook output | MIT |
| matplotlib | 3.11.2 | figures | Python Software Foundation License (classifier) |
| Jinja2 | 3.1.6 | report and page templates | BSD License (classifier) |
| Markdown | 3.11 | report rendering | BSD-3-Clause |
| python-docx | 1.2.0 | Word document output | MIT |
| pytest | 9.1.1 | tests (optional `test` extra) | MIT |
| pypdf | 6.19.0 | optional `docs` extra | BSD-3-Clause |

Packages installed as dependencies of the above:

| Package | Version | Licence (package metadata) |
|---|---|---|
| certifi | 2026.7.22 | MPL-2.0 |
| charset-normalizer | 3.5.2 | MIT |
| contourpy | 1.4.0 | BSD-3-Clause |
| cycler | 0.12.1 | BSD License (classifier) |
| et_xmlfile | 2.0.0 | MIT |
| fonttools | 4.66.1 | MIT |
| idna | 3.20 | BSD-3-Clause |
| iniconfig | 2.3.1 | MIT |
| kiwisolver | 1.5.1 | BSD License (classifier) |
| lxml | 6.1.3 | BSD-3-Clause |
| MarkupSafe | 3.0.4 | BSD-3-Clause |
| packaging | 26.3 | Apache-2.0 OR BSD-2-Clause |
| pillow | 12.3.0 | MIT-CMU |
| pluggy | 1.6.0 | MIT |
| Pygments | 2.21.0 | BSD-2-Clause |
| pyparsing | 3.3.3 | MIT |
| python-dateutil | 2.9.0.post0 | Dual License (BSD License and Apache Software License classifiers) |
| six | 1.17.0 | MIT |
| typing_extensions | 4.16.0 | PSF-2.0 |
| urllib3 | 2.8.0 | MIT |

Runtimes:

- Python 3.13.5, distributed under the Python Software Foundation License Version 2 (the `LICENSE.txt` of the installed Python distribution). The standard library modules used, including `sqlite3`, `csv` and `tomllib`, are part of that distribution.
- R 4.5.1, used only for the cross-check script `scripts/crosscheck_pairs.R` with base R and no add-on packages. R states that it may be redistributed under the terms of the GNU General Public License versions 2 or 3 (`R --version`).

## Scope of the project license

The MIT license in `LICENSE` (copyright 2026 Animesh Bose) covers only the project's own code: the Python package in `src/hospcomp/`, the SQL in `sql/`, the scripts in `scripts/`, and the tests and synthetic test fixtures in `tests/`. It does not cover the CMS data, the cited documents or any third-party software listed above.
