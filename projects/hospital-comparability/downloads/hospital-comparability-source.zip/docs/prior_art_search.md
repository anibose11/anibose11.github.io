# Prior-art and software search

Searches were run on 2026-10-07, before the `analyze` stage first ran. Every bibliographic record below was confirmed against PubMed E-utilities, Europe PMC or Crossref metadata, and each citation was re-checked independently a second time for authors, title, journal, year, volume, pages, DOI and PMID. Software was checked on its CRAN, PyPI or GitHub page on the same date.

## Databases and sources

- PubMed (E-utilities `esearch`, `esummary`, `efetch`)
- Europe PMC REST (search and full-text XML)
- Crossref REST (`/works`, bibliographic queries and DOI lookups)
- OpenAlex (abstracts where publisher pages were blocked)
- CRAN, PyPI JSON API and GitHub (software)
- Official CMS sources: Provider Data Catalog metastore and archive APIs, QualityNet methodology reports, the Federal Register (govinfo.gov), CMS listserves

## Inclusion rules

Included: peer-reviewed methods or empirical work on uncertainty in institutional rankings or league tables; work on the statistical properties of CMS hospital outcome measures; software that computes rank uncertainty or ingests CMS provider data. Excluded: commentary without methods or data, work on process-of-care measures unless it addresses rank uncertainty directly (PMC4195008 was included because it measures rank uncertainty by hospital size in CMS pay-for-performance data), and items that could not be retrieved at least at abstract level.

The seven closest items are summarized in `docs/prior_art.csv`. Access level (full text, abstract only, software documentation) is recorded there and in the manuscript's reference notes.

## Closest items and why

1. Klein, Wright and Wieczorek 2020: the deterministic rank-range counting rule used here.
2. Mogstad, Romano, Shaikh and Wilhelm 2024 and the `csranks` package: proper simultaneous confidence sets for ranks, which need standard errors and a joint distribution that CMS does not publish.
3. Goldstein and Spiegelhalter 1996: the share of pairwise comparisons that cannot be separated in league tables.
4. Marshall and Spiegelhalter 1998: rank intervals derived from published adjusted rates and intervals by simulation.
5. Glance et al. 2021: contemporary reproducibility of CMS hospital rankings, including the HF measures, across reporting periods whose windows overlap.
6. Davidson, Moscovice and Remus 2007 (PMC4195008): rank uncertainty by hospital size.
7. The `readmit` R package: the closest CMS Provider Data Catalog ingestion tool.

## Other verified references used in the manuscript

Ash et al. 2012 (COPSS-CMS white paper); Silber et al. 2010; Schenker and Gentleman 2001; Spiegelhalter 2005; Lingsma et al. 2010; van Dishoeck et al. 2011; Dimick, Staiger and Birkmeyer 2010; Thompson et al. 2016; Bernheim et al. 2010; Krumholz et al. 2006 (two papers); Keenan et al. 2008; Horwitz et al. 2018; Wadhera et al. 2021; Shen, Wadhera and Yeh 2021; Glance, Li and Dick 2017; Austin et al. 2015; Wright, Klein and Wieczorek 2019; Hofstede et al. 2019; Benchimol et al. 2015 (RECORD).

## Software checked

`csranks` (CRAN 1.3.0, GPL-3; needs estimates and a covariance matrix), `ICRanks` (archived on CRAN 2026-01-16; needs known standard deviations), `RankingProject` (CRAN 0.4.0, GPL-2; needs standard errors), `FunnelPlotR` (CRAN 0.6.0, MIT; needs observed and expected counts), `readmit` (CRAN 0.0.1, MIT; imports the live catalog file without release pinning or footnote handling), `asacarny/hospital-compare` (Stata, last updated 2018, drops intervals and footnotes), `provider` (GitHub development version; does not cover the outcome datasets). No package was found that combines release pinning, source-preserving parsing, definitional gates and interval-based rank assessment.

## Search log

| Topic | Database | Query | Date | Hits | Notes |
|---|---|---|---|---|---|
| cms-public-reporting | PubMed (E-utilities esearch) | Krumholz HM[au] AND administrative claims model 30-day mortality myocardial infarction AND Circulation[ta] AND 2006[dp] | 2026-10-07 | 1 | PMID 16549637 |
| cms-public-reporting | PubMed (E-utilities esearch) | Krumholz HM[au] AND administrative claims model 30-day mortality heart failure AND Circulation[ta] AND 2006[dp] | 2026-10-07 | 1 | PMID 16549636 |
| cms-public-reporting | PubMed (E-utilities esearch) | Keenan PS[au] AND 30-day all-cause readmission heart failure administrative claims measure | 2026-10-07 | 1 | PMID 20031785 |
| cms-public-reporting | PubMed (E-utilities esearch) | Krumholz HM[au] AND administrative claims measure 30-day all-cause readmission acute myocardial infarction AND 2011[dp] | 2026-10-07 | 1 | PMID 21406673 |
| cms-public-reporting | PubMed (E-utilities esearch) | Silber JH[au] AND Hospital Compare mortality model volume-outcome relationship | 2026-10-07 | 1 | PMID 20579125 |
| cms-public-reporting | PubMed (E-utilities esearch) | Austin JM[au] AND Jha AK[au] AND national hospital ratings systems | 2026-10-07 | 1 | PMID 25732492 |
| cms-public-reporting | PubMed (E-utilities esearch) | Horwitz LI[au] AND excess days in acute care | 2026-10-07 | 1 | PMID 29462075 |
| cms-public-reporting | PubMed (E-utilities esearch) | "excess days in acute care" | 2026-10-07 | 1 | PMID 41076536 (readmission disparity measure, not selected) |
| cms-public-reporting | PubMed (E-utilities esearch) | "Hospital Compare" AND (outlier* OR "no different" OR "better than" OR "worse than") AND (mortality OR readmission) AND national | 2026-10-07 | 8 | Yielded Glance 2021 (34874402) and Meddings 2018; others off-topic |
| cms-public-reporting | PubMed (E-utilities esearch) | Krumholz HM[au] AND patterns of hospital performance acute myocardial infarction heart failure 30-day mortality readmission | 2026-10-07 | 2 | PMIDs 20031870 (Krumholz 2009) and 20736442 (Bernheim 2010) |
| cms-public-reporting | PubMed (E-utilities esearch) | statistical issues in assessing hospital performance | 2026-10-07 | 4320 | Unfielded query too broad; COPSS white paper is not PubMed-indexed |
| cms-public-reporting | PubMed (E-utilities esearch) | "days in acute care" AND (heart failure OR myocardial infarction OR pneumonia) AND (observation OR emergency department) AND readmission | 2026-10-07 | 0 |  |
| cms-public-reporting | PubMed (E-utilities esearch) | "Hospital Compare" AND (shrinkage OR "small hospitals" OR "low-volume" OR "hierarchical") AND (mortality OR readmission) | 2026-10-07 | 13 | Included Silber 2010 and Joynt 2016; others not selected |
| cms-public-reporting | PubMed (E-utilities esearch) | "Hospital Compare" AND (rank* OR ranking*) AND (uncertainty OR "confidence interval*" OR reliability) | 2026-10-07 | 8 | Glance 2021 again; Hu 2017 correlations among measures not selected |
| cms-public-reporting | PubMed (E-utilities esearch) | Bilimoria KY[au] AND "Hospital Compare" | 2026-10-07 | 8 | No Bilimoria paper on CMS outcome-measure categorization found (VTE surveillance bias, malpractice, HAC, NSQIP topics) |
| cms-public-reporting | PubMed (E-utilities esearch) | Hofer TP[au] AND (hospital mortality OR report cards) AND (reliab* OR detect*) | 2026-10-07 | 10 | Hofer and Hayward 1996 abstract read (not in final list) |
| cms-public-reporting | PubMed (E-utilities esearch) | (hospital ratings OR hospital rating systems) AND (agreement OR concordance OR "share few") AND (star ratings OR Leapfrog OR "US News") | 2026-10-07 | 34 | First attempt failed on rate limit; rerun returned 34; titles not screened further beyond Austin 2015 |
| cms-public-reporting | PubMed (E-utilities esearch) | Marshall EC[au] AND Spiegelhalter DJ[au] AND league tables | 2026-10-07 | 1 | PMID 9614016 |
| cms-public-reporting | PubMed (E-utilities esearch) | Dimick JB[au] AND ranking hospitals surgical mortality reliability adjustment | 2026-10-07 | 6 | Dimick 2010 HSR identified, not read |
| cms-public-reporting | PubMed (E-utilities esearch) | (hospital*[ti]) AND (rank*[ti]) AND (uncertainty[ti] OR "confidence intervals"[ti] OR league[ti]) | 2026-10-07 | 4 | Feudtner 2011 Pediatrics identified, not read |
| cms-public-reporting | PubMed (E-utilities esearch) | "Hospital Compare" AND (heart failure) AND (readmission OR mortality) AND (classif* OR categor*) AND (national rate) | 2026-10-07 | 3 | Glance 2021, Pollock 2020, Missios 2016 |
| cms-public-reporting | PubMed (E-utilities esearch) | Joynt KE[au] AND "Hospital Compare" | 2026-10-07 | 1 | Joynt 2016 Ann Intern Med; full text retrieved but not central |
| cms-public-reporting | PubMed (E-utilities esearch) | Krumholz HM[au] AND (hospital performance) AND (outlier OR "better than" OR "worse than") AND (Medicare) AND (mortality OR readmission) | 2026-10-07 | 2 | Krumholz 2019 JAMA Netw Open; Ross 2012 Health Aff; not selected |
| cms-public-reporting | Europe PMC REST search | "excess days in acute care" | 2026-10-07 | 30 | Yielded Wadhera 2021 Ann Intern Med, Shen 2021 JAMA Cardiol, Horwitz 2018, Sabbatini 2023 |
| cms-public-reporting | Europe PMC REST search | "Statistical issues in assessing hospital performance" | 2026-10-07 | 2 | Only citing papers; white paper itself not indexed |
| cms-public-reporting | Web search (general engine) | COPSS-CMS white paper "Statistical Issues in Assessing Hospital Performance" Ash Fienberg Louis Normand Stukel Utts 2012 | 2026-10-07 | 9 result links | Located CMS-hosted PDF; full text read |
| cms-public-reporting | Crossref works API | query.bibliographic=Statistical issues in assessing hospital performance Ash Fienberg Louis | 2026-10-07 | 4735586 (relevance-ranked; top 5 screened) | Top hit Normand et al. 2016 Annu Rev Stat Appl 3:21-50 'League Tables for Hospital Comparisons' (abstract read via Crossref; not in final list) |
| ranking-uncertainty | Europe PMC REST (search) | PMCID:PMC4195008 (resultType=core) | 2026-10-07 | 1 | Resolved to PMID 18624079, Davidson, Moscovice, Remus 2007, Health Care Financ Rev 29(1):45-57. |
| ranking-uncertainty | Europe PMC REST (fullTextXML) | PMC4195008/fullTextXML | 2026-10-07 | 1 full text (78,364 bytes XML) | Full text read in full, including Tables 2 to 6 and discussion. |
| ranking-uncertainty | Crossref API (query.bibliographic) | League tables and their limitations statistical issues in comparisons of institutional performance | 2026-10-07 | 3,914,778 total-results (relevance-ranked fuzzy match; not a precision count) | Top hit 10.2307/2983325, JRSS A 159(3), 1996. An earlier identical query with author names returned a non-JSON response and was retried. |
| ranking-uncertainty | Crossref API (query.bibliographic) | Klein Wright Wieczorek joint confidence region for an overall ranking of populations | 2026-10-07 | 1,966,024 total-results (relevance-ranked) | Top hit 10.1111/rssc.12402 (JRSS C 69(3):589-606); also surfaced Wright 2025 Stat Probab Lett 217:110288, Wright/Klein/Wieczorek 2019 Am Stat primer, and CRAN RankingProject. |
| ranking-uncertainty | Crossref API (query.bibliographic) | Mogstad Romano Shaikh Wilhelm inference for ranks with applications to mobility across neighbourhoods and academic achievement across countries | 2026-10-07 | 466,165 total-results (relevance-ranked) | Hits include 10.1093/restud/rdad006 (Rev Econ Stud 91(1):476-518) and NBER 10.3386/w26883. |
| ranking-uncertainty | Crossref API (query.bibliographic) | Schenker Gentleman On judging the significance of differences by examining the overlap between confidence intervals | 2026-10-07 | 106,455 total-results (relevance-ranked) | Top hit 10.1198/000313001317097960 (Am Stat 55(3):182-186); also Payton, Greenstone, Schenker 2003 J Insect Sci. |
| ranking-uncertainty | Crossref API (query.bibliographic) | Ranking hospitals on surgical mortality: the importance of reliability adjustment Dimick Staiger | 2026-10-07 | 1,878,442 total-results (relevance-ranked) | Top hit 10.1111/j.1475-6773.2010.01158.x. |
| ranking-uncertainty | Crossref API (query.bibliographic) | Funnel plots for comparing institutional performance Spiegelhalter | 2026-10-07 | not returned (non-JSON response) | Located instead via PubMed. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Marshall EC[au] AND Spiegelhalter DJ[au] AND league tables | 2026-10-07 | 1 | PMID 9614016. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Spiegelhalter DJ[au] AND funnel plots[ti] | 2026-10-07 | 2 | PMID 15568194 used; 25123852 (Rakow et al. 2015) not relevant. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Lingsma HF[au] AND rankability | 2026-10-07 | 9 | Included 21642443, 29789406, 19607709, 23338243, 31242857 and others; Netherlands Stroke Survey paper not among them. |
| ranking-uncertainty | PubMed (E-utilities esearch) | van Dishoeck AM[au] AND rankability | 2026-10-07 | 2 | 21642443 (BMJ Qual Saf 2011) and 23338243 (Br J Surg 2013). |
| ranking-uncertainty | PubMed (E-utilities esearch) | Dimick JB[au] AND Staiger DO[au] AND reliability adjustment AND ranking | 2026-10-07 | 3 | 20722747 used; 23235395 and 24783994 not read. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Davidson G[au] AND Moscovice I[au] AND pay-for-performance | 2026-10-07 | 1 | 18624079 (confirms PMC4195008). |
| ranking-uncertainty | PubMed (E-utilities esearch) | comparing and ranking hospitals based on outcome Netherlands Stroke Survey | 2026-10-07 | 3 | 20008321 relevant; two GBD papers not relevant. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Lingsma HF[au] AND Netherlands Stroke Survey AND ranking | 2026-10-07 | 1 | 20008321. First two attempts hit the NCBI rate limit and were retried. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Goldstein H[au] AND Spiegelhalter DJ[au] | 2026-10-07 | 0 | JRSS A 1996 paper not indexed in PubMed; found via Crossref and web search. |
| ranking-uncertainty | PubMed (E-utilities esearch) | hospital ranking uncertainty confidence intervals ranks Medicare Hospital Compare | 2026-10-07 | 0 |  |
| ranking-uncertainty | PubMed (E-utilities esearch) | (rank confidence interval* OR "uncertainty in rank*") AND hospital*[tiab] AND (league table* OR ranking*) | 2026-10-07 | 133 | Top 20 titles screened via Europe PMC; none relevant (mostly network meta-analyses and decision-analysis papers). Low precision query. |
| ranking-uncertainty | PubMed (E-utilities esearch) | "Hospital Compare"[tiab] AND (rank*[tiab]) AND (uncertainty[tiab] OR "confidence interval*"[tiab] OR reliability[tiab]) | 2026-10-07 | 6 | 34874402 (Glance et al. 2021) selected; 18665057 (Shwartz 2008 composite) and others not selected. |
| ranking-uncertainty | PubMed (E-utilities esearch) | reliability AND readmission AND "Hospital Readmissions Reduction Program" AND Thompson MP[au] | 2026-10-07 | 0 | Phrase did not match title wording. |
| ranking-uncertainty | PubMed (E-utilities esearch) | Thompson MP[au] AND readmission AND reliability | 2026-10-07 | 2 | 27766634 (HSR 2016) selected; 34689581 (TAVR center variability) not selected. |
| ranking-uncertainty | PubMed (E-utilities esearch) | "overlapping confidence intervals"[tiab] AND (significance[tiab] OR comparison*[tiab]) | 2026-10-07 | not obtained (NCBI rate-limit error; the 'count 4' in the error body is the request count, not a hit count) | Replaced by the Europe PMC title search below. |
| ranking-uncertainty | Europe PMC REST (search) | TITLE:"overlapping confidence intervals" | 2026-10-07 | 9 | Austin and Hux 2002 J Vasc Surg (abstract read, not included) and Payton et al. 2003 J Insect Sci (not read). |
| ranking-uncertainty | Europe PMC REST (search, core) | EXT_ID lookups for 15568194, 21642443, 9614016, 20008321, 20722747, 27766634, 12096281, 23338243, 19607709, 29789406 | 2026-10-07 | 1 record each | Abstracts and bibliographic details retrieved. |
| ranking-uncertainty | NCBI BioC API / efetch db=pmc / Europe PMC fullTextXML | PMC2976775, PMC28567, PMC2810392, PMC5134200, PMC8652605 | 2026-10-07 | full text retrieved for PMC2976775 (BioC) and PMC8652605 (Europe PMC); PMC28567, PMC2810392 and PMC5134200 returned front matter only | PMC28567, PMC2810392 and PMC5134200 read on the PMC article web pages, with verbatim sentence extraction for key numbers. |
| ranking-uncertainty | arXiv API | ti:joint AND ti:confidence AND ti:region AND ti:ranking | 2026-10-07 | 0 | Klein et al. not on arXiv; Census-hosted PDF used. |
| ranking-uncertainty | Web search (general engine) | Klein Wright Wieczorek "joint confidence region for an overall ranking of populations" pdf | 2026-10-07 | 10 results | Census Bureau PDF of the published article; related Census working papers RRS2024-01 and RRS2024-03 (not read). |
| ranking-uncertainty | Web search (general engine) | Mogstad Romano Shaikh Wilhelm "Inference for Ranks" Review of Economic Studies 2024 confidence sets for ranks | 2026-10-07 | 10 results | IDEAS page for NBER w26883 confirming Rev Econ Stud 91(1):476-518 (2024); NBER PDF downloaded and read. |
| ranking-uncertainty | Web search (general engine) | Goldstein Spiegelhalter 1996 "League tables and their limitations" abstract Journal of the Royal Statistical Society Series A 159 385 | 2026-10-07 | 9 results | University of Bristol CMM author manuscript PDF downloaded and read. |
| ranking-uncertainty | Web search (general engine) | Schenker Gentleman 2001 "On judging the significance of differences by examining the overlap between confidence intervals" abstract overlap method conservative | 2026-10-07 | 10 results | Publisher page 403; abstract obtained from OpenAlex. |
| ranking-uncertainty | OpenAlex API | works/doi: 10.1198/000313001317097960; 10.2307/2983325; 10.1002/sim.1970; 10.1136/bmjqs.2010.048058; 10.1080/00031305.2017.1392359; 10.1093/restud/rdad006; 10.1111/rssc.12402 | 2026-10-07 | 1 record each | Abstracts reconstructed from inverted index; bibliographic volume/issue/pages confirmed. |
| software-tools | CRAN (package page fetch via curl) | https://cran.r-project.org/web/packages/csranks/index.html | 2026-10-07 | 1 (csranks 1.3.0, published 2026-08-21) |  |
| software-tools | PyPI JSON API | pypi.org/pypi/{csranks, cs-ranks, pycsranks, rankability}/json | 2026-10-07 | 0 (all returned 404 Not Found) |  |
| software-tools | GitHub REST API | users/danielwilhelm/repos and repos/danielwilhelm/R-CS-ranks | 2026-10-07 | 8 repositories; R-CS-ranks GPL-3.0, pushed 2026-08-18 |  |
| software-tools | Web search | csranks python package confidence sets for ranks | 2026-10-07 | 9 results, all CRAN mirrors of the R package; no Python port | Confirms R-only |
| software-tools | pkgdown site (project web page) | https://danielwilhelm.github.io/R-CS-ranks/reference/csranks.html | 2026-10-07 | 1 reference page (function signature and Sigma requirement) |  |
| software-tools | CRAN (package page, reference manual, vignette) | RankingProject index.html, refman/RankingProject.html, vignettes/intro.html | 2026-10-07 | 1 package (0.4.0, 2022-01-28) | vignettes/RankingProject.html returned 404; correct file is intro.html |
| software-tools | CRAN and pkgdown | FunnelPlotR index.html and nhs-r-community.github.io/FunnelPlotR/reference/funnel_plot.html | 2026-10-07 | 1 package (0.6.0, 2025-07-23) |  |
| software-tools | CMS Provider Data Catalog metastore API | api/1/metastore/schemas/dataset/items (full catalog) filtered for footnote, dictionary, unplanned, complications, readmission, hospital general | 2026-10-07 | 237 datasets in catalog; 15 matched filter |  |
| software-tools | CMS Provider Data Catalog datastore API | datastore/query/ynj2-r877/0 with measure_id = MORT_30_HF | 2026-10-07 | 4,790 rows |  |
| software-tools | CMS Provider Data Catalog CSV downloads | Complications_and_Deaths-Hospital.csv, Unplanned_Hospital_Visits-Hospital.csv, both National files, Footnote_Crosswalk.csv, FY_2026_Hospital_Readmissions_Reduction_Program_Hospital.csv | 2026-10-07 | 6 files; hospital files 95,800 and 67,060 rows | First downloads were truncated; re-downloaded until byte size matched Content-Length (22,813,123 and 18,945,811 bytes) |
| software-tools | Web search (extended) | Care Compare hospital readmission mortality "compared to national" not available 2026 refresh interval estimates | 2026-10-07 | 10 results, none documenting the 2026 suppression |  |
| software-tools | Web search | data.cms.gov provider-data hospital data dictionary PDF "Compared to National" "Lower Estimate" "Higher Estimate" | 2026-10-07 | 9 results, no direct dictionary link |  |
| software-tools | CMS Provider Data Catalog (direct URL probe) | provider-data/sites/default/files/data_dictionaries/hospital/HOSPITAL_Data_Dictionary.pdf | 2026-10-07 | 1 PDF (HTTP 200, 100 pages, titled July 2026, server last-modified 2026-09-30) |  |
| software-tools | Medicare.gov and QualityNet (web pages) | medicare.gov/care-compare/resources/hospital/complications-and-deaths; qualitynet.cms.gov/inpatient/measures/readmission/methodology | 2026-10-07 | 0 readable (JavaScript-rendered pages) |  |
| software-tools | Web search | medicare.gov care-compare resources hospital "interval estimate" national rate better worse "no different" | 2026-10-07 | 9 results, secondary sources only |  |
| software-tools | Web search | CMS Care Compare 2026 hospital mortality readmission measures "compared to national" categories removed OR suppressed OR "not displayed" interval estimates | 2026-10-07 | 9 results; led to July 2026 data refresh listserve PDF |  |
| software-tools | Web search (extended) | qualityreportingcenter.com listserves 2026 "Hospital Quality Public Reporting Data Refresh" September OR October 2026 | 2026-10-07 | 10 results; led to IQR 2026 listserve index |  |
| software-tools | QualityReportingCenter IQR listserve index (web page) | listserves/2026/ notices dated 2026-08-01 or later | 2026-10-07 | 28 notices; 2026-89-IP (suppression of national compare values and confidence intervals) identified and read in full, with 2026-90-IP and 2026-70-IP |  |
| software-tools | CMS Provider Data Catalog (archive URL probes) | provider-data/archived-data/hospitals and sites/default/files/archive/Hospitals/{2024,2025,2026}/hospitals_MM_YYYY.zip | 2026-10-07 | 0 (HTTP 404 for guessed paths; archive location not verified) |  |
| software-tools | GitHub search API | "provider data catalog" cms | 2026-10-07 | 7 repositories (small personal projects) |  |
| software-tools | GitHub REST API | users/andrewallenbruce/repos (filtered for provider, cms, compare, medicare, hospital) | 2026-10-07 | 13 repositories; provider and providertwo inspected |  |
| software-tools | Web search | pypi python package CMS Provider Data Catalog API hospital Care Compare download datasets | 2026-10-07 | 9 results (pdt, Apify scrapers, an MCP listing) | pdt 0.8.2.8 (2020) is NPPES-focused; excluded |
| software-tools | GitHub search API | hospital compare in:name,description (sorted by stars) | 2026-10-07 | 542 total; top 10 reviewed; asacarny/hospital-compare selected |  |
| software-tools | GitHub search API | care compare cms in:description | 2026-10-07 | 7 repositories (klocey/stars-data-builder reviewed, not selected) |  |
| software-tools | GitHub search API | data.cms.gov provider-data | 2026-10-07 | 5 repositories |  |
| software-tools | GitHub search API | hospital quality cms api python | 2026-10-07 | 2 repositories |  |
| software-tools | GitHub search API | rankability; "rankability" in:name,description,readme | 2026-10-07 | 48,820 and 1,175,265 (stemmed to 'rank'; no relevant results) |  |
| software-tools | Web search (extended) | "rankability" hospital R package OR code implementation Lingsma van Houwelingen between-hospital variance | 2026-10-07 | 10 results; pointed to ICRanks and to code in a thesis appendix |  |
| software-tools | CRAN (package page and archive) | ICRanks index.html and src/contrib/Archive/ICRanks/ | 2026-10-07 | 1 package, archived 2026-01-16; 8 archived versions; 3.2 tarball read |  |
| software-tools | PyPI JSON API | pyrankability; rankability-toolbox | 2026-10-07 | 1 (pyrankability 0.1.4, 2022; sports-ranking concept, excluded) and 0 |  |
| software-tools | CRAN package title index | available_packages_by_name.html filtered for rankab, rank plus confidence/uncertain/hospital/provider/institution/inference, funnel, league, hospital, medicare, cms | 2026-10-07 | 25,348 packages scanned; 31 title matches (including readmit, medicare, pprof, funnelR, controlcharts) |  |
| software-tools | CRAN (package pages) | pprof, readmit, medicare index pages; readmit 0.0.1 tarball source | 2026-10-07 | 3 packages; readmit selected; pprof (patient-level models) and medicare (cost reports, POS files) excluded |  |
| software-tools | Web search | "rankability" R function package CRAN OR GitHub provider profiling reliability tau2 hospital rankings software | 2026-10-07 | about 30 results over three result sets; no dedicated rankability package found |  |