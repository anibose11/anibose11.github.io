# Data dictionary

This dictionary traces every CMS source column the study uses from the raw release file to the frozen SQLite database `data/interim/hospcomp.sqlite` and on to the output tables in `outputs/tables/`. It also defines each derived table column by column, lists the key and join cardinality checks, and states how the project tells apart a zero, an absent row, a suppressed value, an unavailable value, an inapplicable value and a quantity that was not evaluated.

Parsing code: `src/hospcomp/parse.py` (value parsers) and `src/hospcomp/build.py` (file loading and checks). Schema: `sql/01_schema.sql`. Gates: `sql/02_gates.sql`. Pairs and rank ranges: `sql/03_pairs_ranks.sql`. Comparisons among records excluded by G2b: `sql/04_population_groups.sql`. Summaries: `src/hospcomp/analyze.py`. Example values below were read from the study database; the current run ID is recorded in `outputs/run_manifest.json`.

## Releases in the database

| release_key | Role | Source | Interval status | Basis |
|---|---|---|---|---|
| 2026-05-13 | primary | official archive snapshot (April 2026 refresh) | published | latest release with published intervals not covered by a CMS correction or suppression notice |
| 2026-08-13 | flagged | official archive (July 2026 refresh) | flagged_by_cms_notice | CMS listserve 2026-89-IP, sent 2026-09-18 |
| 2026-09-30 | current | live catalog files | suppressed_by_cms_notice | same notice; interval limits and national categories read "Not Available" |

Every table that depends on a release carries `release_key`. Each release has its own hospital list, footnote crosswalk, Measure Dates table and reference aggregates, so no attribute is joined across releases.

## Source files

Row counts are data rows (header excluded) as recorded in `source_manifest.json` and checked by the build.

| dataset_key | Catalog title (dataset ID) | File | 2026-05-13 | 2026-08-13 | 2026-09-30 |
|---|---|---|---|---|---|
| unplanned_visits | Unplanned Hospital Visits - Hospital (632h-zaca) | Unplanned_Hospital_Visits-Hospital.csv | 67,088 | 67,060 | 67,060 |
| complications_deaths | Complications and Deaths - Hospital (ynj2-r877) | Complications_and_Deaths-Hospital.csv | 95,840 | 95,800 | 95,800 |
| general_info | Hospital General Information (xubh-q36u) | Hospital_General_Information.csv | 5,432 | 5,419 | 5,419 |
| footnotes | Footnote Crosswalk (y9us-9xdf) | Footnote_Crosswalk.csv | 32 | 32 | 32 |
| measure_dates | Measure Dates (4j6d-yzce) | Measure_Dates.csv | 172 | 171 | 171 |
| hrrp | Hospital Readmissions Reduction Program (9n3s-kdb3) | FY_2026_Hospital_Readmissions_Reduction_Program_Hospital.csv | 18,330 | 18,330 | 18,330 |
| unplanned_national | Unplanned Hospital Visits - National (cvcs-xecj) | Unplanned_Hospital_Visits-National.csv | 14 | 14 | 14 |
| complications_national | Complications and Deaths - National (qqw3-t4ie) | Complications_and_Deaths-National.csv | 20 | 20 | 20 |
| unplanned_state | Unplanned Hospital Visits - State (4gkm-5ypv) | Unplanned_Hospital_Visits-State.csv | 784 | 784 | 784 |
| complications_state | Complications and Deaths - State (bs2r-24vh) | Complications_and_Deaths-State.csv | 1,120 | 1,120 | 1,120 |

Archived releases are read from the members of the official archive ZIP files (`data/raw/archives/<archive_key>/members/`); the current release is read from `data/raw/<dataset_key>/`. In the live catalog on the build date, the Footnote Crosswalk, Hospital General Information, Measure Dates and HRRP datasets carried a release date of 2026-08-13, and their files have the same SHA-256 as the corresponding members of the 2026-08-13 archive. The 2026-09-30 release key therefore pairs the 2026-09-30 outcome, national and state files with those four dictionary and reference files. The HRRP file has the same SHA-256 in all three releases. Column headers are identical across the three releases for every file.

## Parsing conventions

Every parsed field sits next to the exact source string it came from (`*_src`). Parsers never overwrite the source string.

**Numeric fields** (`parse_numeric`). The source string is trimmed and matched against `^[+-]?(\d+(\.\d*)?|\.\d+)$`. A match that is finite gives `*_num` (REAL) and state `numeric`; `*_decimals` is the count of digits after the decimal point (so `12` has 0 decimals and `17.9` has 1). Any other string gives `*_num` = NULL and a text state from the table below, matched case-insensitively after trimming.

| Trimmed source string | State label |
|---|---|
| (empty) | `blank` |
| `Not Available` | `not_available` |
| `Not Applicable` | `not_applicable` |
| `Too Few to Report` | `too_few_to_report` |
| `N/A` | `not_available_na` |
| `--` | `dash` |
| a number that is not finite | `non_finite` |
| any other text | `other_text` |

**Facility ID** (`normalize_facility_id`). Trimmed and upper-cased. An all-digit ID shorter than six characters is left-padded with zeros to restore zeros lost in spreadsheet round trips; IDs containing letters are never altered. Valid IDs match `^[0-9A-Z]{6}$`. In this run no ID needed padding (`facility_id_src` equals `facility_id` in all 488,648 records) and every ID is valid. 164 hospitals per release have IDs ending in a letter (132 Veterans Administration and 32 Department of Defense hospitals, for example `01014F` BIRMINGHAM VA MEDICAL CENTER and `02013F` 673rd Medical Group).

**Dates** (`parse_date`). `MM/DD/YYYY` becomes ISO `YYYY-MM-DD`; any other string or an impossible date becomes NULL. No record in this run has a NULL parsed date.

**Footnotes** (`parse_footnotes`). The source string is split on commas, semicolons and whitespace, duplicates are removed, numeric codes are sorted numerically and non-numeric codes (such as `*`, `**`, `a`) follow. The normalized list is stored comma separated in `footnote_codes` and one row per code in `record_footnotes`. `1, 29` becomes `1,29`.

**Availability state** (`availability_state`). `reported` when the score is numeric. For a non-numeric score, the first code found in the precedence order 19, 12, 7, 1, 4, 13, 5 sets the state; if none is present the state is `missing_unspecified`.

| Footnote | availability_state |
|---|---|
| 19 | `not_eligible_program` |
| 12 | `not_applicable_to_hospital` |
| 7 | `no_eligible_cases` |
| 1 | `too_few_cases` |
| 4 | `suppressed_by_cms` |
| 13 | `cannot_be_calculated` |
| 5 | `not_available_this_period` |

**CSV reading.** Files are read as UTF-8 with an optional byte order mark, with Python's `csv` module. Every field is kept as text until parsed.

## Value states: zero, absent, suppressed, unavailable, inapplicable, not evaluated

These six states are kept apart throughout. None of them is converted into another, and none is imputed.

| State | Meaning in this project | How it is stored | Where it occurs in this run |
|---|---|---|---|
| Zero | A measured count or value equal to 0. | The number 0 in a `*_num` field or a count column. | `sep_r1_count` = 0 for READM_30_HF in Arizona (1,299 point-ordered pairs, none separated); CMS state category cells such as `0` hospitals Worse for MORT_30_AMI in Arizona (2026-05-13); `numeric_score_without_usable_interval` = 0 in the primary release. |
| Absent | No row exists, or the source file has no such column. | No row; or NULL in a column whose source header is missing. | Hospitals in General Information with no row in the measure file: 640 in 2026-05-13 (635 Psychiatric and 5 Long-term hospitals for READM_30_HF) and 629 in the other two releases, reported as `absent_from_measure_file`. Columns `Number of Hospitals Fewer/Average/More/Too Small` do not exist in the Complications and Deaths national and state files, so `n_fewer`, `n_average`, `n_more`, `n_too_small` are NULL for those rows of `national_reference` (1,140 per release). Facility IDs present in one release and missing from another (12 and 10 between 2026-05-13 and the later releases, `facility_presence.csv`). |
| Suppressed | CMS withheld a value it would otherwise publish. | Release level: `releases.interval_status` = `suppressed_by_cms_notice`, gate G0 reason `release_intervals_suppressed_by_cms`. Record level: footnote 4 gives `suppressed_by_cms`. | In 2026-09-30 all 28,740 study-measure records have `lower_src` and `upper_src` = `Not Available` and `Compared to National` = `Not Available`, while 14,848 scores are numeric. Footnote 4 does not occur on any study-measure record. |
| Unavailable | A value is not shown, and CMS gives a reason such as too few cases, no eligible cases, program non-participation or no result for the period. | `*_state` = `not_available` (or `not_available_na` in HRRP), with the reason in `availability_state`. | Study-measure scores reading `Not Available`: 14,020 in 2026-05-13 and 13,892 in each later release. Reasons in 2026-05-13: `too_few_cases` 8,989; `not_available_this_period` 3,452; `not_eligible_program` 1,020; `no_eligible_cases` 559. |
| Inapplicable | CMS states that the field does not apply to this measure or hospital. | `*_state` = `not_applicable`; footnote 12 gives `not_applicable_to_hospital`. | National Rate and the Worse/Same/Better/Too Few cells for EDAC_30_HF and EDAC_30_AMI read `Not Applicable` (EDAC uses the Fewer/Average/More/Too Small cells). Denominator reads `Not Applicable` in 14,372 Complications and Deaths records of non-study measures (4,792 in 2026-05-13 and 4,790 in each later release). Footnote 12 does not occur on any study-measure record. |
| Not evaluated | The project did not compute the quantity for that row. | No row in the derived table. | No pairs, pair summaries, hospital-level shares or rank ranges exist for 2026-08-13 or 2026-09-30, because every record there fails G0 first. Universes with one compatible hospital (GU and MP for every study measure, plus VT for EDAC_30_AMI) have rank-range rows (n = 1) but no pairs and no `hospital_level` rows. HRRP look-alike records are loaded but never gated, paired or ranked. |

An empty cell in an output CSV means NULL or a blank source string; the two are distinguished only in the SQLite database (for example, `footnote_src` is the empty string, never NULL, for the 43,451 study-measure records with no footnote). An absent row must never be read as a zero. For example, an empty pair summary for the current release means "not evaluated", and it does not mean that zero pairs were separated.

## Source to analysis: hospital outcome files

Applies to Unplanned Hospital Visits - Hospital and Complications and Deaths - Hospital. Both files load into `records`, one row per release x dataset x Facility ID x Measure ID, for all 14 and 20 measure IDs in the two files (162,928 records in 2026-05-13 and 162,860 in each later release). Gates are applied only to the six study measures (86,232 records across the three releases).

| Source field | Example raw values seen | Parsed field(s) in `records` | Parsing rule | States distinguished |
|---|---|---|---|---|
| Facility ID | `010001`, `020001`, `01014F` | `facility_id_src`, `facility_id`, `facility_id_valid` | normalize_facility_id; `facility_id_valid` = 1 when the ID matches `^[0-9A-Z]{6}$` and State matches `^[A-Z]{2}$` | valid or invalid; never blank in this run |
| Facility Name | `SOUTHEAST HEALTH MEDICAL CENTER` | `facility_name` | stored as given | text |
| State | `AL`, `AZ`, `DC`, `PR`, `GU`, `MP` (56 codes) | `state` | trimmed | text |
| Measure ID | `READM_30_HF`, `MORT_30_HF`, `EDAC_30_HF` | `measure_id` | trimmed | text |
| Measure Name | `Heart failure (HF) 30-Day Readmission Rate`, `Death rate for heart failure patients`, `Hospital return days for heart failure patients` | `measure_name_src`; feeds `measure_windows.source_measure_name` and `n_source_names` | stored as given; gate G2 requires one distinct name per Measure ID per release | text |
| Compared to National | `No Different Than the National Rate`, `Better Than the National Rate`, `Worse Than the National Rate`, `Number of Cases Too Small`, `Average Days per 100 Discharges`, `Fewer Days Than Average per 100 Discharges`, `More Days Than Average per 100 Discharges`, `Not Available` | `compared_to_national_src`; mapped to `official_category` in `compat_oriented` | stored as given; mapping in `sql/03_pairs_ranks.sql` | category text; `Not Available` |
| Denominator | `473`, `25`, `3486`, `Not Available`, `Not Applicable` | `denominator_src`, `denominator_num`, `denominator_state` | parse_numeric | numeric, not_available; not_applicable occurs only on non-study measures |
| Score | `17.9`, `12`, `-1.7`, `Not Available` | `score_src`, `score_num`, `score_state`, `score_decimals` | parse_numeric | numeric, not_available |
| Lower Estimate | `15.5`, `-12.1`, `Not Available` | `lower_src`, `lower_num`, `lower_state`, `lower_decimals` | parse_numeric | numeric, not_available |
| Higher Estimate | `20.7`, `8.9`, `Not Available` | `upper_src`, `upper_num`, `upper_state`, `upper_decimals` | parse_numeric | numeric, not_available |
| Footnote | (empty), `1`, `5`, `7`, `19`, `28`, `29`, `23`, `1, 29`, `1, 28` | `footnote_src`, `footnote_codes`; `record_footnotes` | parse_footnotes; classes from `footnote_dictionary` | blank, one code, several codes |
| Start Date | `07/01/2021`, `07/01/2022`, `07/01/2023` | `start_date_src`, `start_date` | parse_date | ISO date |
| End Date | `06/30/2024`, `06/30/2025` | `end_date_src`, `end_date` | parse_date | ISO date |
| (derived) | `reported`, `too_few_cases` | `availability_state` | availability_state | nine possible states: `reported`, the seven footnote states above and `missing_unspecified`; five occur on study measures in this run |
| (join to General Information) | `Acute Care Hospitals` | `hospital_type`, `in_general_info` | same-release lookup by `facility_id` | present in every record (`in_general_info` = 1 for all 488,648) |
| (provenance) | see the note below the table | `record_id`, `release_key`, `dataset_key`, `release_date`, `file_version`, `source_row`, `source_row_sha256` | see the note below the table | text |

Provenance fields: `record_id` joins release key, dataset key, Facility ID and Measure ID with a vertical bar (for example `2026-05-13`, `unplanned_visits`, `020001`, `READM_30_HF`). `source_row` is the 1-based data row in the raw CSV. `source_row_sha256` is the SHA-256 of the row's fields joined by the unit separator character (0x1F). `file_version` is the catalog distribution version for the live release and the ZIP member timestamp for an archived release; `release_date` is the release date of the file.

Not loaded: Address, City/Town, ZIP Code, County/Parish, Telephone Number, and the Unplanned Hospital Visits columns Number of Patients and Number of Patients Returned.

Parsed states for the six study measures:

| Release | Score numeric | Score not_available | Limits numeric | Limits not_available | Denominator numeric | Denominator not_available |
|---|---|---|---|---|---|---|
| 2026-05-13 | 14,732 | 14,020 | 14,732 | 14,020 | 14,732 | 14,020 |
| 2026-08-13 | 14,848 | 13,892 | 14,848 | 13,892 | 14,848 | 13,892 |
| 2026-09-30 | 14,848 | 13,892 | 0 | 28,740 | 14,848 | 13,892 |

No study-measure score, limit or denominator is blank, `other_text` or `too_few_to_report` in any release; `validation_report.json` checks that study-measure scores are only `numeric` or `not_available`. Scores are published with at most one decimal for all six study measures (`measure_windows.reported_decimals` = 1); a value such as `12` is the same quantity as `12.0`.

Availability states for the six study measures:

| availability_state | 2026-05-13 | 2026-08-13 | 2026-09-30 |
|---|---|---|---|
| reported | 14,732 | 14,848 | 14,848 |
| too_few_cases | 8,989 | 8,657 | 8,657 |
| not_available_this_period | 3,452 | 3,686 | 3,686 |
| not_eligible_program | 1,020 | 1,032 | 1,032 |
| no_eligible_cases | 559 | 517 | 517 |

`Compared to National` labels for the six study measures:

| Label | 2026-05-13 | 2026-08-13 | 2026-09-30 |
|---|---|---|---|
| No Different Than the National Rate | 9,428 | 9,991 | 0 |
| Better Than the National Rate | 391 | 137 | 0 |
| Worse Than the National Rate | 209 | 80 | 0 |
| Average Days per 100 Discharges | 2,130 | 3,979 | 0 |
| Fewer Days Than Average per 100 Discharges | 1,022 | 335 | 0 |
| More Days Than Average per 100 Discharges | 1,552 | 326 | 0 |
| Number of Cases Too Small | 8,989 | 8,657 | 0 |
| Not Available | 5,031 | 5,235 | 28,740 |

Footnote strings on study-measure records, all three releases combined: empty 43,451; `1` 26,261; `5` 10,824; `19` 3,084; `7` 1,593; `29` 909; `28` 60; `1, 29` 40; `23` 8; `1, 28` 2.

## Source to analysis: Hospital General Information

Loads into `hospitals`, one row per release x Facility ID (5,432; 5,419; 5,419 rows). It supplies hospital type for every record and the broader denominator for coverage.

| Source field | Example raw values seen | Parsed field in `hospitals` | Parsing rule | States distinguished |
|---|---|---|---|---|
| Facility ID | `010001`, `01014F`, `02013F` | `facility_id_src`, `facility_id` | normalize_facility_id; must be unique within the file | unique ID |
| Facility Name | `SOUTHEAST HEALTH MEDICAL CENTER` | `facility_name` | as given | text |
| State | `AL` | `state` | as given | text |
| Hospital Type | `Acute Care Hospitals` (3,115 in 2026-05-13), `Critical Access Hospitals` (1,378), `Psychiatric` (635), `Acute Care - Veterans Administration` (132), `Childrens` (94), `Rural Emergency Hospital` (41), `Acute Care - Department of Defense` (32), `Long-term` (5) | `hospital_type`; copied to `records.hospital_type` | as given; gate G2b compares it with `population_exclusions` | text |
| Hospital Ownership | `Proprietary`, `Voluntary non-profit - Private`, `Government - Federal`, `Veterans Health Administration`, `Tribal`, `Department of Defense`, `Physician` | `ownership` | as given; descriptive only | text |
| Emergency Services | `Yes` (4,498 in 2026-05-13), `No` (934) | `emergency_services` | as given; descriptive only | text |

Not loaded: address and contact columns, the birthing-friendly designation, the overall star rating and its footnote, and all measure-group count columns.

## Source to analysis: Footnote Crosswalk

Loads into `footnote_dictionary`, one row per release x code (32 codes per release, including `*`, `**` and `a`).

| Source field | Example raw values seen | Parsed field | Parsing rule |
|---|---|---|---|
| Footnote | `1`, `29`, `*`, `a` | `code` | trimmed |
| Footnote Text | `The number of cases/patients is too few to report.` | `footnote_text` | trimmed |
| (derived) | | `study_class`, `availability_state` | from `[footnote_policy]` in `config/measures.toml` |

| study_class | Codes | Effect |
|---|---|---|
| window_blocking | 29 (partial performance period), 3 (shorter period than required) | record fails gate G3 |
| availability | 19, 12, 7, 1, 4, 13, 5 | sets `availability_state` for a non-numeric score; on a numeric score, fails gate G6 |
| caution | 23, 28, 11 | record passes with `caution_flag` = 1; dropped in the strict subset (S1) |
| informational | all other codes | no effect on gates |

The build stops if a record carries a code missing from the same release's crosswalk (`footnote_codes_known`).

## Source to analysis: Measure Dates

Loads into `measure_windows` (official fields), one row per release x study or look-alike measure.

| Source field | Example raw values seen | Parsed field | Parsing rule |
|---|---|---|---|
| Measure ID | `READM_30_HF`, `READM_30_HF_HRRP` | lookup key | trimmed; a look-alike ID is looked up with hyphens replaced by underscores (`READM-30-HF-HRRP` to `READM_30_HF_HRRP`) |
| Measure Name | `Heart Failure (HF) 30-Day Readmission Rate` | `official_name` | trimmed |
| Start Date | `07/01/2021` (2026-05-13 file), `07/01/2023` (current file, READM_30_HF) | `official_start` | parse_date |
| End Date | `06/30/2024`, `06/30/2025` | `official_end` | parse_date |

Not loaded: Measure Start Quarter and Measure End Quarter (for example `3Q2021`, `2Q2024`).

## Source to analysis: HRRP file

Loads into `hrrp_records`, one row per release x Facility ID x HRRP measure (all six HRRP conditions; 3,055 rows per condition per release). Only READM-30-HF-HRRP and READM-30-AMI-HRRP are in the study dictionary, as look-alikes for the definition check. HRRP rows are never gated, paired or ranked.

| Source field | Example raw values seen | Parsed field(s) | Parsing rule | States seen for the two look-alikes (three releases) |
|---|---|---|---|---|
| Facility ID | `010001` | `facility_id` | normalize_facility_id | |
| State | `AL` | `state` | as given | |
| Measure Name | `READM-30-HF-HRRP`, `READM-30-AMI-HRRP` | `measure_id` | trimmed; this column carries the measure code | |
| Excess Readmission Ratio | `1.0233`, `N/A` | `err_src`, `err_num` | parse_numeric | numeric 13,071; not_available_na 5,259 |
| Predicted Readmission Rate | `20.5695`, `N/A` | `predicted_src`, `predicted_num` | parse_numeric | numeric 13,071; not_available_na 5,259 |
| Expected Readmission Rate | `20.1010`, `N/A` | `expected_src`, `expected_num` | parse_numeric | numeric 13,071; not_available_na 5,259 |
| Number of Discharges | `653`, `N/A` | `discharges_src`, `discharges_num` | parse_numeric | numeric 10,893; not_available_na 7,437 |
| Number of Readmissions | `136`, `Too Few to Report`, `N/A` | `readmissions_src`, `readmissions_num` | parse_numeric | numeric 10,668; not_available_na 5,259; too_few_to_report 2,403 |
| Footnote | (empty), `1`, `5`, `7`, `29` | `footnote_src` | stored as given | |
| Start Date, End Date | `07/01/2021`, `06/30/2024` | `start_date`, `end_date` | parse_date | |

Not loaded: Facility Name. The HRRP rows contribute the look-alike windows (2021-07-01 to 2024-06-30 in all three releases) and reported decimals (4) to `measure_windows`.

## Source to analysis: national and state files

Load into `national_reference`, one row per release x dataset x geography x Measure ID (1,938 rows per release). Values are stored as source strings and are parsed only where used.

| Source field | Example raw values seen | Field in `national_reference` | Use |
|---|---|---|---|
| State (state files only) | `AZ` | `geography` | national rows carry `NATION` |
| Measure ID | `READM_30_HF` | `measure_id` | key |
| National Rate (national files only) | `19.7` (READM_30_HF, 2026-05-13), `21.3` (READM_30_HF, 2026-09-30), `Not Applicable` (EDAC) | `national_rate` | reported as given in `evidence/claims.json` |
| Number of Hospitals Worse, Same, Better, Too Few | `57`, `3120`, `56`, `1271` (READM_30_HF national, 2026-05-13); `Not Available` (2026-09-30); `Not Applicable` (EDAC) | `n_worse`, `n_same`, `n_better`, `n_too_few` | category reconciliation |
| Number of Hospitals Fewer, Average, More, Too Small (Unplanned Hospital Visits files only) | `767`, `1432`, `1034`, `1271` (EDAC_30_HF national, 2026-05-13); `Not Applicable` (READM rows); `Not Available` (2026-09-30) | `n_fewer`, `n_average`, `n_more`, `n_too_small` | category reconciliation; NULL where the column is absent from the file |
| Footnote | (empty), `4` (Unplanned Hospital Visits national and state rows, 2026-08-13 and 2026-09-30), `5` (state rows, all releases) | `footnote` | stored as given; not used by any gate |
| Start Date, End Date | `07/01/2021`, `06/30/2024` | `start_date`, `end_date` | parse_date; compared with the hospital-file window |

Not loaded: Measure Name. In `src/hospcomp/validate.py` a category cell is converted with `int()`; a cell that is not an integer (`Not Available`, `Not Applicable`) is treated as unpublished, and no difference is computed for it (`outputs/validation/reconciliation_categories.csv`).

## Configuration tables

| Table | Source | Rows | Content |
|---|---|---|---|
| `releases` | `config/releases.toml` | 3 | release key, source, role, label, `interval_status`, status note, notice and notice URL |
| `source_files` | `source_manifest.json` | 30 | release key, dataset key, dataset ID, title, released and modified dates, file version, download URL, SHA-256, data rows |
| `measure_dictionary` | `config/measures.toml` | 8 | Measure ID, dataset, condition, endpoint, quantity, unit, favorable direction, unit bounds, study role, documentation source |
| `definition_changes` | `config/releases.toml` | 4 | documented definition changes between releases with Federal Register citations |
| `population_exclusions` | `config/population_exclusions.csv` | 6 | Veterans Administration hospital type for each of the six study measures, with the QualityNet report and page (Amendment 2) |

Units and directions in `measure_dictionary`: READM and MORT measures are risk-standardized rates in percent of index admissions, bounded 0 to 100; EDAC measures are excess days in acute care per 100 discharges and can be negative; the HRRP look-alikes are excess readmission ratios. Lower is favorable for all eight.

## Derived tables

### measure_windows

One row per release x dictionary measure (24 rows). Built in `build.py`; exported unchanged as `outputs/tables/measure_windows.csv`.

| Column | Definition |
|---|---|
| release_key | release |
| measure_id | dictionary Measure ID |
| source_measure_name | first, in sorted order, of the distinct Measure Name strings seen for the ID in the release file |
| n_source_names | number of distinct Measure Name strings for the ID (1 for every measure in every release) |
| official_name, official_start, official_end | from the same release's Measure Dates file |
| modal_start, modal_end | most frequent record window in the release file |
| window_months | inclusive months from modal_start to modal_end |
| reported_decimals | largest number of decimals seen in Score, Lower Estimate or Higher Estimate (Excess Readmission Ratio for HRRP) |
| n_window_variants | number of distinct record windows (1 everywhere in this run) |

Windows in this run: all study measures cover 2021-07-01 to 2024-06-30 (36 months) in 2026-05-13. In 2026-08-13 and 2026-09-30, READM_30_HF and READM_30_AMI cover 2023-07-01 to 2025-06-30 (24 months) and the MORT and EDAC measures cover 2022-07-01 to 2025-06-30 (36 months).

### gate_results

One row per study-measure record (86,232 rows: 28,752 in 2026-05-13 and 28,740 in each later release). Built by `sql/02_gates.sql`; exported unchanged as `outputs/tables/gate_results.csv`. Each gate is evaluated on every record independently; `first_failed_gate` and `reason_code` report the first failure in the fixed order G0, G1, G2, G2b, G3, G4, G5, G6.

| Column | Definition |
|---|---|
| record_id, release_key, dataset_key, release_date | from `records` |
| interval_status | from `releases` |
| facility_id, facility_name, state, measure_id, hospital_type, availability_state, compared_to_national_src | from `records` |
| study_role | `primary`, `supporting` or `secondary`, from `measure_dictionary` |
| score_src, lower_src, upper_src, denominator_src, footnote_src | exact source strings |
| start_date, end_date | parsed ISO dates |
| score_num, lower_num, upper_num, denominator_num | parsed values (NULL when not numeric) |
| favorable | `lower` for every study measure |
| reported_decimals | from `measure_windows` |
| g0_release | 1 when `interval_status` = `published` |
| g1_identity | 1 when `facility_id_valid` = 1 and the (release, dataset, Facility ID, Measure ID) key occurs once |
| g2_definition | 1 when the Measure ID has exactly one source Measure Name in the release file |
| g2b_population | 0 when the record's hospital type is listed for the measure in `population_exclusions` |
| g3_window | 1 when the record window equals the official Measure Dates window and the record carries no footnote 29 or 3 |
| g4_score | 1 when `score_state` = `numeric` |
| g5_interval | 1 when score and both limits are numeric, lower <= score <= upper, lower < upper, and the limits lie within the unit bounds |
| g6_footnote | 0 when the record carries any availability footnote (1, 4, 5, 7, 12, 13, 19) |
| first_failed_gate | `G0` to `G6`, or NULL when all gates pass |
| reason_code | `release_intervals_flagged_by_cms`, `release_intervals_suppressed_by_cms`, `release_not_usable`, `invalid_or_duplicate_identifier`, `measure_definition_ambiguous`, `population_or_data_source_differs`, `partial_or_short_period_footnote`, `observation_window_mismatch`, the record's `availability_state` (for a G4 failure), `interval_limit_missing`, `interval_reversed`, `interval_zero_width`, `score_outside_interval`, `interval_out_of_bounds`, `blocking_footnote_on_numeric_record`, or `compatible` |
| compatible | 1 when all eight gates pass |
| caution_flag | 1 when the record carries footnote 11, 23 or 28 |

Gate outcomes in this run: in 2026-05-13, 13,846 records are compatible (60 of them carry a caution footnote, all footnote 28). Every record in 2026-08-13 fails G0 with `release_intervals_flagged_by_cms`, and every record in 2026-09-30 fails G0 with `release_intervals_suppressed_by_cms`; their independent gate flags are still filled in.

### compat_oriented (view)

One row per compatible record (13,846 rows, all from 2026-05-13). Exported as `outputs/tables/compatible_records.csv` (selected columns).

| Column | Definition |
|---|---|
| record_id, release_key, measure_id, state, facility_id, facility_name, hospital_type, compared_to_national_src, caution_flag, favorable, reported_decimals, score_num, lower_num, upper_num, denominator_num | from `gate_results` |
| score_i, lower_i, upper_i | value x 10^reported_decimals, rounded to an integer, so that comparisons are exact in units of the last reported decimal |
| o_s, o_lo, o_hi | oriented integers: equal to score_i, lower_i, upper_i when lower is favorable; for a higher-is-better measure the sign is flipped and the limits swap |
| official_category | `better` (Better Than the National Rate; Fewer Days Than Average), `worse` (Worse Than the National Rate; More Days Than Average), `no_different` (No Different Than the National Rate; Average Days), `too_small`, or `other` |

### pairs

One row per unordered pair of distinct compatible hospitals in the same release, state and Measure ID (583,695 rows, all from 2026-05-13). Built by `sql/03_pairs_ranks.sql`. Exported only as summaries (`pair_summary_national.csv`, `pair_summary_by_state.csv`, `state_weighted_summary.csv`, `hospital_level.csv`, `hospital_level_summary.csv`).

| Column | Definition |
|---|---|
| release_key, measure_id, state | universe |
| facility_a, facility_b | the two Facility IDs, with facility_a < facility_b as text |
| score_a, lower_a, upper_a, score_b, lower_b, upper_b | published values |
| category_a, category_b | `official_category` of each hospital |
| caution_a, caution_b | `caution_flag` of each hospital |
| point_ordered | 1 when the published scores differ (score_i values unequal); 0 is a tie |
| sep_r1 | R1, strict non-overlap: o_hi of one hospital < o_lo of the other; touching endpoints are not separated |
| sep_r2 | R2, rounding-robust non-overlap: the gap between the intervals exceeds one unit in the last reported decimal |
| sep_r3 | R3, point-outside (lenient): each point estimate lies outside the other hospital's interval |
| official_opposite | reference only: one hospital's CMS category is `better` and the other's is `worse` |
| gap_scaled | max(o_lo_b - o_hi_a, o_lo_a - o_hi_b) in integer units of the last reported decimal; positive values are gaps, 0 is touching, negative values are overlaps |

Separation flags are computed for every pair. Summaries count them only among point-ordered pairs; ties are counted separately. The strict subset (S1) keeps pairs with caution_a = 0 and caution_b = 0.

### rank_ranges

One row per subset x compatible record (27,632 rows: 13,846 in the primary subset and 13,786 in the strict subset). Built by `sql/03_pairs_ranks.sql`; exported as `outputs/tables/rank_ranges.csv` with two added columns.

| Column | Definition |
|---|---|
| subset | `primary` (all compatible records) or `strict` (caution_flag = 0) |
| release_key, measure_id, state, facility_id, facility_name, hospital_type | identifiers |
| official_category | from `compat_oriented` |
| score_num, lower_num, upper_num | published values |
| n | number of hospitals in the subset x release x measure x state universe |
| point_rank | 1 + number of hospitals in the universe with a strictly more favorable published score (competition ranking; ties share the best rank) |
| best_rank | 1 + #{j : U_j < L_i}, the number of hospitals whose interval lies entirely on the favorable side of hospital i's interval, plus one |
| worst_rank | n - #{j : L_j > U_i} |
| range_width (CSV only) | worst_rank - best_rank + 1 |
| width_share_of_n (CSV only) | range_width / n |

The range is the set of ranks hospital i could hold if every hospital's true value lay anywhere inside its own published marginal 95% interval (the counting rule of Klein, Wright and Wieczorek 2020). It is an interval-compatible rank range. It is not a confidence set for ranks, carries no probability and is not a significance test. Universes with n = 1 give best_rank = worst_rank = 1 and are excluded from `rank_range_summary.csv`, which uses n >= 2.

### Summary tables built from the derived tables

| Output | Grain | Built from |
|---|---|---|
| gate_flow_national.csv | release x measure (18 rows) | gate_results; `broader_denominator_general_info` from hospitals |
| gate_flow_by_state.csv | release x measure x state (1,008 rows) | gate_results and hospitals |
| failure_reasons.csv | release x measure x first failed gate x reason (54 rows) | gate_results |
| availability_states.csv | release x measure x availability state (90 rows) | gate_results |
| compatible_by_hospital_type.csv | release x measure x hospital type (108 rows) | gate_results |
| official_category_counts.csv | release x measure x CMS label (66 rows) | gate_results |
| pair_summary_national.csv | subset x release x measure (12 rows) | pairs |
| pair_summary_by_state.csv | subset x release x measure x state with at least one pair (628 rows) | pairs |
| state_weighted_summary.csv | subset x release x measure (12 rows) | pair_summary_by_state (states with point-ordered pairs, equal weight) |
| hospital_level.csv | subset x release x measure x state x hospital with at least one point-ordered comparison (27,606 rows) | pairs |
| hospital_level_summary.csv | subset x release x measure (12 rows) | hospital_level |
| rank_range_summary.csv | subset x release x measure (12 rows) | rank_ranges with n >= 2; top-ranked hospital per universe with n >= 10 |
| compatibility_matrix.csv | release x measure pair among the 8 dictionary measures (84 rows) | measure_dictionary and measure_windows |
| cross_release_windows.csv | measure x release (24 rows) | measure_windows, releases, definition_changes |
| facility_presence.csv | release pair (3 rows) | records (Unplanned Hospital Visits facility sets) |
| measure_dictionary.csv, measure_windows.csv, releases.csv | as in the database | database tables |
| compatible_records.csv | compatible record (13,846 rows) | compat_oriented |
| examples.json | prespecified lead and passing examples | rank_ranges, pairs, gate_results and `[analysis]` in `config/study.toml` |
| r_crosscheck_pairs.csv | release x measure (6 rows) | `scripts/crosscheck_pairs.R` reading compatible_records.csv |

Numbers in output CSVs are written with up to 10 significant digits. Shares are proportions between 0 and 1. Boolean columns in `compatibility_matrix.csv` and `cross_release_windows.csv` are written as `True` or `False`; gate flags are 0 or 1.

## Keys and join cardinality checks

Primary keys (enforced by the schema): `releases(release_key)`; `source_files(release_key, dataset_key)`; `footnote_dictionary(release_key, code)`; `measure_dictionary(measure_id)`; `measure_windows(release_key, measure_id)`; `hospitals(release_key, facility_id)`; `records(record_id)`; `record_footnotes(record_id, code)`; `population_exclusions(measure_id, hospital_type)`; `hrrp_records(record_id)`; `national_reference(release_key, dataset_key, geography, measure_id)`.

Checks recorded in `outputs/logs/build_log.json` (45 checks, 15 per release, all passed; a failure stops the build):

| Check | 2026-05-13 | 2026-08-13 | 2026-09-30 |
|---|---|---|---|
| general_info_facility_unique (no duplicate Facility ID in General Information) | 5,432 rows, 0 duplicates | 5,419 rows, 0 duplicates | 5,419 rows, 0 duplicates |
| row_count_unplanned_visits (parsed rows equal manifest rows) | 67,088 = 67,088 | 67,060 = 67,060 | 67,060 = 67,060 |
| row_count_complications_deaths | 95,840 = 95,840 | 95,800 = 95,800 | 95,800 = 95,800 |
| row_count_hrrp | 18,330 = 18,330 | 18,330 = 18,330 | 18,330 = 18,330 |
| facility_in_general_info for each outcome file (every outcome Facility ID joins to the same release's General Information) | 0 missing | 0 missing | 0 missing |
| footnote_codes_known (every record code is in the same release's crosswalk) | 0 unknown | 0 unknown | 0 unknown |
| measure_present for each of the 8 dictionary measures | present | present | present |

The build log also records 4,792 facilities in each outcome file for 2026-05-13 and 4,790 for the later releases. In addition, the build stops on any duplicate (Facility ID, Measure ID) within one outcome file, and gate G1 re-checks key uniqueness in SQL.

Cardinality of the derived joins, checked by query against the frozen database for this run:

| Join | Expected | Observed |
|---|---|---|
| records (six study measures) to gate_results through measure_dictionary (one row per Measure ID), measure_windows (one row per release x Measure ID) and releases (one row per release) | one gate row per study record | 86,232 records, 86,232 gate rows, 86,232 distinct record IDs |
| gate_results (compatible = 1) to compat_oriented through measure_windows | one row per compatible record | 13,846 and 13,846 |
| compat_oriented self-join to pairs within release x measure x state | sum over universes of n(n - 1)/2 | 583,695 and 583,695 |
| compat_oriented to rank_ranges | one row per compatible record per subset | primary 13,846; strict 13,786 (13,846 minus 60 caution records) |
| rank_ranges to hospital_level on subset, release, measure, state, Facility ID | one-to-one except hospitals with no point-ordered comparison | 27,632 and 27,606; the 26 unmatched rows are the 13 single-hospital universes in each subset |
| record_footnotes to records | every footnote row has a record | 0 orphan rows |
| compatible gate rows to hospital type | every compatible record has a same-release hospital type | 0 missing (`validation_report.json`) |

## Lineage

1. Acquisition (`hospcomp acquire`, `src/hospcomp/acquire.py`). Datasets are resolved from the CMS Provider Data Catalog metastore and the official archive API. Each raw file is saved under `data/raw/` with its SHA-256, byte size, data row count, headers, catalog dates and download URL in `source_manifest.json`. Metastore records are saved under `data/raw/metastore/`. When a file is downloaded again, its checksum is compared with the one pinned in `source_manifest.json`, and acquisition stops if CMS now serves a different file or if the live outcome files carry a newer release date, unless `--force` is given. The build and analysis stages refuse to run if any cached file's checksum differs from the manifest.
2. Build (`hospcomp build`, `src/hospcomp/build.py`). For each release in `config/releases.toml`: `releases` and `source_files`; Footnote Crosswalk to `footnote_dictionary`; General Information to `hospitals`; Measure Dates to the official fields of `measure_windows`; outcome files to `records` and `record_footnotes`; HRRP to `hrrp_records`; national and state files to `national_reference`. Configuration files fill `measure_dictionary`, `definition_changes` and `population_exclusions`. Checks go to `outputs/logs/build_log.json`.
3. Gates (`hospcomp analyze`, `sql/02_gates.sql`). `records` + `measure_dictionary` + `measure_windows` + `releases` + `record_footnotes` + `footnote_dictionary` + `population_exclusions` give `gate_results`.
4. Pairs and rank ranges (`sql/03_pairs_ranks.sql`). `gate_results` (compatible records) + `measure_windows` give the view `compat_oriented`, which gives `pairs` and `rank_ranges`.
5. Summaries (`src/hospcomp/analyze.py`). The derived tables give every CSV in `outputs/tables/` and `examples.json` (see the summary table above), and `outputs/run_manifest.json` records the run ID and the SHA-256 of the plan, configuration, SQL, sources and outputs. The stage refuses to run unless `docs/analysis_plan.md` matches `docs/analysis_plan.lock.json`.
6. Validation (`hospcomp validate`, `src/hospcomp/validate.py`). Data checks, category reconciliation against the national and state files (`reconciliation_categories.csv`), raw reconstruction of 24 prespecified records from the raw CSV bytes with an independent parser (`raw_reconstruction.csv`), the R cross-check (`r_crosscheck_pairs.csv`) and a full rebuild and reanalysis compared table by table (`rerun_comparison.csv`, `outputs/rerun/`). Results go to `outputs/validation/validation_report.json`, which separates checks that have a pass condition from records that only document a comparison or count; the R cross-check is reported as skipped when R is not installed.
7. Evidence map (`src/hospcomp/claims.py`). Headline numbers are read from the output tables into `evidence/claims.json`, each with its output path, row selector, column, numerator, denominator, scope, source keys and run ID.
