# Contribution decision

Written 2026-10-07, after the prior-art search (`docs/prior_art_search.md`, `docs/prior_art.csv`) and before the `analyze` stage first ran.

## Who would use the output

Quality-improvement and health-services analysts who build comparison tables or rankings of hospitals from the CMS Provider Data Catalog: hospital association analysts, state agency staff, health-system quality teams and researchers. It is not written for patients choosing a hospital and it does not recommend hospitals.

## Decision it supports

Two decisions an analyst makes before publishing or acting on a comparison:

1. Is the proposed comparison supportable at all? Do the records share the same Measure ID, quantity, unit, population definition and observation window, and does each record have a valid numeric score and interval rather than a suppressed, too-few, not-eligible or partial-period value?
2. Within the records that pass, which pairwise orderings are separated by CMS's own published interval estimates, and how wide is the range of ranks each hospital could hold?

## What is already established

- Rankings of institutions carry large uncertainty and most pairwise orderings often cannot be separated (Goldstein and Spiegelhalter 1996; Marshall and Spiegelhalter 1998). Rank uncertainty is several times larger for small hospitals (Davidson, Moscovice and Remus 2007, PMC4195008).
- CMS classifies nearly all hospitals as no different from the national rate on the 30-day outcome measures (Silber et al. 2010; Glance et al. 2021), and the readmission measures have limited reliability for many hospitals (Thompson et al. 2016).
- The deterministic counting rule behind interval-compatible rank ranges is published (Klein, Wright and Wieczorek 2020), as are proper simultaneous confidence sets for ranks that need standard errors and a joint distribution (Mogstad, Romano, Shaikh and Wilhelm 2024). Software exists for both (RankingProject and csranks).
- Changing a measure's definition changes which hospitals look better or worse (Glance, Li and Dick 2017; Wadhera et al. 2021; Horwitz et al. 2018).
- COPSS-CMS (Ash et al. 2012) cautions that indirectly standardized hospital rates should not generally be compared with one another.

## The narrow unresolved question

None of the above gives an analyst an auditable check, run on the current CMS release files, that first rejects records and requests that are not comparable for documented definitional reasons and then measures how much of a naive within-state point ordering the published intervals support. The question is practical and release-specific: for heart-failure readmission and mortality in the 2026-09-30 release, what share of requested records can enter a same-measure, same-state comparison, and what share of the point-estimate orderings among them are separated by the published intervals?

The release matters. The FY 2026 IPPS final rule (90 FR 36537, 36931 to 36932) added Medicare Advantage beneficiaries to the six readmission measures and shortened their period from three years to two starting with the FY 2027 program year. In the current catalogue, READM_30_HF therefore covers July 2023 to June 2025 (24 months), while MORT_30_HF and EDAC_30_HF cover July 2022 to June 2025 (36 months), and the HRRP file's look-alike READM-30-HF-HRRP covers July 2021 to June 2024 with a different estimand (an excess readmission ratio).

## Framing

This is a reusable tool and an updated measurement on contemporary public data. It is not a new statistical method and not a claim of discovery. The rank-range calculation is credited to Klein et al. (2020). The pairwise separation summary follows the logic of Goldstein and Spiegelhalter (1996). The work does not claim to be first.

## Comparator

The naive comparator is the point-estimate-only ordering of hospitals within the same state and the same Measure ID in the same release. It never mixes endpoints, conditions or programs.

## Estimands

- Record level: the fraction of requested hospital-measure records passing each gate, against two denominators (rows in the measure file; hospitals in Hospital General Information).
- Pair level: among point-ordered pairs of compatible hospitals in the same state and measure, the fraction not separated by the published 95% intervals (strict non-overlap), pooled, by state with equal state weight, and per hospital.
- Rank level: interval-compatible rank ranges relative to universe size, and the worst compatible rank of each state's point-estimate first-ranked hospital.

## What counts as a useful negative result

- If most point-ordered pairs are separated, the public intervals support most within-state orderings for these measures; the useful part of the tool is then the definitional gates.
- If nearly every requested record passes the gates, record-level incompatibility is a minor issue in this release and the report says so.
- Either result is reported as found.

## What this work does not do

It does not measure the quality of care, recommend a hospital, test statistical significance, produce simultaneous confidence sets, re-estimate CMS models, or attribute differences to hospital actions. It describes one public measure population, not hospital quality in general.

## One paper

The manuscript and the portfolio report describe the same single analysis. No second paper is split from it.

## Addendum (2026-10-07T11:27Z)

The question above names the 2026-09-30 release. After this decision was written, source checks showed that the 2026-09-30 files no longer publish interval estimates for the study measures and that the intervals in the 2026-08-13 release were flagged by a CMS notice. The pairwise analysis therefore uses the 2026-05-13 release, the latest release with published intervals not covered by a notice, and the two newer releases are run through the same gates (`docs/analysis_plan.md`, "Release selection"). The users, decision, comparator, estimands and the definition of a useful negative result are unchanged.

