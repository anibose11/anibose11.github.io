# Tableau import and interaction specification

This document specifies how the study outputs should be loaded into Tableau and which interactions and displays are allowed. No Tableau workbook is delivered with the project, and no workbook built from this specification has been tested. The specification describes the data contract that a workbook would have to follow so that it shows the same numbers as the study tables.

All files are in `outputs/tables/` and come from the run recorded in `outputs/run_manifest.json` (its `run_id`). Column definitions are in `docs/data_dictionary.md`.

## General rules

1. Every number shown in Tableau is a value already present in one row of an imported CSV. Tableau selects and displays rows. It does not compute study quantities.
2. Filters may only select precomputed rows. A filter must never cause a pair share, a separated count, a rank, a rank range or a gate pass share to be recomputed from the filtered subset.
3. Pair shares and rank ranges were computed within a full universe (one release, one Measure ID, one state, one subset). Hiding some hospitals with a filter does not change the ranks or shares of the hospitals that remain visible, and the view must say so.
4. National figures come from the national tables. They are never rebuilt by summing or averaging state rows.

## Extracts to import

Import each CSV as its own table in one Tableau data source using relationships (the logical layer). Physical joins are not used, so that no table's rows are duplicated by another table's grain. `gate_results.csv` is not distributed in the downloads because of its size; `hospcomp build` followed by `hospcomp analyze` writes it to `outputs/tables/` from the raw CMS files.

| Extract | Grain (one row per) | Rows | Key |
|---|---|---|---|
| releases.csv | release | 3 | release_key |
| measure_dictionary.csv | dictionary measure | 8 | measure_id |
| measure_windows.csv | release x measure | 24 | release_key, measure_id |
| gate_results.csv | release x study measure x hospital record | 86,232 | record_id (equivalently release_key, measure_id, facility_id) |
| gate_flow_national.csv | release x study measure | 18 | release_key, measure_id |
| gate_flow_by_state.csv | release x study measure x state | 1,008 | release_key, measure_id, state |
| failure_reasons.csv | release x study measure x first failed gate x reason | 54 | release_key, measure_id, first_failed_gate, reason_code |
| availability_states.csv | release x study measure x availability state | 90 | release_key, measure_id, availability_state |
| compatible_by_hospital_type.csv | release x study measure x hospital type | 108 | release_key, measure_id, hospital_type |
| official_category_counts.csv | release x study measure x CMS comparison label | 66 | release_key, measure_id, compared_to_national_src |
| pair_summary_national.csv | subset x release x study measure | 12 | subset, release_key, measure_id |
| pair_summary_by_state.csv | subset x release x study measure x state with at least one pair | 628 | subset, release_key, measure_id, state |
| state_weighted_summary.csv | subset x release x study measure | 12 | subset, release_key, measure_id |
| hospital_level.csv | subset x release x study measure x state x hospital with at least one point-ordered comparison | 27,606 | subset, release_key, measure_id, state, facility_id |
| hospital_level_summary.csv | subset x release x study measure | 12 | subset, release_key, measure_id |
| rank_ranges.csv | subset x compatible record | 27,632 | subset, release_key, measure_id, facility_id |
| rank_range_summary.csv | subset x release x study measure | 12 | subset, release_key, measure_id |
| cross_release_windows.csv | study measure x release | 24 | measure_id, release_key |
| compatibility_matrix.csv | release x pair of dictionary measures | 84 | release_key, measure_a, measure_b |
| facility_presence.csv | pair of releases | 3 | release_a, release_b |

Not imported:

- `compatible_records.csv` duplicates fields already in `gate_results.csv` and `rank_ranges.csv`.
- `examples.json` is a nested document. The lead example can be shown from `rank_ranges.csv` with subset = primary, release_key = 2026-05-13, measure_id = READM_30_HF and state = AZ (52 rows).
- `r_crosscheck_pairs.csv` is a software cross-check.
- The pair-level table `pairs` (583,695 rows) exists only in `data/interim/hospcomp.sqlite` and is not exported. Pair results are shown only from the pair summary tables and `hospital_level.csv`.
- HRRP look-alike records are not exported to any table; the look-alike measures appear only in `measure_dictionary.csv`, `measure_windows.csv` and `compatibility_matrix.csv`.

## Field types

Set these types explicitly on import, overriding Tableau's guesses:

| Field | Type | Reason |
|---|---|---|
| release_key, release_a, release_b | String | a release identifier; date parsing would change its label |
| facility_id, facility_a, facility_b | String | six-character IDs with leading zeros and letters (for example `010001`, `01014F`) |
| state | String (a State/Province geographic role is allowed) | two-letter CMS code, including DC, PR, GU, MP, AS and VI |
| measure_id, subset, hospital_type, availability_state, reason_code, first_failed_gate, official_category, interval_status, compared_to_national_src | String, dimension | categorical |
| g0_release to g6_footnote, compatible, caution_flag | Whole number, dimension | 0 or 1 flags |
| score_num, lower_num, upper_num, denominator_num | Decimal, dimension (or ATTR in a view) | one row's published value; never summed or averaged |
| point_rank, best_rank, worst_rank, n, range_width | Whole number, dimension | ranks within one universe; never summed or averaged |
| every column ending in `_share`, `median_*`, `q1`, `q3`, `min_state_share`, `max_state_share`, `width_share_of_n`, `separated_share` | Decimal, dimension (or ATTR) | precomputed proportions between 0 and 1 |
| count columns (requested_records, compatible, pairs, point_ordered_pairs, sep_r1_count and similar) | Whole number | shown as the value of one row |
| True/False columns in compatibility_matrix.csv and cross_release_windows.csv | Boolean | written as `True` or `False` |

An empty cell is NULL. In `gate_results.csv` an empty `first_failed_gate` means the record passed every gate, and an empty `footnote_src` means the record had no footnote. Empty `score_num`, `lower_num` or `upper_num` means the source value was not numeric; the reason is in `availability_state`, `reason_code` and the matching `*_src` text.

## Relationships

| From | To | Fields | Cardinality |
|---|---|---|---|
| gate_results | releases | release_key | many to one |
| gate_results | measure_dictionary | measure_id | many to one |
| gate_results | measure_windows | release_key, measure_id | many to one |
| rank_ranges | gate_results | release_key, measure_id, facility_id | many to one (two subset rows per compatible record, or one row for the 60 records with a caution footnote, which appear only in the primary subset) |
| hospital_level | rank_ranges | subset, release_key, measure_id, state, facility_id | one to one where present; hospitals in single-hospital universes have no hospital_level row |
| gate_flow_by_state, pair_summary_by_state | measure_windows | release_key, measure_id | many to one |
| gate_flow_national, pair_summary_national, state_weighted_summary, hospital_level_summary, rank_range_summary, failure_reasons, availability_states, compatible_by_hospital_type, official_category_counts | measure_windows | release_key, measure_id | many to one |
| every table with release_key | releases | release_key | many to one |
| every table with measure_id | measure_dictionary | measure_id | many to one |

`pair_summary_by_state` is not related directly to `gate_flow_by_state`. The two tables have different grains (the pair table has a subset dimension and rows only where a state has at least one pair), and a direct relationship invites mixing record-level and pair-level denominators in one calculation.

## Measures and units

| Quantity | Fields | Unit |
|---|---|---|
| READM_30_HF, READM_30_AMI scores and limits | score_num, lower_num, upper_num | risk-standardized readmission rate, percent of index admissions; lower is favorable |
| MORT_30_HF, MORT_30_AMI scores and limits | score_num, lower_num, upper_num | risk-standardized mortality rate, percent of index admissions; lower is favorable |
| EDAC_30_HF, EDAC_30_AMI scores and limits | score_num, lower_num, upper_num | excess days in acute care per 100 discharges, can be negative; lower is favorable |
| Denominator | denominator_num | as published by CMS for the measure |
| Record counts | requested_records, pass_through_*, independent_pass_*, numeric_score_without_usable_interval, compatible, compatible_strict, records, requested, numeric_score | records (one hospital x measure x release) |
| Hospital counts from General Information | broader_denominator_general_info, absent_from_measure_file | hospitals listed in the same release's Hospital General Information file |
| Pair counts | pairs, point_ordered_pairs, tied_pairs, sep_r1_count, sep_r2_count, sep_r3_count, official_opposite_count, not_separated_r1_count | unordered pairs of hospitals in the same release, state and measure |
| Pair shares | sep_r1_share, sep_r2_share, sep_r3_share, official_opposite_share, not_separated_r1_share | proportion of point-ordered pairs |
| State-weighted pair summaries | states_with_point_ordered_pairs; median_state_not_separated_share, q1, q3, min_state_share, max_state_share | number of states; distribution across states (each state weighted equally) of the state's share of point-ordered pairs not separated under R1 |
| Hospital-level pair counts | point_ordered_comparisons, separated_r1 (hospital_level.csv); hospitals_with_point_ordered_comparisons, hospitals_separated_from_none (hospital_level_summary.csv) | point-ordered same-state comparisons of one hospital; hospitals |
| Hospital-level shares | separated_share; median_separated_share, q1, q3, share_separated_from_none | proportion of one hospital's point-ordered comparisons separated under R1; distribution of that proportion across hospitals; proportion of hospitals |
| Record shares | compatible_share_of_requested, compatible_share_of_broader, compatible_strict_share_of_requested | proportion of requested records, or of hospitals in General Information |
| Ranks | point_rank, best_rank, worst_rank, n, range_width | rank positions within one universe; 1 is most favorable |
| Rank width share | width_share_of_n | range_width divided by n |
| Rank-range summaries | hospitals_in_universes_n_ge_2, universes_n_ge_2, universes_n_ge_10, top_ranked_worst_rank_over_half_n_ge_10; median_width_share_of_n, share_width_over_half_of_n, share_full_range, top_ranked_median_worst_rank_share_n_ge_10 | hospitals or state universes (counts); proportions of n or of hospitals (shares), from universes with n >= 2 (n >= 10 for the top-ranked columns) |
| Windows | official_start, official_end, modal_start, modal_end, window_start, window_end, window_months, overlap_months_with_primary | ISO dates; months |

A view that shows scores, limits or ranks must have exactly one measure_id selected, so that values with different units never share an axis.

## Interval fields

- `lower_num` and `upper_num` are CMS's published 95% interval limits for one hospital, in the unit of the score. They are marginal intervals. They come from the 2026-05-13 release wherever a hospital is compared.
- `lower_src` and `upper_src` in `gate_results.csv` keep the exact published text, including `Not Available`.
- `best_rank` and `worst_rank` in `rank_ranges.csv` bound the interval-compatible rank range; `point_rank` is the rank from published scores alone (ties share the best rank).
- A drawing helper such as `[upper_num] - [lower_num]` (for a Gantt bar size) is allowed, because it restates one row's own values. No calculation may combine values from different rows.

## Suppression and availability flags

| Flag | Table | Meaning |
|---|---|---|
| interval_status | releases, gate_results, cross_release_windows | `published` (2026-05-13), `flagged_by_cms_notice` (2026-08-13), `suppressed_by_cms_notice` (2026-09-30) |
| g0_release | gate_results | 0 for every record in the flagged and current releases |
| first_failed_gate, reason_code | gate_results, failure_reasons | first failing gate and its reason, for example `release_intervals_suppressed_by_cms`, `too_few_cases`, `population_or_data_source_differs`, `partial_or_short_period_footnote` |
| availability_state | gate_results, availability_states | `reported`, `too_few_cases`, `not_available_this_period`, `not_eligible_program`, `no_eligible_cases` and the other documented states |
| compatible | gate_results | 1 when all gates pass |
| caution_flag | gate_results | 1 when footnote 11, 23 or 28 is present; such records are dropped in the strict subset |
| numeric_score_without_usable_interval | gate_flow_national, gate_flow_by_state | records with a numeric score and no usable interval (for example 3,253 READM_30_HF records in 2026-09-30) |
| absent_from_measure_file | gate_flow_national, gate_flow_by_state | hospitals in General Information with no row in the measure file |

For 2026-08-13 and 2026-09-30, the pair, hospital-level and rank tables contain no rows, because every record in those releases fails gate G0. A view of those tables filtered to either release must display the text "Not evaluated: interval estimates in this release are flagged or suppressed by CMS (listserve 2026-89-IP)". An empty view must never be presented as zero.

## Permitted filters

| Filter | Allowed values | Applies to | Notes |
|---|---|---|---|
| release_key | 2026-05-13, 2026-08-13, 2026-09-30 | all tables with release_key | single select; default 2026-05-13 |
| measure_id | the six study measures | all tables with measure_id | single select in any view showing scores, limits, ranks or pair shares |
| subset | primary, strict | pair summaries, hospital_level, rank_ranges and their summaries | single select; default primary; always required so that the two subsets are never added together |
| state | CMS state codes | gate_flow_by_state, pair_summary_by_state, hospital_level, rank_ranges, gate_results | rank and pair values stay those of the full state universe |
| hospital_type | hospital types in the release | gate_results, compatible_by_hospital_type, rank_ranges | hides rows only; ranks shown remain ranks among all compatible hospitals in the state |

Not permitted:

- Top N, Bottom N or conditional filters on any score, rank or share.
- Table calculations (RANK, INDEX, RUNNING_*, WINDOW_*, percent of total) and level of detail expressions on score, limit, rank, count or share fields.
- Calculated fields that derive a share from counts, for example SUM(sep_r1_count) / SUM(point_ordered_pairs) over a filtered set of states. A multi-state share for an arbitrary set of states is not a study quantity.
- SUM, AVG, MEDIAN or any other aggregation of shares, ranks, scores or limits across rows.
- Context filters or data source filters that remove hospitals before ranks or shares are displayed. Ranks and shares are fixed in the CSV and are never recomputed.

## Required labeling

Every sheet and dashboard shows:

1. The release: `release_key`, the release `label` from `releases.csv` and its `interval_status`.
2. The observation window of the selected measure in the selected release, from `measure_windows.csv` (`official_start` to `official_end`, `window_months` months).
3. The measure: `measure_id`, quantity, unit and favorable direction from `measure_dictionary.csv`.
4. The subset (primary or strict) wherever pair or rank values appear.
5. The separation rule wherever a pair count or share appears: "R1: strict non-overlap of the published 95% intervals; touching intervals are not separated" (or R2 or R3 when those columns are shown, with their definitions).
6. On any view showing best_rank and worst_rank, the exact phrase "interval-compatible rank range, not a confidence set", together with the universe size n and the statement that the range is the set of ranks consistent with every hospital's true value lying inside its own published interval.
7. The comparison universe: "Hospitals are compared only with hospitals in the same state, for the same Measure ID, in the same release."
8. When a hospital_type or state filter hides rows: "Ranks and shares were computed among all compatible hospitals in the state; filtering does not recompute them."
9. The source line: "Source: CMS Provider Data Catalog, release <release_key>; study tables from run <run_id>."

## Forbidden displays

- Stars, star ratings, grades, medals, badges or any symbol that implies an overall quality score.
- A single best hospital: no highlight, annotation, headline or Top 1 filter that marks the hospital with point_rank = 1 (or any other hospital) as best or as the winner.
- Averaging or combining across measures: no composite, index, sum or average across readmission, mortality and excess days, and no axis that mixes measures.
- A ranked list or rank comparison that combines hospitals from different states, different Measure IDs or different releases.
- Any interval, pair or rank value from 2026-08-13 presented as usable, and any display of 2026-09-30 scores ordered as if intervals were available.
- Probability language about ranks, such as "chance of being best" or "likely top hospital".
- Colour or shape encodings that imply a statistical difference from point estimates alone.
- The `official_opposite` columns presented as a separation rule; they are a reference row showing CMS category disagreement only.
- HRRP look-alike measures substituted for, or displayed alongside, the study measures as if they were the same quantity.
