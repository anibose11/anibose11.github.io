"""Render the manuscript, supplement and report pages from templates and the evidence map.

Numbers come from evidence/claims.json through Jinja2; Markdown is converted to
HTML with Python-Markdown. A Word copy of the manuscript is written with
python-docx for journal submission. Quarto and pandoc are not used (see
outputs/runtime_manifest.json for the renderer actually used).
"""

from __future__ import annotations

import html
import json
import re
import subprocess
import sys
from pathlib import Path

import jinja2
import markdown
import pandas as pd

from .claims import CLAIMS, values
from .common import OUTPUTS, ROOT, TABLES, read_json, write_json

MS_DIR = ROOT / "manuscript"
STATE_NAMES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado",
    "CT": "Connecticut", "DE": "Delaware", "DC": "the District of Columbia", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas", "KY": "Kentucky",
    "LA": "Louisiana", "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota",
    "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire",
    "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina", "ND": "North Dakota",
    "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia",
    "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
}
MEASURE_ROWS = [("readm_hf", "HF readmission"), ("mort_hf", "HF mortality"), ("edac_hf", "HF excess days"),
                ("readm_ami", "AMI readmission"), ("mort_ami", "AMI mortality"), ("edac_ami", "AMI excess days")]
MEASURE_LABEL = {"READM_30_HF": "HF readmission", "MORT_30_HF": "HF mortality", "EDAC_30_HF": "HF excess days",
                 "READM_30_AMI": "AMI readmission", "MORT_30_AMI": "AMI mortality", "EDAC_30_AMI": "AMI excess days"}


def n(x) -> str:
    return f"{int(round(float(x))):,}"


def pct(share, d: int = 1) -> str:
    v = float(share) * 100
    s = f"{v:.{d}f}"
    if v < 100 and float(s) >= 100:
        s = f"{v:.{d + 2}f}"
    return s + "%"


def f1(x) -> str:
    return f"{float(x):.1f}"


def ratio(total, part) -> str:
    return f"{round(float(total) / float(part)):,}"


def r_version() -> str:
    try:
        out = subprocess.run(["Rscript", "-e", "cat(paste(R.version$major, R.version$minor, sep='.'))"],
                             capture_output=True, text=True, timeout=60).stdout.strip()
        return out or "not available"
    except (OSError, subprocess.SubprocessError):
        return "not available"


TYPE_PROSE = {"Childrens": "children's", "Rural Emergency Hospital": "rural emergency",
              "Acute Care - Department of Defense": "Department of Defense"}


def zero_types_text(raw: str) -> str:
    """'Acute Care - Department of Defense (32); Childrens (94)' -> readable prose."""
    parts = []
    for item in [x.strip() for x in raw.split(";") if x.strip()]:
        name, _, count = item.rpartition(" (")
        parts.append(f"{TYPE_PROSE.get(name, name.lower())} hospitals ({count.rstrip(')')} requested)")
    if len(parts) > 1:
        return ", ".join(parts[:-1]) + " or " + parts[-1]
    return parts[0] if parts else "no other hospital type"


def context(public: bool = True) -> dict:
    import matplotlib
    import sqlite3

    from .references import Citer

    v = values()
    vr = read_json(OUTPUTS / "validation" / "validation_report.json")
    citer = Citer()
    author = _private_author()
    if public or not author.get("corresponding_email"):
        corr = "Correspondence: Animesh Bose, Norlowe Research"
    else:
        corr = (f"Corresponding author: Animesh Bose, Norlowe Research. "
                f"Email: {author['corresponding_email']}")
    # Optional Methods statement for the journal version only.
    tools = ROOT / "submission" / "methods_tools_statement.txt"
    tools_note = tools.read_text(encoding="utf-8").strip() if (not public and tools.exists()) else ""
    v = dict(v)
    v["type_readm_hf_zero_types"] = zero_types_text(v.get("type_readm_hf_zero_types", ""))
    return {
        "cite": citer.cite, "af": citer.af, "references": citer.reference_list,
        "additional_files": (lambda: citer.additional_file_list("downloads/")) if public else citer.additional_file_list,
        "correspondence": corr, "tools_note": tools_note,
        "v": _Dot(v), "n": n, "pct": pct, "f1": f1, "ratio": ratio, "measure_rows": MEASURE_ROWS,
        "state_name": STATE_NAMES.get(v["ex_state"], v["ex_state"]),
        "python_version": sys.version.split()[0], "sqlite_version": sqlite3.sqlite_version,
        "pandas_version": pd.__version__, "matplotlib_version": matplotlib.__version__, "r_version": r_version(),
        "val_total": vr["summary"]["checks"], "val_passed": vr["summary"]["passed"],
    }


class _Dot(dict):
    """dict with attribute access whose nested dicts also allow attributes."""

    def __getattr__(self, k):
        val = self[k]
        return _Dot(val) if isinstance(val, dict) else val


def render_template(src: Path, ctx: dict) -> str:
    env = jinja2.Environment(undefined=jinja2.StrictUndefined, keep_trailing_newline=True, autoescape=False)
    return env.from_string(src.read_text(encoding="utf-8")).render(**ctx)


def md_table(df: pd.DataFrame, fmt: dict | None = None) -> str:
    fmt = fmt or {}
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in df.iterrows():
        cells = []
        for c in cols:
            val = r[c]
            if c in fmt and pd.notna(val):
                val = fmt[c](val)
            elif isinstance(val, float) and pd.notna(val) and float(val).is_integer():
                val = f"{int(val):,}"
            elif pd.isna(val):
                val = ""
            cells.append(str(val).replace("|", "/"))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def build_supplement(ctx: dict) -> str:
    P = read_json(OUTPUTS / "run_manifest.json")["primary_release"]
    t = lambda name: pd.read_csv(TABLES / name, dtype={"release_key": str})  # noqa: E731
    out = ["# Supplementary tables S1 to S12", "",
           f"Run {read_json(OUTPUTS / 'run_manifest.json')['run_id']}. Primary release {P}. All tables are generated "
           "from the output files listed under each heading; the CSV files are included in the source archive.", ""]
    gf = t("gate_flow_national.csv")
    gf["measure"] = gf["measure_id"].map(MEASURE_LABEL)
    s1 = gf[["release_key", "measure", "requested_records", "pass_through_g0_release", "pass_through_g2b_population",
             "pass_through_g3_window", "pass_through_g4_score", "pass_through_g5_interval", "compatible",
             "compatible_strict", "numeric_score_without_usable_interval"]].rename(columns={
        "release_key": "Release", "measure": "Measure", "requested_records": "Requested", "pass_through_g0_release": "After G0",
        "pass_through_g2b_population": "After G2b", "pass_through_g3_window": "After G3", "pass_through_g4_score": "After G4",
        "pass_through_g5_interval": "After G5", "compatible": "Compatible", "compatible_strict": "Compatible, strict",
        "numeric_score_without_usable_interval": "Numeric score, no usable interval"})
    out += ["## Table S1. Gate flow by release and measure", "", "Source: outputs/tables/gate_flow_national.csv", "",
            md_table(s1), ""]
    fr = t("failure_reasons.csv")
    fr = fr[fr["release_key"] == P].copy()
    fr["measure"] = fr["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S2. First failing gate and reason, primary release", "", "Source: outputs/tables/failure_reasons.csv",
            "", md_table(fr[["measure", "first_failed_gate", "reason_code", "records"]].rename(columns={
                "measure": "Measure", "first_failed_gate": "First failed gate", "reason_code": "Reason", "records": "Records"})), ""]
    ps = t("pair_summary_national.csv")
    ps = ps[ps["release_key"] == P].copy()
    ps["measure"] = ps["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S3. Pairwise separation, primary and strict subsets (S1, S2)", "",
            "Source: outputs/tables/pair_summary_national.csv. Shares are of point-ordered pairs.", "",
            md_table(ps[["subset", "measure", "pairs", "point_ordered_pairs", "tied_pairs", "sep_r1_count", "sep_r1_share",
                         "sep_r2_share", "sep_r3_share", "official_opposite_share", "not_separated_r1_share"]].rename(columns={
                "subset": "Subset", "measure": "Measure", "pairs": "Pairs", "point_ordered_pairs": "Point-ordered",
                "tied_pairs": "Tied", "sep_r1_count": "Separated R1", "sep_r1_share": "R1 share", "sep_r2_share": "R2 share",
                "sep_r3_share": "R3 share", "official_opposite_share": "CMS categories opposite",
                "not_separated_r1_share": "Not separated R1"}),
                fmt={c: (lambda x: pct(x, 2)) for c in ("R1 share", "R2 share", "R3 share", "CMS categories opposite",
                                                         "Not separated R1")}), ""]
    sw = t("state_weighted_summary.csv")
    sw = sw[(sw["release_key"] == P)].copy()
    sw["measure"] = sw["measure_id"].map(MEASURE_LABEL)
    hl = t("hospital_level_summary.csv")
    hl = hl[hl["release_key"] == P].copy()
    hl["measure"] = hl["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S4. State-weighted and hospital-level summaries", "",
            "Sources: outputs/tables/state_weighted_summary.csv and outputs/tables/hospital_level_summary.csv.", "",
            md_table(sw[["subset", "measure", "states_with_point_ordered_pairs", "median_state_not_separated_share", "q1", "q3",
                         "min_state_share", "max_state_share"]].rename(columns={
                "subset": "Subset", "measure": "Measure", "states_with_point_ordered_pairs": "States",
                "median_state_not_separated_share": "Median state share not separated", "q1": "Q1", "q3": "Q3",
                "min_state_share": "Minimum", "max_state_share": "Maximum"}),
                fmt={c: pct for c in ("Median state share not separated", "Q1", "Q3", "Minimum", "Maximum")}), "",
            md_table(hl[["subset", "measure", "hospitals_with_point_ordered_comparisons", "median_separated_share", "q1", "q3",
                         "hospitals_separated_from_none", "share_separated_from_none"]].rename(columns={
                "subset": "Subset", "measure": "Measure", "hospitals_with_point_ordered_comparisons": "Hospitals",
                "median_separated_share": "Median share of peers separated", "q1": "Q1", "q3": "Q3",
                "hospitals_separated_from_none": "Separated from none", "share_separated_from_none": "Share separated from none"}),
                fmt={c: pct for c in ("Median share of peers separated", "Q1", "Q3", "Share separated from none")}), ""]
    rs = t("rank_range_summary.csv")
    rs = rs[rs["release_key"] == P].copy()
    rs["measure"] = rs["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S5. Interval-compatible rank ranges", "", "Source: outputs/tables/rank_range_summary.csv.", "",
            md_table(rs[["subset", "measure", "hospitals_in_universes_n_ge_2", "median_width_share_of_n",
                         "share_width_over_half_of_n", "share_full_range", "universes_n_ge_10",
                         "top_ranked_median_worst_rank_share_n_ge_10", "top_ranked_worst_rank_over_half_n_ge_10"]].rename(columns={
                "subset": "Subset", "measure": "Measure", "hospitals_in_universes_n_ge_2": "Hospitals",
                "median_width_share_of_n": "Median width / n", "share_width_over_half_of_n": "Width over half of n",
                "share_full_range": "Full range", "universes_n_ge_10": "States with 10 or more",
                "top_ranked_median_worst_rank_share_n_ge_10": "First-ranked: median worst rank / n",
                "top_ranked_worst_rank_over_half_n_ge_10": "First-ranked: worst rank in bottom half (states)"}),
                fmt={c: pct for c in ("Median width / n", "Width over half of n", "Full range",
                                      "First-ranked: median worst rank / n")}), ""]
    cm = t("compatibility_matrix.csv")
    cm = cm[cm["release_key"] == P]
    out += ["## Table S6. Definitional compatibility matrix, primary release", "", "Source: outputs/tables/compatibility_matrix.csv.",
            "", md_table(cm[["measure_a", "measure_b", "same_measure_id", "same_quantity", "same_unit", "same_window",
                             "same_condition", "same_source_program", "n_checks_failed", "first_failed_check"]].rename(columns={
                "measure_a": "Measure A", "measure_b": "Measure B", "same_measure_id": "Same ID", "same_quantity": "Same quantity",
                "same_unit": "Same unit", "same_window": "Same window", "same_condition": "Same condition",
                "same_source_program": "Same program", "n_checks_failed": "Checks failed", "first_failed_check": "First failure"})), ""]
    cw = t("cross_release_windows.csv")
    cw.loc[cw["measure_id"].str.endswith("HRRP"), "interval_status"] = "not applicable (HRRP file; no intervals; not covered by the notice)"
    out += ["## Table S7. Observation windows across releases", "",
            "Source: outputs/tables/cross_release_windows.csv. Interval status describes the Care Compare release; the HRRP "
            "payment file has no interval columns and is the same file in all three releases. Definition changes are "
            "taken from the FY 2026 IPPS final rule and the CMS answers to frequently asked questions for Summer 2026 "
            "public reporting (config/releases.toml gives the pages).", "",
            md_table(cw[["measure_id", "release_key", "interval_status", "window_start", "window_end", "window_months",
                         "overlap_months_with_primary", "documented_definition_change_since_primary"]].rename(columns={
                "measure_id": "Measure ID", "release_key": "Release", "interval_status": "Interval status",
                "window_start": "Start", "window_end": "End", "window_months": "Months",
                "overlap_months_with_primary": "Months shared with primary",
                "documented_definition_change_since_primary": "Documented definition change"})), ""]
    rc = pd.read_csv(OUTPUTS / "validation" / "reconciliation_categories.csv", dtype={"release_key": str})
    rc = rc[(rc["geography"] == "NATION")]
    out += ["## Table S8. Category counts from hospital rows compared with CMS national files", "",
            "Source: outputs/validation/reconciliation_categories.csv. Difference is hospital rows minus the CMS count.", "",
            md_table(rc[["release_key", "measure_id", "category", "hospital_rows", "cms_aggregate_src", "difference"]].rename(columns={
                "release_key": "Release", "measure_id": "Measure ID", "category": "Category", "hospital_rows": "Hospital rows",
                "cms_aggregate_src": "CMS national file", "difference": "Difference"})), ""]
    rr = pd.read_csv(OUTPUTS / "validation" / "raw_reconstruction.csv", dtype={"facility_id": str})
    out += ["## Table S9. Raw-record reconstruction", "",
            "Source: outputs/validation/raw_reconstruction.csv. Each record was re-read from the raw CSV bytes with an "
            "independent parser and 14 fields were compared.", "",
            md_table(rr[["measure_id", "selection", "facility_id", "source_file", "source_row", "score_src", "lower_src",
                         "upper_src", "footnote_src", "matched"]].rename(columns={
                "measure_id": "Measure ID", "selection": "Selection", "facility_id": "Facility ID", "source_file": "File",
                "source_row": "Row", "score_src": "Score", "lower_src": "Lower", "upper_src": "Upper",
                "footnote_src": "Footnote", "matched": "Matched"})), ""]
    vr = read_json(OUTPUTS / "validation" / "validation_report.json")
    vt = pd.DataFrame([{"Type": c.get("type", "check"), "Kind": c["kind"], "Entry": c["check"],
                        "Result": ("skipped" if c.get("skipped") else ("recorded" if c["passed"] is None
                                                                       else ("passed" if c["passed"] else "failed"))),
                        "Detail": json.dumps(c["detail"])[:220]} for c in vr["checks"]])
    out += ["## Table S10. Validation checks and records", "",
            "Source: outputs/validation/validation_report.json. Checks have a pass condition; records document a "
            "comparison or count and have none.", "", md_table(vt), ""]
    ht = t("compatible_by_hospital_type.csv")
    ht = ht[ht["release_key"] == P].copy()
    ht["measure"] = ht["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S11. Requested, numeric and compatible records by hospital type, primary release", "",
            "Source: outputs/tables/compatible_by_hospital_type.csv. VA records are compared only among VA hospitals "
            "(Table S12).", "",
            md_table(ht[["measure", "hospital_type", "requested", "numeric_score", "compatible"]].rename(columns={
                "measure": "Measure", "hospital_type": "Hospital type", "requested": "Requested",
                "numeric_score": "Numeric score", "compatible": "Compatible"})), ""]
    sg = t("separate_group_summary.csv")
    sg = sg[sg["release_key"] == P].copy()
    sg["measure"] = sg["measure_id"].map(MEASURE_LABEL)
    out += ["## Table S12. VA hospitals compared only with each other, primary release", "",
            "Source: outputs/tables/separate_group_summary.csv. Records that passed every gate except G2b, paired within "
            "the same state; R1 rule. This descriptive comparison was added after Amendment 2 so that G2b was applied as "
            "written (analysis plan, note on the record of 11:27Z).", "",
            md_table(sg[["measure", "records_passing_other_gates", "states", "states_with_2_or_more", "pairs",
                         "point_ordered_pairs", "sep_r1_count", "not_separated_r1_share"]].rename(columns={
                "measure": "Measure", "records_passing_other_gates": "VA records", "states": "States",
                "states_with_2_or_more": "States with 2 or more", "pairs": "Pairs",
                "point_ordered_pairs": "Point-ordered", "sep_r1_count": "Separated R1",
                "not_separated_r1_share": "Not separated"}), fmt={"Not separated": pct}), ""]
    return "\n".join(out)


HTML_TEMPLATE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ title }}</title>
<meta name="description" content="{{ description }}">
<link rel="stylesheet" href="{{ css }}">
</head>
<body class="doc">
<a class="skip" href="#main">Skip to content</a>
<header class="doc-header">
  <nav aria-label="Project"><a href="index.html">Project page</a>{% for href, label in nav %} <span aria-hidden="true">/</span> <a href="{{ href }}">{{ label }}</a>{% endfor %}</nav>
</header>
<main id="main" class="doc-main">
{{ body }}
</main>
<footer class="doc-footer"><p>{{ footer }}</p></footer>
</body>
</html>
"""


def md_to_html(text: str) -> str:
    body = markdown.markdown(text, extensions=["tables", "toc", "attr_list", "sane_lists"], output_format="html5")
    # wrap tables for horizontal scrolling inside their own container
    body = body.replace("<table>", '<div class="table-wrap" tabindex="0"><table>').replace("</table>", "</table></div>")
    return body


def insert_figures(body: str, prefix: str) -> str:
    """Place each figure after the first Results paragraph that cites it; legends stay as text at the end."""
    files = {1: "fig1_gate_flow", 2: "fig2_lead_example", 3: "fig3_passing_example", 4: "fig4_separation",
             5: "fig5_rank_width", 6: "fig6_windows"}
    legends = {}
    for m in re.finditer(r"<p><strong>Figure (\d)\. (.*?)</strong>(.*?)</p>", body, flags=re.S):
        legends[int(m.group(1))] = (re.sub(r"<[^>]+>", "", m.group(2)).strip(), m.group(0))
    start = body.find('id="results"')
    end = body.find('id="discussion"')
    for k in sorted(files):
        title, legend_html = legends.get(k, (f"Figure {k}", ""))
        fig = (f'<figure id="figure-{k}"><img src="{prefix}{files[k]}.svg" alt="{html.escape(title)}" loading="lazy" '
               f'width="760"><figcaption>{legend_html.replace("<p>", "").replace("</p>", "")}</figcaption></figure>')
        pattern = re.compile(r"<p>(?:(?!</p>).)*?Figure " + str(k) + r"\b(?:(?!</p>).)*?</p>", re.S)
        m = pattern.search(body, start, end if end > 0 else len(body))
        if m:
            body = body[:m.end()] + fig + body[m.end():]
            end = body.find('id="discussion"')
    return body


def _add_line_and_page_numbers(doc) -> None:
    """Continuous line numbering and a centered page number in the footer (BMC formatting)."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    for section in doc.sections:
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:restart"), "continuous")
        ln.set(qn("w:distance"), "360")
        section._sectPr.append(ln)
        par = section.footer.paragraphs[0]
        par.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = par.add_run()
        for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
            if tag:
                el = OxmlElement("w:fldChar")
                el.set(qn("w:fldCharType"), tag)
            else:
                el = OxmlElement("w:instrText")
                el.set(qn("xml:space"), "preserve")
                el.text = text
            run._r.append(el)


def write_docx(md_text: str, path: Path, figure_dir: Path | None = None) -> None:
    """Word copy for submission: double spacing, line and page numbers, legends without embedded images."""
    from docx import Document
    from docx.enum.text import WD_LINE_SPACING
    from docx.shared import Pt

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.font.size = Pt(11)
    st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
    _add_line_and_page_numbers(doc)

    def add_runs(par, text):
        for part in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", text):
            if not part:
                continue
            if part.startswith("**") and part.endswith("**"):
                par.add_run(part[2:-2]).bold = True
            elif part.startswith("*") and part.endswith("*"):
                par.add_run(part[1:-1]).italic = True
            else:
                par.add_run(part)

    lines = md_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("#"):
            level = len(line) - len(line.lstrip("#"))
            doc.add_heading(line.lstrip("#").strip(), level=min(level, 4))
        elif line.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            rows = [[c.strip() for c in r.strip("|").split("|")] for r in block if not re.match(r"^\|[-| ]+\|$", r)]
            table = doc.add_table(rows=len(rows), cols=len(rows[0]))
            table.style = "Table Grid"
            for ri, r in enumerate(rows):
                for ci, c in enumerate(r):
                    cell = table.cell(ri, ci)
                    cell.text = ""
                    add_runs(cell.paragraphs[0], c)
                    for run in cell.paragraphs[0].runs:
                        run.font.size = Pt(8)
                        if ri == 0:
                            run.bold = True
            continue
        elif line.startswith("- "):
            add_runs(doc.add_paragraph(style="List Bullet"), line[2:])
        elif re.match(r"^\d+\. ", line):
            add_runs(doc.add_paragraph(), line)
        elif line.strip():
            add_runs(doc.add_paragraph(), line)
        i += 1
    core = doc.core_properties
    core.author = "Animesh Bose"
    core.title = lines[0].lstrip("# ").strip()
    doc.save(path)
    from .editorial_format import finish
    path.write_bytes(finish(path.read_bytes(), supplement=path.name.startswith(("supplement", "ESM2")))[0])


def _private_author() -> dict:
    """Contact details live in .local/author.json, which is never packaged or published."""
    path = ROOT / ".local" / "author.json"
    return json.loads(path.read_text()) if path.exists() else {}


def prose_words(md: str) -> int:
    """Words in Markdown prose, excluding table rows, heading markers and emphasis markup."""
    kept = []
    for line in md.splitlines():
        if line.startswith("|"):
            continue
        line = re.sub(r"^#+\s*", "", line)
        line = line.replace("**", "")
        kept.append(line)
    return len(" ".join(kept).split())


def run() -> dict:
    ctx = context(public=True)
    ms = render_template(MS_DIR / "manuscript.md.j2", ctx)
    (MS_DIR / "manuscript.md").write_text(ms, encoding="utf-8")
    sup = build_supplement(ctx)
    (MS_DIR / "supplement.md").write_text(sup, encoding="utf-8")
    write_docx(sup, MS_DIR / "supplement.docx")
    # Submission copy: same text, with the corresponding author's email on the title page
    ms_sub = render_template(MS_DIR / "manuscript.md.j2", context(public=False))
    write_docx(ms_sub, MS_DIR / "manuscript.docx")
    listed = re.findall(r"^Additional file (\d+): .*\(([^()]+)\)\.$", ms_sub.split("## Additional files")[1], flags=re.M)
    (OUTPUTS / "report").mkdir(parents=True, exist_ok=True)
    write_json(OUTPUTS / "report" / "additional_files.json", [{"number": int(a), "file": b} for a, b in listed])
    # Submission documents (private: copied to handoff/, never to the public site or source archive)
    abstract = ms.split("## Abstract")[1].split("**Keywords:**")[0]
    sub_ctx = dict(ctx, abstract_words=len(re.sub(r"\*\*[A-Za-z]+:\*\*", "", abstract).split()),
                   main_words=prose_words(ms_sub.split("## Background")[1].split("## List of abbreviations")[0]),
                   n_tables=len(re.findall(r"^\*\*Table \d+\.", ms, flags=re.M)),
                   n_figures=len(re.findall(r"^\*\*Figure \d+\.", ms, flags=re.M)),
                   corresponding_email=_private_author().get("corresponding_email", "[corresponding email]"))
    (ROOT / "README.md").write_text(render_template(ROOT / "README.md.j2", ctx), encoding="utf-8")
    for tpl_path in sorted((ROOT / "submission").glob("*.md.j2")):
        (tpl_path.parent / tpl_path.name[:-3]).write_text(render_template(tpl_path, sub_ctx), encoding="utf-8")
    css = "assets/report.css"
    title = ms.splitlines()[0].lstrip("# ").strip()
    pages = {}
    env = jinja2.Environment(autoescape=False)
    tpl = env.from_string(HTML_TEMPLATE)
    footer = ("Built from the frozen outputs of run "
              f"{read_json(OUTPUTS / 'run_manifest.json')['run_id']}. CMS data are U.S. federal public data.")
    body = insert_figures(md_to_html(ms), "assets/figures/")
    pages["report.html"] = tpl.render(title="Hospital comparability report", description=title, css=css, body=body,
                                      nav=[("supplement.html", "Supplementary tables")], footer=footer)
    pages["supplement.html"] = tpl.render(title="Hospital comparability supplement",
                                          description="Supplementary tables for the hospital comparability report", css=css,
                                          body=md_to_html(sup), nav=[("report.html", "Report")], footer=footer)
    out_dir = OUTPUTS / "report"
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, text in pages.items():
        (out_dir / name).write_text(text, encoding="utf-8")
    return {"manuscript_md": "manuscript/manuscript.md", "supplement_md": "manuscript/supplement.md",
            "docx": "manuscript/manuscript.docx", "html": sorted(pages)}


if __name__ == "__main__":
    print(json.dumps(run(), indent=1))
