"""Analyze stage: gates, pairwise separation, rank ranges, sensitivity analyses
and release comparisons.

Refuses to run unless docs/analysis_plan.md matches its lock file, so the plan
demonstrably predates the results produced here.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd

from . import __version__
from .acquire import MANIFEST, verify_manifest
from .common import DB_PATH, ROOT, SQL_DIR, TABLES, load_config, read_json, rel, sha256_file, utc_now, write_json

PLAN = ROOT / "docs" / "analysis_plan.md"
PLAN_LOCK = ROOT / "docs" / "analysis_plan.lock.json"
GATES = ["g0_release", "g1_identity", "g2_definition", "g2b_population", "g3_window", "g4_score", "g5_interval",
         "g6_footnote"]
GATE_LABELS = {
    "g0_release": "G0 release intervals usable",
    "g1_identity": "G1 identity and uniqueness",
    "g2_definition": "G2 measure definition",
    "g2b_population": "G2b population",
    "g3_window": "G3 observation window",
    "g4_score": "G4 numeric score reported",
    "g5_interval": "G5 usable interval",
    "g6_footnote": "G6 no blocking footnote",
}


class AnalyzeError(RuntimeError):
    pass


def check_plan_lock() -> dict:
    if not PLAN_LOCK.exists():
        raise AnalyzeError("docs/analysis_plan.lock.json missing: lock the plan before analysis")
    lock = read_json(PLAN_LOCK)
    if sha256_file(PLAN) != lock["sha256"]:
        raise AnalyzeError("analysis_plan.md changed after locking; record an amendment and re-lock")
    return lock


def frac(num, den):
    return float(num) / float(den) if den else float("nan")


def primary_release(con: sqlite3.Connection) -> str:
    rows = con.execute("SELECT release_key FROM releases WHERE role='primary'").fetchall()
    if len(rows) != 1:
        raise AnalyzeError(f"expected exactly one primary release, found {rows}")
    return rows[0][0]


def gate_flow(g: pd.DataFrame, hosp: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    rows = []
    gen_state = hosp.groupby(["release_key", "state"]).size()
    gen_rel = hosp.groupby("release_key").size()
    for keys, grp in g.groupby(by, sort=True):
        rec = dict(zip(by, keys if isinstance(keys, tuple) else (keys,)))
        n = len(grp)
        rec["requested_records"] = n
        mask = np.ones(n, dtype=bool)
        for gate in GATES:
            mask &= grp[gate].to_numpy() == 1
            rec[f"pass_through_{gate}"] = int(mask.sum())
        for gate in GATES:
            rec[f"independent_pass_{gate}"] = int(grp[gate].sum())
        rec["numeric_score_without_usable_interval"] = int(((grp["g4_score"] == 1) & (grp["g5_interval"] == 0)).sum())
        rec["compatible"] = int(grp["compatible"].sum())
        rec["compatible_strict"] = int(((grp["compatible"] == 1) & (grp["caution_flag"] == 0)).sum())
        rec["compatible_share_of_requested"] = frac(rec["compatible"], n)
        if "state" in rec:
            broader = int(gen_state.get((rec["release_key"], rec["state"]), 0))
        else:
            broader = int(gen_rel.get(rec["release_key"], 0))
        rec["broader_denominator_general_info"] = broader
        rec["absent_from_measure_file"] = broader - n
        rec["compatible_share_of_broader"] = frac(rec["compatible"], broader)
        rec["compatible_strict_share_of_requested"] = frac(rec["compatible_strict"], n)
        rows.append(rec)
    return pd.DataFrame(rows)


def pair_summary(p: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    rows = []
    for keys, grp in p.groupby(by, sort=True):
        rec = dict(zip(by, keys if isinstance(keys, tuple) else (keys,)))
        po = grp[grp["point_ordered"] == 1]
        rec["pairs"] = len(grp)
        rec["point_ordered_pairs"] = len(po)
        rec["tied_pairs"] = int((grp["point_ordered"] == 0).sum())
        for rule in ("sep_r1", "sep_r2", "sep_r3", "official_opposite"):
            rec[f"{rule}_count"] = int(po[rule].sum())
            rec[f"{rule}_share"] = frac(po[rule].sum(), len(po))
        rec["not_separated_r1_count"] = int(len(po) - po["sep_r1"].sum())
        rec["not_separated_r1_share"] = frac(len(po) - po["sep_r1"].sum(), len(po))
        rows.append(rec)
    return pd.DataFrame(rows)


def hospital_level(p: pd.DataFrame) -> pd.DataFrame:
    po = p[p["point_ordered"] == 1]
    cols = ["subset", "release_key", "measure_id", "state"]
    left = po[cols + ["facility_a", "sep_r1"]].rename(columns={"facility_a": "facility_id"})
    right = po[cols + ["facility_b", "sep_r1"]].rename(columns={"facility_b": "facility_id"})
    both = pd.concat([left, right], ignore_index=True)
    out = (both.groupby(cols + ["facility_id"])
               .agg(point_ordered_comparisons=("sep_r1", "size"), separated_r1=("sep_r1", "sum"))
               .reset_index())
    out["separated_share"] = out["separated_r1"] / out["point_ordered_comparisons"]
    return out


def describe(series: pd.Series) -> dict:
    s = series.dropna()
    if s.empty:
        return {"n": 0, "median": None, "q1": None, "q3": None, "min": None, "max": None}
    return {"n": int(s.size), "median": float(s.median()), "q1": float(s.quantile(0.25)),
            "q3": float(s.quantile(0.75)), "min": float(s.min()), "max": float(s.max())}


def months_overlap(a_start: str, a_end: str, b_start: str, b_end: str) -> int:
    s = max(date.fromisoformat(a_start), date.fromisoformat(b_start))
    e = min(date.fromisoformat(a_end), date.fromisoformat(b_end))
    if e < s:
        return 0
    return (e.year - s.year) * 12 + (e.month - s.month) + 1


def compatibility_matrix(con: sqlite3.Connection, release_key: str) -> pd.DataFrame:
    md = pd.read_sql("SELECT d.*, w.modal_start, w.modal_end, w.window_months FROM measure_dictionary d "
                     "JOIN measure_windows w ON w.measure_id = d.measure_id AND w.release_key = ? "
                     "ORDER BY d.measure_id", con, params=(release_key,))
    program = {"unplanned_visits": "Care Compare", "complications_deaths": "Care Compare", "hrrp": "HRRP payment program"}
    rows = []
    recs = md.to_dict("records")
    for a in recs:
        for b in recs:
            if a["measure_id"] >= b["measure_id"]:
                continue
            checks = [
                ("same_measure_id", a["measure_id"] == b["measure_id"]),
                ("same_quantity", a["quantity"] == b["quantity"]),
                ("same_unit", a["unit"] == b["unit"]),
                ("same_window", (a["modal_start"], a["modal_end"]) == (b["modal_start"], b["modal_end"])),
                ("same_condition", a["condition"] == b["condition"]),
                ("same_source_program", program[a["dataset_key"]] == program[b["dataset_key"]]),
            ]
            first = next((name for name, ok in checks if not ok), None)
            rows.append({"release_key": release_key, "measure_a": a["measure_id"], "measure_b": b["measure_id"],
                         **{name: bool(ok) for name, ok in checks},
                         "n_checks_failed": sum(not ok for _, ok in checks),
                         "window_a": f"{a['modal_start']} to {a['modal_end']} ({a['window_months']} months)",
                         "window_b": f"{b['modal_start']} to {b['modal_end']} ({b['window_months']} months)",
                         "quantity_a": a["quantity"], "quantity_b": b["quantity"],
                         "comparable": first is None, "first_failed_check": first or ""})
    return pd.DataFrame(rows)


def cross_release(con: sqlite3.Connection, primary: str) -> pd.DataFrame:
    w = pd.read_sql("SELECT w.*, d.study_role FROM measure_windows w JOIN measure_dictionary d USING (measure_id) "
                    "ORDER BY measure_id, release_key", con)
    releases = pd.read_sql("SELECT * FROM releases", con)
    changes = pd.read_sql("SELECT * FROM definition_changes", con)
    rows = []
    for mid, grp in w.groupby("measure_id"):
        base = grp[grp["release_key"] == primary].iloc[0]
        for _, r in grp.iterrows():
            ch = changes[(changes["measure_id"] == mid) & (changes["to_release"] <= r["release_key"])
                         & (changes["from_release"] >= primary) & (r["release_key"] != primary)]
            rel_row = releases[releases["release_key"] == r["release_key"]].iloc[0]
            rows.append({
                "measure_id": mid, "study_role": r["study_role"], "release_key": r["release_key"],
                "release_role": rel_row["role"], "interval_status": rel_row["interval_status"],
                "window_start": r["modal_start"], "window_end": r["modal_end"], "window_months": r["window_months"],
                "official_start": r["official_start"], "official_end": r["official_end"],
                "window_matches_official": (r["modal_start"], r["modal_end"]) == (r["official_start"], r["official_end"]),
                "overlap_months_with_primary": months_overlap(base["modal_start"], base["modal_end"],
                                                              r["modal_start"], r["modal_end"]),
                "same_window_as_primary": (r["modal_start"], r["modal_end"]) == (base["modal_start"], base["modal_end"]),
                "documented_definition_change_since_primary": "; ".join(ch["change"].tolist()),
                "definition_change_source": "; ".join(ch["source"].tolist()),
            })
    return pd.DataFrame(rows)


def facility_presence(con: sqlite3.Connection) -> pd.DataFrame:
    sets = {}
    for rk, in con.execute("SELECT release_key FROM releases ORDER BY release_key"):
        sets[rk] = {r[0] for r in con.execute(
            "SELECT DISTINCT facility_id FROM records WHERE release_key=? AND dataset_key='unplanned_visits'", (rk,))}
    keys = sorted(sets)
    rows = []
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            rows.append({"release_a": a, "release_b": b, "facilities_a": len(sets[a]), "facilities_b": len(sets[b]),
                         "in_both": len(sets[a] & sets[b]), "only_in_a": len(sets[a] - sets[b]),
                         "only_in_b": len(sets[b] - sets[a]),
                         "only_in_a_ids": " ".join(sorted(sets[a] - sets[b])),
                         "only_in_b_ids": " ".join(sorted(sets[b] - sets[a]))})
    return pd.DataFrame(rows)


def select_examples(rr: pd.DataFrame, pairs: pd.DataFrame, gates: pd.DataFrame, cfg: dict, primary: str) -> dict:
    measure = cfg["primary_example_measure"]
    rp = rr[(rr["subset"] == "primary") & (rr["release_key"] == primary) & (rr["measure_id"] == measure)]
    counts = rp.groupby("state").size().reset_index(name="n")
    eligible = counts[counts["n"] >= cfg["example_min_hospitals"]].sort_values(["n", "state"]).reset_index(drop=True)
    if eligible.empty:
        return {"rule_failed": "no state meets the minimum size"}
    pos = (len(eligible) - 1) // 2
    state = eligible.loc[pos, "state"]
    median_n = int(eligible.loc[pos, "n"])
    tied = sorted(eligible.loc[eligible["n"] == median_n, "state"].tolist())
    sign = 1 if gates.loc[gates["measure_id"] == measure, "favorable"].iloc[0] == "lower" else -1
    hosp = (rp[rp["state"] == state].assign(_o=lambda d: d["score_num"] * sign)
            .sort_values(["_o", "facility_id"]).drop(columns="_o").reset_index(drop=True))
    top = hosp.iloc[0]
    g = gates[(gates["release_key"] == primary) & (gates["measure_id"] == measure) & (gates["state"] == state)]
    ps = pairs[(pairs["subset"] == "primary") & (pairs["release_key"] == primary) & (pairs["measure_id"] == measure)
               & (pairs["state"] == state)]
    # Passing pair: prespecified rule on the lead measure, then the fallback order
    # fixed in Amendment 1 of docs/analysis_plan.md (MORT_30_HF, then EDAC_30_HF, same state).
    passing = None
    attempts = []
    for pm in (measure, "MORT_30_HF", "EDAC_30_HF"):
        pps = pairs[(pairs["subset"] == "primary") & (pairs["release_key"] == primary) & (pairs["measure_id"] == pm)
                    & (pairs["state"] == state)]
        sep = pps[pps["sep_r1"] == 1].sort_values(["gap_scaled", "facility_a", "facility_b"], ascending=[False, True, True])
        attempts.append({"measure_id": pm, "separated_pairs": int(len(sep))})
        if sep.empty:
            continue
        gpm = gates[(gates["release_key"] == primary) & (gates["measure_id"] == pm) & (gates["state"] == state)]
        decimals = int(gpm["reported_decimals"].dropna().iloc[0])
        best = sep.iloc[0]
        passing = {
            "measure_id": pm, "rule_source": "prespecified" if pm == measure else "amendment_1_fallback",
            "facility_a": best["facility_a"], "facility_b": best["facility_b"],
            "score_a": float(best["score_a"]), "lower_a": float(best["lower_a"]), "upper_a": float(best["upper_a"]),
            "score_b": float(best["score_b"]), "lower_b": float(best["lower_b"]), "upper_b": float(best["upper_b"]),
            "gap": float(best["gap_scaled"]) / 10 ** decimals,
            "pairs_in_state": int(len(pps)), "point_ordered_in_state": int(pps["point_ordered"].sum()),
            "separated_in_state": int(len(sep)),
            "gate_decisions": gpm[gpm["facility_id"].isin([best["facility_a"], best["facility_b"]])][
                ["facility_id", "facility_name", "hospital_type", "score_src", "lower_src", "upper_src", "footnote_src",
                 "compared_to_national_src"] + GATES + ["reason_code"]].to_dict("records"),
        }
        break
    tie_or_overlap_with_top = ps[((ps["facility_a"] == top["facility_id"]) | (ps["facility_b"] == top["facility_id"]))]
    return {
        "rule": (f"{measure}, release {primary}: among states with at least {cfg['example_min_hospitals']} compatible "
                 "hospitals, the lower-median state by compatible count (ties alphabetical); top hospital = lowest score, "
                 "ties by Facility ID; passing pair = R1-separated pair with the largest interval gap, ties by Facility IDs"),
        "release_key": primary,
        "measure_id": measure,
        "eligible_states": eligible.to_dict("records"),
        "state": state,
        "selection_position": int(pos),
        "median_count": median_n,
        "states_tied_at_median_count": tied,
        "n_compatible": int(len(hosp)),
        "requested_records": int(len(g)),
        "gate_reason_counts": g["reason_code"].value_counts().sort_index().to_dict(),
        "top_hospital": {k: (v.item() if hasattr(v, "item") else v) for k, v in top[[
            "facility_id", "facility_name", "score_num", "lower_num", "upper_num", "point_rank", "best_rank",
            "worst_rank", "n", "official_category"]].items()},
        "top_hospital_pairs": {
            "comparisons": int(len(tie_or_overlap_with_top)),
            "point_ordered": int(tie_or_overlap_with_top["point_ordered"].sum()),
            "separated_r1": int((tie_or_overlap_with_top["point_ordered"] * tie_or_overlap_with_top["sep_r1"]).sum()),
        },
        "hospitals": hosp[["facility_id", "facility_name", "score_num", "lower_num", "upper_num", "point_rank",
                           "best_rank", "worst_rank", "official_category"]].to_dict("records"),
        "state_pairs": {
            "pairs": int(len(ps)),
            "point_ordered": int(ps["point_ordered"].sum()),
            "separated_r1_among_point_ordered": int(ps.loc[ps["point_ordered"] == 1, "sep_r1"].sum()),
        },
        "passing_pair": passing,
        "passing_pair_attempts": attempts,
    }


def run(db_path: Path = DB_PATH, tables_dir: Path = TABLES, write_manifest: bool = True) -> dict:
    lock = check_plan_lock()
    problems = verify_manifest()
    if problems:
        raise AnalyzeError("; ".join(problems))
    cfg = load_config()["analysis"]
    tables_dir.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db_path)
    con.executescript((SQL_DIR / "02_gates.sql").read_text())
    con.executescript((SQL_DIR / "03_pairs_ranks.sql").read_text())
    con.executescript((SQL_DIR / "04_population_groups.sql").read_text())
    con.commit()
    primary = primary_release(con)

    gates = pd.read_sql("SELECT * FROM gate_results ORDER BY release_key, measure_id, state, facility_id", con)
    hosp = pd.read_sql("SELECT * FROM hospitals ORDER BY release_key, facility_id", con)
    pairs_all = pd.read_sql("SELECT * FROM pairs ORDER BY release_key, measure_id, state, facility_a, facility_b", con)
    rr = pd.read_sql("SELECT * FROM rank_ranges ORDER BY subset, release_key, measure_id, state, facility_id", con)

    p_primary = pairs_all.assign(subset="primary")
    p_strict = pairs_all[(pairs_all["caution_a"] == 0) & (pairs_all["caution_b"] == 0)].assign(subset="strict")
    pairs = pd.concat([p_primary, p_strict], ignore_index=True)

    out: dict[str, pd.DataFrame] = {}
    out["gate_flow_national"] = gate_flow(gates, hosp, ["release_key", "measure_id"])
    out["gate_flow_by_state"] = gate_flow(gates, hosp, ["release_key", "measure_id", "state"])
    fr = gates.assign(first_failed_gate=gates["first_failed_gate"].fillna("none"))
    out["failure_reasons"] = (fr.groupby(["release_key", "measure_id", "first_failed_gate", "reason_code"])
                              .size().reset_index(name="records")
                              .sort_values(["release_key", "measure_id", "records"], ascending=[True, True, False]))
    out["availability_states"] = (gates.groupby(["release_key", "measure_id", "availability_state"]).size()
                                  .reset_index(name="records"))
    out["compatible_by_hospital_type"] = (gates.groupby(["release_key", "measure_id", "hospital_type"])
                                          .agg(requested=("record_id", "size"), compatible=("compatible", "sum"),
                                               numeric_score=("g4_score", "sum"))
                                          .reset_index())
    out["pair_summary_national"] = pair_summary(pairs, ["subset", "release_key", "measure_id"])
    out["pair_summary_by_state"] = pair_summary(pairs, ["subset", "release_key", "measure_id", "state"])

    sw_rows = []
    for (subset, rk, mid), grp in out["pair_summary_by_state"].groupby(["subset", "release_key", "measure_id"]):
        g2 = grp[grp["point_ordered_pairs"] > 0]
        d = describe(g2["not_separated_r1_share"])
        sw_rows.append({"subset": subset, "release_key": rk, "measure_id": mid, "states_with_point_ordered_pairs": d["n"],
                        "median_state_not_separated_share": d["median"], "q1": d["q1"], "q3": d["q3"],
                        "min_state_share": d["min"], "max_state_share": d["max"]})
    out["state_weighted_summary"] = pd.DataFrame(sw_rows)

    hl = hospital_level(pairs)
    out["hospital_level"] = hl
    hl_rows = []
    for (subset, rk, mid), grp in hl.groupby(["subset", "release_key", "measure_id"]):
        d = describe(grp["separated_share"])
        hl_rows.append({"subset": subset, "release_key": rk, "measure_id": mid,
                        "hospitals_with_point_ordered_comparisons": d["n"], "median_separated_share": d["median"],
                        "q1": d["q1"], "q3": d["q3"],
                        "hospitals_separated_from_none": int((grp["separated_r1"] == 0).sum()),
                        "share_separated_from_none": frac((grp["separated_r1"] == 0).sum(), len(grp))})
    out["hospital_level_summary"] = pd.DataFrame(hl_rows)

    rr["range_width"] = rr["worst_rank"] - rr["best_rank"] + 1
    rr["width_share_of_n"] = rr["range_width"] / rr["n"]
    out["rank_ranges"] = rr
    rr_rows = []
    fav = dict(pd.read_sql("SELECT measure_id, favorable FROM measure_dictionary", con).values)
    for (subset, rk, mid), grp in rr[rr["n"] >= 2].groupby(["subset", "release_key", "measure_id"]):
        grp = grp.assign(_o=grp["score_num"] * (1 if fav[mid] == "lower" else -1))
        tops = grp.sort_values(["state", "_o", "facility_id"]).groupby("state").head(1)
        tops10 = tops[tops["n"] >= 10]
        rr_rows.append({
            "subset": subset, "release_key": rk, "measure_id": mid,
            "hospitals_in_universes_n_ge_2": int(len(grp)), "universes_n_ge_2": int(grp["state"].nunique()),
            "median_width_share_of_n": float(grp["width_share_of_n"].median()),
            "share_width_over_half_of_n": frac((grp["width_share_of_n"] > 0.5).sum(), len(grp)),
            "share_full_range": frac((grp["range_width"] == grp["n"]).sum(), len(grp)),
            "universes_n_ge_10": int(len(tops10)),
            "top_ranked_median_worst_rank_share_n_ge_10": float((tops10["worst_rank"] / tops10["n"]).median()) if len(tops10) else None,
            "top_ranked_worst_rank_over_half_n_ge_10": int((tops10["worst_rank"] > tops10["n"] / 2).sum()),
        })
    out["rank_range_summary"] = pd.DataFrame(rr_rows)
    out["compatibility_matrix"] = pd.concat([compatibility_matrix(con, rk) for rk, in
                                             con.execute("SELECT release_key FROM releases ORDER BY release_key")],
                                            ignore_index=True)
    out["cross_release_windows"] = cross_release(con, primary)
    out["facility_presence"] = facility_presence(con)
    out["measure_windows"] = pd.read_sql("SELECT * FROM measure_windows ORDER BY release_key, measure_id", con)
    out["measure_dictionary"] = pd.read_sql("SELECT * FROM measure_dictionary ORDER BY measure_id", con)
    out["releases"] = pd.read_sql("SELECT * FROM releases ORDER BY release_key", con)
    out["official_category_counts"] = (gates.groupby(["release_key", "measure_id", "compared_to_national_src"]).size()
                                       .reset_index(name="records"))
    sg_records = pd.read_sql("SELECT release_key, measure_id, hospital_type, state, COUNT(*) AS n FROM separate_group_oriented "
                             "GROUP BY release_key, measure_id, hospital_type, state", con)
    sg_pairs = pd.read_sql("SELECT * FROM separate_group_pairs", con)
    sg_rows = []
    for (rk, mid, ht), grp in sg_records.groupby(["release_key", "measure_id", "hospital_type"]):
        pp = sg_pairs[(sg_pairs["release_key"] == rk) & (sg_pairs["measure_id"] == mid) & (sg_pairs["hospital_type"] == ht)]
        po = pp[pp["point_ordered"] == 1]
        sg_rows.append({"release_key": rk, "measure_id": mid, "hospital_type": ht,
                        "records_passing_other_gates": int(grp["n"].sum()), "states": int(len(grp)),
                        "states_with_2_or_more": int((grp["n"] >= 2).sum()), "pairs": int(len(pp)),
                        "point_ordered_pairs": int(len(po)), "sep_r1_count": int(po["sep_r1"].sum()),
                        "not_separated_r1_share": frac(len(po) - po["sep_r1"].sum(), len(po))})
    ref_rows = []
    for rk, mid, val in con.execute("SELECT release_key, measure_id, national_rate FROM national_reference "
                                    "WHERE geography='NATION' ORDER BY release_key, measure_id"):
        ref_rows.append({"release_key": rk, "item": "cms_national_value", "measure_id": mid, "value": val})
    for rk, n_fac in con.execute("SELECT release_key, COUNT(DISTINCT facility_id) FROM records "
                                 "WHERE dataset_key='unplanned_visits' GROUP BY release_key"):
        ref_rows.append({"release_key": rk, "item": "facilities_in_outcome_files", "measure_id": "", "value": n_fac})
    for rk, n_h in con.execute("SELECT release_key, COUNT(*) FROM hospitals GROUP BY release_key"):
        ref_rows.append({"release_key": rk, "item": "hospitals_in_general_information", "measure_id": "", "value": n_h})
    for rk, mid, n29 in con.execute(
            "SELECT r.release_key, r.measure_id, COUNT(*) FROM records r JOIN record_footnotes f ON f.record_id=r.record_id "
            "WHERE f.code='29' AND r.score_state='numeric' GROUP BY r.release_key, r.measure_id"):
        ref_rows.append({"release_key": rk, "item": "footnote_29_with_numeric_score", "measure_id": mid, "value": n29})
    out["reference_values"] = pd.DataFrame(ref_rows)
    out["separate_group_summary"] = pd.DataFrame(sg_rows, columns=[
        "release_key", "measure_id", "hospital_type", "records_passing_other_gates", "states", "states_with_2_or_more",
        "pairs", "point_ordered_pairs", "sep_r1_count", "not_separated_r1_share"])

    for name, df in out.items():
        df.to_csv(tables_dir / f"{name}.csv", index=False, float_format="%.10g")

    comp = pd.read_sql("SELECT record_id, release_key, measure_id, state, facility_id, score_num, lower_num, upper_num, "
                       "caution_flag, reported_decimals, favorable FROM compat_oriented "
                       "ORDER BY release_key, measure_id, state, facility_id", con)
    comp.to_csv(tables_dir / "compatible_records.csv", index=False, float_format="%.10g")
    gates.to_csv(tables_dir / "gate_results.csv", index=False, float_format="%.10g")
    write_json(tables_dir / "examples.json", select_examples(rr, pairs, gates, cfg, primary))
    con.close()

    result = {"primary_release": primary,
              "tables": sorted(f"{k}.csv" for k in out) + ["compatible_records.csv", "gate_results.csv", "examples.json"]}
    if write_manifest:
        man = read_json(MANIFEST)
        run_manifest = {
            "run_id": None,
            "completed_utc": utc_now(),
            "package_version": __version__,
            "primary_release": primary,
            "plan_sha256": lock["sha256"],
            "plan_locked_utc": lock["locked_utc"],
            "config_sha256": {rel(p): sha256_file(p) for p in sorted((ROOT / "config").iterdir()) if p.is_file()},
            "sql_sha256": {rel(p): sha256_file(p) for p in sorted(SQL_DIR.glob("*.sql"))},
            "source_sha256": {**{k: v["sha256"] for k, v in man["datasets"].items()},
                              **{f"{ak}/{mk}": mv["sha256"] for ak, a in man.get("archives", {}).items()
                                 for mk, mv in a["members"].items()}},
            "outputs_sha256": {f.name: sha256_file(f) for f in sorted(tables_dir.iterdir()) if f.is_file()},
        }
        basis = json.dumps({k: run_manifest[k] for k in ("plan_sha256", "config_sha256", "sql_sha256", "source_sha256")},
                           sort_keys=True).encode()
        stamp = run_manifest["completed_utc"].replace(":", "").replace("-", "")[:15]
        run_manifest["run_id"] = f"hc-{stamp}-{hashlib.sha256(basis).hexdigest()[:10]}"
        write_json(ROOT / "outputs" / "run_manifest.json", run_manifest)
        result["run_id"] = run_manifest["run_id"]
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=1))
