"""Render stage: figures, evidence map, review workbook, manuscript and project page."""

from __future__ import annotations

import json
import platform
import sqlite3
import subprocess
import sys
from importlib import metadata

from .common import OUTPUTS, utc_now, write_json


def runtime_manifest() -> dict:
    def ver(pkg: str) -> str | None:
        try:
            return metadata.version(pkg)
        except metadata.PackageNotFoundError:
            return None

    def cmd(args: list[str]) -> str | None:
        try:
            out = subprocess.run(args, capture_output=True, text=True, timeout=60)
            return (out.stdout or out.stderr).strip().splitlines()[0] if out.returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            return None

    man = {
        "recorded_utc": utc_now(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "sqlite": sqlite3.sqlite_version,
        "packages": {p: ver(p) for p in ("pandas", "numpy", "requests", "openpyxl", "matplotlib", "jinja2", "markdown",
                                         "python-docx", "pytest", "pypdf")},
        "r": cmd(["Rscript", "--version"]),
        "sql_engine": "SQLite through Python's sqlite3 module. The project does not require PostgreSQL and creates no "
                      "PostgreSQL database.",
        "postgresql_on_path": cmd(["psql", "--version"]),
        "quarto_on_path": cmd(["quarto", "--version"]),
        "pandoc_on_path": cmd(["pandoc", "--version"]),
        "report_renderer": "Jinja2 templates with Python-Markdown for HTML and python-docx for the Word copy. Quarto and "
                           "pandoc are not used by the pipeline.",
        "figures": "matplotlib (Agg backend), PNG at 200 dpi and SVG",
        "docker": "not used",
    }
    write_json(OUTPUTS / "runtime_manifest.json", man)
    return man


def run() -> dict:
    from . import claims, figures, report, site

    out = {"figures": figures.run()["figures"]}
    out["claims"] = len(claims.build()["claims"])
    try:
        from . import workbook

        out["workbook"] = workbook.run()
    except ImportError:
        out["workbook"] = "workbook module not present"
    out["report"] = report.run()
    out["site"] = site.build()
    out["runtime"] = runtime_manifest()["report_renderer"]
    return out


if __name__ == "__main__":
    print(json.dumps(run(), indent=1, default=str))
