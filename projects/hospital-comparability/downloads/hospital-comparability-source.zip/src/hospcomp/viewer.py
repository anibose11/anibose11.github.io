"""Static data files for the interactive viewer on the project page.

export(out_dir) writes compact JSON files that the browser component in
site_src/viewer/ reads. Every value is copied from the frozen SQLite database
or from the output tables of the recorded run; the browser only filters and
sorts what is written here.

Files written:
  viewer_index.json            releases, measures, windows, national reference
                               values, gate and reason labels, footnote texts and
                               per-state record counts
  r<release>_<measure>.json    one file per exported release and measure, with
                               the records grouped by state and the state pair
                               counts (subset 'primary')

Record rows are arrays in the column order given by the file's "cols" list.
Columns listed in "lk" hold an integer index into that lookup list. The three
source-string columns (score_src, lower_src, upper_src) hold the source text
when it is numeric and an integer index into lk["src"] when it is not (for
example "Not Available"). Trailing null values are dropped from each row, so a
missing position means null.
"""

from __future__ import annotations

import json
import math
import sqlite3
import sys
from pathlib import Path

import pandas as pd

from .common import DB_PATH, OUTPUTS, TABLES, read_json

STUDY_MEASURES = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI"]
CURRENT_RELEASE = "2026-09-30"
CURRENT_MEASURES = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF"]
SIZE_LIMIT_BYTES = 6 * 1024 * 1024

GATE_ORDER = ["G0", "G1", "G2", "G2b", "G3", "G4", "G5", "G6"]
GATE_COLUMNS = {
    "G0": "g0_release", "G1": "g1_identity", "G2": "g2_definition", "G2b": "g2b_population",
    "G3": "g3_window", "G4": "g4_score", "G5": "g5_interval", "G6": "g6_footnote",
}
GATE_LABELS = {
    "G0": "G0 release",
    "G1": "G1 identity",
    "G2": "G2 measure definition",
    "G2b": "G2b population",
    "G3": "G3 observation window",
    "G4": "G4 numeric score",
    "G5": "G5 usable interval",
    "G6": "G6 residual footnotes",
}
REASON_LABELS = {
    "compatible": "Passes every gate",
    "release_intervals_flagged_by_cms": "CMS reported problems with the interval estimates in this release",
    "release_intervals_suppressed_by_cms": "CMS suppressed the interval estimates in this release",
    "release_not_usable": "The release's interval status is not usable",
    "invalid_or_duplicate_identifier": "Facility ID is invalid or appears more than once for this measure",
    "measure_definition_ambiguous": "More than one measure name is used for this measure ID",
    "population_or_data_source_differs": "CMS methodology documents a different cohort and data source for this hospital type",
    "partial_or_short_period_footnote": "Footnote reports a partial or shorter performance period",
    "observation_window_mismatch": "Record dates differ from the release's official measure window",
    "too_few_cases": "Too few cases to report a result",
    "not_available_this_period": "Result not available for this reporting period",
    "not_eligible_program": "Shown only for hospitals in the CMS inpatient and outpatient quality reporting programs",
    "no_eligible_cases": "No cases met the measure criteria",
    "not_applicable_to_hospital": "Measure does not apply to this hospital for this period",
    "cannot_be_calculated": "Result cannot be calculated for this period",
    "suppressed_by_cms": "CMS suppressed the data for one or more quarters",
    "reported": "Score is not a finite number",
    "interval_limit_missing": "An interval limit is missing",
    "interval_reversed": "Lower limit is above the upper limit",
    "interval_zero_width": "Lower and upper limits are equal",
    "score_outside_interval": "Score lies outside its own interval",
    "interval_out_of_bounds": "Interval lies outside the measure's possible range",
    "blocking_footnote_on_numeric_record": "Availability footnote on a record with a numeric score",
}
STATE_NAMES = {
    "AK": "Alaska", "AL": "Alabama", "AR": "Arkansas", "AS": "American Samoa", "AZ": "Arizona", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DC": "District of Columbia", "DE": "Delaware", "FL": "Florida",
    "GA": "Georgia", "GU": "Guam", "HI": "Hawaii", "IA": "Iowa", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana",
    "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "MA": "Massachusetts", "MD": "Maryland", "ME": "Maine",
    "MI": "Michigan", "MN": "Minnesota", "MO": "Missouri", "MP": "Northern Mariana Islands", "MS": "Mississippi",
    "MT": "Montana", "NC": "North Carolina", "ND": "North Dakota", "NE": "Nebraska", "NH": "New Hampshire",
    "NJ": "New Jersey", "NM": "New Mexico", "NV": "Nevada", "NY": "New York", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "PR": "Puerto Rico", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VA": "Virginia",
    "VI": "U.S. Virgin Islands", "VT": "Vermont", "WA": "Washington", "WI": "Wisconsin", "WV": "West Virginia",
    "WY": "Wyoming",
}
COLS = [
    "facility_id", "facility_name", "hospital_type", "score_src", "lower_src", "upper_src", "score", "lower", "upper",
    "compared_to_national_src", "footnote_src", "availability_state", "first_failed_gate", "reason_code", "compatible",
    "caution_flag", "point_rank", "best_rank", "worst_rank", "n", "other_gate", "other_reason",
]
LOOKUP_COLS = ["hospital_type", "compared_to_national_src", "availability_state", "reason_code", "other_reason"]


def _connect() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH.resolve().as_uri() + "?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    return con


def _num(x, decimals: int | None = None):
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    if math.isnan(v) or math.isinf(v):
        return None
    if decimals is not None:
        v = round(v, decimals)
    return v


def _int(x):
    v = _num(x)
    return None if v is None else int(v)


def _str(x) -> str:
    if x is None:
        return ""
    if isinstance(x, float) and math.isnan(x):
        return ""
    return str(x)


def _dump(path: Path, obj) -> int:
    data = json.dumps(obj, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    path.write_bytes(data)
    return len(data)


def _file_name(release_key: str, measure_id: str) -> str:
    return f"r{release_key.replace('-', '')}_{measure_id}.json"


class _Lookup:
    def __init__(self) -> None:
        self.values: list[str] = []
        self.index: dict[str, int] = {}

    def __call__(self, value):
        if value is None or value == "":
            return None
        if value not in self.index:
            self.index[value] = len(self.values)
            self.values.append(value)
        return self.index[value]


def _window_codes(con: sqlite3.Connection, release_key: str, measure_id: str) -> set[str]:
    rows = con.execute(
        """SELECT DISTINCT f.record_id FROM record_footnotes f
           JOIN footnote_dictionary d ON d.code = f.code AND d.release_key = ?
           JOIN records r ON r.record_id = f.record_id
           WHERE r.release_key = ? AND r.measure_id = ? AND d.study_class = 'window_blocking'""",
        (release_key, release_key, measure_id),
    ).fetchall()
    return {r[0] for r in rows}


def _other_failure(row: sqlite3.Row, window_records: set[str]) -> tuple[str | None, str | None]:
    """First failing gate after G0 for records of a release whose intervals are not usable.

    G5 is skipped because in such a release the missing or flagged intervals are the
    release-level problem already reported by G0.
    """
    for gate in ("G1", "G2", "G2b", "G3", "G4", "G6"):
        if int(row[GATE_COLUMNS[gate]]) == 0:
            if gate == "G1":
                return gate, "invalid_or_duplicate_identifier"
            if gate == "G2":
                return gate, "measure_definition_ambiguous"
            if gate == "G2b":
                return gate, "population_or_data_source_differs"
            if gate == "G3":
                if row["record_id"] in window_records:
                    return gate, "partial_or_short_period_footnote"
                return gate, "observation_window_mismatch"
            if gate == "G4":
                return gate, row["availability_state"]
            return gate, "blocking_footnote_on_numeric_record"
    return None, None


def _trim(row: list) -> list:
    while row and row[-1] is None:
        row.pop()
    return row


def _release_measure_file(con: sqlite3.Connection, release: dict, measure_id: str, decimals: int,
                          pairs_by_state: dict, codes_seen: set[str]) -> tuple[dict, dict]:
    rk = release["key"]
    usable = release["intervals_usable"]
    recs = con.execute(
        """SELECT g.*, rr.point_rank, rr.best_rank, rr.worst_rank, rr.n AS rank_n
           FROM gate_results g
           LEFT JOIN rank_ranges rr
             ON rr.subset = 'primary' AND rr.release_key = g.release_key AND rr.measure_id = g.measure_id
            AND rr.state = g.state AND rr.facility_id = g.facility_id
           WHERE g.release_key = ? AND g.measure_id = ?
           ORDER BY g.state, g.compatible DESC, g.score_num, g.facility_id""",
        (rk, measure_id),
    ).fetchall()
    window_records = _window_codes(con, rk, measure_id) if not usable else set()
    fn_rows = con.execute(
        """SELECT DISTINCT f.code FROM record_footnotes f JOIN records r ON r.record_id = f.record_id
           WHERE r.release_key = ? AND r.measure_id = ?""", (rk, measure_id)).fetchall()
    codes_seen.update(r[0] for r in fn_rows)

    lk = {c: _Lookup() for c in LOOKUP_COLS}
    src_lk = _Lookup()

    def src(value, number):
        text = _str(value)
        return text if number is not None else src_lk(text)

    states: dict[str, dict] = {}
    scored: dict[str, int] = {}
    for r in recs:
        st = r["state"] or ""
        other_gate, other_reason = (None, None)
        if int(r["g0_release"]) == 0:
            other_gate, other_reason = _other_failure(r, window_records)
            if int(r["g4_score"]) == 1:
                scored[st] = scored.get(st, 0) + 1
        compatible = int(r["compatible"])
        row = [
            r["facility_id"],
            _str(r["facility_name"]),
            lk["hospital_type"](_str(r["hospital_type"])),
            src(r["score_src"], r["score_num"]),
            src(r["lower_src"], r["lower_num"]),
            src(r["upper_src"], r["upper_num"]),
            _num(r["score_num"], decimals),
            _num(r["lower_num"], decimals),
            _num(r["upper_num"], decimals),
            lk["compared_to_national_src"](_str(r["compared_to_national_src"])),
            _str(r["footnote_src"]),
            lk["availability_state"](_str(r["availability_state"])),
            r["first_failed_gate"],
            lk["reason_code"](_str(r["reason_code"])),
            compatible,
            int(r["caution_flag"] or 0),
            _int(r["point_rank"]) if compatible else None,
            _int(r["best_rank"]) if compatible else None,
            _int(r["worst_rank"]) if compatible else None,
            _int(r["rank_n"]) if compatible else None,
            other_gate,
            lk["other_reason"](other_reason),
        ]
        states.setdefault(st, {"r": []})["r"].append(_trim(row))
        if compatible and r["point_rank"] is None:
            raise ValueError(f"compatible record without rank range: {r['record_id']}")

    for st, block in states.items():
        p = pairs_by_state.get((rk, measure_id, st))
        if p is not None:
            block["pairs"] = p
    payload = {
        "release": rk,
        "measure": measure_id,
        "decimals": decimals,
        "intervals_usable": usable,
        "cols": COLS,
        "lk": {**{c: lk[c].values for c in LOOKUP_COLS}, "src": src_lk.values},
        "states": states,
    }
    return payload, scored


def export(out_dir: Path) -> dict:
    """Write the viewer JSON files into out_dir and return a summary with file sizes."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    run = read_json(OUTPUTS / "run_manifest.json")
    examples = read_json(TABLES / "examples.json")
    primary = run["primary_release"]

    gate_flow = pd.read_csv(TABLES / "gate_flow_by_state.csv", dtype={"release_key": str, "state": str})
    pair_sum = pd.read_csv(TABLES / "pair_summary_by_state.csv", dtype={"release_key": str, "state": str})
    windows = pd.read_csv(TABLES / "cross_release_windows.csv", dtype={"release_key": str})

    pairs_by_state = {}
    for _, p in pair_sum[pair_sum["subset"] == "primary"].iterrows():
        pairs_by_state[(p["release_key"], p["measure_id"], p["state"])] = {
            "pairs": int(p["pairs"]),
            "point_ordered_pairs": int(p["point_ordered_pairs"]),
            "sep_r1_count": int(p["sep_r1_count"]),
            "not_separated_r1_share": _num(p["not_separated_r1_share"], 4),
        }

    con = _connect()
    try:
        releases = []
        for r in con.execute("SELECT * FROM releases ORDER BY release_key"):
            releases.append({
                "key": r["release_key"],
                "label": r["label"],
                "role": r["role"],
                "interval_status": r["interval_status"],
                "intervals_usable": r["interval_status"] == "published",
                "status_note": r["status_note"] or "",
                "notice": r["notice"] or "",
                "notice_url": r["notice_url"] or "",
            })
        by_key = {r["key"]: r for r in releases}

        plan = [(primary, m) for m in STUDY_MEASURES] + [(CURRENT_RELEASE, m) for m in CURRENT_MEASURES]
        for rel_key, _ in plan:
            if rel_key not in by_key:
                raise ValueError(f"release {rel_key} not in database")

        mdict = {r["measure_id"]: dict(r) for r in con.execute("SELECT * FROM measure_dictionary")}
        decimals = {(r["release_key"], r["measure_id"]): int(r["reported_decimals"])
                    for r in con.execute("SELECT release_key, measure_id, reported_decimals FROM measure_windows")}
        nat = {(r["release_key"], r["measure_id"]): r["national_rate"]
               for r in con.execute("SELECT release_key, measure_id, national_rate FROM national_reference "
                                    "WHERE geography = 'NATION'")}

        files: dict[str, dict[str, str]] = {}
        sizes: dict[str, int] = {}
        state_counts: dict[str, dict[str, list]] = {}
        codes_seen: dict[str, set[str]] = {}
        for rel_key, mid in plan:
            dec = decimals[(rel_key, mid)]
            seen = codes_seen.setdefault(rel_key, set())
            payload, scored = _release_measure_file(con, by_key[rel_key], mid, dec, pairs_by_state, seen)
            name = _file_name(rel_key, mid)
            sizes[name] = _dump(out_dir / name, payload)
            files.setdefault(rel_key, {})[mid] = name

            gf = gate_flow[(gate_flow["release_key"] == rel_key) & (gate_flow["measure_id"] == mid)].sort_values("state")
            rows = []
            for _, g in gf.iterrows():
                st = g["state"]
                n_rows = len(payload["states"].get(st, {"r": []})["r"])
                if n_rows != int(g["requested_records"]):
                    raise ValueError(f"{rel_key} {mid} {st}: {n_rows} rows but {g['requested_records']} requested")
                n_compat = sum(1 for row in payload["states"].get(st, {"r": []})["r"] if row[14] == 1)
                if n_compat != int(g["compatible"]):
                    raise ValueError(f"{rel_key} {mid} {st}: compatible count differs from gate_flow_by_state")
                entry = {"s": st, "name": STATE_NAMES.get(st, st), "requested": int(g["requested_records"]),
                         "compatible": int(g["compatible"])}
                if not by_key[rel_key]["intervals_usable"]:
                    entry["scored"] = int(scored.get(st, 0))
                rows.append(entry)
            state_counts.setdefault(rel_key, {})[mid] = rows

        footnotes = {}
        for rel_key, seen in codes_seen.items():
            footnotes[rel_key] = {
                r["code"]: r["footnote_text"]
                for r in con.execute("SELECT code, footnote_text FROM footnote_dictionary WHERE release_key = ? "
                                     "ORDER BY code", (rel_key,))
                if r["code"] in seen
            }
    finally:
        con.close()

    measures = []
    for mid in STUDY_MEASURES:
        md = mdict[mid]
        win = {}
        national = {}
        for rel_key in files:
            if mid not in files[rel_key]:
                continue
            w = windows[(windows["measure_id"] == mid) & (windows["release_key"] == rel_key)]
            if len(w) != 1:
                raise ValueError(f"window for {mid} {rel_key} not found")
            w = w.iloc[0]
            win[rel_key] = {"start": w["window_start"], "end": w["window_end"], "months": int(w["window_months"])}
            if mid.startswith("EDAC"):
                national[rel_key] = {"value": 0.0, "label": "0 days per 100 discharges (no excess days)",
                                     "kind": "zero_excess_days"}
            else:
                src = nat.get((rel_key, mid))
                val = _num(src, decimals[(rel_key, mid)])
                if val is not None:
                    national[rel_key] = {"value": val, "label": f"CMS national rate {src}", "kind": "national_rate",
                                         "src": src}
        measures.append({
            "id": mid,
            "label": f"{md['condition']}, {md['endpoint']}",
            "condition": md["condition"],
            "endpoint": md["endpoint"],
            "quantity": md["quantity"],
            "unit": md["unit"],
            "favorable": md["favorable"],
            "study_role": md["study_role"],
            "windows": win,
            "national": national,
        })

    for r in releases:
        r["measures"] = [m for m in STUDY_MEASURES if m in files.get(r["key"], {})]

    default_state = examples["state"]
    if not any(s["s"] == default_state for s in state_counts[primary][examples["measure_id"]]):
        raise ValueError("default state missing from the primary release")

    index = {
        "schema": 1,
        "run_id": run["run_id"],
        "primary_release": primary,
        "default_release": primary,
        "default_measure": examples["measure_id"],
        "default_state": default_state,
        "releases": releases,
        "measures": measures,
        "files": files,
        "states": state_counts,
        "gates": GATE_LABELS,
        "gate_order": GATE_ORDER,
        "reasons": REASON_LABELS,
        "footnotes": footnotes,
    }
    sizes["viewer_index.json"] = _dump(out_dir / "viewer_index.json", index)
    total = sum(sizes.values())
    if total > SIZE_LIMIT_BYTES:
        raise ValueError(f"viewer data is {total} bytes, above the {SIZE_LIMIT_BYTES} byte limit")
    return {"out_dir": str(out_dir), "run_id": run["run_id"], "files": sizes, "total_bytes": total}


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: python -m hospcomp.viewer OUT_DIR")
    summary = export(Path(sys.argv[1]))
    for name, size in sorted(summary["files"].items()):
        print(f"{size:>9}  {name}")
    print(f"{summary['total_bytes']:>9}  total")
