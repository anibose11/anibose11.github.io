"""Package stage: source archive, downloads, handoff files and the outer bundle.

The source archive is built from an explicit allowlist. Environments, raw data,
the study database, caches, private notes, submission documents with contact
details and delivery folders are never included.
"""

from __future__ import annotations

import fnmatch
import json
import re
import shutil
import zipfile
from pathlib import Path

from .claims import CLAIMS, values
from .common import OUTPUTS, ROOT, read_json, sha256_file, utc_now, write_json

SLUG = "hospital-comparability"
SITE = ROOT / "site" / "projects" / SLUG
DOWNLOADS = SITE / "downloads"
HANDOFF = ROOT / "handoff"
OUTER = ROOT / "deliverables" / "07-hospital-comparability-PROJECT-BUNDLE.zip"
FIXED_TIME = (2026, 10, 7, 0, 0, 0)

SOURCE_ALLOW = [
    "README.md", "README.md.j2", "LICENSE", "NOTICE.md", "CITATION.cff", "pyproject.toml", "requirements.lock",
    "source_manifest.json", "outputs/verification/*",
    "config/*", "src/hospcomp/*.py", "sql/*.sql", "scripts/*", "tests/*.py", "tests/fixtures/demo/*/*.csv",
    "docs/*.md", "docs/*.csv", "docs/*.json",
    "manuscript/manuscript.md.j2", "manuscript/supplement.md",
    "site_src/style.css", "site_src/viewer/viewer.js", "site_src/viewer/viewer.css", "site_src/viewer/viewer_snippet.html",
    "site_src/viewer/viewer_demo.html",
    "outputs/tables/*.csv", "outputs/tables/examples.json", "outputs/validation/*", "outputs/figures/*",
    "outputs/run_manifest.json", "outputs/runtime_manifest.json", "outputs/logs/build_log.json",
    "outputs/archive/run1_before_amendment2/run_manifest.json",
    "outputs/archive/run1_before_amendment2/tables/*.csv",
    "outputs/archive/run1_before_amendment2/tables/examples.json",
    "evidence/claims.json",
]
SOURCE_DENY = [
    "docs/journal_fit.md",
    "outputs/verification/clean_install.json",
    "outputs/verification/site_check.json",
    "outputs/tables/gate_results.csv",
    "outputs/archive/run1_before_amendment2/tables/gate_results.csv",
    "outputs/archive/run1_before_amendment2/tables/rank_ranges.csv",
    "outputs/archive/run1_before_amendment2/tables/compatible_records.csv",
    "outputs/archive/run1_before_amendment2/tables/hospital_level.csv",
    "*/__pycache__/*", "*.pyc", "*.DS_Store", "site_src/viewer/_test_data/*",
]
TABLE_DOWNLOADS = [
    "gate_flow_national.csv", "gate_flow_by_state.csv", "failure_reasons.csv", "pair_summary_national.csv",
    "pair_summary_by_state.csv", "state_weighted_summary.csv", "hospital_level_summary.csv", "rank_range_summary.csv",
    "rank_ranges.csv", "compatibility_matrix.csv", "cross_release_windows.csv", "facility_presence.csv",
    "measure_windows.csv", "releases.csv", "examples.json", "compatible_by_hospital_type.csv", "reference_values.csv",
    "separate_group_summary.csv",
]


def allowed_files() -> list[Path]:
    out = []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        r = p.relative_to(ROOT).as_posix()
        if r.startswith((".venv/", "data/", ".local/", "deliverables/", "handoff/", "site/", "submission/", ".git/",
                         "outputs/rerun/", "outputs/report/")):
            continue
        if any(fnmatch.fnmatch(r, pat) for pat in SOURCE_DENY):
            continue
        if any(fnmatch.fnmatch(r, pat) for pat in SOURCE_ALLOW):
            out.append(p)
    return out


def write_zip(path: Path, entries: list[tuple[Path, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".zip.part")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src, arc in sorted(entries, key=lambda e: e[1]):
            info = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(src, "rb") as fh:
                zf.writestr(info, fh.read(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(tmp) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f"corrupt member {bad} in {path.name}")
    tmp.replace(path)


def scan_for_private(paths: list[Path]) -> list[str]:
    """Reject machine-specific paths and personal contact details in public files."""
    needles = [str(ROOT.parent), "/" + "Users/", "/" + "private/tmp/"]
    private = ROOT / ".local" / "private_terms.json"
    if private.exists():
        needles += json.loads(private.read_text())["terms"]
    hits = []
    for p in paths:
        if p.suffix.lower() in (".png", ".zip", ".xlsx", ".pdf", ".docx", ".sqlite"):
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for nd in needles:
            if nd in text:
                hits.append(f"{p.relative_to(ROOT).as_posix()}: contains {nd!r}")
    return hits


def build_downloads() -> dict:
    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    src_files = allowed_files()
    problems = scan_for_private(src_files)
    if problems:
        raise RuntimeError("private or machine-specific content in source archive: " + "; ".join(problems[:10]))
    write_zip(DOWNLOADS / f"{SLUG}-source.zip", [(p, p.relative_to(ROOT).as_posix()) for p in src_files])
    wb = OUTPUTS / "hospital-comparability-review.xlsx"
    if wb.exists():
        shutil.copy2(wb, DOWNLOADS / wb.name)
    # Paths inside the tables archive equal the project paths, so every evidence-map output_path resolves in it.
    paths = {OUTPUTS / "tables" / t for t in TABLE_DOWNLOADS if (OUTPUTS / "tables" / t).exists()}
    paths |= {CLAIMS, OUTPUTS / "validation" / "validation_report.json", ROOT / "source_manifest.json"}
    paths |= {p for p in (OUTPUTS / "verification" / "hand_check.csv", OUTPUTS / "verification" / "hand_recheck.json")
              if p.exists()}
    paths |= {ROOT / c["output_path"] for c in read_json(CLAIMS)["claims"] if c.get("output_path")}
    missing = sorted(p.relative_to(ROOT).as_posix() for p in paths if not p.exists())
    if missing:
        raise RuntimeError(f"evidence-map outputs missing: {missing}")
    write_zip(DOWNLOADS / f"{SLUG}-tables.zip", [(p, p.relative_to(ROOT).as_posix()) for p in paths])
    shutil.copy2(ROOT / "docs" / "analysis_plan.md", DOWNLOADS / "analysis_plan.md")
    shutil.copy2(ROOT / "source_manifest.json", DOWNLOADS / "source_manifest.json")
    for src, name in ((ROOT / "submission" / "strobe_record_checklist.md", "strobe_record_checklist.md"),
                      (ROOT / "manuscript" / "supplement.docx", f"{SLUG}-supplement.docx")):
        if src.exists():
            shutil.copy2(src, DOWNLOADS / name)
    return {"source_files": len(src_files)}


def public_files() -> list[dict]:
    return [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": sha256_file(p)}
            for p in sorted(SITE.rglob("*")) if p.is_file() and p.name != ".DS_Store"]


def commands_log() -> list[dict]:
    path = OUTPUTS / "logs" / "commands.jsonl"
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def manuscript_status() -> str:
    review = OUTPUTS / "verification" / "author_review.json"
    if review.exists():
        r = read_json(review)
        if r.get("approved"):
            return f"complete; approved by the author on {r.get('date')} for BMC Health Services Research"
    return "complete; author approval not recorded in outputs/verification/author_review.json"


def remaining_author_actions() -> list[str]:
    review = OUTPUTS / "verification" / "author_review.json"
    items = []
    if not (review.exists() and read_json(review).get("approved")):
        items.append("Record the author's approval in outputs/verification/author_review.json.")
    items += [
        "Submission is the author's action and nothing has been submitted: upload handoff/submission/manuscript.docx, "
        "the figures in handoff/submission/figures/, the six files in handoff/submission/additional_files/ and the "
        "cover letter; title_page.md, declarations.md and author_information.md are reference copies of text already "
        "in the manuscript or needed for the submission form.",
        "Choose the article licence (CC BY 4.0 or CC BY-NC-ND 4.0) and confirm the article processing charge for the "
        "author's country at submission.",
        "Optional: deposit the source archive in a public repository with a DOI and add it under Availability of data "
        "and materials; JOSS requires six months of public repository history.",
    ]
    return items


def hand_summary() -> dict:
    import csv

    path = OUTPUTS / "verification" / "hand_check.csv"
    if not path.exists():
        return {}
    with open(path, newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    out = {"items": len(rows),
           "author_matched": sum(r.get("author_result") == "matched" for r in rows),
           "author_dates": sorted({r["author_date"] for r in rows if r.get("author_date")}),
           "script_matched": sum(r.get("script_recheck") == "matched" for r in rows),
           "script_differs": [r["check_id"] for r in rows if r.get("script_recheck") == "differs"]}
    rc = OUTPUTS / "verification" / "hand_recheck.json"
    if rc.exists():
        d = read_json(rc)
        out.update({"script": d.get("script"), "network": d.get("network"), "date": d.get("date"),
                    "results": d.get("results", [])})
    return out


def site_digest() -> str:
    import hashlib

    lines = [f"{f['path']} {f['sha256']}" for f in public_files()]
    return hashlib.sha256("\n".join(lines).encode()).hexdigest()


def handoff(stats: dict) -> None:
    v = values()
    run = read_json(OUTPUTS / "run_manifest.json")
    man = read_json(ROOT / "source_manifest.json")
    vr = read_json(OUTPUTS / "validation" / "validation_report.json")
    verif_dir = OUTPUTS / "verification"
    verification = {p.stem: read_json(p) for p in sorted(verif_dir.glob("*.json"))} if verif_dir.exists() else {}
    HANDOFF.mkdir(parents=True, exist_ok=True)
    claims_path = "evidence/claims.json"

    def finding(cid: str, text: str) -> dict:
        return {"claim_id": cid, "finding": text, "evidence": claims_path, "value": v[cid]}

    findings = [
        finding("cur_readm_hf_numeric", "Current CMS files (2026-09-30): hospitals with a heart-failure readmission score"),
        finding("cur_readm_hf_with_interval", "Current CMS files: those records with a usable interval"),
        finding("readm_hf_compatible_share", "Primary release 2026-05-13: share of requested HF readmission records passing all gates"),
        finding("readm_hf_not_sep", "Primary release: share of point-ordered same-state HF readmission pairs not separated (R1)"),
        finding("readm_hf_point_ordered", "Primary release: point-ordered same-state HF readmission pairs"),
        finding("mort_hf_not_sep", "Primary release: share of point-ordered HF mortality pairs not separated (R1)"),
        finding("edac_hf_not_sep", "Primary release: share of point-ordered HF excess-days pairs not separated (R1)"),
        finding("readm_hf_hosp_share_separated_from_none", "Primary release: HF readmission hospitals separated from no same-state peer"),
        finding("readm_hf_rank_top_ranked_worst_rank_over_half_n_ge_10", "States (of those with 10 or more compatible hospitals) where the first-ranked HF readmission hospital could rank in the bottom half"),
        finding("overlap_readm_hf", "Months shared by the READM_30_HF windows of the primary and current releases"),
    ]
    data_versions = []
    for rk, rel_ in (("2026-05-13", "pdc_2026_05_13"), ("2026-08-13", "pdc_2026_08_13")):
        a = man["archives"][rel_]
        data_versions.append({"release": rk, "source": a["zip_url"], "zip_sha256": a["zip_sha256"],
                              "accessed_utc": a["accessed_utc"],
                              "members": {k: m["sha256"] for k, m in a["members"].items()}})
    data_versions.append({"release": "2026-09-30", "source": "CMS Provider Data Catalog metastore (live)",
                          "files": {k: {"dataset_id": e["id"], "released": e["released"], "modified": e["modified"],
                                        "sha256": e["sha256"], "url": e["download_url"]} for k, e in man["datasets"].items()}})
    tests = verification.get("tests", {})
    clean = verification.get("clean_install", {})
    site_check = verification.get("site_check", {})
    src_sha = sha256_file(DOWNLOADS / f"{SLUG}-source.zip")
    current = {"site_files_identical_to_checked": site_check.get("site_files_digest") == site_digest(),
               "source_zip_identical_to_checked": (clean.get("archive_sha256") == src_sha
                                                   and site_check.get("source_zip_sha256") == src_sha)}
    site_check = dict(site_check, **current) if site_check else {}
    computational_ok = (vr["summary"]["all_passed"] and bool(clean.get("passed")) and bool(site_check.get("passed"))
                        and all(current.values()))
    doc = {
        "slug": SLUG,
        "title": "When Hospital Quality Comparisons Are Not Comparable",
        "featured": False,
        "summary": ("A release-aware validator for CMS Provider Data Catalog hospital outcome measures, applied to "
                    "heart-failure and acute myocardial infarction 30-day measures in three releases. It gates records on "
                    "release status, identity, definition, population, window, score, interval and footnotes, then reports "
                    "same-state interval separation and interval-compatible rank ranges."),
        "status": {
            "computational_completion": "complete" if computational_ok else "complete except checks listed under unresolved",
            "manuscript": manuscript_status(),
            "unresolved_prerequisites": remaining_author_actions(),
        },
        "data_versions": data_versions,
        "primary_release": run["primary_release"],
        "run_id": run["run_id"],
        "plan_sha256": run["plan_sha256"],
        "key_limitations": [
            "Primary release (2026-05-13) is not the newest; newer releases lack usable intervals.",
            "Separation uses marginal 95% intervals at one-decimal precision without covariance; overlap is descriptive.",
            "Pairwise comparison of indirectly standardized rates is itself questioned (COPSS-CMS white paper).",
            "VA exclusion was added by a dated amendment after the plan lock; both runs reported.",
            "CMS national category counts exceed hospital-file counts; reconciliation incomplete.",
            "Describes one public measure population, not hospital quality in general.",
        ],
        "paths": {"report": f"site/projects/{SLUG}/report.html", "supplement": f"site/projects/{SLUG}/supplement.html",
                  "project_page": f"site/projects/{SLUG}/index.html",
                  "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip",
                  "manuscript_markdown": "manuscript/manuscript.md (inside the source archive)",
                  "claims": "evidence/claims.json (inside the source archive)"},
        "executed_commands": commands_log() + [
            {"command": c.get("command"), "recorded_utc": c.get("recorded_utc"), "result": c.get("result")}
            for c in (tests,) if c] + ([{"command": "python scripts/verify_bundle.py <scratch>", "recorded_utc": clean.get("recorded_utc"),
                                        "result": {"clean_install": clean.get("passed"), "site_check": site_check.get("passed")}}]
                                      if clean else []),
        "validation": {"checks": vr["summary"], "tests": tests, "clean_install": clean, "site_check": site_check,
                       "hand_verification": hand_summary()},
        "measured_findings": findings,
        "public_files": public_files(),
        "generated_utc": utc_now(),
    }
    write_json(HANDOFF / f"{SLUG}.json", doc)

    lines = ["# Validation record: hospital-comparability", "",
             f"Run {run['run_id']}, primary release {run['primary_release']}, plan SHA-256 {run['plan_sha256']}.", "",
             "Software testing, source reconciliation and external scientific validation are kept separate below. "
             "No external scientific validation of the CMS estimates was performed.", "",
             "## Software tests", ""]
    if tests:
        lines += [f"- Command: `{tests.get('command')}`", f"- Result: {tests.get('result')}", ""]
    lines += ["## Pipeline validation checks", ""]
    for c in vr["checks"]:
        label = "SKIPPED" if c.get("skipped") else ("RECORD" if c["passed"] is None else ("PASS" if c["passed"] else "FAIL"))
        lines.append(f"- {label} ({c['kind']}): {c['check']}. Detail: `{json.dumps(c['detail'])}`")
    lines += ["", "## Clean extraction of the source archive", ""]
    if clean:
        for k, val in clean.items():
            lines.append(f"- {k}: {val}")
    lines += ["", "## Static site checks", ""]
    if site_check:
        for k, val in site_check.items():
            lines.append(f"- {k}: {val}")
    hs = hand_summary()
    lines += ["", "## Hand verification", ""]
    if hs:
        lines += [f"- Checklist: `outputs/verification/hand_check.csv` ({hs['items']} items).",
                  f"- Author: {hs['author_matched']} of {hs['items']} items recorded as matched "
                  f"(dates: {', '.join(hs['author_dates']) or 'none'}).",
                  f"- Scripted re-derivation (`{hs.get('script', 'scripts/recheck_hand_items.py')}`, network checks "
                  f"{'on' if hs.get('network') else 'off'}): {hs['script_matched']} of {hs['items']} items matched; "
                  f"differing: {hs['script_differs'] or 'none'}.", ""]
        for r in hs.get("results", []):
            lines.append(f"- {r['check_id']} {r['result']}: {r['detail']}")
    lines += ["", "## Not performed", "",
              "- No Tableau workbook was built or tested; only an import specification is provided (docs/tableau_spec.md).",
              "- No REDCap import or PostgreSQL database was used; neither is required by this project.",
              "- No external expert review of the CMS estimates was performed.", ""]
    (HANDOFF / f"{SLUG}-validation.md").write_text("\n".join(lines), encoding="utf-8")

    vr_lines = ["# Verified results", "",
                "Only methods and results verified in this project, each with its evidence path.", "",
                "## Methods actually used", "",
                "- Python and SQLite pipeline with source-preserving parsing, eight gates, integer-precision interval comparison, "
                "deterministic interval-compatible rank ranges (Klein, Wright and Wieczorek counting rule).",
                "- Official CMS archive releases retrieved through the catalogue archive API with ZIP integrity and checksum checks.",
                "- Locked analysis plan with three dated amendments and two dated notes on the record; three prespecified "
                "sensitivity analyses.",
                "- Hand verification of a 23-item checklist by the author, re-derived item by item by "
                "scripts/recheck_hand_items.py (raw records, examples, recalculations, documents, references, numbers).",
                "- Validation: data checks, CMS aggregate reconciliation, 24-record raw reconstruction, R reimplementation, full rerun.",
                "", "## Measured results", ""]
    for f in findings:
        val = f["value"]
        if isinstance(val, float):
            val = f"{val:.4f}"
        vr_lines.append(f"- {f['finding']}: {val} (evidence: {claims_path}, id `{f['claim_id']}`)")
    vr_lines += ["", "## Not claimed", "",
                 "- No deployment, users, adoption, publication, peer review, citations or time savings.",
                 "- No external validation of CMS estimates.", ""]
    (HANDOFF / "verified_results.md").write_text("\n".join(vr_lines), encoding="utf-8")


def additional_files() -> list[tuple[Path, str]]:
    """Files named in the manuscript's Additional files list, numbered as cited."""
    listed = [(str(x["number"]), x["file"]) for x in read_json(OUTPUTS / "report" / "additional_files.json")]
    where = {"analysis_plan.md": DOWNLOADS / "analysis_plan.md",
             "strobe_record_checklist.md": ROOT / "submission" / "strobe_record_checklist.md"}
    out = []
    for num, fname in listed:
        path = where.get(fname, DOWNLOADS / fname)
        if not path.exists():
            raise RuntimeError(f"Additional file {num} ({fname}) not found")
        out.append((path, f"additional_file_{num}_{fname}"))
    if len(out) != 6:
        raise RuntimeError(f"expected 6 additional files, found {len(out)}")
    return out


def outer_bundle() -> dict:
    entries = [(p, p.relative_to(ROOT).as_posix()) for p in sorted(SITE.rglob("*")) if p.is_file() and p.name != ".DS_Store"]
    for name in (f"{SLUG}.json", f"{SLUG}-validation.md", "verified_results.md"):
        entries.append((HANDOFF / name, f"handoff/{name}"))
    for p in sorted((ROOT / "submission").glob("*.md")):
        entries.append((p, f"handoff/submission/{p.name}"))
    if (ROOT / "manuscript" / "manuscript.docx").exists():
        entries.append((ROOT / "manuscript" / "manuscript.docx", "handoff/submission/manuscript.docx"))
    for f in sorted((OUTPUTS / "figures").glob("*.png")):
        entries.append((f, f"handoff/submission/figures/{f.name}"))
    for path, name in additional_files():
        entries.append((path, f"handoff/submission/additional_files/{name}"))
    if (ROOT / "docs" / "journal_fit.md").exists():
        entries.append((ROOT / "docs" / "journal_fit.md", "handoff/notes/journal_fit.md"))
    write_zip(OUTER, entries)
    digest = sha256_file(OUTER)
    (OUTER.parent / (OUTER.name + ".sha256")).write_text(f"{digest}  {OUTER.name}\n")
    return {"outer_zip": OUTER.relative_to(ROOT).as_posix(), "bytes": OUTER.stat().st_size,
            "mib": round(OUTER.stat().st_size / 1024 / 1024, 2), "sha256": digest, "entries": len(entries)}


def run() -> dict:
    from . import site

    stats = build_downloads()
    site.build()
    handoff(stats)
    out = outer_bundle()
    out.update(stats)
    return out


if __name__ == "__main__":
    print(json.dumps(run(), indent=1))
