"""Source-preserving parsers. Each returns the parsed value and a state label,
and never overwrites the source string."""

from __future__ import annotations

import math
import re
from datetime import date

NUMERIC_RE = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)$")
FACILITY_RE = re.compile(r"^[0-9A-Z]{6}$")
STATE_RE = re.compile(r"^[A-Z]{2}$")
DATE_RE = re.compile(r"^(\d{2})/(\d{2})/(\d{4})$")

TEXT_STATES = {
    "": "blank",
    "not available": "not_available",
    "not applicable": "not_applicable",
    "too few to report": "too_few_to_report",
    "n/a": "not_available_na",
    "--": "dash",
}


def parse_numeric(src: str | None) -> tuple[float | None, str, int | None]:
    """Return (value, state, decimals). State is 'numeric' or a text-state label."""
    if src is None:
        return None, "blank", None
    s = src.strip()
    if NUMERIC_RE.match(s):
        value = float(s)
        if not math.isfinite(value):
            return None, "non_finite", None
        decimals = len(s.split(".", 1)[1]) if "." in s else 0
        return value, "numeric", decimals
    return None, TEXT_STATES.get(s.lower(), "other_text"), None


def normalize_facility_id(src: str | None) -> tuple[str, bool]:
    """CMS Certification Numbers are six characters. Restore leading zeros lost by
    spreadsheet round trips on all-digit IDs; never alter IDs containing letters."""
    s = (src or "").strip().upper()
    if s.isdigit() and 0 < len(s) < 6:
        s = s.zfill(6)
    return s, bool(FACILITY_RE.match(s))


def parse_footnotes(src: str | None) -> list[str]:
    """'1, 28' -> ['1', '28']; preserves non-numeric codes such as 'a' or '*'."""
    if not src:
        return []
    parts = [p.strip() for p in re.split(r"[,;]", src) if p.strip()]
    out = []
    for p in parts:
        out.extend(x for x in p.split() if x)
    def key(c: str):
        return (0, int(c), c) if c.isdigit() else (1, 0, c)
    return sorted(set(out), key=key)


def parse_date(src: str | None) -> str | None:
    m = DATE_RE.match((src or "").strip())
    if not m:
        return None
    mm, dd, yyyy = (int(x) for x in m.groups())
    try:
        return date(yyyy, mm, dd).isoformat()
    except ValueError:
        return None


def months_inclusive(start_iso: str | None, end_iso: str | None) -> int | None:
    if not start_iso or not end_iso:
        return None
    s, e = date.fromisoformat(start_iso), date.fromisoformat(end_iso)
    return (e.year - s.year) * 12 + (e.month - s.month) + 1


def availability_state(score_state: str, codes: list[str], precedence: list[str], states: dict[str, str]) -> str:
    if score_state == "numeric":
        return "reported"
    for code in precedence:
        if code in codes:
            return states[code]
    return "missing_unspecified"
