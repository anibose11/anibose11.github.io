"""Excel review workbook.

One workbook holds every record requested for a within-state, same-measure
comparison in the primary release, with its source strings, gate decisions and
rank range, followed by the summary, reconciliation, dictionary and provenance
tables. Values are copied from the frozen study database
(data/interim/hospcomp.sqlite), the output tables and the manifests; nothing is
recomputed here except joins and sort order.

The file is written with fixed package timestamps (the run's completion time),
so the same inputs give a byte-identical workbook.
"""

from __future__ import annotations

import csv
import json
import math
import re
import sqlite3
import tomllib
import zipfile
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from .common import DB_PATH, OUTPUTS, ROOT, TABLES, read_json, rel, sha256_file

WORKBOOK_PATH = OUTPUTS / "hospital-comparability-review.xlsx"
VALIDATION = OUTPUTS / "validation"
TITLE = "When hospital quality comparisons are not comparable: review workbook"
CREATOR = "hospital-comparability"

STUDY_MEASURES = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI"]
CURRENT_HF_MEASURES = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF"]
LOOKALIKE_MEASURES = ["READM-30-HF-HRRP", "READM-30-AMI-HRRP"]
MEASURE_ORDER = {m: i for i, m in enumerate(STUDY_MEASURES + LOOKALIKE_MEASURES)}

GATES = ["g0_release", "g1_identity", "g2_definition", "g2b_population", "g3_window", "g4_score", "g5_interval",
         "g6_footnote"]
# Same wording as hospcomp.analyze.GATE_LABELS (checked in tests/test_workbook.py).
GATE_LABELS = {
    "g0_release": "G0 release intervals usable",
    "g1_identity": "G1 identity and uniqueness",
    "g2_definition": "G2 measure definition",
    "g2b_population": "G2b population",
    "g3_window": "G3 observation window",
    "g4_score": "G4 numeric score reported",
    "g5_interval": "G5 usable interval",
    "g6_footnote": "G6 no blocking footnote",
}
GATE_RULES = {
    "g0_release": "the release's documented interval status is 'published'; releases whose intervals were flagged or "
                  "suppressed by a CMS notice fail",
    "g1_identity": "valid six-character Facility ID, valid two-letter state code, and exactly one row for the Facility ID "
                   "and Measure ID in the file",
    "g2_definition": "the Measure ID is in the study dictionary with a documented quantity, unit and favorable direction, "
                     "and has a single source Measure Name in the file",
    "g2b_population": "the hospital type is not listed for the measure in config/population_exclusions.csv; "
                      "'Acute Care - Veterans Administration' is listed for all six study measures (Amendment 2)",
    "g3_window": "start and end dates equal the release's official Measure Dates window for the Measure ID, and the "
                 "record carries neither footnote 29 (partial performance period) nor footnote 3 (shorter period)",
    "g4_score": "the score parses as a finite number",
    "g5_interval": "both limits are numeric, lower <= score <= upper, lower < upper, and all three lie within the "
                   "measure's bounds",
    "g6_footnote": "no availability footnote (1, 4, 5, 7, 12, 13 or 19) on the record; caution footnotes 11, 23 and 28 "
                   "pass with caution_flag = 1",
}

# ---------------------------------------------------------------------------
# Column layout of every table written after the Definitions sheet
# ---------------------------------------------------------------------------

RECORD_COLUMNS = [
    "release_key", "measure_id", "state", "facility_id", "facility_name", "hospital_type", "dataset_key", "source_row",
    "score_src", "lower_src", "upper_src", "denominator_src", "compared_to_national_src", "footnote_src",
    "start_date_src", "end_date_src",
    "score_num", "lower_num", "upper_num", "denominator_num", "start_date", "end_date",
    "availability_state", *GATES, "first_failed_gate", "reason_code", "compatible", "caution_flag",
    "point_rank", "best_rank", "worst_rank", "n", "record_id",
]

GATE_FLOW_TAIL = [
    "requested_records",
    *[f"pass_through_{g}" for g in GATES],
    *[f"independent_pass_{g}" for g in GATES],
    "numeric_score_without_usable_interval", "compatible", "compatible_strict", "compatible_share_of_requested",
    "broader_denominator_general_info", "absent_from_measure_file", "compatible_share_of_broader",
    "compatible_strict_share_of_requested",
]

BLOCK_COLUMNS: dict[str, list[str]] = {
    "releases": ["release_key", "source", "role", "label", "interval_status", "status_note", "notice", "notice_url"],
    "source_files": ["release_key", "dataset_key", "dataset_id", "title", "released", "modified", "file_version",
                     "download_url", "sha256", "data_rows"],
    "gate_flow": ["release_key", "measure_id", *GATE_FLOW_TAIL],
    "gate_flow_state": ["release_key", "measure_id", "state", *GATE_FLOW_TAIL],
    "records_primary": RECORD_COLUMNS,
    "records_current": RECORD_COLUMNS,
    "pair_summary": ["subset", "release_key", "measure_id", "pairs", "point_ordered_pairs", "tied_pairs",
                     "sep_r1_count", "sep_r1_share", "sep_r2_count", "sep_r2_share", "sep_r3_count", "sep_r3_share",
                     "official_opposite_count", "official_opposite_share", "not_separated_r1_count",
                     "not_separated_r1_share"],
    "state_summary": ["subset", "release_key", "measure_id", "states_with_point_ordered_pairs",
                      "median_state_not_separated_share", "q1", "q3", "min_state_share", "max_state_share"],
    "hospital_summary": ["subset", "release_key", "measure_id", "hospitals_with_point_ordered_comparisons",
                         "median_separated_share", "q1", "q3", "hospitals_separated_from_none",
                         "share_separated_from_none"],
    "rank_summary": ["subset", "release_key", "measure_id", "hospitals_in_universes_n_ge_2", "universes_n_ge_2",
                     "median_width_share_of_n", "share_width_over_half_of_n", "share_full_range", "universes_n_ge_10",
                     "top_ranked_median_worst_rank_share_n_ge_10", "top_ranked_worst_rank_over_half_n_ge_10"],
    "compatibility_matrix": ["release_key", "measure_a", "measure_b", "same_measure_id", "same_quantity", "same_unit",
                             "same_window", "same_condition", "same_source_program", "n_checks_failed", "window_a",
                             "window_b", "quantity_a", "quantity_b", "comparable", "first_failed_check"],
    "cross_release_windows": ["measure_id", "study_role", "release_key", "release_role", "interval_status",
                              "window_start", "window_end", "window_months", "official_start", "official_end",
                              "window_matches_official", "overlap_months_with_primary", "same_window_as_primary",
                              "documented_definition_change_since_primary", "definition_change_source"],
    "facility_presence": ["release_a", "release_b", "facilities_a", "facilities_b", "in_both", "only_in_a",
                          "only_in_b", "only_in_a_ids", "only_in_b_ids"],
    "reconciliation": ["release_key", "measure_id", "geography", "category", "hospital_rows", "cms_aggregate_src",
                       "cms_aggregate", "difference"],
    "raw_reconstruction": ["measure_id", "selection", "record_id", "source_file", "source_row", "facility_id",
                           "score_src", "lower_src", "upper_src", "footnote_src", "fields_compared", "mismatches",
                           "matched"],
    "footnotes": ["release_key", "code", "footnote_text", "study_class", "availability_state", "study_effect"],
    "measures": ["release_key", "measure_id", "study_role", "dataset_key", "condition", "endpoint", "quantity", "unit",
                 "favorable", "lower_bound", "upper_bound", "doc_source", "source_measure_name", "n_source_names",
                 "official_name", "official_start", "official_end", "modal_start", "modal_end", "window_months",
                 "reported_decimals", "n_window_variants"],
    "documents": ["source_type", "key", "title", "url", "local_path", "bytes", "sha256", "retrieval_note"],
    "citations": ["citation_type", "citation", "url", "applies_to", "detail"],
    "population_exclusions": ["measure_id", "hospital_type", "reason", "source"],
}

# Output tables copied as they are; the workbook checks that their headers still match BLOCK_COLUMNS.
CSV_SOURCES: dict[str, Path] = {
    "gate_flow": TABLES / "gate_flow_national.csv",
    "gate_flow_state": TABLES / "gate_flow_by_state.csv",
    "pair_summary": TABLES / "pair_summary_national.csv",
    "state_summary": TABLES / "state_weighted_summary.csv",
    "hospital_summary": TABLES / "hospital_level_summary.csv",
    "rank_summary": TABLES / "rank_range_summary.csv",
    "compatibility_matrix": TABLES / "compatibility_matrix.csv",
    "cross_release_windows": TABLES / "cross_release_windows.csv",
    "facility_presence": TABLES / "facility_presence.csv",
    "reconciliation": VALIDATION / "reconciliation_categories.csv",
    "raw_reconstruction": VALIDATION / "raw_reconstruction.csv",
}

BLOCK_TITLES = {
    "releases": "Releases",
    "source_files": "Source files",
    "cross_release_windows": "Observation windows by release",
    "facility_presence": "Facility ID presence between releases",
    "documents": "Documents and archive packages",
    "citations": "Citations for release status and definition changes",
    "population_exclusions": "Population exclusions applied at gate G2b (config/population_exclusions.csv)",
}

# Sheet order. Each sheet lists its table blocks; sheets with several blocks show a title above each block.
SHEETS: list[tuple[str, list[str]]] = [
    ("Read me", []),
    ("Definitions", []),
    ("Releases", ["releases", "source_files"]),
    ("Gate flow", ["gate_flow"]),
    ("Gate flow by state", ["gate_flow_state"]),
    ("Records primary", ["records_primary"]),
    ("Records current HF", ["records_current"]),
    ("Pair summary", ["pair_summary"]),
    ("State summary", ["state_summary"]),
    ("Hospital summary", ["hospital_summary"]),
    ("Rank ranges summary", ["rank_summary"]),
    ("Compatibility matrix", ["compatibility_matrix"]),
    ("Cross-release", ["cross_release_windows", "facility_presence"]),
    ("Reconciliation", ["reconciliation"]),
    ("Raw reconstruction", ["raw_reconstruction"]),
    ("Footnotes", ["footnotes"]),
    ("Measures", ["measures"]),
    ("Source evidence", ["documents", "citations", "population_exclusions"]),
]
SHEET_NAMES = [name for name, _ in SHEETS]

FREEZE = {"Gate flow": "C3", "Gate flow by state": "D3", "Records primary": "E2", "Records current HF": "E2"}
LABEL_ROW_SHEETS = {"Gate flow", "Gate flow by state"}

# ---------------------------------------------------------------------------
# Definitions: (definition, unit, source)
# ---------------------------------------------------------------------------

_GATE_DEFS = {
    g: (f"1 if the record passes {GATE_LABELS[g]}, otherwise 0. Rule: {GATE_RULES[g]}.", "flag (1 = pass)",
        "computed: sql/02_gates.sql")
    for g in GATES
}
_PASS_THROUGH_DEFS = {
    f"pass_through_{g}": (f"Records remaining after the gates are applied in order up to and including "
                          f"{GATE_LABELS[g]}.", "records", "computed from gate flags (outputs/tables/gate_flow_*.csv)")
    for g in GATES
}
_INDEPENDENT_DEFS = {
    f"independent_pass_{g}": (f"Records passing {GATE_LABELS[g]} when that gate is evaluated on its own.", "records",
                              "computed from gate flags (outputs/tables/gate_flow_*.csv)")
    for g in GATES
}

DEFINITIONS: dict[str, tuple[str, str, str]] = {
    # identifiers
    "release_key": ("Release identifier: the date of the CMS archive snapshot, or the release date of the outcome "
                    "datasets for the current catalogue files.", "date (ISO text)", "config/releases.toml"),
    "measure_id": ("CMS Measure ID.", "code", "CMS field 'Measure ID'"),
    "state": ("Two-letter state or territory code. Hospitals are compared only within the same state, release and "
              "Measure ID.", "code", "CMS field 'State'"),
    "subset": ("'primary' uses every compatible record; 'strict' also removes records carrying caution footnote 11, 23 "
               "or 28 (sensitivity analysis S1 ii).", "category", "computed"),
    "facility_id": ("Six-character CMS Certification Number, with leading zeros restored on all-digit IDs.", "text",
                    "CMS field 'Facility ID', normalized"),
    "facility_name": ("Hospital name as published.", "text", "CMS field 'Facility Name'"),
    "hospital_type": ("Hospital type listed in the same release's General Information file.", "category",
                      "CMS field 'Hospital Type' (Hospital General Information)"),
    "dataset_key": ("Study key of the CMS source dataset: unplanned_visits (Unplanned Hospital Visits), "
                    "complications_deaths (Complications and Deaths), hrrp (Hospital Readmissions Reduction Program) "
                    "and the dictionary and reference files.", "code", "config/study.toml"),
    "source_row": ("Data row of the record in the raw CSV file, counted from 1 after the header.", "row number",
                   "recorded when the file was loaded"),
    "record_id": ("Record key release_key|dataset_key|facility_id|measure_id; joins to outputs/tables/gate_results.csv.",
                  "text", "computed"),
    # source strings
    "score_src": ("Score exactly as published.", "text", "CMS field 'Score'"),
    "lower_src": ("Lower interval limit exactly as published.", "text", "CMS field 'Lower Estimate'"),
    "upper_src": ("Upper interval limit exactly as published.", "text", "CMS field 'Higher Estimate'"),
    "denominator_src": ("Denominator exactly as published.", "text", "CMS field 'Denominator'"),
    "compared_to_national_src": ("CMS comparison category exactly as published. It is source information; the study's "
                                 "separation rules do not use it.", "text", "CMS field 'Compared to National'"),
    "footnote_src": ("Footnote codes exactly as published.", "text", "CMS field 'Footnote'"),
    "start_date_src": ("Start of the record's observation window as published.", "text (MM/DD/YYYY)",
                       "CMS field 'Start Date'"),
    "end_date_src": ("End of the record's observation window as published.", "text (MM/DD/YYYY)",
                     "CMS field 'End Date'"),
    # parsed values
    "score_num": ("Score parsed as a number; blank when the published score is not numeric.",
                  "measure unit (see Measures sheet)", "parsed from score_src"),
    "lower_num": ("Lower interval limit parsed as a number; blank when not numeric.", "measure unit (see Measures sheet)",
                  "parsed from lower_src"),
    "upper_num": ("Upper interval limit parsed as a number; blank when not numeric.", "measure unit (see Measures sheet)",
                  "parsed from upper_src"),
    "denominator_num": ("Denominator parsed as a number; blank when not numeric.", "count as published",
                        "parsed from denominator_src"),
    "start_date": ("Start of the record's observation window.", "date (ISO text)", "parsed from start_date_src"),
    "end_date": ("End of the record's observation window.", "date (ISO text)", "parsed from end_date_src"),
    "availability_state": ("'reported' when the score is numeric. Otherwise the state given by the first footnote found "
                           "in the order 19, 12, 7, 1, 4, 13, 5 (for example too_few_cases for footnote 1), or "
                           "missing_unspecified.", "category",
                           "computed: config/measures.toml footnote policy; docs/analysis_plan.md, Record states"),
    # gates
    **_GATE_DEFS,
    "first_failed_gate": ("First gate the record fails, in the order G0, G1, G2, G2b, G3, G4, G5, G6; blank when the "
                          "record passes every gate.", "gate code", "computed: sql/02_gates.sql"),
    "reason_code": ("Reason for the first failure, for example release_intervals_suppressed_by_cms, "
                    "population_or_data_source_differs, partial_or_short_period_footnote or too_few_cases; "
                    "'compatible' when every gate passes.", "code", "computed: sql/02_gates.sql"),
    "compatible": ("1 if the record passes every gate from G0 to G6, otherwise 0.", "flag (1 = compatible)",
                   "computed: sql/02_gates.sql"),
    "caution_flag": ("1 if the record carries caution footnote 11, 23 or 28. Such records stay in the primary subset and "
                     "are removed from the strict subset.", "flag", "computed: sql/02_gates.sql"),
    # ranks
    "point_rank": ("Point-estimate rank among compatible hospitals in the same release, state and measure: 1 plus the "
                   "number of hospitals with a more favorable published score (ties share the best rank). Blank for "
                   "records outside the compatible subset.", "rank",
                   "computed: sql/03_pairs_ranks.sql (rank_ranges, subset primary)"),
    "best_rank": ("Best interval-compatible rank: 1 plus the number of same-state compatible hospitals whose upper limit "
                  "is below this hospital's lower limit (lower is better for all study measures).", "rank",
                  "computed: sql/03_pairs_ranks.sql (rank_ranges, subset primary)"),
    "worst_rank": ("Worst interval-compatible rank: n minus the number of same-state compatible hospitals whose lower "
                   "limit is above this hospital's upper limit.", "rank",
                   "computed: sql/03_pairs_ranks.sql (rank_ranges, subset primary)"),
    "n": ("Compatible hospitals in the release, state and measure universe (primary subset).", "hospitals",
          "computed: sql/03_pairs_ranks.sql"),
    # gate flow
    "requested_records": ("Rows for the Measure ID in the release file: nationally, or within the state on the state "
                          "sheet.", "records", "count of CMS hospital file rows"),
    **_PASS_THROUGH_DEFS,
    **_INDEPENDENT_DEFS,
    "numeric_score_without_usable_interval": ("Records with a numeric score (G4 pass) and no usable interval (G5 fail).",
                                              "records", "computed from gate flags"),
    "compatible_strict": ("Compatible records without caution footnotes 11, 23 and 28 (S1 ii).", "records",
                          "computed from gate flags and caution_flag"),
    "compatible_share_of_requested": ("compatible divided by requested_records.", "proportion", "computed"),
    "broader_denominator_general_info": ("Hospitals listed in the same release's General Information file, nationally "
                                         "or in the state, including hospitals with no row in the measure file (S1 iii).",
                                         "hospitals", "count of Hospital General Information rows"),
    "absent_from_measure_file": ("broader_denominator_general_info minus requested_records.", "hospitals", "computed"),
    "compatible_share_of_broader": ("compatible divided by broader_denominator_general_info (S1 iii).", "proportion",
                                    "computed"),
    "compatible_strict_share_of_requested": ("compatible_strict divided by requested_records.", "proportion",
                                             "computed"),
    # pairs
    "pairs": ("Unordered pairs of distinct compatible hospitals in the same release, state and measure, pooled across "
              "states.", "pairs", "computed: sql/03_pairs_ranks.sql"),
    "point_ordered_pairs": ("Pairs whose published scores differ at the reported precision.", "pairs", "computed"),
    "tied_pairs": ("Pairs with equal published scores.", "pairs", "computed"),
    "sep_r1_count": ("Point-ordered pairs separated under R1, the primary rule: one hospital's upper limit is below the "
                     "other hospital's lower limit. Touching endpoints count as not separated.", "pairs",
                     "computed: sql/03_pairs_ranks.sql"),
    "sep_r1_share": ("sep_r1_count divided by point_ordered_pairs.", "proportion", "computed"),
    "sep_r2_count": ("Point-ordered pairs separated under R2 (rounding-robust): the gap between the two intervals "
                     "exceeds one unit in the last reported decimal place.", "pairs", "computed: sql/03_pairs_ranks.sql"),
    "sep_r2_share": ("sep_r2_count divided by point_ordered_pairs.", "proportion", "computed"),
    "sep_r3_count": ("Point-ordered pairs separated under R3 (lenient): each point estimate lies outside the other "
                     "hospital's interval.", "pairs", "computed: sql/03_pairs_ranks.sql"),
    "sep_r3_share": ("sep_r3_count divided by point_ordered_pairs.", "proportion", "computed"),
    "official_opposite_count": ("Point-ordered pairs whose CMS categories lie on opposite sides of the national "
                                "comparison (Better and Worse, or Fewer Days and More Days for EDAC). Reference row "
                                "from source categories; it is not one of the study's rules.", "pairs",
                                "computed from CMS field 'Compared to National'"),
    "official_opposite_share": ("official_opposite_count divided by point_ordered_pairs.", "proportion", "computed"),
    "not_separated_r1_count": ("point_ordered_pairs minus sep_r1_count.", "pairs", "computed"),
    "not_separated_r1_share": ("Primary pair metric: share of point-ordered pairs not separated under R1.", "proportion",
                               "computed"),
    # state and hospital summaries
    "states_with_point_ordered_pairs": ("States with at least one point-ordered pair.", "states", "computed"),
    "median_state_not_separated_share": ("Median across states of the state-level R1 not-separated share, each state "
                                         "weighted equally.", "proportion", "computed"),
    "min_state_share": ("Lowest state-level R1 not-separated share.", "proportion", "computed"),
    "max_state_share": ("Highest state-level R1 not-separated share.", "proportion", "computed"),
    "hospitals_with_point_ordered_comparisons": ("Compatible hospitals with at least one point-ordered same-state "
                                                 "comparison.", "hospitals", "computed"),
    "median_separated_share": ("Median across hospitals of the share of each hospital's point-ordered same-state "
                               "comparisons that are separated under R1.", "proportion", "computed"),
    "hospitals_separated_from_none": ("Hospitals separated under R1 from none of their point-ordered same-state peers.",
                                      "hospitals", "computed"),
    "share_separated_from_none": ("hospitals_separated_from_none divided by hospitals_with_point_ordered_comparisons.",
                                  "proportion", "computed"),
    # rank summary
    "hospitals_in_universes_n_ge_2": ("Compatible hospitals in state universes with at least 2 compatible hospitals.",
                                      "hospitals", "computed"),
    "universes_n_ge_2": ("State universes with at least 2 compatible hospitals.", "universes", "computed"),
    "median_width_share_of_n": ("Median of rank-range width (worst_rank minus best_rank plus 1) divided by n.",
                                "proportion", "computed"),
    "share_width_over_half_of_n": ("Share of hospitals whose rank-range width is more than half of n.", "proportion",
                                   "computed"),
    "share_full_range": ("Share of hospitals whose rank range covers every rank from 1 to n.", "proportion", "computed"),
    "universes_n_ge_10": ("State universes with at least 10 compatible hospitals.", "universes", "computed"),
    "top_ranked_median_worst_rank_share_n_ge_10": ("For the point-estimate first-ranked hospital of each universe with "
                                                   "at least 10 hospitals (lowest score, ties by Facility ID), the median "
                                                   "of worst_rank divided by n.", "proportion", "computed"),
    "top_ranked_worst_rank_over_half_n_ge_10": ("Number of those first-ranked hospitals whose worst_rank is more than "
                                                "half of n.", "hospitals", "computed"),
    # compatibility matrix
    "measure_a": ("First Measure ID of the requested cross-measure comparison (alphabetical order).", "code",
                  "measure dictionary"),
    "measure_b": ("Second Measure ID of the requested cross-measure comparison.", "code", "measure dictionary"),
    "same_measure_id": ("TRUE when the two Measure IDs are identical.", "TRUE or FALSE", "computed"),
    "same_quantity": ("TRUE when the documented quantities are identical.", "TRUE or FALSE",
                      "computed from config/measures.toml"),
    "same_unit": ("TRUE when the documented units are identical.", "TRUE or FALSE", "computed from config/measures.toml"),
    "same_window": ("TRUE when the modal observation windows in the release are identical.", "TRUE or FALSE",
                    "computed from record windows"),
    "same_condition": ("TRUE when the conditions are identical.", "TRUE or FALSE", "computed from config/measures.toml"),
    "same_source_program": ("TRUE when both measures come from the same program: Care Compare (Unplanned Hospital "
                            "Visits, Complications and Deaths) or the HRRP payment program.", "TRUE or FALSE",
                            "computed from dataset_key"),
    "n_checks_failed": ("Number of the six checks that are FALSE.", "checks", "computed"),
    "window_a": ("Modal observation window of measure_a in the release, with its length in months.", "text",
                 "computed from record windows"),
    "window_b": ("Modal observation window of measure_b in the release, with its length in months.", "text",
                 "computed from record windows"),
    "quantity_a": ("Documented quantity of measure_a.", "text", "config/measures.toml"),
    "quantity_b": ("Documented quantity of measure_b.", "text", "config/measures.toml"),
    "comparable": ("TRUE only when all six checks pass.", "TRUE or FALSE", "computed"),
    "first_failed_check": ("First failing check in the column order shown; blank when comparable.", "check name",
                           "computed"),
    # cross-release
    "study_role": ("primary, supporting, secondary (sensitivity analysis S3) or lookalike (definition checks only).",
                   "category", "config/measures.toml"),
    "release_role": ("Role of the release: primary, flagged or current.", "category", "config/releases.toml"),
    "interval_status": ("Documented status of the release's interval estimates: published, flagged_by_cms_notice or "
                        "suppressed_by_cms_notice. Drives gate G0.", "category", "config/releases.toml"),
    "window_start": ("Most common record start date for the measure in the release.", "date (ISO text)",
                     "computed from CMS field 'Start Date'"),
    "window_end": ("Most common record end date for the measure in the release.", "date (ISO text)",
                   "computed from CMS field 'End Date'"),
    "window_months": ("Length of the observation window in calendar months.", "months", "computed"),
    "official_start": ("Start date for the Measure ID in the release's Measure Dates file.", "date (ISO text)",
                       "CMS Measure Dates field 'Start Date'"),
    "official_end": ("End date for the Measure ID in the release's Measure Dates file.", "date (ISO text)",
                     "CMS Measure Dates field 'End Date'"),
    "window_matches_official": ("TRUE when the record window equals the official Measure Dates window.",
                                "TRUE or FALSE", "computed"),
    "overlap_months_with_primary": ("Calendar months shared with the measure's window in the primary release.",
                                    "months", "computed"),
    "same_window_as_primary": ("TRUE when the window equals the measure's window in the primary release.",
                               "TRUE or FALSE", "computed"),
    "documented_definition_change_since_primary": ("Documented definition change between the primary release and this "
                                                   "release; blank when none is documented.", "text",
                                                   "config/releases.toml"),
    "definition_change_source": ("Citation for the documented definition change.", "text", "config/releases.toml"),
    "release_a": ("First release of the comparison.", "date (ISO text)", "config/releases.toml"),
    "release_b": ("Second release of the comparison.", "date (ISO text)", "config/releases.toml"),
    "facilities_a": ("Distinct Facility IDs in the Unplanned Hospital Visits file of release_a.", "facilities",
                     "computed"),
    "facilities_b": ("Distinct Facility IDs in the Unplanned Hospital Visits file of release_b.", "facilities",
                     "computed"),
    "in_both": ("Facility IDs present in both releases.", "facilities", "computed"),
    "only_in_a": ("Facility IDs present in release_a and absent from release_b.", "facilities", "computed"),
    "only_in_b": ("Facility IDs present in release_b and absent from release_a.", "facilities", "computed"),
    "only_in_a_ids": ("The Facility IDs counted in only_in_a, separated by spaces. No link across a changed identifier "
                      "is inferred.", "text", "computed"),
    "only_in_b_ids": ("The Facility IDs counted in only_in_b, separated by spaces.", "text", "computed"),
    # reconciliation
    "geography": ("NATION for the national file row, or the state code for the state file row.", "code",
                  "CMS national and state files"),
    "category": ("CMS comparison category: better, no_different, worse and too_small for rates; fewer, average, more "
                 "and too_small for excess days in acute care.", "category", "CMS field 'Compared to National'"),
    "hospital_rows": ("Hospital rows in the release's hospital file whose 'Compared to National' text falls in the "
                      "category.", "hospitals", "computed from CMS field 'Compared to National'"),
    "cms_aggregate_src": ("Count of hospitals in the category exactly as published in the CMS national or state file.",
                          "text", "CMS fields 'Number of Hospitals Better', 'Number of Hospitals Same', 'Number of "
                          "Hospitals Worse', 'Number of Hospitals Too Few' (rates) or 'Number of Hospitals Fewer', "
                          "'Number of Hospitals Average', 'Number of Hospitals More', 'Number of Hospitals Too Small' "
                          "(excess days)"),
    "cms_aggregate": ("cms_aggregate_src parsed as a number; blank when CMS did not publish a number.", "hospitals",
                      "parsed from cms_aggregate_src"),
    "difference": ("hospital_rows minus cms_aggregate; blank when CMS did not publish a number.", "hospitals",
                   "computed"),
    # raw reconstruction
    "selection": ("Which record was picked: the first, middle or last compatible record by Facility ID, or the first "
                  "too_few_cases record.", "category", "docs/analysis_plan.md, Checks"),
    "source_file": ("Raw CSV file the record was re-read from.", "file name", "source_manifest.json"),
    "fields_compared": ("Fields compared between the raw CSV bytes and the database: 11 source strings and 3 parsed "
                        "numbers.", "fields", "computed: hospcomp.validate"),
    "mismatches": ("Fields that differed, with both values; blank when every field matched.", "text",
                   "computed: hospcomp.validate"),
    "matched": ("TRUE when every compared field agrees.", "TRUE or FALSE", "computed: hospcomp.validate"),
    # footnotes
    "code": ("Footnote code.", "code", "CMS Footnote Crosswalk field 'Footnote'"),
    "footnote_text": ("Footnote text.", "text", "CMS Footnote Crosswalk field 'Footnote Text'"),
    "study_class": ("How the study treats the footnote: availability, window_blocking, caution or informational.",
                    "category", "config/measures.toml footnote policy"),
    "study_effect": ("Effect of the footnote class on the gates.", "text",
                     "config/measures.toml footnote policy; sql/02_gates.sql"),
    # measures
    "condition": ("Clinical condition of the measure cohort.", "text", "config/measures.toml"),
    "endpoint": ("Outcome the measure counts.", "text", "config/measures.toml"),
    "quantity": ("Quantity reported in the score.", "text", "config/measures.toml"),
    "unit": ("Unit of the score and interval limits.", "text", "config/measures.toml"),
    "favorable": ("Direction in which values are more favorable (lower for every measure here).", "category",
                  "config/measures.toml"),
    "lower_bound": ("Lowest admissible value used by gate G5. -1,000,000,000 marks no practical bound, since excess "
                    "days can be negative.", "measure unit", "config/measures.toml"),
    "upper_bound": ("Highest admissible value used by gate G5. 1,000,000,000 marks no practical bound.", "measure unit",
                    "config/measures.toml"),
    "doc_source": ("Documentation page supporting the quantity, unit and direction.", "text", "config/measures.toml"),
    "source_measure_name": ("Measure Name written in the release's file for the Measure ID.", "text",
                            "CMS field 'Measure Name'"),
    "n_source_names": ("Distinct Measure Names for the Measure ID in the file; gate G2 requires 1.", "names",
                       "computed"),
    "official_name": ("Measure Name in the release's Measure Dates file.", "text", "CMS Measure Dates field 'Measure Name'"),
    "modal_start": ("Most common record start date for the measure in the release.", "date (ISO text)", "computed"),
    "modal_end": ("Most common record end date for the measure in the release.", "date (ISO text)", "computed"),
    "reported_decimals": ("Most common number of decimal places in published scores and limits; pair comparisons use "
                          "integers in units of this last decimal.", "decimal places", "computed"),
    "n_window_variants": ("Distinct start and end date combinations among the release's records for the measure.",
                          "windows", "computed"),
    # releases and provenance
    "role": ("Role of the release: primary, flagged or current.", "category", "config/releases.toml"),
    "label": ("Description of the release.", "text", "config/releases.toml"),
    "status_note": ("Documented basis for the interval status.", "text", "config/releases.toml"),
    "notice": ("CMS notice that changed the interval status; blank when none applies.", "text", "config/releases.toml"),
    "notice_url": ("Address of the CMS notice.", "URL", "config/releases.toml"),
    "dataset_id": ("CMS Provider Data Catalog dataset identifier for current catalogue files; the study dataset key for "
                   "archive members.", "code", "CMS metastore record or archive listing"),
    "released": ("Release date recorded by CMS for the file.", "date (ISO text)", "CMS metastore record or archive listing"),
    "modified": ("Last-modified date recorded by CMS (catalogue files) or the date of the archive member timestamp.",
                 "date (ISO text)", "CMS metastore record or archive zip member"),
    "file_version": ("Catalogue distribution version (catalogue files) or archive member timestamp (archive files).",
                     "text", "CMS metastore record or archive zip member"),
    "download_url": ("Download address. Archive members are given as the archive zip address followed by '#' and the "
                     "member file name.", "URL", "source_manifest.json"),
    "sha256": ("SHA-256 checksum of the stored file.", "hex digest", "source_manifest.json"),
    "data_rows": ("Data rows in the file, excluding the header.", "rows", "source_manifest.json"),
    "source_type": ("document (retrieved over HTTPS), browser document (saved from a browser session because the site "
                    "requires JavaScript) or archive package (official CMS archive zip).", "category",
                    "source_manifest.json"),
    "key": ("Key of the source in source_manifest.json and config/study.toml.", "code", "source_manifest.json"),
    "url": ("Address the file was retrieved from, or the address of the cited document.", "URL",
            "source_manifest.json; config/releases.toml"),
    "local_path": ("Project-relative path of the stored copy.", "path", "source_manifest.json"),
    "bytes": ("Size of the stored file.", "bytes", "source_manifest.json"),
    "retrieval_note": ("How and when the file was retrieved, as recorded in source_manifest.json.", "text",
                       "source_manifest.json"),
    "citation_type": ("Kind of cited source: CMS notice or Federal Register rule.", "category", "config/releases.toml"),
    "citation": ("Citation as recorded in the study configuration.", "text", "config/releases.toml"),
    "applies_to": ("Releases or measures the citation applies to.", "text", "config/releases.toml"),
    "detail": ("Documented status or definition change taken from the citation.", "text", "config/releases.toml"),
    "reason": ("Documented reason the hospital type's results come from a different population or data source.", "text",
               "config/population_exclusions.csv"),
}

# Columns whose meaning depends on the sheet.
SHEET_DEFINITIONS: dict[tuple[str, str], tuple[str, str, str]] = {
    ("Releases", "source"): ("archive for an official CMS archive snapshot; live for the current catalogue files.",
                             "category", "config/releases.toml"),
    ("Releases", "title"): ("File title: the catalogue dataset title (catalogue files) or the archive snapshot name and "
                            "member file name (archive files).", "text", "CMS metastore record or archive listing"),
    ("Source evidence", "title"): ("Title of the document or archive package.", "text", "source_manifest.json"),
    ("Source evidence", "source"): ("Document and page that state the population or data source difference.", "text",
                                    "config/population_exclusions.csv"),
    ("Source evidence", "hospital_type"): ("Hospital type excluded from comparisons with other types for the measure.",
                                           "category", "config/population_exclusions.csv"),
    ("Gate flow", "compatible"): ("Records passing every gate from G0 to G6.", "records", "computed from gate flags"),
    ("Gate flow by state", "compatible"): ("Records passing every gate from G0 to G6.", "records",
                                           "computed from gate flags"),
    ("State summary", "q1"): ("25th percentile across states of the state-level R1 not-separated share.", "proportion",
                              "computed"),
    ("State summary", "q3"): ("75th percentile across states of the state-level R1 not-separated share.", "proportion",
                              "computed"),
    ("Hospital summary", "q1"): ("25th percentile across hospitals of the hospital-level R1 separated share.",
                                 "proportion", "computed"),
    ("Hospital summary", "q3"): ("75th percentile across hospitals of the hospital-level R1 separated share.",
                                 "proportion", "computed"),
    ("Footnotes", "availability_state"): ("Availability state given to a non-numeric score that carries this footnote; "
                                          "blank for footnotes outside the availability class.", "category",
                                          "config/measures.toml footnote policy"),
    ("Raw reconstruction", "source_row"): ("Data row re-read from the raw CSV file, counted from 1 after the header.",
                                           "row number", "records table"),
}

STUDY_EFFECT = {
    "availability": "Non-numeric score: sets availability_state and fails G4. On a numeric score: fails G6.",
    "window_blocking": "Fails G3 (partial or shorter observation period).",
    "caution": "Passes with caution_flag = 1; removed in the strict subset (S1 ii).",
    "informational": "No effect on any gate.",
}

SHEET_GUIDE = {
    "Read me": "Run identifiers, purpose, reading notes, the gate rules and this guide.",
    "Definitions": "Every column used in the later sheets with a plain definition, its unit and its source: the field "
                   "name in the CMS file or the rule that computes it. Look up any header here.",
    "Releases": "The three loaded releases with their documented interval status and the CMS notice behind it, then one "
                "row per source file with title, release date, file version, download address, SHA-256 and row count. "
                "Use the SHA-256 values to confirm that a local copy is the file analyzed.",
    "Gate flow": "National counts by release and measure: records requested, records remaining after each gate in "
                 "order, records passing each gate on its own, and compatible counts and shares. Row 1 gives a readable "
                 "label for each column. Read across a row to see where records leave the comparison.",
    "Gate flow by state": "The same counts for each state in the primary release. Filter on measure_id to compare "
                          "states for one measure.",
    "Records primary": "One row per requested record for the six study measures in the primary release: source strings "
                       "as published, parsed values, each gate decision, the first failed gate, the reason code and, for "
                       "compatible records, the point rank and the interval-compatible rank range. Filter on reason_code "
                       "or first_failed_gate to see why records were excluded, or on compatible = 1 for the comparison "
                       "set.",
    "Records current HF": "The same layout for the three heart failure measures in the current release. Many scores are "
                          "numeric while the interval limits read 'Not Available'. Every record fails gate G0 because "
                          "the release's intervals are suppressed under the CMS notice listed on the Releases sheet, so "
                          "no rank is shown.",
    "Pair summary": "Pooled pair counts for each subset and measure in the primary release: pairs, point-ordered pairs, "
                    "ties, and counts and shares separated under rules R1, R2 and R3, with the CMS category reference "
                    "row. not_separated_r1_share is the primary pair metric.",
    "State summary": "The R1 not-separated share summarized across states with each state weighted equally (median, "
                     "quartiles, minimum and maximum).",
    "Hospital summary": "For each compatible hospital, the share of its point-ordered same-state comparisons separated "
                        "under R1, summarized across hospitals, with the number and share of hospitals separated from "
                        "none of their peers.",
    "Rank ranges summary": "Rank-range width relative to universe size, the shares of hospitals whose range covers more "
                           "than half or all of the possible ranks, and the worst compatible rank of each point-estimate "
                           "first-ranked hospital in universes of at least 10 hospitals.",
    "Compatibility matrix": "For every pair of the eight dictionary measures in each release: whether Measure ID, "
                            "quantity, unit, observation window, condition and source program agree, and the first "
                            "check that fails. Shows why a cross-measure comparison, including one with an HRRP "
                            "look-alike measure, is refused.",
    "Cross-release": "Observation windows of each measure in each release, months shared with the primary release and "
                     "documented definition changes with their citations, then counts and lists of Facility IDs present "
                     "in one release and absent from another.",
    "Reconciliation": "Counts of hospitals by CMS category computed from hospital rows next to the counts CMS publishes "
                      "in its national and state files. National rows come first. A blank cms_aggregate means CMS did "
                      "not publish a number for that cell.",
    "Raw reconstruction": "Records re-read from the raw CSV bytes with an independent parser and compared field by "
                          "field with the database: the first, middle and last compatible record and the first "
                          "too_few_cases record for each study measure.",
    "Footnotes": "The CMS Footnote Crosswalk of the primary release with the study class of each code and its effect on "
                 "the gates.",
    "Measures": "The measure dictionary (condition, endpoint, quantity, unit, favorable direction, bounds and "
                "documentation source) joined with each release's official and observed observation windows.",
    "Source evidence": "Official documents and archive packages with address, local path, size, SHA-256 and retrieval "
                       "note; the CMS notice and Federal Register citations behind the release status and definition "
                       "changes; and the documented population exclusions applied at gate G2b.",
}

# ---------------------------------------------------------------------------
# Static helpers (no database needed)
# ---------------------------------------------------------------------------


def sheet_columns() -> dict[str, list[str]]:
    """Columns written on each table sheet, in order, as declared in BLOCK_COLUMNS."""
    out: dict[str, list[str]] = {}
    for sheet, blocks in SHEETS:
        cols: list[str] = []
        for b in blocks:
            cols += [c for c in BLOCK_COLUMNS[b] if c not in cols]
        if blocks:
            out[sheet] = cols
    return out


def definition_for(sheet: str, column: str) -> tuple[str, str, str] | None:
    return SHEET_DEFINITIONS.get((sheet, column)) or DEFINITIONS.get(column)


def undefined_columns() -> list[tuple[str, str]]:
    return [(s, c) for s, cols in sheet_columns().items() for c in cols if definition_for(s, c) is None]


def definition_rows() -> list[list[str]]:
    """One row per distinct (column, definition), listing the sheets that use it."""
    order: list[tuple] = []
    sheets_for: dict[tuple, list[str]] = {}
    for sheet, cols in sheet_columns().items():
        for col in cols:
            d = definition_for(sheet, col)
            if d is None:
                raise KeyError(f"no definition for column {col!r} on sheet {sheet!r}")
            key = (col, *d)
            if key not in sheets_for:
                sheets_for[key] = []
                order.append(key)
            if sheet not in sheets_for[key]:
                sheets_for[key].append(sheet)
    return [[k[0], ", ".join(sheets_for[k]), k[1], k[2], k[3]] for k in order]


PERCENT_FORMAT = "0.0%"
INTEGER_FORMAT = "#,##0"
INTEGER_LIKE = {"denominator_num", "cms_aggregate", "difference", "lower_bound", "upper_bound", "point_rank",
                "best_rank", "worst_rank", "n"}


def is_percent_column(column: str) -> bool:
    return "share" in column or column in ("q1", "q3")


def number_format(column: str, value) -> str | None:
    """Display format for one cell: proportions as 0.0%, integer counts with thousands separators."""
    if value is None or isinstance(value, (bool, str)):
        return None
    if is_percent_column(column):
        return PERCENT_FORMAT
    if isinstance(value, int):
        return INTEGER_FORMAT
    if isinstance(value, float) and column in INTEGER_LIKE and value.is_integer():
        return INTEGER_FORMAT
    return None


# Columns read from CSV that must stay text (identifiers, codes, dates and published strings).
TEXT_COLUMNS = {
    "release_key", "release_a", "release_b", "facility_id", "state", "measure_id", "measure_a", "measure_b", "geography",
    "category", "cms_aggregate_src", "score_src", "lower_src", "upper_src", "denominator_src", "footnote_src",
    "only_in_a_ids", "only_in_b_ids", "record_id", "mismatches", "window_start", "window_end", "official_start",
    "official_end", "window_a", "window_b", "source_file", "selection", "subset",
}
_INT_RE = re.compile(r"^[+-]?\d+$")


def typed(column: str, raw: str):
    """Convert one CSV string to the Python value written to the sheet."""
    if raw == "":
        return None
    if column in TEXT_COLUMNS:
        return raw
    if raw in ("True", "False"):
        return raw == "True"
    if _INT_RE.match(raw):
        return int(raw)
    try:
        value = float(raw)
    except ValueError:
        return raw
    if not math.isfinite(value):
        return raw
    if column in INTEGER_LIKE and value.is_integer():
        return int(value)
    return value


def read_csv_block(path: Path, columns: list[str]) -> list[list]:
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        if header != columns:
            raise ValueError(f"{rel(path)} header changed: {header} != {columns}")
        return [[typed(c, v) for c, v in zip(columns, row)] for row in reader]


def clean(value):
    if isinstance(value, float) and math.isnan(value):
        return None
    if hasattr(value, "item") and not isinstance(value, (str, bytes)):
        value = value.item()
    return value


def _footnote_sort_key(code: str):
    return (0, int(code), code) if code.isdigit() else (1, 0, code)


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------


class Context:
    def __init__(self, db_path: Path) -> None:
        self.con = sqlite3.connect(f"{db_path.as_uri()}?mode=ro", uri=True)
        self.run = read_json(OUTPUTS / "run_manifest.json")
        self.manifest = read_json(ROOT / "source_manifest.json")
        with open(ROOT / "config" / "releases.toml", "rb") as fh:
            self.releases_cfg = tomllib.load(fh)
        self.primary = self.run["primary_release"]
        roles = dict(self.con.execute("SELECT role, release_key FROM releases"))
        if roles.get("primary") != self.primary:
            raise ValueError(f"primary release in database {roles.get('primary')} != run manifest {self.primary}")
        self.current = roles["current"]
        self.flagged = roles.get("flagged")

    def query(self, sql: str, params: tuple = ()) -> list[list]:
        return [[clean(v) for v in row] for row in self.con.execute(sql, params)]


def load_records(ctx: Context, release_key: str, measures: list[str]) -> list[list]:
    ph = ",".join("?" * len(measures))
    sql = f"""
        SELECT g.release_key, g.measure_id, g.state, g.facility_id, g.facility_name, g.hospital_type, g.dataset_key,
               r.source_row, g.score_src, g.lower_src, g.upper_src, g.denominator_src, g.compared_to_national_src,
               g.footnote_src, r.start_date_src, r.end_date_src, g.score_num, g.lower_num, g.upper_num,
               g.denominator_num, g.start_date, g.end_date, g.availability_state,
               {", ".join("g." + gate for gate in GATES)},
               g.first_failed_gate, g.reason_code, g.compatible, g.caution_flag,
               k.point_rank, k.best_rank, k.worst_rank, k.n, g.record_id
          FROM gate_results g
          JOIN records r ON r.record_id = g.record_id
          LEFT JOIN rank_ranges k
            ON k.subset = 'primary' AND k.release_key = g.release_key AND k.measure_id = g.measure_id
           AND k.state = g.state AND k.facility_id = g.facility_id
         WHERE g.release_key = ? AND g.measure_id IN ({ph})"""
    rows = ctx.query(sql, (release_key, *measures))
    rows.sort(key=lambda r: (MEASURE_ORDER[r[1]], r[2] or "", r[3]))
    for r in rows:
        for i, col in enumerate(RECORD_COLUMNS):
            if col in INTEGER_LIKE and isinstance(r[i], float) and r[i].is_integer():
                r[i] = int(r[i])
    return rows


def load_block(ctx: Context, key: str) -> list[list]:
    cols = BLOCK_COLUMNS[key]
    if key in CSV_SOURCES:
        rows = read_csv_block(CSV_SOURCES[key], cols)
        if key == "gate_flow_state":
            rows = [r for r in rows if r[0] == ctx.primary]
        if key == "reconciliation":
            rows = sorted(rows, key=lambda r: (r[2] != "NATION", r[0], r[1], r[2] if r[2] != "NATION" else ""))
        return rows
    if key == "records_primary":
        return load_records(ctx, ctx.primary, STUDY_MEASURES)
    if key == "records_current":
        return load_records(ctx, ctx.current, CURRENT_HF_MEASURES)
    if key == "releases":
        rows = ctx.query(f"SELECT {', '.join(cols)} FROM releases ORDER BY release_key")
        return [documented_release_row(ctx, cols, r) for r in rows]
    if key == "source_files":
        return ctx.query(f"SELECT {', '.join(cols)} FROM source_files ORDER BY release_key, rowid")
    if key == "footnotes":
        rows = ctx.query("SELECT release_key, code, footnote_text, study_class, availability_state "
                         "FROM footnote_dictionary WHERE release_key = ?", (ctx.primary,))
        rows.sort(key=lambda r: _footnote_sort_key(r[1]))
        return [r + [STUDY_EFFECT[r[3]]] for r in rows]
    if key == "measures":
        rows = ctx.query(
            "SELECT w.release_key, d.measure_id, d.study_role, d.dataset_key, d.condition, d.endpoint, d.quantity, "
            "d.unit, d.favorable, d.lower_bound, d.upper_bound, d.doc_source, w.source_measure_name, w.n_source_names, "
            "w.official_name, w.official_start, w.official_end, w.modal_start, w.modal_end, w.window_months, "
            "w.reported_decimals, w.n_window_variants "
            "FROM measure_windows w JOIN measure_dictionary d ON d.measure_id = w.measure_id")
        rows.sort(key=lambda r: (r[0], MEASURE_ORDER.get(r[1], 99), r[1]))
        for r in rows:
            for i in (9, 10):
                if isinstance(r[i], float) and r[i].is_integer():
                    r[i] = int(r[i])
        return rows
    if key == "documents":
        return document_rows(ctx)
    if key == "citations":
        return citation_rows(ctx)
    if key == "population_exclusions":
        path = ROOT / "config" / "population_exclusions.csv"
        return read_csv_block(path, cols)
    raise KeyError(key)


# Release descriptions are documentation text and feed no gate. They are taken from config/releases.toml, the source
# named on the Definitions sheet, so the Releases sheet and the citation rows on Source evidence carry the same wording.
# The fields that decide gate G0 must still agree with the frozen database.
RELEASE_TEXT_FIELDS = ("label", "status_note", "notice", "notice_url")
RELEASE_GATE_FIELDS = ("source", "role", "interval_status")


def documented_release_row(ctx: Context, cols: list[str], row: list) -> list:
    cfg = {r["key"]: r for r in ctx.releases_cfg.get("release", [])}.get(row[0])
    if cfg is None:
        raise ValueError(f"release {row[0]} is in the database and missing from config/releases.toml")
    out = list(row)
    for field in RELEASE_GATE_FIELDS:
        i = cols.index(field)
        if cfg.get(field) != row[i]:
            raise ValueError(f"release {row[0]} {field}: database {row[i]!r} != config/releases.toml {cfg.get(field)!r}")
    for field in RELEASE_TEXT_FIELDS:
        if field in cols:
            out[cols.index(field)] = cfg.get(field) or None
    return out


def document_rows(ctx: Context) -> list[list]:
    man = ctx.manifest
    rows = []
    for key, d in man.get("documents", {}).items():
        http = d.get("http", {})
        note = f"HTTP {http.get('http_status')} ({http.get('content_type')}); accessed {d.get('accessed_utc')}"
        if http.get("last_modified_header"):
            note += f"; server Last-Modified {http['last_modified_header']}"
        rows.append(["document", key, d["title"], d["url"], d["local_path"], d["bytes"], d["sha256"], note])
    for key, d in man.get("documents_browser", {}).items():
        note = d.get("retrieval", "")
        if d.get("present") and d.get("is_pdf"):
            note += "; PDF signature and SHA-256 checked"
        rows.append(["browser document", key, d["title"], d["url"], d["local_path"], d["bytes"], d["sha256"], note])
    for key, a in man.get("archives", {}).items():
        http = a.get("http", {})
        note = (f"HTTP {http.get('http_status')} ({http.get('content_type')}); accessed {a.get('accessed_utc')}; "
                f"{a.get('zip_member_count')} members in the package; size equals the archive listing: "
                f"{'yes' if a.get('listing_size_matches') else 'no'}")
        rows.append(["archive package", key, a["archive_name"], a["zip_url"], a["zip_local_path"], a["zip_bytes"],
                     a["zip_sha256"], note])
    return rows


def citation_rows(ctx: Context) -> list[list]:
    rows = []
    notices: dict[tuple[str, str], list[dict]] = {}
    for r in ctx.releases_cfg.get("release", []):
        if r.get("notice"):
            notices.setdefault((r["notice"], r["notice_url"]), []).append(r)
    for (notice, url), rels in notices.items():
        rows.append(["CMS notice", notice, url,
                     "; ".join(f"release {r['key']} ({r['interval_status']})" for r in rels),
                     " ".join(f"Release {r['key']}: {r['status_note']}" for r in rels)])
    for ch in ctx.releases_cfg.get("definition_change", []):
        rows.append(["Federal Register rule", ch["source"], ch["source_url"],
                     f"{', '.join(ch['measure_ids'])}; release {ch['from_release']} to release {ch['to_release']}",
                     ch["change"]])
    return rows


# ---------------------------------------------------------------------------
# Writing
# ---------------------------------------------------------------------------

HEADER_FONT = Font(bold=True)
HEADER_FILL = PatternFill("solid", fgColor="D9D9D9")
LABEL_FILL = PatternFill("solid", fgColor="F2F2F2")
LABEL_FONT = Font(italic=True)
TITLE_FONT = Font(bold=True, size=14)
BLOCK_FONT = Font(bold=True, size=12)
WRAP = Alignment(wrap_text=True, vertical="top")
TOP = Alignment(vertical="top")

WRAP_COLUMNS = {
    "label", "status_note", "notice", "title", "footnote_text", "doc_source", "documented_definition_change_since_primary",
    "definition_change_source", "only_in_a_ids", "only_in_b_ids", "mismatches", "retrieval_note", "citation", "detail",
    "applies_to", "reason", "source", "study_effect", "official_name", "source_measure_name",
}
WRAP_WIDTH = {"only_in_a_ids": 40, "only_in_b_ids": 40, "footnote_text": 70, "detail": 70, "status_note": 60,
              "documented_definition_change_since_primary": 60}
MAX_WIDTH = 48
LINE_HEIGHT = 15.0


def _display_len(column: str, value) -> int:
    if value is None:
        return 0
    if isinstance(value, bool):
        return 5
    fmt = number_format(column, value)
    if fmt == PERCENT_FORMAT:
        return 6
    if fmt == INTEGER_FORMAT:
        return len(f"{int(value):,}")
    if isinstance(value, float):
        return min(len(repr(value)), 12)
    return len(str(value))


def _lines(text, width: float) -> int:
    if text is None:
        return 1
    total = 0
    for part in str(text).split("\n"):
        total += max(1, math.ceil(len(part) / max(width * 1.05, 1)))
    return total


def _cell(ws, value, *, font=None, fill=None, align=None, fmt=None):
    c = WriteOnlyCell(ws, value=value)
    if isinstance(value, str) and value.startswith("="):
        c.data_type = "s"
    if font is not None:
        c.font = font
    if fill is not None:
        c.fill = fill
    if align is not None:
        c.alignment = align
    if fmt is not None:
        c.number_format = fmt
    return c


def _set_dimension(ws, ncols: int, nrows: int) -> None:
    ref = f"A1:{get_column_letter(max(ncols, 1))}{max(nrows, 1)}"
    ws.calculate_dimension = lambda: ref  # write-only sheets do not compute this themselves


def gate_flow_label(column: str) -> str:
    fixed = {
        "release_key": "Release", "measure_id": "Measure ID", "state": "State", "requested_records": "Requested records",
        "numeric_score_without_usable_interval": "Numeric score without usable interval",
        "compatible": "Compatible (passed every gate)",
        "compatible_strict": "Compatible without caution footnotes (S1 strict)",
        "compatible_share_of_requested": "Compatible share of requested",
        "broader_denominator_general_info": "Hospitals in the General Information file",
        "absent_from_measure_file": "Hospitals with no row in the measure file",
        "compatible_share_of_broader": "Compatible share of General Information hospitals",
        "compatible_strict_share_of_requested": "Strict compatible share of requested",
    }
    if column in fixed:
        return fixed[column]
    for prefix, text in (("pass_through_", "Remaining after {code} ({desc})"),
                         ("independent_pass_", "Passing {code} ({desc}) on its own")):
        if column.startswith(prefix):
            code, desc = GATE_LABELS[column[len(prefix):]].split(" ", 1)
            return text.format(code=code, desc=desc)
    return column


def write_table_sheet(wb: Workbook, sheet: str, blocks: list[tuple[str, list[list]]]) -> int:
    ws = wb.create_sheet(sheet)
    multi = len(blocks) > 1
    label_row = sheet in LABEL_ROW_SHEETS

    # column widths across all blocks
    ncols = max(len(BLOCK_COLUMNS[k]) for k, _ in blocks)
    widths = [8.0] * ncols
    for key, rows in blocks:
        cols = BLOCK_COLUMNS[key]
        for i, col in enumerate(cols):
            longest = max([len(col)] + [_display_len(col, r[i]) for r in rows])
            cap = WRAP_WIDTH.get(col, MAX_WIDTH) if col in WRAP_COLUMNS else MAX_WIDTH
            widths[i] = max(widths[i], min(longest + 2, cap))
    if label_row:
        widths = [max(w, 12) for w in widths]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = round(w, 1)

    # row layout and heights
    plan: list[tuple[str, object]] = []
    for bi, (key, rows) in enumerate(blocks):
        if multi:
            if bi:
                plan.append(("blank", None))
            plan.append(("title", key))
        if label_row:
            plan.append(("labels", key))
        plan.append(("header", key))
        for r in rows:
            plan.append(("data", (key, r)))
    total_rows = len(plan)
    for idx, (kind, payload) in enumerate(plan, 1):
        if kind == "labels":
            ws.row_dimensions[idx].height = LINE_HEIGHT * 3
        elif kind == "data" and len(plan) <= 5000:
            key, r = payload
            cols = BLOCK_COLUMNS[key]
            lines = max([1] + [_lines(r[i], widths[i]) for i, c in enumerate(cols) if c in WRAP_COLUMNS and r[i]])
            if lines > 1:
                ws.row_dimensions[idx].height = LINE_HEIGHT * min(lines, 20)

    if sheet in FREEZE:
        ws.freeze_panes = FREEZE[sheet]
    elif not multi:
        ws.freeze_panes = "A2"
    if not multi:
        key, rows = blocks[0]
        header_row = 2 if label_row else 1
        ws.auto_filter.ref = f"A{header_row}:{get_column_letter(len(BLOCK_COLUMNS[key]))}{header_row + len(rows)}"
    _set_dimension(ws, ncols, total_rows)

    data_rows = 0
    for kind, payload in plan:
        if kind == "blank":
            ws.append([])
        elif kind == "title":
            ws.append([_cell(ws, BLOCK_TITLES[payload], font=BLOCK_FONT)])
        elif kind == "labels":
            ws.append([_cell(ws, gate_flow_label(c), font=LABEL_FONT, fill=LABEL_FILL, align=WRAP)
                       for c in BLOCK_COLUMNS[payload]])
        elif kind == "header":
            ws.append([_cell(ws, c, font=HEADER_FONT, fill=HEADER_FILL, align=TOP) for c in BLOCK_COLUMNS[payload]])
        else:
            key, r = payload
            out = []
            for col, v in zip(BLOCK_COLUMNS[key], r):
                fmt = number_format(col, v)
                if col in WRAP_COLUMNS and isinstance(v, str):
                    out.append(_cell(ws, v, align=WRAP, fmt=fmt))
                elif fmt is not None or (isinstance(v, str) and v.startswith("=")):
                    out.append(_cell(ws, v, fmt=fmt))
                else:
                    out.append(v)
            ws.append(out)
            data_rows += 1
    return data_rows


def write_definitions(wb: Workbook) -> int:
    ws = wb.create_sheet("Definitions")
    header = ["Column", "Sheets", "Definition", "Unit", "Source"]
    rows = definition_rows()
    widths = [max(len(header[0]), max(len(r[0]) for r in rows)) + 2, 40, 70, 22, 45]
    keys = ["column", "sheets", "definition", "unit", "source"]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for idx, r in enumerate(rows, 2):
        lines = max(_lines(v, widths[i]) for i, v in enumerate(r))
        if lines > 1:
            ws.row_dimensions[idx].height = LINE_HEIGHT * lines
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:E{len(rows) + 1}"
    _set_dimension(ws, 5, len(rows) + 1)
    ws.append([_cell(ws, h, font=HEADER_FONT, fill=HEADER_FILL) for h in header])
    for r in rows:
        ws.append([_cell(ws, v, align=WRAP) if keys[i] != "column" else _cell(ws, v, align=TOP)
                   for i, v in enumerate(r)])
    return len(rows)


def readme_content(ctx: Context) -> dict:
    run = ctx.run
    rel_cols = BLOCK_COLUMNS["releases"]
    rel_rows = {r[0]: [r[0], r[rel_cols.index("label")], r[rel_cols.index("interval_status")], r[rel_cols.index("notice")]]
                for r in load_block(ctx, "releases")}
    roles: dict[str, list[str]] = {}
    for mid, role in ctx.query("SELECT measure_id, study_role FROM measure_dictionary"):
        roles.setdefault(role, []).append(mid)
    for v in roles.values():
        v.sort(key=lambda m: MEASURE_ORDER.get(m, 99))
    units = sorted({u for (u,) in ctx.query(
        f"SELECT DISTINCT unit FROM measure_dictionary WHERE measure_id IN ({','.join('?' * len(STUDY_MEASURES))})",
        tuple(STUDY_MEASURES))})
    favorable = {f for (f,) in ctx.query(
        f"SELECT DISTINCT favorable FROM measure_dictionary WHERE measure_id IN ({','.join('?' * len(STUDY_MEASURES))})",
        tuple(STUDY_MEASURES))}
    notice = rel_rows[ctx.current][3]
    flagged = ctx.flagged
    measures_text = (f"Primary: {', '.join(roles.get('primary', []))}. Supporting: {', '.join(roles.get('supporting', []))}. "
                     f"Secondary (sensitivity analysis S3): {', '.join(roles.get('secondary', []))}. Look-alike "
                     f"measures {' and '.join(roles.get('lookalike', []))} appear only in the definition checks.")
    facts = [
        ("Run ID", run["run_id"]),
        ("Run completed (UTC)", run["completed_utc"]),
        ("Package version", run["package_version"]),
        ("Primary release", f"{ctx.primary}: {rel_rows[ctx.primary][1]}"),
        ("Analysis plan", "docs/analysis_plan.md, locked by SHA-256 in docs/analysis_plan.lock.json. The lock is "
                          "internal and timestamped; the plan was not registered publicly."),
        ("Plan SHA-256", run["plan_sha256"]),
        ("Plan locked (UTC)", run["plan_locked_utc"]),
        ("Data source", "CMS Provider Data Catalog, hospitals theme (https://data.cms.gov/provider-data). The Releases "
                        "and Source evidence sheets list every file with its SHA-256."),
        ("Study measures", measures_text),
    ]
    purpose = ("This workbook is for reviewing which CMS hospital outcome records can enter a comparison between "
               "hospitals in the same state on the same measure, and why the others cannot. Every requested record "
               "passes through gates G0 to G6 in a fixed order, and the first failed gate and a reason code are recorded "
               "for each record. Records that pass every gate form the compatible subset, which is the only input to the "
               "pairwise interval comparisons and the rank ranges.")
    unit_text = " and ".join(units)
    fav_text = ("Lower values are more favorable for all six study measures." if favorable == {"lower"}
                else "See the Measures sheet for the favorable direction of each measure.")
    notes = [
        ("Rank ranges", "best_rank to worst_rank is an interval-compatible rank range: the ranks a hospital could take if "
                        "each hospital's true value lay anywhere inside its own published 95% interval. Rank ranges are "
                        "not confidence sets for ranks. They have no stated coverage and carry no probability."),
        ("CMS categories", "The 'Compared to National' categories are reproduced as source information. The separation "
                           "rules R1, R2 and R3 do not use them, and official_opposite in the Pair summary sheet is a "
                           "reference row only."),
        ("Data level", "All values are hospital-level aggregate statistics that CMS publishes for public use. The "
                       "workbook contains no person-level data."),
        ("Releases", f"Only the primary release {ctx.primary} enters pair and rank calculations. Intervals in release "
                     f"{flagged} were flagged and intervals in release {ctx.current} are suppressed under {notice}. "
                     f"Records from those releases fail gate G0 and are shown for comparison."),
        ("Units", f"Study measure units: {unit_text}. {fav_text}"),
        ("Display", "Shares are stored as proportions and shown as percentages. Dates are ISO text (YYYY-MM-DD). "
                    "Facility IDs are text so that leading zeros are kept. Gate flags are 1 for pass and 0 for fail."),
    ]
    gates = [(GATE_LABELS[g], GATE_RULES[g][0].upper() + GATE_RULES[g][1:] + ".") for g in GATES]
    guide = [(name, SHEET_GUIDE[name]) for name in SHEET_NAMES]
    return {"facts": facts, "purpose": purpose, "notes": notes, "gates": gates, "guide": guide}


def write_readme(wb: Workbook, ctx: Context) -> int:
    ws = wb.create_sheet("Read me")
    content = readme_content(ctx)
    widths = [26, 110]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    rows: list[tuple[str, list]] = [("title", [TITLE]), ("blank", [])]
    rows += [("fact", list(f)) for f in content["facts"]]
    rows += [("blank", []), ("section", ["Purpose"]), ("text", ["", content["purpose"]]), ("blank", []),
             ("section", ["Reading notes"])]
    rows += [("fact", list(n)) for n in content["notes"]]
    rows += [("blank", []), ("section", ["Gates, applied in order"])]
    rows += [("fact", list(g)) for g in content["gates"]]
    rows += [("blank", []), ("section", ["How to use each sheet"]), ("header", ["Sheet", "What it holds and how to use it"])]
    rows += [("fact", list(g)) for g in content["guide"]]
    for idx, (kind, vals) in enumerate(rows, 1):
        if kind in ("fact", "text") and len(vals) > 1:
            lines = max(_lines(vals[0], widths[0]), _lines(vals[1], widths[1]))
            if lines > 1:
                ws.row_dimensions[idx].height = LINE_HEIGHT * lines
        if kind == "title":
            ws.row_dimensions[idx].height = 22
    _set_dimension(ws, 2, len(rows))
    for kind, vals in rows:
        if kind == "blank":
            ws.append([])
        elif kind == "title":
            ws.append([_cell(ws, vals[0], font=TITLE_FONT)])
        elif kind == "section":
            ws.append([_cell(ws, vals[0], font=BLOCK_FONT)])
        elif kind == "header":
            ws.append([_cell(ws, v, font=HEADER_FONT, fill=HEADER_FILL) for v in vals])
        else:
            ws.append([_cell(ws, vals[0], font=HEADER_FONT, align=WRAP) if vals[0] else None,
                       _cell(ws, vals[1], align=WRAP)])
    return len(rows)


def _normalize_package(path: Path, stamp: str) -> None:
    """Rewrite the zip with fixed member timestamps and core-property dates so reruns are byte-identical."""
    with zipfile.ZipFile(path) as zin:
        items = [(i.filename, zin.read(i.filename)) for i in zin.infolist()]
    tmp = path.with_name(path.stem + ".tmp.xlsx")
    pattern = re.compile(rb"(<dcterms:(created|modified)[^>]*>)[^<]*(</dcterms:\2>)")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in items:
            if name == "docProps/core.xml":
                data = pattern.sub(lambda m: m.group(1) + stamp.encode() + m.group(3), data)
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zout.writestr(info, data)
    tmp.replace(path)


def run(db_path: Path = DB_PATH, out_path: Path = WORKBOOK_PATH) -> dict:
    ctx = Context(db_path)
    try:
        wb = Workbook(write_only=True)
        stamp = ctx.run["completed_utc"]
        when = datetime.strptime(stamp, "%Y-%m-%dT%H:%M:%SZ")
        wb.properties.creator = CREATOR
        wb.properties.lastModifiedBy = CREATOR
        wb.properties.title = TITLE
        wb.properties.identifier = ctx.run["run_id"]
        wb.properties.created = when
        wb.properties.modified = when

        counts: dict[str, int] = {}
        counts["Read me"] = write_readme(wb, ctx)
        counts["Definitions"] = write_definitions(wb)
        for sheet, blocks in SHEETS:
            if not blocks:
                continue
            loaded = [(k, load_block(ctx, k)) for k in blocks]
            counts[sheet] = write_table_sheet(wb, sheet, loaded)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(out_path)
    finally:
        ctx.con.close()
    _normalize_package(out_path, stamp)
    plan_now = sha256_file(ROOT / "docs" / "analysis_plan.md")
    return {
        "path": rel(out_path),
        "bytes": out_path.stat().st_size,
        "sha256": sha256_file(out_path),
        "run_id": ctx.run["run_id"],
        "primary_release": ctx.primary,
        "plan_matches_run": plan_now == ctx.run["plan_sha256"],
        "sheets": counts,
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=1))
