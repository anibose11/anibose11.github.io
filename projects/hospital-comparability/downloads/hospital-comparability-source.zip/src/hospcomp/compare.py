"""Reference implementations of the separation rules and rank ranges.

The study tables are computed in SQL (sql/03_pairs_ranks.sql). These small
functions restate the same rules in Python for the CLI and for tests that
check the SQL against an independent statement of the arithmetic.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Est:
    """One hospital's published estimate, in integer units of the last reported decimal."""

    facility_id: str
    score: int
    lower: int
    upper: int

    def oriented(self, favorable: str) -> tuple[int, int, int]:
        """(score, lo, hi) such that smaller is always more favorable."""
        if favorable == "lower":
            return self.score, self.lower, self.upper
        if favorable == "higher":
            return -self.score, -self.upper, -self.lower
        raise ValueError(f"favorable must be 'lower' or 'higher', got {favorable!r}")


def to_units(value: float, decimals: int) -> int:
    return int(round(value * 10**decimals))


def point_ordered(a: Est, b: Est) -> bool:
    return a.score != b.score


def separated_r1(a: Est, b: Est, favorable: str = "lower") -> bool:
    """Strict non-overlap. Touching endpoints are not separated."""
    _, alo, ahi = a.oriented(favorable)
    _, blo, bhi = b.oriented(favorable)
    return ahi < blo or bhi < alo


def separated_r2(a: Est, b: Est, favorable: str = "lower", margin_units: int = 1) -> bool:
    """Non-overlap with a gap larger than one unit in the last reported decimal."""
    _, alo, ahi = a.oriented(favorable)
    _, blo, bhi = b.oriented(favorable)
    return (blo - ahi) > margin_units or (alo - bhi) > margin_units


def separated_r3(a: Est, b: Est, favorable: str = "lower") -> bool:
    """Each point estimate lies outside the other hospital's interval."""
    as_, alo, ahi = a.oriented(favorable)
    bs, blo, bhi = b.oriented(favorable)
    return (as_ < blo or as_ > bhi) and (bs < alo or bs > ahi)


def interval_better(j: Est, i: Est, favorable: str = "lower") -> bool:
    """True when j is better than i under strict interval separation."""
    _, jlo, jhi = j.oriented(favorable)
    _, ilo, ihi = i.oriented(favorable)
    return jhi < ilo


def rank_range(i: Est, universe: list[Est], favorable: str = "lower") -> tuple[int, int, int]:
    """(point_rank, best_rank, worst_rank) for i within universe (which includes i).

    best  = 1 + #{j : U_j < L_i}
    worst = n - #{j : L_j > U_i}
    point = 1 + #{j : s_j < s_i}   (competition ranking; ties share the best rank)
    """
    n = len(universe)
    is_, ilo, ihi = i.oriented(favorable)
    better_point = 0
    surely_better = 0
    surely_worse = 0
    for j in universe:
        if j.facility_id == i.facility_id:
            continue
        js, jlo, jhi = j.oriented(favorable)
        if js < is_:
            better_point += 1
        if jhi < ilo:
            surely_better += 1
        if jlo > ihi:
            surely_worse += 1
    return 1 + better_point, 1 + surely_better, n - surely_worse
