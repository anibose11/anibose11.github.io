"""Build the static project page under site/projects/hospital-comparability/.

All numbers come from evidence/claims.json. The page links the full report,
the supplement, the source archive and small downloads. Filters in the viewer
only select rows of the frozen snapshot.
"""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

import jinja2

from .claims import values
from .common import OUTPUTS, ROOT, read_json
from .report import STATE_NAMES, f1, n, pct, ratio

SLUG = "hospital-comparability"
SITE = ROOT / "site" / "projects" / SLUG
ASSETS = SITE / "assets"
DOWNLOADS = SITE / "downloads"

PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hospital comparability</title>
<meta name="description" content="A release-aware check of CMS hospital outcome files that rejects comparisons the data cannot support and measures how much of a within-state hospital ordering the published intervals support.">
<link rel="stylesheet" href="assets/style.css">
{% if viewer %}<link rel="stylesheet" href="assets/viewer.css">{% endif %}
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="page-header">
  <nav aria-label="Breadcrumb"><a href="../../">Portfolio</a> <span aria-hidden="true">/</span> Hospital comparability</nav>
</header>
<main id="main" class="page-main">
<p class="kicker">Animesh Bose. Health services research using public CMS data.</p>
<h1>When hospital quality comparisons are not comparable</h1>
<p class="lede">In {{ state_name }}, the hospital ranked first for heart-failure readmission could occupy any rank from {{ v.ex_top.best_rank }} to {{ v.ex_top.worst_rank }} within the published intervals. I built a check that first establishes whether CMS records can be compared, then shows how much of their apparent ordering those intervals support.</p>

<div class="question">
<p><strong>Research question.</strong> When hospitals in one state are ranked on heart-failure readmission or mortality from the CMS Provider Data Catalog, how many requested records can enter a valid same-measure comparison, and how many of the resulting orderings do the published intervals separate?</p>
</div>

<figure>
  <img src="assets/figures/fig2_lead_example.svg" width="960" height="784" alt="Two-panel chart for {{ state_name }}. Left: {{ v.ex_n }} hospitals' heart-failure readmission rates with published 95% intervals, all overlapping. Right: each hospital's point rank and interval-compatible rank range; the first-ranked hospital's range spans ranks {{ v.ex_top.best_rank }} to {{ v.ex_top.worst_rank }}.">
  <figcaption>Heart-failure readmission in {{ state_name }}, April 2026 refresh (released 2026-05-13). The hospital ranked first on its point estimate ({{ f1(v.ex_top.score_num) }}%, interval {{ f1(v.ex_top.lower_num) }} to {{ f1(v.ex_top.upper_num) }}) could hold any rank from {{ v.ex_top.best_rank }} to {{ v.ex_top.worst_rank }}. None of the state's {{ n(v.ex_pairs.point_ordered) }} point orderings is separated by the published intervals. The state was chosen by a rule fixed before the analysis; the report explains how a four-way tie at the median count was resolved.</figcaption>
</figure>

<ul class="facts" aria-label="Key results">
  <li><span class="num">{{ pct(v.readm_hf_not_sep) }}</span><span class="what">of {{ n(v.readm_hf_point_ordered) }} same-state orderings on heart-failure readmission were not separated by the published intervals</span></li>
  <li><span class="num">{{ pct(v.mort_hf_not_sep) }}</span><span class="what">for heart-failure mortality ({{ n(v.mort_hf_point_ordered) }} orderings), against {{ pct(v.edac_hf_not_sep) }} for heart-failure excess days</span></li>
  <li><span class="num">{{ n(v.cur_readm_hf_with_interval) }} of {{ n(v.cur_readm_hf_numeric) }}</span><span class="what">hospitals with a heart-failure readmission rate in the current CMS files have a usable interval</span></li>
  <li><span class="num">{{ pct(v.readm_hf_compatible_share) }}</span><span class="what">of {{ n(v.readm_hf_requested) }} requested heart-failure readmission records passed every gate in the primary release</span></li>
</ul>

<section class="prose" aria-labelledby="data">
<h2 id="data">The data: three releases of the same measures</h2>
<p>All data are public files from the CMS Provider Data Catalog: the hospital-level Unplanned Hospital Visits and Complications and Deaths files, Hospital General Information, the Footnote Crosswalk, Measure Dates, the Hospital Readmissions Reduction Program file and the national and state reference files. Each release is loaded with its own hospital list and dictionaries, and every file is pinned by SHA-256.</p>
<div class="table-wrap" tabindex="0">
<table>
<caption class="small" style="caption-side: bottom; text-align: left; padding: 0.5rem 0.65rem;">Heart-failure readmission window and interval status by release.</caption>
<thead><tr><th scope="col">Release</th><th scope="col">Readmission window</th><th scope="col">Intervals</th><th scope="col">Role</th></tr></thead>
<tbody>
<tr><td>2026-05-13 (archive)</td><td>{{ v['win_readm_hf_2026-05-13'] }}, {{ v['winmonths_readm_hf_2026-05-13'] }} months</td><td>Published</td><td>Primary analysis</td></tr>
<tr><td>2026-08-13 (archive)</td><td>{{ v['win_readm_hf_2026-08-13'] }}, {{ v['winmonths_readm_hf_2026-08-13'] }} months</td><td>Published, then flagged by CMS</td><td>Gate check only</td></tr>
<tr><td>2026-09-30 (current)</td><td>{{ v['win_readm_hf_2026-09-30'] }}, {{ v['winmonths_readm_hf_2026-09-30'] }} months</td><td>Suppressed</td><td>Gate check only</td></tr>
</tbody>
</table>
</div>
<p>Primary measures are the heart-failure 30-day readmission and mortality rates. Heart-failure excess days in acute care is a supporting measure with a different unit (days per 100 discharges), and the acute myocardial infarction measures are a separate secondary analysis. No score is ever averaged across measures.</p>
</section>

<section class="prose" aria-labelledby="method">
<h2 id="method">How the check works</h2>
<p>Every hospital-measure-release record goes through eight gates in a fixed order: release status, identity, measure definition, population, observation window, numeric score, usable interval and footnotes. The tool records the first gate each record fails and keeps the source string next to every parsed value, so a suppressed score, too few cases and a hospital outside the reporting program stay distinct.</p>
<p>For records that pass, every pair of hospitals in the same state and measure is checked for separation: one hospital's upper limit must sit below the other's lower limit. Each hospital also gets an interval-compatible rank range, the ranks it could hold if every true value lay inside its published interval. The range uses the counting rule of Klein, Wright and Wieczorek (2020). Because CMS publishes marginal 95% intervals and no covariance, the range carries no probability and is not a simultaneous confidence set.</p>
</section>

<section class="prose" aria-labelledby="decisions">
<h2 id="decisions">Why the release and comparison rules matter</h2>
<h3>The newest files could not be used for uncertainty</h3>
<p>In the current files, released 2026-09-30, CMS shows "Not Available" for the intervals and national categories of 18 outcome measures, following a notice that issues had affected the published values. The previous release still carries the intervals the notice describes. I therefore used the April 2026 refresh, the latest release with intervals not covered by a notice, and ran the two newer releases through the same gates to show what the check does with them: every record fails at the release gate, even though most hospitals still have a rate.</p>
<h3>VA hospitals were moved to their own comparison after the plan was locked</h3>
<p>The first version of the population gate excluded no hospital type. While checking a VA medical center that appeared in an example, I found CMS methodology text stating that Medicare enrollment criteria do not apply to VA hospitalizations and that VA data are a separate source. I recorded a dated amendment and applied the gate as written, so VA hospitals are compared only with other VA hospitals. The headline shares barely moved: {% if pct(v.run1_readm_hf_not_sep) == pct(v.readm_hf_not_sep) %}readmission stayed at {{ pct(v.readm_hf_not_sep) }}{% else %}readmission went from {{ pct(v.run1_readm_hf_not_sep) }} to {{ pct(v.readm_hf_not_sep) }}{% endif %} and mortality went from {{ pct(v.run1_mort_hf_not_sep) }} to {{ pct(v.mort_hf_not_sep) }}. The share of hospitals separated from no peer on mortality moved more, from {{ pct(v.run1_mort_hf_hosp_share_separated_from_none) }} to {{ pct(v.mort_hf_hosp_share_separated_from_none) }}. Both runs are kept.</p>
</section>

<section aria-labelledby="results">
<h2 id="results">Results</h2>
<div class="prose">
<p>In the primary release, {{ n(v.readm_hf_compatible) }} of {{ n(v.readm_hf_requested) }} requested heart-failure readmission records passed every gate. Too few cases removed {{ n(v.readm_hf_reason_too_few_cases) }}, and {{ n(v.readm_hf_reason_partial_or_short_period_footnote) }} records with valid-looking numbers failed because CMS marked them as covering only part of the performance period.</p>
</div>
<figure>
  <img src="assets/figures/fig1_gate_flow.svg" width="960" height="366" alt="Bar charts of heart-failure readmission records remaining after each gate. Primary release: {{ n(v.readm_hf_requested) }} requested, {{ n(v.readm_hf_compatible) }} compatible. Flagged and current releases: zero records pass the release gate.">
  <figcaption>Records remaining after each gate in the three releases.</figcaption>
</figure>
<div class="prose">
<p>Among compatible hospitals in the same state, the intervals separated about one heart-failure readmission ordering in {{ ratio(v.readm_hf_point_ordered, v.readm_hf_sep_r1) }}, and {{ pct(v.readm_hf_hosp_share_separated_from_none) }} of hospitals were separated from none of their peers. For mortality the intervals separated about one ordering in {{ ratio(v.mort_hf_point_ordered, v.mort_hf_sep_r1) }}, and {{ pct(v.mort_hf_hosp_share_separated_from_none) }} of hospitals were separated from none. Excess days separated hospitals far more often, which matches earlier work comparing that measure with readmission. Weighting each state equally instead of each pair gave the same picture.</p>
</div>
<figure>
  <img src="assets/figures/fig4_separation.svg" width="960" height="430" alt="Dot chart of the share of point-ordered same-state pairs not separated, by measure and rule. Readmission and mortality measures sit close to 100 percent; the excess days measures sit near two thirds.">
  <figcaption>Share of point orderings not separated, by measure, under the primary rule (R1), a rounding-robust rule (R2) and a lenient rule (R3), with the median and interquartile range across states.</figcaption>
</figure>
<div class="prose">
<p>In all {{ v.readm_hf_rank_universes_n_ge_10 }} states with at least 10 compatible hospitals, the hospital ranked first on heart-failure readmission could rank in the bottom half of its state. In {{ state_name }}, two hospitals' mortality intervals sit {{ f1(v.ex_pass.gap) }} percentage points apart, one of {{ v.ex_pass.separated_in_state }} separated mortality pairs out of {{ n(v.ex_pass.point_ordered_in_state) }}.</p>
<p>Between releases, the readmission Measure ID kept its name but moved from a {{ v['winmonths_readm_hf_2026-05-13'] }}-month to a {{ v['winmonths_readm_hf_2026-09-30'] }}-month window and, under the FY 2026 final rule, added Medicare Advantage beneficiaries. The mortality and excess-days measures kept their identifiers too, but from the Summer 2026 refresh every study measure includes patients admitted with COVID-19 and uses updated risk adjustment. A comparison across those releases would mix definitions under one identifier.</p>
</div>
<figure>
  <img src="assets/figures/fig6_windows.svg" width="960" height="456" alt="Timeline of observation windows for heart-failure measures in three releases; the readmission window shortens from 36 to 24 months.">
  <figcaption>Observation windows of the same Measure IDs across the three releases.</figcaption>
</figure>
</section>

{% if viewer %}
<section aria-labelledby="explore">
<h2 id="explore">Explore the frozen snapshot</h2>
<p class="prose">Pick a release, measure and state to see each hospital's published score and interval, its interval-compatible rank range, and every record that was not compared with the reason. The controls only filter precomputed rows from run {{ run_id }}; nothing is recalculated in the browser, and nothing here recommends a hospital.</p>
{{ viewer }}
</section>
{% endif %}

<section class="prose" aria-labelledby="limits">
<h2 id="limits">Limits</h2>
<ul>
<li>The primary release is not the newest; it is the newest whose intervals are not covered by a CMS notice, and its window ends in June 2024.</li>
<li>Separation is judged from marginal 95% intervals published to one decimal, without covariance. Overlap does not show that two hospitals perform the same, and non-overlap is not a formal test.</li>
<li>A statistical white paper commissioned for CMS cautions that indirectly standardized rates should not generally be compared directly between hospitals. The study describes what the published intervals show for orderings people commonly make.</li>
<li>The VA exclusion rests on documentation found after the plan was locked; both runs are reported.</li>
<li>CMS national category counts exceed the counts in the hospital file by {{ [v.recon_gap_readm_hf, v.recon_gap_mort_hf, v.recon_gap_edac_hf, v.recon_gap_readm_ami, v.recon_gap_mort_ami, v.recon_gap_edac_ami]|min }} to {{ [v.recon_gap_readm_hf, v.recon_gap_mort_hf, v.recon_gap_edac_hf, v.recon_gap_readm_ami, v.recon_gap_mort_ami, v.recon_gap_edac_ami]|max }} hospitals per measure, and the public files do not identify the difference, so that reconciliation is incomplete.</li>
<li>The CMS notice does not describe the issues it reports, so it cannot be ruled out that earlier releases were affected.</li>
<li>The results describe heart-failure and heart-attack outcome measures in the public files and say nothing about other aspects of hospital quality.</li>
</ul>
</section>

<section class="prose" aria-labelledby="reproduce">
<h2 id="reproduce">Reproduce the analysis</h2>
<p>The source archive contains the code, SQL, configuration, the locked plan, tests and a synthetic demonstration. With Python 3.12 or later:</p>
<pre><code>python3 -m venv .venv
.venv/bin/pip install -r requirements.lock -e .
.venv/bin/python -m pytest -q
.venv/bin/hospcomp demo
.venv/bin/hospcomp all</code></pre>
<p>The demo runs on a small synthetic fixture and only shows that the software works. <code>hospcomp all</code> downloads the CMS files, stops if any file differs from the checksums pinned for the study, and rebuilds every table. The R cross-check needs R and is skipped without it; everything else needs only Python.</p>
</section>

<section class="prose" aria-labelledby="files">
<h2 id="files">Report and files</h2>
<ul class="files">
{% for f in files %}<li><a href="{{ f.href }}">{{ f.label }}</a><span class="meta">{{ f.meta }}</span></li>
{% endfor %}</ul>
</section>
</main>
<footer class="page-footer">
<p>Data: CMS Provider Data Catalog, U.S. federal public data, retrieved 2026-10-07. Code: MIT license. Run {{ run_id }}. This page describes a public measure population and does not rate or recommend hospitals.</p>
</footer>
{% if viewer %}<script src="assets/viewer.js" defer></script>{% endif %}
</body>
</html>
"""


def svg_size(path: Path) -> tuple[int, int]:
    """Width and height in CSS pixels from an SVG's width and height attributes (points)."""
    head = path.read_text(encoding="utf-8")[:2000]
    w = re.search(r'width="([\d.]+)pt"', head)
    h = re.search(r'height="([\d.]+)pt"', head)
    if not (w and h):
        return 960, 600
    scale = 96 / 72
    return round(float(w.group(1)) * scale), round(float(h.group(1)) * scale)


def human_size(num: int) -> str:
    for unit in ("bytes", "KB", "MB"):
        if num < 1024 or unit == "MB":
            return f"{num:,} bytes" if unit == "bytes" else f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} MB"


DOWNLOAD_LABELS = [
    ("hospital-comparability-source.zip", "Source archive (code, SQL, configuration, plan, tests, demo)"),
    ("hospital-comparability-review.xlsx", "Review workbook (original fields, gate decisions, source evidence)"),
    ("hospital-comparability-tables.zip", "Output tables (CSV) and evidence map"),
    ("analysis_plan.md", "Analysis plan with lock history and amendments"),
    ("source_manifest.json", "Source manifest (URLs, release dates, SHA-256)"),
    ("strobe_record_checklist.md", "STROBE checklist with applicable RECORD items"),
    ("hospital-comparability-supplement.docx", "Supplementary tables S1 to S12 (Word)"),
]


def build() -> dict:
    v = values()
    run = read_json(OUTPUTS / "run_manifest.json")
    for d in (ASSETS / "figures", DOWNLOADS):
        d.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "site_src" / "style.css", ASSETS / "style.css")
    for f in (OUTPUTS / "figures").glob("*.svg"):
        shutil.copy2(f, ASSETS / "figures" / f.name)
    for f in (OUTPUTS / "figures").glob("*.png"):
        shutil.copy2(f, ASSETS / "figures" / f.name)
    for name in ("report.html", "supplement.html"):
        text = (OUTPUTS / "report" / name).read_text(encoding="utf-8").replace("assets/report.css", "assets/style.css")
        # Use first person in the portfolio; keep the journal declaration unchanged.
        text = text.replace("Animesh Bose is the owner of Norlowe Research, the organization listed as the author's affiliation. The author declares that they have no other competing interests.", 'I own Norlowe Research and have no other competing interests.')
        text = text.replace('I carried out the work using internal resources from Norlowe Research, which I own. No external funding was received.', 'I carried out the work using internal resources from Norlowe Research, which I own.')
        (SITE / name).write_text(text, encoding="utf-8")
    viewer_html = ""
    vdir = ROOT / "site_src" / "viewer"
    if (vdir / "viewer.js").exists() and (vdir / "viewer_snippet.html").exists():
        from . import viewer

        viewer.export(ASSETS / "data")
        shutil.copy2(vdir / "viewer.js", ASSETS / "viewer.js")
        shutil.copy2(vdir / "viewer.css", ASSETS / "viewer.css")
        viewer_html = (vdir / "viewer_snippet.html").read_text(encoding="utf-8")
    files = [{"href": "report.html", "label": "Full report and references", "meta": "HTML"},
             {"href": "supplement.html", "label": "Supplementary tables S1 to S12", "meta": "HTML"}]
    for fname, label in DOWNLOAD_LABELS:
        p = DOWNLOADS / fname
        if p.exists():
            files.append({"href": f"downloads/{fname}", "label": label, "meta": human_size(p.stat().st_size)})
    env = jinja2.Environment(undefined=jinja2.StrictUndefined, autoescape=False)
    page = PAGE
    for svg in sorted((ASSETS / "figures").glob("*.svg")):
        w, h = svg_size(svg)
        page = re.sub(rf'(src="assets/figures/{re.escape(svg.name)}") width="\d+" height="\d+"',
                      rf'\1 width="{w}" height="{h}"', page)
    html_text = env.from_string(page).render(
        v=_Dot(v), n=n, pct=pct, f1=f1, ratio=ratio, run_id=run["run_id"],
        state_name=STATE_NAMES.get(v["ex_state"], v["ex_state"]), viewer=viewer_html, files=files)
    (SITE / "index.html").write_text(html_text, encoding="utf-8")
    return {"site": str(SITE.relative_to(ROOT)), "viewer": bool(viewer_html), "files": [f["href"] for f in files]}


class _Dot(dict):
    def __getattr__(self, k):
        val = self[k]
        return _Dot(val) if isinstance(val, dict) else val


if __name__ == "__main__":
    print(json.dumps(build(), indent=1))
