"""Shared paths, hashing and small I/O helpers."""

from __future__ import annotations

import hashlib
import json
import os
import tomllib
from datetime import datetime, timezone
from pathlib import Path


def project_root() -> Path:
    env = os.environ.get("HOSPCOMP_ROOT")
    if env:
        return Path(env).resolve()
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "config" / "study.toml").exists():
            return parent
    return Path.cwd().resolve()


ROOT = project_root()
RAW = ROOT / "data" / "raw"
INTERIM = ROOT / "data" / "interim"
OUTPUTS = ROOT / "outputs"
TABLES = OUTPUTS / "tables"
FIGURES = OUTPUTS / "figures"
LOGS = OUTPUTS / "logs"
DB_PATH = INTERIM / "hospcomp.sqlite"
SQL_DIR = ROOT / "sql"


def load_config() -> dict:
    with open(ROOT / "config" / "study.toml", "rb") as fh:
        return tomllib.load(fh)


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write_json(path: Path, obj, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=indent, sort_keys=False, ensure_ascii=False)
        fh.write("\n")
    tmp.replace(path)


def read_json(path: Path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def rel(path: Path) -> str:
    """Project-relative POSIX path, so manifests carry no machine-specific prefix."""
    try:
        return Path(path).resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return Path(path).as_posix()
