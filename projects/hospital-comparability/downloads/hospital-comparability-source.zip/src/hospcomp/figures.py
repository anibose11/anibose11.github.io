"""Figures for the report, manuscript and project page (PNG and SVG).

Every figure is drawn from the frozen output tables; nothing is recomputed here.
Palette: validated three-slot categorical set on a light surface; hairline grid.
Figure titles live in the manuscript legends, not inside the graphics; panel
labels inside multi-panel figures are kept.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import date

import matplotlib

matplotlib.use("Agg")
import matplotlib.dates as mdates  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import Patch  # noqa: E402

from .common import DB_PATH, FIGURES, TABLES, read_json  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
S1, S2, S3 = "#2a78d6", "#eb6834", "#1baf7a"
FADE = "#b9b7ae"

MEASURE_LABEL = {
    "READM_30_HF": "HF readmission",
    "MORT_30_HF": "HF mortality",
    "EDAC_30_HF": "HF excess days",
    "READM_30_AMI": "AMI readmission",
    "MORT_30_AMI": "AMI mortality",
    "EDAC_30_AMI": "AMI excess days",
    "READM-30-HF-HRRP": "HF HRRP ratio",
}

plt.rcParams.update({
    "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 9,
    "axes.edgecolor": AXIS,
    "axes.linewidth": 0.8,
    "axes.labelcolor": INK2,
    "axes.titlecolor": INK,
    "axes.titlesize": 10,
    "axes.titleweight": "bold",
    "axes.titlelocation": "left",
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "xtick.labelcolor": INK2,
    "ytick.labelcolor": INK2,
    "axes.grid": False,
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "svg.fonttype": "none",
})


def f1(v: float) -> str:
    return f"{v:.1f}"


def pct(share: float) -> str:
    """Percent with one decimal, never rounding a share below 1 up to 100.0%."""
    v = share * 100
    if v < 100 and round(v, 1) >= 100:
        return f"{v:.2f}%"
    return f"{v:.1f}%"


def _style(ax, grid_axis: str = "x") -> None:
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.grid(True, axis=grid_axis, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)


def _save(fig, name: str) -> list[str]:
    FIGURES.mkdir(parents=True, exist_ok=True)
    out = []
    for ext in ("png", "svg"):
        path = FIGURES / f"{name}.{ext}"
        fig.savefig(path, dpi=300 if ext == "png" else None, bbox_inches="tight",
                    metadata={"Date": None} if ext == "svg" else {"Software": None})
        out.append(path.name)
    plt.close(fig)
    return out


def _national_rate(primary: str, measure: str) -> float | None:
    con = sqlite3.connect(DB_PATH)
    row = con.execute("SELECT national_rate FROM national_reference WHERE release_key=? AND geography='NATION' "
                      "AND measure_id=?", (primary, measure)).fetchone()
    con.close()
    try:
        return float(row[0]) if row else None
    except (TypeError, ValueError):
        return None


def fig_gate_flow(primary: str) -> list[str]:
    gf = pd.read_csv(TABLES / "gate_flow_national.csv", dtype={"release_key": str})
    rel = pd.read_csv(TABLES / "releases.csv", dtype={"release_key": str})
    steps = [("requested_records", "Requested records"), ("pass_through_g0_release", "G0 release intervals usable"),
             ("pass_through_g2b_population", "G1 to G2b identity, definition, population"),
             ("pass_through_g3_window", "G3 observation window"), ("pass_through_g4_score", "G4 numeric score"),
             ("pass_through_g5_interval", "G5 usable interval"), ("compatible", "G6 footnotes: compatible")]
    keys = list(rel.sort_values("release_key")["release_key"])
    fig, axes = plt.subplots(1, len(keys), figsize=(7.6, 2.9), sharey=True)
    for ax, rk in zip(axes, keys):
        row = gf[(gf["release_key"] == rk) & (gf["measure_id"] == "READM_30_HF")].iloc[0]
        vals = [int(row[c]) for c, _ in steps]
        y = list(range(len(steps)))[::-1]
        ax.barh(y, vals, height=0.55, color=S1 if rk == primary else FADE)
        n = vals[0]
        for yi, v in zip(y, vals):
            ax.text(v + n * 0.02, yi, f"{v:,}", va="center", ha="left", fontsize=8, color=INK)
        _style(ax)
        ax.set_xlim(0, n * 1.32)
        ax.set_xticks([0, 2500, 5000])
        ax.set_xticklabels(["0", "2,500", "5,000"])
        r = rel[rel["release_key"] == rk].iloc[0]
        status = {"published": "intervals published", "flagged_by_cms_notice": "intervals flagged by CMS",
                  "suppressed_by_cms_notice": "intervals suppressed"}[r["interval_status"]]
        ax.set_title(f"{rk}\n{status}", fontsize=9)
        if rk != primary:
            num = int(row["independent_pass_g4_score"])
            ax.text(n * 0.18, 3, f"{num:,} hospitals have a\nnumeric score, but no\nrecord passes G0", fontsize=7.5,
                    color=INK2, va="center")
    axes[0].set_yticks(list(range(len(steps)))[::-1])
    axes[0].set_yticklabels([s for _, s in steps])
    fig.tight_layout()
    return _save(fig, "fig1_gate_flow")


def _interval_panel(ax, hosp: pd.DataFrame, highlight: dict, natrate: float | None, xlabel: str) -> pd.DataFrame:
    hosp = hosp.sort_values(["score_num", "facility_id"], ascending=[False, False]).reset_index(drop=True)
    for i, r in hosp.iterrows():
        c = highlight.get(r["facility_id"], FADE)
        lw = 2 if r["facility_id"] in highlight else 1.2
        ax.plot([r["lower_num"], r["upper_num"]], [i, i], color=c, linewidth=lw, solid_capstyle="round", zorder=2)
        ax.scatter([r["score_num"]], [i], s=22 if r["facility_id"] in highlight else 12, color=c, zorder=3,
                   edgecolors=SURFACE, linewidths=1)
    if natrate is not None:
        ax.axvline(natrate, color=INK2, linewidth=0.9, zorder=1)
        ax.text(natrate + 0.15, -1.6, f"national observed rate {natrate:g}%", fontsize=7.5, color=INK2, ha="left",
                va="center")
    ax.set_ylim(-2.4, len(hosp) + 0.8)
    ax.set_yticks([])
    ax.set_xlabel(xlabel)
    _style(ax)
    return hosp


def fig_lead_example(primary: str) -> list[str]:
    ex = read_json(TABLES / "examples.json")
    natrate = _national_rate(primary, ex["measure_id"])
    hosp = pd.DataFrame(ex["hospitals"])
    top = ex["top_hospital"]["facility_id"]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.6, 6.0), sharey=True, gridspec_kw={"width_ratios": [1.15, 1]})
    hs = _interval_panel(a1, hosp, {top: S2}, natrate, "Readmission rate (%) and published 95% interval")
    n = len(hs)
    for i, r in hs.iterrows():
        is_top = r["facility_id"] == top
        a2.plot([r["best_rank"], r["worst_rank"]], [i, i], color=S2 if is_top else FADE, linewidth=2 if is_top else 1.2,
                solid_capstyle="round")
        a2.scatter([r["point_rank"]], [i], s=22 if is_top else 12, color=INK if is_top else INK2, zorder=3,
                   edgecolors=SURFACE, linewidths=1)
    a2.set_xlim(0, n + 1)
    a2.set_xticks([1, n // 2, n])
    a2.set_xlabel("Rank (1 = lowest): point rank and compatible range")
    _style(a2)
    ti = hs.index[hs["facility_id"] == top][0]
    th = ex["top_hospital"]
    a1.annotate(f"point-estimate rank 1\n{f1(th['score_num'])}% [{f1(th['lower_num'])}, {f1(th['upper_num'])}]",
                xy=(th["upper_num"], ti), xytext=(th["upper_num"] + 1.6, ti + 3), fontsize=7.5, color=INK,
                arrowprops=dict(arrowstyle="-", color=INK2, linewidth=0.7))
    a2.annotate(f"compatible ranks {th['best_rank']} to {th['worst_rank']} of {n}", xy=(n, ti),
                xytext=(n * 0.38, ti + 3), fontsize=7.5, color=INK,
                arrowprops=dict(arrowstyle="-", color=INK2, linewidth=0.7))
    fig.tight_layout()
    return _save(fig, "fig2_lead_example")


def fig_passing_example(primary: str) -> list[str]:
    ex = read_json(TABLES / "examples.json")
    pp = ex["passing_pair"]
    rr = pd.read_csv(TABLES / "rank_ranges.csv", dtype={"release_key": str, "facility_id": str})
    hosp = rr[(rr["subset"] == "primary") & (rr["release_key"] == primary) & (rr["measure_id"] == pp["measure_id"])
              & (rr["state"] == ex["state"])]
    natrate = _national_rate(primary, pp["measure_id"])
    fig, ax = plt.subplots(figsize=(7.6, 5.4))
    hs = _interval_panel(ax, hosp, {pp["facility_a"]: S2, pp["facility_b"]: S1}, natrate,
                         "Risk-standardized mortality rate (%) with published 95% interval")
    for fid in (pp["facility_a"], pp["facility_b"]):
        r = hs[hs["facility_id"] == fid].iloc[0]
        i = hs.index[hs["facility_id"] == fid][0]
        ax.text(r["upper_num"] + 0.3, i, f"{fid}  {f1(r['score_num'])}% [{f1(r['lower_num'])}, {f1(r['upper_num'])}]",
                fontsize=7.5, color=INK, va="center", zorder=6,
                bbox=dict(facecolor=SURFACE, edgecolor="none", pad=1.5))
    fig.tight_layout()
    return _save(fig, "fig3_passing_example")


def fig_separation(primary: str) -> list[str]:
    ps = pd.read_csv(TABLES / "pair_summary_national.csv", dtype={"release_key": str})
    ps = ps[(ps["subset"] == "primary") & (ps["release_key"] == primary)]
    sw = pd.read_csv(TABLES / "state_weighted_summary.csv", dtype={"release_key": str})
    sw = sw[(sw["subset"] == "primary") & (sw["release_key"] == primary)].set_index("measure_id")
    order = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI"]
    ps = ps.set_index("measure_id").loc[order]
    fig, ax = plt.subplots(figsize=(7.6, 3.4))
    y = list(range(len(order)))[::-1]
    for yi, mid in zip(y, order):
        r = ps.loc[mid]
        vals = {"R3": 1 - r["sep_r3_share"], "R1": r["not_separated_r1_share"], "R2": 1 - r["sep_r2_share"]}
        ax.plot([min(vals.values()) * 100, max(vals.values()) * 100], [yi, yi], color=GRID, linewidth=2, zorder=1)
        q1, q3 = sw.loc[mid, "q1"] * 100, sw.loc[mid, "q3"] * 100
        ax.plot([q1, q3], [yi - 0.28, yi - 0.28], color=INK2, linewidth=1.2)
        ax.scatter([sw.loc[mid, "median_state_not_separated_share"] * 100], [yi - 0.28], marker="|", s=60, color=INK2)
        ax.scatter([vals["R3"] * 100], [yi], s=30, color=S3, zorder=3, edgecolors=SURFACE, linewidths=1.5)
        ax.scatter([vals["R1"] * 100], [yi], s=40, color=S1, zorder=4, edgecolors=SURFACE, linewidths=1.5)
        ax.scatter([vals["R2"] * 100], [yi], s=120, facecolors="none", edgecolors=S2, linewidths=1.6, zorder=5)
        ax.text(101, yi, f"{pct(r['not_separated_r1_share'])} of {int(r['point_ordered_pairs']):,}",
                va="center", fontsize=7.5, color=INK)
    ax.set_yticks(y)
    ax.set_yticklabels([MEASURE_LABEL[m] for m in order])
    ax.set_xlim(0, 100)
    ax.set_xlabel("Point-ordered same-state pairs not separated by published intervals (%)")
    _style(ax)
    handles = [Line2D([], [], marker="o", linestyle="", color=S1, markersize=6, label="R1 strict non-overlap (primary)"),
               Line2D([], [], marker="o", linestyle="", markerfacecolor="none", markeredgecolor=S2, markeredgewidth=1.6,
                      markersize=9, label="R2 rounding-robust (ring)"),
               Line2D([], [], marker="o", linestyle="", color=S3, markersize=6, label="R3 point outside other interval"),
               Line2D([], [], color=INK2, linewidth=1.2, label="state median and interquartile range (R1)")]
    ax.legend(handles=handles, loc="lower left", fontsize=7.5, frameon=False, ncol=2, bbox_to_anchor=(0, -0.42))
    fig.tight_layout()
    return _save(fig, "fig4_separation")


def fig_rank_width(primary: str) -> list[str]:
    rr = pd.read_csv(TABLES / "rank_ranges.csv", dtype={"release_key": str})
    rr = rr[(rr["subset"] == "primary") & (rr["release_key"] == primary) & (rr["n"] >= 2)]
    order = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI"]
    fig, axes = plt.subplots(2, 3, figsize=(7.6, 4.0), sharex=True, sharey=True)
    bins = [i / 20 for i in range(21)]
    for ax, mid in zip(axes.ravel(), order):
        s = rr[rr["measure_id"] == mid]["width_share_of_n"]
        ax.hist(s, bins=bins, weights=[100 / len(s)] * len(s), color=S1, rwidth=0.85)
        _style(ax, "y")
        ax.set_title(f"{MEASURE_LABEL[mid]} (median {s.median() * 100:.0f}%)", fontsize=8.5)
    for ax in axes[1]:
        ax.set_xlabel("Rank-range width / hospitals in state")
        ax.set_xticks([0, 0.5, 1])
        ax.set_xticklabels(["0", "50%", "100%"])
    for ax in axes[:, 0]:
        ax.set_ylabel("% of hospitals")
    fig.tight_layout()
    return _save(fig, "fig5_rank_width")


def fig_windows() -> list[str]:
    cw = pd.read_csv(TABLES / "cross_release_windows.csv", dtype={"release_key": str})
    rel = pd.read_csv(TABLES / "releases.csv", dtype={"release_key": str})
    measures = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM-30-HF-HRRP"]
    keys = list(rel.sort_values("release_key")["release_key"])
    colors = {"published": S1, "flagged_by_cms_notice": S2, "suppressed_by_cms_notice": FADE}
    fig, ax = plt.subplots(figsize=(7.6, 3.6))
    yt, yl = [], []
    y = 0
    for mid in measures[::-1]:
        for rk in keys[::-1]:
            r = cw[(cw["measure_id"] == mid) & (cw["release_key"] == rk)].iloc[0]
            s, e = date.fromisoformat(r["window_start"]), date.fromisoformat(r["window_end"])
            st = rel[rel["release_key"] == rk].iloc[0]["interval_status"]
            ax.barh(y, mdates.date2num(e) - mdates.date2num(s), left=mdates.date2num(s), height=0.62,
                    color=S3 if mid.endswith("HRRP") else colors[st])
            ax.text(mdates.date2num(e) + 12, y, f"{r['window_months']} mo", va="center", fontsize=7, color=INK2)
            yt.append(y)
            yl.append(f"{MEASURE_LABEL[mid]} · {rk}")
            y += 1
        y += 0.6
    ax.set_yticks(yt)
    ax.set_yticklabels(yl, fontsize=7.5)
    ax.xaxis_date()
    ax.xaxis.set_major_locator(mdates.YearLocator())
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    _style(ax)
    ax.legend(handles=[Patch(color=S1, label="intervals published"), Patch(color=S2, label="published, then flagged by CMS"),
                       Patch(color=FADE, label="intervals suppressed"),
                       Patch(color=S3, label="HRRP payment file (ratio; not covered by the notice)")],
              loc="lower left", fontsize=7.5, frameon=False, ncol=2, bbox_to_anchor=(0, -0.38))
    fig.tight_layout()
    return _save(fig, "fig6_windows")


def run() -> dict:
    primary = pd.read_csv(TABLES / "releases.csv", dtype={"release_key": str}).query("role == 'primary'")["release_key"].iloc[0]
    made = []
    for f in (fig_gate_flow, fig_lead_example, fig_passing_example, fig_separation, fig_rank_width):
        made += f(primary)
    made += fig_windows()
    return {"figures": made}


if __name__ == "__main__":
    print(json.dumps(run(), indent=1))
