"""Acquire stage: resolve datasets from the CMS metastore and cache immutable downloads.

Every download URL comes from the live metastore record for the dataset ID in
config/study.toml. Files are streamed to a temporary path, checked (HTTP status,
content type, size, HTML error-page signature, parseable CSV header) and only
then moved into data/raw/. The metastore JSON itself is stored with a hash
because the API is mutable and cannot be replayed later.
"""

from __future__ import annotations

import csv
import io
import json
import time
from pathlib import Path

import requests

from .common import RAW, ROOT, load_config, read_json, rel, sha256_bytes, sha256_file, utc_now, write_json

MANIFEST = ROOT / "source_manifest.json"

HTML_SIGNATURES = (b"<!doctype html", b"<html", b"<?xml", b"{\"error")


class AcquireError(RuntimeError):
    pass


def _get(session: requests.Session, url: str, cfg: dict, stream: bool = False) -> requests.Response:
    last_exc: Exception | None = None
    for attempt in range(1, cfg["max_retries"] + 1):
        try:
            resp = session.get(url, timeout=cfg["timeout_seconds"], stream=stream)
            if resp.status_code == 200:
                return resp
            last_exc = AcquireError(f"HTTP {resp.status_code} for {url}")
            if resp.status_code in (400, 401, 403, 404):
                break
        except requests.RequestException as exc:  # bounded retry on transport errors
            last_exc = exc
        time.sleep(cfg["backoff_seconds"] * attempt)
    raise AcquireError(f"failed to fetch {url}: {last_exc}")


def _check_payload_head(head: bytes, url: str, expect: str) -> None:
    lowered = head.lstrip().lower()
    if expect == "csv" and any(lowered.startswith(sig) for sig in HTML_SIGNATURES):
        raise AcquireError(f"{url} returned an HTML/XML/JSON error page instead of CSV")
    if expect == "pdf" and not head.startswith(b"%PDF"):
        raise AcquireError(f"{url} did not return a PDF")
    if expect == "html" and b"<" not in lowered[:64]:
        raise AcquireError(f"{url} did not return HTML")


def _csv_profile(path: Path) -> dict:
    """Header and row count from a streamed pass (no type inference)."""
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        n = 0
        widths = set()
        for row in reader:
            n += 1
            widths.add(len(row))
    return {"columns": header, "data_rows": n, "row_widths": sorted(widths)}


def resolve(session: requests.Session, ds: dict, meta_url: str, cfg: dict) -> tuple[dict, bytes]:
    url = f"{meta_url}/{ds['id']}?show-reference-ids=false"
    resp = _get(session, url, cfg)
    raw = resp.content
    item = json.loads(raw)
    if item.get("identifier") != ds["id"]:
        raise AcquireError(f"metastore identifier mismatch for {ds['id']}")
    if item.get("title") != ds["expected_title"]:
        raise AcquireError(
            f"dataset {ds['id']} title changed: expected {ds['expected_title']!r}, got {item.get('title')!r}"
        )
    if len(csv_distributions(item)) != 1:
        raise AcquireError(f"expected exactly one CSV distribution for {ds['id']}")
    return item, raw


def csv_distributions(item: dict) -> list[dict]:
    """Distribution records whether or not the metastore nests them under 'data'."""
    out = []
    for d in item.get("distribution") or []:
        d = d.get("data", d) if isinstance(d, dict) else {}
        if str(d.get("downloadURL", "")).lower().endswith(".csv"):
            out.append(d)
    return out


def _file_version(dist: dict) -> str | None:
    for ref in dist.get("%Ref:downloadURL", []) or []:
        version = (ref.get("data") or {}).get("version")
        if version:
            return str(version)
    return None


def download(session: requests.Session, url: str, dest: Path, cfg: dict, expect: str = "csv") -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    resp = _get(session, url, cfg, stream=True)
    ctype = resp.headers.get("Content-Type", "")
    if "text/html" in ctype.lower() and expect != "html":
        raise AcquireError(f"{url} served text/html")
    first = True
    with open(tmp, "wb") as fh:
        for chunk in resp.iter_content(chunk_size=1 << 20):
            if not chunk:
                continue
            if first:
                _check_payload_head(chunk[:64], url, expect)
                first = False
            fh.write(chunk)
    size = tmp.stat().st_size
    if size < cfg["min_csv_bytes"]:
        raise AcquireError(f"{url} too small ({size} bytes)")
    declared = resp.headers.get("Content-Length")
    if declared is not None and resp.headers.get("Content-Encoding") in (None, "", "identity") and int(declared) != size:
        tmp.unlink(missing_ok=True)
        raise AcquireError(f"{url} truncated: {size} bytes received, Content-Length {declared}")
    tmp.replace(dest)
    return {
        "http_status": resp.status_code,
        "content_type": ctype,
        "content_length_header": resp.headers.get("Content-Length"),
        "last_modified_header": resp.headers.get("Last-Modified"),
        "etag_header": resp.headers.get("ETag"),
    }


def _pin_check(label: str, dest: Path, new_sha: str, pinned_sha: str | None, force: bool) -> None:
    """Stop when a freshly downloaded file differs from the checksum pinned in source_manifest.json.

    A changed file means CMS now serves different content; rebuilding from it would not reproduce the
    study. With --force the new file is accepted and the manifest is updated.
    """
    if pinned_sha and new_sha != pinned_sha and not force:
        aside = dest.with_name(dest.name + ".unpinned")
        dest.replace(aside)
        raise AcquireError(
            f"{label}: the file now served by CMS (SHA-256 {new_sha[:12]}) differs from the pinned study file "
            f"(SHA-256 {pinned_sha[:12]}). It was saved as {aside.name} and nothing was overwritten. "
            "Rerun with --force to accept the new file; results will then differ from the study.")


def _live_release_key() -> str | None:
    import tomllib

    with open(ROOT / "config" / "releases.toml", "rb") as fh:
        rels = tomllib.load(fh).get("release", [])
    live = [r["key"] for r in rels if r.get("source") == "live"]
    return live[0] if live else None


def run(force: bool = False) -> dict:
    conf = load_config()
    cfg = conf["acquire"]
    meta_url = conf["project"]["metastore"]
    previous = read_json(MANIFEST) if MANIFEST.exists() else {"datasets": {}}
    session = requests.Session()
    session.headers["User-Agent"] = cfg["user_agent"]

    manifest = {
        "description": "Resolved CMS Provider Data Catalog sources for hospital-comparability",
        "generated_utc": utc_now(),
        "permitted_use": (
            "CMS Provider Data Catalog files are U.S. federal government data published for public use; "
            "the catalogue records accessLevel 'public'. Cite CMS as the source. No license is asserted over them by this project."
        ),
        "rebuild_limits": (
            "The metastore and download endpoints are mutable. Each resolved metastore record is stored with its SHA-256 "
            "under data/raw/metastore/. When a file is downloaded again, its checksum is compared with the checksum pinned "
            "here; a difference stops the acquire stage unless --force is given, and the live outcome files must still "
            "carry the release date of the 'live' release in config/releases.toml. Archive snapshots are fetched first "
            "and must always match their pinned checksums, so a newer live release does not block them. Later stages "
            "verify every file against this manifest before use."
        ),
        "datasets": {},
        "documents": {},
    }

    for ds in conf["datasets"]:
        item, raw_meta = resolve(session, ds, meta_url, cfg)
        meta_path = RAW / "metastore" / f"{ds['id']}.json"
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        meta_path.write_bytes(raw_meta)
        dist = csv_distributions(item)[0]
        url = dist["downloadURL"]
        fname = url.rsplit("/", 1)[-1]
        dest = RAW / ds["key"] / fname
        prev = previous.get("datasets", {}).get(ds["key"])
        live_key = _live_release_key()
        if (ds["role"] in ("outcome", "reference_aggregate") and live_key and item.get("released") != live_key
                and not force):
            raise AcquireError(
                f"{ds['id']} now has release date {item.get('released')}, but the study's live release is {live_key}. "
                "CMS has published a newer file. Rerun with --force to accept it; results will then differ from the study.")
        reused = False
        http = {}
        if (
            not force
            and prev
            and prev.get("download_url") == url
            and dest.exists()
            and sha256_file(dest) == prev.get("sha256")
        ):
            reused = True
            http = prev.get("http", {})
            accessed = prev.get("accessed_utc")
        else:
            http = download(session, url, dest, cfg, expect="csv")
            accessed = utc_now()
            _pin_check(ds["key"], dest, sha256_file(dest), (prev or {}).get("sha256"), force)
        profile = _csv_profile(dest)
        if len(profile["row_widths"]) != 1 or profile["row_widths"][0] != len(profile["columns"]):
            raise AcquireError(f"{dest.name}: ragged CSV rows {profile['row_widths']}")
        manifest["datasets"][ds["key"]] = {
            "id": ds["id"],
            "title": item.get("title"),
            "role": ds["role"],
            "landing_page": item.get("landingPage"),
            "metastore_url": f"{meta_url}/{ds['id']}",
            "metastore_snapshot": rel(meta_path),
            "metastore_snapshot_sha256": sha256_bytes(raw_meta),
            "issued": item.get("issued"),
            "modified": item.get("modified"),
            "released": item.get("released"),
            "metastore_record_modified": item.get("%modified"),
            "download_url": url,
            "distribution_media_type": dist.get("mediaType"),
            "distribution_file_version": _file_version(dist),
            "described_by": dist.get("describedBy"),
            "local_path": rel(dest),
            "bytes": dest.stat().st_size,
            "sha256": sha256_file(dest),
            "accessed_utc": accessed,
            "reused_cached_file": reused,
            "http": http,
            "columns": profile["columns"],
            "data_rows": profile["data_rows"],
        }

    for key, spec in conf.get("documents", {}).items():
        url, expect, fname = spec["url"], spec.get("type", "pdf"), spec["file"]
        dest = RAW / "documents" / fname
        prev = previous.get("documents", {}).get(key)
        if not force and prev and dest.exists() and sha256_file(dest) == prev.get("sha256"):
            http, accessed, reused = prev.get("http", {}), prev.get("accessed_utc"), True
        else:
            http, accessed, reused = download(session, url, dest, cfg, expect=expect), utc_now(), False
        manifest["documents"][key] = {
            "title": spec.get("title", key),
            "url": url,
            "local_path": rel(dest),
            "bytes": dest.stat().st_size,
            "sha256": sha256_file(dest),
            "accessed_utc": accessed,
            "reused_cached_file": reused,
            "http": http,
        }

    if "archives" in previous:
        manifest["archives"] = previous["archives"]
    manifest["documents_browser"] = register_browser_documents(conf)
    write_json(MANIFEST, manifest)
    return manifest


def register_browser_documents(conf: dict) -> dict:
    """Record documents saved from a browser session (sites that need JavaScript)."""
    out = {}
    for key, spec in conf.get("browser_documents", {}).items():
        path = RAW / "documents" / spec["file"]
        entry = {"title": spec["title"], "url": spec["url"], "local_path": rel(path),
                 "retrieval": f"saved from a browser session on {spec.get('saved_date', 'an unrecorded date')}; "
                              "the site requires JavaScript"}
        if spec.get("container"):
            entry["retrieval"] += f"; extracted from {spec['container']} (SHA-256 {spec['container_sha256']})"
        if path.exists():
            with open(path, "rb") as fh:
                head = fh.read(8)
            entry.update({"present": True, "is_pdf": head.startswith(b"%PDF"), "bytes": path.stat().st_size,
                          "sha256": sha256_file(path)})
        else:
            how = (f"download {spec['container']} from {spec['url']} and extract {spec['file']} to {rel(path)}"
                   if spec.get("container") else f"open {spec['url']} in a browser and save it as {rel(path)}")
            entry.update({"present": False, "instruction": how})
        out[key] = entry
    return out


def verify_manifest() -> list[str]:
    """Return a list of problems if cached raw files no longer match the manifest."""
    problems = []
    if not MANIFEST.exists():
        return ["source_manifest.json missing; run `hospcomp acquire`"]
    man = read_json(MANIFEST)
    entries = [(k, e) for k, e in man["datasets"].items()]
    entries += [(f"{ak}/{mk}", m) for ak, a in man.get("archives", {}).items() for mk, m in a["members"].items()]
    for key, entry in entries:
        path = ROOT / entry["local_path"]
        if not path.exists():
            problems.append(f"{key}: missing {entry['local_path']}")
        elif sha256_file(path) != entry["sha256"]:
            problems.append(f"{key}: checksum mismatch for {entry['local_path']}")
    return problems


if __name__ == "__main__":
    out = run()
    print(json.dumps({k: (v["bytes"], v["data_rows"]) for k, v in out["datasets"].items()}, indent=1))


# ---------------------------------------------------------------------------
# Official archive releases
# ---------------------------------------------------------------------------

import re
import zipfile
from pathlib import PurePosixPath

ARCHIVE_DIR = RAW / "archives"


def _safe_member(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and not name.startswith(("/", "\\"))


def acquire_archives(force: bool = False) -> dict:
    conf = load_config()
    cfg = conf["acquire"]
    arc = conf["archive"]
    session = requests.Session()
    session.headers["User-Agent"] = cfg["user_agent"]
    api_url = arc["api"].format(theme=arc["theme"])
    resp = _get(session, api_url, cfg)
    listing_raw = resp.content
    listing = json.loads(listing_raw)["data"]
    snap = RAW / "metastore" / f"archive_listing_{arc['theme']}.json"
    snap.write_bytes(listing_raw)
    previous = read_json(MANIFEST).get("archives", {}) if MANIFEST.exists() else {}
    out = {}
    for rel_spec in conf.get("archive_releases", []):
        matches = [x for x in listing if x.get("type") == "theme" and x.get("date") == rel_spec["date"]]
        if len(matches) != 1:
            raise AcquireError(f"archive listing has {len(matches)} theme entries dated {rel_spec['date']}")
        entry = matches[0]
        url = arc["base"] + entry["url"]
        zpath = ARCHIVE_DIR / rel_spec["key"] / url.rsplit("/", 1)[-1]
        prev = previous.get(rel_spec["key"])
        # Archive snapshots are fixed files: a cached copy that matches the pinned checksum is reused,
        # and a downloaded copy must match it even under --force.
        if prev and prev.get("zip_url") == url and zpath.exists() and sha256_file(zpath) == prev.get("zip_sha256"):
            accessed, http, reused = prev["accessed_utc"], prev.get("http", {}), True
        else:
            zpath.parent.mkdir(parents=True, exist_ok=True)
            tmp = zpath.with_suffix(".part")
            r = _get(session, url, cfg, stream=True)
            ctype = r.headers.get("Content-Type", "")
            first = True
            with open(tmp, "wb") as fh:
                for chunk in r.iter_content(chunk_size=1 << 20):
                    if first:
                        if not chunk.startswith(b"PK\x03\x04"):
                            raise AcquireError(f"{url} is not a ZIP archive")
                        first = False
                    fh.write(chunk)
            tmp.replace(zpath)
            _pin_check(rel_spec["key"], zpath, sha256_file(zpath), (prev or {}).get("zip_sha256"), False)
            accessed, reused = utc_now(), False
            http = {"http_status": r.status_code, "content_type": ctype,
                    "content_length_header": r.headers.get("Content-Length"),
                    "last_modified_header": r.headers.get("Last-Modified")}
        # The listing's size field is recorded, not enforced: a mismatch is a provenance
        # discrepancy to report, while integrity is checked with zipfile.testzip().
        size_matches = str(zpath.stat().st_size) == str(entry.get("size"))
        members_out = {}
        with zipfile.ZipFile(zpath) as zf:
            bad = zf.testzip()
            if bad:
                raise AcquireError(f"{zpath.name}: corrupt member {bad}")
            names = zf.namelist()
            unsafe = [n for n in names if not _safe_member(n)]
            if unsafe:
                raise AcquireError(f"{zpath.name}: unsafe member paths {unsafe[:5]}")
            # Archives use two layouts: bare file names (May 2026) and
            # '<folder>/<dataset id>_<modified>_<file name>' with macOS resource-fork
            # entries under __MACOSX (August 2026). Resource-fork entries are skipped.
            data_names = [n for n in names if "__MACOSX" not in PurePosixPath(n).parts
                          and not PurePosixPath(n).name.startswith("._")]
            for want in rel_spec["members"]:
                pattern = re.compile(r"^(?:[0-9a-z]{4}-[0-9a-z]{4}_\d{4}-\d{2}-\d{2}_)?" + re.escape(want) + "$")
                cands = [n for n in data_names if pattern.match(PurePosixPath(n).name)]
                if len(cands) != 1:
                    raise AcquireError(f"{zpath.name}: expected one member named {want}, found {cands}")
                info = zf.getinfo(cands[0])
                if info.file_size > 500 * 1024 * 1024:
                    raise AcquireError(f"{want}: member too large")
                dest = zpath.parent / "members" / want
                dest.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(dest, "wb") as dst:
                    head = src.read(64)
                    _check_payload_head(head, want, "csv")
                    dst.write(head)
                    while True:
                        block = src.read(1 << 20)
                        if not block:
                            break
                        dst.write(block)
                prof = _csv_profile(dest)
                if prof["row_widths"] != [len(prof["columns"])]:
                    raise AcquireError(f"{want}: rows with {prof['row_widths']} fields against {len(prof['columns'])} columns")
                members_out[want] = {"zip_member": cands[0], "local_path": rel(dest), "bytes": dest.stat().st_size,
                                     "sha256": sha256_file(dest), "columns": prof["columns"], "data_rows": prof["data_rows"],
                                     "member_date_time": "%04d-%02d-%02dT%02d:%02d:%02d" % info.date_time}
        out[rel_spec["key"]] = {
            "release_date": rel_spec["date"], "role": rel_spec["role"], "archive_name": entry.get("name"),
            "archive_listing_url": api_url, "archive_listing_snapshot": rel(snap),
            "archive_listing_snapshot_sha256": sha256_file(snap),
            "zip_url": url, "zip_local_path": rel(zpath), "zip_bytes": zpath.stat().st_size,
            "zip_sha256": sha256_file(zpath), "listing_size": entry.get("size"), "listing_size_matches": size_matches,
            "accessed_utc": accessed,
            "reused_cached_file": reused, "http": http, "zip_member_count": len(names), "members": members_out,
        }
    man = read_json(MANIFEST) if MANIFEST.exists() else {}
    man["archives"] = out
    write_json(MANIFEST, man)
    return out
