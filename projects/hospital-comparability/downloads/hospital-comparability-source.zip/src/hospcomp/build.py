"""Build stage: parse cached raw files for every configured release into the
frozen SQLite study database.

Join-cardinality, uniqueness and row-count reconciliation checks run here and
abort the build on failure. Each release keeps its own hospital list, footnote
crosswalk, Measure Dates table and reference aggregates, so no attribute is
joined across releases.
"""

from __future__ import annotations

import csv
import hashlib
import sqlite3
import tomllib
from collections import Counter, defaultdict
from pathlib import Path

from .acquire import MANIFEST, verify_manifest
from .common import DB_PATH, LOGS, ROOT, SQL_DIR, read_json, write_json
from .parse import (
    STATE_RE,
    availability_state,
    months_inclusive,
    normalize_facility_id,
    parse_date,
    parse_footnotes,
    parse_numeric,
)

OUTCOME_KEYS = ("unplanned_visits", "complications_deaths")
FILE_NAMES = {
    "unplanned_visits": "Unplanned_Hospital_Visits-Hospital.csv",
    "complications_deaths": "Complications_and_Deaths-Hospital.csv",
    "general_info": "Hospital_General_Information.csv",
    "footnotes": "Footnote_Crosswalk.csv",
    "measure_dates": "Measure_Dates.csv",
    "hrrp": "FY_2026_Hospital_Readmissions_Reduction_Program_Hospital.csv",
    "unplanned_national": "Unplanned_Hospital_Visits-National.csv",
    "complications_national": "Complications_and_Deaths-National.csv",
    "unplanned_state": "Unplanned_Hospital_Visits-State.csv",
    "complications_state": "Complications_and_Deaths-State.csv",
}


class BuildError(RuntimeError):
    pass


def load_toml(name: str) -> dict:
    with open(ROOT / "config" / name, "rb") as fh:
        return tomllib.load(fh)


def row_hash(fields: list[str]) -> str:
    return hashlib.sha256("\x1f".join(fields).encode("utf-8")).hexdigest()


def read_csv_rows(path: Path):
    with open(path, "r", encoding="utf-8-sig", newline="") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        for i, row in enumerate(reader, start=1):
            if len(row) != len(header):
                raise ValueError(f"{path.name}: data row {i} has {len(row)} fields, header has {len(header)}")
            yield header, i, row


def footnote_class(code: str, policy: dict) -> tuple[str, str | None]:
    if code in policy["window_blocking"]:
        return "window_blocking", None
    if code in policy["availability_state"]:
        return "availability", policy["availability_state"][code]
    if code in policy["caution"]:
        return "caution", None
    return "informational", None


def release_files(rel: dict, man: dict) -> dict[str, dict]:
    """Logical dataset key -> path, checksum and provenance for one release."""
    out = {}
    if rel["source"] == "live":
        for key in FILE_NAMES:
            e = man["datasets"][key]
            out[key] = {"path": ROOT / e["local_path"], "sha256": e["sha256"], "data_rows": e["data_rows"],
                        "released": e["released"], "file_version": e.get("distribution_file_version"),
                        "url": e["download_url"], "dataset_id": e["id"], "title": e["title"], "modified": e["modified"]}
    else:
        a = man["archives"][rel["archive_key"]]
        for key, fname in FILE_NAMES.items():
            m = a["members"][fname]
            out[key] = {"path": ROOT / m["local_path"], "sha256": m["sha256"], "data_rows": m["data_rows"],
                        "released": a["release_date"], "file_version": m["member_date_time"],
                        "url": a["zip_url"] + "#" + m["zip_member"], "dataset_id": key,
                        "title": f"{a['archive_name']}: {fname}", "modified": m["member_date_time"][:10]}
    return out


def run(db_path: Path = DB_PATH, log_path: Path | None = None) -> dict:
    problems = verify_manifest()
    if problems:
        raise BuildError("; ".join(problems))
    man = read_json(MANIFEST)
    mconf = load_toml("measures.toml")
    rconf = load_toml("releases.toml")
    policy = mconf["footnote_policy"]
    measures = {m["measure_id"]: m for m in mconf["measure"]}

    db_path.parent.mkdir(parents=True, exist_ok=True)
    if db_path.exists():
        db_path.unlink()
    con = sqlite3.connect(db_path)
    con.executescript((SQL_DIR / "01_schema.sql").read_text())
    log: dict = {"checks": [], "releases": {}}

    def check(name: str, ok: bool, detail) -> None:
        log["checks"].append({"check": name, "passed": bool(ok), "detail": detail})
        if not ok:
            raise BuildError(f"{name} failed: {detail}")

    for mid, m in measures.items():
        con.execute("INSERT INTO measure_dictionary VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (mid, m["dataset_key"], m["condition"], m["endpoint"], m["quantity"], m["unit"], m["favorable"],
                     m["lower_bound"], m["upper_bound"], m["study_role"], m["doc_source"]))

    # Gate G2b documentation-based population exclusions (may be empty)
    pe_path = ROOT / "config" / "population_exclusions.csv"
    pe_rows = [row for _, _, row in read_csv_rows(pe_path)] if pe_path.exists() else []
    con.executemany("INSERT INTO population_exclusions VALUES (?,?,?,?)", [tuple(r[:4]) for r in pe_rows if r])

    for ch in rconf.get("definition_change", []):
        for mid in ch["measure_ids"]:
            con.execute("INSERT INTO definition_changes VALUES (?,?,?,?,?,?)",
                        (mid, ch["from_release"], ch["to_release"], ch["change"], ch["source"], ch["source_url"]))

    for rel in rconf["release"]:
        rk = rel["key"]
        files = release_files(rel, man)
        con.execute("INSERT INTO releases VALUES (?,?,?,?,?,?,?,?)",
                    (rk, rel["source"], rel["role"], rel["label"], rel["interval_status"], rel["status_note"],
                     rel["notice"], rel["notice_url"]))
        for key, f in files.items():
            con.execute("INSERT INTO source_files VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (rk, key, f["dataset_id"], f["title"], f["released"], f["modified"], f["file_version"],
                         f["url"], f["sha256"], f["data_rows"]))
        rlog: dict = {}

        known_codes = set()
        for _, _, row in read_csv_rows(files["footnotes"]["path"]):
            code, text = row[0].strip(), row[1].strip()
            cls, state = footnote_class(code, policy)
            con.execute("INSERT INTO footnote_dictionary VALUES (?,?,?,?,?)", (rk, code, text, cls, state))
            known_codes.add(code)

        gen_ids = Counter()
        for header, _, row in read_csv_rows(files["general_info"]["path"]):
            r = dict(zip(header, row))
            fid, _ = normalize_facility_id(r["Facility ID"])
            gen_ids[fid] += 1
            con.execute("INSERT OR REPLACE INTO hospitals VALUES (?,?,?,?,?,?,?,?)",
                        (rk, fid, r["Facility ID"], r["Facility Name"], r["State"], r["Hospital Type"],
                         r["Hospital Ownership"], r["Emergency Services"]))
        dups = [k for k, v in gen_ids.items() if v > 1]
        check(f"{rk}:general_info_facility_unique", not dups, {"duplicates": dups[:10], "rows": sum(gen_ids.values())})
        hosp_type = dict(con.execute("SELECT facility_id, hospital_type FROM hospitals WHERE release_key=?", (rk,)))

        official = {}
        for header, _, row in read_csv_rows(files["measure_dates"]["path"]):
            r = dict(zip(header, row))
            official[r["Measure ID"].strip()] = (r["Measure Name"].strip(), parse_date(r["Start Date"]), parse_date(r["End Date"]))

        names_by_measure: dict[str, set] = defaultdict(set)
        windows_by_measure: dict[str, Counter] = defaultdict(Counter)
        decimals_by_measure: dict[str, Counter] = defaultdict(Counter)
        unknown_codes: Counter = Counter()
        for key in OUTCOME_KEYS:
            f = files[key]
            seen = set()
            batch = []
            for header, i, row in read_csv_rows(f["path"]):
                r = dict(zip(header, row))
                fid, valid = normalize_facility_id(r["Facility ID"])
                mid = r["Measure ID"].strip()
                if (fid, mid) in seen:
                    raise BuildError(f"{rk}: duplicate (facility, measure) {(fid, mid)} in {key}")
                seen.add((fid, mid))
                den = parse_numeric(r.get("Denominator"))
                sc = parse_numeric(r.get("Score"))
                lo = parse_numeric(r.get("Lower Estimate"))
                hi = parse_numeric(r.get("Higher Estimate"))
                codes = parse_footnotes(r.get("Footnote"))
                unknown_codes.update(c for c in codes if c not in known_codes)
                sd, ed = parse_date(r["Start Date"]), parse_date(r["End Date"])
                names_by_measure[mid].add(r["Measure Name"].strip())
                windows_by_measure[mid][(sd, ed)] += 1
                for d in (sc[2], lo[2], hi[2]):
                    if d is not None:
                        decimals_by_measure[mid][d] += 1
                avail = availability_state(sc[1], codes, policy["availability_precedence"], policy["availability_state"])
                state = r["State"].strip()
                batch.append((
                    f"{rk}|{key}|{fid}|{mid}", rk, key, f["released"], f["file_version"], i, row_hash(row),
                    r["Facility ID"], fid, int(valid and bool(STATE_RE.match(state))), r["Facility Name"], state, mid,
                    r["Measure Name"], r["Compared to National"],
                    r.get("Denominator"), den[0], den[1],
                    r.get("Score"), sc[0], sc[1],
                    r.get("Lower Estimate"), lo[0], lo[1],
                    r.get("Higher Estimate"), hi[0], hi[1],
                    sc[2], lo[2], hi[2],
                    r.get("Footnote"), ",".join(codes),
                    r["Start Date"], sd, r["End Date"], ed,
                    avail, hosp_type.get(fid), int(fid in hosp_type),
                ))
            con.executemany(f"INSERT INTO records VALUES ({','.join(['?'] * 39)})", batch)
            con.executemany("INSERT INTO record_footnotes VALUES (?,?)",
                            [(b[0], c) for b in batch for c in b[31].split(",") if c])
            check(f"{rk}:row_count_{key}", len(batch) == f["data_rows"], {"parsed": len(batch), "manifest": f["data_rows"]})
            missing = sorted({fid for fid, _ in seen if fid not in hosp_type})
            check(f"{rk}:facility_in_general_info_{key}", not missing, {"missing": missing[:10]})
            rlog[f"{key}_facilities"] = len({fid for fid, _ in seen})
        check(f"{rk}:footnote_codes_known", not unknown_codes, dict(unknown_codes))

        hrows = []
        for header, i, row in read_csv_rows(files["hrrp"]["path"]):
            r = dict(zip(header, row))
            fid, _ = normalize_facility_id(r["Facility ID"])
            mid = r["Measure Name"].strip()
            vals = [parse_numeric(r[c]) for c in ("Excess Readmission Ratio", "Predicted Readmission Rate",
                                                   "Expected Readmission Rate", "Number of Discharges", "Number of Readmissions")]
            sd, ed = parse_date(r["Start Date"]), parse_date(r["End Date"])
            hrows.append((f"{rk}|hrrp|{fid}|{mid}", rk, i, fid, r["State"], mid,
                          r["Excess Readmission Ratio"], vals[0][0], r["Predicted Readmission Rate"], vals[1][0],
                          r["Expected Readmission Rate"], vals[2][0], r["Number of Discharges"], vals[3][0],
                          r["Number of Readmissions"], vals[4][0], r["Footnote"], sd, ed))
            windows_by_measure[mid][(sd, ed)] += 1
            names_by_measure[mid].add(mid)
            if vals[0][2] is not None:
                decimals_by_measure[mid][vals[0][2]] += 1
        con.executemany(f"INSERT INTO hrrp_records VALUES ({','.join(['?'] * 19)})", hrows)
        check(f"{rk}:row_count_hrrp", len(hrows) == files["hrrp"]["data_rows"],
              {"parsed": len(hrows), "manifest": files["hrrp"]["data_rows"]})

        for key, geo_col in (("unplanned_national", None), ("complications_national", None),
                             ("unplanned_state", "State"), ("complications_state", "State")):
            for header, _, row in read_csv_rows(files[key]["path"]):
                r = dict(zip(header, row))
                con.execute(
                    "INSERT INTO national_reference VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (rk, key, r[geo_col] if geo_col else "NATION", r["Measure ID"].strip(),
                     r.get("Number of Hospitals Worse"), r.get("Number of Hospitals Same"),
                     r.get("Number of Hospitals Better"), r.get("Number of Hospitals Too Few"),
                     r.get("Number of Hospitals Fewer"), r.get("Number of Hospitals Average"),
                     r.get("Number of Hospitals More"), r.get("Number of Hospitals Too Small"),
                     r.get("National Rate"), r.get("Footnote"), parse_date(r.get("Start Date")),
                     parse_date(r.get("End Date"))))

        rlog["windows"] = {}
        for mid, m in measures.items():
            names = names_by_measure.get(mid, set())
            check(f"{rk}:measure_present_{mid}", bool(names), {"measure": mid})
            modal = windows_by_measure[mid].most_common(1)[0][0]
            off = official.get(mid if m["dataset_key"] != "hrrp" else mid.replace("-", "_"))
            decs = max(decimals_by_measure[mid]) if decimals_by_measure[mid] else None
            con.execute("INSERT INTO measure_windows VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                        (rk, mid, sorted(names)[0], len(names), off[0] if off else None,
                         off[1] if off else None, off[2] if off else None, modal[0], modal[1],
                         months_inclusive(modal[0], modal[1]), decs, len(windows_by_measure[mid])))
            rlog["windows"][mid] = {"official": [off[1], off[2]] if off else None, "modal": list(modal),
                                    "variants": len(windows_by_measure[mid]), "reported_decimals": decs}
        log["releases"][rk] = rlog
    con.commit()

    summary = {
        "db": db_path.name,
        "records_by_release": dict(con.execute("SELECT release_key, COUNT(*) FROM records GROUP BY release_key")),
        "hospitals_by_release": dict(con.execute("SELECT release_key, COUNT(*) FROM hospitals GROUP BY release_key")),
        "releases": log["releases"],
    }
    log["summary"] = summary
    write_json(log_path or (LOGS / "build_log.json"), log)
    con.close()
    return summary


if __name__ == "__main__":
    import json

    print(json.dumps(run(), indent=1))
