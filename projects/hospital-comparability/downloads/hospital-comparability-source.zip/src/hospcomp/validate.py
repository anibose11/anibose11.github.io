"""Validate stage.

Four separate kinds of evidence, kept apart in the report:
1. Data checks on the frozen database (units, bounds, interval order, windows,
   suppression strings, footnote consistency).
2. Source reconciliation against CMS's own national and state aggregates.
3. Raw reconstruction of 24 prespecified records from the CSV bytes with an
   independent parser (no csv module, no pandas).
4. Software cross-checks: an R reimplementation of the pair counts and a full
   deterministic rerun compared with the first run.
None of these is external scientific validation of the CMS estimates.
"""

from __future__ import annotations

import json
import shutil
import tomllib
import sqlite3
import subprocess
from decimal import Decimal, InvalidOperation
from pathlib import Path

import numpy as np
import pandas as pd

from .common import DB_PATH, OUTPUTS, ROOT, TABLES, load_config, read_json, utc_now, write_json

VALIDATION = OUTPUTS / "validation"
STUDY = ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI")


def _check(name: str, passed: bool, detail, kind: str) -> dict:
    """A check has a pass condition and can fail."""
    return {"type": "check", "kind": kind, "check": name, "passed": bool(passed), "detail": detail}


def _record(name: str, detail, kind: str) -> dict:
    """A record documents a comparison or count that has no pass condition."""
    return {"type": "record", "kind": kind, "check": name, "passed": None, "detail": detail}


def data_checks(con: sqlite3.Connection) -> list[dict]:
    q = lambda sql, *a: con.execute(sql, a).fetchone()[0]  # noqa: E731
    out = []
    placeholders = ",".join("?" * len(STUDY))
    order_bad = q("SELECT COUNT(*) FROM gate_results WHERE compatible=1 AND NOT (lower_num <= score_num AND "
                  "score_num <= upper_num AND lower_num < upper_num)")
    out.append(_check("compatible records have lower <= score <= upper and lower < upper", order_bad == 0,
                      {"violations": order_bad, "compatible_records": q("SELECT COUNT(*) FROM gate_results WHERE compatible=1")},
                      "data"))
    pct_where = "FROM gate_results g JOIN measure_dictionary m USING (measure_id) WHERE g.compatible=1 AND m.unit LIKE 'percent%'"
    pct_bad = q(f"SELECT COUNT(*) {pct_where} AND (g.lower_num < 0 OR g.upper_num > 100)")
    out.append(_check("compatible rate records lie within 0 to 100 percent", pct_bad == 0,
                      {"violations": pct_bad, "compatible_percent_records": q(f"SELECT COUNT(*) {pct_where}")}, "data"))
    mismatch = q(f"SELECT COUNT(*) FROM records r JOIN measure_windows w ON w.release_key=r.release_key AND "
                 f"w.measure_id=r.measure_id WHERE r.measure_id IN ({placeholders}) AND (r.start_date <> w.official_start "
                 f"OR r.end_date <> w.official_end)", *STUDY)
    out.append(_check("every study record's window equals its release's official Measure Dates window", mismatch == 0,
                      {"records_with_other_windows": mismatch}, "data"))
    numeric_with_avail = q(
        f"SELECT COUNT(*) FROM records r WHERE r.measure_id IN ({placeholders}) AND r.score_state='numeric' AND EXISTS "
        f"(SELECT 1 FROM record_footnotes f JOIN footnote_dictionary d ON d.code=f.code AND d.release_key=r.release_key "
        f"WHERE f.record_id=r.record_id AND d.study_class='availability')", *STUDY)
    out.append(_check("no numeric score carries an availability footnote (1, 4, 5, 7, 12, 13, 19)",
                      numeric_with_avail == 0, {"records": numeric_with_avail}, "data"))
    too_small_numeric = q(f"SELECT COUNT(*) FROM records WHERE measure_id IN ({placeholders}) AND "
                          f"lower(compared_to_national_src) LIKE 'number of cases too small%' AND score_state='numeric'", *STUDY)
    out.append(_check("'Number of Cases Too Small' rows have no numeric score", too_small_numeric == 0,
                      {"records": too_small_numeric}, "data"))
    texts = [r[0] for r in con.execute(
        f"SELECT DISTINCT score_state FROM records WHERE measure_id IN ({placeholders})", STUDY)]
    out.append(_check("score strings are numeric or the documented 'Not Available' text",
                      set(texts) <= {"numeric", "not_available"}, {"states": sorted(texts)}, "data"))
    for rk, status in con.execute("SELECT release_key, interval_status FROM releases"):
        n_num = q(f"SELECT COUNT(*) FROM records WHERE release_key=? AND measure_id IN ({placeholders}) "
                  f"AND score_state='numeric'", rk, *STUDY)
        n_int = q(f"SELECT COUNT(*) FROM records WHERE release_key=? AND measure_id IN ({placeholders}) "
                  f"AND score_state='numeric' AND lower_state='numeric' AND upper_state='numeric'", rk, *STUDY)
        expected_full = status in ("published", "flagged_by_cms_notice")
        ok = (n_int == n_num) if expected_full else (n_int == 0)
        out.append(_check(f"{rk}: interval presence matches documented status '{status}'", ok,
                          {"numeric_scores": n_num, "numeric_scores_with_both_limits": n_int}, "data"))
    fn29 = q(f"SELECT COUNT(*) FROM records r JOIN record_footnotes f ON f.record_id=r.record_id WHERE f.code='29' AND "
             f"r.score_state='numeric' AND r.measure_id IN ({placeholders}) AND r.release_key="
             f"(SELECT release_key FROM releases WHERE role='primary')", *STUDY)
    out.append(_record("partial-period (footnote 29) records with numeric scores in the primary release",
                       {"primary_release_records": fn29}, "data"))
    no_type = q("SELECT COUNT(*) FROM gate_results WHERE compatible=1 AND hospital_type IS NULL")
    out.append(_check("every compatible record joins to a same-release hospital type", no_type == 0, {"missing": no_type}, "data"))
    return out


CATS = {
    "rate": [("better", "n_better", ("better",)), ("no_different", "n_same", ("no different",)),
             ("worse", "n_worse", ("worse",)), ("too_small", "n_too_few", ("number of cases too small",))],
    "edac": [("fewer", "n_fewer", ("fewer days",)), ("average", "n_average", ("average days",)),
             ("more", "n_more", ("more days",)), ("too_small", "n_too_small", ("number of cases too small",))],
}


def reconcile(con: sqlite3.Connection) -> tuple[pd.DataFrame, list[dict]]:
    rec = pd.read_sql(f"SELECT release_key, dataset_key, state, measure_id, compared_to_national_src FROM records "
                      f"WHERE measure_id IN ({','.join('?' * len(STUDY))})", con, params=STUDY)
    ref = pd.read_sql("SELECT * FROM national_reference", con)
    rec["cat_l"] = rec["compared_to_national_src"].str.lower()
    rows = []
    for (rk, mid), grp in rec.groupby(["release_key", "measure_id"]):
        kind = "edac" if mid.startswith("EDAC") else "rate"
        nat_key = "complications_national" if mid.startswith("MORT") else "unplanned_national"
        st_key = nat_key.replace("national", "state")
        for geo, sub, rkey in [("NATION", grp, nat_key)] + [(s, g, st_key) for s, g in grp.groupby("state")]:
            r = ref[(ref["release_key"] == rk) & (ref["dataset_key"] == rkey) & (ref["geography"] == geo)
                    & (ref["measure_id"] == mid)]
            if r.empty:
                continue
            r = r.iloc[0]
            for cat, col, prefixes in CATS[kind]:
                n_rows = int(sub["cat_l"].apply(lambda v: any(v.startswith(p) for p in prefixes)).sum())
                src = r[col]
                try:
                    agg = int(src)
                except (TypeError, ValueError):
                    agg = None
                rows.append({"release_key": rk, "measure_id": mid, "geography": geo, "category": cat,
                             "hospital_rows": n_rows, "cms_aggregate_src": src, "cms_aggregate": agg,
                             "difference": (n_rows - agg) if agg is not None else None})
    df = pd.DataFrame(rows)
    checks = []
    for rk, grp in df.groupby("release_key"):
        published = grp[grp["cms_aggregate"].notna()]
        nat = published[published["geography"] == "NATION"]
        exact = int((nat["difference"] == 0).sum())
        checks.append(_record(
            f"{rk}: hospital-row category counts compared with the CMS national and state files",
            {"national_cells_published": int(len(nat)), "national_cells_equal": exact,
             "national_cells_unpublished": int(((grp["geography"] == "NATION") & grp["cms_aggregate"].isna()).sum()),
             "max_abs_national_difference": int(nat["difference"].abs().max()) if len(nat) else None,
             "state_cells_published": int(((published["geography"] != "NATION")).sum()),
             "state_cells_equal": int(((published["geography"] != "NATION") & (published["difference"] == 0)).sum())},
            "reconciliation"))
    # Windows agree across hospital, state and national files of each release
    w = pd.read_sql("SELECT release_key, measure_id, official_start, official_end FROM measure_windows", con)
    bad = 0
    for _, r in ref[ref["measure_id"].isin(STUDY)].iterrows():
        ww = w[(w["release_key"] == r["release_key"]) & (w["measure_id"] == r["measure_id"])].iloc[0]
        if (r["start_date"], r["end_date"]) != (ww["official_start"], ww["official_end"]):
            bad += 1
    checks.append(_check("national and state file windows equal the hospital file windows in every release", bad == 0,
                         {"mismatching_reference_rows": bad}, "reconciliation"))
    return df, checks


# --- independent raw reader -------------------------------------------------

def split_csv_line(line: str) -> list[str]:
    """Minimal RFC 4180 field splitter for one physical line (no embedded newlines)."""
    fields, buf, inq, i = [], [], False, 0
    while i < len(line):
        ch = line[i]
        if inq:
            if ch == '"':
                if i + 1 < len(line) and line[i + 1] == '"':
                    buf.append('"')
                    i += 1
                else:
                    inq = False
            else:
                buf.append(ch)
        elif ch == '"':
            inq = True
        elif ch == ",":
            fields.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
        i += 1
    fields.append("".join(buf))
    return fields


def reconstruct(con: sqlite3.Connection) -> tuple[pd.DataFrame, list[dict]]:
    primary = con.execute("SELECT release_key FROM releases WHERE role='primary'").fetchone()[0]
    picks = []
    for mid in STUDY:
        comp = [r[0] for r in con.execute(
            "SELECT record_id FROM gate_results WHERE release_key=? AND measure_id=? AND compatible=1 ORDER BY facility_id",
            (primary, mid))]
        if comp:
            picks += [(mid, "compatible_first", comp[0]), (mid, "compatible_middle", comp[(len(comp) - 1) // 2]),
                      (mid, "compatible_last", comp[-1])]
        tf = con.execute("SELECT record_id FROM gate_results WHERE release_key=? AND measure_id=? AND "
                         "reason_code='too_few_cases' ORDER BY facility_id LIMIT 1", (primary, mid)).fetchone()
        if tf:
            picks.append((mid, "too_few_first", tf[0]))
    man = read_json(ROOT / "source_manifest.json")
    with open(ROOT / "config" / "releases.toml", "rb") as fh:
        rel_cfg = {r["key"]: r for r in tomllib.load(fh)["release"]}
    archive = man["archives"][rel_cfg[primary]["archive_key"]] if rel_cfg[primary]["source"] == "archive" else None
    raw_lines: dict[str, list[str]] = {}
    rows = []
    fields_map = {"Facility ID": "facility_id_src", "State": "state", "Measure ID": "measure_id",
                  "Compared to National": "compared_to_national_src", "Denominator": "denominator_src",
                  "Score": "score_src", "Lower Estimate": "lower_src", "Higher Estimate": "upper_src",
                  "Footnote": "footnote_src", "Start Date": "start_date_src", "End Date": "end_date_src"}
    for mid, role, rid in picks:
        rec = dict(zip([c[0] for c in con.execute("SELECT * FROM records LIMIT 0").description],
                       con.execute("SELECT * FROM records WHERE record_id=?", (rid,)).fetchone()))
        dkey = rec["dataset_key"]
        fname = {"unplanned_visits": "Unplanned_Hospital_Visits-Hospital.csv",
                 "complications_deaths": "Complications_and_Deaths-Hospital.csv"}[dkey]
        local = ROOT / (archive["members"][fname]["local_path"] if archive else man["datasets"][dkey]["local_path"])
        if dkey not in raw_lines:
            data = local.read_bytes()
            if data.startswith(b"\xef\xbb\xbf"):
                data = data[3:]
            raw_lines[dkey] = data.decode("utf-8").replace("\r\n", "\n").split("\n")
        lines = raw_lines[dkey]
        header = split_csv_line(lines[0])
        raw = dict(zip(header, split_csv_line(lines[rec["source_row"]])))
        mismatches = []
        for col, dbcol in fields_map.items():
            if raw.get(col, "") != (rec[dbcol] or ""):
                mismatches.append(f"{col}: raw={raw.get(col)!r} db={rec[dbcol]!r}")
        for col, dbcol in (("Score", "score_num"), ("Lower Estimate", "lower_num"), ("Higher Estimate", "upper_num")):
            try:
                val = float(Decimal(raw[col]))
            except (InvalidOperation, KeyError):
                val = None
            if val != rec[dbcol]:
                mismatches.append(f"{col} numeric: raw={val!r} db={rec[dbcol]!r}")
        rows.append({"measure_id": mid, "selection": role, "record_id": rid, "source_file": local.name,
                     "source_row": rec["source_row"], "facility_id": rec["facility_id"],
                     "score_src": raw.get("Score"), "lower_src": raw.get("Lower Estimate"),
                     "upper_src": raw.get("Higher Estimate"), "footnote_src": raw.get("Footnote"),
                     "fields_compared": len(fields_map) + 3, "mismatches": "; ".join(mismatches),
                     "matched": not mismatches})
    df = pd.DataFrame(rows)
    checks = [_check("24 prespecified records reconstructed from raw CSV bytes with an independent parser",
                     len(df) == 24 and bool(df["matched"].all()),
                     {"records": int(len(df)), "matched": int(df["matched"].sum())}, "reconstruction")]
    return df, checks


def second_implementation() -> list[dict]:
    if shutil.which("Rscript") is None:
        return [{"type": "check", "kind": "software_crosscheck", "check": "R reimplementation of pair counts",
                 "passed": None, "skipped": True, "detail": "Rscript not found; R is optional and the check was skipped"}]
    res = subprocess.run(["Rscript", str(ROOT / "scripts" / "crosscheck_pairs.R"), str(ROOT)],
                         capture_output=True, text=True)
    if res.returncode != 0:
        return [_check("R reimplementation of pair counts", False, res.stderr[-500:], "software_crosscheck")]
    r = pd.read_csv(TABLES / "r_crosscheck_pairs.csv", dtype={"release_key": str})
    p = pd.read_csv(TABLES / "pair_summary_national.csv", dtype={"release_key": str})
    p = p[p["subset"] == "primary"][["release_key", "measure_id", "pairs", "point_ordered_pairs", "sep_r1_count"]]
    m = r.merge(p, on=["release_key", "measure_id"], suffixes=("_r", "_py"), how="outer")
    eq = all((m[f"{c}_r"] == m[f"{c}_py"]).all() for c in ("pairs", "point_ordered_pairs", "sep_r1_count"))
    return [_check("R reimplementation reproduces pair, point-ordered and R1-separated counts", eq,
                   {"rows": int(len(m)), "r_version": res.stdout.strip().split(" with ")[-1]}, "software_crosscheck")]


def compare_tables(a_dir: Path, b_dir: Path, tol: float) -> list[dict]:
    out = []
    for fa in sorted(a_dir.glob("*.csv")):
        if fa.name.startswith("r_crosscheck"):
            continue
        fb = b_dir / fa.name
        if not fb.exists():
            out.append({"table": fa.name, "identical": False, "detail": "missing in rerun"})
            continue
        A = pd.read_csv(fa, dtype=str, keep_default_na=False)
        B = pd.read_csv(fb, dtype=str, keep_default_na=False)
        if A.shape != B.shape or list(A.columns) != list(B.columns):
            out.append({"table": fa.name, "identical": False, "detail": f"shape {A.shape} vs {B.shape}"})
            continue
        bad_cols = []
        for c in A.columns:
            if (A[c] == B[c]).all():
                continue
            try:
                x = pd.to_numeric(A[c]).to_numpy(dtype=float)
                y = pd.to_numeric(B[c]).to_numpy(dtype=float)
                if not np.allclose(x, y, atol=tol, rtol=0, equal_nan=True):
                    bad_cols.append(c)
            except (ValueError, TypeError):
                bad_cols.append(c)
        out.append({"table": fa.name, "rows": int(len(A)), "identical": not bad_cols,
                    "detail": ", ".join(bad_cols)})
    ea, eb = a_dir / "examples.json", b_dir / "examples.json"
    out.append({"table": "examples.json", "identical": read_json(ea) == read_json(eb), "detail": ""})
    return out


def rerun_check() -> list[dict]:
    from . import analyze, build

    tol = load_config()["analysis"]["rerun_tolerance"]
    rr = OUTPUTS / "rerun"
    if rr.exists():
        shutil.rmtree(rr)
    (rr / "tables").mkdir(parents=True)
    build.run(db_path=rr / "hospcomp_rerun.sqlite", log_path=rr / "build_log_rerun.json")
    analyze.run(db_path=rr / "hospcomp_rerun.sqlite", tables_dir=rr / "tables", write_manifest=False)
    comp = compare_tables(TABLES, rr / "tables", tol)
    pd.DataFrame(comp).to_csv(VALIDATION / "rerun_comparison.csv", index=False)
    ok = all(c["identical"] for c in comp)
    return [_check(f"full rebuild and reanalysis from cached inputs reproduces all {len(comp)} outputs (tolerance {tol})",
                   ok, {"tables": len(comp), "differing": [c["table"] for c in comp if not c["identical"]]},
                   "software_crosscheck")]


def write_hand_check_template(con: sqlite3.Connection) -> Path:
    """Write the author's hand-check list once. Existing author entries are never overwritten."""
    path = OUTPUTS / "verification" / "hand_check.csv"
    if path.exists():
        return path
    path.parent.mkdir(parents=True, exist_ok=True)
    primary = con.execute("SELECT release_key FROM releases WHERE role='primary'").fetchone()[0]
    rows = []
    recon = pd.read_csv(VALIDATION / "raw_reconstruction.csv", dtype=str)
    pick = recon[recon["selection"].isin(["compatible_first", "too_few_first"])]
    for _, r in pick.iterrows():
        rec = con.execute("SELECT score_src, lower_src, upper_src, footnote_src, start_date_src, end_date_src "
                          "FROM records WHERE record_id=?", (r["record_id"],)).fetchone()
        rows.append({"check_type": "raw_record", "target": r["record_id"],
                     "what_to_compare": f"Open {r['source_file']} from the {primary} archive, data row {r['source_row']} "
                                        "(row 1 is the first row after the header); compare Score, Lower Estimate, Higher "
                                        "Estimate, Footnote, Start Date and End Date with the review workbook",
                     "expected": f"score={rec[0]!r}; lower={rec[1]!r}; upper={rec[2]!r}; footnote={rec[3]!r}; "
                                 f"start={rec[4]}; end={rec[5]}"})
    ex = read_json(TABLES / "examples.json")
    th, pp = ex["top_hospital"], ex["passing_pair"]
    rows.append({"check_type": "example", "target": f"{ex['measure_id']} {ex['state']} {th['facility_id']}",
                 "what_to_compare": "Find the lead-example hospital in the raw file and compare score and interval",
                 "expected": f"{th['score_num']} [{th['lower_num']}, {th['upper_num']}]"})
    for side in ("a", "b"):
        rows.append({"check_type": "example", "target": f"{pp['measure_id']} {ex['state']} {pp['facility_' + side]}",
                     "what_to_compare": "Find the passing-example hospital in the raw file and compare score and interval",
                     "expected": f"{pp['score_' + side]} [{pp['lower_' + side]}, {pp['upper_' + side]}]"})
    rows.append({"check_type": "recalculation", "target": f"rank range of {th['facility_id']}",
                 "what_to_compare": "Count hospitals in the state whose upper limit is below this hospital's lower limit "
                                    "(best rank = 1 + count) and whose lower limit is above its upper limit (worst rank = n - count)",
                 "expected": f"ranks {th['best_rank']} to {th['worst_rank']} of {th['n']}"})
    rows.append({"check_type": "recalculation", "target": f"separation of {pp['facility_a']} and {pp['facility_b']}",
                 "what_to_compare": "Subtract the lower hospital's upper limit from the other hospital's lower limit",
                 "expected": f"gap {pp['gap']} percentage points (separated under R1)"})
    for target, what in (
            ("CMS listserve 2026-89-IP", "Confirm the 18 listed measures, suppression until July 2027 and that hospital rates were not affected"),
            ("FY 2026 IPPS final rule, 90 FR 36537, 36931-36932, 36949", "Confirm the Medicare Advantage addition, the 2-year period and the COVID-19 exclusion text"),
            ("QualityNet reports: 2025 readmission PDF pp. 10 and 15; 2025 mortality PDF pp. 11 and 16; 2025 EDAC PDF pp. 10, 75 and 77", "Confirm that Medicare enrollment criteria do not apply to VA hospitalizations"),
            ("2025 EDAC report p. 37", "Confirm AMI EDAC counts 278, 736, 551 and 2,149")):
        rows.append({"check_type": "document", "target": target, "what_to_compare": what, "expected": "as stated in the manuscript"})
    rows.append({"check_type": "references", "target": "all manuscript references",
                 "what_to_compare": "Check each reference against PubMed, its DOI or the cited web page",
                 "expected": "details match"})
    rows.append({"check_type": "numbers", "target": "abstract, Tables 1 to 3, figure legends",
                 "what_to_compare": "Compare each number with evidence/claims.json", "expected": "all numbers match"})
    df = pd.DataFrame(rows)
    df.insert(0, "check_id", [f"H{i:02d}" for i in range(1, len(df) + 1)])
    df["author_result"] = ""
    df["author_date"] = ""
    df["author_note"] = ""
    df.to_csv(path, index=False)
    return path


def run(rerun: bool = True) -> dict:
    VALIDATION.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    checks = data_checks(con)
    recon_df, rchecks = reconcile(con)
    recon_df.to_csv(VALIDATION / "reconciliation_categories.csv", index=False)
    checks += rchecks
    recon, cchecks = reconstruct(con)
    recon.to_csv(VALIDATION / "raw_reconstruction.csv", index=False)
    checks += cchecks
    write_hand_check_template(con)
    con.close()
    checks += second_implementation()
    if rerun:
        checks += rerun_check()
    real = [c for c in checks if c["type"] == "check" and c["passed"] is not None]
    summary = {"completed_utc": utc_now(),
               "checks": len(real), "passed": sum(c["passed"] for c in real),
               "all_passed": all(c["passed"] for c in real),
               "skipped": sum(1 for c in checks if c.get("skipped")),
               "records": sum(1 for c in checks if c["type"] == "record"),
               "entries": len(checks),
               "by_kind": {k: sum(1 for c in checks if c["kind"] == k) for k in sorted({c["kind"] for c in checks})}}
    report = {"summary": summary, "checks": checks}
    write_json(VALIDATION / "validation_report.json", report)
    return report
