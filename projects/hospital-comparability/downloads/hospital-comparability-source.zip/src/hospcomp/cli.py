"""Command-line interface: `hospcomp <command>`.

Pipeline stages: acquire, build, lock-plan, analyze, validate, render, package, all.
Validator commands (read the frozen study database): compare, check-request, check-pair.
`demo` runs the full pipeline on the synthetic fixture in a temporary directory.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

from .common import DB_PATH, ROOT, sha256_file, utc_now, write_json


def _db() -> sqlite3.Connection:
    if not DB_PATH.exists():
        sys.exit("study database not found; run `hospcomp build` and `hospcomp analyze` first")
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    has = con.execute("SELECT name FROM sqlite_master WHERE name='gate_results'").fetchone()
    if not has:
        sys.exit("gate results not found; run `hospcomp analyze` first")
    return con


def _release(con: sqlite3.Connection, requested: str | None) -> sqlite3.Row:
    if requested:
        row = con.execute("SELECT * FROM releases WHERE release_key=?", (requested,)).fetchone()
        if row is None:
            keys = [r[0] for r in con.execute("SELECT release_key FROM releases")]
            sys.exit(f"unknown release {requested}; available: {', '.join(keys)}")
        return row
    return con.execute("SELECT * FROM releases WHERE role='primary'").fetchone()


def cmd_lock_plan(args) -> None:
    plan = ROOT / "docs" / "analysis_plan.md"
    lock = ROOT / "docs" / "analysis_plan.lock.json"
    entry = {"file": "docs/analysis_plan.md", "sha256": sha256_file(plan), "locked_utc": utc_now(),
             "note": "Internal timestamped lock; not a formal preregistration."}
    if lock.exists() and not args.force:
        prev = json.loads(lock.read_text())
        if prev["sha256"] == entry["sha256"]:
            print(f"plan already locked at {prev['locked_utc']}")
            return
        sys.exit("plan changed since lock; add an amendment and rerun with --force")
    if lock.exists():
        prev = json.loads(lock.read_text())
        entry["previous_locks"] = prev.get("previous_locks", []) + [{k: prev[k] for k in ("sha256", "locked_utc")}]
    write_json(lock, entry)
    _log_command("lock-plan --force" if args.force else "lock-plan", entry["locked_utc"], "ok")
    print(f"locked {entry['sha256'][:12]} at {entry['locked_utc']}")


def cmd_compare(args) -> None:
    con = _db()
    rel = _release(con, args.release)
    rk = rel["release_key"]
    m = con.execute("SELECT d.*, w.official_start, w.official_end, w.window_months FROM measure_dictionary d "
                    "JOIN measure_windows w ON w.measure_id = d.measure_id AND w.release_key = ? "
                    "WHERE d.measure_id = ?", (rk, args.measure)).fetchone()
    if m is None or m["study_role"] == "lookalike":
        sys.exit(f"{args.measure} is not a study measure in config/measures.toml")
    rows = con.execute("SELECT * FROM gate_results WHERE release_key=? AND measure_id=? AND state=? ORDER BY facility_id",
                       (rk, args.measure, args.state)).fetchall()
    if not rows:
        sys.exit(f"no records for {args.measure} in {args.state} in release {rk}")
    ranks = {r["facility_id"]: r for r in con.execute(
        "SELECT * FROM rank_ranges WHERE subset=? AND release_key=? AND measure_id=? AND state=?",
        (args.subset, rk, args.measure, args.state))}
    pairs = con.execute(
        "SELECT COUNT(*) n, SUM(point_ordered) po, SUM(point_ordered*sep_r1) s1, SUM(point_ordered*sep_r2) s2, "
        "SUM(point_ordered*sep_r3) s3 FROM pairs WHERE release_key=? AND measure_id=? AND state=?"
        + ("" if args.subset == "primary" else " AND caution_a=0 AND caution_b=0"),
        (rk, args.measure, args.state)).fetchone()
    comp = [r for r in rows if r["compatible"] == 1 and (args.subset == "primary" or r["caution_flag"] == 0)]
    comp_ids = {r["facility_id"] for r in comp}
    excluded = [r for r in rows if r["facility_id"] not in comp_ids]
    out = {
        "request": {"release": rk, "measure_id": args.measure, "state": args.state, "subset": args.subset},
        "release_status": {"interval_status": rel["interval_status"], "note": rel["status_note"], "notice": rel["notice"]},
        "measure": {k: m[k] for k in ("quantity", "unit", "favorable", "official_start", "official_end", "window_months")},
        "requested_records": len(rows),
        "compatible_records": len(comp),
        "not_compared": [{"facility_id": r["facility_id"], "facility_name": r["facility_name"],
                          "gate": r["first_failed_gate"] or "S1-caution", "reason": r["reason_code"],
                          "score_src": r["score_src"], "lower_src": r["lower_src"], "upper_src": r["upper_src"],
                          "footnote_src": r["footnote_src"]} for r in excluded],
        "compared": [{"facility_id": r["facility_id"], "facility_name": r["facility_name"], "score": r["score_num"],
                      "lower": r["lower_num"], "upper": r["upper_num"], "cms_category": r["compared_to_national_src"],
                      "point_rank": ranks[r["facility_id"]]["point_rank"] if r["facility_id"] in ranks else None,
                      "rank_range": [ranks[r["facility_id"]]["best_rank"], ranks[r["facility_id"]]["worst_rank"]]
                      if r["facility_id"] in ranks else None}
                     for r in sorted(comp, key=lambda x: (x["score_num"], x["facility_id"]))],
        "pairs": {"pairs": pairs["n"], "point_ordered": pairs["po"] or 0, "separated_r1": pairs["s1"] or 0,
                  "separated_r2": pairs["s2"] or 0, "separated_r3": pairs["s3"] or 0},
        "note": ("Rank ranges are interval-compatible ranges from each hospital's published 95% interval; "
                 "they are not simultaneous confidence sets and carry no probability."),
    }
    if args.format == "json":
        print(json.dumps(out, indent=1))
        return
    print(f"release {rk}: {rel['label']} [intervals: {rel['interval_status']}]")
    print(f"{args.measure} in {args.state} ({m['quantity']}, {m['unit']}, {m['favorable']} is better)")
    print(f"window {m['official_start']} to {m['official_end']} ({m['window_months']} months); "
          f"requested {len(rows)}; compatible {len(comp)}")
    if comp:
        print(f"{'facility':8} {'score':>7} {'interval':>15} {'point':>5} {'range':>9}  name")
        for c in out["compared"]:
            rr = c["rank_range"]
            print(f"{c['facility_id']:8} {c['score']:7.1f} [{c['lower']:6.1f},{c['upper']:6.1f}] "
                  f"{c['point_rank'] or '':>5} {f'{rr[0]}-{rr[1]}' if rr else '':>9}  {c['facility_name']}")
        p = out["pairs"]
        print(f"pairs {p['pairs']}; point-ordered {p['point_ordered']}; separated R1 {p['separated_r1']} "
              f"R2 {p['separated_r2']} R3 {p['separated_r3']}")
    if excluded:
        print("not compared:")
        for e in out["not_compared"]:
            print(f"  {e['facility_id']} {e['gate']:<10} {e['reason']:<38} score={e['score_src']!r} "
                  f"interval=[{e['lower_src']}, {e['upper_src']}] footnote={e['footnote_src']!r}")
    print(out["note"])


def cmd_check_request(args) -> None:
    con = _db()
    ra = _release(con, args.release_a)["release_key"]
    rb = _release(con, args.release_b or args.release_a)["release_key"]
    q = ("SELECT d.*, w.modal_start, w.modal_end, w.window_months, w.release_key FROM measure_dictionary d "
         "JOIN measure_windows w ON w.measure_id = d.measure_id WHERE d.measure_id=? AND w.release_key=?")
    a = con.execute(q, (args.measure_a, ra)).fetchone()
    b = con.execute(q, (args.measure_b, rb)).fetchone()
    if a is None or b is None:
        sys.exit("both measures must be in the study dictionary (config/measures.toml)")
    checks = [
        ("same measure ID", a["measure_id"] == b["measure_id"]),
        ("same quantity", a["quantity"] == b["quantity"]),
        ("same unit", a["unit"] == b["unit"]),
        ("same observation window", (a["modal_start"], a["modal_end"]) == (b["modal_start"], b["modal_end"])),
        ("same condition", a["condition"] == b["condition"]),
    ]
    changes = []
    if ra != rb and a["measure_id"] == b["measure_id"]:
        lo, hi = sorted([ra, rb])
        changes = con.execute("SELECT * FROM definition_changes WHERE measure_id=? AND from_release>=? AND to_release<=?",
                              (a["measure_id"], lo, hi)).fetchall()
        checks.append(("no documented definition change between releases", not changes))
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
    for x in (a, b):
        print(f"  {x['measure_id']} [{x['release_key']}]: {x['quantity']} ({x['unit']}), {x['modal_start']} to "
              f"{x['modal_end']} [{x['window_months']} months], source {x['dataset_key']}")
    for c in changes:
        print(f"  documented change: {c['change']} Source: {c['source']}")
    verdict = all(ok for _, ok in checks)
    print("comparable" if verdict else "not comparable: same measure, same definition and same window are required")
    sys.exit(0 if verdict else 2)


def cmd_check_pair(args) -> None:
    from .compare import Est, separated_r1, separated_r2, separated_r3, to_units

    con = _db()
    rk = _release(con, args.release)["release_key"]
    rows = {r["facility_id"]: r for r in con.execute(
        "SELECT * FROM gate_results WHERE release_key=? AND measure_id=? AND facility_id IN (?,?)",
        (rk, args.measure, args.facility_a, args.facility_b))}
    for f in (args.facility_a, args.facility_b):
        if f not in rows:
            sys.exit(f"no {args.measure} record for {f}")
    ra, rb = rows[args.facility_a], rows[args.facility_b]
    for r in (ra, rb):
        print(f"{r['facility_id']} {r['state']} compatible={r['compatible']} reason={r['reason_code']} "
              f"score={r['score_src']!r} interval=[{r['lower_src']}, {r['upper_src']}] footnote={r['footnote_src']!r}")
    if ra["state"] != rb["state"]:
        print("not compared: different states (the comparison universe is one state)")
        return
    if not (ra["compatible"] and rb["compatible"]):
        print("not compared: at least one record fails a gate")
        return
    d = ra["reported_decimals"]
    ea = Est(ra["facility_id"], to_units(ra["score_num"], d), to_units(ra["lower_num"], d), to_units(ra["upper_num"], d))
    eb = Est(rb["facility_id"], to_units(rb["score_num"], d), to_units(rb["lower_num"], d), to_units(rb["upper_num"], d))
    fav = ra["favorable"]
    print(f"point-ordered: {ea.score != eb.score}; R1 separated: {separated_r1(ea, eb, fav)}; "
          f"R2: {separated_r2(ea, eb, fav)}; R3: {separated_r3(ea, eb, fav)}")


def _log_command(name: str, started: str, status: str) -> None:
    from .common import LOGS
    LOGS.mkdir(parents=True, exist_ok=True)
    with open(LOGS / "commands.jsonl", "a", encoding="utf-8") as fh:
        fh.write(json.dumps({"command": f"hospcomp {name}", "started_utc": started, "finished_utc": utc_now(),
                             "status": status}) + "\n")


def _stage(name: str):
    def run(args):
        started = utc_now()
        try:
            _run_stage(name, args)
        except SystemExit as exc:
            _log_command(name, started, f"exit {exc.code}")
            raise
        except Exception:
            _log_command(name, started, "error")
            raise
        _log_command(name, started, "ok")
    return run


def _run_stage(name: str, args) -> None:
    if True:
        if name == "acquire":
            from .acquire import acquire_archives, run as f
            # Archives first: they are fixed snapshots, so a newer live release does not block them.
            acquire_archives(force=args.force)
            f(force=args.force)
        elif name == "build":
            from .build import run as f
            res = f()
            print(json.dumps({k: res[k] for k in ("records_by_release", "hospitals_by_release")}))
        elif name == "analyze":
            from .analyze import run as f
            print(json.dumps(f(), indent=1))
        elif name == "validate":
            from .validate import run as f
            res = f(rerun=not args.skip_rerun)
            print(json.dumps(res["summary"], indent=1))
            if not res["summary"]["all_passed"]:
                sys.exit(1)
        elif name == "render":
            from .render import run as f
            res = f()
            print(json.dumps({k: res[k] for k in ("claims", "report", "site")}, indent=1, default=str))
        elif name == "package":
            from .package import run as f
            print(json.dumps(f(), indent=1))


def cmd_all(args) -> None:
    for stage in ("acquire", "build", "analyze", "validate", "render", "package"):
        print(f"== {stage}")
        ns = argparse.Namespace(force=False, skip_rerun=False)
        _stage(stage)(ns)


def cmd_demo(args) -> None:
    """Run build and analyze on the SYNTHETIC fixture in a temporary project root."""
    fixture = ROOT / "tests" / "fixtures" / "demo"
    if not fixture.exists():
        sys.exit("fixture missing; run `python scripts/make_fixture.py`")
    tmp = Path(tempfile.mkdtemp(prefix="hospcomp-demo-"))
    for d in ("config", "sql"):
        shutil.copytree(ROOT / d, tmp / d)
    (tmp / "docs").mkdir()
    for f in ("analysis_plan.md", "analysis_plan.lock.json"):
        shutil.copy2(ROOT / "docs" / f, tmp / "docs" / f)
    shutil.copytree(fixture, tmp / "data" / "raw")
    from .build import read_csv_rows

    datasets = {}
    meta = {"unplanned_visits": "632h-zaca", "complications_deaths": "ynj2-r877", "general_info": "xubh-q36u",
            "footnotes": "y9us-9xdf", "measure_dates": "4j6d-yzce", "hrrp": "9n3s-kdb3",
            "unplanned_national": "cvcs-xecj", "complications_national": "qqw3-t4ie",
            "unplanned_state": "4gkm-5ypv", "complications_state": "bs2r-24vh"}
    for key, did in meta.items():
        path = next((tmp / "data" / "raw" / key).glob("*.csv"))
        rows = list(read_csv_rows(path))
        datasets[key] = {"id": did, "title": f"SYNTHETIC FIXTURE {key}", "released": "2000-01-01", "modified": "2000-01-01",
                         "distribution_file_version": "fixture", "download_url": "fixture://" + path.name,
                         "local_path": f"data/raw/{key}/{path.name}", "sha256": sha256_file(path),
                         "data_rows": len(rows), "role": "fixture"}
    write_json(tmp / "source_manifest.json", {"description": "SYNTHETIC FIXTURE, not study data", "datasets": datasets, "documents": {}})
    (tmp / "config" / "releases.toml").write_text(
        '[[release]]\nkey = "fixture"\nsource = "live"\nrole = "primary"\nlabel = "SYNTHETIC FIXTURE"\n'
        'interval_status = "published"\nstatus_note = "synthetic"\nnotice = ""\nnotice_url = ""\n')
    env = dict(os.environ, HOSPCOMP_ROOT=str(tmp), PYTHONPATH=str(ROOT / "src"))
    for cmd in (["build"], ["analyze"], ["compare", "--measure", "READM_30_HF", "--state", "ZZ"]):
        print(f"== demo: hospcomp {' '.join(cmd)}")
        res = subprocess.run([sys.executable, "-m", "hospcomp.cli", *cmd], env=env, capture_output=True, text=True)
        print(res.stdout)
        if res.returncode != 0:
            print(res.stderr)
            sys.exit(res.returncode)
    print(f"demo root (synthetic fixture only): {tmp}")
    if not args.keep:
        shutil.rmtree(tmp)


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="hospcomp", description=__doc__.split("\n")[0])
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("acquire", help="resolve and download CMS sources, checking pinned checksums")
    s.add_argument("--force", action="store_true",
                   help="re-download everything and accept files that differ from the pinned checksums")
    s.set_defaults(func=_stage("acquire"))
    sub.add_parser("build", help="parse raw files into the study database").set_defaults(func=_stage("build"))
    s = sub.add_parser("lock-plan", help="hash-lock docs/analysis_plan.md")
    s.add_argument("--force", action="store_true")
    s.set_defaults(func=cmd_lock_plan)
    sub.add_parser("analyze", help="gates, pairs, rank ranges, sensitivity analyses").set_defaults(func=_stage("analyze"))
    s = sub.add_parser("validate", help="reconciliation, raw reconstruction, second implementation, rerun")
    s.add_argument("--skip-rerun", action="store_true")
    s.set_defaults(func=_stage("validate"))
    sub.add_parser("render", help="figures, workbook, report, manuscript and static site").set_defaults(func=_stage("render"))
    sub.add_parser("package", help="source archive, handoff files and outer ZIP").set_defaults(func=_stage("package"))
    sub.add_parser("all", help="run every pipeline stage in order").set_defaults(func=cmd_all)
    s = sub.add_parser("compare", help="validate a within-state same-measure comparison")
    s.add_argument("--measure", required=True)
    s.add_argument("--state", required=True)
    s.add_argument("--subset", choices=["primary", "strict"], default="primary")
    s.add_argument("--format", choices=["table", "json"], default="table")
    s.add_argument("--release", help="release key (default: the primary release)")
    s.set_defaults(func=cmd_compare)
    s = sub.add_parser("check-request", help="check whether two measures can be compared at all")
    s.add_argument("--measure-a", required=True)
    s.add_argument("--measure-b", required=True)
    s.add_argument("--release-a", help="release key for measure A (default: primary)")
    s.add_argument("--release-b", help="release key for measure B (default: same as A)")
    s.set_defaults(func=cmd_check_request)
    s = sub.add_parser("check-pair", help="gate and separation decision for two hospitals")
    s.add_argument("--measure", required=True)
    s.add_argument("--facility-a", required=True)
    s.add_argument("--facility-b", required=True)
    s.add_argument("--release", help="release key (default: the primary release)")
    s.set_defaults(func=cmd_check_pair)
    s = sub.add_parser("demo", help="run the pipeline on the synthetic fixture only")
    s.add_argument("--keep", action="store_true")
    s.set_defaults(func=cmd_demo)
    args = p.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
