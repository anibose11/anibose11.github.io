"""Evidence map: every headline number with its output path, selector, numerator,
denominator, scope, configuration, source hashes and run ID.

The manuscript, project page and handoff files read their numbers from
evidence/claims.json, so no figure in the text is typed by hand.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .common import OUTPUTS, ROOT, TABLES, read_json, rel, utc_now, write_json

CLAIMS = ROOT / "evidence" / "claims.json"


class Evidence:
    def __init__(self) -> None:
        self.run = read_json(OUTPUTS / "run_manifest.json")
        self.primary = self.run["primary_release"]
        self.items: list[dict] = []
        self._cache: dict[str, pd.DataFrame] = {}

    def table(self, name: str) -> pd.DataFrame:
        if name not in self._cache:
            path = TABLES / name if (TABLES / name).exists() else OUTPUTS / "validation" / name
            self._cache[name] = pd.read_csv(path, dtype={"release_key": str, "facility_id": str, "state": str})
        return self._cache[name]

    def path_of(self, name: str) -> str:
        return rel(TABLES / name) if (TABLES / name).exists() else rel(OUTPUTS / "validation" / name)

    def row(self, name: str, **flt) -> pd.Series:
        df = self.table(name)
        for k, v in flt.items():
            df = df[df[k] == v]
        if len(df) != 1:
            raise ValueError(f"{name} {flt}: expected one row, got {len(df)}")
        return df.iloc[0]

    def add(self, cid: str, statement: str, value, *, table: str, selector: dict, column: str,
            numerator=None, denominator=None, unit: str = "", scope: str = "", sources: list[str] | None = None) -> None:
        def clean(x):
            if hasattr(x, "item"):
                x = x.item()
            return x
        self.items.append({
            "id": cid, "statement": statement, "value": clean(value), "unit": unit,
            "numerator": clean(numerator), "denominator": clean(denominator),
            "output_path": self.path_of(table) if table.endswith(".csv") else table,
            "selector": selector, "column": column, "scope": scope,
            "source_keys": sources or [], "run_id": self.run["run_id"],
        })

    def get(self, cid: str):
        return next(i for i in self.items if i["id"] == cid)["value"]


def build() -> dict:
    ev = Evidence()
    P = ev.primary
    prim_src = [k for k in ev.run["source_sha256"] if k.startswith("pdc_2026_05_13/")]
    cur_src = ["unplanned_visits", "complications_deaths"]
    measures = ["READM_30_HF", "MORT_30_HF", "EDAC_30_HF", "READM_30_AMI", "MORT_30_AMI", "EDAC_30_AMI"]
    short = {"READM_30_HF": "readm_hf", "MORT_30_HF": "mort_hf", "EDAC_30_HF": "edac_hf",
             "READM_30_AMI": "readm_ami", "MORT_30_AMI": "mort_ami", "EDAC_30_AMI": "edac_ami"}

    for m in measures:
        s = short[m]
        g = ev.row("gate_flow_national.csv", release_key=P, measure_id=m)
        ev.add(f"{s}_requested", f"{m} records requested in release {P}", g["requested_records"],
               table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m}, column="requested_records",
               unit="records", scope=f"release {P}, all states", sources=prim_src)
        ev.add(f"{s}_compatible", f"{m} records passing all gates in release {P}", g["compatible"],
               table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m}, column="compatible",
               numerator=g["compatible"], denominator=g["requested_records"], unit="records",
               scope=f"release {P}, all states", sources=prim_src)
        ev.add(f"{s}_compatible_share", f"Share of requested {m} records that are compatible", g["compatible_share_of_requested"],
               table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m},
               column="compatible_share_of_requested", numerator=g["compatible"], denominator=g["requested_records"],
               unit="proportion", scope=f"release {P}", sources=prim_src)
        ev.add(f"{s}_compatible_share_broader", f"Compatible {m} records as a share of all hospitals in General Information",
               g["compatible_share_of_broader"], table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m},
               column="compatible_share_of_broader", numerator=g["compatible"],
               denominator=g["broader_denominator_general_info"], unit="proportion", scope=f"release {P} (S1 iii)",
               sources=prim_src)
        ev.add(f"{s}_compatible_strict", f"{m} compatible records without caution footnotes (S1 ii)", g["compatible_strict"],
               table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m}, column="compatible_strict",
               numerator=g["compatible_strict"], denominator=g["requested_records"], unit="records", scope=f"release {P}",
               sources=prim_src)
        for gate in ("g2b_population", "g3_window", "g4_score"):
            ev.add(f"{s}_pass_{gate}", f"{m} records remaining after {gate}", g[f"pass_through_{gate}"],
                   table="gate_flow_national.csv", selector={"release_key": P, "measure_id": m},
                   column=f"pass_through_{gate}", unit="records", scope=f"release {P}", sources=prim_src)
        for subset in ("primary", "strict"):
            pr = ev.row("pair_summary_national.csv", subset=subset, release_key=P, measure_id=m)
            sfx = "" if subset == "primary" else "_strict"
            ev.add(f"{s}_pairs{sfx}", f"{m} same-state pairs of compatible hospitals ({subset})", pr["pairs"],
                   table="pair_summary_national.csv", selector={"subset": subset, "release_key": P, "measure_id": m},
                   column="pairs", unit="pairs", scope=f"release {P}, pooled across states", sources=prim_src)
            ev.add(f"{s}_point_ordered{sfx}", f"{m} point-ordered pairs ({subset})", pr["point_ordered_pairs"],
                   table="pair_summary_national.csv", selector={"subset": subset, "release_key": P, "measure_id": m},
                   column="point_ordered_pairs", unit="pairs", scope=f"release {P}", sources=prim_src)
            ev.add(f"{s}_tied{sfx}", f"{m} tied pairs ({subset})", pr["tied_pairs"], table="pair_summary_national.csv",
                   selector={"subset": subset, "release_key": P, "measure_id": m}, column="tied_pairs", unit="pairs",
                   scope=f"release {P}", sources=prim_src)
            ev.add(f"{s}_sep_r1{sfx}", f"{m} point-ordered pairs separated under R1 ({subset})", pr["sep_r1_count"],
                   table="pair_summary_national.csv", selector={"subset": subset, "release_key": P, "measure_id": m},
                   column="sep_r1_count", numerator=pr["sep_r1_count"], denominator=pr["point_ordered_pairs"], unit="pairs",
                   scope=f"release {P}", sources=prim_src)
            ev.add(f"{s}_not_sep{sfx}", f"Share of {m} point-ordered pairs not separated under R1 ({subset})",
                   pr["not_separated_r1_share"], table="pair_summary_national.csv",
                   selector={"subset": subset, "release_key": P, "measure_id": m}, column="not_separated_r1_share",
                   numerator=pr["not_separated_r1_count"], denominator=pr["point_ordered_pairs"], unit="proportion",
                   scope=f"release {P}, pooled pairs", sources=prim_src)
            if subset == "primary":
                for rule in ("sep_r2", "sep_r3", "official_opposite"):
                    ev.add(f"{s}_{rule}_share", f"Share of {m} point-ordered pairs with {rule}", pr[f"{rule}_share"],
                           table="pair_summary_national.csv", selector={"subset": subset, "release_key": P, "measure_id": m},
                           column=f"{rule}_share", numerator=pr[f"{rule}_count"], denominator=pr["point_ordered_pairs"],
                           unit="proportion", scope=f"release {P} (S2)", sources=prim_src)
        sw = ev.row("state_weighted_summary.csv", subset="primary", release_key=P, measure_id=m)
        for col in ("median_state_not_separated_share", "q1", "q3", "min_state_share", "max_state_share",
                    "states_with_point_ordered_pairs"):
            ev.add(f"{s}_state_{col}", f"{m} state-level not-separated share, {col} (states weighted equally)", sw[col],
                   table="state_weighted_summary.csv", selector={"subset": "primary", "release_key": P, "measure_id": m},
                   column=col, unit="proportion" if col != "states_with_point_ordered_pairs" else "states",
                   scope=f"release {P}", sources=prim_src)
        hl = ev.row("hospital_level_summary.csv", subset="primary", release_key=P, measure_id=m)
        for col in ("median_separated_share", "q1", "q3", "share_separated_from_none", "hospitals_separated_from_none",
                    "hospitals_with_point_ordered_comparisons"):
            ev.add(f"{s}_hosp_{col}", f"{m} hospital-level {col}", hl[col], table="hospital_level_summary.csv",
                   selector={"subset": "primary", "release_key": P, "measure_id": m}, column=col,
                   numerator=hl["hospitals_separated_from_none"] if col == "share_separated_from_none" else None,
                   denominator=hl["hospitals_with_point_ordered_comparisons"] if col == "share_separated_from_none" else None,
                   unit="proportion" if "share" in col else "hospitals", scope=f"release {P}", sources=prim_src)
        rs = ev.row("rank_range_summary.csv", subset="primary", release_key=P, measure_id=m)
        for col in ("median_width_share_of_n", "share_width_over_half_of_n", "share_full_range", "universes_n_ge_10",
                    "top_ranked_median_worst_rank_share_n_ge_10", "top_ranked_worst_rank_over_half_n_ge_10",
                    "hospitals_in_universes_n_ge_2"):
            ev.add(f"{s}_rank_{col}", f"{m} rank-range summary {col}", rs[col], table="rank_range_summary.csv",
                   selector={"subset": "primary", "release_key": P, "measure_id": m}, column=col,
                   unit="proportion" if "share" in col else "count", scope=f"release {P}", sources=prim_src)

    # Reference values (exported from the database to outputs/tables/reference_values.csv)
    rv = ev.table("reference_values.csv")

    def refval(item: str, rk: str, mid: str = ""):
        sub = rv[(rv["item"] == item) & (rv["release_key"] == rk) & (rv["measure_id"].fillna("") == mid)]
        return sub["value"].iloc[0] if len(sub) else None

    for m in measures:
        for rk in (P, "2026-09-30"):
            ev.add(f"natrate_{short[m]}_{rk}", f"CMS national value for {m} in release {rk}",
                   refval("cms_national_value", rk, m), table="reference_values.csv",
                   selector={"item": "cms_national_value", "release_key": rk, "measure_id": m}, column="value")
    ev.add("readm_hf_fn29_numeric", "READM_30_HF records with footnote 29 and a numeric score in the primary release",
           int(refval("footnote_29_with_numeric_score", P, "READM_30_HF") or 0), table="reference_values.csv",
           selector={"item": "footnote_29_with_numeric_score", "release_key": P, "measure_id": "READM_30_HF"},
           column="value", unit="records")
    for rk in (P, "2026-08-13", "2026-09-30"):
        ev.add(f"facilities_{rk}", f"Facilities in the outcome files of release {rk}",
               int(refval("facilities_in_outcome_files", rk)), table="reference_values.csv",
               selector={"item": "facilities_in_outcome_files", "release_key": rk}, column="value", unit="facilities")
        ev.add(f"general_info_{rk}", f"Hospitals in General Information for release {rk}",
               int(refval("hospitals_in_general_information", rk)), table="reference_values.csv",
               selector={"item": "hospitals_in_general_information", "release_key": rk}, column="value",
               unit="hospitals")

    # Compatible records by hospital type (STROBE 14a)
    ht = ev.table("compatible_by_hospital_type.csv")
    for m in ("READM_30_HF", "MORT_30_HF"):
        for typ, tag in (("Acute Care Hospitals", "acute"), ("Critical Access Hospitals", "cah"),
                         ("Acute Care - Veterans Administration", "va")):
            r = ht[(ht["release_key"] == P) & (ht["measure_id"] == m) & (ht["hospital_type"] == typ)].iloc[0]
            for col in ("requested", "compatible", "numeric_score"):
                ev.add(f"type_{short[m]}_{tag}_{col}", f"{m} {typ}: {col}", int(r[col]), table="compatible_by_hospital_type.csv",
                       selector={"release_key": P, "measure_id": m, "hospital_type": typ}, column=col, unit="records")
        zero = ht[(ht["release_key"] == P) & (ht["measure_id"] == m) & (ht["compatible"] == 0)
                  & (ht["hospital_type"] != "Acute Care - Veterans Administration")]
        ev.add(f"type_{short[m]}_zero_types", f"{m}: hospital types with no compatible record (excluding VA)",
               "; ".join(f"{a} ({int(b)})" for a, b in zip(zero["hospital_type"], zero["requested"])),
               table="compatible_by_hospital_type.csv", selector={"release_key": P, "measure_id": m, "compatible": 0},
               column="hospital_type")

    # Records excluded by G2b, compared only within their own hospital type (descriptive)
    sg = ev.table("separate_group_summary.csv")
    for m in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
        r = sg[(sg["release_key"] == P) & (sg["measure_id"] == m)]
        r = r.iloc[0] if len(r) else None
        for col in ("records_passing_other_gates", "states_with_2_or_more", "pairs", "point_ordered_pairs", "sep_r1_count"):
            ev.add(f"va_{short[m]}_{col}", f"{m} VA-only comparison: {col}", int(r[col]) if r is not None else 0,
                   table="separate_group_summary.csv", selector={"release_key": P, "measure_id": m}, column=col)

    # Current and flagged releases
    for rk, tag in (("2026-09-30", "cur"), ("2026-08-13", "flag")):
        for m in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
            g = ev.row("gate_flow_national.csv", release_key=rk, measure_id=m)
            ev.add(f"{tag}_{short[m]}_numeric", f"{m} records with a numeric score in release {rk}",
                   g["independent_pass_g4_score"], table="gate_flow_national.csv",
                   selector={"release_key": rk, "measure_id": m}, column="independent_pass_g4_score", unit="records",
                   scope=f"release {rk}", sources=cur_src if tag == "cur" else
                   [k for k in ev.run["source_sha256"] if k.startswith("pdc_2026_08_13/")])
            ev.add(f"{tag}_{short[m]}_with_interval", f"{m} records with a usable interval in release {rk}",
                   g["independent_pass_g5_interval"], table="gate_flow_national.csv",
                   selector={"release_key": rk, "measure_id": m}, column="independent_pass_g5_interval", unit="records",
                   scope=f"release {rk}")
            ev.add(f"{tag}_{short[m]}_compatible", f"{m} compatible records in release {rk}", g["compatible"],
                   table="gate_flow_national.csv", selector={"release_key": rk, "measure_id": m}, column="compatible",
                   unit="records", scope=f"release {rk}")
            ev.add(f"{tag}_{short[m]}_requested", f"{m} records requested in release {rk}", g["requested_records"],
                   table="gate_flow_national.csv", selector={"release_key": rk, "measure_id": m},
                   column="requested_records", unit="records", scope=f"release {rk}")

    # Failure reasons for HF readmission in the primary release
    fr = ev.table("failure_reasons.csv")
    for reason in ("too_few_cases", "not_available_this_period", "not_eligible_program", "partial_or_short_period_footnote",
                   "no_eligible_cases", "population_or_data_source_differs"):
        for m in ("READM_30_HF", "MORT_30_HF"):
            sub = fr[(fr["release_key"] == P) & (fr["measure_id"] == m) & (fr["reason_code"] == reason)]
            val = int(sub["records"].sum()) if len(sub) else 0
            ev.add(f"{short[m]}_reason_{reason}", f"{m} records whose first failure is {reason}", val,
                   table="failure_reasons.csv", selector={"release_key": P, "measure_id": m, "reason_code": reason},
                   column="records", unit="records", scope=f"release {P}", sources=prim_src)

    # Cross-release windows and identifiers
    cw = ev.table("cross_release_windows.csv")
    for m in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
        for rk in ("2026-05-13", "2026-08-13", "2026-09-30"):
            r = cw[(cw["measure_id"] == m) & (cw["release_key"] == rk)].iloc[0]
            ev.add(f"win_{short[m]}_{rk}", f"{m} observation window in release {rk}",
                   f"{r['window_start']} to {r['window_end']}", table="cross_release_windows.csv",
                   selector={"measure_id": m, "release_key": rk}, column="window_start,window_end", scope="window")
            ev.add(f"winmonths_{short[m]}_{rk}", f"{m} window length in release {rk}", r["window_months"],
                   table="cross_release_windows.csv", selector={"measure_id": m, "release_key": rk},
                   column="window_months", unit="months", scope="window")
        r = cw[(cw["measure_id"] == m) & (cw["release_key"] == "2026-09-30")].iloc[0]
        ev.add(f"overlap_{short[m]}", f"Months shared by the {m} windows of releases {P} and 2026-09-30",
               r["overlap_months_with_primary"], table="cross_release_windows.csv",
               selector={"measure_id": m, "release_key": "2026-09-30"}, column="overlap_months_with_primary",
               unit="months", scope="cross-release")
    fp = ev.row("facility_presence.csv", release_a=P, release_b="2026-09-30")
    for col in ("only_in_a", "only_in_b", "in_both"):
        ev.add(f"presence_{col}", f"Facility IDs ({col}) between {P} and 2026-09-30", fp[col],
               table="facility_presence.csv", selector={"release_a": P, "release_b": "2026-09-30"}, column=col,
               unit="facilities", scope="cross-release")

    # Examples
    ex = read_json(TABLES / "examples.json")
    exp = rel(TABLES / "examples.json")
    th = ex["top_hospital"]
    ev.items += [
        {"id": "ex_state", "statement": "Lead-example state selected by the prespecified rule", "value": ex["state"],
         "output_path": exp, "selector": {"key": "state"}, "column": "state", "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_n", "statement": "Compatible READM_30_HF hospitals in the lead-example state", "value": ex["n_compatible"],
         "numerator": ex["n_compatible"], "denominator": ex["requested_records"], "output_path": exp,
         "selector": {"key": "n_compatible"}, "column": "n_compatible", "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_requested", "statement": "Requested READM_30_HF records in the lead-example state",
         "value": ex["requested_records"], "output_path": exp, "selector": {"key": "requested_records"},
         "column": "requested_records", "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_top", "statement": "Point-estimate first-ranked hospital in the lead example", "value": th,
         "output_path": exp, "selector": {"key": "top_hospital"}, "column": "top_hospital", "scope": f"release {P}",
         "run_id": ev.run["run_id"]},
        {"id": "ex_pairs", "statement": "Pairs in the lead example", "value": ex["state_pairs"], "output_path": exp,
         "selector": {"key": "state_pairs"}, "column": "state_pairs", "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_pass", "statement": "Passing example (Amendment 1 fallback when applicable)",
         "value": {k: v for k, v in ex["passing_pair"].items() if k != "gate_decisions"},
         "output_path": exp, "selector": {"key": "passing_pair"}, "column": "passing_pair", "scope": f"release {P}",
         "run_id": ev.run["run_id"]},
        {"id": "ex_pass_names", "statement": "Passing-example hospitals as named in the CMS file",
         "value": {g["facility_id"]: {"name": g["facility_name"], "type": g["hospital_type"],
                                      "category": g["compared_to_national_src"]} for g in ex["passing_pair"]["gate_decisions"]},
         "output_path": exp, "selector": {"key": "passing_pair.gate_decisions"}, "column": "facility_name",
         "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_tie", "statement": "Lead-example selection: median count, states tied at it, and the position used",
         "value": {"median_count": ex.get("median_count"), "tied": ex.get("states_tied_at_median_count", []),
                   "position": ex.get("selection_position"), "eligible": len(ex.get("eligible_states", []))},
         "output_path": exp, "selector": {"key": "states_tied_at_median_count"}, "column": "state",
         "scope": f"release {P}", "run_id": ev.run["run_id"]},
        {"id": "ex_attempts", "statement": "Separated pairs found when applying the passing rule in order",
         "value": ex["passing_pair_attempts"], "output_path": exp, "selector": {"key": "passing_pair_attempts"},
         "column": "separated_pairs", "scope": f"release {P}", "run_id": ev.run["run_id"]},
    ]

    # The state an alphabetical tie-break at the median count would have selected
    tied = sorted(ex.get("states_tied_at_median_count", []))
    if tied:
        ps = ev.table("pair_summary_by_state.csv")
        for m in ("READM_30_HF", "MORT_30_HF"):
            r = ps[(ps["subset"] == "primary") & (ps["release_key"] == P) & (ps["measure_id"] == m)
                   & (ps["state"] == tied[0])].iloc[0]
            ev.add(f"alt_ex_{short[m]}_point_ordered", f"{m} point-ordered pairs in {tied[0]}, the alphabetically first "
                   "state tied at the median count", int(r["point_ordered_pairs"]), table="pair_summary_by_state.csv",
                   selector={"subset": "primary", "release_key": P, "measure_id": m, "state": tied[0]},
                   column="point_ordered_pairs", unit="pairs")
            ev.add(f"alt_ex_{short[m]}_sep", f"{m} R1-separated pairs in {tied[0]}", int(r["sep_r1_count"]),
                   table="pair_summary_by_state.csv",
                   selector={"subset": "primary", "release_key": P, "measure_id": m, "state": tied[0]},
                   column="sep_r1_count", unit="pairs")

    # Validation
    vr = read_json(OUTPUTS / "validation" / "validation_report.json")
    vpath = rel(OUTPUTS / "validation" / "validation_report.json")
    for i, c in enumerate(vr["checks"]):
        ev.items.append({"id": f"val_{i:02d}", "statement": c["check"], "value": c["passed"], "detail": c["detail"],
                         "kind": c["kind"], "output_path": vpath, "selector": {"index": i}, "column": "passed",
                         "run_id": ev.run["run_id"]})
    recon = ev.table("reconciliation_categories.csv")
    nat = recon[(recon["release_key"] == P) & (recon["geography"] == "NATION")]
    ev.add("recon_cells", "National category cells compared in the primary release", len(nat),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "NATION"}, column="difference",
           unit="cells")
    ev.add("recon_equal", "National category cells where hospital rows equal the CMS count", int((nat["difference"] == 0).sum()),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "NATION"}, column="difference",
           numerator=int((nat["difference"] == 0).sum()), denominator=len(nat), unit="cells")
    ev.add("recon_max_gap", "Largest national category gap (CMS count minus hospital rows)",
           int((-nat["difference"]).max()), table="reconciliation_categories.csv",
           selector={"release_key": P, "geography": "NATION"}, column="difference", unit="hospitals")
    for m, s in short.items():
        gap = int((-nat.loc[nat["measure_id"] == m, "difference"]).sum())
        ev.add(f"recon_gap_{s}", f"{m}: CMS national count minus hospital rows, summed over categories", gap,
               table="reconciliation_categories.csv", selector={"release_key": P, "geography": "NATION", "measure_id": m},
               column="difference", unit="hospitals")
    fr = ev.table("failure_reasons.csv")
    fn19 = fr[(fr["release_key"] == P) & (fr["reason_code"] == "not_eligible_program")]
    for m, s in short.items():
        ev.add(f"fn19_{s}", f"{m}: records withheld under footnote 19 in the primary release",
               int(fn19.loc[fn19["measure_id"] == m, "records"].sum()), table="failure_reasons.csv",
               selector={"release_key": P, "measure_id": m, "reason_code": "not_eligible_program"}, column="records",
               unit="records")
    ev.add("recon_never_more", "Cells where hospital rows exceed the CMS national count", int((nat["difference"] > 0).sum()),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "NATION"}, column="difference",
           unit="cells")
    st = recon[(recon["release_key"] == P) & (recon["geography"] != "NATION") & recon["cms_aggregate"].notna()]
    ev.add("recon_state_cells", "State category cells with a published CMS count in the primary release", len(st),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "state codes"},
           column="cms_aggregate", unit="cells")
    ev.add("recon_state_equal", "State category cells where hospital rows equal the CMS count", int((st["difference"] == 0).sum()),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "state codes"},
           column="difference", numerator=int((st["difference"] == 0).sum()), denominator=len(st), unit="cells")
    ev.add("recon_state_never_more", "State cells where hospital rows exceed the CMS count", int((st["difference"] > 0).sum()),
           table="reconciliation_categories.csv", selector={"release_key": P, "geography": "state codes"},
           column="difference", unit="cells")
    vsum = vr["summary"]
    for k in ("checks", "passed", "records", "skipped", "entries"):
        ev.items.append({"id": f"val_summary_{k}", "statement": f"Validation summary: {k}", "value": vsum.get(k),
                         "output_path": vpath, "selector": {"key": f"summary.{k}"}, "column": k, "run_id": ev.run["run_id"]})
    rec = ev.table("raw_reconstruction.csv")
    ev.add("recon_raw_records", "Records reconstructed from raw CSV bytes", len(rec), table="raw_reconstruction.csv",
           selector={}, column="record_id", unit="records")
    ev.add("recon_raw_fields", "Fields compared per reconstructed record", int(rec["fields_compared"].iloc[0]),
           table="raw_reconstruction.csv", selector={}, column="fields_compared", unit="fields")
    ev.add("recon_raw_matched", "Reconstructed records matching on every field", int(rec["matched"].sum()),
           table="raw_reconstruction.csv", selector={}, column="matched", unit="records")
    hand = ROOT / "outputs" / "verification" / "hand_check.csv"
    if hand.exists():
        hc = pd.read_csv(hand, dtype=str).fillna("")
        ev.items.append({"id": "hand_records", "statement": "Reconstructed records listed for the author's hand check",
                         "value": int((hc["check_type"] == "raw_record").sum()), "output_path": rel(hand),
                         "selector": {"check_type": "raw_record"}, "column": "record_id", "run_id": ev.run["run_id"]})
        ev.items.append({"id": "hand_completed", "statement": "Hand-check rows completed by the author",
                         "value": int((hc["author_result"] != "").sum()), "output_path": rel(hand),
                         "selector": {"author_result": "non-empty"}, "column": "author_result", "run_id": ev.run["run_id"]})

    # Run 1 (before Amendment 2) for transparency
    arch = OUTPUTS / "archive" / "run1_before_amendment2" / "tables" / "pair_summary_national.csv"
    if arch.exists():
        a = pd.read_csv(arch, dtype={"release_key": str})
        for m in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
            r = a[(a["subset"] == "primary") & (a["release_key"] == P) & (a["measure_id"] == m)].iloc[0]
            ev.items.append({"id": f"run1_{short[m]}_not_sep", "statement": f"{m} not-separated share in run 1, before Amendment 2",
                             "value": float(r["not_separated_r1_share"]), "numerator": int(r["not_separated_r1_count"]),
                             "denominator": int(r["point_ordered_pairs"]), "output_path": rel(arch),
                             "selector": {"subset": "primary", "release_key": P, "measure_id": m},
                             "column": "not_separated_r1_share", "run_id": "run 1 (archived)"})
        hl = pd.read_csv(arch.parent / "hospital_level_summary.csv", dtype={"release_key": str})
        for m in ("READM_30_HF", "MORT_30_HF", "EDAC_30_HF"):
            r = hl[(hl["subset"] == "primary") & (hl["release_key"] == P) & (hl["measure_id"] == m)].iloc[0]
            ev.items.append({"id": f"run1_{short[m]}_hosp_share_separated_from_none",
                             "statement": f"{m} share of hospitals separated from no peer in run 1, before Amendment 2",
                             "value": float(r["share_separated_from_none"]),
                             "numerator": int(r["hospitals_separated_from_none"]),
                             "denominator": int(r["hospitals_with_point_ordered_comparisons"]),
                             "output_path": rel(arch.parent / "hospital_level_summary.csv"),
                             "selector": {"subset": "primary", "release_key": P, "measure_id": m},
                             "column": "share_separated_from_none", "run_id": "run 1 (archived)"})
    out = {"generated_utc": utc_now(), "run_id": ev.run["run_id"], "primary_release": P,
           "plan_sha256": ev.run["plan_sha256"], "config_sha256": ev.run["config_sha256"],
           "source_sha256": ev.run["source_sha256"], "claims": ev.items}
    write_json(CLAIMS, out)
    return out


def values() -> dict:
    """Flat id -> value map for templates."""
    data = read_json(CLAIMS)
    return {c["id"]: c["value"] for c in data["claims"]}


if __name__ == "__main__":
    print(len(build()["claims"]), "claims written")
