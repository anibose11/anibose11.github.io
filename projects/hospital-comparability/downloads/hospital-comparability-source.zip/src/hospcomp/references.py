"""Reference list and additional-file list for the manuscript.

Citations are written in the template as cite("key"). Numbers are assigned in
order of first citation (Vancouver), and the list is printed in that order.
Additional files are numbered the same way through af("key").
"""

from __future__ import annotations

import re

ACCESSED = "cited 2026 Oct 7"


def _ds(title: str, dataset_id: str, released: str) -> str:
    """Vancouver entry for a CMS Provider Data Catalog dataset."""
    return (f"Centers for Medicare & Medicaid Services. {title}, dataset {dataset_id}, released {released} "
            "[dataset on the Internet]. Baltimore (MD): Centers for Medicare & Medicaid Services; 2026 "
            f"[{ACCESSED}]. Available from: https://data.cms.gov/provider-data/dataset/{dataset_id}")


REFERENCES = {
    "cms_pdc": "Centers for Medicare & Medicaid Services. Provider Data Catalog: hospitals [Internet]. Baltimore (MD): "
               f"Centers for Medicare & Medicaid Services; 2026 [{ACCESSED}]. Available from: "
               "https://data.cms.gov/provider-data/topics/hospitals",
    "cms_dict": "Centers for Medicare & Medicaid Services. Hospital downloadable database data dictionary [Internet]. "
                f"Baltimore (MD): Centers for Medicare & Medicaid Services; 2026 Jul [{ACCESSED}]. Available from: "
                "https://data.cms.gov/provider-data/sites/default/files/data_dictionaries/hospital/HOSPITAL_Data_Dictionary.pdf",
    "goldstein1996": "Goldstein H, Spiegelhalter DJ. League tables and their limitations: statistical issues in "
                     "comparisons of institutional performance. J R Stat Soc Ser A Stat Soc. 1996;159(3):385-443. "
                     "doi:10.2307/2983325",
    "marshall1998": "Marshall EC, Spiegelhalter DJ. Reliability of league tables of in vitro fertilisation clinics: "
                    "retrospective analysis of live birth rates. BMJ. 1998;316(7146):1701-4. doi:10.1136/bmj.316.7146.1701",
    "davidson2007": "Davidson G, Moscovice I, Remus D. Hospital size, uncertainty, and pay-for-performance. "
                    "Health Care Financ Rev. 2007;29(1):45-57.",
    "silber2010": "Silber JH, Rosenbaum PR, Brachet TJ, Ross RN, Bressler LJ, Even-Shoshan O, et al. The Hospital "
                  "Compare mortality model and the volume-outcome relationship. Health Serv Res. 2010;45(5 Pt 1):1148-67. "
                  "doi:10.1111/j.1475-6773.2010.01130.x",
    "bernheim2010": "Bernheim SM, Grady JN, Lin Z, Wang Y, Wang Y, Savage SV, et al. National patterns of risk-standardized "
                    "mortality and readmission for acute myocardial infarction and heart failure. Update on publicly "
                    "reported outcomes measures based on the 2010 release. Circ Cardiovasc Qual Outcomes. "
                    "2010;3(5):459-67. doi:10.1161/CIRCOUTCOMES.110.957613",
    "thompson2016": "Thompson MP, Kaplan CM, Cao Y, Bazzoli GJ, Waters TM. Reliability of 30-day readmission measures "
                    "used in the Hospital Readmission Reduction Program. Health Serv Res. 2016;51(6):2095-114. "
                    "doi:10.1111/1475-6773.12587",
    "glance2021": "Glance LG, Nerenz DR, Joynt Maddox KE, Hall BL, Dick AW. Reproducibility of hospital rankings based on "
                  "Centers for Medicare & Medicaid Services Hospital Compare measures as a function of measure reliability. "
                  "JAMA Netw Open. 2021;4(12):e2137647. doi:10.1001/jamanetworkopen.2021.37647",
    "ash2012": "Ash AS, Fienberg SE, Louis TA, Normand SLT, Stukel TA, Utts J. Statistical issues in assessing hospital "
               "performance [Internet]. Commissioned by the Committee of Presidents of Statistical Societies. Baltimore "
               f"(MD): Centers for Medicare & Medicaid Services; 2012 [{ACCESSED}]. Available from: "
               "https://www.cms.gov/Medicare/Quality-Initiatives-Patient-Assessment-Instruments/HospitalQualityInits/"
               "Downloads/Statistical-Issues-in-Assessing-Hospital-Performance.pdf",
    "klein2020": "Klein M, Wright T, Wieczorek J. A joint confidence region for an overall ranking of populations. "
                 "J R Stat Soc Ser C Appl Stat. 2020;69(3):589-606. doi:10.1111/rssc.12402",
    "mogstad2024": "Mogstad M, Romano JP, Shaikh AM, Wilhelm D. Inference for ranks with applications to mobility across "
                   "neighbourhoods and academic achievement across countries. Rev Econ Stud. 2024;91(1):476-518. "
                   "doi:10.1093/restud/rdad006",
    "spiegelhalter2005": "Spiegelhalter DJ. Funnel plots for comparing institutional performance. Stat Med. "
                         "2005;24(8):1185-202. doi:10.1002/sim.1970",
    "lingsma2010": "Lingsma HF, Steyerberg EW, Eijkemans MJ, Dippel DW, Scholte Op Reimer WJ, Van Houwelingen HC. "
                   "Comparing and ranking hospitals based on outcome: results from The Netherlands Stroke Survey. QJM. "
                   "2010;103(2):99-108. doi:10.1093/qjmed/hcp169",
    "vandishoeck2011": "van Dishoeck AM, Lingsma HF, Mackenbach JP, Steyerberg EW. Random variation and rankability of "
                       "hospitals using outcome indicators. BMJ Qual Saf. 2011;20(10):869-74. doi:10.1136/bmjqs.2010.048058",
    "glance2017": "Glance LG, Li Y, Dick AW. Impact on hospital ranking of basing readmission measures on a composite "
                  "endpoint of death or readmission versus readmissions alone. BMC Health Serv Res. 2017;17(1):327. "
                  "doi:10.1186/s12913-017-2266-4",
    "horwitz2018": "Horwitz LI, Wang Y, Altaf FK, Wang C, Lin Z, Liu S, et al. Hospital characteristics associated with "
                   "postdischarge hospital readmission, observation, and emergency department utilization. Med Care. "
                   "2018;56(4):281-9. doi:10.1097/MLR.0000000000000882",
    "wadhera2021": "Wadhera RK, Joynt Maddox KE, Desai NR, Landon BE, Vaduganathan M, Gilstrap LG, et al. Evaluation of "
                   "hospital performance using the excess days in acute care measure in the Hospital Readmissions "
                   "Reduction Program. Ann Intern Med. 2021;174(1):86-92. doi:10.7326/M20-3486",
    "ds_archive_0513": "Centers for Medicare & Medicaid Services. Hospitals data archive, snapshot of 2026 May 13 "
                       "(hospitals_2026-05-13.zip) [dataset on the Internet]. Baltimore (MD): Centers for Medicare & "
                       f"Medicaid Services; 2026 [{ACCESSED}]. Available from: https://data.cms.gov/provider-data/sites/"
                       "default/files/dataset-archives/theme/hospitals/hospitals_2026-05-13.zip",
    "ds_archive_0813": "Centers for Medicare & Medicaid Services. Hospitals data archive, release of 2026 Aug 13 "
                       "(hospitals_2026-08-13.zip) [dataset on the Internet]. Baltimore (MD): Centers for Medicare & "
                       f"Medicaid Services; 2026 [{ACCESSED}]. Available from: https://data.cms.gov/provider-data/sites/"
                       "default/files/dataset-archives/theme/hospitals/hospitals_2026-08-13.zip",
    "ds_uhv": "Centers for Medicare & Medicaid Services. Unplanned Hospital Visits - Hospital, dataset 632h-zaca, "
              "released 2026 Sep 30 [dataset on the Internet]. Baltimore (MD): Centers for Medicare & Medicaid Services; "
              f"2026 [{ACCESSED}]. Available from: https://data.cms.gov/provider-data/dataset/632h-zaca",
    "ds_cd": "Centers for Medicare & Medicaid Services. Complications and Deaths - Hospital, dataset ynj2-r877, released "
             "2026 Sep 30 [dataset on the Internet]. Baltimore (MD): Centers for Medicare & Medicaid Services; 2026 "
             f"[{ACCESSED}]. Available from: https://data.cms.gov/provider-data/dataset/ynj2-r877",
    "ds_gi": _ds("Hospital General Information", "xubh-q36u", "2026 Aug 13"),
    "ds_fn": _ds("Footnote Crosswalk", "y9us-9xdf", "2026 Aug 13"),
    "ds_md": _ds("Measure Dates", "4j6d-yzce", "2026 Aug 13"),
    "ds_hrrp": _ds("Hospital Readmissions Reduction Program", "9n3s-kdb3", "2026 Aug 13"),
    "ds_uhv_nat": _ds("Unplanned Hospital Visits - National", "cvcs-xecj", "2026 Sep 30"),
    "ds_cd_nat": _ds("Complications and Deaths - National", "qqw3-t4ie", "2026 Sep 30"),
    "ds_uhv_state": _ds("Unplanned Hospital Visits - State", "4gkm-5ypv", "2026 Sep 30"),
    "ds_cd_state": _ds("Complications and Deaths - State", "bs2r-24vh", "2026 Sep 30"),
    "cbmfaq2026": "Centers for Medicare & Medicaid Services. Frequently asked questions for publicly reported "
                  "claims-based outcome measures: Summer 2026 public reporting [Internet]. Baltimore (MD): Centers for "
                  f"Medicare & Medicaid Services; 2026 [{ACCESSED}]. Available from: "
                  "https://qualitynet.cms.gov/files/69c59e5d4110de9e75d8df9e?filename=2026_CBM_FAQ.pdf",
    "cms_archive_page": "Centers for Medicare & Medicaid Services. Provider Data Catalog archived data: hospitals "
                        f"[Internet]. Baltimore (MD): Centers for Medicare & Medicaid Services; 2026 [{ACCESSED}]. "
                        "Available from: https://data.cms.gov/provider-data/archived-data/hospitals",
    "notice2026": "Centers for Medicare & Medicaid Services, Inpatient and Outpatient Healthcare Quality Systems "
                  "Development and Program Support. Data suppression for national compare values and confidence "
                  "intervals. Listserve 2026-89-IP [Internet]. Tampa (FL): Quality Reporting Center; 2026 Sep 18 "
                  f"[{ACCESSED}]. Available from: https://www.qualityreportingcenter.com/globalassets/listserves/2026/"
                  "iqr/2026-89-ip-508.pdf",
    "csr2025": "Yale New Haven Health Services Corporation, Center for Outcomes Research and Evaluation. 2025 "
               "condition-specific readmission measures updates and specifications report [Internet]. Baltimore (MD): "
               f"Centers for Medicare & Medicaid Services; 2025 Apr [{ACCESSED}]. Available from: "
               "https://qualitynet.cms.gov/files/6a0b7d2db58870567d25f40b?filename=2025_Rdmsn_MeasureMethodology.zip",
    "csr2026": "Yale New Haven Health Services Corporation, Center for Outcomes Research and Evaluation. 2026 "
               "condition-specific readmission measures updates and specifications report [Internet]. Baltimore (MD): "
               f"Centers for Medicare & Medicaid Services; 2026 Apr [{ACCESSED}]. Available from: "
               "https://qualitynet.cms.gov/files/6a03778f0bc8b455c239e213?filename=2026_CSR_AUS_Report.pdf_v2.0",
    "csm2025": "Yale New Haven Health Services Corporation, Center for Outcomes Research and Evaluation. 2025 "
               "condition-specific mortality measures updates and specifications report [Internet]. Baltimore (MD): "
               f"Centers for Medicare & Medicaid Services; 2025 [{ACCESSED}]. Available from: "
               "https://qualitynet.cms.gov/files/67ff9f8575ffca0f7fb8d062?filename=2025_CSM_AUS_Report_v1.0.pdf",
    "edac2025": "Yale New Haven Health Services Corporation, Center for Outcomes Research and Evaluation. 2025 "
                "condition-specific excess days in acute care measures updates and specifications report [Internet]. "
                f"Baltimore (MD): Centers for Medicare & Medicaid Services; 2025 [{ACCESSED}]. Available from: "
                "https://qualitynet.cms.gov/files/6826495a662c6b68b52c49ba?filename=2025_EDAC_AUS_Report_.pdf",
    "krumholz2006": "Krumholz HM, Wang Y, Mattera JA, Wang Y, Han LF, Ingber MJ, et al. An administrative claims model "
                    "suitable for profiling hospital performance based on 30-day mortality rates among patients with "
                    "heart failure. Circulation. 2006;113(13):1693-701. doi:10.1161/CIRCULATIONAHA.105.611194",
    "keenan2008": "Keenan PS, Normand SL, Lin Z, Drye EE, Bhat KR, Ross JS, et al. An administrative claims measure "
                  "suitable for profiling hospital performance on the basis of 30-day all-cause readmission rates among "
                  "patients with heart failure. Circ Cardiovasc Qual Outcomes. 2008;1(1):29-37. "
                  "doi:10.1161/CIRCOUTCOMES.108.802686",
    "schenker2001": "Schenker N, Gentleman JF. On judging the significance of differences by examining the overlap "
                    "between confidence intervals. Am Stat. 2001;55(3):182-6. doi:10.1198/000313001317097960",
    "fr2025": "Centers for Medicare & Medicaid Services. Medicare program; hospital inpatient prospective payment systems "
              "for acute care hospitals (IPPS) and the long-term care hospital prospective payment system and policy "
              "changes and fiscal year (FY) 2026 rates; changes to the FY 2025 IPPS rates due to court decision; "
              "requirements for quality programs; and other policy changes; health data, technology, and "
              "interoperability: electronic prescribing, real-time prescription benefit and electronic prior "
              "authorization. Final rules. Fed Regist. 2025 Aug 4;90(147):36536-37308. FR Doc. 2025-14681 [Internet]. "
              f"[{ACCESSED}]. Available from: https://www.govinfo.gov/content/pkg/FR-2025-08-04/html/2025-14681.htm",
    "strobe2007": "von Elm E, Altman DG, Egger M, Pocock SJ, Gotzsche PC, Vandenbroucke JP. The Strengthening the "
                  "Reporting of Observational Studies in Epidemiology (STROBE) statement: guidelines for reporting "
                  "observational studies. Lancet. 2007;370(9596):1453-7. doi:10.1016/S0140-6736(07)61602-X",
    "record2015": "Benchimol EI, Smeeth L, Guttmann A, Harron K, Moher D, Petersen I, et al. The REporting of studies "
                  "Conducted using Observational Routinely-collected health Data (RECORD) statement. PLoS Med. "
                  "2015;12(10):e1001885. doi:10.1371/journal.pmed.1001885",
    "wright2019": "Wright T, Klein M, Wieczorek J. A primer on visualizations for comparing populations, including the "
                  "issue of overlapping confidence intervals. Am Stat. 2019;73(2):165-78. doi:10.1080/00031305.2017.1392359",
    "austin2022": "Austin PC. The failure of four bootstrap procedures for estimating confidence intervals for "
                  "predicted-to-expected ratios for hospital profiling. BMC Med Res Methodol. 2022;22(1):271. "
                  "doi:10.1186/s12874-022-01739-x",
}

ADDITIONAL_FILES = {
    "plan": "Analysis plan with its dated amendments and notes on the record; the hash-lock history and the text of "
            "the first lock are in docs/ in the source code archive (analysis_plan.md).",
    "evidence": "Output tables, evidence map linking every computed number to its output (each referenced output is "
                "included at its project path), validation report, hand-check record with its item-by-item "
                "re-derivation, and source manifest with dataset identifiers, URLs, retrieval dates and SHA-256 "
                "checksums (hospital-comparability-tables.zip).",
    "supplement": "Supplementary tables S1 to S12 (hospital-comparability-supplement.docx).",
    "workbook": "Review workbook with original fields, gate decisions and source evidence for every primary-release "
                "record and every current heart-failure record (hospital-comparability-review.xlsx).",
    "source": "Source code archive with configuration, SQL, tests, a synthetic demonstration and setup instructions "
              "(hospital-comparability-source.zip).",
    "checklist": "STROBE checklist with applicable RECORD items (strobe_record_checklist.md).",
}


class Citer:
    def __init__(self) -> None:
        self.order: list[str] = []
        self.af_order: list[str] = []

    def _num(self, key: str) -> int:
        if key not in REFERENCES:
            raise KeyError(f"unknown reference key {key}")
        if key not in self.order:
            self.order.append(key)
        return self.order.index(key) + 1

    def cite(self, *keys: str) -> str:
        nums = sorted(self._num(k) for k in keys)
        parts, start, prev = [], nums[0], nums[0]
        for x in nums[1:] + [None]:
            if x is not None and x == prev + 1:
                prev = x
                continue
            parts.append(f"{start}" if start == prev else (f"{start}, {prev}" if prev == start + 1 else f"{start}-{prev}"))
            if x is not None:
                start = prev = x
        return "[" + ", ".join(parts) + "]"

    def af(self, key: str) -> str:
        if key not in ADDITIONAL_FILES:
            raise KeyError(f"unknown additional file {key}")
        if key not in self.af_order:
            self.af_order.append(key)
        return f"Additional file {self.af_order.index(key) + 1}"

    def reference_list(self) -> str:
        unused = [k for k in REFERENCES if k not in self.order]
        if unused:
            raise ValueError(f"references never cited: {unused}")
        return "\n".join(f"{i}. {REFERENCES[k]}" for i, k in enumerate(self.order, start=1))

    def additional_file_list(self, link_prefix: str | None = None) -> str:
        missing = [k for k in ADDITIONAL_FILES if k not in self.af_order]
        if missing:
            raise ValueError(f"additional files never cited: {missing}")
        def entry(k: str) -> str:
            text = ADDITIONAL_FILES[k]
            if link_prefix:
                text = re.sub(r"\(([^()]+)\)\.$", lambda m: f"([{m.group(1)}]({link_prefix}{m.group(1)})).", text)
            return text
        return "\n\n".join(f"Additional file {i}: {entry(k)}" for i, k in enumerate(self.af_order, start=1))
