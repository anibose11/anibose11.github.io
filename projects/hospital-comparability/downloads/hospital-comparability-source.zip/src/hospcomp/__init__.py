"""Release-aware comparability checks for CMS hospital outcome measures."""

__version__ = "1.0.0"
