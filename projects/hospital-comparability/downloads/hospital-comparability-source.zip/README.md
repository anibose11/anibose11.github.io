# hospcomp: release-aware comparability checks for CMS hospital outcome measures

`hospcomp` checks whether a proposed comparison of public CMS hospital outcome measures is supported by compatible releases, definitions, populations, observation windows, valid numbers and published interval estimates. For the records that pass, it reports which same-state pairwise orderings the published intervals separate and gives each hospital an interval-compatible rank range.

It is written for quality-improvement and health-services analysts. It does not rate or recommend hospitals.

## Study and results

The study applied the tool to heart-failure and acute myocardial infarction 30-day measures in three CMS Provider Data Catalog releases (2026-05-13 archive, 2026-08-13 archive, 2026-09-30 current files).

- In the current files, 3,253 hospitals have a heart-failure readmission rate and none has a usable interval, following a CMS suppression notice.
- In the primary release (2026-05-13), 2,975 of 4,792 requested heart-failure readmission records passed every gate, and 99.6% of 141,219 point-ordered same-state pairs were not separated by the published intervals (97.0% for mortality, 62.0% for excess days in acute care).
- All six study Measure IDs changed definition between releases; the readmission window went from 36 to 24 months.

`hospcomp render` writes the full report from `manuscript/manuscript.md.j2` to `manuscript/manuscript.md`, with supplementary tables in `manuscript/supplement.md`. Every computed result in them maps to an output in `evidence/claims.json`.

## Requirements

- Python 3.12 or later (tested with 3.13.5 on macOS 27, arm64)
- About 1.3 GB of free disk for a full run: about 175 MB of cached CMS files, about 520 MB for `data/interim/hospcomp.sqlite` and about 550 MB for the second database that `validate` builds to check the rerun
- Network access to data.cms.gov for `acquire` (not needed for the tests or the demo)
- Optional: R 4.x for the second implementation in `scripts/crosscheck_pairs.R`; without R that check is skipped and reported as skipped

No database server, cloud service, API key or paid software is needed. SQL runs in SQLite through Python's standard library.

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock -e .
```

## Quick checks

```bash
.venv/bin/python -m pytest -q
.venv/bin/hospcomp demo
```

The fixture tests and the demo use only the synthetic fixture in `tests/fixtures/demo/`. Fixture rows are named `SYNTHETIC HOSPITAL ...` and use the fictional state codes ZZ and ZY. Two workbook tests also compare the review workbook with the study outputs when those files are present, and are skipped otherwise.

## Full pipeline

```bash
.venv/bin/hospcomp acquire     # current files from the CMS metastore and the official archive releases, with checks
.venv/bin/hospcomp build       # parse every release into data/interim/hospcomp.sqlite with integrity checks
.venv/bin/hospcomp analyze     # gates, pairs, rank ranges, sensitivity analyses (refuses to run if the plan lock does not match)
.venv/bin/hospcomp validate    # data checks, reconciliation, raw reconstruction, optional R cross-check, full rerun comparison
.venv/bin/hospcomp render      # figures, review workbook, manuscript, supplement, project page
.venv/bin/hospcomp package     # source archive, handoff files, outer bundle
```

`hospcomp all` runs the same stages in order. `acquire` compares every downloaded file with the SHA-256 checksum pinned in `source_manifest.json` and stops if CMS now serves a different file or a newer release; `hospcomp acquire --force` accepts new current files, after which results will differ from the study. The archived releases are fetched first and must always match their checksums, so they remain retrievable after CMS publishes a newer release; the current files used in the study then have to come from another copy that matches the recorded checksums. Later stages check every file against the manifest before use.

QualityNet methodology PDFs are served through a JavaScript application and cannot be fetched by the script. They are cited in the report; local copies can be saved from a browser to the paths listed under `browser_documents` in `config/study.toml`. The pipeline does not need them to run; the document items of the hand-check re-derivation do.

The hand-check list in `outputs/verification/hand_check.csv` can be re-derived item by item from the raw files, the saved documents and `evidence/claims.json`; `--network` adds the reference checks against Crossref, PubMed and the cited pages:

```bash
.venv/bin/python scripts/recheck_hand_items.py --network
```

## Validator commands

```bash
.venv/bin/hospcomp compare --measure READM_30_HF --state AZ
.venv/bin/hospcomp compare --measure READM_30_HF --state AZ --release 2026-09-30
.venv/bin/hospcomp check-request --measure-a READM_30_HF --measure-b READM-30-HF-HRRP
.venv/bin/hospcomp check-request --measure-a READM_30_HF --release-a 2026-05-13 --measure-b READM_30_HF --release-b 2026-09-30
.venv/bin/hospcomp check-pair --measure MORT_30_HF --facility-a 030006 --facility-b 030119
```

`compare` lists compatible hospitals with their published intervals and rank ranges, and every record that was not compared with its gate and reason. `check-request` refuses comparisons across different measures, units, windows or documented definition changes. `check-pair` gives the gate and separation decisions for two hospitals.

## Layout

| Path | Contents |
|---|---|
| `config/` | study settings, measure dictionary, release status, population exclusions |
| `src/hospcomp/` | pipeline and command-line code |
| `sql/` | schema, gates, pairs, rank ranges and the separate VA comparison |
| `scripts/` | fixture generator, R cross-check, hand-check re-derivation and bundle verifier |
| `tests/` | unit, fixture and command-line tests |
| `docs/` | analysis plan, its lock history and the text of the first lock, contribution decision, prior art, data dictionary, Tableau specification |
| `outputs/tables/` | analysis tables (CSV), reference values and prespecified examples |
| `outputs/validation/` | validation report, reconciliation, raw reconstruction, rerun comparison |
| `outputs/verification/` | test, visual-check and hand-check records, with the item-by-item re-derivation of the hand checks |
| `outputs/figures/` | figures (PNG and SVG) |
| `evidence/claims.json` | every computed number with its output path, selector, denominator, scope and run ID |
| `manuscript/` | report template and supplementary tables |
| `source_manifest.json` | resolved URLs, release dates, file versions, sizes and SHA-256 of every source file |

## Interpreting the outputs

- A pair is separated when one hospital's published upper limit is below the other's lower limit. Overlap does not show equivalent performance, and separation is not a formal significance test.
- Rank ranges come from the published marginal 95% intervals. They carry no probability and are not simultaneous confidence sets.
- CMS's "Compared to National" categories are kept as source information and are not recomputed.
- Mortality, readmission and excess days are never combined.

## License and data

Code: MIT (see `LICENSE`). Data: CMS Provider Data Catalog files are U.S. federal government data published for public use; this project asserts no license over them (see `NOTICE.md`). Cite the software with `CITATION.cff`.
