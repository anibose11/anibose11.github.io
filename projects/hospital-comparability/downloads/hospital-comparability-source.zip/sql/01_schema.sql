-- Schema for the frozen study database (SQLite).
-- Every parsed field sits next to the exact source string it came from, and
-- every table that depends on a release carries release_key.

DROP TABLE IF EXISTS releases;
CREATE TABLE releases (
    release_key     TEXT PRIMARY KEY,
    source          TEXT NOT NULL,          -- live | archive
    role            TEXT NOT NULL,          -- primary | flagged | current
    label           TEXT NOT NULL,
    interval_status TEXT NOT NULL,          -- published | flagged_by_cms_notice | suppressed_by_cms_notice
    status_note     TEXT,
    notice          TEXT,
    notice_url      TEXT
);

DROP TABLE IF EXISTS source_files;
CREATE TABLE source_files (
    release_key        TEXT NOT NULL,
    dataset_key        TEXT NOT NULL,
    dataset_id         TEXT NOT NULL,
    title              TEXT NOT NULL,
    released           TEXT,
    modified           TEXT,
    file_version       TEXT,
    download_url       TEXT NOT NULL,
    sha256             TEXT NOT NULL,
    data_rows          INTEGER NOT NULL,
    PRIMARY KEY (release_key, dataset_key)
);

DROP TABLE IF EXISTS footnote_dictionary;
CREATE TABLE footnote_dictionary (
    release_key        TEXT NOT NULL,
    code               TEXT NOT NULL,
    footnote_text      TEXT NOT NULL,
    study_class        TEXT NOT NULL,      -- availability | window_blocking | caution | informational
    availability_state TEXT,
    PRIMARY KEY (release_key, code)
);

DROP TABLE IF EXISTS measure_dictionary;
CREATE TABLE measure_dictionary (
    measure_id          TEXT PRIMARY KEY,
    dataset_key         TEXT NOT NULL,
    condition           TEXT NOT NULL,
    endpoint            TEXT NOT NULL,
    quantity            TEXT NOT NULL,
    unit                TEXT NOT NULL,
    favorable           TEXT NOT NULL CHECK (favorable IN ('lower', 'higher')),
    lower_bound         REAL NOT NULL,
    upper_bound         REAL NOT NULL,
    study_role          TEXT NOT NULL,
    doc_source          TEXT
);

DROP TABLE IF EXISTS measure_windows;
CREATE TABLE measure_windows (
    release_key         TEXT NOT NULL,
    measure_id          TEXT NOT NULL,
    source_measure_name TEXT,
    n_source_names      INTEGER,
    official_name       TEXT,
    official_start      TEXT,
    official_end        TEXT,
    modal_start         TEXT,
    modal_end           TEXT,
    window_months       INTEGER,
    reported_decimals   INTEGER,
    n_window_variants   INTEGER,
    PRIMARY KEY (release_key, measure_id)
);

DROP TABLE IF EXISTS definition_changes;
CREATE TABLE definition_changes (
    measure_id    TEXT NOT NULL,
    from_release  TEXT NOT NULL,
    to_release    TEXT NOT NULL,
    change        TEXT NOT NULL,
    source        TEXT NOT NULL,
    source_url    TEXT NOT NULL
);

DROP TABLE IF EXISTS hospitals;
CREATE TABLE hospitals (
    release_key        TEXT NOT NULL,
    facility_id        TEXT NOT NULL,
    facility_id_src    TEXT NOT NULL,
    facility_name      TEXT,
    state              TEXT,
    hospital_type      TEXT,
    ownership          TEXT,
    emergency_services TEXT,
    PRIMARY KEY (release_key, facility_id)
);

DROP TABLE IF EXISTS records;
CREATE TABLE records (
    record_id               TEXT PRIMARY KEY,   -- release_key|dataset_key|facility_id|measure_id
    release_key             TEXT NOT NULL,
    dataset_key             TEXT NOT NULL,
    release_date            TEXT NOT NULL,
    file_version            TEXT,
    source_row              INTEGER NOT NULL,   -- 1-based data row in the raw CSV
    source_row_sha256       TEXT NOT NULL,
    facility_id_src         TEXT NOT NULL,
    facility_id             TEXT NOT NULL,
    facility_id_valid       INTEGER NOT NULL,
    facility_name           TEXT,
    state                   TEXT,
    measure_id              TEXT NOT NULL,
    measure_name_src        TEXT,
    compared_to_national_src TEXT,
    denominator_src         TEXT, denominator_num REAL, denominator_state TEXT,
    score_src               TEXT, score_num REAL,       score_state TEXT,
    lower_src               TEXT, lower_num REAL,       lower_state TEXT,
    upper_src               TEXT, upper_num REAL,       upper_state TEXT,
    score_decimals          INTEGER,
    lower_decimals          INTEGER,
    upper_decimals          INTEGER,
    footnote_src            TEXT,
    footnote_codes          TEXT,               -- normalized, comma separated, sorted
    start_date_src          TEXT, start_date TEXT,
    end_date_src            TEXT, end_date TEXT,
    availability_state      TEXT NOT NULL,
    hospital_type           TEXT,
    in_general_info         INTEGER NOT NULL
);
CREATE INDEX idx_records_release_measure_state ON records (release_key, measure_id, state);
CREATE INDEX idx_records_key ON records (release_key, dataset_key, facility_id, measure_id);

DROP TABLE IF EXISTS record_footnotes;
CREATE TABLE record_footnotes (
    record_id TEXT NOT NULL,
    code      TEXT NOT NULL,
    PRIMARY KEY (record_id, code)
);

-- Hospital types whose results for a measure are documented by CMS as computed
-- from a different patient population or data source (gate G2b). Filled from
-- config/population_exclusions.csv; empty when no such documentation exists.
DROP TABLE IF EXISTS population_exclusions;
CREATE TABLE population_exclusions (
    measure_id    TEXT NOT NULL,
    hospital_type TEXT NOT NULL,
    reason        TEXT NOT NULL,
    source        TEXT NOT NULL,
    PRIMARY KEY (measure_id, hospital_type)
);

DROP TABLE IF EXISTS hrrp_records;
CREATE TABLE hrrp_records (
    record_id            TEXT PRIMARY KEY,
    release_key          TEXT NOT NULL,
    source_row           INTEGER NOT NULL,
    facility_id          TEXT NOT NULL,
    state                TEXT,
    measure_id           TEXT NOT NULL,
    err_src TEXT, err_num REAL,
    predicted_src TEXT, predicted_num REAL,
    expected_src TEXT, expected_num REAL,
    discharges_src TEXT, discharges_num REAL,
    readmissions_src TEXT, readmissions_num REAL,
    footnote_src TEXT,
    start_date TEXT, end_date TEXT
);

DROP TABLE IF EXISTS national_reference;
CREATE TABLE national_reference (
    release_key   TEXT NOT NULL,
    dataset_key   TEXT NOT NULL,
    geography     TEXT NOT NULL,           -- 'NATION' or a state code
    measure_id    TEXT NOT NULL,
    n_worse       TEXT, n_same TEXT, n_better TEXT, n_too_few TEXT,
    n_fewer       TEXT, n_average TEXT, n_more TEXT, n_too_small TEXT,
    national_rate TEXT,
    footnote      TEXT,
    start_date    TEXT, end_date TEXT,
    PRIMARY KEY (release_key, dataset_key, geography, measure_id)
);
