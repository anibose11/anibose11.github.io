-- Record-level applicability and comparability gates (G0 to G6).
-- Gates are evaluated independently; the first failing gate in the fixed order
-- G0, G1, G2, G2b, G3, G4, G5, G6 determines the reported reason.
-- G0 is a release-level gate taken from documented CMS release status.

DROP TABLE IF EXISTS gate_results;
CREATE TABLE gate_results AS
WITH base AS (
    SELECT
        r.record_id, r.release_key, r.dataset_key, r.release_date, rl.interval_status, r.facility_id, r.facility_name, r.state,
        r.measure_id, r.hospital_type, r.availability_state, r.compared_to_national_src,
        r.score_src, r.lower_src, r.upper_src, r.footnote_src, r.start_date, r.end_date,
        r.score_num, r.lower_num, r.upper_num, r.score_state, r.lower_state, r.upper_state,
        r.denominator_src, r.denominator_num,
        r.facility_id_valid,
        w.n_source_names, w.official_start, w.official_end, m.lower_bound, m.upper_bound,
        m.favorable, w.reported_decimals, m.study_role,
        EXISTS (SELECT 1 FROM record_footnotes f JOIN footnote_dictionary d
                  ON d.code = f.code AND d.release_key = r.release_key
                WHERE f.record_id = r.record_id AND d.study_class = 'window_blocking') AS fn_window,
        EXISTS (SELECT 1 FROM record_footnotes f JOIN footnote_dictionary d
                  ON d.code = f.code AND d.release_key = r.release_key
                WHERE f.record_id = r.record_id AND d.study_class = 'availability') AS fn_blocking,
        EXISTS (SELECT 1 FROM record_footnotes f JOIN footnote_dictionary d
                  ON d.code = f.code AND d.release_key = r.release_key
                WHERE f.record_id = r.record_id AND d.study_class = 'caution') AS fn_caution,
        EXISTS (SELECT 1 FROM population_exclusions p
                WHERE p.measure_id = r.measure_id AND p.hospital_type = r.hospital_type) AS pop_excluded,
        (SELECT COUNT(*) FROM records r2
          WHERE r2.release_key = r.release_key AND r2.dataset_key = r.dataset_key
            AND r2.facility_id = r.facility_id AND r2.measure_id = r.measure_id) AS key_count
    FROM records r
    JOIN measure_dictionary m
      ON m.measure_id = r.measure_id AND m.dataset_key = r.dataset_key
    JOIN measure_windows w
      ON w.release_key = r.release_key AND w.measure_id = r.measure_id
    JOIN releases rl
      ON rl.release_key = r.release_key
    WHERE m.study_role IN ('primary', 'supporting', 'secondary')
),
g AS (
    SELECT base.*,
        CASE WHEN interval_status = 'published' THEN 1 ELSE 0 END AS g0_release,
        CASE WHEN facility_id_valid = 1 AND key_count = 1 THEN 1 ELSE 0 END AS g1_identity,
        CASE WHEN n_source_names = 1 THEN 1 ELSE 0 END AS g2_definition,
        CASE WHEN pop_excluded THEN 0 ELSE 1 END AS g2b_population,
        CASE WHEN start_date = official_start AND end_date = official_end AND NOT fn_window
             THEN 1 ELSE 0 END AS g3_window,
        CASE WHEN score_state = 'numeric' THEN 1 ELSE 0 END AS g4_score,
        CASE WHEN score_state = 'numeric' AND lower_state = 'numeric' AND upper_state = 'numeric'
              AND lower_num <= score_num AND score_num <= upper_num AND lower_num < upper_num
              AND lower_num >= lower_bound AND upper_num <= upper_bound
             THEN 1 ELSE 0 END AS g5_interval,
        CASE WHEN fn_blocking THEN 0 ELSE 1 END AS g6_footnote
    FROM base
)
SELECT
    record_id, release_key, dataset_key, release_date, interval_status, facility_id, facility_name, state, measure_id, study_role,
    hospital_type, availability_state, compared_to_national_src,
    score_src, lower_src, upper_src, denominator_src, footnote_src, start_date, end_date,
    score_num, lower_num, upper_num, denominator_num, favorable, reported_decimals,
    g0_release, g1_identity, g2_definition, g2b_population, g3_window, g4_score, g5_interval, g6_footnote,
    CASE
        WHEN g0_release = 0 THEN 'G0'
        WHEN g1_identity = 0 THEN 'G1'
        WHEN g2_definition = 0 THEN 'G2'
        WHEN g2b_population = 0 THEN 'G2b'
        WHEN g3_window = 0 THEN 'G3'
        WHEN g4_score = 0 THEN 'G4'
        WHEN g5_interval = 0 THEN 'G5'
        WHEN g6_footnote = 0 THEN 'G6'
        ELSE NULL
    END AS first_failed_gate,
    CASE
        WHEN g0_release = 0 AND interval_status = 'flagged_by_cms_notice' THEN 'release_intervals_flagged_by_cms'
        WHEN g0_release = 0 AND interval_status = 'suppressed_by_cms_notice' THEN 'release_intervals_suppressed_by_cms'
        WHEN g0_release = 0 THEN 'release_not_usable'
        WHEN g1_identity = 0 THEN 'invalid_or_duplicate_identifier'
        WHEN g2_definition = 0 THEN 'measure_definition_ambiguous'
        WHEN g2b_population = 0 THEN 'population_or_data_source_differs'
        WHEN g3_window = 0 AND fn_window THEN 'partial_or_short_period_footnote'
        WHEN g3_window = 0 THEN 'observation_window_mismatch'
        WHEN g4_score = 0 THEN availability_state
        WHEN g5_interval = 0 AND (lower_state <> 'numeric' OR upper_state <> 'numeric') THEN 'interval_limit_missing'
        WHEN g5_interval = 0 AND lower_num > upper_num THEN 'interval_reversed'
        WHEN g5_interval = 0 AND lower_num = upper_num THEN 'interval_zero_width'
        WHEN g5_interval = 0 AND (score_num < lower_num OR score_num > upper_num) THEN 'score_outside_interval'
        WHEN g5_interval = 0 THEN 'interval_out_of_bounds'
        WHEN g6_footnote = 0 THEN 'blocking_footnote_on_numeric_record'
        ELSE 'compatible'
    END AS reason_code,
    CASE WHEN g0_release AND g1_identity AND g2_definition AND g2b_population AND g3_window AND g4_score
              AND g5_interval AND g6_footnote THEN 1 ELSE 0 END AS compatible,
    CAST(fn_caution AS INTEGER) AS caution_flag
FROM g;

CREATE INDEX idx_gate_release_measure_state ON gate_results (release_key, measure_id, state);
