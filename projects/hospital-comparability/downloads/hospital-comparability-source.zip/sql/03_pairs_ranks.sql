-- Pairwise interval separation and interval-compatible rank ranges.
-- All comparisons use integers scaled by 10^reported_decimals so that the
-- rounding-robust rule (R2) is not distorted by binary floating point.
-- Values are oriented so that a smaller oriented value is always more favorable.

DROP VIEW IF EXISTS compat_oriented;
CREATE VIEW compat_oriented AS
SELECT
    g.record_id, g.release_key, g.measure_id, g.state, g.facility_id, g.facility_name, g.hospital_type,
    g.compared_to_national_src, g.caution_flag, g.favorable, g.reported_decimals,
    g.score_num, g.lower_num, g.upper_num, g.denominator_num,
    CAST(ROUND(g.score_num * power10.scale) AS INTEGER) AS score_i,
    CAST(ROUND(g.lower_num * power10.scale) AS INTEGER) AS lower_i,
    CAST(ROUND(g.upper_num * power10.scale) AS INTEGER) AS upper_i,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.score_num * power10.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.score_num * power10.scale) AS INTEGER) END AS o_s,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.lower_num * power10.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.upper_num * power10.scale) AS INTEGER) END AS o_lo,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.upper_num * power10.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.lower_num * power10.scale) AS INTEGER) END AS o_hi,
    CASE
        WHEN lower(g.compared_to_national_src) LIKE 'better%' THEN 'better'
        WHEN lower(g.compared_to_national_src) LIKE 'fewer days%' THEN 'better'
        WHEN lower(g.compared_to_national_src) LIKE 'worse%' THEN 'worse'
        WHEN lower(g.compared_to_national_src) LIKE 'more days%' THEN 'worse'
        WHEN lower(g.compared_to_national_src) LIKE 'no different%' THEN 'no_different'
        WHEN lower(g.compared_to_national_src) LIKE 'average days%' THEN 'no_different'
        WHEN lower(g.compared_to_national_src) LIKE 'number of cases too small%' THEN 'too_small'
        ELSE 'other'
    END AS official_category
FROM gate_results g
JOIN (SELECT release_key, measure_id,
             CASE reported_decimals WHEN 0 THEN 1 WHEN 1 THEN 10 WHEN 2 THEN 100 WHEN 3 THEN 1000 ELSE 10000 END AS scale
        FROM measure_windows) power10
  ON power10.measure_id = g.measure_id AND power10.release_key = g.release_key
WHERE g.compatible = 1;

DROP TABLE IF EXISTS pairs;
CREATE TABLE pairs AS
SELECT
    a.release_key, a.measure_id, a.state,
    a.facility_id AS facility_a, b.facility_id AS facility_b,
    a.score_num AS score_a, a.lower_num AS lower_a, a.upper_num AS upper_a,
    b.score_num AS score_b, b.lower_num AS lower_b, b.upper_num AS upper_b,
    a.official_category AS category_a, b.official_category AS category_b,
    a.caution_flag AS caution_a, b.caution_flag AS caution_b,
    CASE WHEN a.score_i <> b.score_i THEN 1 ELSE 0 END AS point_ordered,
    -- R1: strict non-overlap of published intervals (touching endpoints are not separated)
    CASE WHEN a.o_hi < b.o_lo OR b.o_hi < a.o_lo THEN 1 ELSE 0 END AS sep_r1,
    -- R2: gap must exceed one unit in the last reported decimal place (scaled unit = 1)
    CASE WHEN (b.o_lo - a.o_hi) > 1 OR (a.o_lo - b.o_hi) > 1 THEN 1 ELSE 0 END AS sep_r2,
    -- R3: each point estimate lies outside the other hospital's interval (lenient)
    CASE WHEN (a.o_s < b.o_lo OR a.o_s > b.o_hi) AND (b.o_s < a.o_lo OR b.o_s > a.o_hi)
         THEN 1 ELSE 0 END AS sep_r3,
    -- Reference only: CMS categories on opposite sides of the national rate
    CASE WHEN (a.official_category = 'better' AND b.official_category = 'worse')
           OR (a.official_category = 'worse' AND b.official_category = 'better')
         THEN 1 ELSE 0 END AS official_opposite,
    MAX(b.o_lo - a.o_hi, a.o_lo - b.o_hi) AS gap_scaled
FROM compat_oriented a
JOIN compat_oriented b
  ON a.release_key = b.release_key AND a.measure_id = b.measure_id AND a.state = b.state
 AND a.facility_id < b.facility_id;

CREATE INDEX idx_pairs_release_measure_state ON pairs (release_key, measure_id, state);

DROP TABLE IF EXISTS rank_ranges;
CREATE TABLE rank_ranges AS
WITH subsets AS (
    SELECT 'primary' AS subset, c.* FROM compat_oriented c
    UNION ALL
    SELECT 'strict' AS subset, c.* FROM compat_oriented c WHERE c.caution_flag = 0
),
sized AS (
    SELECT s.*, COUNT(*) OVER (PARTITION BY subset, release_key, measure_id, state) AS n
    FROM subsets s
)
SELECT
    c.subset, c.release_key, c.measure_id, c.state, c.facility_id, c.facility_name, c.hospital_type,
    c.official_category, c.score_num, c.lower_num, c.upper_num, c.n,
    1 + (SELECT COUNT(*) FROM sized o
          WHERE o.subset = c.subset AND o.release_key = c.release_key AND o.measure_id = c.measure_id AND o.state = c.state
            AND o.o_s < c.o_s) AS point_rank,
    1 + (SELECT COUNT(*) FROM sized o
          WHERE o.subset = c.subset AND o.release_key = c.release_key AND o.measure_id = c.measure_id AND o.state = c.state
            AND o.o_hi < c.o_lo) AS best_rank,
    c.n - (SELECT COUNT(*) FROM sized o
          WHERE o.subset = c.subset AND o.release_key = c.release_key AND o.measure_id = c.measure_id AND o.state = c.state
            AND o.o_lo > c.o_hi) AS worst_rank
FROM sized c;

CREATE INDEX idx_rank_release_measure_state ON rank_ranges (subset, release_key, measure_id, state);
