-- Records excluded from the general comparison by gate G2b (documented cohort
-- or data-source difference) are compared only with records of the same
-- hospital type. This mirrors 03_pairs_ranks.sql for that separate group and
-- uses the R1 rule only; it is a descriptive output reported separately.

DROP VIEW IF EXISTS separate_group_oriented;
CREATE VIEW separate_group_oriented AS
SELECT
    g.release_key, g.measure_id, g.state, g.hospital_type, g.facility_id,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.score_num * p.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.score_num * p.scale) AS INTEGER) END AS o_s,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.lower_num * p.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.upper_num * p.scale) AS INTEGER) END AS o_lo,
    CASE WHEN g.favorable = 'lower' THEN CAST(ROUND(g.upper_num * p.scale) AS INTEGER)
         ELSE -CAST(ROUND(g.lower_num * p.scale) AS INTEGER) END AS o_hi
FROM gate_results g
JOIN (SELECT release_key, measure_id,
             CASE reported_decimals WHEN 0 THEN 1 WHEN 1 THEN 10 WHEN 2 THEN 100 WHEN 3 THEN 1000 ELSE 10000 END AS scale
        FROM measure_windows) p
  ON p.release_key = g.release_key AND p.measure_id = g.measure_id
WHERE g.g2b_population = 0
  AND g.g0_release = 1 AND g.g1_identity = 1 AND g.g2_definition = 1 AND g.g3_window = 1
  AND g.g4_score = 1 AND g.g5_interval = 1 AND g.g6_footnote = 1;

DROP TABLE IF EXISTS separate_group_pairs;
CREATE TABLE separate_group_pairs AS
SELECT a.release_key, a.measure_id, a.state, a.hospital_type,
       a.facility_id AS facility_a, b.facility_id AS facility_b,
       CASE WHEN a.o_s <> b.o_s THEN 1 ELSE 0 END AS point_ordered,
       CASE WHEN a.o_hi < b.o_lo OR b.o_hi < a.o_lo THEN 1 ELSE 0 END AS sep_r1
FROM separate_group_oriented a
JOIN separate_group_oriented b
  ON a.release_key = b.release_key AND a.measure_id = b.measure_id AND a.state = b.state
 AND a.hospital_type = b.hospital_type AND a.facility_id < b.facility_id;
