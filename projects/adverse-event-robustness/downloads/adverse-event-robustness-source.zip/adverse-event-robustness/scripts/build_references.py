"""Build docs/references.json from the verified reference records.

Every journal entry comes from docs/_research/references_verified.json, which records how each item was
checked (PubMed and Crossref metadata, or the live page). The FDA documentation shipped inside the quarterly
archives was read directly from the downloaded files and is added here with its archive location.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V = {r["key"]: r for r in json.loads((ROOT / "docs/_research/references_verified.json").read_text())}

ARTICLES = {
    "faers_essentials": "potter2025_faers_essentials", "vanpuijenbroek2002": "vanpuijenbroek2002_measures",
    "rothman2004": "rothman2004_ror", "janiczak2025": "janiczak2025_duplicate_characteristics",
    "hauben2021": "hauben2021_more_extreme_duplication", "hung2023": "hung2023_literature_reference_duplication",
    "noren2007": "noren2007_duplicate_detection", "tregunno2014": "tregunno2014_vigimatch",
    "kreimeyer2017": "kreimeyer2017_record_linkage", "kreimeyer2025": "kreimeyer2025_network_dedup",
    "wong2015": "wong2015_drugname_standardisation", "banda2016": "banda2016_aeolus",
    "khaleel2022": "khaleel2022_standardized_faers", "fusaroli2024diana": "fusaroli2024_diana",
    "parry2025": "parry2025_aioli", "readuspv2024": "fusaroli2024_readus_statement",
    "khouri2021": "khouri2021_variability", "khouri2021jce": "khouri2021_jce_transparency",
    "martinezcadena2026": "martinezcadena2026_quarterly_persistence", "xu2026": "xu2026_glp1_ps_stratification",
    "fadini2017": "fadini2017_sglt2_dka", "blau2017": "blau2017_sglt2_ketoacidosis", "chen2026": "chen2026_sglt2_dka_faers_jader",
    "bersoffmatcha2019": "bersoffmatcha2019_fournier", "fadini2019": "fadini2019_fournier_faers",
    "bene2016": "bene2016_bp_dpp4_france", "jedlowski2021": "jedlowski2021_bp_dpp4_faers",
    "elashoff2011": "elashoff2011_glp1_pancreatitis", "raschi2013": "raschi2013_pancreatitis_antidiabetics",
    "egan2014": "egan2014_incretin_pancreas", "tarapues2013": "tarapues2013_gliptin_musculoskeletal",
    "men2017": "men2017_dpp4_arthralgia_meta", "munoz2019": "munoz2019_litigation",
    "alkabbani2023": "alkabbani2023_acr_da",
}
WEB = {
    "fda_aems_qde": "fda_aems_qde_files", "januvia_label": "dailymed_januvia_label",
    "farxiga_label": "drugsatfda_farxiga_label_2024", "invokana_label": "dailymed_invokana_label",
    "fda_signals_2016q2": "fda_potential_signals_2016q2",
}


def article(key, vk):
    r = V[vk]
    return {"key": key, "type": "article", "source_key": vk, "authors": [a.strip() for a in r["authors"].split(",")],
            "title": r["title"], "journal": r["journal"], "year": r["year"], "volume": r.get("volume"), "issue": r.get("issue"),
            "pages": r.get("pages"), "doi": r.get("doi"), "pmid": r.get("pmid"), "verified_via": r["verified_via"],
            "accessed": r["accessed"]}


def web(key, vk, org=None):
    r = V[vk]
    return {"key": key, "type": "web", "source_key": vk, "org": org or r["authors"], "title": r["title"],
            "date": r.get("year"), "url": r["url"], "accessed": r["accessed"], "verified_via": r["verified_via"]}


refs = [article(k, v) for k, v in ARTICLES.items()]
refs += [dict(web("fda_aems_qde", "fda_aems_qde_files", "US Food and Drug Administration"),
              title="FDA Adverse Event Monitoring System (AEMS) Quarterly Data Extract Files"),
         web("januvia_label", "dailymed_januvia_label", "Merck Sharp & Dohme LLC"),
         web("farxiga_label", "drugsatfda_farxiga_label_2024", "AstraZeneca"),
         web("invokana_label", "dailymed_invokana_label", "Janssen Pharmaceuticals"),
         web("fda_signals_2016q2", "fda_potential_signals_2016q2", "US Food and Drug Administration")]
ARCH = "distributed in each quarterly ASCII archive"
refs += [
    {"key": "fda_qde_readme", "type": "web", "org": "US Food and Drug Administration",
     "title": "README file for the quarterly data extract (QDE) from the FDA Adverse Event Reporting System (FAERS) (Readme.pdf; last revised February 2022), " + ARCH,
     "date": "2022", "url": "https://fis.fda.gov/content/Exports/faers_ascii_2026q2.zip", "accessed": "2026-10-07",
     "verified_via": "Read from the downloaded archives (all eight releases carry the same revision)."},
    {"key": "fda_asc_nts", "type": "web", "org": "US Food and Drug Administration",
     "title": "ASC_NTS file for the quarterly data extract from the FDA Adverse Event Reporting System (FAERS) (ASC_NTS.pdf; last revised January 2025), " + ARCH,
     "date": "2025", "url": "https://fis.fda.gov/content/Exports/faers_ascii_2026q2.zip", "accessed": "2026-10-07",
     "verified_via": "Read from the downloaded archives; 2024Q3 carries the October 2022 revision."},
    {"key": "fda_qde_faq", "type": "web", "org": "US Food and Drug Administration",
     "title": "Frequently asked questions on the FAERS quarterly data extract (FAQs.pdf; last revised October 2024), items 29, 30, 31 and 44, " + ARCH,
     "date": "2024", "url": "https://fis.fda.gov/content/Exports/faers_ascii_2026q2.zip", "accessed": "2026-10-07",
     "verified_via": "Read from the downloaded archives."},
    {"key": "rxnav", "type": "web", "org": "National Library of Medicine",
     "title": "RxNorm API and RxClass API (RxNav). Data version 05-Oct-2026",
     "date": "2026", "url": "https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html", "accessed": "2026-10-07",
     "verified_via": "Pages returned HTTP 200 with titles 'RxNorm API - APIs' and 'RxClass API - APIs'; responses used in the study are frozen in data/cache/rxnav."},
]
(ROOT / "docs" / "references.json").write_text(json.dumps(refs, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(len(refs), "references written")

# Drug Safety (Adis) reference style: sentence-case article titles (proper nouns and acronyms kept).
STYLE_TITLES = {
    "faers_essentials": "FDA Adverse Event Reporting System (FAERS) essentials: a guide to understanding, applying, and interpreting adverse event data reported to FAERS",
    "janiczak2025": "An evaluation of duplicate adverse event reports characteristics in the Food and Drug Administration Adverse Event Reporting System",
    "kreimeyer2017": "Using probabilistic record linkage of structured and unstructured data to identify duplicate cases in spontaneous adverse event reporting systems",
    "kreimeyer2025": "Deduplicating the FDA Adverse Event Reporting System with a novel application of network-based grouping",
    "khaleel2022": "A standardized dataset of a spontaneous adverse event reporting system",
    "fusaroli2024diana": "Enhancing transparency in defining studied drugs: the open-source living DiAna dictionary for standardizing drug names in the FAERS",
    "parry2025": "Aioli: standardising drugs in the FDA Adverse Event Reporting System (FAERS) to RxNorm and Anatomical Therapeutic Chemical (ATC) codes",
    "readuspv2024": "The reporting of a disproportionality analysis for drug safety signal detection using individual case safety reports in pharmacovigilance (READUS-PV): development and statement",
    "khouri2021": "Leveraging the variability of pharmacovigilance disproportionality analyses to improve signal detection performances",
    "xu2026": "Safety signals of GLP-1 receptor agonists: a multi-method pharmacovigilance analysis of FAERS (2018-2025) with sensitivity-stratified prioritisation, notoriety-bias assessment, and cross-database validation",
    "blau2017": "Ketoacidosis associated with SGLT2 inhibitor treatment: analysis of FAERS data",
    "bersoffmatcha2019": "Fournier gangrene associated with sodium-glucose cotransporter-2 inhibitors: a review of spontaneous postmarketing cases",
    "bene2016": "Bullous pemphigoid and dipeptidyl peptidase IV inhibitors: a case-noncase study in the French Pharmacovigilance Database",
    "jedlowski2021": "DPP-4 inhibitors and increased reporting odds of bullous pemphigoid: a pharmacovigilance study of the FDA Adverse Event Reporting System (FAERS) from 2006 to 2020",
    "egan2014": "Pancreatic safety of incretin-based drugs: FDA and EMA assessment",
    "men2017": "Dipeptidyl peptidase-4 inhibitors and risk of arthralgia: a systematic review and meta-analysis",
    "munoz2019": "The impact of litigation-associated reports on signal identification in the US FDA's Adverse Event Reporting System",
    "alkabbani2023": "Active-comparator restricted disproportionality analysis for pharmacovigilance signal detection studies of chronic disease medications: an example using sodium/glucose cotransporter 2 inhibitors",
    "fda_aems_qde": "FDA Adverse Event Monitoring System (AEMS) quarterly data extract files: ASCII files 2024Q3 to 2026Q2 [dataset]",
    "januvia_label": "Januvia (sitagliptin) tablets: prescribing information. DailyMed SPL set ID f85a48d0-0407-4c50-b0fa-7673a160bf01, version 71",
    "farxiga_label": "Farxiga (dapagliflozin) tablets: prescribing information. Revised 06/2024",
    "invokana_label": "Invokana (canagliflozin) tablets: prescribing information. DailyMed SPL set ID b9057d3b-b104-4f09-8a61-c61ef9d4a3f3, version 32",
    "fda_signals_2016q2": "April-June 2016: new safety information or potential signals of serious risks identified from the FDA Adverse Event Monitoring System (AEMS)",
    "fda_qde_readme": "README file for the quarterly data extract from the FDA Adverse Event Reporting System (FAERS), last revised February 2022 (distributed in each quarterly ASCII archive)",
    "fda_asc_nts": "ASC_NTS file for the quarterly data extract from the FDA Adverse Event Reporting System (FAERS), last revised January 2025 (distributed in each quarterly ASCII archive)",
    "fda_qde_faq": "Frequently asked questions on the FAERS quarterly data extract, last revised October 2024, items 29, 30, 31, and 44 (distributed in each quarterly ASCII archive)",
    "rxnav": "RxNorm and RxClass application programming interfaces (RxNav), data version 05-Oct-2026",
}
ORGS = {"US Food and Drug Administration": "U.S. Food and Drug Administration", "National Library of Medicine": "U.S. National Library of Medicine"}
for r in refs:
    r["title"] = STYLE_TITLES.get(r["key"], r["title"])
    if r["type"] == "web":
        r["org"] = ORGS.get(r["org"], r["org"])
(ROOT / "docs" / "references.json").write_text(json.dumps(refs, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print("Drug Safety title style applied")
