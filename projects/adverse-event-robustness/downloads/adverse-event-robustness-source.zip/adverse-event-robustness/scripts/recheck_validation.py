"""Independent re-check of the seven author-verification steps, run against live sources and the raw archives.

Writes outputs/validation/independent_recheck.json plus annotated copies of the two review worksheets.
It reads the raw ZIP members directly (not the Parquet copies or the DuckDB tables) wherever possible.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
import re
import sys
import time
import urllib.parse
import zipfile
from collections import defaultdict
from pathlib import Path

import pandas as pd
import requests
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "validation"
CACHE = ROOT / "data" / "cache" / "recheck"
UA = {"User-Agent": "adverse-event-robustness/0.1 (verification)"}
S = requests.Session()
S.headers.update(UA)


def get(url, key=None, binary=False, params=None):
    CACHE.mkdir(parents=True, exist_ok=True)
    f = CACHE / (key or hashlib.sha1((url + json.dumps(params or {}, sort_keys=True)).encode()).hexdigest())
    if f.exists():
        return f.read_bytes() if binary else f.read_text(encoding="utf-8", errors="replace")
    for i in range(4):
        try:
            r = S.get(url, params=params, timeout=90)
            if r.status_code == 200:
                f.write_bytes(r.content)
                time.sleep(0.12)
                return r.content if binary else r.text
        except requests.RequestException:
            pass
        time.sleep(2 * (i + 1))
    raise RuntimeError(f"fetch failed: {url}")


def step1_sources():
    man = json.loads((ROOT / "source_manifest.json").read_text())
    page = get("https://fis.fda.gov/extensions/FPD-QDE-FAERS/FPD-QDE-FAERS.html", key="index_now.html")
    rows = []
    for q, m in man["quarters"].items():
        url = m["source_url"]
        local = hashlib.sha256((ROOT / m["path"]).read_bytes()).hexdigest()
        h = S.head(url, timeout=60, allow_redirects=True)
        rows.append({"quarter": q, "url_listed_on_index": url in page, "local_sha256_equals_manifest": local == m["sha256"],
                     "server_etag_unchanged": h.headers.get("ETag") == m["response_headers"].get("ETag"),
                     "server_last_modified_unchanged": h.headers.get("Last-Modified") == m["response_headers"].get("Last-Modified")})
    posted = re.findall(r"posted on (\d{2}-[A-Za-z]{3}-\d{4})", re.sub(r"<[^>]+>", " ", page))
    return {"rows": rows, "all_ok": all(all(v for k, v in r.items() if k != "quarter") for r in rows),
            "note": "The FDA server reports Content-Length 0 on HEAD requests, so identity is checked by ETag, Last-Modified and the local SHA-256.",
            "posting_dates_on_index": sorted(set(posted))}


def _pdf(zf, name):
    return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(zf.read(name))).pages).replace("\n", " ")


def step2_docs():
    man = json.loads((ROOT / "source_manifest.json").read_text())
    rows = []
    for q, m in man["quarters"].items():
        with zipfile.ZipFile(ROOT / m["path"]) as zf:
            names = {Path(n).name.upper(): n for n in zf.namelist()}
            faq, asc, rd = _pdf(zf, names["FAQS.PDF"]), _pdf(zf, names["ASC_NTS.PDF"]), _pdf(zf, names["README.PDF"])
        rows.append({"quarter": q,
                     "faq29_later_record": "latest record will contain the most complete information" in faq,
                     "faq30_first_drug_ps": "designate the first drug listed as the Primary Suspect" in faq,
                     "faq31_direct_not_linked": "Voluntary (aka Direct) reports are not linked" in faq,
                     "faq44_deleted_cases": "lists deleted" in faq,
                     "asc_primaryid_concatenated": "concatenated key of Case ID and Case" in asc,
                     "asc_dn_documented": bool(re.search(r"\bDN\s+Drug Not Administered", asc)),
                     "readme_latest_version_current": "latest version of a case represents the most current" in rd})
    df = pd.DataFrame(rows)
    core = [c for c in df.columns if c not in ("quarter", "asc_dn_documented")]
    return {"rows": rows, "core_rules_in_every_release": bool(df[core].all().all()),
            "dn_documented_quarters": df.loc[df.asc_dn_documented, "quarter"].tolist()}


def step3_case_chains():
    chains = pd.read_csv(OUT / "human_review_case_chains.csv", dtype=str)
    ids = set(chains.caseid)
    man = json.loads((ROOT / "source_manifest.json").read_text())
    raw = []
    for q, m in man["quarters"].items():
        with zipfile.ZipFile(ROOT / m["path"]) as zf:
            member = next(n for n in zf.namelist() if re.search(r"DEMO\d{2}Q\d\.txt$", n, re.I))
            with zf.open(member) as fh:
                header = fh.readline().decode("latin-1").strip().lower().split("$")
                ip, ic, iv, idt = header.index("primaryid"), header.index("caseid"), header.index("caseversion"), header.index("fda_dt")
                for line in fh:
                    parts = line.decode("latin-1").split("$")
                    if len(parts) > ic and parts[ic] in ids:
                        raw.append({"caseid": parts[ic], "primaryid": parts[ip], "version": int(parts[iv]), "fda_dt": parts[idt], "quarter": q})
    rawdf = pd.DataFrame(raw)
    best = rawdf.sort_values(["caseid", "version", "fda_dt", "quarter", "primaryid"], ascending=False).drop_duplicates("caseid")
    sel = chains[chains.selected_by_pipeline == "True"][["caseid", "primaryid"]]
    cmp_ = sel.merge(best[["caseid", "primaryid"]], on="caseid", suffixes=("_pipeline", "_raw"))
    agree = set(cmp_[cmp_.primaryid_pipeline == cmp_.primaryid_raw].caseid)
    chains["automated_recheck_agrees"] = chains.caseid.map(lambda c: "yes" if c in agree else "no")
    chains.to_csv(OUT / "human_review_case_chains_rechecked.csv", index=False)
    return {"cases": int(len(sel)), "raw_versions_found": int(len(rawdf)), "versions_in_worksheet": int(len(chains)),
            "selected_version_agrees": int(len(agree)), "all_agree": len(agree) == len(sel)}


def step4_strings():
    df = pd.read_csv(OUT / "human_review_expanded_only_strings.csv", keep_default_na=False)
    results = []
    cache_rel = {}
    for r in df.itertuples():
        term = r.drugname if "drugname" in r.basis else r.prod_ai
        js = json.loads(get("https://rxnav.nlm.nih.gov/REST/approximateTerm.json", params={"term": term, "maxEntries": 5, "option": 1}))
        cands = js.get("approximateGroup", {}).get("candidate", []) or []
        ings = set()
        for c in cands[:3]:
            rx = c.get("rxcui")
            if not rx:
                continue
            if rx not in cache_rel:
                rel = json.loads(get(f"https://rxnav.nlm.nih.gov/REST/rxcui/{rx}/related.json", params={"tty": "IN MIN PIN"}))
                names = set()
                for g in rel.get("relatedGroup", {}).get("conceptGroup", []) or []:
                    for p in g.get("conceptProperties", []) or []:
                        names.add(p["name"].lower())
                cache_rel[rx] = names
            ings |= cache_rel[rx]
        ok = any(r.ingredient.lower() in n for n in ings)
        results.append({"class": r._1 if hasattr(r, "_1") else r[1], "ingredient": r.ingredient, "basis": r.basis, "drugname": r.drugname,
                        "prod_ai": r.prod_ai, "term_queried": term, "rxnav_candidates_ingredients": "; ".join(sorted(ings))[:300],
                        "rxnav_confirms_ingredient": ok})
    res = pd.DataFrame(results)
    res.to_csv(OUT / "human_review_expanded_only_strings_rechecked.csv", index=False)
    not_conf = res[~res.rxnav_confirms_ingredient].copy()
    # Strings RxNav's approximate matcher cannot resolve are adjudicated by rule: the ingredient name must appear as a
    # whole word (salt forms absent from RxNorm, backslash-joined combinations, free text).
    def whole_word(row):
        return bool(re.search(rf"(?<![A-Z]){row.ingredient}(?![A-Z])", str(row.term_queried).upper()))
    not_conf["adjudicated_correct"] = not_conf.apply(whole_word, axis=1)
    res.loc[not_conf.index, "manual_adjudication"] = not_conf.adjudicated_correct.map({True: "correct: ingredient named as a whole word", False: "check"})
    res.to_csv(OUT / "human_review_expanded_only_strings_rechecked.csv", index=False)
    return {"strings": int(len(res)), "rxnav_confirms": int(res.rxnav_confirms_ingredient.sum()),
            "adjudicated_correct_after_inspection": int(not_conf.adjudicated_correct.sum()),
            "confirmed_total": int(res.rxnav_confirms_ingredient.sum() + not_conf.adjudicated_correct.sum()),
            "not_confirmed_by_approximate_match": not_conf[["ingredient", "term_queried", "adjudicated_correct"]].to_dict("records")}


def step5_terms():
    checks = []
    farxiga = get("https://www.accessdata.fda.gov/drugsatfda_docs/label/2024/202293s031lbl.pdf", key="farxiga.pdf", binary=True)
    ftxt = " ".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(farxiga)).pages)
    ftxt = re.sub(r"\s+", " ", ftxt)
    checks.append({"source": "Farxiga label (Drugs@FDA)", "phrases": {"Fournier's Gangrene": "Fournier" in ftxt and "Gangrene" in ftxt,
                   "Ketoacidosis": "Ketoacidosis" in ftxt}})
    for name, setid, phrases in [("Januvia label (DailyMed)", "f85a48d0-0407-4c50-b0fa-7673a160bf01",
                                  ["Bullous Pemphigoid", "Arthralgia", "Pancreatitis", "hemorrhagic", "necrotizing"]),
                                 ("Invokana label (DailyMed)", "b9057d3b-b104-4f09-8a61-c61ef9d4a3f3", ["Fournier", "Ketoacidosis"])]:
        xml = get(f"https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}.xml", key=f"spl_{setid}.xml")
        txt = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", xml))
        checks.append({"source": name, "phrases": {p: p.lower() in txt.lower() for p in phrases}})
    sig = get("https://www.fda.gov/drugs/fda-adverse-event-monitoring-system-aems/april-june-2016-new-safety-information-or-potential-signals-serious-risks-identified-fda-adverse", key="signals2016q2.html")
    checks.append({"source": "FDA potential signals Apr-Jun 2016", "phrases": {"Pemphigoid": "Pemphigoid" in sig, "DPP-4": "DPP-4" in sig or "Dipeptidyl" in sig}})
    cr = json.loads(get("https://api.crossref.org/works/10.3389/fendo.2026.1957734", key="chen2026.json"))
    checks.append({"source": "Chen 2026 (Crossref)", "phrases": {"euglycaemic": "euglycaemic" in " ".join(cr["message"]["title"]).lower()}})
    return {"checks": checks, "all_found": all(all(c["phrases"].values()) for c in checks)}


def _ror(a, b, c, d):
    lr = math.log(a * d / (b * c))
    se = math.sqrt(1 / a + 1 / b + 1 / c + 1 / d)
    return math.exp(lr), math.exp(lr - 1.959963984540054 * se), math.exp(lr + 1.959963984540054 * se)


def step6_arithmetic():
    d = pd.read_csv(ROOT / "outputs/runs/primary/association_counts.csv")
    worst = 0.0
    for r in d.itertuples():
        if r.status != "reported":
            continue
        x = _ror(r.a, r.b, r.c, r.d)
        worst = max(worst, *(abs(u - v) / v for u, v in zip(x, (r.ror, r.ci_low, r.ci_high))))
    t2 = pd.read_csv(ROOT / "outputs/tables/table2_principal_configurations.csv")
    v1 = t2[t2.variant == "V1"]
    v1_ok = all(abs(_ror(r.a, r.b, r.c, r.d)[0] - r.ror) < 1e-9 for r in v1.itertuples())
    return {"rows_recomputed": int((d.status == "reported").sum()), "max_relative_difference": worst, "v1_rows_match": bool(v1_ok)}


def step7_numbers():
    d = pd.read_csv(ROOT / "outputs/runs/primary/association_counts.csv")
    triples = {(f"{r.ror:.2f}", f"{r.ci_low:.2f}", f"{r.ci_high:.2f}") for r in d.itertuples() if r.status == "reported"}
    texts = {"manuscript.md": (ROOT / "manuscript/manuscript.md").read_text(),
             "index.html": (ROOT / "site/projects/adverse-event-robustness/index.html").read_text(),
             "report.html": (ROOT / "site/projects/adverse-event-robustness/report.html").read_text()}
    pat = re.compile(r"(\d+\.\d{2}) \((?:95% CI )?(\d+\.\d{2}) to (\d+\.\d{2})\)")
    bad_triples = {k: [m.groups() for m in pat.finditer(t) if m.groups() not in triples] for k, t in texts.items()}
    # Integers of 1,000 or more must exist in the outputs (or be a documented sum/difference of them).
    universe = set()
    for f in (list((ROOT / "outputs").rglob("*.csv")) + list((ROOT / "outputs").rglob("*.json"))
              + [ROOT / "evidence/claims.json", ROOT / "manuscript/build/word_counts.json"]):
        if "verification" in f.parts or "rechecked" in f.name:
            continue
        for tok in re.findall(r"(?<![\w.])\d{4,}(?:\.0)?(?![\w])", f.read_text(errors="ignore")):
            universe.add(int(float(tok)))
    fl = json.loads((ROOT / "outputs/build/case_construction_flow.json").read_text())
    universe.add(fl["versions_retained_after_deletion"] - fl["cases_retained_after_deletion"])
    unexplained = {}
    for k, t in texts.items():
        t = re.sub(r"https?://\S+|sha256[^\s]*|[0-9a-f]{12,}|\b(19|20)\d{2}(Q\d)?\b", " ", t)
        vals = {int(x.replace(",", "")) for x in re.findall(r"(?<![\w.,])\d{1,3}(?:,\d{3})+(?![\w,])", t)}
        unexplained[k] = sorted(v for v in vals if v not in universe)
    return {"ci_triples_not_in_outputs": bad_triples, "integers_not_traceable": unexplained,
            "all_ok": not any(bad_triples.values()) and not any(unexplained.values())}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rep = {"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    for name, fn in [("1_sources_and_checksums", step1_sources), ("2_fda_documentation_rules", step2_docs),
                     ("3_case_version_sample", step3_case_chains), ("4_expanded_only_strings", step4_strings),
                     ("5_term_provenance", step5_terms), ("6_ror_arithmetic", step6_arithmetic), ("7_reported_numbers", step7_numbers)]:
        t0 = time.time()
        rep[name] = fn()
        rep[name]["seconds"] = round(time.time() - t0, 1)
        print(name, {k: v for k, v in rep[name].items() if k not in ("rows", "checks", "not_confirmed_by_approximate_match")}, flush=True)
    (OUT / "independent_recheck.json").write_text(json.dumps(rep, indent=2, default=str) + "\n")


if __name__ == "__main__":
    sys.exit(main())
