# Contribution decision

Written 2026-10-07 before any association count was computed. Updated later only to add verified references (see the change note at the end).

## Who would use the output

Analysts who build or audit disproportionality pipelines on the FDA quarterly extract files: pharmacovigilance scientists in industry and regulatory settings, academic groups publishing FAERS-based case/non-case studies, and reviewers of such manuscripts who need to know whether a reported ROR would survive a different, equally defensible processing choice.

## Decision it supports

Whether a pipeline's choices of counting unit, drug role, and ingredient matching need to be fixed and reported in detail (because the estimate moves materially when they change), or whether a given association is insensitive to them in current files. It also supports a narrower practical decision: which processing choices to include as sensitivity analyses in a FAERS-based study, in line with READUS-PV reporting.

## Narrow unresolved question

Prior work has examined single processing steps in isolation: duplicate reports and their characteristics, extreme duplication, probabilistic duplicate detection, and drug-name standardization dictionaries. Published disproportionality studies usually describe one deduplication rule and one drug-identification rule without showing what happens to the two-by-two table under the alternatives. The question left open for the current files is: for a fixed set of previously communicated associations, how much do the ROR and its underlying cells change across a small factorial of routine choices (case versus report-version counting, primary versus any suspect role, exact ingredient versus verified expanded mapping), and which specific units move between cells when they do?

This is framed as a processing-sensitivity study and a reusable, configuration-driven tool. It is not a claim to be the first to show that processing matters, and it does not seek new safety signals.

## Comparator

The primary configuration (latest available case version, primary or secondary suspect, RxNav-verified expanded mapping, deletion lists applied) is compared with each single-factor alternative. Report-version counting is a diagnostic comparator, not an equally valid analysis. Secondary analyses change one element each: deletion lists, receipt-date cohort, an active comparator (SGLT2 inhibitors versus DPP-4 inhibitors), and background composition.

## Estimand

For each prespecified association and configuration: the ROR (Woolf 95% interval) computed over all retained units in the eight-quarter extract, together with the cells a, b, c, d. The study-level quantity is the spread of the ROR across the four case-level configurations (minimum, maximum, max/min ratio, direction agreement) and the cell-level decomposition of that spread. These are properties of reporting data under processing rules, not incidence, risk, or causal effects.

## What would count as a useful negative result

If all five associations have RORs within a narrow band (for example a max/min ratio near 1) across the case-level configurations, that is evidence that, for these classes and current files, the three processing choices are low-stakes and a pipeline can document them briefly. If the report-version comparator inflates counts without changing the ROR, that shows version counting distorts case totals more than the ratio. Both are useful and would be reported as such. A large shift for one association and not others would also be reported, with the cells that explain it, and not generalized beyond these classes.

## Framing given the prior work

- Duplicate characteristics and detection are established topics (FDA and academic work); this project does not propose a duplicate-detection method and does not resolve cross-case duplicates.
- Drug-name standardization tools for FAERS exist (manual recoding, open dictionaries, RxNorm/ATC mappings); this project uses RxNav directly for a narrow, auditable mapping of ten ingredients and compares it with exact ingredient matching.
- The incremental value is the side-by-side, cell-level comparison of routine choices for known associations in the 2024Q3 to 2026Q2 files, including a schema change inside the window (the DN role code), with a tool that reruns the comparison on other quarters or associations by editing configuration files.

## Change note

2026-10-07, after the verified literature search and before the discussion was written: no change to the question, comparator, estimand, or configurations. The search confirmed the framing. Two FAERS studies already used a primary versus secondary suspect contrast as a sensitivity analysis (Martínez-Cadena 2026; Xu 2026), a VigiBase study showed that analytic choices can turn signals on and off (Khouri 2021), curated datasets implement latest-version deduplication and RxNorm mapping without quantifying their effect (Banda 2016; Khaleel 2022), and the DiAna authors suggested comparing disproportionality results across drug-name strategies (Fusaroli 2024). The contribution is therefore stated as an update and a measured, cell-level comparison of these choices on fixed labeled pairs in current files, with a reusable tool, not as a first demonstration that processing matters.
