Mapping to the numbered READUS-PV items (Fusaroli et al., Drug Safety 2024;47:575–584; doi:10.1007/s40264-024-01421-9). Grouped item numbers cover all main-text and abstract recommendations. Locations refer to this manuscript; partial coverage and inapplicable clinical assessments are identified explicitly.

| READUS-PV item | Where addressed or applicability |
|---|---|
| 1a–b | Title. The title identifies disproportionality, the FDA quarterly files, both drug classes and the study period; the five reactions are listed in the Abstract. |
| 2a–c | Rationale. Sections 1 and 4.2 explain the processing problem and prior evidence. Section 2.5 gives the fixed event definitions and their labeling sources. This is a methods study, not an estimate of event frequency in treated patients. |
| 3 | Objective. Abstract Objective and the final paragraph of Section 1; the database-wide background is defined in Section 2.6. |
| 4a–b | Design. Sections 2.1–2.7 describe the factorial disproportionality analysis, the primary configuration and four secondary analyses. The plan and amendments are in ESM 1. |
| 5a | Data and terminology. Sections 2.2, 2.4 and 2.5 identify FDA, the quarterly files, RxNorm/RxClass and the exact MedDRA preferred-term strings. ESM 2 Tables S1 and S3 document release compatibility and terms. Section 4.4 explains the lack of a fixed MedDRA hierarchy/version across quarters. |
| 5b | Preprocessing. Sections 2.2–2.4, Table 1 and Fig. 1 describe retrieval, exclusions, case versions, deletion lists and matching. Source dates and checksums are in ESM 3. |
| 6a–d | Variables. Sections 2.2–2.7 define the report population, exposure, events, roles, matching and comparison groups, and explain how frozen RxNav responses inform drug identification. ESM 2 Tables S3–S5 give the exact terms and names. |
| 7a | Descriptive analyses. Section 2.7 identifies the post hoc profiles of moved units; Section 3.4 and ESM 2 Table S7 report drug/reaction counts and reporter characteristics. No demographic subgroup or hypothesis test was added. |
| 7b | Measure and thresholds. Section 2.6 defines the ROR, Woolf 95% interval and minimum-cell rules. Section 2.7 compares estimates and interval limits with 1 descriptively; no new safety-signal discovery threshold is claimed. |
| 7c | Sensitivity analyses. Section 2.7, Tables 2–4 and Sections 3.3–3.5. The active-comparator analysis changes the background; no confounder-adjusted causal estimate is reported. |
| 7d–e | Other analyses. No clinical case-by-case causality assessment was performed. The author’s raw-record and mapping checks in Section 2.9 verify processing. RxNav supplies names and class membership, not a separate statistical sample. |
| 8a | Report flow. Section 3.1, Table 1 and Fig. 1 give the report/version/case counts and exclusions. |
| 8b | Case characteristics. Section 3.4 and ESM 2 Table S7 describe moved report groups and reporter characteristics. Age, sex and detailed clinical profiles were not analyzed; this reporting item is only partly addressed. |
| 9 | Estimates. Tables 2 and 4 report every principal and secondary estimate with its four cells and interval; Fig. 2 shows the principal configurations. Table 3 summarizes case-level robustness. |
| 10 | Clinical case assessment. Not performed. No patient-level causal adjudication or new clinical safety-signal assessment is claimed; see Sections 2.9 and 4.4. |
| 11 | Interpretation. Sections 4.1–4.2 distinguish processing sensitivity in fixed, previously communicated pairs from discovery. The arthralgia analysis uses a broader term than severe, disabling joint pain in the label. |
| 12a–c | Applicability. Sections 4.3–4.4 and 5 limit the conclusions to report processing and five pairs. They do not establish patient risk or treatment recommendations. Extension to other windows and event definitions requires further study. |
| 13 | Limitations. Section 4.4 describes reporting and indication biases, incomplete case histories, unresolved duplicates, term coverage and the lack of causal or incidence interpretation. |
| 14a–c | Declarations. Funding, Conflicts of Interest, Ethics approval and consent statements identify internal resources, ownership of Norlowe Research and the use of public de-identified data. |
| 14d | Reproducibility. Sections 2.1 and 2.8–2.10; Data and Code availability; ESM 1 and ESM 3. The plan was internal and not registered; software versions, source manifests and reusable code are supplied. |
| Abstract 1a–c | Aim and setting. Introduction, Objective and Methods identify the FDA reporting database, five class–reaction pairs and the processing-sensitivity question. |
| Abstract 2a–e | Methods. Methods describes public quarterly files, period and configurations; Objective names the ROR and Results gives 95% intervals. The analysis does not claim a discovery threshold or clinical case-by-case assessment. |
| Abstract 3 | Findings. Results reports retained cases, principal estimates, intervals and the processing effects. No clinical case assessment was performed. |
| Abstract 4a–c | Conclusion. Conclusions recommends reporting/testing processing rules and explicitly distinguishes reporting estimates from risk. The inference concerns methods, not treatment choices. |
