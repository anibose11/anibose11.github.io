# Tableau import and interaction specification

No Tableau workbook was built or tested. This specification describes how to build one from the verified export.

## Source

`outputs/tableau/association_configurations_long.csv` (also in the public downloads). Text CSV, UTF-8, header row, comma-delimited.

## Grain

One row per prespecified association (5) and analysis (8 principal configurations V1 to V8, 4 secondary analyses S1 to S4): 60 rows. Rows are not additive across associations or configurations, because the same reports appear in several rows.

## Fields

| Field | Type | Meaning |
|---|---|---|
| association, association_label | dimension | Drug class and reaction pair |
| variant, variant_label, analysis | dimension | Configuration identifier and description; principal or secondary |
| unit | dimension | case (patient-level unit) or version (diagnostic) |
| role, mapping | dimension | suspect or ps; strict or expanded |
| a, b, c, d, n | measure (count of reports) | Two-by-two cells and total units; see the workbook Definitions sheet |
| exposed_units | measure | a + b |
| event_share_exposed | measure (proportion) | a / (a + b) |
| ror, ci_low, ci_high | measure (ratio, unitless) | Reporting odds ratio and Woolf 95% interval; blank when status is not "reported" |
| status | dimension | reported; not_computed_zero_cell; not_evaluated_low_support |
| is_primary_configuration, is_diagnostic_unit | boolean | V1 flag; report-version flag |
| suppressed | boolean | Always false: all values are aggregate counts of public reports |
| s3_comparator_class, s3_excluded_both_classes | dimension / measure | Only for S3 |

## Permitted interactions

- Filter by association and by analysis. Highlight V1 and shade V5 to V8 as diagnostic.
- Plot ror with ci_low and ci_high on a logarithmic axis, one panel per association.
- Show a, b, c, d in the tooltip for every mark.

## Not permitted

- Do not SUM or AVERAGE ror, ci_low, or ci_high across rows, and do not recompute ROR from aggregated cells across associations or configurations.
- Do not sum a, b, c, d across associations or configurations.
- Do not label any value as risk, incidence, or a drug ranking.
