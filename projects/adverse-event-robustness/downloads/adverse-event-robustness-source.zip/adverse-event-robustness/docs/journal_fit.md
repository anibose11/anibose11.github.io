# Journal fit

All facts below were checked on the publishers' pages on 2026-10-07. Nothing here predicts editorial interest, acceptance, or impact.

## 1. Drug Safety (Springer Nature / Adis; official journal of the International Society of Pharmacovigilance): chosen target

- **Scope and article type.** Publishes original research in pharmacovigilance and pharmacoepidemiology. The Original Research Article type explicitly covers disproportionality analyses of individual case safety report databases and asks authors to follow READUS-PV. Up to about 6000 words (guide), excluding abstract, references, legends and captions; no limit on tables, figures or references.
- **Front matter.** Structured abstract of 150 to 250 words (up to 450 when a reporting guideline needs it); two or three Key Points; running head up to 100 characters; title page with affiliations, corresponding author email, and ORCID where available.
- **Declarations** (headed section before the references; "Not applicable" where relevant). The journal's additional-information PDF lists: Funding; Conflicts of Interest; Availability of data and material; Ethics approval; Consent to participate; Consent for publication; Code availability; Author contributions. The PDF prints "Consent for publication" twice; the first is taken as "Consent to participate" (to confirm with the editorial office).
- **AI policy.** Use of a large language model should be documented in the Methods section; AI cannot be an author; AI-assisted copy editing needs no statement. ICMJE, which the journal endorses, also asks for a statement in the cover letter.
- **Reporting.** READUS-PV checklist encouraged; a study flowchart is required (Fig. 1 here).
- **Data and code.** Data availability statement mandatory; code availability has its own heading.
- **Charges.** Hybrid journal. Subscription publication has no charge. Open access charge GBP 3190 / USD 5190 / EUR 3990 plus VAT, CC BY-NC licence; the choice is made after acceptance.
- **Closest published comparisons in this journal.** Janiczak et al. 2025 (duplicate report characteristics in FAERS); Fusaroli et al. 2024 (DiAna drug-name dictionary); Kreimeyer et al. 2017 (probabilistic duplicate detection); the READUS-PV statement (2024).
- **Fit.** Good: the journal publishes FAERS data-processing methods papers and explicitly addresses disproportionality reporting. The manuscript is formatted for this journal.

## 2. Pharmacoepidemiology and Drug Safety (Wiley; official journal of ISPE): alternative

- **Scope.** The ISPE journal page lists data assembly and processing, computerised dictionaries, and methods for detecting adverse events among its areas, which matches this study well.
- **Not verified.** The Wiley author-guidelines page was behind an automated human-verification check and could not be read, so word limits, abstract format, Key Points count, and declaration headings are unconfirmed. Published PDS original articles use Purpose/Methods/Results/Conclusions abstracts and Key Points; treat these as examples only.
- **AI policy (Wiley, verified).** AI cannot be an author; drafting or editing help is disclosed in the Acknowledgments; AI use in methods, code, or data pipelines is disclosed in Methods.
- **Charges.** Hybrid; subscription route without charge; open access charge USD 5120 / GBP 3620 / EUR 4400 (Wiley price list updated 2 September 2026).
- **Closest published comparisons.** Parry et al. 2025 (Aioli: FAERS drugs to RxNorm and ATC); Hung et al. 2023 and Hauben et al. 2021 (extreme duplication); Wong et al. 2015 (manual recoding of drug names).

## 3. Remaining scientific objections a reviewer may raise

1. Five pairs in two classes cannot show how often processing changes conclusions in general.
2. Exact preferred-term strings without the MedDRA hierarchy may undercount events.
3. No probabilistic deduplication across CASEIDs; the long multi-drug reports were described but not deduplicated.
4. The descriptive profiles explaining the role and mapping effects are post hoc.
5. The arthralgia term is broad; the labeled warning concerns severe, disabling joint pain.
6. Single author; the author verification is not independent external review.

## 4. Not claimed

No deadline, acceptance likelihood, impact factor, reviewer interest, or editorial decision is stated or implied. The repository has no public development history, so eligibility for venues such as JOSS that require one has not been assessed and is not claimed.
