# Adverse-event reporting odds ratios under alternative case definitions

A reproducible processing-sensitivity study of the FDA quarterly adverse event data extract files (FAERS, now listed on FDA's Adverse Event Monitoring System pages). For five prespecified SGLT2 and DPP-4 inhibitor reaction pairs, it measures how reporting odds ratios change across eight case-construction, drug-role, and drug-name configurations, and which cells of the two-by-two table move.

The estimates are reporting associations in spontaneous reports. They are not risks, incidence, causal effects, or a ranking of drugs.

## Requirements

- Python 3.11 or later (tested with 3.13 on macOS arm64)
- About 3 GB of free disk for the full study (measured: 530 MB of archives, 235 MB of column-limited Parquet, 1.6 GB DuckDB working database)
- 8 GB of memory is enough for the SQL pipeline (peak about 3 GB); the pandas cross-check in `validate` peaked at 11 to 14 GB in the recorded runs
- Network access to fis.fda.gov for `acquire`; RxNav responses are frozen in `data/cache/rxnav/` and reused offline

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/pip install -e .
.venv/bin/python -m pytest -q
.venv/bin/aesens demo
```

`demo` runs the whole pipeline on two invented quarterly archives in a temporary directory. It shows that the software works; it is not evidence about any drug.

## Running the study

```bash
.venv/bin/aesens acquire     # download and checksum the eight quarterly ASCII archives (2024Q3-2026Q2)
.venv/bin/aesens build       # compatibility table, streamed ingestion to Parquet, case construction (DuckDB SQL)
.venv/bin/aesens analyze     # drug matching (frozen RxNav snapshot), all configurations, decompositions
.venv/bin/aesens validate    # source reconciliation, structural checks, pandas re-implementation, rerun comparison
.venv/bin/aesens render      # tables, figures, workbook, Tableau export, manuscript, static page
.venv/bin/aesens package     # source archive, handoff files, outer bundle
```

Stages are resumable: downloads are cached and verified by checksum, ingestion is skipped when the archive checksum is unchanged. `aesens analyze --run-label rerun` writes a second run for the reproducibility check. `--refresh-rxnorm` re-queries RxNav and creates a new snapshot. Rendering uses pandoc (`.tools/pandoc-3.12-arm64/bin/pandoc`, the official release); Quarto is not required.

## Layout

| Path | Contents |
|---|---|
| `config/` | Study window and URLs, drug classes, associations and terms, configurations |
| `sql/` | Case construction in DuckDB SQL |
| `src/aesens/` | Pipeline stages, statistics, figures, manuscript and page generation |
| `tests/` | Software tests with synthetic fixtures |
| `docs/` | Analysis plan with amendments, contribution decision, data dictionary, term provenance, decision ledger, literature search, prior art, journal fit, Tableau specification, READUS-PV checklist |
| `outputs/` | Aggregate results only: tables, run records, mapping review, validation, figures, workbook |
| `evidence/claims.json` | Every headline number mapped to its output file, field, configuration, and run |
| `source_manifest.json` | Archive URLs, retrieval times, sizes, SHA-256, members |

## Data and licences

The FDA quarterly files are US Government public data; FDA does not endorse this analysis. Reaction terms are MedDRA preferred-term strings as published in the files (MedDRA is a registered trademark of ICH); no MedDRA dictionary was used. RxNav data come from the National Library of Medicine. The code in this repository is released under the MIT licence (`LICENSE`); third-party data keep their own terms.

## Citation

See `CITATION.cff`. No DOI has been assigned.
