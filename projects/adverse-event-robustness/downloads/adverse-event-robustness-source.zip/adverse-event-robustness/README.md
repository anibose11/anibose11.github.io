# Adverse-event reporting odds ratios under alternative case definitions

**FDA Adverse Event Reporting System (FAERS) Study** · [Project page](https://anibose11.github.io/projects/adverse-event-robustness/) · [Full report](https://anibose11.github.io/projects/adverse-event-robustness/report.html)

A reproducible processing-sensitivity study of the FDA quarterly adverse event data extract files (FAERS, now listed on FDA's Adverse Event Monitoring System pages). For five prespecified SGLT2 and DPP-4 inhibitor reaction pairs, it measures how reporting odds ratios change across eight case-construction, drug-role, and drug-name configurations, and which cells of the two-by-two table move.

For DPP-4 inhibitors and arthralgia, counting secondary-suspect drug listings changed the reporting odds ratio from below 1 to above 1.

The estimates are reporting associations in spontaneous reports. They are not risks, incidence, causal effects, or a ranking of drugs.

## Requirements

- Python 3.12 or later (tested with 3.13.5 on macOS arm64)
- About 3 GB of free disk for the full study (measured: 530 MB of archives, 235 MB of column-limited Parquet, 1.6 GB DuckDB working database)
- 8 GB of memory is enough for the SQL pipeline (peak about 3 GB); the pandas cross-check in `validate` peaked at 11 to 14 GB in the recorded runs
- Network access to fis.fda.gov for `acquire`; RxNav responses are frozen in `data/cache/rxnav/` and reused offline

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/pip install -e .
.venv/bin/python -m pytest -q
.venv/bin/aesens demo
```

`demo` runs the build and analyze stages on two invented quarterly archives in a temporary directory. It shows that the software works; it is not evidence about any drug.

## Running the study

```bash
.venv/bin/aesens acquire     # download and checksum the eight quarterly ASCII archives (2024Q3-2026Q2)
.venv/bin/aesens build       # compatibility table, streamed ingestion to Parquet, case construction (DuckDB SQL)
.venv/bin/aesens analyze     # drug matching (frozen RxNav snapshot), all configurations, decompositions
.venv/bin/aesens validate    # source reconciliation, structural checks, pandas re-implementation, rerun comparison
```

Stages are resumable: downloads are cached and verified by checksum, ingestion is skipped when the archive checksum is unchanged. `aesens analyze --run-label rerun` writes a second run for the reproducibility check. `--refresh-rxnorm` re-queries RxNav and creates a new snapshot. `aesens render` and `aesens package` (and therefore `aesens all`) also build the manuscript, project page and submission bundle. They need manuscript templates and submission files that are not part of this repository, so they stop with an error here, and `render` rewrites some files in `outputs/` and `evidence/` before it stops. The tables, figures and workbook that `render` produces are already in `outputs/`.

The code hashes in `outputs/runs/*/run_meta.json` record the source files used for the recorded runs on 2026-10-07. Seven of them (`analyze.py`, `evidence.py`, `figures.py`, `handoff.py`, `manuscript.py`, `package.py` and `site.py` in `src/aesens/`) were edited afterwards without rerunning the analysis, so their hashes no longer match. Rerunning `analyze` with the current code gives the same counts and estimates; only some label wording in `count_decomposition.csv` changes.

## Layout

| Path | Contents |
|---|---|
| `config/` | Study window and URLs, drug classes, associations and terms, configurations |
| `data/cache/rxnav/` | Frozen RxNav and RxClass responses used for drug matching, with their manifest |
| `sql/` | Case construction in DuckDB SQL |
| `src/aesens/` | Pipeline stages, statistics, figures, manuscript and page generation |
| `scripts/` | `build_references.py` rebuilds `docs/references.json` from the verified reference records; `recheck_validation.py` repeats the author verification checks; it needs network access, the raw archives from `acquire`, the review worksheets written by `validate`, and the built manuscript and project page (none of these are in this repository) |
| `tests/` | Software tests with synthetic fixtures |
| `docs/` | Analysis plan with amendments, contribution decision, data dictionary, term provenance, decision ledger, literature search, prior art, Tableau specification, READUS-PV checklist |
| `outputs/` | Aggregate results only: tables, run records, mapping review, validation, figures, workbook |
| `evidence/claims.json` | Every headline number mapped to its output file, field, configuration, and run |
| `source_manifest.json` | Archive URLs, retrieval times, sizes, SHA-256, members |

## Data and licences

The FDA quarterly files are US Government public data; FDA does not endorse this analysis. Reaction terms are MedDRA preferred-term strings as published in the files (MedDRA is a registered trademark of ICH); no MedDRA dictionary was used. RxNav data come from the National Library of Medicine. The code in this repository is released under the MIT licence ([`LICENSE`](LICENSE)); third-party data keep their own terms ([`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)).

## Citation

See `CITATION.cff`. No DOI has been assigned.
