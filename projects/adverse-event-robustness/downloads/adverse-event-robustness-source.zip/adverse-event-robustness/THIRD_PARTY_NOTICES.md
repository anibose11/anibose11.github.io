# Third-party notices

The code in this repository is released under the MIT licence (`LICENSE`). This licence covers the code in this repository only. The FDA adverse event data files, MedDRA terms appearing in them, and RxNav/RxNorm data are third-party materials and keep their own terms.

## RxNav and RxNorm

The frozen responses in `data/cache/rxnav/` were retrieved from the RxNav and RxClass APIs. This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or recommend this or any other product.
