"""Package stage: allowlisted source archive, public page assets, handoff files, and the outer bundle."""
from __future__ import annotations

import fnmatch
import json
import zipfile
from pathlib import Path

from .common import ROOT, rel, sha256_file, utc_now, write_json

SLUG = "adverse-event-robustness"
SITE = ROOT / "site" / "projects" / SLUG
BUNDLE = ROOT / "deliverables" / "09-adverse-event-robustness-PROJECT-BUNDLE.zip"
FIXED_TIME = (2026, 10, 7, 0, 0, 0)  # constant member timestamps so identical content gives identical archives

SOURCE_ALLOW = [
    "README.md", "LICENSE", "CITATION.cff", "pyproject.toml", "requirements.lock", "source_manifest.json",
    "config/*.yaml", "sql/*.sql", "src/aesens/*.py", "tests/*.py", "tests/fixtures/*.py", "tests/fixtures/*.csv",
    "data/cache/rxnav/*.json",
    "docs/*.md", "docs/*.csv", "docs/*.json",
    "outputs/tables/*.csv", "outputs/runs/primary/*.csv", "outputs/runs/primary/run_meta.json",
    "outputs/runs/rerun/run_meta.json",
    "outputs/build/*.json", "outputs/build/*.csv", "outputs/mapping/*.csv", "outputs/mapping/*.json",
    "outputs/validation/validation_report.json", "outputs/validation/source_reconciliation.csv", "outputs/validation/independent_recheck.json",
    "outputs/validation/second_implementation_*.csv", "outputs/figures/*.svg", "outputs/figures/*.png",
    "outputs/runtime/*.json", "outputs/runtime/*.jsonl", "outputs/tableau/*.csv", "outputs/*.xlsx",
    "evidence/claims.json", "scripts/*.py", "docs/_research/references_verified.json",
]
SOURCE_DENY = ["*.parquet", "*.duckdb", "*.zip", ".venv/*", ".tools/*", ".local/*", "data/raw/*", "data/work/*",
               "deliverables/*", "handoff/*", "submission/*", "private/*", "site/*", "docs/_research/*.md", "*/__pycache__/*",
               "outputs/validation/human_review_*"]


def _allowed(relpath: str) -> bool:
    if any(fnmatch.fnmatch(relpath, d) for d in SOURCE_DENY):
        return False
    return any(fnmatch.fnmatch(relpath, a) and relpath.count("/") == a.count("/") for a in SOURCE_ALLOW)


def _zip(paths: list[tuple[Path, str]], dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src, arc in sorted(paths, key=lambda t: t[1]):
            info = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, src.read_bytes())
    with zipfile.ZipFile(tmp) as zf:
        if zf.testzip() is not None:
            raise RuntimeError(f"ZIP integrity check failed for {dest}")
    tmp.replace(dest)


def source_archive() -> dict:
    files = []
    for p in ROOT.rglob("*"):
        if p.is_file():
            r = p.relative_to(ROOT).as_posix()
            if _allowed(r):
                files.append((p, f"{SLUG}/{r}"))
    # Scan for machine-specific paths or secrets before packaging.
    home = str(Path.home())
    leaks = [arc for src, arc in files if src.suffix in {".py", ".md", ".csv", ".json", ".yaml", ".sql", ".jsonl", ".cff", ".toml", ".lock"}
             and (home in src.read_text(encoding="utf-8", errors="ignore"))]
    if leaks:
        raise RuntimeError(f"Machine-specific paths found in: {leaks[:5]}")
    dest = SITE / "downloads" / f"{SLUG}-source.zip"
    _zip(files, dest)
    return {"path": rel(dest), "members": len(files), "bytes": dest.stat().st_size, "sha256": sha256_file(dest)}


def public_files() -> list[dict]:
    out = []
    for p in sorted(SITE.rglob("*")):
        if p.is_file():
            out.append({"path": f"site/projects/{SLUG}/" + p.relative_to(SITE).as_posix(), "bytes": p.stat().st_size,
                        "sha256": sha256_file(p)})
    return out


def bundle() -> dict:
    files = [(p, f"site/projects/{SLUG}/" + p.relative_to(SITE).as_posix()) for p in SITE.rglob("*") if p.is_file()]
    for name in (f"{SLUG}.json", f"{SLUG}-validation.md", "verified_results.md"):
        files.append((ROOT / "handoff" / name, f"handoff/{name}"))
    # Journal submission package (private: contains the corresponding author's email; not for the public site).
    sub = ROOT / "submission"
    for p in sorted(sub.rglob("*")):
        if p.is_file() and not p.name.startswith(".") and p.suffix in {".docx", ".zip", ".png", ".svg", ".md"}:
            files.append((p, "submission/" + p.relative_to(sub).as_posix()))
    _zip(files, BUNDLE)
    with zipfile.ZipFile(BUNDLE) as zf:
        names = zf.namelist()
    return {"path": rel(BUNDLE), "members": len(names), "bytes": BUNDLE.stat().st_size}


def run() -> dict:
    from . import handoff

    src = source_archive()
    import shutil
    shutil.copy2(ROOT / src["path"], ROOT / "submission" / "ESM3_source_archive.zip")
    handoff.run(public_files(), src)
    b = bundle()
    b["sha256"] = sha256_file(BUNDLE)
    write_json(ROOT / "deliverables" / "bundle_checksum.json", {**b, "generated_utc": utc_now()})
    print(f"[package] source archive {src['bytes'] / 1024 / 1024:.2f} MiB ({src['members']} files); "
          f"bundle {b['bytes'] / 1024 / 1024:.2f} MiB ({b['members']} members) sha256 {b['sha256']}")
    return {"source": src, "bundle": b}
