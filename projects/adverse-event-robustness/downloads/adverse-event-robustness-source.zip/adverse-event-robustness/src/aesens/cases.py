"""Build stage, part 2: case construction in DuckDB SQL, plus construction-flow and cardinality summaries."""
from __future__ import annotations

import duckdb
import pandas as pd

from .common import ROOT, path, rel, utc_now, write_json

SQL_DIR = ROOT / "sql"
OUT = ROOT / "outputs" / "build"


def connect(read_only: bool = False) -> duckdb.DuckDBPyConnection:
    con = duckdb.connect(str(path("db")), read_only=read_only)
    if not read_only:
        con.execute("SET memory_limit='12GB'")
        con.execute(f"SET temp_directory='{(ROOT / 'data' / 'work' / 'tmp').as_posix()}'")
    con.execute("SET preserve_insertion_order=false")
    return con


def run_sql_file(con, name: str, **subs) -> None:
    text = (SQL_DIR / name).read_text(encoding="utf-8")
    for k, v in subs.items():
        text = text.replace("{" + k + "}", v)
    # Comments are removed before splitting so a semicolon inside a comment cannot end a statement.
    text = "\n".join(l for l in text.splitlines() if not l.strip().startswith("--"))
    for stmt in [s.strip() for s in text.split(";")]:
        if stmt:
            con.execute(stmt)


def q(con, sql: str) -> pd.DataFrame:
    return con.execute(sql).fetchdf()


def run() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    con = connect()
    run_sql_file(con, "10_case_construction.sql", parquet=path("parquet").as_posix())

    flow = {}
    flow["demo_rows_delivered"] = q(con, "SELECT count(*) n FROM demo_raw").n[0]
    flow["demo_rows_null_primaryid"] = q(con, "SELECT count(*) n FROM demo_raw WHERE primaryid IS NULL").n[0]
    flow["report_versions_unique_primaryid"] = q(con, "SELECT count(*) n FROM report_version").n[0]
    flow["primaryid_in_more_than_one_extract"] = q(con, "SELECT count(*) n FROM report_version WHERE n_extracts_with_pid > 1").n[0]
    flow["cases_unique_caseid"] = q(con, "SELECT count(*) n FROM case_latest").n[0]
    flow["cases_deleted_listed"] = q(con, "SELECT count(*) n FROM case_latest WHERE is_deleted").n[0]
    flow["cases_retained_after_deletion"] = q(con, "SELECT count(*) n FROM case_latest WHERE NOT is_deleted").n[0]
    flow["deleted_caseids_total_listed"] = q(con, "SELECT count(*) n FROM deleted_case").n[0]
    flow["deleted_caseids_not_in_window"] = q(con, "SELECT count(*) n FROM deleted_case d ANTI JOIN case_latest c USING (caseid)").n[0]
    flow["cases_with_version_after_deletion_listing"] = q(con, "SELECT count(*) n FROM case_latest WHERE version_after_deletion_listing").n[0]
    flow["versions_retained_after_deletion"] = q(con, "SELECT count(*) n FROM version_unit WHERE NOT is_deleted").n[0]
    flow["version_source_counts"] = q(con, "SELECT version_source, count(*) n FROM report_version GROUP BY 1 ORDER BY 1").set_index("version_source").n.to_dict()
    flow["version_field_conflicts"] = q(con, "SELECT count(*) n FROM report_version WHERE version_field_conflict").n[0]
    flow["cases_with_tied_max_version"] = q(con, "SELECT count(*) n FROM case_latest WHERE n_rows_at_max_version > 1").n[0]
    flow["cases_where_fda_dt_rule_disagrees"] = q(con, """
        SELECT count(*) n FROM case_latest c JOIN case_latest_by_fda_dt f USING (caseid) WHERE c.primaryid <> f.primaryid""").n[0]
    flow["cases_multi_version_in_window"] = q(con, "SELECT count(*) n FROM case_latest WHERE n_versions_in_window > 1").n[0]
    flow["cases_latest_version_gt1"] = q(con, "SELECT count(*) n FROM case_latest WHERE caseversion_num > 1").n[0]
    flow["cases_latest_is_followup_without_initial_in_window"] = q(con, """
        SELECT count(*) n FROM case_latest WHERE caseversion_num > 1 AND min_version_in_window > 1""").n[0]
    flow["cases_init_fda_dt_in_window"] = q(con, """
        SELECT count(*) n FROM case_latest WHERE NOT is_deleted AND regexp_full_match(init_fda_dt, '[0-9]{8}')
          AND init_fda_dt BETWEEN '20240701' AND '20260630'""").n[0]
    flow["cases_init_fda_dt_missing_or_partial"] = q(con, """
        SELECT count(*) n FROM case_latest WHERE NOT is_deleted AND (init_fda_dt IS NULL OR NOT regexp_full_match(init_fda_dt, '[0-9]{8}'))""").n[0]
    flow["drug_rows_attached"] = q(con, "SELECT count(*) n FROM drug_rv").n[0]
    flow["reac_rows_attached"] = q(con, "SELECT count(*) n FROM reac_rv").n[0]
    flow["drug_rows_delivered"] = q(con, f"SELECT count(*) n FROM read_parquet('{path('parquet').as_posix()}/drug/*.parquet')").n[0]
    flow["reac_rows_delivered"] = q(con, f"SELECT count(*) n FROM read_parquet('{path('parquet').as_posix()}/reac/*.parquet')").n[0]
    flow["versions_without_drug_rows"] = q(con, "SELECT count(*) n FROM report_version rv ANTI JOIN (SELECT DISTINCT primaryid FROM drug_rv) d USING (primaryid)").n[0]
    flow["versions_without_reac_rows"] = q(con, "SELECT count(*) n FROM report_version rv ANTI JOIN (SELECT DISTINCT primaryid FROM reac_rv) r USING (primaryid)").n[0]
    flow["versions_without_ps_drug"] = q(con, "SELECT count(*) n FROM ps_designation WHERE NOT has_ps").n[0]
    flow["generated_utc"] = utc_now()
    flow = {k: (int(v) if hasattr(v, "item") else v) for k, v in flow.items()}

    per_q = q(con, """
        SELECT src_quarter AS quarter, count(*) AS report_versions,
               count(DISTINCT caseid) AS distinct_caseids,
               sum(CASE WHEN i_f_code = 'I' THEN 1 ELSE 0 END) AS initial_flag,
               sum(CASE WHEN i_f_code = 'F' THEN 1 ELSE 0 END) AS followup_flag,
               sum(CASE WHEN caseversion_num = 1 THEN 1 ELSE 0 END) AS version_1,
               min(fda_dt) AS min_fda_dt, max(fda_dt) AS max_fda_dt
        FROM report_version GROUP BY 1 ORDER BY 1""")
    per_q.to_csv(OUT / "versions_by_quarter.csv", index=False)

    ver_dist = q(con, """
        SELECT CASE WHEN n_versions_in_window >= 5 THEN '5+' ELSE CAST(n_versions_in_window AS VARCHAR) END AS versions_in_window,
               count(*) AS cases FROM case_latest GROUP BY 1 ORDER BY 1""")
    ver_dist.to_csv(OUT / "versions_per_case.csv", index=False)

    write_json(OUT / "case_construction_flow.json", flow)
    con.close()
    print("[cases] construction flow:", {k: flow[k] for k in ("demo_rows_delivered", "report_versions_unique_primaryid",
                                                            "cases_unique_caseid", "cases_retained_after_deletion")})
    return flow
