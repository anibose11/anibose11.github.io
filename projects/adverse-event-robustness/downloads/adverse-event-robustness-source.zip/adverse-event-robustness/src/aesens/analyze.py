"""Analyze stage: unit-level indicators, two-by-two tables for every prespecified configuration,
secondary analyses, and the count decomposition that explains differences between configurations."""
from __future__ import annotations

import hashlib
import json

import pandas as pd

from .cases import connect
from .common import ROOT, load_yaml, read_json, rel, sha256_file, utc_now, write_json
from .stats import ror

RUNS = ROOT / "outputs" / "runs"
WINDOW = ("20240701", "20260630")


def _sql_str(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def run_identity(run_label: str) -> dict:
    files = ["config/study.yaml", "config/associations.yaml", "config/variants.yaml", "config/drug_classes.yaml",
             "source_manifest.json", "data/cache/rxnav/rxnav_manifest.json"]
    hashes = {f: sha256_file(ROOT / f) for f in files}
    code = {p.name: sha256_file(p) for p in sorted((ROOT / "src" / "aesens").glob("*.py"))}
    code.update({p.name: sha256_file(p) for p in sorted((ROOT / "sql").glob("*.sql"))})
    digest = hashlib.sha256(json.dumps([hashes, code], sort_keys=True).encode()).hexdigest()[:12]
    return {"run_label": run_label, "run_id": f"{run_label}-{digest}", "input_hashes": hashes, "code_hashes": code}


def build_indicators(con, assoc: list[dict], classes: list[str]) -> None:
    # Drug-row role flags. The FDA FAQ 30 rule designates the lowest DRUG_SEQ as PS when a report has none.
    sel = []
    for c in classes:
        k = c.lower()
        sel += [
            f"bool_or(class = '{c}' AND is_ps AND strict) AS {k}_ps_strict",
            f"bool_or(class = '{c}' AND is_ps AND expanded) AS {k}_ps_expanded",
            f"bool_or(class = '{c}' AND is_suspect AND strict) AS {k}_suspect_strict",
            f"bool_or(class = '{c}' AND is_suspect AND expanded) AS {k}_suspect_expanded",
            f"bool_or(class = '{c}' AND expanded) AS {k}_any_expanded",
            f"bool_or(class = '{c}' AND basis = 'same_stem_unverified') AS {k}_stem_unverified",
            f"bool_or(class = '{c}' AND is_suspect AND expanded AND NOT strict) AS {k}_suspect_expanded_only",
            f"bool_or(class = '{c}' AND is_suspect AND expanded AND basis LIKE '%drugname%' AND basis NOT LIKE '%prod_ai%') AS {k}_suspect_drugname_only",
            f"bool_or(class = '{c}' AND is_ps AND expanded AND NOT p_has_ps) AS {k}_ps_by_fallback",
        ]
    con.execute(f"""
        CREATE OR REPLACE TABLE expo AS
        WITH dm AS (
            SELECT m.*, p.has_ps AS p_has_ps,
                   (m.role_cod = 'PS' OR (NOT p.has_ps AND m.drug_seq = p.first_seq)) AS is_ps
            FROM drug_match m JOIN ps_designation p USING (primaryid)
        )
        SELECT primaryid, {", ".join(sel)}
        FROM (SELECT *, (is_ps OR role_cod = 'SS') AS is_suspect FROM dm)
        GROUP BY primaryid""")
    ev_sel = []
    for a in assoc:
        terms = ", ".join(_sql_str(t.strip().lower()) for t in a["terms"])
        ev_sel.append(f"bool_or(lower(trim(pt)) IN ({terms})) AS ev_{a['id'].lower()}")
    con.execute(f"CREATE OR REPLACE TABLE ev AS SELECT primaryid, {', '.join(ev_sel)} FROM reac_rv GROUP BY primaryid")
    expo_cols = [r[0] for r in con.execute("SELECT column_name FROM information_schema.columns WHERE table_name='expo' AND column_name <> 'primaryid'").fetchall()]
    ev_cols = [f"ev_{a['id'].lower()}" for a in assoc]
    con.execute(f"""
        CREATE OR REPLACE TABLE unit_flags AS
        SELECT rv.primaryid, rv.caseid, rv.src_quarter, rv.caseversion_num,
               vu.is_case_latest, vu.is_deleted,
               (regexp_full_match(coalesce(cl.init_fda_dt, ''), '[0-9]{{8}}')
                    AND cl.init_fda_dt BETWEEN '{WINDOW[0]}' AND '{WINDOW[1]}') AS init_in_window,
               {", ".join(f"coalesce(e.{c}, false) AS {c}" for c in expo_cols)},
               {", ".join(f"coalesce(v.{c}, false) AS {c}" for c in ev_cols)}
        FROM report_version rv
        JOIN version_unit vu USING (primaryid)
        LEFT JOIN case_latest cl ON cl.primaryid = rv.primaryid
        LEFT JOIN expo e ON e.primaryid = rv.primaryid
        LEFT JOIN ev v ON v.primaryid = rv.primaryid""")


def universe(unit: str, apply_deletions: bool = True) -> str:
    parts = ["is_case_latest"] if unit == "case" else ["true"]
    if apply_deletions:
        parts.append("NOT is_deleted")
    return " AND ".join(parts)


def cells(con, where: str, x: str, e: str, extra: dict | None = None) -> dict:
    extra = extra or {}
    extra_sql = "".join(f", count(*) FILTER (WHERE {v}) AS {k}" for k, v in extra.items())
    r = con.execute(f"""
        SELECT count(*) FILTER (WHERE ({x}) AND ({e})) AS a,
               count(*) FILTER (WHERE ({x}) AND NOT ({e})) AS b,
               count(*) FILTER (WHERE NOT ({x}) AND ({e})) AS c,
               count(*) FILTER (WHERE NOT ({x}) AND NOT ({e})) AS d,
               count(*) AS n {extra_sql}
        FROM unit_flags WHERE {where}""").fetchdf().iloc[0].to_dict()
    return {k: int(v) for k, v in r.items()}


def posthoc_profiles(con, assoc: list[dict], out, run_id: str) -> None:
    """Post hoc descriptive profiles (plan amendment 3). No estimates; explains observed cell changes."""
    U = universe("case")
    con.execute("""CREATE OR REPLACE TEMP TABLE rows_per_version AS
        SELECT primaryid, nd, nr FROM (SELECT primaryid, count(*) nd FROM drug_rv GROUP BY 1)
        FULL JOIN (SELECT primaryid, count(*) nr FROM reac_rv GROUP BY 1) USING (primaryid)""")
    prof = []
    for a in assoc:
        k, e = a["class"].lower(), f"ev_{a['id'].lower()}"
        groups = {
            "cell_a_primary_suspect": f"{k}_ps_expanded AND {e}",
            "cell_a_secondary_suspect_only": f"{k}_suspect_expanded AND NOT {k}_ps_expanded AND {e}",
            "cell_c_background": f"NOT {k}_suspect_expanded AND {e}",
        }
        for g, cond in groups.items():
            r = con.execute(f"""
                SELECT count(*) AS units,
                       median(coalesce(p.nd, 0)) AS median_drug_rows, quantile_cont(coalesce(p.nd, 0), 0.25) AS q1_drug_rows,
                       quantile_cont(coalesce(p.nd, 0), 0.75) AS q3_drug_rows, median(coalesce(p.nr, 0)) AS median_reaction_rows,
                       avg(CASE WHEN coalesce(p.nd, 0) >= 20 THEN 1.0 ELSE 0 END) AS share_20plus_drug_rows,
                       avg(CASE WHEN rv.lit_ref IS NOT NULL THEN 1.0 ELSE 0 END) AS share_literature_reference,
                       avg(CASE WHEN rv.rept_cod = 'EXP' THEN 1.0 ELSE 0 END) AS share_expedited,
                       avg(CASE WHEN rv.occp_cod = 'CN' THEN 1.0 ELSE 0 END) AS share_consumer_reporter
                FROM unit_flags u JOIN report_version rv USING (primaryid) LEFT JOIN rows_per_version p USING (primaryid)
                WHERE {U.replace('is_', 'u.is_')} AND {cond}""").fetchdf().iloc[0].to_dict()
            prof.append({"association": a["id"], "group": g, **r})
    pp = pd.DataFrame(prof)
    pp.insert(0, "run_id", run_id)
    pp.insert(1, "status", "post hoc descriptive (plan amendment 3)")
    pp.to_csv(out / "posthoc_role_profile.csv", index=False)

    mp = []
    for a in assoc:
        k, e = a["class"].lower(), f"ev_{a['id'].lower()}"
        for g, cond in {"strict_match": f"{k}_suspect_strict", "expanded_only_match": f"{k}_suspect_expanded AND NOT {k}_suspect_strict"}.items():
            r = con.execute(f"""SELECT count(*) AS exposed_units, count(*) FILTER (WHERE {e}) AS with_event
                                FROM unit_flags WHERE {U} AND {cond}""").fetchdf().iloc[0].to_dict()
            ing = con.execute(f"""
                SELECT m.ingredient, count(DISTINCT m.primaryid) n FROM drug_match m JOIN unit_flags u USING (primaryid)
                WHERE {U.replace('is_', 'u.is_')} AND {cond.replace(k + '_', 'u.' + k + '_')} AND m.class = '{a['class']}' AND m.expanded
                GROUP BY 1 ORDER BY 2 DESC""").fetchdf()
            mix = "; ".join(f"{r_.ingredient} {r_.n}" for r_ in ing.itertuples())
            mp.append({"association": a["id"], "group": g, **{kk: int(vv) for kk, vv in r.items()},
                       "event_share": (r["with_event"] / r["exposed_units"]) if r["exposed_units"] else None,
                       "ingredient_mix_units": mix})
    mm = pd.DataFrame(mp)
    mm.insert(0, "run_id", run_id)
    mm.insert(1, "status", "post hoc descriptive (plan amendment 3)")
    mm.to_csv(out / "posthoc_mapping_profile.csv", index=False)


def run(run_label: str = "primary") -> dict:
    acfg = load_yaml("associations.yaml")
    vcfg = load_yaml("variants.yaml")
    assoc = acfg["associations"]
    min_a = acfg["measure"]["minimum_support"]
    classes = sorted({a["class"] for a in assoc})
    ident = run_identity(run_label)
    out = RUNS / run_label
    out.mkdir(parents=True, exist_ok=True)
    con = connect()
    build_indicators(con, assoc, classes)

    rows = []
    for v in vcfg["principal"]:
        where = universe(v["unit"])
        for a in assoc:
            k = a["class"].lower()
            x = f"{k}_{v['role']}_{v['mapping']}"
            e = f"ev_{a['id'].lower()}"
            extra = {"c_class_listed_nonqualifying": f"NOT {x} AND {e} AND {k}_any_expanded",
                     "d_class_listed_nonqualifying": f"NOT {x} AND NOT {e} AND {k}_any_expanded"}
            cl = cells(con, where, x, e, extra)
            rows.append({"analysis": "principal", "variant": v["id"], "variant_label": v["label"], "unit": v["unit"],
                         "role": v["role"], "mapping": v["mapping"], "association": a["id"],
                         "association_label": a["label"], "class": a["class"], **cl, **ror(cl["a"], cl["b"], cl["c"], cl["d"], min_a)})

    # Secondary analyses (single changes from V1).
    v1 = next(v for v in vcfg["principal"] if v["id"] == vcfg["primary"])
    for a in assoc:
        k = a["class"].lower()
        other = next(c for c in classes if c != a["class"]).lower()
        x = f"{k}_{v1['role']}_{v1['mapping']}"
        e = f"ev_{a['id'].lower()}"
        specs = {
            "S1": (universe("case", apply_deletions=False), x),
            "S2": (universe("case") + " AND init_in_window", x),
            "S4": (universe("case") + f" AND ({x} OR NOT ({k}_stem_unverified OR {other}_stem_unverified))", x),
        }
        for sid, (where, xx) in specs.items():
            cl = cells(con, where, xx, e)
            rows.append({"analysis": "secondary", "variant": sid, "variant_label": next(s["label"] for s in vcfg["secondary"] if s["id"] == sid),
                         "unit": "case", "role": v1["role"], "mapping": v1["mapping"], "association": a["id"],
                         "association_label": a["label"], "class": a["class"], **cl, **ror(cl["a"], cl["b"], cl["c"], cl["d"], min_a)})
        # S3 active comparator: rows are target-class cases versus other-class cases; both-class cases excluded.
        where = universe("case") + (f" AND (({x} AND NOT {other}_any_expanded) OR "
                                    f"({other}_{v1['role']}_{v1['mapping']} AND NOT {k}_any_expanded))")
        cl = cells(con, where, x, e)
        excluded_both = con.execute(f"""SELECT count(*) FROM unit_flags WHERE {universe('case')}
              AND (({x} AND {other}_any_expanded) OR ({other}_{v1['role']}_{v1['mapping']} AND {k}_any_expanded))""").fetchone()[0]
        rows.append({"analysis": "secondary", "variant": "S3", "variant_label": next(s["label"] for s in vcfg["secondary"] if s["id"] == "S3"),
                     "unit": "case", "role": v1["role"], "mapping": v1["mapping"], "association": a["id"],
                     "association_label": a["label"], "class": a["class"], **cl,
                     "s3_comparator_class": other.upper(), "s3_excluded_both_classes": int(excluded_both),
                     **ror(cl["a"], cl["b"], cl["c"], cl["d"], min_a)})

    res = pd.DataFrame(rows)
    res.insert(0, "run_id", ident["run_id"])
    res.to_csv(out / "association_counts.csv", index=False)

    # Robustness summary over the four case-level principal variants, and over all eight for reference.
    summ = []
    for a in assoc:
        sub = res[(res.analysis == "principal") & (res.association == a["id"])]
        for scope, s in (("case_level_V1_V4", sub[sub.unit == "case"]), ("all_principal_V1_V8", sub)):
            rep = s[s.status == "reported"]
            r = {"association": a["id"], "scope": scope, "variants_reported": len(rep), "variants_total": len(s)}
            if len(rep):
                r.update({"ror_min": rep.ror.min(), "ror_max": rep.ror.max(), "ror_max_over_min": rep.ror.max() / rep.ror.min(),
                          "variant_min": rep.loc[rep.ror.idxmin(), "variant"], "variant_max": rep.loc[rep.ror.idxmax(), "variant"],
                          "all_point_estimates_above_1": bool((rep.ror > 1).all()),
                          "all_lower_bounds_above_1": bool((rep.ci_low > 1).all()),
                          "any_lower_bound_above_1": bool((rep.ci_low > 1).any()),
                          "a_min": int(s.a.min()), "a_max": int(s.a.max()),
                          "max_ci_ratio_within_variant": (rep.ci_high / rep.ci_low).max()})
            summ.append(r)
    summary = pd.DataFrame(summ)
    summary.insert(0, "run_id", ident["run_id"])
    summary.to_csv(out / "robustness_summary.csv", index=False)

    # Decomposition: which units move between cells, and why.
    dec = []
    for a in assoc:
        k = a["class"].lower()
        e = f"ev_{a['id'].lower()}"
        U = universe("case")
        q = lambda s: int(con.execute(f"SELECT count(*) FROM unit_flags WHERE {U} AND {s}").fetchone()[0])  # noqa: E731
        dec += [
            {"association": a["id"], "comparison": "V2 -> V1 (strict -> expanded mapping, suspect role)",
             "units_moved_into_exposed": q(f"{k}_suspect_expanded AND NOT {k}_suspect_strict"),
             "of_which_event": q(f"{k}_suspect_expanded AND NOT {k}_suspect_strict AND {e}"),
             "of_which_drugname_only": q(f"{k}_suspect_expanded AND NOT {k}_suspect_strict AND {k}_suspect_drugname_only"),
             "reason": "member listed only under an RxNorm precise-ingredient (salt) name or a verified brand/verbatim DRUGNAME"},
            {"association": a["id"], "comparison": "V3 -> V1 (primary suspect -> any suspect, expanded mapping)",
             "units_moved_into_exposed": q(f"{k}_suspect_expanded AND NOT {k}_ps_expanded"),
             "of_which_event": q(f"{k}_suspect_expanded AND NOT {k}_ps_expanded AND {e}"),
             "of_which_drugname_only": None,
             "reason": "member reported as secondary suspect only"},
            {"association": a["id"], "comparison": "V1 background (listed in non-qualifying role: concomitant, interacting, not administered, or missing role)",
             "units_moved_into_exposed": q(f"{k}_any_expanded AND NOT {k}_suspect_expanded"),
             "of_which_event": q(f"{k}_any_expanded AND NOT {k}_suspect_expanded AND {e}"),
             "of_which_drugname_only": None,
             "reason": "these units remain in cells c/d under every principal configuration"},
        ]
        # Version multiplicity: report versions that fall in cell a under V5, split by whether their case's
        # selected (latest) version is also in cell a under V1.
        va = con.execute(f"""
            SELECT count(*) AS versions_in_a,
                   count(*) FILTER (WHERE is_case_latest) AS latest_versions_in_a,
                   count(*) FILTER (WHERE NOT is_case_latest) AS earlier_versions_in_a,
                   count(*) FILTER (WHERE NOT is_case_latest AND caseid NOT IN (
                        SELECT caseid FROM unit_flags WHERE {U} AND {k}_suspect_expanded AND {e})) AS earlier_versions_whose_case_not_in_a
            FROM unit_flags WHERE NOT is_deleted AND {k}_suspect_expanded AND {e}""").fetchdf().iloc[0].to_dict()
        dec.append({"association": a["id"], "comparison": "V1 -> V5 (case -> report version, diagnostic)",
                    "units_moved_into_exposed": int(va["earlier_versions_in_a"]),
                    "of_which_event": int(va["earlier_versions_in_a"]), "of_which_drugname_only": None,
                    "reason": (f"earlier versions of cases add to cell a; {int(va['earlier_versions_whose_case_not_in_a'])} "
                               f"of them {'belongs' if int(va['earlier_versions_whose_case_not_in_a']) == 1 else 'belong'} to cases whose latest version no longer meets the exposure or event definition")})
    decomp = pd.DataFrame(dec)
    decomp.insert(0, "run_id", ident["run_id"])
    decomp.to_csv(out / "count_decomposition.csv", index=False)

    # Composition of V1 cell a by qualification route (a partition of cell a).
    comp = []
    for a in assoc:
        k, e = a["class"].lower(), f"ev_{a['id'].lower()}"
        routes = {
            "primary suspect, ingredient name": f"{k}_ps_strict",
            "primary suspect, salt or brand name only": f"{k}_ps_expanded AND NOT {k}_ps_strict",
            "secondary suspect only, ingredient name": f"NOT {k}_ps_expanded AND {k}_suspect_strict",
            "secondary suspect only, salt or brand name only": f"NOT {k}_ps_expanded AND NOT {k}_suspect_strict",
        }
        for route, cond in routes.items():
            n = con.execute(f"SELECT count(*) FROM unit_flags WHERE {universe('case')} AND {k}_suspect_expanded AND {e} AND {cond}").fetchone()[0]
            comp.append({"association": a["id"], "route": route, "units": int(n)})
    cp = pd.DataFrame(comp)
    cp.insert(0, "run_id", ident["run_id"])
    cp.to_csv(out / "cell_a_composition.csv", index=False)

    # Dependence between associations: units counted in cell a of more than one association under V1.
    U = universe("case")
    ov = []
    for i, a1 in enumerate(assoc):
        for a2 in assoc[i + 1:]:
            x1, x2 = f"{a1['class'].lower()}_suspect_expanded", f"{a2['class'].lower()}_suspect_expanded"
            e1, e2 = f"ev_{a1['id'].lower()}", f"ev_{a2['id'].lower()}"
            n = con.execute(f"SELECT count(*) FROM unit_flags WHERE {U} AND {x1} AND {e1} AND {x2} AND {e2}").fetchone()[0]
            ov.append({"association_1": a1["id"], "association_2": a2["id"], "cases_in_both_cell_a": int(n)})
    pd.DataFrame(ov).to_csv(out / "association_overlap.csv", index=False)

    # Exposed-case composition by ingredient under V1 (descriptive; explains class totals).
    ing = con.execute(f"""
        SELECT m.class, m.ingredient, count(DISTINCT m.primaryid) AS cases_listing_ingredient_as_suspect
        FROM drug_match m JOIN unit_flags u USING (primaryid) JOIN ps_designation p USING (primaryid)
        WHERE u.is_case_latest AND NOT u.is_deleted AND m.expanded
          AND (m.role_cod IN ('PS','SS') OR (NOT p.has_ps AND m.drug_seq = p.first_seq))
        GROUP BY ALL ORDER BY 1, 3 DESC""").fetchdf()
    ing.to_csv(out / "exposed_cases_by_ingredient.csv", index=False)

    # Term occurrence: retained cases carrying each prespecified PT string (any drug).
    terms = []
    for a in assoc:
        for t in a["terms"]:
            n = con.execute(f"""SELECT count(DISTINCT r.primaryid) FROM reac_rv r JOIN unit_flags u USING (primaryid)
                                WHERE {U} AND lower(trim(r.pt)) = {_sql_str(t.lower())}""").fetchone()[0]
            terms.append({"association": a["id"], "pt_string": t, "retained_cases_with_term": int(n),
                          "state": "present" if n else "zero (string absent from retained cases)"})
    pd.DataFrame(terms).to_csv(out / "term_occurrence.csv", index=False)

    posthoc_profiles(con, assoc, out, ident["run_id"])

    unit_n = con.execute(f"""SELECT
            count(*) FILTER (WHERE {universe('case')}) AS cases_retained,
            count(*) FILTER (WHERE {universe('version')}) AS versions_retained,
            count(*) FILTER (WHERE {universe('case', False)}) AS cases_before_deletions,
            count(*) FILTER (WHERE {universe('case')} AND init_in_window) AS cases_first_received_in_window
        FROM unit_flags""").fetchdf().iloc[0].to_dict()
    con.close()
    meta = {**ident, "finished_utc": utc_now(), "units": {k: int(v) for k, v in unit_n.items()},
            "outputs": [rel(p) for p in sorted(out.glob("*.csv"))]}
    write_json(out / "run_meta.json", meta)
    print(f"[analyze] run {ident['run_id']}: {len(res)} association rows written to {rel(out)}")
    return meta
