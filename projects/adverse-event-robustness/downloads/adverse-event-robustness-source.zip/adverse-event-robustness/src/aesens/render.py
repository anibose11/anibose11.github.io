"""Render stage: tables, aggregate workbook, Tableau-ready export, figures, manuscript, and the static page.

Everything here reads saved outputs; nothing queries the database, so the rendered numbers are exactly
the analysed numbers.
"""
from __future__ import annotations

import json
import platform
import subprocess
import sys

import pandas as pd

from .common import ROOT, environment_record, read_json, rel, utc_now, write_json

RUN = ROOT / "outputs" / "runs" / "primary"
TAB = ROOT / "outputs" / "tables"
ASSOC_LABEL = {
    "SGLT2I_DKA": "SGLT2 inhibitors and ketoacidosis",
    "SGLT2I_FOURNIER": "SGLT2 inhibitors and Fournier's gangrene",
    "DPP4I_PEMPHIGOID": "DPP-4 inhibitors and pemphigoid",
    "DPP4I_ARTHRALGIA": "DPP-4 inhibitors and arthralgia",
    "DPP4I_PANCREATITIS": "DPP-4 inhibitors and pancreatitis",
}


def f2(x):
    return "" if x is None or pd.isna(x) else f"{x:.2f}"


def tables() -> dict:
    TAB.mkdir(parents=True, exist_ok=True)
    d = pd.read_csv(RUN / "association_counts.csv")
    d["ror_ci"] = d.apply(lambda r: f"{f2(r.ror)} ({f2(r.ci_low)} to {f2(r.ci_high)})" if r.status == "reported" else r.status, axis=1)
    keep = ["association", "variant", "variant_label", "unit", "role", "mapping", "a", "b", "c", "d", "n",
            "ror", "ci_low", "ci_high", "status", "c_class_listed_nonqualifying", "d_class_listed_nonqualifying"]
    prin = d[d.analysis == "principal"][keep]
    prin.to_csv(TAB / "table2_principal_configurations.csv", index=False)
    sec = d[d.analysis == "secondary"][["association", "variant", "variant_label", "a", "b", "c", "d", "n", "ror", "ci_low",
                                        "ci_high", "status", "s3_comparator_class", "s3_excluded_both_classes"]]
    sec.to_csv(TAB / "table4_secondary_analyses.csv", index=False)
    rob = pd.read_csv(RUN / "robustness_summary.csv")
    rob.to_csv(TAB / "table3_robustness_summary.csv", index=False)
    flow = read_json(ROOT / "outputs" / "build" / "case_construction_flow.json")
    flow_rows = [
        ("DEMO rows delivered in 8 extracts", flow["demo_rows_delivered"]),
        ("PRIMARYIDs present in two extracts (later kept)", flow["primaryid_in_more_than_one_extract"]),
        ("Unique report versions (PRIMARYID)", flow["report_versions_unique_primaryid"]),
        ("Unique cases (CASEID)", flow["cases_unique_caseid"]),
        ("Cases with more than one version in the window", flow["cases_multi_version_in_window"]),
        ("Cases whose selected version is a follow-up (version > 1)", flow["cases_latest_version_gt1"]),
        ("  of which no earlier version in the window", flow["cases_latest_is_followup_without_initial_in_window"]),
        ("CASEIDs on acquired deletion lists", flow["deleted_caseids_total_listed"]),
        ("Cases removed by deletion lists", flow["cases_deleted_listed"]),
        ("Cases retained (primary unit)", flow["cases_retained_after_deletion"]),
        ("Report versions retained (diagnostic unit)", flow["versions_retained_after_deletion"]),
        ("Cases first received in window (S2)", flow["cases_init_fda_dt_in_window"]),
        ("Version ties at the maximum version", flow["cases_with_tied_max_version"]),
        ("Cases where FDA_DT-first ordering selects another version", flow["cases_where_fda_dt_rule_disagrees"]),
        ("Report versions with no primary-suspect row", flow["versions_without_ps_drug"]),
    ]
    pd.DataFrame(flow_rows, columns=["step", "count"]).to_csv(TAB / "table1_case_construction.csv", index=False)
    for f in ["count_decomposition.csv", "cell_a_composition.csv", "association_overlap.csv", "exposed_cases_by_ingredient.csv",
              "term_occurrence.csv", "posthoc_role_profile.csv", "posthoc_mapping_profile.csv"]:
        pd.read_csv(RUN / f).to_csv(TAB / f, index=False)
    return {"principal": prin, "secondary": sec, "robustness": rob, "flow": flow_rows}


DEFINITIONS = [
    ("Grain", "One row per prespecified association and processing configuration unless the sheet says otherwise."),
    ("Unit", "case = latest available version of a CASEID within the eight acquired extracts; version = one PRIMARYID (diagnostic only)."),
    ("a", "Units exposed to the drug class under the configuration and carrying at least one prespecified PT string."),
    ("b", "Units exposed to the drug class without any prespecified PT string."),
    ("c", "Background units (all other retained units, every product) with a prespecified PT string."),
    ("d", "Background units without a prespecified PT string."),
    ("n", "a + b + c + d = all retained units in the configuration's universe."),
    ("ROR", "Reporting odds ratio (a/b)/(c/d). A reporting association in spontaneous reports; not incidence, risk, or a causal effect."),
    ("ci_low, ci_high", "Woolf (log) 95% interval. Describes sampling precision under the stated model only."),
    ("status", "reported; not_computed_zero_cell (a cell is 0, no continuity correction); not_evaluated_low_support (a < 3)."),
    ("role", "suspect = PS or SS; ps = primary suspect. A report with no PS row has its lowest non-DN DRUG_SEQ treated as PS (FDA FAQ 30)."),
    ("mapping", "strict = PROD_AI component equals the RxNorm ingredient name; expanded = adds RxNav precise-ingredient and brand names in PROD_AI or DRUGNAME."),
    ("c_class_listed_nonqualifying", "Units in cell c that list a class member in a role or name form the configuration does not count."),
    ("Suppression", "No cell is suppressed. All counts are aggregate counts of reports; the workbook contains no person-level records."),
    ("Filtering rule", "Filter by association or configuration only. Do not sum cells across configurations or associations: units overlap between them."),
    ("Source", "FDA quarterly data extract ASCII files 2024Q3 to 2026Q2 (AEMS, formerly FAERS) with checksums in source_manifest.json."),
]


def workbook(t: dict) -> str:
    path = ROOT / "outputs" / "adverse-event-robustness-results.xlsx"
    meta = read_json(RUN / "run_meta.json")
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        defs = pd.DataFrame(DEFINITIONS, columns=["term", "definition"])
        defs.loc[len(defs)] = ["Run ID", meta["run_id"]]
        defs.to_excel(xw, sheet_name="Definitions", index=False)
        t["principal"].to_excel(xw, sheet_name="Principal configurations", index=False)
        t["secondary"].to_excel(xw, sheet_name="Secondary analyses", index=False)
        t["robustness"].drop(columns="run_id").to_excel(xw, sheet_name="Robustness summary", index=False)
        pd.read_csv(RUN / "count_decomposition.csv").drop(columns="run_id").to_excel(xw, sheet_name="Count decomposition", index=False)
        pd.read_csv(RUN / "cell_a_composition.csv").drop(columns="run_id").to_excel(xw, sheet_name="Cell a composition", index=False)
        pd.DataFrame(t["flow"], columns=["step", "count"]).to_excel(xw, sheet_name="Case construction", index=False)
        pd.read_csv(ROOT / "outputs" / "validation" / "source_reconciliation.csv").to_excel(xw, sheet_name="Source reconciliation", index=False)
        pd.read_csv(ROOT / "outputs" / "mapping" / "verified_drug_names.csv").to_excel(xw, sheet_name="Verified drug names", index=False)
        tp = ROOT / "docs" / "term_provenance.csv"
        if tp.exists():
            pd.read_csv(tp).to_excel(xw, sheet_name="Term provenance", index=False)
        for f, s in (("posthoc_role_profile.csv", "Post hoc role profile"), ("posthoc_mapping_profile.csv", "Post hoc mapping profile")):
            pd.read_csv(RUN / f).drop(columns="run_id").to_excel(xw, sheet_name=s, index=False)
        for ws in xw.book.worksheets:
            for col in ws.columns:
                width = min(max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2, 60)
                ws.column_dimensions[col[0].column_letter].width = width
            ws.freeze_panes = "A2"
    return rel(path)


def tableau(t: dict) -> str:
    out = ROOT / "outputs" / "tableau"
    out.mkdir(parents=True, exist_ok=True)
    p = t["principal"].copy()
    p["analysis"] = "principal"
    s = t["secondary"].copy()
    s["analysis"] = "secondary"
    long = pd.concat([p, s], ignore_index=True)
    long.insert(1, "association_label", long.association.map(ASSOC_LABEL))
    long["is_primary_configuration"] = long.variant.eq("V1")
    long["is_diagnostic_unit"] = long.unit.eq("version")
    long["exposed_units"] = long.a + long.b
    long["event_share_exposed"] = long.a / long.exposed_units
    long["suppressed"] = False
    long.to_csv(out / "association_configurations_long.csv", index=False)
    return rel(out / "association_configurations_long.csv")


def runtime_manifest() -> dict:
    stages = []
    log = ROOT / "outputs" / "runtime" / "stage_log.jsonl"
    if log.exists():
        stages = [json.loads(l) for l in log.read_text().splitlines() if l.strip()]
    pandoc = ROOT / ".tools" / "pandoc-3.12-arm64" / "bin" / "pandoc"
    pv = subprocess.run([str(pandoc), "--version"], capture_output=True, text=True).stdout.splitlines()[0] if pandoc.exists() else "unavailable"
    man = {"generated_utc": utc_now(), "environment": environment_record(),
           "reporting_renderer": f"{pv} (project-local official arm64 release); Quarto not installed",
           "figure_renderer": f"matplotlib {__import__('matplotlib').__version__}",
           "database_engine": f"DuckDB {__import__('duckdb').__version__} (embedded, SQL over Parquet)",
           "python_executable": sys.version.split()[0], "os": platform.platform(),
           "stages_recorded": stages}
    write_json(ROOT / "outputs" / "runtime" / "runtime_manifest.json", man)
    return man


def run() -> dict:
    from . import evidence, figures, manuscript, site

    t = tables()
    figs = figures.run()
    wb = workbook(t)
    tb = tableau(t)
    rt = runtime_manifest()
    evidence.run()
    ms = manuscript.run()
    st = site.run()
    print(f"[render] tables, {len(figs)} figure files, {wb}, {tb}, manuscript {ms}, site {st}")
    return {"figures": figs, "workbook": wb, "tableau": tb, "runtime": rt["reporting_renderer"]}
