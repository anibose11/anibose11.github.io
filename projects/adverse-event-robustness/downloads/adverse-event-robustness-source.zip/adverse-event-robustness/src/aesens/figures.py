"""Figures generated from saved run outputs (no database access). SVG for the web page; the forest plot also provides PDF and 600-dpi PNG."""
from __future__ import annotations

import json

import matplotlib
import matplotlib.ticker  # noqa: F401

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

from .common import ROOT  # noqa: E402

# Validated categorical slots (light surface #fcfcfb): blue, orange, aqua, yellow. Text uses ink tokens.
SURFACE, INK, INK2, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#8a8984", "#e4e3df"
S1, S2, S3, S4 = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
LABELS = {
    "SGLT2I_DKA": "SGLT2 inhibitors and ketoacidosis",
    "SGLT2I_FOURNIER": "SGLT2 inhibitors and Fournier's gangrene",
    "DPP4I_PEMPHIGOID": "DPP-4 inhibitors and pemphigoid",
    "DPP4I_ARTHRALGIA": "DPP-4 inhibitors and arthralgia",
    "DPP4I_PANCREATITIS": "DPP-4 inhibitors and pancreatitis",
}
VLAB = {"V1": "V1 case, suspect, expanded (primary)", "V2": "V2 case, suspect, strict",
        "V3": "V3 case, PS, expanded", "V4": "V4 case, PS, strict",
        "V5": "V5 version, suspect, expanded", "V6": "V6 version, suspect, strict",
        "V7": "V7 version, PS, expanded", "V8": "V8 version, PS, strict"}


def _style():
    plt.rcParams.update({
        "font.family": ["Arial", "Helvetica", "DejaVu Sans"], "font.size": 8.5, "svg.fonttype": "none",
        "axes.edgecolor": GRID, "axes.linewidth": 0.8, "axes.labelcolor": INK2, "xtick.color": INK2,
        "ytick.color": INK, "text.color": INK, "figure.facecolor": SURFACE, "axes.facecolor": SURFACE,
        "savefig.facecolor": SURFACE, "legend.frameon": False,
    })


def _save(fig, outdir, name):
    outdir.mkdir(parents=True, exist_ok=True)
    fig.savefig(outdir / f"{name}.svg", bbox_inches="tight")
    fig.savefig(outdir / f"{name}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fmt(x, nd=2):
    return f"{x:,.{nd}f}" if x is not None and not pd.isna(x) else "n/a"


def forest(run_dir, outdir):
    """Print-size forest panels; saved principal estimates are not recomputed."""
    import csv
    import matplotlib.ticker as mt
    source = run_dir / "association_counts.csv"
    OUT = outdir
    OUT.mkdir(parents=True, exist_ok=True)
    rows=[r for r in csv.DictReader(source.open()) if r['analysis']=='principal']
    assert len(rows)==40
    labels=[('SGLT2I_DKA','SGLT2 inhibitors\nKetoacidosis'),('SGLT2I_FOURNIER',"SGLT2 inhibitors\nFournier’s gangrene"),('DPP4I_PEMPHIGOID','DPP-4 inhibitors\nPemphigoid'),('DPP4I_ARTHRALGIA','DPP-4 inhibitors\nArthralgia'),('DPP4I_PANCREATITIS','DPP-4 inhibitors\nPancreatitis')]
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','pdf.fonttype':42,'axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False})
    fig,axs=plt.subplots(3,2,figsize=(6.4,7.0))
    fig.subplots_adjust(left=.07,right=.985,top=.94,bottom=.085,wspace=.24,hspace=.55)
    plotted=[]
    for i,(aid,label) in enumerate(labels):
     ax=axs.flat[i]; subset={r['variant']:r for r in rows if r['association']==aid}
     lo=min(float(r['ci_low']) for r in subset.values()); hi=max(float(r['ci_high']) for r in subset.values())
     ax.set_xscale('log'); ax.set_xlim(lo/1.3,hi*1.3)
     ax.set_ylim(-.65,7.65); ax.axhspan(-.5,3.5,color='#f0f0f0',zorder=0)
     if lo/1.3 <= 1 <= hi*1.3: ax.axvline(1,color='#555555',lw=.75,zorder=1)
     for j in range(1,9):
      r=subset[f'V{j}']; y=8-j; color='#2166ac' if r['role']=='suspect' else '#b35806'
      marker='o' if r['mapping']=='expanded' else 's'; face=color if r['unit']=='case' else 'white'
      x,a,b=map(float,[r['ror'],r['ci_low'],r['ci_high']])
      ax.plot([a,b],[y,y],color=color,lw=1.35,zorder=2)
      ax.plot(x,y,marker=marker,ms=4.8,mfc=face,mec=color,mew=1.05,zorder=3)
      plotted.append({k:r[k] for k in ('association','variant','a','b','c','d','ror','ci_low','ci_high')})
     ax.set_yticks(range(7,-1,-1),[f'V{j}' for j in range(1,9)],fontsize=9)
     ax.tick_params(axis='y',length=0,pad=3); ax.tick_params(axis='x',labelsize=8.7,length=3)
     candidates=[.3,.5,1,2,3,5,10,20,30,50,100,200,300,500,1000]
     ticks=[t for t in candidates if lo/1.3<=t<=hi*1.3]
     if len(ticks)>5: ticks=ticks[::2]
     ax.xaxis.set_major_locator(mt.FixedLocator(ticks)); ax.xaxis.set_major_formatter(mt.FuncFormatter(lambda v,_:f'{v:g}'))
     ax.xaxis.set_minor_locator(mt.NullLocator()); ax.grid(axis='x',color='#dddddd',lw=.55); ax.set_axisbelow(True)
     ax.set_title(f'{chr(97+i)}  {label}',loc='left',fontsize=9.5,fontweight='bold',pad=6)
    key=axs.flat[5];key.axis('off')
    key.text(0,1.19,'Configuration key',va='top',fontsize=9.5,fontweight='bold')
    key.text(0,1.02,'V1–V4: cases   •   V5–V8: report versions',va='top',fontsize=8.8)
    for y,txt in zip([.84,.68,.52,.36],['V1 / V5   Any suspect, expanded','V2 / V6   Any suspect, strict','V3 / V7   Primary suspect, expanded','V4 / V8   Primary suspect, strict']):
     key.text(0,y,txt,va='top',fontsize=8.8)
    key.text(0,.14,'Shaded rows: diagnostic version analyses\nV1 is the primary configuration.\nExact counts and estimates: Table 2.',va='top',fontsize=8.5,linespacing=1.35)
    fig.text(.5,.025,'Reporting odds ratio with 95% confidence interval (log scale)',ha='center',fontsize=9.2)
    for ext in ('svg','png','pdf'):
     fig.savefig(OUT/f'fig1_ror_by_configuration.{ext}',dpi=600,facecolor='white')
    plt.close(fig)
    assert sorted(plotted,key=lambda r:(r['association'],r['variant']))==sorted([{k:r[k] for k in ('association','variant','a','b','c','d','ror','ci_low','ci_high')} for r in rows],key=lambda r:(r['association'],r['variant']))


def flow(build_dir, run_dir, outdir):
    _style()
    f = json.loads((build_dir / "case_construction_flow.json").read_text())
    meta = json.loads((run_dir / "run_meta.json").read_text())
    d = pd.read_csv(run_dir / "association_counts.csv")
    v1 = d[(d.variant == "V1")]
    sg = v1[v1.association == "SGLT2I_DKA"].iloc[0]
    dp = v1[v1.association == "DPP4I_PEMPHIGOID"].iloc[0]
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    def box(x, y, w, h, title, body, strong=False):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                    fc="#eef4fc" if strong else "#ffffff", ec=S1 if strong else "#c9c8c2", lw=1))
        ax.text(x + 1.5, y + h - 2.2, title, fontsize=8.2, fontweight="bold", va="top", color=INK)
        ax.text(x + 1.5, y + h - 6.6, body, fontsize=7.6, va="top", color=INK2, linespacing=1.35)

    def arrow(x, y1, y2):
        ax.annotate("", xy=(x, y2), xytext=(x, y1), arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=1))

    box(2, 86, 56, 12, f"{f['demo_rows_delivered']:,} report rows (DEMO)",
        "8 quarterly ASCII extracts, 2024Q3 to 2026Q2\nall row counts equal FDA-printed totals")
    arrow(30, 86, 80.6)
    box(2, 68, 56, 12, f"{f['report_versions_unique_primaryid']:,} report versions",
        f"{f['primaryid_in_more_than_one_extract']:,} PRIMARYIDs in two extracts:\nrecord from the later extract kept")
    arrow(30, 68, 62.6)
    box(2, 50, 56, 12, f"{f['cases_unique_caseid']:,} cases (CASEID)",
        f"latest available version per case; {f['cases_multi_version_in_window']:,} cases\nhad more than one version in the window")
    arrow(30, 50, 44.6)
    box(2, 32, 56, 12, f"{f['cases_retained_after_deletion']:,} cases retained",
        f"{f['cases_deleted_listed']:,} cases on FDA deletion lists removed\nprimary unit and background for every table", strong=True)
    box(63, 50, 35, 12, "Diagnostic unit",
        f"{f['versions_retained_after_deletion']:,} report versions\nafter deletions (V5 to V8)")
    box(63, 32, 35, 12, "Receipt-date cohort (S2)",
        f"{meta['units']['cases_first_received_in_window']:,} cases first\nreceived 2024-07-01 to 2026-06-30")
    arrow(30, 32, 26.6)
    box(2, 6, 45, 18, "Exposed under V1 (any suspect,\nexpanded mapping)",
        f"\nSGLT2 inhibitors: {int(sg.a + sg.b):,} cases\nDPP-4 inhibitors: {int(dp.a + dp.b):,} cases\nevents: 5 prespecified PT sets")
    box(52, 6, 46, 18, "Two-by-two table per association",
        "a: exposed with event   b: exposed without\nc: background with event   d: background without\nevery retained case in exactly one cell")
    _save(fig, outdir, "fig2_case_construction_flow")


def composition(run_dir, outdir):
    _style()
    c = pd.read_csv(run_dir / "cell_a_composition.csv")
    routes = ["primary suspect, ingredient name", "primary suspect, salt or brand name only",
              "secondary suspect only, ingredient name", "secondary suspect only, salt or brand name only"]
    cols = [S1, S3, S2, S4]
    assoc = list(LABELS)
    fig, ax = plt.subplots(figsize=(7.2, 3.1))
    for i, aid in enumerate(assoc):
        s = c[c.association == aid].set_index("route").loc[routes, "units"]
        tot = s.sum()
        left = 0
        y = len(assoc) - 1 - i
        for r, col in zip(routes, cols):
            w = s[r] / tot
            if w > 0:
                ax.barh(y, w, left=left, height=0.56, color=col, edgecolor=SURFACE, linewidth=2)
            left += w
        ax.text(1.01, y, f"a = {tot:,}", va="center", fontsize=7.8, color=INK2, transform=ax.get_yaxis_transform())
    ax.set_yticks(range(len(assoc)))
    ax.set_yticklabels([LABELS[a] for a in reversed(assoc)])
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="x", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    ax.set_xlabel("Share of primary-configuration cell a (exposed cases with the event)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=col) for col in cols]
    ax.legend(handles, ["Primary suspect, ingredient name", "Primary suspect, salt or brand name only",
                        "Secondary suspect only, ingredient name", "Secondary suspect only, salt or brand name only"],
              ncol=2, fontsize=7.4, loc="lower left", bbox_to_anchor=(0, 1.02))
    _save(fig, outdir, "fig3_cell_a_composition")


def posthoc_rows(run_dir, outdir):
    _style()
    p = pd.read_csv(run_dir / "posthoc_role_profile.csv")
    p = p[p.group != "cell_c_background"]
    assoc = list(LABELS)
    fig, ax = plt.subplots(figsize=(7.2, 2.9))
    for i, aid in enumerate(assoc):
        y = len(assoc) - 1 - i
        for g, col, dy in (("cell_a_primary_suspect", S2, 0.14), ("cell_a_secondary_suspect_only", S1, -0.14)):
            r = p[(p.association == aid) & (p.group == g)].iloc[0]
            ax.plot([max(r.q1_drug_rows, 0.9), r.q3_drug_rows], [y + dy, y + dy], color=col, lw=2, solid_capstyle="round")
            ax.plot(max(r.median_drug_rows, 0.9), y + dy, "o", ms=6, color=col, mec=SURFACE, mew=1.5)
    ax.set_xscale("log")
    ax.xaxis.set_major_locator(matplotlib.ticker.FixedLocator([1, 2, 5, 10, 20, 50, 100]))
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:g}"))
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_yticks(range(len(assoc)))
    ax.set_yticklabels([LABELS[a] for a in reversed(assoc)])
    ax.set_xlabel("Drug rows per report in cell a: median and interquartile range (log scale)")
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.grid(axis="x", color=GRID, lw=0.6)
    ax.legend([Line2D([], [], color=S2, lw=2, marker="o"), Line2D([], [], color=S1, lw=2, marker="o")],
              ["Qualifies as primary suspect", "Qualifies only as secondary suspect"], ncol=2, fontsize=7.5,
              loc="lower left", bbox_to_anchor=(0, 1.02))
    _save(fig, outdir, "figS1_drug_rows_by_role")


def run(outdir=None):
    run_dir = ROOT / "outputs" / "runs" / "primary"
    build_dir = ROOT / "outputs" / "build"
    outdir = outdir or ROOT / "outputs" / "figures"
    forest(run_dir, outdir)
    flow(build_dir, run_dir, outdir)
    composition(run_dir, outdir)
    posthoc_rows(run_dir, outdir)
    return sorted(p.name for p in outdir.glob("*"))
