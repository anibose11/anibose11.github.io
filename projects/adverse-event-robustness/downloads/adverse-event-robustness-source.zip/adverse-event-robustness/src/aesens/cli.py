"""Command-line entry point. Stages: acquire, build, analyze, validate, render, package, all; plus demo."""
from __future__ import annotations

import argparse
import sys

from .common import StageTimer

STAGES = ["acquire", "build", "analyze", "validate", "render", "package"]


def _run(stage: str, args) -> None:
    with StageTimer(stage):
        if stage == "acquire":
            from . import acquire
            acquire.run(force=args.force)
        elif stage == "build":
            from . import compat, ingest, cases
            compat.run()
            ingest.run(force=args.force)
            cases.run()
        elif stage == "analyze":
            from . import drugmap, analyze
            drugmap.run(refresh=args.refresh_rxnorm)
            analyze.run(run_label=args.run_label)
        elif stage == "validate":
            from . import validate
            validate.run()
        elif stage == "render":
            from . import render
            render.run()
        elif stage == "package":
            from . import package
            package.run()


def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="aesens", description=__doc__)
    p.add_argument("stage", choices=STAGES + ["all", "demo"])
    p.add_argument("--force", action="store_true", help="re-download or re-ingest even when cached")
    p.add_argument("--refresh-rxnorm", action="store_true", help="re-query RxNav instead of using the frozen cache")
    p.add_argument("--run-label", default="primary", help="label for the analysis run directory")
    p.add_argument("--keep", action="store_true", help="demo: keep the temporary project directory")
    args = p.parse_args(argv)
    if args.stage == "demo":
        from . import demo
        demo.run(keep=args.keep)
        return
    stages = STAGES if args.stage == "all" else [args.stage]
    for s in stages:
        print(f"== stage: {s}", flush=True)
        _run(s, args)


if __name__ == "__main__":
    main(sys.argv[1:])
