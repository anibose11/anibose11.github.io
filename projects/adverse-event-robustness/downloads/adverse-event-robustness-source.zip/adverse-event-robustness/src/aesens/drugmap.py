"""Drug identity: RxClass/RxNav snapshot, verified name lists, and row-level class matches.

The RxNav responses are cached once and treated as a frozen snapshot (checksums in
data/cache/rxnav/rxnav_manifest.json). Re-querying requires --refresh-rxnorm and produces a new snapshot.
Strings that do not match a verified name stay unmapped; they are listed for review, never guessed.
"""
from __future__ import annotations

import json
import re
import time

import pandas as pd
import requests

from .cases import connect
from .common import ROOT, load_yaml, rel, sha256_bytes, utc_now, write_json

RXNAV = "https://rxnav.nlm.nih.gov/REST"
SNAP = ROOT / "data" / "cache" / "rxnav"
OUT = ROOT / "outputs" / "mapping"


def _get(sess, url, params, key, manifest):
    target = SNAP / f"{key}.json"
    if target.exists():
        body = target.read_bytes()
    else:
        for attempt in range(4):
            try:
                r = sess.get(url, params=params, timeout=60)
                r.raise_for_status()
                if "json" not in r.headers.get("Content-Type", ""):
                    raise ValueError(f"non-JSON response for {url}")
                body = r.content
                break
            except Exception:  # noqa: BLE001 - bounded retry, re-raised below
                if attempt == 3:
                    raise
                time.sleep(3 * (attempt + 1))
        target.write_bytes(body)
        time.sleep(0.1)  # RxNav asks clients to stay well under 20 requests per second
    manifest["responses"][key] = {"url": url, "params": params, "sha256": sha256_bytes(body), "bytes": len(body)}
    return json.loads(body)


def snapshot(refresh: bool = False) -> dict:
    SNAP.mkdir(parents=True, exist_ok=True)
    mpath = SNAP / "rxnav_manifest.json"
    if refresh:
        for f in SNAP.glob("*.json"):
            f.unlink()
    manifest = {"responses": {}}
    if mpath.exists() and not refresh:
        manifest = json.loads(mpath.read_text())
        manifest.setdefault("responses", {})
    else:
        manifest["snapshot_created_utc"] = utc_now()
    cfg = load_yaml("drug_classes.yaml")
    sess = requests.Session()
    sess.headers["User-Agent"] = "adverse-event-robustness/0.1 (research; RxNav)"
    manifest["rxnav_version"] = _get(sess, f"{RXNAV}/version.json", {}, "version", manifest)

    names = []
    for cls, spec in cfg["classes"].items():
        ingredients = {}
        for src in spec["rxclass"]:
            key = f"classmembers_{src['class_id']}_{src['rela_source']}_{src['rela']}"
            data = _get(sess, f"{RXNAV}/rxclass/classMembers.json",
                        {"classId": src["class_id"], "relaSource": src["rela_source"], "rela": src["rela"]}, key, manifest)
            for m in data.get("drugMemberGroup", {}).get("drugMember", []):
                c = m["minConcept"]
                if c["tty"] == "IN":
                    ingredients.setdefault(c["rxcui"], {"name": c["name"], "sources": set()})["sources"].add(src["rela_source"])
                elif c["tty"] == "PIN":
                    rel_ = _get(sess, f"{RXNAV}/rxcui/{c['rxcui']}/related.json", {"tty": "IN"}, f"related_IN_{c['rxcui']}", manifest)
                    for g in rel_.get("relatedGroup", {}).get("conceptGroup", []):
                        for p in g.get("conceptProperties", []) or []:
                            ingredients.setdefault(p["rxcui"], {"name": p["name"], "sources": set()})["sources"].add(src["rela_source"])
        for in_rxcui, info in sorted(ingredients.items(), key=lambda kv: kv[1]["name"]):
            ing = info["name"].upper()
            names.append({"class": cls, "ingredient": ing, "name": ing, "tty": "IN", "rxcui": in_rxcui,
                          "class_sources": "+".join(sorted(info["sources"]))})
            allrel = _get(sess, f"{RXNAV}/rxcui/{in_rxcui}/allrelated.json", {}, f"allrelated_{in_rxcui}", manifest)
            for g in allrel.get("allRelatedGroup", {}).get("conceptGroup", []):
                if g.get("tty") in ("PIN", "BN"):
                    for p in g.get("conceptProperties", []) or []:
                        names.append({"class": cls, "ingredient": ing, "name": p["name"].upper(), "tty": g["tty"],
                                      "rxcui": p["rxcui"], "class_sources": "+".join(sorted(info["sources"]))})
    manifest["n_names"] = len(names)
    write_json(mpath, manifest)
    df = pd.DataFrame(names).drop_duplicates(["class", "ingredient", "name", "tty"]).sort_values(["class", "ingredient", "tty", "name"])
    OUT.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUT / "verified_drug_names.csv", index=False)
    return {"manifest": manifest, "names": df}


def _norm(s: str | None) -> str:
    if not s:
        return ""
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9]+", " ", s.upper())).strip()


def match_rows(names: pd.DataFrame, con=None, outdir=None) -> dict:
    cfg = load_yaml("drug_classes.yaml")
    own = con is None
    con = connect() if own else con
    outdir = OUT if outdir is None else outdir
    ins = names[names.tty == "IN"]
    in_map = {(r["name"]): (r["class"], r["ingredient"]) for _, r in ins.iterrows()}
    pin_map = {r["name"]: (r["class"], r["ingredient"]) for _, r in names[names.tty == "PIN"].iterrows()}
    word_map = {_norm(r["name"]): (r["class"], r["ingredient"], r["tty"]) for _, r in names.iterrows()}
    stems = {cls: spec["inn_stem"] for cls, spec in cfg["classes"].items()}
    # Broad SQL prefilter: anything mentioning a stem or a verified word. Final decisions happen in Python.
    words = sorted({w for w in word_map if w}, key=len, reverse=True)
    broad = "|".join([re.escape(w) for w in words] + list(stems.values()))
    cand = con.execute(f"""
        SELECT drugname, prod_ai, count(*) AS n_rows
        FROM drug_rv
        WHERE regexp_matches(upper(coalesce(prod_ai, '')), '{broad}')
           OR regexp_matches(upper(coalesce(drugname, '')), '{broad}')
        GROUP BY 1, 2""").fetchdf()
    word_re = re.compile(r"(?<![A-Z0-9])(" + "|".join(re.escape(w) for w in words) + r")(?![A-Z0-9])")
    stem_re = re.compile(r"\b([A-Z]*(?:" + "|".join(stems.values()) + r"))[A-Z]*\b")
    us_tokens = set(in_map) | {w for n in pin_map for w in n.split()}

    recs = []
    for drugname, prod_ai, n_rows in cand.itertuples(index=False):
        drugname = drugname if isinstance(drugname, str) else None
        prod_ai = prod_ai if isinstance(prod_ai, str) else None
        comps = [c.strip().upper() for c in (prod_ai or "").split(cfg["matching"]["prod_ai_delimiter"]) if c.strip()]
        found = {}
        for c in comps:
            if c in in_map:
                found.setdefault(in_map[c], set()).add("prod_ai_IN")
            elif c in pin_map:
                found.setdefault(pin_map[c], set()).add("prod_ai_PIN")
        dn = _norm(drugname)
        for m in word_re.finditer(dn):
            cls, ing, tty = word_map[m.group(1)]
            found.setdefault((cls, ing), set()).add(f"drugname_{tty}")
        for (cls, ing), basis in found.items():
            recs.append({"drugname": drugname, "prod_ai": prod_ai, "class": cls, "ingredient": ing,
                         "strict": "prod_ai_IN" in basis, "expanded": True, "basis": "+".join(sorted(basis)),
                         "n_rows": int(n_rows)})
        # Stem-bearing tokens that are not verified member names (non-US agents, variant spellings) for S4.
        text = " ".join(comps) + " " + dn
        for m in stem_re.finditer(text):
            tok = m.group(0)
            if tok in us_tokens or any(tok == i for i in in_map):
                continue
            stem_cls = next(c for c, s in stems.items() if s in tok)
            if not found or all(k[0] != stem_cls for k in found):
                recs.append({"drugname": drugname, "prod_ai": prod_ai, "class": stem_cls, "ingredient": tok,
                             "strict": False, "expanded": False, "basis": "same_stem_unverified", "n_rows": int(n_rows)})
    m = pd.DataFrame(recs, columns=["drugname", "prod_ai", "class", "ingredient", "strict", "expanded", "basis", "n_rows"])
    m = m.drop_duplicates(["drugname", "prod_ai", "class", "ingredient", "basis"])
    m = m.astype({"drugname": object, "prod_ai": object})
    m = m.where(m.notna(), None)
    con.register("m_df", m)
    con.execute("CREATE OR REPLACE TABLE string_match AS SELECT * FROM m_df")
    # Row-level matches: join on both strings with NULL-safe equality.
    con.execute("""
        CREATE OR REPLACE TABLE drug_match AS
        SELECT d.primaryid, d.src_quarter, d.drug_seq, d.role_cod, d.drugname, d.prod_ai,
               s.class, s.ingredient, s.strict, s.expanded, s.basis
        FROM drug_rv d
        JOIN string_match s
          ON d.drugname IS NOT DISTINCT FROM s.drugname AND d.prod_ai IS NOT DISTINCT FROM s.prod_ai""")
    outdir.mkdir(parents=True, exist_ok=True)
    review = con.execute("""
        SELECT class, ingredient, basis, drugname, prod_ai, count(*) AS drug_rows, count(DISTINCT primaryid) AS report_versions
        FROM drug_match GROUP BY ALL ORDER BY class, basis, drug_rows DESC""").fetchdf()
    review.to_csv(outdir / "drug_string_matches.csv", index=False)
    summary = con.execute("""
        SELECT class, basis, count(*) AS drug_rows, count(DISTINCT primaryid) AS report_versions,
               count(DISTINCT coalesce(drugname,'') || '|' || coalesce(prod_ai,'')) AS distinct_strings
        FROM drug_match GROUP BY ALL ORDER BY class, basis""").fetchdf()
    summary.to_csv(outdir / "match_basis_summary.csv", index=False)
    # Near misses: stem-bearing strings with no verified match, kept unmapped and listed for review.
    near = con.execute(f"""
        SELECT d.drugname, d.prod_ai, count(*) AS drug_rows
        FROM drug_rv d ANTI JOIN string_match s
          ON d.drugname IS NOT DISTINCT FROM s.drugname AND d.prod_ai IS NOT DISTINCT FROM s.prod_ai
        WHERE regexp_matches(upper(coalesce(d.drugname,'') || ' ' || coalesce(d.prod_ai,'')), 'GLIFL|GLIPT')
        GROUP BY 1, 2 ORDER BY 3 DESC""").fetchdf()
    near.to_csv(outdir / "unmapped_stem_strings.csv", index=False)
    if own:
        con.close()
    return {"candidates": len(cand), "string_matches": len(m), "unmapped_stem_strings": len(near)}


def run(refresh: bool = False) -> dict:
    snap = snapshot(refresh=refresh)
    res = match_rows(snap["names"])
    res["rxnav_version"] = snap["manifest"]["rxnav_version"]
    write_json(OUT / "drugmap_summary.json", {**res, "verified_names": rel(OUT / "verified_drug_names.csv"),
                                               "generated_utc": utc_now()})
    print("[drugmap]", res)
    return res
