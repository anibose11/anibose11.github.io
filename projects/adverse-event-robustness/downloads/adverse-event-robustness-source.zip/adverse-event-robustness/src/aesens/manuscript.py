"""Manuscript, supplementary material and submission documents, generated from saved outputs.

Qualitative sentences in the template are guarded: each is checked against the outputs here and the build
fails if a statement is no longer true.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess

import jinja2
import pandas as pd

from .common import ROOT, read_json, write_json
from .context import ORDER, SHORT, build

MS = ROOT / "manuscript"
PRIVATE = ROOT / "private" / "submission_with_email"   # never packaged; used only for the journal upload


def contact_email() -> str | None:
    """Corresponding-author email, kept in .local/contact.json so it never enters code, outputs, or bundles."""
    f = ROOT / ".local" / "contact.json"
    return json.loads(f.read_text()).get("email") if f.exists() else None
BUILD = MS / "build"
PANDOC = ROOT / ".tools" / "pandoc-3.12-arm64" / "bin" / "pandoc"
TITLE = ("Processing choices and reporting odds ratios in the FDA quarterly adverse event files: "
         "a disproportionality analysis of five SGLT2 and DPP-4 inhibitor associations, 2024 to 2026")
RUNNING_HEAD = "Processing sensitivity of FAERS reporting odds ratios"
DECL = {
    "funding": ("No specific grant from any funding agency in the public, commercial, or not-for-profit sectors was received for "
                "this study. I used internal resources from Norlowe Research, which I own."),
    "coi": ("Animesh Bose is the owner of Norlowe Research, the organization through which this work was conducted. Animesh Bose "
            "has no other conflicts of interest that are directly relevant to the content of this article."),
    "data": ("The data analyzed are the FDA Adverse Event Monitoring System (formerly FAERS) quarterly data extract files in ASCII "
             "format for 2024Q3 to 2026Q2, which are publicly available from the FDA [@fda_aems_qde]. ESM 3 lists the download URL, "
             "retrieval date, size, and SHA-256 checksum of each file and contains the workflow that downloads, verifies, and "
             "reprocesses them to reproduce every result. Drug class and name data were retrieved from the US National Library of "
             "Medicine RxNav services [@rxnav]; the responses used are included in ESM 3. All aggregate results, including every "
             "two-by-two table, are provided in ESM 2 and ESM 3."),
    "ethics": ("Not applicable. This study is a secondary analysis of publicly available, de-identified adverse event reports "
               "released by the US Food and Drug Administration. No new participants were recruited and no identifiable "
               "information was accessed."),
    "code": ("The analysis code (Python and SQL; MIT License), configuration files, tests with synthetic fixtures, and run "
             "records are provided as ESM 3."),
    "contrib": ("Animesh Bose is the sole author and was responsible for conceptualization, methodology, software, validation, "
                "formal analysis, investigation, data curation, visualization, writing (original draft, and review and editing), "
                "and project administration. The author reviewed and revised the manuscript."),
    "data_web": ("The FDA quarterly data extract files are publicly available from the FDA [@fda_aems_qde]; their checksums and "
                 "the workflow that reproduces every result are in the source archive linked from the project page."),
    "code_web": "Code (MIT License), configuration, tests, and run records are in the same archive.",
}


# --------------------------------------------------------------------------------------------- references
def load_refs() -> dict:
    p = ROOT / "docs" / "references.json"
    return {r["key"]: r for r in json.loads(p.read_text())} if p.exists() else {}


def _pages(p: str | None) -> str:
    """Adis style page ranges: 567-582 -> 567\u201382."""
    if not p:
        return ""
    m = re.fullmatch(r"(\d+)-(\d+)", p)
    if not m:
        return p
    a, b = m.groups()
    if len(a) == len(b):
        i = 0
        while i < len(a) - 1 and a[i] == b[i]:
            i += 1
        b = b[i:]
    return f"{a}\u2013{b}"


def fmt_ref(r: dict) -> str:
    """Drug Safety (Adis) reference style."""
    if r.get("type") == "web":
        import datetime as _dt
        acc = ""
        if r.get("accessed"):
            acc = " Accessed " + _dt.date.fromisoformat(r["accessed"]).strftime("%-d %b %Y") + "."
        date = f" {r['date']}." if r.get("date") else ""
        return f"{r['org']}. {r['title'].rstrip('.')}.{date} {r['url']}.{acc}"
    au = r["authors"]
    au = au if isinstance(au, list) else [a.strip() for a in au.split(",")]
    names = ", ".join(au) if len(au) <= 3 else ", ".join(au[:3]) + ", et al"
    vol = f";{r['volume']}" if r.get("volume") else ""
    iss = f"({r['issue']})" if r.get("issue") else ""
    pages = f":{_pages(r.get('pages'))}" if r.get("pages") else ""
    doi = f" https://doi.org/{r['doi']}." if r.get("doi") else ""
    return f"{names}. {r['title'].rstrip('.')}. {r['journal']}. {r['year']}{vol}{iss}{pages}.{doi}"


def resolve_citations(text: str, refs: dict) -> tuple[str, list[str]]:
    order: list[str] = []

    def nums(keys):
        out = []
        for k in keys:
            if k not in refs:
                raise KeyError(f"Unverified or missing reference key: {k}")
            if k not in order:
                order.append(k)
            out.append(order.index(k) + 1)
        out = sorted(set(out))
        parts, i = [], 0
        while i < len(out):
            j = i
            while j + 1 < len(out) and out[j + 1] == out[j] + 1:
                j += 1
            parts.append(f"{out[i]}–{out[j]}" if j - i >= 2 else ", ".join(str(x) for x in out[i:j + 1]))
            i = j + 1
        return "[" + ", ".join(parts) + "]"

    text = re.sub(r"\[(@[^\]]+)\]", lambda m: nums([k.strip().lstrip("@") for k in m.group(1).split(";")]), text)
    return text, order


# ---------------------------------------------------------------------------------------------- tables
def secondary_label(variant: str, cls: str) -> str:
    return {"S1": "deletion lists not applied", "S2": "cases first received in the window",
            "S3": "DPP-4 inhibitors versus SGLT2 inhibitors" if cls == "DPP4I" else "SGLT2 inhibitors versus DPP-4 inhibitors",
            "S4": "background without unverified -gliflozin/-gliptin names"}[variant]


def md_table(df: pd.DataFrame, align=None) -> str:
    cols = list(df.columns)
    align = align or ["l"] + ["r"] * (len(cols) - 1)
    sep = ["---" if a == "l" else "--:" for a in align]
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(sep) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r.values) + " |")
    return "\n".join(lines)


def tables_md(c: dict) -> str:
    f = c["flow"]
    t1 = pd.read_csv(ROOT / "outputs/tables/table1_case_construction.csv")
    t1["count"] = t1["count"].map(lambda x: f"{int(x):,}")
    t1.columns = ["Step", "Count"]
    d = pd.read_csv(ROOT / "outputs/runs/primary/association_counts.csv")
    p = d[d.analysis == "principal"].copy()
    p["_o"] = p.association.map({a: i for i, a in enumerate(ORDER)})
    p = p.sort_values(["_o", "variant"])
    p["Pair"] = p.association.map(SHORT)
    p["Configuration"] = p.variant + " " + p.unit.map({"case": "case", "version": "version"}) + ", " + \
        p.role.map({"suspect": "any suspect", "ps": "primary suspect"}) + ", " + p.mapping
    for col in "abcd":
        p[col] = p[col].map(lambda x: f"{int(x):,}")
    p["ROR (95% CI)"] = d.loc[p.index].apply(lambda r: f"{r.ror:.2f} ({r.ci_low:.2f} to {r.ci_high:.2f})" if r.status == "reported" else r.status, axis=1)
    p["Pair"] = [pair if i == 0 or pair != prev else "" for i, (pair, prev) in enumerate(zip(p.Pair, [None] + list(p.Pair[:-1])))]
    t2 = p[["Pair", "Configuration", "a", "b", "c", "d", "ROR (95% CI)"]]
    rob = []
    for aid in ORDER:
        A = c["A"][aid]
        rob.append({"Pair": SHORT[aid], "Case-level ROR range": f"{A['case_min']:.2f} to {A['case_max']:.2f}",
                    "Max/min": f"{A['case_ratio']:.2f}",
                    "All lower limits > 1": "yes" if A["case_all_lb_above_1"] else "no",
                    "Moved by role (V3 to V1): units / with event": f"{int(A['dec']['V3 -> V1'].units_moved_into_exposed):,} / {int(A['dec']['V3 -> V1'].of_which_event):,}",
                    "Moved by mapping (V2 to V1): units / with event": f"{int(A['dec']['V2 -> V1'].units_moved_into_exposed):,} / {int(A['dec']['V2 -> V1'].of_which_event):,}",
                    "Extra versions in cell a (V1 to V5)": f"{int(A['dec']['V1 -> V5'].units_moved_into_exposed):,}"})
    t3 = pd.DataFrame(rob)
    s = d[d.analysis == "secondary"].copy()
    s["Pair"] = s.association.map(SHORT)
    s["Analysis"] = s.apply(lambda r: f"{r.variant} {secondary_label(r.variant, r['class'])}", axis=1)
    for col in "abcd":
        s[col] = s[col].map(lambda x: f"{int(x):,}")
    s["ROR (95% CI)"] = d.loc[s.index].apply(lambda r: f"{r.ror:.2f} ({r.ci_low:.2f} to {r.ci_high:.2f})" if r.status == "reported" else r.status, axis=1)
    s = s.sort_values(["association", "variant"], key=lambda x: x.map({a: i for i, a in enumerate(ORDER)}) if x.name == "association" else x)
    s["Pair"] = [pair if i == 0 or pair != prev else "" for i, (pair, prev) in enumerate(zip(s.Pair, [None] + list(s.Pair[:-1])))]
    t4 = s[["Pair", "Analysis", "a", "b", "c", "d", "ROR (95% CI)"]]
    parts = [
        "**Table 1** Case construction from the eight quarterly files (2024Q3 to 2026Q2)", "", md_table(t1), "",
        "*CASEID* case identifier, *DEMO* demographic file, *FDA_DT* date FDA received the case version, *PRIMARYID* report "
        "version identifier, *S2* secondary analysis restricted to cases first received in the window", "",
        "**Table 2** Two-by-two cells and reporting odds ratios under the eight principal configurations. V1 is the primary "
        "configuration; V5 to V8 count report versions and are diagnostic comparators. a, exposed with event; b, exposed without; "
        "c, background with event; d, background without. The background is all other retained units in the database.", "",
        md_table(t2, ["l", "l", "r", "r", "r", "r", "r"]), "", "*CI* confidence interval, *DPP-4* dipeptidyl peptidase-4, *ROR* reporting odds ratio, *SGLT2* sodium-glucose cotransporter-2, *V1 to V8* principal configurations", "",
        "**Table 3** Robustness across the four case-level configurations and the units that moved. 'Moved by role' counts cases "
        "exposed only through a secondary-suspect listing; 'moved by mapping' counts cases exposed only through a salt-form or brand "
        "name; 'extra versions' counts earlier report versions that enter cell a when versions are counted.", "",
        md_table(t3, ["l", "r", "r", "l", "r", "r", "r"]), "", "*CI* confidence interval, *DPP-4* dipeptidyl peptidase-4, *ROR* reporting odds ratio, *SGLT2* sodium-glucose cotransporter-2, *V1 to V8* principal configurations", "",
        "**Table 4** Secondary analyses, each a single change from V1. In S3 the comparison group (c, d) is the other drug class, and "
        "cases listing both classes are excluded.", "", md_table(t4, ["l", "l", "r", "r", "r", "r", "r"]), "",
        "*CI* confidence interval, *DPP-4* dipeptidyl peptidase-4, *ROR* reporting odds ratio, *S1 to S4* secondary analyses, "
        "*SGLT2* sodium-glucose cotransporter-2", "",
    ]
    return "\n".join(parts)


# ---------------------------------------------------------------------------------------------- guards
def guards(c: dict) -> dict:
    A = c["A"]
    g = {}
    four = ["SGLT2I_DKA", "SGLT2I_FOURNIER", "DPP4I_PEMPHIGOID", "DPP4I_PANCREATITIS"]
    g["four_pairs_case_level_all_above_1"] = all(A[a]["case_all_lb_above_1"] for a in four)
    g["arthralgia_V3_V4_below_1"] = A["DPP4I_ARTHRALGIA"]["v"]["V3"].ror < 1 and A["DPP4I_ARTHRALGIA"]["v"]["V4"].ror < 1
    g["arthralgia_V1_lb_above_1"] = A["DPP4I_ARTHRALGIA"]["v"]["V1"].ci_low > 1
    g["all_V1_above_1"] = all(A[a]["v"]["V1"].ror > 1 for a in ORDER)
    g["dka_V1_V3_ci_disjoint"] = A["SGLT2I_DKA"]["v"]["V3"].ci_high < A["SGLT2I_DKA"]["v"]["V1"].ci_low
    g["stable_pairs_ratio_1_1_to_1_7"] = all(1.1 <= A[a]["case_ratio"] <= 1.7 for a in ["SGLT2I_FOURNIER", "DPP4I_PANCREATITIS"])
    g["moving_pairs_ratio_1_7_to_2_7"] = all(1.7 <= A[a]["case_ratio"] <= 2.7 for a in ["SGLT2I_DKA", "DPP4I_PEMPHIGOID"])
    lower = all(A[a]["v"]["V5"].ror < A[a]["v"]["V1"].ror for a in four)
    g["version_lower_for_four_higher_for_arthralgia"] = lower and A["DPP4I_ARTHRALGIA"]["v"]["V5"].ror > A["DPP4I_ARTHRALGIA"]["v"]["V1"].ror
    side = all((A[a]["v"][vv].ror > 1) == (A[a]["v"][cv].ror > 1) for a in ORDER for vv, cv in (("V5", "V1"), ("V6", "V2"), ("V7", "V3"), ("V8", "V4")))
    g["no_version_side_change"] = side
    s4 = {a: abs(A[a]["v"]["S4"].ror / A[a]["v"]["V1"].ror - 1) for a in ORDER}
    g["s4_pemphigoid_largest"] = max(s4, key=s4.get) == "DPP4I_PEMPHIGOID"
    s2 = {a: abs(A[a]["v"]["S2"].ror / A[a]["v"]["V1"].ror - 1) for a in ORDER}
    g["s2_arthralgia_largest"] = max(s2, key=s2.get) == "DPP4I_ARTHRALGIA"
    mp = all(A[a]["mprof"]["expanded_only_match"].event_share < A[a]["mprof"]["strict_match"].event_share for a in ORDER)
    g["expanded_only_lower_event_share_all"] = mp
    ss = all(A[a]["prof"]["cell_a_secondary_suspect_only"].median_drug_rows > A[a]["prof"]["cell_a_primary_suspect"].median_drug_rows for a in ORDER)
    g["ss_only_more_drugs_all"] = ss
    g["all_terms_present"] = bool((c["terms"].retained_cases_with_term > 0).all())
    g["dpp4_expanded_only_mostly_sitagliptin"] = "SITAGLIPTIN" in A["DPP4I_PEMPHIGOID"]["mprof"]["expanded_only_match"].ingredient_mix_units.split(";")[0]
    g["no_version_ties"] = c["flow"]["cases_with_tied_max_version"] == 0 and c["flow"]["cases_where_fda_dt_rule_disagrees"] == 0
    failed = [k for k, v in g.items() if not v]
    if failed:
        raise AssertionError(f"Manuscript statements no longer supported by outputs: {failed}")
    return {**g, "s1_max_rel_change": max(abs(A[a]["v"]["S1"].ror / A[a]["v"]["V1"].ror - 1) for a in ORDER),
            "s2_max_rel_change_excluding_arthralgia": max(v for k, v in s2.items() if k != "DPP4I_ARTHRALGIA")}


# ---------------------------------------------------------------------------------------------- build
def format_docx(path, line_numbers: bool = False, double: bool = True) -> None:
    """Journal layout: Times New Roman 12 pt, double-spaced text, page numbers, optional continuous line numbers."""
    from docx import Document
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt

    d = Document(str(path))
    for st in d.styles:
        if st.type == 1:  # paragraph styles
            st.font.name = "Times New Roman"
            rpr = st.element.get_or_add_rPr()
            fonts = rpr.find(qn("w:rFonts"))
            if fonts is None:
                fonts = OxmlElement("w:rFonts")
                rpr.append(fonts)
            for k in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
                fonts.set(qn(k), "Times New Roman")
    d.styles["Normal"].font.size = Pt(12)
    from docx.shared import RGBColor
    for st in d.styles:
        if st.type == 1 and (st.name.startswith("Heading") or st.name == "Title"):
            st.font.color.rgb = RGBColor(0, 0, 0)
    for par in d.paragraphs:
        par.paragraph_format.line_spacing = 2.0 if double else 1.15
    for t in d.tables:
        for row in t.rows:
            for cell in row.cells:
                for par in cell.paragraphs:
                    par.paragraph_format.line_spacing = 1.0
                    for run in par.runs:
                        run.font.size = Pt(9)
    sect = d.sections[0]
    sp = sect._sectPr
    if line_numbers and sp.find(qn("w:lnNumType")) is None:
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:restart"), "continuous")
        ln.set(qn("w:distance"), "360")
        anchor = sp.find(qn("w:pgMar"))
        if anchor is not None:
            anchor.addnext(ln)
        else:
            sp.insert(0, ln)
    footer = sect.footer.paragraphs[0]
    if not footer.text and not footer._p.findall(qn("w:fldSimple")):
        fld = OxmlElement("w:fldSimple")
        fld.set(qn("w:instr"), "PAGE")
        r = OxmlElement("w:r")
        t_ = OxmlElement("w:t")
        t_.text = "1"
        r.append(t_)
        fld.append(r)
        footer._p.append(fld)
        footer.alignment = 1
    d.save(str(path))
    from .editorial_format import finish
    path.write_bytes(finish(path.read_bytes(), supplement=path.name.startswith(("supplement", "ESM2")))[0])


def _pandoc(args: list[str]) -> None:
    subprocess.run([str(PANDOC), *args], check=True, cwd=MS)


def word_counts(md: str) -> dict:
    def words(s):
        s = re.sub(r"\[[0-9,– ]+\]", "", s)
        return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'.\-]*", s))
    ab = md.split("# Abstract", 1)[1].split("\n# ", 1)[0]
    body = md.split("# 1 Introduction", 1)[1].split("\n# Declarations", 1)[0]
    return {"abstract_words": words(ab), "main_text_words": words(body)}


def context_extra(c: dict) -> dict:
    stages = {s["stage"]: s for s in c["runtime"].get("stages_recorded", []) if s.get("ok")}
    ov = c["overlap"].sort_values("cases_in_both_cell_a", ascending=False).iloc[0]
    hr = c["val"].get("human_review_material") or {"cases_sampled": 25, "versions_listed": 0, "expanded_only_distinct_strings": 0}
    g = guards(c)
    if not hr.get("versions_listed") or not hr.get("expanded_only_distinct_strings"):
        raise AssertionError("Human review material missing from the validation report; run the validate stage first")
    A = c["A"]
    max_map = max(max(A[a]["v"]["V2"].ror / A[a]["v"]["V1"].ror, A[a]["v"]["V1"].ror / A[a]["v"]["V2"].ror,
                      A[a]["v"]["V4"].ror / A[a]["v"]["V3"].ror, A[a]["v"]["V3"].ror / A[a]["v"]["V4"].ror) for a in ORDER)
    tests = read_json(ROOT / "outputs/verification/pytest_summary.json") if (ROOT / "outputs/verification/pytest_summary.json").exists() else {"passed": 18}
    return {
        "title": TITLE, "running_head": RUNNING_HEAD, "decl": DECL, "hr": hr,
        "build_seconds": f"{stages['build']['wall_seconds']:.0f}" if "build" in stages else "n/a",
        "build_mem_gb": f"{stages['build']['peak_rss_mb_process'] / 1024:.1f}" if "build" in stages else "n/a",
        "analyze_seconds": f"{stages['analyze']['wall_seconds']:.0f}" if "analyze" in stages else "n/a",
        "max_overlap": {"n": int(ov.cases_in_both_cell_a), "pair": f"{SHORT[ov.association_1].split(' and ')[1]} and {SHORT[ov.association_2].split(' and ')[1]}"},
        "s1_maxdiff": f"{100 * g['s1_max_rel_change']:.1f}", "s2_maxdiff": f"{100 * g['s2_max_rel_change_excluding_arthralgia']:.0f}",
        "max_map_ratio": max_map, "n_tests": tests.get("passed", 18), "guards": g,
    }


def render_md(web: bool) -> tuple[str, list[str], dict]:
    c = build()
    extra = context_extra(c)
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(MS)), undefined=jinja2.StrictUndefined, keep_trailing_newline=True)
    tpl = env.get_template("template.md.j2")
    refs = load_refs()
    raw = tpl.render(**c, **extra, web=web, references="{{REFS}}", tables="{{TABLES}}")
    text, order = resolve_citations(raw, refs)
    reflist = "\n".join(f"{i + 1}. {fmt_ref(refs[k])}" for i, k in enumerate(order))
    text = text.replace("{{REFS}}", reflist).replace("{{TABLES}}", tables_md(c))
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text, order, extra


def figures_for(target):
    target.mkdir(parents=True, exist_ok=True)
    mapping = {"Fig1": "fig2_case_construction_flow", "Fig2": "fig1_ror_by_configuration", "Fig3": "fig3_cell_a_composition",
               "FigS1": "figS1_drug_rows_by_role"}
    for new, old in mapping.items():
        for ext in ("png", "svg"):
            shutil.copy2(ROOT / "outputs/figures" / f"{old}.{ext}", target / f"{new}.{ext}")
    return mapping


def run() -> dict:
    BUILD.mkdir(parents=True, exist_ok=True)
    figures_for(MS / "figures")
    md, order, extra = render_md(web=False)
    if "—" in md:
        raise AssertionError("Em dash found in manuscript text")
    (MS / "manuscript.md").write_text(md, encoding="utf-8")
    wc = word_counts(md)
    if wc["abstract_words"] > 250 or wc["main_text_words"] > 6000:
        raise AssertionError(f"Word limits exceeded: {wc}")
    md = md.replace("{WC_ABSTRACT}", str(wc["abstract_words"])).replace("{WC_MAIN}", f"{wc['main_text_words']:,}")
    email = contact_email()
    if email:
        PRIVATE.mkdir(parents=True, exist_ok=True)
        (PRIVATE / "manuscript.md").write_text(md.replace("{EMAIL_SUFFIX}", f" Email: {email}"), encoding="utf-8")
        _pandoc([str(PRIVATE / "manuscript.md"), "-o", str(PRIVATE / "manuscript.docx"), "--resource-path", str(MS)])
        format_docx(PRIVATE / "manuscript.docx", line_numbers=True)
        (PRIVATE / "manuscript.md").unlink()
    md = md.replace("{EMAIL_SUFFIX}", "")
    (MS / "manuscript.md").write_text(md, encoding="utf-8")
    write_json(BUILD / "word_counts.json", {**wc, "abstract_limit": 250, "main_text_limit": 6000, "references": len(order),
                                             "guards": extra["guards"]})
    _pandoc(["manuscript.md", "-o", "manuscript.docx", "--resource-path", str(MS)])
    format_docx(MS / "manuscript.docx", line_numbers=True)
    _pandoc(["manuscript.md", "-s", "-o", "manuscript.html", "--metadata", "lang=en", "--css", "build/print.css"])
    (BUILD / "print.css").write_text("body{font-family:system-ui,Arial,sans-serif;max-width:52rem;margin:2rem auto;padding:0 16px;line-height:1.55;color:#16161a}"
                                      "table{border-collapse:collapse;font-size:.85rem}td,th{border-top:1px solid #ddd;padding:.25rem .5rem}"
                                      "img{max-width:100%}\n", encoding="utf-8")
    # Web version for the portfolio report: same scientific text, no title-page block, figures inline.
    web, _, _ = render_md(web=True)
    figs = {"**Fig. 1**": "assets/fig2_case_construction_flow.svg", "**Fig. 2**": "assets/fig1_ror_by_configuration.svg",
            "**Fig. 3**": "assets/fig3_cell_a_composition.svg"}
    for lab, src in figs.items():
        web = web.replace(f"\n{lab} ", f"\n![]({src}){{width=100%}}\n\n{lab} ", 1)
    (BUILD / "web.md").write_text(web, encoding="utf-8")
    _pandoc(["build/web.md", "-o", "build/report_fragment.html", "--shift-heading-level-by=1", "--section-divs"])
    frag = (BUILD / "report_fragment.html").read_text(encoding="utf-8")
    frag = re.sub(r'<header id="title-block-header">.*?</header>', "", frag, flags=re.S)
    frag = f"<h1>{TITLE}</h1>\n<p>Animesh Bose, Norlowe Research</p>\n" + frag
    (BUILD / "report_fragment.html").write_text(frag, encoding="utf-8")
    supplementary(build())
    submission(extra, wc)
    return {"words": wc, "references": len(order)}


# ---------------------------------------------------------------------------------------------- supplement
def supplementary(c: dict) -> None:
    def csv(p, cols=None, rename=None):
        df = pd.read_csv(ROOT / p)
        if cols:
            df = df[cols]
        if rename:
            df = df.rename(columns=rename)
        # Presentation only: retain the numeric precision in the source CSVs.
        labels = {'quarter': 'Quarter', 'server_last_modified': 'Archive modified', 'readme_last_revised': 'Readme revised', 'asc_nts_last_revised': 'ASCII notes revised', 'role_cod_values_documented': 'Documented drug roles', 'headers_identical_to_first_release': 'Headers match first release', 'table': 'File', 'raw_physical_lines': 'Raw lines', 'parsed_rows': 'Parsed rows', 'rejected_rows': 'Rejected rows', 'fda_reported_total': 'FDA total', 'parsed_equals_fda_total': 'Matches FDA total', 'association': 'Drug and event pair', 'pt_string': 'Preferred term', 'match_rule': 'Matching rule', 'source': 'Source', 'source_wording': 'Source wording', 'source_url': 'Source link', 'source_verified': 'Source checked', 'note': 'Note', 'retained_cases_with_term': 'Retained cases with term', 'class': 'Drug class', 'ingredient': 'Ingredient', 'name': 'Drug name', 'tty': 'RxNorm term type', 'rxcui': 'RxNorm ID', 'class_sources': 'Class sources', 'cases_listing_ingredient_as_suspect': 'Cases listing ingredient as suspect', 'basis': 'Match basis', 'drug_rows': 'Drug rows', 'report_versions': 'Report versions', 'distinct_strings': 'Distinct names', 'comparison': 'Comparison', 'units_moved_into_exposed': 'Units added to exposed group', 'of_which_event': 'With the event', 'of_which_drugname_only': 'Matched by drug name only', 'reason': 'Reason', 'group': 'Report group', 'units': 'Units', 'median_drug_rows': 'Drug rows median', 'q1_drug_rows': 'Drug rows Q1', 'q3_drug_rows': 'Drug rows Q3', 'median_reaction_rows': 'Reaction rows median', 'share_20plus_drug_rows': '20 or more drugs (%)', 'share_literature_reference': 'Literature reference (%)', 'share_expedited': 'Expedited (%)', 'share_consumer_reporter': 'Consumer reporter (%)', 'exposed_units': 'Exposed units', 'with_event': 'With the event', 'event_share': 'With the event (%)', 'ingredient_mix_units': 'Ingredient mix (units)', 'association_1': 'First drug and event pair', 'association_2': 'Second drug and event pair', 'cases_in_both_cell_a': 'Cases in both exposed event groups'}
        percent_columns = ['event_share', 'share_20plus_drug_rows', 'share_consumer_reporter', 'share_expedited', 'share_literature_reference']
        display_values = {'cell_a_primary_suspect': 'Exposed event cases: primary suspect', 'cell_a_secondary_suspect_only': 'Exposed event cases: secondary suspect only', 'cell_c_background': 'Other event cases', 'strict_match': 'Strict match', 'expanded_only_match': 'Expanded match only', 'SGLT2I_DKA': 'SGLT2 / ketoacidosis', 'SGLT2I_FOURNIER': 'SGLT2 / Fournier gangrene', 'DPP4I_PEMPHIGOID': 'DPP-4 / pemphigoid', 'DPP4I_ARTHRALGIA': 'DPP-4 / arthralgia', 'DPP4I_PANCREATITIS': 'DPP-4 / pancreatitis'}
        for col in percent_columns:
            if col in df.columns:
                df[col] = df[col].map(lambda value: "" if pd.isna(value) else f"{value * 100:.1f}")
        for col in ['fda_reported_total', 'of_which_drugname_only', 'units']:
            if col in df.columns:
                df[col] = df[col].map(lambda value: "" if pd.isna(value) else f"{int(value):,}" if float(value).is_integer() else str(value))
        df = df.replace(display_values)
        df = df.rename(columns=labels)
        return md_table(df.fillna(""), ["l"] * len(df.columns))

    run = "outputs/runs/primary/"
    parts = [f"# Electronic Supplementary Material 2\n\n{TITLE}\n",
             "## Table S1 Release compatibility\n", csv("docs/transition_table.csv", ["quarter", "server_last_modified", "readme_last_revised",
                                                                                   "asc_nts_last_revised", "role_cod_values_documented", "headers_identical_to_first_release"]),
             "\n## Table S2 Source reconciliation (parsed rows, raw lines, FDA-printed totals)\n",
             csv("outputs/validation/source_reconciliation.csv", ["quarter", "table", "raw_physical_lines", "parsed_rows", "rejected_rows", "fda_reported_total", "parsed_equals_fda_total"]),
             "\n## Table S3 Reaction term provenance\n", csv("docs/term_provenance.csv") if (ROOT / "docs/term_provenance.csv").exists() else "",
             "\n### Term occurrence among retained cases\n", csv(run + "term_occurrence.csv", ["association", "pt_string", "retained_cases_with_term"]),
             "\n## Table S4 Verified drug names (RxNav snapshot) and cases listing each ingredient as suspect under V1\n",
             csv("outputs/mapping/verified_drug_names.csv", ["class", "ingredient", "name", "tty", "rxcui", "class_sources"]), "\n",
             csv(run + "exposed_cases_by_ingredient.csv"),
             "\n## Table S5 Drug-name match basis (drug rows and report versions)\n", csv("outputs/mapping/match_basis_summary.csv"),
             "\n## Table S6 Count decomposition between configurations\n",
             csv(run + "count_decomposition.csv", ["association", "comparison", "units_moved_into_exposed", "of_which_event", "of_which_drugname_only", "reason"]),
             "\n## Table S7 Post hoc descriptive profiles of moved units\n\nPercentages in these tables are rounded to one decimal place for display. The CSV files retain full precision.\n",
             csv(run + "posthoc_role_profile.csv", ["association", "group", "units", "median_drug_rows", "q1_drug_rows", "q3_drug_rows", "median_reaction_rows",
                                                   "share_20plus_drug_rows", "share_literature_reference", "share_expedited", "share_consumer_reporter"]),
             "\n", csv(run + "posthoc_mapping_profile.csv", ["association", "group", "exposed_units", "with_event", "event_share", "ingredient_mix_units"]),
             "\n## Table S8 Overlap of cell a between pairs (V1)\n", csv(run + "association_overlap.csv"),
             "\n## Supplementary Fig. S1\n\n![Drug rows per report in cell a by role route (post hoc)](figures/FigS1.png)\n",
             "\n## READUS-PV checklist\n", (ROOT / "docs/readus_pv_checklist.md").read_text() if (ROOT / "docs/readus_pv_checklist.md").exists() else ""]
    md = "\n".join(parts)
    (MS / "supplementary_material.md").write_text(md, encoding="utf-8")
    _pandoc(["supplementary_material.md", "-s", "-o", "supplementary_material.html", "--metadata", "title=Supplementary material",
             "--css", "build/print.css", "--embed-resources"])
    _pandoc(["supplementary_material.md", "-o", "supplementary_material.docx", "--resource-path", str(MS)])
    from .editorial_format import finish
    supp = MS / "supplementary_material.docx"
    supp.write_bytes(finish(supp.read_bytes(), supplement=True)[0])


# ---------------------------------------------------------------------------------------------- submission
def _two_versions(text: str, stem: str, email: str | None, suffix: str) -> None:
    """Public copy (submission/, packaged) without the email; private copy with it (never packaged)."""
    sub = ROOT / "submission"
    (sub / f"{stem}.md").write_text(text.replace("{EMAIL_SUFFIX}", ""), encoding="utf-8")
    _pandoc([str(sub / f"{stem}.md"), "-o", str(sub / f"{stem}.docx")])
    format_docx(sub / f"{stem}.docx", double=False)
    if email:
        PRIVATE.mkdir(parents=True, exist_ok=True)
        tmp = PRIVATE / f"{stem}.md"
        tmp.write_text(text.replace("{EMAIL_SUFFIX}", suffix), encoding="utf-8")
        _pandoc([str(tmp), "-o", str(PRIVATE / f"{stem}.docx")])
        format_docx(PRIVATE / f"{stem}.docx", double=False)
        tmp.unlink()


def submission(extra: dict, wc: dict) -> None:
    sub = ROOT / "submission"
    sub.mkdir(exist_ok=True)
    figures_for(sub / "figures")
    freeze = json.loads((ROOT / "docs" / "plan_freeze.json").read_text())
    ledger = pd.read_csv(ROOT / "docs" / "issue_decision_ledger.csv")
    esm1 = "\n\n".join([
        f"# Electronic Supplementary Material 1\n\n{TITLE}",
        "## A. Analysis plan with dated amendments\n\n" + re.sub(r"^# ", "### ", (ROOT / "docs/analysis_plan.md").read_text(), flags=re.M),
        "## B. Plan and configuration checksums at the time the plan was written\n\n"
        + f"Recorded {freeze['frozen_utc']}.\n\n" + md_table(pd.DataFrame(list(freeze["files"].items()), columns=["file", "sha256"]), ["l", "l"]),
        "## C. Contribution decision\n\n" + re.sub(r"^# .*\n", "", (ROOT / "docs/contribution_decision.md").read_text()),
        "## D. Issue and decision log\n\n" + md_table(ledger.fillna(""), ["l"] * len(ledger.columns)),
    ])
    (sub / "ESM1_analysis_plan_and_decision_log.md").write_text(esm1, encoding="utf-8")
    _pandoc([str(sub / "ESM1_analysis_plan_and_decision_log.md"), "-o", str(sub / "ESM1_analysis_plan_and_decision_log.docx")])
    format_docx(sub / "ESM1_analysis_plan_and_decision_log.docx", double=False)
    shutil.copy2(MS / "manuscript.docx", sub / "manuscript.docx")
    shutil.copy2(MS / "supplementary_material.docx", sub / "ESM2_supplementary_tables.docx")
    format_docx(sub / "ESM2_supplementary_tables.docx", double=False)
    title_page = f"""---
title: "Title page"
---

**Title:** {TITLE}

**Running head:** {RUNNING_HEAD}

**Article type:** Original Research Article

**Author:** Animesh Bose

**Affiliation:** Norlowe Research

**Corresponding author:** Animesh Bose, Norlowe Research.{{EMAIL_SUFFIX}}

**Word counts:** abstract {wc['abstract_words']} words; main text {wc['main_text_words']:,} words (excluding abstract, references, tables, and legends).

**Tables:** 4. **Figures:** 3. **Electronic Supplementary Material:** 3 files.

**Acknowledgments:** None.

**Reporting guideline:** READUS-PV (checklist in ESM 2).
"""
    email = contact_email()
    _two_versions(title_page, "title_page", email, f" Email: {email}" if email else "")
    cover = f"""Dear Editor,

Please consider the enclosed manuscript, "{TITLE}", for publication as an Original Research Article in *Drug Safety*.

Analyses of the FDA quarterly adverse event files rest on choices about case versions, drug roles, and drug-name matching that are usually reported in a sentence. Using the eight most recent quarterly files, the study fixes five drug-class and reaction pairs selected from US labeling, using a broader arthralgia definition than the severe, disabling joint-pain warning, and measures how their reporting odds ratios change across a prespecified factorial of these choices, with every two-by-two cell reported. For some pairs, variation across configurations exceeded a within-configuration confidence-interval width. For DPP-4 inhibitors and arthralgia, the role rule moved the estimate across 1; the paper identifies the reports responsible. The work builds on duplicate-report and drug-name standardization studies published in *Drug Safety*. An item-by-item READUS-PV mapping is included, with the limits of its application to this methods study stated.

I designed and conducted this study, verified its results, and reviewed and revised the manuscript. Claude Code (Anthropic) and ChatGPT (OpenAI) were used as tools for software development, data analysis, literature searching, and manuscript drafting and formatting, as stated in the Methods. Codex (OpenAI) assisted with language editing, document formatting, and reproducibility checks.

I confirm that the manuscript is original, has not been published, is not under consideration elsewhere, and that I am the sole author. No specific grant funding supported the work. I own Norlowe Research, the organization through which the work was conducted, and have no other conflicts of interest. The study used only publicly available, de-identified FDA data; the complete code and aggregate outputs are provided as supplementary material.

Thank you for your consideration.

Sincerely,

Animesh Bose  
Norlowe Research{{EMAIL_SUFFIX}}
"""
    _two_versions(cover, "cover_letter", email, f"  \n{email}" if email else "")
    (sub / "author_information.md").write_text(
        "# Author information\n\n**Animesh Bose**, Norlowe Research.\n\n\n\nAuthor contributions (CRediT, sole author): "
        "conceptualization, methodology, software, validation, formal analysis, investigation, data curation, visualization, "
        "writing (original draft, and review and editing), and project administration.\n", encoding="utf-8")
