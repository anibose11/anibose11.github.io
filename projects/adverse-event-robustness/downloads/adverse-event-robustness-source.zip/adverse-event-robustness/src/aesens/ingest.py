"""Build stage, part 1: stream quarterly ASCII members from the cached ZIPs into column-limited Parquet.

Nothing is extracted to disk. Each member is decoded line by line, split on the '$' delimiter,
checked against its header width, and written to Parquet in fixed-size batches. Lines whose field
count is short are joined with the following physical line once (embedded line breaks occur in
free-text fields); anything still malformed is counted and written to a reject file, never guessed.
"""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path, PurePosixPath

import pyarrow as pa
import pyarrow.parquet as pq

from .common import ROOT, path, read_json, rel, study, utc_now, write_json

# Columns retained per table. Every other source column is dropped at read time to control disk use.
KEEP = {
    "DEMO": ["primaryid", "caseid", "caseversion", "i_f_code", "event_dt", "mfr_dt", "init_fda_dt", "fda_dt",
             "rept_cod", "mfr_sndr", "lit_ref", "age", "age_cod", "sex", "occp_cod", "reporter_country", "occr_country",
             "rept_dt"],
    "DRUG": ["primaryid", "caseid", "drug_seq", "role_cod", "drugname", "prod_ai", "route", "nda_num"],
    "REAC": ["primaryid", "caseid", "pt"],
    "OUTC": ["primaryid", "caseid", "outc_cod"],
    "DELE": ["caseid"],
}
MEMBER_RE = re.compile(r"^(DEMO|DRUG|REAC|OUTC|DELETE|DELE)(\d{2})Q(\d)\.TXT$", re.I)
BATCH_ROWS = 250_000
LOG = ROOT / "outputs" / "build" / "ingest_log.json"


def _find_members(zf: zipfile.ZipFile) -> dict[str, str]:
    found = {}
    for name in zf.namelist():
        m = MEMBER_RE.match(PurePosixPath(name.replace("\\", "/")).name)
        if m:
            tbl = m.group(1).upper()
            tbl = "DELE" if tbl.startswith("DELE") else tbl
            if tbl in found:
                raise RuntimeError(f"Duplicate member for {tbl}: {found[tbl]} and {name}")
            found[tbl] = name
    return found


def _decode(raw: bytes) -> str:
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def _parse_member(zf: zipfile.ZipFile, member: str, table: str, quarter: str, out: Path, rejects: Path) -> dict:
    keep = KEEP[table]
    stats = {"member": member, "physical_lines": 0, "data_rows": 0, "joined_rows": 0, "rejected_rows": 0,
             "header": None, "columns_missing": []}
    with zf.open(member) as fh:
        stream = io.BufferedReader(fh, buffer_size=1 << 20)
        first = _decode(stream.readline()).rstrip("\r\n")
        stats["physical_lines"] += 1
        header = [h.strip().lower() for h in first.split("$")]
        if header and header[-1] == "":
            header = header[:-1]
        has_header = "caseid" in header or "primaryid" in header
        if table == "DELE" and not has_header:
            # Deletion lists are a bare column of CASEIDs; the first line is data.
            header = ["caseid"]
            pending_first = first
        else:
            pending_first = None
        stats["header"] = header
        width = len(header)
        idx = {}
        for c in keep:
            if c in header:
                idx[c] = header.index(c)
            else:
                stats["columns_missing"].append(c)
        cols = {c: [] for c in keep}
        writer = None
        schema = pa.schema([(c, pa.string()) for c in keep] + [("src_quarter", pa.string())])
        rej_fh = None

        def flush():
            nonlocal writer, cols
            n = len(cols[keep[0]])
            if n == 0:
                return
            arrays = [pa.array(cols[c], type=pa.string()) for c in keep] + [pa.array([quarter] * n, type=pa.string())]
            tbl = pa.Table.from_arrays(arrays, schema=schema)
            if writer is None:
                writer = pq.ParquetWriter(out, schema, compression="zstd")
            writer.write_table(tbl)
            cols = {c: [] for c in keep}

        def emit(fields):
            for c in keep:
                if c in idx:
                    v = fields[idx[c]].strip()
                    cols[c].append(v if v != "" else None)
                else:
                    cols[c].append(None)
            stats["data_rows"] += 1
            if len(cols[keep[0]]) >= BATCH_ROWS:
                flush()

        def lines():
            if pending_first is not None:
                yield pending_first
            for raw in stream:
                stats["physical_lines"] += 1
                yield _decode(raw).rstrip("\r\n")

        def split(s):
            f = s.split("$")
            if len(f) == width + 1 and f[-1] == "":
                f = f[:-1]
            return f

        def reject(s):
            nonlocal rej_fh
            stats["rejected_rows"] += 1
            if rej_fh is None:
                rej_fh = open(rejects, "a", encoding="utf-8")
            rej_fh.write(f"{quarter}\t{table}\t{s[:500]}\n")

        carry, joins = None, 0
        for line in lines():
            if carry is not None:
                joined = carry + " " + line
                f = split(joined)
                if len(f) == width:
                    emit(f)
                    stats["joined_rows"] += 1
                    carry, joins = None, 0
                    continue
                if len(f) < width and joins < 5:
                    carry, joins = joined, joins + 1
                    continue
                # The fragment cannot be completed; reject it and evaluate the current line alone.
                reject(carry)
                carry, joins = None, 0
            if line == "":
                continue
            f = split(line)
            if len(f) == width:
                emit(f)
            elif len(f) < width:
                carry, joins = line, 1
            else:
                reject(line)
        if carry is not None:
            reject(carry)
        flush()
        if writer is not None:
            writer.close()
        else:
            pq.write_table(pa.Table.from_arrays([pa.array([], type=pa.string())] * (len(keep) + 1), schema=schema),
                           out, compression="zstd")
        if rej_fh:
            rej_fh.close()
    return stats


def run(force: bool = False) -> dict:
    cfg = study()
    manifest = read_json(ROOT / "source_manifest.json")
    pqdir = path("parquet")
    rejects = ROOT / "outputs" / "build" / "rejected_lines.tsv"
    rejects.parent.mkdir(parents=True, exist_ok=True)
    log = read_json(LOG) if LOG.exists() and not force else {"quarters": {}}
    for q in cfg["quarters"]:
        qid = q["id"]
        meta = manifest["quarters"][qid]
        prev = log["quarters"].get(qid, {})
        if not force and prev.get("source_sha256") == meta["sha256"] and all(
                (pqdir / t.lower() / f"{qid}.parquet").exists()
                for t, v in prev["tables"].items() if v.get("status") == "ingested"):
            print(f"[ingest] {qid}: parquet current")
            continue
        zpath = ROOT / meta["path"]
        qlog = {"source_sha256": meta["sha256"], "ingested_utc": utc_now(), "tables": {}}
        with zipfile.ZipFile(zpath) as zf:
            members = _find_members(zf)
            for table in KEEP:
                if table not in members:
                    qlog["tables"][table] = {"status": "absent_in_release"}
                    continue
                out = pqdir / table.lower() / f"{qid}.parquet"
                out.parent.mkdir(parents=True, exist_ok=True)
                st = _parse_member(zf, members[table], table, qid, out, rejects)
                st["parquet"] = rel(out)
                st["status"] = "ingested"
                qlog["tables"][table] = st
                print(f"[ingest] {qid} {table}: {st['data_rows']:,} rows "
                      f"(joined {st['joined_rows']}, rejected {st['rejected_rows']})", flush=True)
        qlog["tables"] = {k: v for k, v in qlog["tables"].items()}
        log["quarters"][qid] = qlog
        write_json(LOG, log)
    write_json(LOG, log)
    return log
