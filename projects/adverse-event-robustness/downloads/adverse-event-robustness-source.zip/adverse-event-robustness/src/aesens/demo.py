"""Fast end-to-end demo on SYNTHETIC fixture archives, in an isolated temporary project root.

Shows that acquisition metadata, ingestion, case construction, drug matching and the two-by-two tables run
together. The records are invented; the output says nothing about any drug.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import yaml

from .common import ROOT


def run(keep: bool = False) -> Path:
    tmp = Path(tempfile.mkdtemp(prefix="aesens-demo-"))
    for sub in ("config", "sql"):
        shutil.copytree(ROOT / sub, tmp / sub)
    shutil.copytree(ROOT / "data" / "cache" / "rxnav", tmp / "data" / "cache" / "rxnav")
    sys.path.insert(0, str(ROOT / "tests" / "fixtures"))
    import make_fixture

    zips = make_fixture.build(tmp / "data" / "raw")
    study = yaml.safe_load((tmp / "config" / "study.yaml").read_text())
    study["snapshot_label"] = "SYNTHETIC FIXTURE (not FDA data)"
    study["quarters"] = [{"id": q, "url": "synthetic://fixture"} for q in zips]
    (tmp / "config" / "study.yaml").write_text(yaml.safe_dump(study, sort_keys=False))
    man = {"study_id": "synthetic-demo", "quarters": {}}
    for q, p in zips.items():
        man["quarters"][q] = {"quarter": q, "path": p.relative_to(tmp).as_posix(), "bytes": p.stat().st_size,
                              "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "members": [],
                              "response_headers": {"Last-Modified": "synthetic"}}
    (tmp / "source_manifest.json").write_text(json.dumps(man, indent=2))
    env = dict(os.environ, AESENS_ROOT=str(tmp))
    for stage in ("build", "analyze"):
        subprocess.run([sys.executable, "-m", "aesens", stage], env=env, check=True)
    import pandas as pd

    d = pd.read_csv(tmp / "outputs" / "runs" / "primary" / "association_counts.csv")
    v = d[d.analysis == "principal"][["variant", "association", "a", "b", "c", "d", "n", "status"]]
    print("\nSYNTHETIC FIXTURE RESULTS (invented records; software demonstration only)")
    print(v.to_string(index=False))
    if not keep:
        shutil.rmtree(tmp)
        print("\n[demo] temporary project removed")
    else:
        print(f"\n[demo] kept at {tmp}")
    return tmp
