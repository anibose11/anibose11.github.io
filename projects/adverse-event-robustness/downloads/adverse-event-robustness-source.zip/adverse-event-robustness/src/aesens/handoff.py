"""Private handoff files: machine-readable project record, validation record, and verified results."""
from __future__ import annotations

import json

from .common import ROOT, read_json, utc_now, write_json
from .context import build

SLUG = "adverse-event-robustness"
STATUS = ROOT / "config" / "project_status.json"


def run(public_files: list[dict], source: dict) -> None:
    c = build()
    A, f = c["A"], c["flow"]
    st = read_json(STATUS)
    ver = ROOT / "outputs" / "verification" / "package_verification.json"
    verification = read_json(ver) if ver.exists() else None
    findings = []
    for aid in c["ORDER"]:
        v1 = A[aid]["v"]["V1"]
        findings.append({"association": aid, "label": A[aid]["label"], "configuration": "V1 (primary)",
                         "a": int(v1.a), "b": int(v1.b), "c": int(v1.c), "d": int(v1.d),
                         "ror": round(v1.ror, 3), "ci95": [round(v1.ci_low, 3), round(v1.ci_high, 3)],
                         "case_level_ror_range": [round(A[aid]["case_min"], 3), round(A[aid]["case_max"], 3)],
                         "evidence_path": "outputs/runs/primary/association_counts.csv; outputs/runs/primary/robustness_summary.csv"})
    rec = {
        "slug": SLUG,
        "title": "Adverse-event reporting odds ratios under alternative case definitions",
        "featured": False,
        "summary": (f"Processing-sensitivity study of reporting odds ratios for five prespecified SGLT2 and DPP-4 inhibitor "
                    f"reaction pairs in the FDA quarterly adverse event files 2024Q3 to 2026Q2 ({f['cases_retained_after_deletion']:,} "
                    "retained cases), across eight case-construction, drug-role and drug-name configurations."),
        "computational_completion_status": st["computational_completion_status"],
        "manuscript_status": st["manuscript_status"],
        "unresolved_prerequisites": st["unresolved_prerequisites"],
        "data_versions": {"source": "FDA quarterly data extract ASCII files (FAERS; AEMS pages)", "quarters": list(c["source_hashes"].keys()),
                          "archive_sha256": c["source_hashes"], "rxnav_version": c["rxnav_version"],
                          "retrieved": "2026-10-07"},
        "key_limitations": [
            "Spontaneous reports: no exposure denominator, selective and stimulated reporting, no causal inference.",
            "CASEID collapsing does not remove duplicates FDA has not linked; no probabilistic duplicate detection.",
            "Latest version means latest within the eight acquired files.",
            "Exact preferred-term strings without the MedDRA hierarchy.",
            "Explanatory profiles of moved units are post hoc and descriptive.",
        ],
        "paths": {"public_page": f"site/projects/{SLUG}/index.html", "report": f"site/projects/{SLUG}/report.html",
                  "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip",
                  "manuscript_project_path": "manuscript/manuscript.md", "claims": "evidence/claims.json"},
        "executed_commands": st["executed_commands"],
        "run_id": c["run_id"],
        "measured_findings": findings,
        "validation": {"source_reconciliation": c["val"]["source_reconciliation"]["parsed_equals_fda_total_all_available"],
                       "second_implementation_identical": c["val"]["second_implementation"]["all_identical"],
                       "rerun": c["val"].get("rerun"), "package_verification": verification},
        "source_archive": source,
        "public_files": public_files,
        "generated_utc": utc_now(),
    }
    write_json(ROOT / "handoff" / f"{SLUG}.json", rec)
    (ROOT / "handoff" / f"{SLUG}-validation.md").write_text(validation_md(c, verification, st), encoding="utf-8")
    (ROOT / "handoff" / "verified_results.md").write_text(verified_md(c), encoding="utf-8")


def validation_md(c, verification, st) -> str:
    v = c["val"]
    rr = v.get("rerun") or {}
    lines = [
        "# Validation record: adverse-event-robustness", "",
        f"Run ID: `{c['run_id']}`", "",
        "## 1. Software tests (synthetic fixtures)", "",
        st.get("tests_summary", "See package verification below."), "",
        "Fixtures are invented records that exercise version ordering, ties, FAQ 29 duplicates, deletions, the FAQ 30",
        "primary-suspect fallback, DN rows, many-to-many rows, salt and brand matching, and same-stem non-members.",
        "They are not study data.", "",
        "## 2. Source reconciliation (real files)", "",
        f"- Member files checked: {v['source_reconciliation']['files_checked']}; raw newline counts agree with the parser: "
        f"{v['source_reconciliation']['physical_lines_agree_all']}.",
        f"- Files with an FDA-printed total: {v['source_reconciliation']['fda_totals_available']}; parsed rows equal the printed total in all: "
        f"{v['source_reconciliation']['parsed_equals_fda_total_all_available']}.",
        f"- Rejected lines: {v['source_reconciliation']['rows_rejected_total']}; joined lines: {v['source_reconciliation']['rows_joined_total']}.", "",
        "## 3. Structural checks", "",
    ]
    for k, val in v["structural_checks"].items():
        lines.append(f"- {k}: {json.dumps(val)}")
    lines += ["", "## 4. Second implementation", "",
              f"- {v['second_implementation']['rows_compared']} case-level tables compared; all identical: {v['second_implementation']['all_identical']}.",
              f"- Nature: {v['second_implementation']['nature']}.", "",
              "## 5. Deterministic rerun", ""]
    if rr:
        lines += [f"- Rows compared: {rr['rows_compared']}; counts identical: {rr['counts_identical']}; maximum relative ROR difference: "
                  f"{rr['max_relative_ror_difference']:.3g} (tolerance {rr['tolerance']:.0e}); within tolerance: {rr['within_tolerance']}.",
                  f"- Run IDs: {rr['run_id_primary']} and {rr['run_id_rerun']}."]
    else:
        lines.append("- Not yet run.")
    lines += ["", "## 6. Package verification", ""]
    if verification:
        for k, val in verification.items():
            lines.append(f"- {k}: {json.dumps(val) if not isinstance(val, str) else val}")
    else:
        lines.append("- Not yet run.")
    lines += ["", "## 7. Author verification", "", st.get("author_verification", ""), ""]
    rc_path = ROOT / "outputs" / "validation" / "independent_recheck.json"
    if rc_path.exists():
        rc = read_json(rc_path)
        lines += ["### Independent re-check of the seven steps", "",
                  f"- Sources: archive URLs listed on the live FDA index, ETag and Last-Modified unchanged, local SHA-256 equals manifest: {rc['1_sources_and_checksums']['all_ok']}.",
                  f"- FDA documentation rules (FAQ 29, 30, 31, 44; PRIMARYID definition; latest-version statement) present in every release: {rc['2_fda_documentation_rules']['core_rules_in_every_release']}; DN documented in {len(rc['2_fda_documentation_rules']['dn_documented_quarters'])} releases from 2024Q4.",
                  f"- Case-version sample read from the raw DEMO files: {rc['3_case_version_sample']['selected_version_agrees']} of {rc['3_case_version_sample']['cases']} selected versions agree ({rc['3_case_version_sample']['raw_versions_found']} raw versions).",
                  f"- Expanded-only drug strings: {rc['4_expanded_only_strings']['rxnav_confirms']} of {rc['4_expanded_only_strings']['strings']} confirmed by RxNav approximate matching; the other {rc['4_expanded_only_strings']['adjudicated_correct_after_inspection']} name the ingredient as a whole word (salt forms absent from RxNorm, combination strings, free text) and were confirmed on inspection.",
                  f"- Reaction-term sources re-read (Farxiga, Januvia, Invokana labeling; FDA 2016 signals page; Chen 2026 metadata): all phrases found: {rc['5_term_provenance']['all_found']}.",
                  f"- ROR and CI recomputed for {rc['6_ror_arithmetic']['rows_recomputed']} rows; maximum relative difference {rc['6_ror_arithmetic']['max_relative_difference']:.1e}.",
                  f"- Every ROR (CI) triple and every comma-grouped integer in the manuscript, project page, and report traces to the outputs: {rc['7_reported_numbers']['all_ok']}.", ""]
    lines += [
              "## 8. What these checks do not establish", "",
              "They show that the files were read completely, that the code paths agree, and that reruns reproduce. They do not",
              "validate any association clinically, do not resolve unlinked duplicates, and are not external expert review.", ""]
    return "\n".join(lines)


def verified_md(c) -> str:
    A, f, n = c["A"], c["flow"], c["n"]
    ar = A["DPP4I_ARTHRALGIA"]
    lines = [
        "# Verified results (private, for later editing)", "",
        "Only methods and measured results that the run produced, each with its evidence path.", "",
        "## Methods actually used", "",
        "- Python 3.13 pipeline with DuckDB SQL over column-limited Parquet; resumable stages acquire, build, analyze, validate, render, package.",
        f"- Eight FDA quarterly ASCII extracts (2024Q3 to 2026Q2), checksummed (source_manifest.json); {n(f['demo_rows_delivered'])} report rows.",
        "- Case construction by CASEID with latest available version, FDA FAQ 29 duplicate rule, FDA deletion lists, FAQ 30 primary-suspect rule with DN rows excluded.",
        "- Drug classes from RxClass (FDA EPC and MED-RT); strict versus RxNav-expanded name matching; frozen RxNav snapshot.",
        "- Eight-configuration factorial plus four single-change secondary analyses; reporting odds ratios with Woolf intervals.",
        "- Validation: row reconciliation against FDA-printed totals, structural checks, a pandas re-implementation, deterministic rerun, synthetic-fixture tests.", "",
        "## Measured results", "",
        f"- Retained cases: {n(f['cases_retained_after_deletion'])} (outputs/build/case_construction_flow.json).",
    ]
    for aid in c["ORDER"]:
        v1 = A[aid]["v"]["V1"]
        lines.append(f"- {A[aid]['label']}: V1 ROR {c['ci'](v1)}, a = {n(v1.a)}; case-level range {A[aid]['case_min']:.2f} to {A[aid]['case_max']:.2f} "
                     "(outputs/runs/primary/association_counts.csv, robustness_summary.csv).")
    lines += [f"- Arthralgia direction change: V1 {ar['v']['V1'].ror:.2f}, V3 {ar['v']['V3'].ror:.2f} (association_counts.csv).",
              "- Reconciliation: parsed rows equal all FDA-printed totals; pandas re-implementation identical for 20 tables (outputs/validation/).", "",
              "## Not claimed", "",
              "- No deployment, collaborator, external review, publication, citation, user adoption, or time saving.", ""]
    return "\n".join(lines)
