"""Static project page and full report page under site/projects/<slug>/. No external requests, system fonts."""
from __future__ import annotations

import html
import json
import shutil

import pandas as pd

from .common import ROOT
from .context import SHORT, build
from .manuscript import secondary_label

SLUG = "adverse-event-robustness"
SITE = ROOT / "site" / "projects" / SLUG
TITLE = "Adverse-event reporting odds ratios under alternative case definitions"

CSS = """
:root{color-scheme:light;--bg:#fcfcfb;--panel:#ffffff;--ink:#16161a;--ink2:#4a4945;--muted:#6b6a65;--rule:#e2e1dc;
--accent:#1c5cab;--accent-soft:#eef4fc;--mono:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
--sans:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;--measure:44rem;--wide:64rem}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 var(--sans)}
a{color:var(--accent);text-underline-offset:2px}
a:focus-visible,button:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.skip{position:absolute;left:-999px;top:0;background:var(--panel);padding:.5rem 1rem}
.skip:focus{left:1rem;z-index:10}
header.site,main,footer{padding:0 16px}
header.site .inner,main>section,main>article,footer .inner{max-width:var(--wide);margin:0 auto}
header.site{border-bottom:1px solid var(--rule);background:var(--panel)}
header.site .inner{display:flex;gap:1rem;justify-content:space-between;align-items:center;padding:.75rem 0;flex-wrap:wrap}
header.site nav a{margin-right:1rem;font-size:.95rem}
.eyebrow{font-size:.8rem;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);margin:2rem 0 .25rem}
h1{font-size:clamp(1.6rem,4vw,2.3rem);line-height:1.2;margin:.2rem 0 1rem;max-width:var(--measure)}
h2{font-size:1.35rem;margin:2.5rem 0 .75rem;padding-top:.5rem;border-top:1px solid var(--rule)}
h3{font-size:1.05rem;margin:1.5rem 0 .5rem}
p,li{max-width:var(--measure)}
.lede{font-size:1.15rem;color:var(--ink2)}
.question{background:var(--accent-soft);border-left:4px solid var(--accent);padding:1rem 1.25rem;max-width:var(--measure);margin:1rem 0 1.5rem}
figure{margin:1.5rem 0;max-width:var(--wide)}
figure img{width:100%;height:auto;border:1px solid var(--rule);background:#fcfcfb}
figcaption{font-size:.9rem;color:var(--ink2);margin-top:.5rem;max-width:var(--measure)}
.facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(13rem,1fr));gap:.75rem;margin:1rem 0;max-width:var(--wide)}
.fact{background:var(--panel);border:1px solid var(--rule);padding:.75rem 1rem}
.fact b{display:block;font-size:1.25rem}
.fact span{font-size:.88rem;color:var(--ink2)}
.tablewrap{overflow-x:auto;max-width:var(--wide);border:1px solid var(--rule);background:var(--panel);margin:.75rem 0 1.5rem}
table{border-collapse:collapse;width:100%;font-size:.88rem;font-variant-numeric:tabular-nums}
caption{text-align:left;padding:.6rem .75rem;font-weight:600;color:var(--ink)}
th,td{padding:.4rem .6rem;border-top:1px solid var(--rule);text-align:right;white-space:nowrap}
th:first-child,td:first-child{text-align:left;white-space:normal}
thead th{background:#f6f5f2;font-weight:600}
tr.primary td{font-weight:600}
tr.diag td{color:var(--ink2);background:#faf9f6}
.controls{display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;margin:.5rem 0}
select{font:inherit;padding:.35rem .5rem;border:1px solid #b9b8b2;border-radius:4px;background:var(--panel);color:var(--ink)}
code,kbd,pre{font-family:var(--mono);font-size:.88em}
pre{background:#f3f2ef;border:1px solid var(--rule);padding:.75rem 1rem;overflow-x:auto;max-width:var(--wide)}
.note{font-size:.9rem;color:var(--ink2)}
ul.files{list-style:none;padding:0}
ul.files li{padding:.35rem 0;border-bottom:1px solid var(--rule)}
ul.files .meta{color:var(--muted);font-size:.85rem;margin-left:.5rem}
footer{border-top:1px solid var(--rule);margin-top:3rem;background:var(--panel)}
footer .inner{padding:1.25rem 0;font-size:.9rem;color:var(--ink2)}
article.report{max-width:var(--wide)}
article.report h1{max-width:var(--wide)}
article.report table{font-size:.85rem;display:block;overflow-x:auto;max-width:100%}
article.report .table-wrap,article.report div.sourceCode{overflow-x:auto}
article.report figure img{max-width:100%}
article.report ol.refs li{margin-bottom:.4rem;font-size:.92rem}

/* Keep report prose within the viewport; wide tables and code scroll locally. */
main{min-width:0;max-width:100%}
main>article,main>section,article.report section{min-width:0}
article.report p,article.report li,article.report a,article.report code{overflow-wrap:anywhere}
article.report table,article.report .table-wrap,article.report div.sourceCode,article.report pre{max-width:100%;overflow-x:auto}
article.report figure,article.report img{max-width:100%}
@media (max-width:640px){body{font-size:15px}th,td{padding:.35rem .45rem}}
@media print{header.site,.skip,.controls{display:none}}
"""

JS = """
(function(){
  var sel=document.getElementById('assoc-select');
  if(!sel){return;}
  var blocks=document.querySelectorAll('[data-assoc-block]');
  sel.hidden=false; document.getElementById('assoc-label').hidden=false;
  function show(v){blocks.forEach(function(b){b.hidden=(v!=='all' && b.getAttribute('data-assoc-block')!==v);});
    var s=document.getElementById('assoc-status'); if(s){s.textContent=v==='all'?'Showing all five associations.':'Showing one association.';}}
  sel.addEventListener('change',function(){show(sel.value);});
  show(sel.value);
})();
"""


def _esc(s):
    return html.escape(str(s))


def _dims(name):
    from PIL import Image
    with Image.open(ROOT / "outputs" / "figures" / f"{name}.png") as im:
        w, h = im.size
    return f'width="{w}" height="{h}"'


def _shell(title, body, desc, rel_css="assets/site.css"):
    import hashlib
    ver = hashlib.sha256((CSS + JS).encode()).hexdigest()[:8]
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{_esc(title)}</title>
<meta name="description" content="{_esc(desc)}">
<link rel="stylesheet" href="{rel_css}?v={ver}">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site"><div class="inner">
<a href="./">Adverse-event processing sensitivity</a>
<nav aria-label="Project"><a href="./">Overview</a><a href="report.html">Full report</a><a href="./#downloads">Downloads</a></nav>
</div></header>
<main id="main">
{body}
</main>
<footer><div class="inner">

<p>Data: FDA quarterly adverse event data extract files (FAERS, now hosted on the FDA Adverse Event Monitoring System pages), 2024Q3 to 2026Q2. FDA does not endorse this analysis. Reporting odds ratios describe reporting patterns, not risk.</p>
</div></footer>
<script src="assets/explorer.js?v={ver}"></script>
</body>
</html>
"""


def _assoc_tables(c) -> str:
    d = pd.read_csv(ROOT / "outputs/runs/primary/association_counts.csv")
    out = []
    for a in c["ORDER"]:
        s = d[d.association == a]
        rows = []
        for r in s.itertuples():
            cls = "primary" if r.variant == "V1" else ("diag" if r.unit == "version" else "")
            est = f"{r.ror:.2f}" if r.status == "reported" else r.status.replace("_", " ")
            ci = f"{r.ci_low:.2f} to {r.ci_high:.2f}" if r.status == "reported" else ""
            lab = r.variant_label if r.analysis == "principal" else secondary_label(r.variant, a.split("_")[0])
            rows.append(f'<tr class="{cls}"><td>{_esc(r.variant)} {_esc(lab)}</td><td>{r.a:,}</td><td>{r.b:,}</td>'
                        f'<td>{r.c:,}</td><td>{r.d:,}</td><td>{est}</td><td>{ci}</td></tr>')
        out.append(f"""<div data-assoc-block="{a}"><div class="tablewrap"><table>
<caption>{_esc(SHORT[a])}: cells and reporting odds ratio by configuration</caption>
<thead><tr><th scope="col">Configuration</th><th scope="col">a</th><th scope="col">b</th><th scope="col">c</th><th scope="col">d</th><th scope="col">ROR</th><th scope="col">95% CI</th></tr></thead>
<tbody>{''.join(rows)}</tbody></table></div></div>""")
    return "\n".join(out)


def _downloads(files) -> str:
    items = []
    for label, name, desc in files:
        p = SITE / "downloads" / name
        size = p.stat().st_size if p.exists() else 0
        kb = f"{size / 1024:,.0f} KB" if size < 1024 * 1024 else f"{size / 1024 / 1024:,.1f} MB"
        items.append(f'<li><a href="downloads/{_esc(name)}">{_esc(label)}</a><span class="meta">{_esc(desc)}, {kb}</span></li>')
    return "<ul class=\"files\">" + "".join(items) + "</ul>"


DOWNLOADS = [
    ("Source archive (code, SQL, configuration, tests, documentation)", "adverse-event-robustness-source.zip", "ZIP"),
    ("Aggregate results workbook with definitions sheet", "adverse-event-robustness-results.xlsx", "Excel"),
    ("All configurations, long format (one row per association and configuration)", "association_configurations_long.csv", "CSV"),
    ("Analysis plan with dated amendments", "analysis_plan.md", "Markdown"),
    ("Reaction term provenance", "term_provenance.csv", "CSV"),
    ("Verified drug names (RxNav snapshot)", "verified_drug_names.csv", "CSV"),
    ("Data dictionary", "data_dictionary.csv", "CSV"),
    ("Release compatibility table", "transition_table.csv", "CSV"),
    ("Supplementary material (tables S1 to S8)", "supplementary_material.html", "HTML"),
]


def copy_assets():
    (SITE / "assets").mkdir(parents=True, exist_ok=True)
    (SITE / "downloads").mkdir(parents=True, exist_ok=True)
    (SITE / "assets" / "site.css").write_text(CSS.strip() + "\n", encoding="utf-8")
    (SITE / "assets" / "explorer.js").write_text(JS.strip() + "\n", encoding="utf-8")
    for f in ["fig1_ror_by_configuration", "fig2_case_construction_flow", "fig3_cell_a_composition", "figS1_drug_rows_by_role"]:
        for ext in ("svg", "png"):
            shutil.copy2(ROOT / "outputs/figures" / f"{f}.{ext}", SITE / "assets" / f"{f}.{ext}")
    for src, name in [("outputs/adverse-event-robustness-results.xlsx", "adverse-event-robustness-results.xlsx"),
                      ("outputs/tableau/association_configurations_long.csv", "association_configurations_long.csv"),
                      ("docs/analysis_plan.md", "analysis_plan.md"), ("docs/term_provenance.csv", "term_provenance.csv"),
                      ("outputs/mapping/verified_drug_names.csv", "verified_drug_names.csv"),
                      ("docs/data_dictionary.csv", "data_dictionary.csv"), ("docs/transition_table.csv", "transition_table.csv"),
                      ("manuscript/supplementary_material.html", "supplementary_material.html")]:
        if (ROOT / src).exists():
            shutil.copy2(ROOT / src, SITE / "downloads" / name)


def index_page(c) -> str:
    A, f, n = c["A"], c["flow"], c["n"]
    ar, pe, dka = A["DPP4I_ARTHRALGIA"], A["DPP4I_PEMPHIGOID"], A["SGLT2I_DKA"]
    fo, pa = A["SGLT2I_FOURNIER"], A["DPP4I_PANCREATITIS"]
    prof_ss = ar["prof"]["cell_a_secondary_suspect_only"]
    prof_ps = ar["prof"]["cell_a_primary_suspect"]
    mp = pe["mprof"]
    body = f"""
<section>
<p class="eyebrow">Pharmacovigilance methods study</p>
<h1>{_esc(TITLE)}</h1>
<p class="lede">For DPP-4 inhibitors and arthralgia, counting secondary-suspect drug listings changed the reporting odds ratio from below 1 to above 1. I traced that change to the underlying reports, then compared drug-role, name-matching and counting rules across five known safety concerns.</p>
<div class="question"><p><strong>Question.</strong> For five drug-class and reaction pairs that FDA has already communicated (SGLT2 inhibitors with ketoacidosis and Fournier's gangrene; DPP-4 inhibitors with pemphigoid, arthralgia and pancreatitis), how far do reporting odds ratios move across eight prespecified ways of processing the same eight quarterly files? The configurations vary the counting unit, the reporter-designated drug role, and how drug names are matched to ingredients.</p></div>
<figure>
<div class="figscroll"><img src="assets/fig1_ror_by_configuration.svg" {_dims("fig1_ror_by_configuration")} alt="Dot-and-interval plot with five panels, one per drug-class and reaction pair. Each panel shows the reporting odds ratio and 95% interval under eight processing configurations. For DPP-4 inhibitors and arthralgia, the estimates are above 1 when any suspect role counts and below 1 when only the primary suspect counts. The other four pairs stay above 1 in every configuration; the case-level pemphigoid estimates range from {pe['case_min']:.0f} to {pe['case_max']:.0f}."></div>
<figcaption>Reporting odds ratio (log scale) and Woolf 95% interval for each association under the eight principal configurations. Blue: primary or secondary suspect counts; orange: primary suspect only. Circles: expanded name mapping; squares: strict ingredient matching. Hollow markers on the shaded band count every report version and are diagnostic only. <a href="assets/fig1_ror_by_configuration.png">PNG version</a>.</figcaption>
</figure>
</section>

<section aria-labelledby="findings">
<h2 id="findings">Which processing choices changed the estimates</h2>
<div class="facts">
<div class="fact"><b>{n(f['cases_retained_after_deletion'])}</b><span>cases retained from {n(f['demo_rows_delivered'])} report rows in eight quarterly files</span></div>
<div class="fact"><b>{c['r2'](ar['case_min'])} to {c['r2'](ar['case_max'])}</b><span>arthralgia ROR range across the four case-level configurations (direction changes)</span></div>
<div class="fact"><b>{c['r1'](pe['case_min'])} to {c['r1'](pe['case_max'])}</b><span>pemphigoid ROR range across the same four configurations</span></div>
<div class="fact"><b>{c['r2'](fo['case_ratio'])}x</b><span>max/min ratio for Fournier's gangrene, the most stable pair</span></div>
</div>
<ul>
<li><strong>Drug role decided the direction for arthralgia.</strong> With any suspect role counted (primary configuration), DPP-4 inhibitors and arthralgia gave ROR {c['ci_short'](ar['v']['V1'])} from {n(ar['v']['V1'].a)} cases. Counting only primary-suspect listings gave {c['ci_short'](ar['v']['V3'])} from {n(ar['v']['V3'].a)} cases. Of the {n(prof_ss.units)} cases that qualified only through a secondary-suspect listing, the median report listed {prof_ss.median_drug_rows:.0f} drugs and {c['pct'](prof_ss.share_20plus_drug_rows, 0)} listed 20 or more; primary-suspect cases had a median of {prof_ps.median_drug_rows:.0f}.</li>
<li><strong>Name matching changed which reports counted as exposed.</strong> Exact ingredient matching missed {n(c['expanded_only']['SGLT2I'])} SGLT2 inhibitor cases and {n(c['expanded_only']['DPP4I'])} DPP-4 inhibitor cases whose drug field carried a salt form (for example dapagliflozin propanediol, sitagliptin phosphate) or only a brand name. Those cases reported pemphigoid less often ({c['pct'](mp['expanded_only_match'].event_share)} against {c['pct'](mp['strict_match'].event_share)}), so adding them lowered the pemphigoid ROR from {c['r1'](pe['v']['V2'].ror)} to {c['r1'](pe['v']['V1'].ror)}.</li>
<li><strong>Counting report versions inflated counts without changing conclusions.</strong> Treating each report version as a unit added {n(f['versions_retained_after_deletion'] - f['cases_retained_after_deletion'])} units to the database and, for ketoacidosis, {n(dka['v']['V5'].a - dka['v']['V1'].a)} to cell a, and lowered that ROR from {c['r1'](dka['v']['V1'].ror)} to {c['r1'](dka['v']['V5'].ror)}.</li>
<li><strong>Some pairs were robust to processing.</strong> Fournier's gangrene stayed between {c['r1'](fo['case_min'])} and {c['r1'](fo['case_max'])}, and pancreatitis between {c['r1'](pa['case_min'])} and {c['r1'](pa['case_max'])}, across the case-level configurations. Agreement across processing rules is not evidence of causation: these are reporting associations without exposure denominators.</li>
</ul>
</section>

<section aria-labelledby="explore">
<h2 id="explore">Counts behind every estimate</h2>
<p>Each table lists the four cells for one association under all twelve analyses: eight principal configurations (V1 to V8) and four secondary analyses (S1 deletion lists not applied, S2 cases first received in the window, S3 SGLT2 inhibitors versus DPP-4 inhibitors, S4 background without unverified same-class names). Except in S3, the background (c, d) contains the other retained reports in the database across all products. S3 uses the other study drug class as its comparator. Rows for V5 to V8 count report versions and are diagnostic.</p>
<div class="controls"><label id="assoc-label" for="assoc-select" hidden>Association</label>
<select id="assoc-select" hidden><option value="all">All five associations</option>
{''.join(f'<option value="{a}">{_esc(SHORT[a])}</option>' for a in c['ORDER'])}
</select><span id="assoc-status" class="note" role="status" aria-live="polite"></span></div>
{_assoc_tables(c)}
<p class="note">a: exposed cases with the event; b: exposed without; c: all other cases with the event; d: all other cases without. In S3, c and d are DPP-4 inhibitor cases for SGLT2 pairs and SGLT2 inhibitor cases for DPP-4 pairs, and cases listing both classes are excluded. The filter only hides tables; it does not recompute anything.</p>
</section>

<section aria-labelledby="data">
<h2 id="data">Data and methods</h2>
<p>The input is the eight most recent FDA quarterly ASCII extracts on the retrieval date (2024Q3 to 2026Q2; {c['archive_bytes'] / 1024 / 1024:,.0f} MB compressed, {n(c['drug_rows'])} drug rows and {n(c['reac_rows'])} reaction rows). Parsed counts matched raw line counts for all 40 member files. They also matched FDA's printed totals for the 32 files that supplied them; the eight deletion lists had no printed total. Reports were collapsed to cases using FDA's documented case and version keys: the latest available version of each CASEID within these eight files, after removing {n(f['cases_deleted_listed'])} cases on FDA's deletion lists. "Latest" means latest in the acquired files, not latest at FDA.</p>
<p>Drug classes came from FDA label classes and MED-RT mechanisms via RxClass, giving six SGLT2 inhibitors and four DPP-4 inhibitors. Reaction terms are exact MedDRA preferred-term strings fixed in the analysis plan before any count was computed. The principal configurations use a database-wide background built before restriction to a drug class. In secondary analysis S3, the comparator is the other study drug class, with cases listing both classes excluded. The measure is the reporting odds ratio with a Woolf interval; estimates need at least 3 exposed cases with the event and no empty cell.</p>
<figure>
<div class="figscroll"><img src="assets/fig2_case_construction_flow.svg" {_dims("fig2_case_construction_flow")} alt="Flow diagram from report rows to report versions, cases, retained cases, and the exposed groups used in the two-by-two tables."></div>
<figcaption>Case construction from the eight quarterly files to the retained cases. The principal analyses use the database-wide background; S3 restricts the comparator to the other study drug class.</figcaption>
</figure>
<h3>Drug roles and name matching</h3>
<p><strong>Which drug roles count as exposure.</strong> FDA's files mark each drug as primary suspect, secondary suspect, concomitant, interacting, or (from the 2024Q4 file onward) not administered. A secondary-suspect listing is part of the reporter's suspicion, but some reports list dozens of suspect drugs. The primary configuration counts both suspect roles; the primary-suspect configurations show what that inclusion contributes.</p>
<p><strong>How strictly names are matched.</strong> FDA's ingredient field often carries salt forms, and some reports give only a brand name. The strict rule requires the exact ingredient name. The expanded rule adds salt forms and brand names that RxNav relates to a class member. Strings that match neither stay unmapped and are listed for review.</p>
<figure>
<div class="figscroll"><img src="assets/fig3_cell_a_composition.svg" alt="Stacked bars showing, for each association, the share of exposed cases with the event that qualify as primary suspect versus only secondary suspect, and by ingredient name versus salt or brand name. Arthralgia is mostly secondary-suspect-only." {_dims("fig3_cell_a_composition")}></div>
<figcaption>How the primary-configuration exposed cases with the event (cell a) qualified. For arthralgia, {c['pct']((ar['comp']['secondary suspect only, ingredient name'] + ar['comp']['secondary suspect only, salt or brand name only']) / ar['v']['V1'].a, 0)} qualified only through a secondary-suspect listing.</figcaption>
</figure>
</section>

<section aria-labelledby="limits">
<h2 id="limits">Limitations</h2>
<ul>
<li>Spontaneous reports have no exposure denominator, are affected by stimulated and selective reporting, and cannot show that a drug caused an event. None of the estimates is a risk, an incidence, or a ranking of drugs.</li>
<li>Collapsing by CASEID does not remove duplicates that FDA has not linked, such as a direct report and a manufacturer report of the same patient. No probabilistic duplicate detection was attempted.</li>
<li>The window holds only versions received in eight quarters. {n(f['cases_latest_is_followup_without_initial_in_window'])} retained cases are represented by a follow-up whose earlier versions predate the window; a separate analysis restricted to cases first received in the window is reported.</li>
<li>Reaction terms are exact preferred-term strings without the MedDRA hierarchy, so related terms outside the lists are not counted. The lists were fixed before results and were not changed.</li>
<li>The descriptive profiles that explain the role and mapping effects were added after the first results were seen, and are labelled post hoc.</li>
</ul>
</section>

<section aria-labelledby="reproduce">
<h2 id="reproduce">Reproduce</h2>
<p>The source archive contains the pipeline (Python and DuckDB SQL), configuration, frozen RxNav responses, tests, and documentation. On macOS or Linux with Python 3.11 or later:</p>
<pre><code>python3 -m venv .venv &amp;&amp; .venv/bin/pip install -r requirements.lock &amp;&amp; .venv/bin/pip install -e .
.venv/bin/python -m pytest -q          # software tests on synthetic fixtures
.venv/bin/aesens demo                  # fast end-to-end run on the synthetic fixture
.venv/bin/aesens all                   # full study: downloads about {c['archive_bytes'] / 1024 / 1024:,.0f} MB from FDA</code></pre>
<p class="note">The demo uses invented records to show the pipeline works; it is not evidence about any drug. On the test machine the full build took about a minute and the analysis a few seconds; see the runtime manifest in the archive.</p>
</section>

<section aria-labelledby="downloads">
<h2 id="downloads">Report and downloads</h2>
<p><a href="report.html">Read the full report</a>.</p>
{_downloads(DOWNLOADS)}
</section>
"""
    return _shell(TITLE, body, "Processing-sensitivity study of reporting odds ratios in FDA quarterly adverse event files, 2024Q3 to 2026Q2.")


def report_page(c) -> str:
    frag = (ROOT / "manuscript" / "build" / "report_fragment.html")
    body = frag.read_text(encoding="utf-8") if frag.exists() else "<p>Report not yet rendered.</p>"
    # Use first person in the portfolio; keep the journal declaration unchanged.
    body = body.replace('Animesh Bose is the owner of Norlowe Research, the organization through which this work was conducted. Animesh Bose has no other conflicts of interest that are directly relevant to the content of this article.', 'I own Norlowe Research, where I conducted this work. I have no other conflicts of interest directly relevant to this article.')
    body = body.replace('Animesh Bose is the owner of\nNorlowe Research, the organization through which this work was\nconducted. Animesh Bose has no other conflicts of interest that are\ndirectly relevant to the content of this article.', 'I own Norlowe Research, where I conducted this work. I have no other conflicts of interest directly relevant to this article.')
    body = f'<article class="report">{body}</article>'
    return _shell("Full report: " + TITLE, body, "Complete scientific report with methods, results, discussion, limitations and references.")


def run() -> str:
    c = build()
    if SITE.exists():
        for sub in ("assets",):
            shutil.rmtree(SITE / sub, ignore_errors=True)
    SITE.mkdir(parents=True, exist_ok=True)
    copy_assets()
    (SITE / "index.html").write_text(index_page(c), encoding="utf-8")
    (SITE / "report.html").write_text(report_page(c), encoding="utf-8")
    return str(SITE.relative_to(ROOT))
