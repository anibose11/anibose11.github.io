"""aesens: case construction and processing-sensitivity analysis for FDA quarterly adverse-event extracts."""
__version__ = "0.1.0"
