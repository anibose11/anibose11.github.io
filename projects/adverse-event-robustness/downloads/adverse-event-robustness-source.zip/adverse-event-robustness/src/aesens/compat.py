"""Release compatibility: headers, documentation revision dates, and FDA record totals per quarter.

Produces docs/transition_table.csv and outputs/build/fda_reported_totals.csv. The FDA totals come from
the per-file statistics PDFs shipped inside each archive and serve as an independent source aggregate
for row reconciliation.
"""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import PurePosixPath

import pandas as pd
from pypdf import PdfReader

from .common import ROOT, read_json, study, write_json

DATA = ("DEMO", "DRUG", "REAC", "OUTC")


def _pdf_text(zf: zipfile.ZipFile, member: str) -> str:
    r = PdfReader(io.BytesIO(zf.read(member)))
    return "\n".join((p.extract_text() or "") for p in r.pages)


def _revised(text: str) -> str | None:
    m = re.search(r"LAST\s+REVISED:\s*([A-Za-z]+\s+\d{4})", text)
    return re.sub(r"\s+", " ", m.group(1)) if m else None


def _fda_total(text: str, table: str) -> int | None:
    # Totals appear in the null-count table, e.g. "CASE 405513 0" (DEMO) or "PT 1431718 0" (REAC).
    pats = {"DEMO": r"\bCASE\s+(\d+)\s+\d+", "REAC": r"\bPT\s+(\d+)\s+\d+",
            "DRUG": r"\b(?:DRUGNAME|ROLE_COD|DRUG_SEQ)\s+(\d+)\s+\d+", "OUTC": r"\bOUTC_COD\s+(\d+)\s+\d+"}
    if table == "OUTC":
        # The outcome report has no null-count table; its total is the sum of the code frequencies.
        codes = re.findall(r"(?m)^(DE|LT|HO|DS|CA|OT|RI)\s+(\d+)\s+[\d.]+", text)
        return sum(int(n) for _, n in codes) if codes else None
    m = re.search(pats[table], text)
    return int(m.group(1)) if m else None


def run() -> pd.DataFrame:
    cfg = study()
    manifest = read_json(ROOT / "source_manifest.json")
    rows, totals = [], []
    ref_headers = None
    for q in cfg["quarters"]:
        qid = q["id"]
        meta = manifest["quarters"][qid]
        with zipfile.ZipFile(ROOT / meta["path"]) as zf:
            names = zf.namelist()
            base = {PurePosixPath(n).name.upper(): n for n in names}
            yyq = f"{qid[2:4]}Q{qid[-1]}"
            headers = {}
            for t in DATA:
                member = base.get(f"{t}{yyq}.TXT")
                with zf.open(member) as fh:
                    headers[t] = fh.readline().decode("latin-1").strip().rstrip("$").lower().split("$")
            dele = base.get(f"DELETE{yyq}.TXT") or base.get(f"DELE{yyq}.TXT")
            asc_text = _pdf_text(zf, base["ASC_NTS.PDF"]) if "ASC_NTS.PDF" in base else ""
            asc = _revised(asc_text) if asc_text else None
            role_codes = "PS, SS, C, I" + (", DN" if re.search(r"\bDN\s+Drug Not Administered", asc_text) else "")
            readme = _revised(_pdf_text(zf, base["README.PDF"])) if "README.PDF" in base else None
            faq_n = None
            if "FAQS.PDF" in base:
                faq = _pdf_text(zf, base["FAQS.PDF"])
                nums = [int(x) for x in re.findall(r"(?m)^\s*(\d{1,2})\.\s", faq)]
                faq_n = max(nums) if nums else None
            for t in DATA:
                stat = base.get(f"{t}{yyq}.PDF")
                total = _fda_total(_pdf_text(zf, stat), t) if stat else None
                totals.append({"quarter": qid, "table": t, "fda_reported_total": total,
                               "source_member": stat or "absent"})
        if ref_headers is None:
            ref_headers = headers
        rows.append({
            "quarter": qid,
            "archive": PurePosixPath(meta["path"]).name,
            "server_last_modified": meta["response_headers"].get("Last-Modified"),
            "readme_last_revised": readme,
            "asc_nts_last_revised": asc,
            "faq_highest_item_number": faq_n,
            "deleted_list_member": dele or "absent",
            "role_cod_values_documented": role_codes,
            **{f"{t.lower()}_columns": len(headers[t]) for t in DATA},
            "headers_identical_to_first_release": all(headers[t] == ref_headers[t] for t in DATA),
            "header_differences": "; ".join(
                f"{t}: +{sorted(set(headers[t]) - set(ref_headers[t]))} -{sorted(set(ref_headers[t]) - set(headers[t]))}"
                for t in DATA if headers[t] != ref_headers[t]) or "none",
            "member_layout": "ASCII/ data folder and Deleted/ folder" if dele else "ASCII/ data folder, no deletion list",
        })
    df = pd.DataFrame(rows)
    (ROOT / "docs").mkdir(exist_ok=True)
    df.to_csv(ROOT / "docs" / "transition_table.csv", index=False)
    tot = pd.DataFrame(totals)
    out = ROOT / "outputs" / "build"
    out.mkdir(parents=True, exist_ok=True)
    tot.to_csv(out / "fda_reported_totals.csv", index=False)
    write_json(out / "compatibility.json", {"all_headers_identical": bool(df.headers_identical_to_first_release.all()),
                                            "quarters": len(df), "reference_headers": ref_headers})
    print(df[["quarter", "readme_last_revised", "asc_nts_last_revised", "headers_identical_to_first_release"]].to_string(index=False))
    return df
