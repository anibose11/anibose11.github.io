"""evidence/claims.json: every headline number mapped to its output file, field, scope, configuration and run."""
from __future__ import annotations

from .common import ROOT, utc_now, write_json
from .context import build

RUNP = "outputs/runs/primary/association_counts.csv"
FLOW = "outputs/build/case_construction_flow.json"


def run() -> list[dict]:
    c = build()
    f, A = c["flow"], c["A"]
    base = {"run_id": c["run_id"], "source_manifest_sha256": c["manifest_sha256"], "source_archive_sha256": c["source_hashes"]}
    claims = []

    def add(cid, statement, value, path, key, scope, configuration="not applicable", numerator=None, denominator=None):
        claims.append({"id": cid, "statement": statement, "value": value, "evidence_path": path, "record_key": key,
                       "numerator": numerator, "denominator": denominator, "analysis_scope": scope,
                       "configuration": configuration})

    scope_all = "FDA quarterly ASCII extracts 2024Q3-2026Q2 (8 files)"
    add("C01", "Report rows (DEMO records) delivered in the eight extracts", f["demo_rows_delivered"], FLOW, "demo_rows_delivered", scope_all)
    add("C02", "Unique report versions (PRIMARYID) after the FAQ 29 rule", f["report_versions_unique_primaryid"], FLOW, "report_versions_unique_primaryid", scope_all)
    add("C03", "Unique cases (CASEID)", f["cases_unique_caseid"], FLOW, "cases_unique_caseid", scope_all)
    add("C04", "Cases removed because they appear on FDA deletion lists", f["cases_deleted_listed"], FLOW, "cases_deleted_listed", scope_all)
    add("C05", "Cases retained: primary unit and background for every table (eligible cohort)", f["cases_retained_after_deletion"], FLOW, "cases_retained_after_deletion", scope_all)
    add("C06", "Report versions retained after deletions (diagnostic unit)", f["versions_retained_after_deletion"], FLOW, "versions_retained_after_deletion", scope_all)
    add("C07", "Retained cases first received in the window (S2 cohort)", f["cases_init_fda_dt_in_window"], FLOW, "cases_init_fda_dt_in_window", scope_all)
    add("C08", "Retained cases whose selected version is a follow-up with no earlier version in the window", f["cases_latest_is_followup_without_initial_in_window"], FLOW, "cases_latest_is_followup_without_initial_in_window", scope_all)
    rec = c["val"]["source_reconciliation"]
    add("C09", "Member files whose parsed rows equal the FDA-printed total (of files with a printed total)", rec["fda_totals_available"],
        "outputs/validation/validation_report.json", "source_reconciliation.parsed_equals_fda_total_all_available", "source reconciliation",
        numerator=rec["fda_totals_available"] if rec["parsed_equals_fda_total_all_available"] else None, denominator=rec["fda_totals_available"])
    si = c["val"]["second_implementation"]
    add("C10", "Case-level two-by-two tables reproduced exactly by the pandas re-implementation", si["rows_compared"] if si["all_identical"] else 0,
        "outputs/validation/second_implementation_comparison.csv", "identical", "software consistency check, V1-V4 x 5 associations",
        numerator=si["rows_compared"] if si["all_identical"] else 0, denominator=si["rows_compared"])
    add("C11", "Cases exposed to SGLT2 inhibitors under V1", c["exposed"]["SGLT2I"], RUNP, "variant=V1, association=SGLT2I_DKA, a+b", "retained cases", "V1")
    add("C12", "Cases exposed to DPP-4 inhibitors under V1", c["exposed"]["DPP4I"], RUNP, "variant=V1, association=DPP4I_PEMPHIGOID, a+b", "retained cases", "V1")
    add("C13", "SGLT2 inhibitor cases found only by the expanded mapping", c["expanded_only"]["SGLT2I"], RUNP, "(a+b) V1 minus (a+b) V2, SGLT2I_DKA", "retained cases", "V1 vs V2")
    add("C14", "DPP-4 inhibitor cases found only by the expanded mapping", c["expanded_only"]["DPP4I"], RUNP, "(a+b) V1 minus (a+b) V2, DPP4I_PEMPHIGOID", "retained cases", "V1 vs V2")
    i = 15
    for aid in c["ORDER"]:
        for v in ["V1", "V2", "V3", "V4", "V5"]:
            r = A[aid]["v"][v]
            add(f"C{i:02d}", f"{A[aid]['label']}: ROR (Woolf 95% CI) under {v}",
                {"ror": round(r.ror, 8), "ci_low": round(r.ci_low, 8), "ci_high": round(r.ci_high, 8), "a": int(r.a), "b": int(r.b), "c": int(r.c), "d": int(r.d)},
                RUNP, f"variant={v}, association={aid}; columns ror, ci_low, ci_high, a, b, c, d", "retained cases" if v != "V5" else "retained report versions (diagnostic)", v,
                numerator=int(r.a), denominator=int(r.n))
            i += 1
        add(f"C{i:02d}", f"{A[aid]['label']}: ROR range across the four case-level configurations",
            {"min": round(A[aid]["case_min"], 4), "max": round(A[aid]["case_max"], 4), "max_over_min": round(A[aid]["case_ratio"], 4)},
            "outputs/runs/primary/robustness_summary.csv", f"association={aid}, scope=case_level_V1_V4", "retained cases", "V1-V4")
        i += 1
    ar = A["DPP4I_ARTHRALGIA"]["prof"]["cell_a_secondary_suspect_only"]
    add(f"C{i:02d}", "DPP-4 inhibitor and arthralgia cases qualifying only as secondary suspect: median drug rows per report (post hoc)",
        {"units": int(ar.units), "median_drug_rows": float(ar.median_drug_rows), "share_20plus_drug_rows": round(float(ar.share_20plus_drug_rows), 4)},
        "outputs/runs/primary/posthoc_role_profile.csv", "association=DPP4I_ARTHRALGIA, group=cell_a_secondary_suspect_only", "V1 cell a", "V1")
    i += 1
    mp = A["DPP4I_PEMPHIGOID"]["mprof"]
    add(f"C{i:02d}", "Pemphigoid share among DPP-4 inhibitor cases matched strictly versus only by the expanded mapping (post hoc)",
        {"strict": round(float(mp["strict_match"].event_share), 4), "expanded_only": round(float(mp["expanded_only_match"].event_share), 4)},
        "outputs/runs/primary/posthoc_mapping_profile.csv", "association=DPP4I_PEMPHIGOID", "exposed retained cases", "V2 vs V1",
        numerator=None, denominator=None)
    i += 1
    add(f"C{i:02d}", "Counts kept separate: test-set size, model calls", {"test_set_size": "not applicable (no predictive model)",
        "model_calls": 0, "issues_logged_in_ledger": sum(1 for _ in open(ROOT / "docs/issue_decision_ledger.csv")) - 1},
        "docs/issue_decision_ledger.csv", "rows", "project")
    for cl in claims:
        cl.update(base)
    write_json(ROOT / "evidence" / "claims.json", {"generated_utc": utc_now(), "run_id": c["run_id"], "claims": claims})
    return claims
