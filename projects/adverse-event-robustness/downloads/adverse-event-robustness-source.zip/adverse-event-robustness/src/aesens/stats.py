"""Reporting odds ratio with the prespecified zero-cell and minimum-support rules."""
from __future__ import annotations

import math

Z95 = 1.959963984540054


def ror(a: int, b: int, c: int, d: int, min_a: int = 3) -> dict:
    """Return ROR, Woolf 95% interval, and a status string.

    status values:
      reported                  all cells > 0 and a >= min_a
      not_evaluated_low_support a < min_a (counts shown, no estimate)
      not_computed_zero_cell    a cell is zero (no continuity correction is applied)
    """
    out = {"ror": None, "ci_low": None, "ci_high": None, "log_ror": None, "se_log_ror": None}
    if min(a, b, c, d) == 0:
        return {**out, "status": "not_computed_zero_cell"}
    if a < min_a:
        return {**out, "status": "not_evaluated_low_support"}
    lr = math.log(a) + math.log(d) - math.log(b) - math.log(c)
    se = math.sqrt(1 / a + 1 / b + 1 / c + 1 / d)
    return {"ror": math.exp(lr), "ci_low": math.exp(lr - Z95 * se), "ci_high": math.exp(lr + Z95 * se),
            "log_ror": lr, "se_log_ror": se, "status": "reported"}
