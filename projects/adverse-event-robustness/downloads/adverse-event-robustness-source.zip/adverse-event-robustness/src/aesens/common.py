"""Shared helpers: project paths, configuration loading, hashing, and run metadata."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import yaml

ROOT = Path(os.environ.get("AESENS_ROOT", Path(__file__).resolve().parents[2]))


def load_yaml(name: str) -> dict:
    with open(ROOT / "config" / name, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def study() -> dict:
    return load_yaml("study.yaml")


def path(key: str) -> Path:
    p = ROOT / study()["paths"][key]
    if key != "db":
        p.mkdir(parents=True, exist_ok=True)
    else:
        p.parent.mkdir(parents=True, exist_ok=True)
    return p


def sha256_file(p: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def write_json(p: Path, obj) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, sort_keys=False, default=str)
        fh.write("\n")
    tmp.replace(p)


def read_json(p: Path):
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def rel(p: Path) -> str:
    """Project-relative POSIX path, so no machine-specific prefix leaks into outputs."""
    try:
        return Path(p).resolve().relative_to(ROOT.resolve()).as_posix()
    except ValueError:
        return Path(p).name


def peak_rss_mb() -> float:
    import resource

    r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # macOS reports bytes, Linux reports kilobytes.
    return round(r / (1024 * 1024) if sys.platform == "darwin" else r / 1024, 1)


def environment_record() -> dict:
    import duckdb
    import pandas
    import pyarrow

    rec = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "duckdb": duckdb.__version__,
        "pyarrow": pyarrow.__version__,
        "pandas": pandas.__version__,
    }
    try:
        out = subprocess.run(["sysctl", "-n", "hw.memsize", "hw.ncpu"], capture_output=True, text=True, timeout=5)
        mem, ncpu = out.stdout.split()
        rec["memory_gb"] = round(int(mem) / 1024**3, 1)
        rec["logical_cpus"] = int(ncpu)
    except Exception:  # noqa: BLE001 - informational only
        pass
    return rec


class StageTimer:
    """Records wall time and peak resident memory for a pipeline stage."""

    def __init__(self, name: str):
        self.name = name

    def __enter__(self):
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, *exc):
        self.seconds = round(time.perf_counter() - self.t0, 2)
        self.peak_rss_mb = peak_rss_mb()
        log = ROOT / "outputs" / "runtime" / "stage_log.jsonl"
        log.parent.mkdir(parents=True, exist_ok=True)
        with open(log, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"stage": self.name, "finished_utc": utc_now(), "wall_seconds": self.seconds,
                                 "peak_rss_mb_process": self.peak_rss_mb, "ok": exc[0] is None}) + "\n")
        return False
