"""One place that turns saved outputs into the numbers quoted in text. Every quoted number has an evidence path."""
from __future__ import annotations

import pandas as pd

from .common import ROOT, read_json, sha256_file

RUN = ROOT / "outputs" / "runs" / "primary"
ORDER = ["SGLT2I_DKA", "SGLT2I_FOURNIER", "DPP4I_PEMPHIGOID", "DPP4I_ARTHRALGIA", "DPP4I_PANCREATITIS"]
SHORT = {"SGLT2I_DKA": "SGLT2 inhibitors and ketoacidosis", "SGLT2I_FOURNIER": "SGLT2 inhibitors and Fournier's gangrene",
         "DPP4I_PEMPHIGOID": "DPP-4 inhibitors and pemphigoid", "DPP4I_ARTHRALGIA": "DPP-4 inhibitors and arthralgia",
         "DPP4I_PANCREATITIS": "DPP-4 inhibitors and pancreatitis"}


def n(x) -> str:
    return f"{int(x):,}"


def r2(x) -> str:
    return f"{x:.2f}"


def r1(x) -> str:
    return f"{x:.1f}"


def ci(row) -> str:
    return f"{row.ror:.2f} (95% CI {row.ci_low:.2f} to {row.ci_high:.2f})"


def ci_short(row) -> str:
    return f"{row.ror:.2f} ({row.ci_low:.2f} to {row.ci_high:.2f})"


def pct(x, d=1) -> str:
    return f"{100 * x:.{d}f}%"


def build() -> dict:
    flow = read_json(ROOT / "outputs/build/case_construction_flow.json")
    meta = read_json(RUN / "run_meta.json")
    val = read_json(ROOT / "outputs/validation/validation_report.json")
    man = read_json(ROOT / "source_manifest.json")
    counts = pd.read_csv(RUN / "association_counts.csv")
    rob = pd.read_csv(RUN / "robustness_summary.csv")
    dec = pd.read_csv(RUN / "count_decomposition.csv")
    comp = pd.read_csv(RUN / "cell_a_composition.csv")
    prof = pd.read_csv(RUN / "posthoc_role_profile.csv")
    mprof = pd.read_csv(RUN / "posthoc_mapping_profile.csv")
    ing = pd.read_csv(RUN / "exposed_cases_by_ingredient.csv")
    ov = pd.read_csv(RUN / "association_overlap.csv")
    terms = pd.read_csv(RUN / "term_occurrence.csv")
    basis = pd.read_csv(ROOT / "outputs/mapping/match_basis_summary.csv")
    recon = pd.read_csv(ROOT / "outputs/validation/source_reconciliation.csv")
    rt = read_json(ROOT / "outputs/runtime/runtime_manifest.json") if (ROOT / "outputs/runtime/runtime_manifest.json").exists() else {}

    def row(v, a):
        return counts[(counts.variant == v) & (counts.association == a)].iloc[0]

    A = {}
    for a in ORDER:
        rc = rob[(rob.association == a) & (rob.scope == "case_level_V1_V4")].iloc[0]
        ra = rob[(rob.association == a) & (rob.scope == "all_principal_V1_V8")].iloc[0]
        A[a] = {
            "label": SHORT[a],
            "v": {v: row(v, a) for v in ["V1", "V2", "V3", "V4", "V5", "V6", "V7", "V8", "S1", "S2", "S3", "S4"]},
            "case_min": rc.ror_min, "case_max": rc.ror_max, "case_ratio": rc.ror_max_over_min,
            "case_vmin": rc.variant_min, "case_vmax": rc.variant_max,
            "all_min": ra.ror_min, "all_max": ra.ror_max, "all_ratio": ra.ror_max_over_min,
            "case_all_lb_above_1": bool(rc.all_lower_bounds_above_1), "case_all_pe_above_1": bool(rc.all_point_estimates_above_1),
            "dec": {r.comparison.split(" (")[0]: r for r in dec[dec.association == a].itertuples()},
            "comp": comp[comp.association == a].set_index("route").units.to_dict(),
            "prof": {r.group: r for r in prof[prof.association == a].itertuples()},
            "mprof": {r.group: r for r in mprof[mprof.association == a].itertuples()},
        }
    exposed = {c: int(counts[(counts.variant == "V1") & (counts["class"] == c)].iloc[0][["a", "b"]].sum()) for c in ["SGLT2I", "DPP4I"]}
    sglt2_strict_only = exposed["SGLT2I"] - int(row("V2", "SGLT2I_DKA")[["a", "b"]].sum())
    dpp4_strict_only = exposed["DPP4I"] - int(row("V2", "DPP4I_PEMPHIGOID")[["a", "b"]].sum())
    sglt2_ps = int(row("V3", "SGLT2I_DKA")[["a", "b"]].sum())
    dpp4_ps = int(row("V3", "DPP4I_PEMPHIGOID")[["a", "b"]].sum())
    ctx = {
        "flow": flow, "meta": meta, "val": val, "A": A, "ORDER": ORDER,
        "run_id": meta["run_id"], "units": meta["units"],
        "exposed": exposed, "exposed_ps": {"SGLT2I": sglt2_ps, "DPP4I": dpp4_ps},
        "expanded_only": {"SGLT2I": sglt2_strict_only, "DPP4I": dpp4_strict_only},
        "ingredients": ing, "overlap": ov, "terms": terms, "basis": basis, "recon": recon, "runtime": rt,
        "n_quarters": len(man["quarters"]),
        "archive_bytes": sum(q["bytes"] for q in man["quarters"].values()),
        "drug_rows": flow["drug_rows_delivered"], "reac_rows": flow["reac_rows_delivered"],
        "rxnav_version": read_json(ROOT / "data/cache/rxnav/rxnav_manifest.json")["rxnav_version"],
        "source_hashes": {q: v["sha256"] for q, v in man["quarters"].items()},
        "manifest_sha256": sha256_file(ROOT / "source_manifest.json"),
        "n": n, "r2": r2, "r1": r1, "ci": ci, "ci_short": ci_short, "pct": pct,
    }
    return ctx
