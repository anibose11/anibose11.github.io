"""Validate stage.

Three kinds of checks, reported separately:
  1. Source reconciliation: parsed rows versus raw newline counts in each archive member and versus the
     record totals printed in FDA's per-file statistics reports.
  2. Structural checks on the SQL tables: one version per case, version ordering, row attachment,
     mutually exclusive cells, unit-level counting.
  3. A second implementation of the case-level cells in pandas/pyarrow that reads the Parquet files
     directly and shares no SQL with the main path. Agreement shows the code paths are consistent; it is
     not external scientific validation.
A rerun comparison is added when outputs/runs/rerun exists.
"""
from __future__ import annotations

import re
import zipfile
from pathlib import PurePosixPath

import numpy as np
import pandas as pd
import pyarrow.compute as pc
import pyarrow.dataset as ds

from .cases import connect
from .common import ROOT, load_yaml, path, read_json, rel, study, utc_now, write_json

OUT = ROOT / "outputs" / "validation"
REL_TOL = 1e-12


def _count_newlines(zf: zipfile.ZipFile, member: str) -> tuple[int, bool]:
    n, last = 0, b""
    with zf.open(member) as fh:
        while True:
            b = fh.read(1 << 22)
            if not b:
                break
            n += b.count(b"\n")
            last = b[-1:]
    return n, last == b"\n"


def source_reconciliation() -> pd.DataFrame:
    manifest = read_json(ROOT / "source_manifest.json")
    log = read_json(ROOT / "outputs" / "build" / "ingest_log.json")
    fda = pd.read_csv(ROOT / "outputs" / "build" / "fda_reported_totals.csv")
    rows = []
    for q in study()["quarters"]:
        qid = q["id"]
        with zipfile.ZipFile(ROOT / manifest["quarters"][qid]["path"]) as zf:
            for table, st in log["quarters"][qid]["tables"].items():
                if st.get("status") != "ingested":
                    continue
                nl, ends_nl = _count_newlines(zf, st["member"])
                physical = nl if ends_nl else nl + 1
                header_lines = 0 if table == "DELE" else 1
                blank = st["physical_lines"] - st["data_rows"] - header_lines - st["joined_rows"] - st["rejected_rows"]
                f = fda[(fda.quarter == qid) & (fda.table == table)]
                fda_total = None if f.empty or pd.isna(f.fda_reported_total.iloc[0]) else int(f.fda_reported_total.iloc[0])
                rows.append({"quarter": qid, "table": table, "raw_physical_lines": physical,
                             "parser_physical_lines": st["physical_lines"], "parsed_rows": st["data_rows"],
                             "joined_rows": st["joined_rows"], "rejected_rows": st["rejected_rows"],
                             "blank_or_header_lines": header_lines + max(blank, 0),
                             "fda_reported_total": fda_total,
                             "physical_lines_agree": physical == st["physical_lines"],
                             "parsed_equals_fda_total": None if fda_total is None else st["data_rows"] == fda_total})
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "source_reconciliation.csv", index=False)
    return df


def structural_checks() -> dict:
    con = connect(read_only=True)
    one = lambda s: con.execute(s).fetchone()[0]  # noqa: E731
    pq = path("parquet").as_posix()
    checks = {
        "case_latest_one_row_per_caseid": one("SELECT count(*) = count(DISTINCT caseid) FROM case_latest"),
        "report_version_one_row_per_primaryid": one("SELECT count(*) = count(DISTINCT primaryid) FROM report_version"),
        "selected_version_is_maximum": one("""SELECT count(*) = 0 FROM case_latest c JOIN report_version r USING (caseid)
                                              WHERE r.caseversion_num > c.caseversion_num"""),
        "unit_flags_one_row_per_primaryid": one("SELECT count(*) = count(DISTINCT primaryid) FROM unit_flags"),
        "unit_flags_rows_equal_report_versions": one("SELECT (SELECT count(*) FROM unit_flags) = (SELECT count(*) FROM report_version)"),
        "drug_rows_not_attached_equal_superseded_copies": one(f"""
            SELECT (SELECT count(*) FROM read_parquet('{pq}/drug/*.parquet')) - (SELECT count(*) FROM drug_rv) =
                   (SELECT count(*) FROM read_parquet('{pq}/drug/*.parquet') d
                    WHERE NOT EXISTS (SELECT 1 FROM report_version r WHERE r.primaryid = d.primaryid AND r.src_quarter = d.src_quarter))"""),
        "drug_rows_orphan_primaryid": one(f"""SELECT count(*) FROM read_parquet('{pq}/drug/*.parquet') d
                                              WHERE d.primaryid NOT IN (SELECT primaryid FROM report_version)"""),
        "reac_rows_orphan_primaryid": one(f"""SELECT count(*) FROM read_parquet('{pq}/reac/*.parquet') r
                                              WHERE r.primaryid NOT IN (SELECT primaryid FROM report_version)"""),
        "deleted_cases_excluded_from_case_universe": one("SELECT count(*) = 0 FROM unit_flags WHERE is_case_latest AND NOT is_deleted AND caseid IN (SELECT caseid FROM deleted_case)"),
    }
    # Many-to-many illustration: rows produced by a naive drug x reaction join for V1 cell a of the DKA pair.
    assoc = load_yaml("associations.yaml")["associations"]
    dka = next(a for a in assoc if a["id"] == "SGLT2I_DKA")
    terms = ", ".join("'" + t.lower().replace("'", "''") + "'" for t in dka["terms"])
    naive = one(f"""SELECT count(*) FROM drug_match m JOIN reac_rv r USING (primaryid) JOIN unit_flags u USING (primaryid)
                    WHERE u.is_case_latest AND NOT u.is_deleted AND m.class = 'SGLT2I' AND m.expanded
                      AND m.role_cod IN ('PS','SS') AND lower(trim(r.pt)) IN ({terms})""")
    unit_a = one("SELECT count(*) FROM unit_flags WHERE is_case_latest AND NOT is_deleted AND sglt2i_suspect_expanded AND ev_sglt2i_dka")
    con.close()
    counts = pd.read_csv(ROOT / "outputs" / "runs" / "primary" / "association_counts.csv")
    checks["cells_sum_to_n_every_row"] = bool((counts[["a", "b", "c", "d"]].sum(axis=1) == counts.n).all())
    checks = {k: (bool(v) if isinstance(v, (bool, np.bool_)) else int(v)) for k, v in checks.items()}
    checks["many_to_many_example"] = {"association": "SGLT2I_DKA", "configuration": "V1",
                                      "naive_drug_x_reaction_join_rows": int(naive), "case_level_cell_a": int(unit_a),
                                      "inflation_if_join_rows_were_counted": round(naive / unit_a, 3)}
    return checks


def _norm(s):
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z0-9]+", " ", s.upper())).strip() if isinstance(s, str) else ""


def second_implementation() -> pd.DataFrame:
    """Recompute case-level cells (V1 to V4) for every association from Parquet with pandas/pyarrow."""
    pq = path("parquet")
    demo = ds.dataset(pq / "demo").to_table(columns=["primaryid", "caseid", "caseversion", "fda_dt", "src_quarter"]).to_pandas()
    # FAQ 29: same PRIMARYID in two extracts -> keep the later extract.
    demo = demo.sort_values(["primaryid", "src_quarter"], ascending=[True, False]).drop_duplicates("primaryid")
    demo["v"] = pd.to_numeric(demo.caseversion, errors="coerce").fillna(0).astype(int)
    demo["fda_dt_s"] = demo.fda_dt.fillna("")
    latest = demo.sort_values(["caseid", "v", "fda_dt_s", "src_quarter", "primaryid"],
                              ascending=[True, False, False, False, False]).drop_duplicates("caseid")
    deleted = set(ds.dataset(pq / "dele").to_table(columns=["caseid"]).column("caseid").to_pylist())
    latest = latest[~latest.caseid.isin(deleted)]
    keep = latest[["primaryid", "src_quarter"]]
    n_units = len(keep)

    names = pd.read_csv(ROOT / "outputs" / "mapping" / "verified_drug_names.csv")
    in_names = dict(zip(names.loc[names.tty == "IN", "name"], names.loc[names.tty == "IN", "class"]))
    pin_names = dict(zip(names.loc[names.tty == "PIN", "name"], names.loc[names.tty == "PIN", "class"]))
    words = {_norm(n): c for n, c in zip(names["name"], names["class"])}
    word_re = re.compile(r"(?<![A-Z0-9])(" + "|".join(re.escape(w) for w in sorted(words, key=len, reverse=True)) + r")(?![A-Z0-9])")

    drug = ds.dataset(pq / "drug").to_table(
        columns=["primaryid", "src_quarter", "drug_seq", "role_cod", "drugname", "prod_ai"],
        filter=pc.field("primaryid").isin(pa_array(keep.primaryid))).to_pandas()
    drug = drug.merge(keep, on=["primaryid", "src_quarter"])
    drug["role"] = drug.role_cod.fillna("").str.strip().str.upper()
    drug["seq"] = pd.to_numeric(drug.drug_seq, errors="coerce")
    has_ps = drug.groupby("primaryid").role.apply(lambda s: (s == "PS").any())
    first = drug[drug.role != "DN"].groupby("primaryid").seq.min()
    drug["is_ps"] = (drug.role == "PS") | (~drug.primaryid.map(has_ps).astype(bool) & (drug.seq == drug.primaryid.map(first)))
    drug["is_suspect"] = drug.is_ps | (drug.role == "SS")

    pairs = drug[["drugname", "prod_ai"]].drop_duplicates()
    rec = []
    for dn, ai in pairs.itertuples(index=False):
        strict, expanded = set(), set()
        for c in (ai.split("\\") if isinstance(ai, str) else []):
            c = c.strip().upper()
            if c in in_names:
                strict.add(in_names[c])
                expanded.add(in_names[c])
            elif c in pin_names:
                expanded.add(pin_names[c])
        for m in word_re.finditer(_norm(dn)):
            expanded.add(words[m.group(1)])
        for cls in {"SGLT2I", "DPP4I"}:
            rec.append((dn, ai, cls, cls in strict, cls in expanded))
    mt = pd.DataFrame(rec, columns=["drugname", "prod_ai", "class", "strict", "expanded"])
    drug = drug.merge(mt, on=["drugname", "prod_ai"], how="left")

    reac = ds.dataset(pq / "reac").to_table(columns=["primaryid", "src_quarter", "pt"],
                                             filter=pc.field("primaryid").isin(pa_array(keep.primaryid))).to_pandas()
    reac = reac.merge(keep, on=["primaryid", "src_quarter"])
    reac["ptl"] = reac.pt.fillna("").str.strip().str.lower()

    assoc = load_yaml("associations.yaml")["associations"]
    rows = []
    for a in assoc:
        ev = set(reac.loc[reac.ptl.isin([t.lower() for t in a["terms"]]), "primaryid"])
        d = drug[drug["class"] == a["class"]]
        for vid, role, mapping in (("V1", "is_suspect", "expanded"), ("V2", "is_suspect", "strict"),
                                   ("V3", "is_ps", "expanded"), ("V4", "is_ps", "strict")):
            ex = set(d.loc[d[role] & d[mapping], "primaryid"])
            a_ = len(ex & ev)
            b_ = len(ex) - a_
            c_ = len(ev) - a_
            rows.append({"variant": vid, "association": a["id"], "a": a_, "b": b_, "c": c_, "d": n_units - a_ - b_ - c_, "n": n_units})
    return pd.DataFrame(rows)


def pa_array(series):
    import pyarrow as pa
    return pa.array(series.astype(str).tolist())


def rerun_comparison() -> dict | None:
    p1, p2 = ROOT / "outputs/runs/primary/association_counts.csv", ROOT / "outputs/runs/rerun/association_counts.csv"
    if not p2.exists():
        return None
    a, b = pd.read_csv(p1), pd.read_csv(p2)
    key = ["analysis", "variant", "association"]
    m = a.merge(b, on=key, suffixes=("_1", "_2"))
    cnt = all((m[f"{c}_1"] == m[f"{c}_2"]).all() for c in ["a", "b", "c", "d", "n"])
    r1, r2 = m.ror_1.fillna(-1), m.ror_2.fillna(-1)
    rel_diff = float((abs(r1 - r2) / r1.abs().clip(lower=1e-300)).max())
    other = {}
    for f in ["robustness_summary.csv", "count_decomposition.csv", "posthoc_role_profile.csv", "posthoc_mapping_profile.csv"]:
        x = pd.read_csv(ROOT / "outputs/runs/primary" / f).drop(columns="run_id")
        y = pd.read_csv(ROOT / "outputs/runs/rerun" / f).drop(columns="run_id")
        num = x.select_dtypes("number").columns
        same_text = x.drop(columns=num).fillna("").equals(y.drop(columns=num).fillna(""))
        diff = float(np.nanmax(np.abs(x[num].to_numpy(float) - y[num].to_numpy(float)) / np.maximum(np.abs(x[num].to_numpy(float)), 1e-300))) if len(num) else 0.0
        other[f] = {"text_identical": bool(same_text), "max_relative_numeric_difference": diff}
    return {"rows_compared": int(len(m)), "rows_primary": int(len(a)), "rows_rerun": int(len(b)),
            "counts_identical": bool(cnt), "max_relative_ror_difference": rel_diff, "tolerance": REL_TOL,
            "within_tolerance": bool(cnt and rel_diff <= REL_TOL and all(v["max_relative_numeric_difference"] <= REL_TOL and v["text_identical"] for v in other.values())),
            "other_tables": other,
            "run_id_primary": a.run_id.iloc[0], "run_id_rerun": b.run_id.iloc[0]}


def human_review_material(seed: int = 20261007, n_cases: int = 25) -> dict:
    """Material for the author's manual review: a seeded sample of multi-version cases with every version,
    and every distinct drug string that qualifies only through the expanded rule."""
    con = connect(read_only=True)
    sample = con.execute(f"""
        WITH multi AS (SELECT caseid FROM case_latest WHERE n_versions_in_window > 1 AND NOT is_deleted)
        SELECT caseid FROM multi ORDER BY hash(caseid || '{seed}') LIMIT {n_cases}""").fetchdf()
    con.register("sample_df", sample)
    chains = con.execute("""
        SELECT rv.caseid, rv.primaryid, rv.caseversion_num, rv.i_f_code, rv.fda_dt, rv.init_fda_dt, rv.src_quarter,
               (cl.primaryid IS NOT NULL) AS selected_by_pipeline
        FROM report_version rv JOIN sample_df s USING (caseid) LEFT JOIN case_latest cl ON cl.primaryid = rv.primaryid
        ORDER BY rv.caseid, rv.caseversion_num""").fetchdf()
    con.close()
    chains["reviewer_agrees"] = ""
    chains.to_csv(OUT / "human_review_case_chains.csv", index=False)
    m = pd.read_csv(ROOT / "outputs" / "mapping" / "drug_string_matches.csv")
    exp_only = m[~m.basis.str.contains("prod_ai_IN") & (m.basis != "same_stem_unverified")].copy()
    exp_only["reviewer_agrees"] = ""
    exp_only.to_csv(OUT / "human_review_expanded_only_strings.csv", index=False)
    return {"cases_sampled": int(sample.shape[0]), "versions_listed": int(len(chains)),
            "expanded_only_distinct_strings": int(len(exp_only)), "seed": seed}


def run() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    hr = human_review_material()
    recon = source_reconciliation()
    struct = structural_checks()
    alt = second_implementation()
    alt.to_csv(OUT / "second_implementation_cells.csv", index=False)
    main = pd.read_csv(ROOT / "outputs/runs/primary/association_counts.csv")
    main = main[(main.analysis == "principal") & main.variant.isin(["V1", "V2", "V3", "V4"])]
    cmp_ = main.merge(alt, on=["variant", "association"], suffixes=("_sql", "_pandas"))
    cmp_["identical"] = np.all([cmp_[f"{c}_sql"] == cmp_[f"{c}_pandas"] for c in "abcdn"], axis=0)
    cmp_[["variant", "association"] + [f"{c}_{s}" for c in "abcdn" for s in ("sql", "pandas")] + ["identical"]].to_csv(
        OUT / "second_implementation_comparison.csv", index=False)
    rr = rerun_comparison()
    report = {
        "generated_utc": utc_now(),
        "source_reconciliation": {
            "files_checked": int(len(recon)),
            "physical_lines_agree_all": bool(recon.physical_lines_agree.all()),
            "rows_rejected_total": int(recon.rejected_rows.sum()),
            "rows_joined_total": int(recon.joined_rows.sum()),
            "fda_totals_available": int(recon.fda_reported_total.notna().sum()),
            "parsed_equals_fda_total_all_available": bool(recon.dropna(subset=["fda_reported_total"]).parsed_equals_fda_total.all()),
            "mismatches": recon[(recon.parsed_equals_fda_total == False)][["quarter", "table", "parsed_rows", "fda_reported_total"]].to_dict("records"),  # noqa: E712
            "detail": rel(OUT / "source_reconciliation.csv"),
        },
        "structural_checks": struct,
        "second_implementation": {"rows_compared": int(len(cmp_)), "all_identical": bool(cmp_.identical.all()),
                                  "detail": rel(OUT / "second_implementation_comparison.csv"),
                                  "nature": "same-author pandas/pyarrow re-implementation; software consistency, not external validation"},
        "rerun": rr,
        "human_review_material": hr,
    }
    write_json(OUT / "validation_report.json", report)
    print("[validate]", {"recon_ok": report["source_reconciliation"]["physical_lines_agree_all"],
                         "fda_totals_ok": report["source_reconciliation"]["parsed_equals_fda_total_all_available"],
                         "second_impl_identical": report["second_implementation"]["all_identical"],
                         "rerun": None if rr is None else rr["within_tolerance"]})
    return report
