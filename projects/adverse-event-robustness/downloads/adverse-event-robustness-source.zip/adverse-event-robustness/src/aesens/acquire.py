"""Acquire stage: download the frozen quarterly ASCII extracts and record their provenance.

Downloads are cached and immutable: an existing archive whose checksum matches the manifest
is never fetched again. Each response is checked for an HTTP 200, a non-HTML content type,
ZIP magic bytes, and a passing CRC test before it replaces the cached copy.
"""
from __future__ import annotations

import re
import time
import zipfile
from pathlib import Path, PurePosixPath

import requests

from .common import ROOT, path, read_json, rel, sha256_bytes, sha256_file, study, utc_now, write_json

MANIFEST = ROOT / "source_manifest.json"
DOC_SUFFIXES = (".pdf", ".doc", ".docx", ".txt", ".rtf")


class AcquisitionError(RuntimeError):
    pass


def _session(cfg: dict) -> requests.Session:
    s = requests.Session()
    s.headers["User-Agent"] = cfg["download"]["user_agent"]
    return s


def _fetch_to(sess: requests.Session, url: str, dest: Path, cfg: dict) -> dict:
    d = cfg["download"]
    last_err = None
    for attempt in range(1, d["max_retries"] + 1):
        part = dest.with_suffix(dest.suffix + ".part")
        try:
            with sess.get(url, stream=True, timeout=d["timeout_seconds"], allow_redirects=True) as r:
                ctype = r.headers.get("Content-Type", "")
                if r.status_code != 200:
                    raise AcquisitionError(f"HTTP {r.status_code} for {url}")
                if "html" in ctype.lower():
                    raise AcquisitionError(f"HTML content type ({ctype}) returned for {url}; refusing error page")
                with open(part, "wb") as fh:
                    for chunk in r.iter_content(chunk_size=d["chunk_bytes"]):
                        fh.write(chunk)
                final_url = r.url
                headers = {k: r.headers.get(k) for k in ("Content-Type", "Content-Length", "Last-Modified", "ETag")}
            with open(part, "rb") as fh:
                if fh.read(4) != b"PK\x03\x04":
                    raise AcquisitionError(f"{url} did not return a ZIP archive")
            with zipfile.ZipFile(part) as zf:
                bad = zf.testzip()
                if bad is not None:
                    raise AcquisitionError(f"CRC failure in member {bad}")
            part.replace(dest)
            return {"final_url": final_url, "response_headers": headers, "attempts": attempt}
        except (requests.RequestException, AcquisitionError, zipfile.BadZipFile) as e:
            last_err = e
            if part.exists():
                part.unlink()
            if attempt < d["max_retries"]:
                time.sleep(d["backoff_seconds"] * attempt)
    raise AcquisitionError(f"Failed after {d['max_retries']} attempts: {last_err}")


def _safe_member_name(name: str) -> str | None:
    p = PurePosixPath(name.replace("\\", "/"))
    if p.is_absolute() or ".." in p.parts:
        return None
    return p.as_posix()


def _extract_docs(zpath: Path, outdir: Path) -> list[dict]:
    """Extract README/documentation members only, with path-traversal protection."""
    docs = []
    with zipfile.ZipFile(zpath) as zf:
        for info in zf.infolist():
            safe = _safe_member_name(info.filename)
            if safe is None or info.is_dir():
                continue
            base = PurePosixPath(safe).name
            is_data = re.match(r"^(DEMO|DRUG|REAC|OUTC|RPSR|THER|INDI|DELETE|DELE)\d{2}Q\d\.TXT$", base.upper())
            if is_data or not base.lower().endswith(DOC_SUFFIXES):
                continue
            target = outdir / base
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())
            docs.append({"member": info.filename, "path": rel(target), "bytes": target.stat().st_size,
                         "sha256": sha256_file(target)})
    return docs


def _members(zpath: Path) -> list[dict]:
    with zipfile.ZipFile(zpath) as zf:
        return [{"name": i.filename, "uncompressed_bytes": i.file_size, "compressed_bytes": i.compress_size,
                 "crc32": f"{i.CRC:08x}", "zip_datetime": "%04d-%02d-%02dT%02d:%02d:%02d" % i.date_time}
                for i in zf.infolist() if not i.is_dir()]


def snapshot_pages(sess: requests.Session, cfg: dict, manifest: dict) -> None:
    cache = path("cache")
    pages = {}
    for key, url in cfg["source_pages"].items():
        r = sess.get(url, timeout=60)
        body = r.content
        out = cache / f"page_{key}.html"
        out.write_bytes(body)
        pages[key] = {"url": url, "final_url": r.url, "http_status": r.status_code, "accessed_utc": utc_now(),
                      "bytes": len(body), "sha256": sha256_bytes(body), "path": rel(out)}
        m = re.search(rb"Content current as of:\s*</?[^>]*>?\s*([0-9/]+)", body)
        if m:
            pages[key]["content_current_as_of"] = m.group(1).decode()
    manifest["source_pages"] = pages


def run(force: bool = False) -> dict:
    cfg = study()
    raw = path("raw")
    manifest = read_json(MANIFEST) if MANIFEST.exists() else {}
    manifest.setdefault("quarters", {})
    sess = _session(cfg)
    snapshot_pages(sess, cfg, manifest)
    for q in cfg["quarters"]:
        qid, url = q["id"], q["url"]
        dest = raw / f"faers_ascii_{qid}.zip"
        prev = manifest["quarters"].get(qid)
        if dest.exists() and prev and not force and sha256_file(dest) == prev.get("sha256"):
            print(f"[acquire] {qid}: cached, checksum verified")
            docdir = raw / qid / "docs"
            for stale in docdir.glob("DELE*.txt"):
                stale.unlink()
            prev["documentation"] = _extract_docs(dest, docdir)
            continue
        print(f"[acquire] {qid}: downloading {url}")
        meta = _fetch_to(sess, url, dest, cfg)
        docdir = raw / qid / "docs"
        manifest["quarters"][qid] = {
            "quarter": qid,
            "source_url": url,
            **meta,
            "accessed_utc": utc_now(),
            "path": rel(dest),
            "bytes": dest.stat().st_size,
            "sha256": sha256_file(dest),
            "members": _members(dest),
            "documentation": _extract_docs(dest, docdir),
            "permitted_use": "U.S. federal government public data release (FDA). Public domain in the United States; "
                             "FDA asks users not to imply FDA endorsement. Reaction terms are MedDRA preferred terms "
                             "(MedDRA is a registered trademark of ICH); the MedDRA dictionary itself was not used.",
        }
        write_json(MANIFEST, _finish(manifest, cfg))
    write_json(MANIFEST, _finish(manifest, cfg))
    return manifest


def _finish(manifest: dict, cfg: dict) -> dict:
    manifest["study_id"] = cfg["study_id"]
    manifest["snapshot_label"] = cfg["snapshot_label"]
    manifest["cutoff_quarter"] = cfg["cutoff_quarter"]
    manifest["selection_rule"] = ("Latest eight consecutive quarterly ASCII drug-report extracts listed on the FDA "
                                  "quarterly data extract index on the retrieval reference date, ending at the newest "
                                  "posted quarter (2026Q2). Compatibility verified in docs/transition_table.csv.")
    manifest["rebuild_limits"] = ("FDA quarterly files are posted once and are not cumulative, but FDA can repost "
                                  "or reorganize files. Checksums identify the exact bytes analysed; a later download "
                                  "with a different checksum is a different snapshot.")
    manifest["quarters"] = dict(sorted(manifest["quarters"].items()))
    return manifest


if __name__ == "__main__":
    run()
