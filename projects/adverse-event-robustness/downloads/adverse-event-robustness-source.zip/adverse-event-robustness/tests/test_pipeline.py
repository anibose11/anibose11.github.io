"""Software tests on SYNTHETIC fixtures. They check rules and arithmetic, not any safety result."""
from __future__ import annotations

import math
import zipfile
from pathlib import Path

import duckdb
import pandas as pd
import pytest

from aesens import analyze, cases, drugmap
from aesens.common import load_yaml
from aesens.ingest import _find_members, _parse_member
from aesens.stats import ror

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture(scope="module")
def db(tmp_path_factory):
    import sys
    sys.path.insert(0, str(FIX))
    import make_fixture

    tmp = tmp_path_factory.mktemp("fx")
    zips = make_fixture.build(tmp / "raw")
    pq = tmp / "parquet"
    for qid, zp in zips.items():
        with zipfile.ZipFile(zp) as zf:
            for table, member in _find_members(zf).items():
                out = pq / table.lower() / f"{qid}.parquet"
                out.parent.mkdir(parents=True, exist_ok=True)
                _parse_member(zf, member, table, qid, out, tmp / "rejects.tsv")
    con = duckdb.connect(str(tmp / "fx.duckdb"))
    cases.run_sql_file(con, "10_case_construction.sql", parquet=pq.as_posix())
    names = pd.read_csv(FIX / "verified_names_fixture.csv")
    drugmap.match_rows(names, con=con, outdir=tmp / "mapping")
    assoc = load_yaml("associations.yaml")["associations"]
    analyze.build_indicators(con, assoc, ["DPP4I", "SGLT2I"])
    yield con
    con.close()


def one(con, sql):
    return con.execute(sql).fetchone()[0]


def flags(con, caseid):
    return con.execute("SELECT * FROM unit_flags WHERE caseid = ? AND is_case_latest", [caseid]).fetchdf().iloc[0]


# --- case construction -------------------------------------------------------------------------------

def test_latest_version_selected(db):
    assert one(db, "SELECT primaryid FROM case_latest WHERE caseid = '100'") == "1002"


def test_faq29_duplicate_primaryid_keeps_later_extract(db):
    assert one(db, "SELECT src_quarter FROM case_latest WHERE caseid = '108'") == "2025Q2"
    assert one(db, "SELECT n_extracts_with_pid FROM report_version WHERE primaryid = '1081'") == 2
    # Drug rows come from the kept extract only.
    assert one(db, "SELECT string_agg(prod_ai, ',') FROM drug_rv WHERE primaryid = '1081'") == "SAXAGLIPTIN HYDROCHLORIDE"


def test_version_tie_broken_by_fda_date(db):
    assert one(db, "SELECT primaryid FROM case_latest WHERE caseid = '111'") == "11105"
    assert one(db, "SELECT n_rows_at_max_version FROM case_latest WHERE caseid = '111'") == 2


def test_deleted_case_flagged(db):
    assert one(db, "SELECT is_deleted FROM case_latest WHERE caseid = '106'") is True
    assert one(db, "SELECT count(*) FROM deleted_case") == 1


def test_one_row_per_case_and_version(db):
    assert one(db, "SELECT count(*) = count(DISTINCT caseid) FROM case_latest")
    assert one(db, "SELECT count(*) = count(DISTINCT primaryid) FROM unit_flags")


# --- exposure and role rules ---------------------------------------------------------------------------

def test_salt_form_expanded_only_and_secondary_suspect(db):
    f = flags(db, "101")  # FARXIGA / DAPAGLIFLOZIN PROPANEDIOL as SS
    assert f.sglt2i_suspect_expanded and not f.sglt2i_suspect_strict and not f.sglt2i_ps_expanded


def test_brand_name_without_prod_ai_is_expanded_only(db):
    f = flags(db, "102")  # "JANUVIA 100MG" with empty PROD_AI
    assert f.dpp4i_ps_expanded and not f.dpp4i_ps_strict


def test_faq30_fallback_designates_first_drug(db):
    f = flags(db, "107")  # no PS row; first drug (linagliptin, listed as C) becomes PS
    assert f.dpp4i_ps_strict and f.dpp4i_suspect_strict and f.dpp4i_ps_by_fallback


def test_dn_row_never_designated_or_exposed(db):
    f = flags(db, "112")  # first row is DN (not administered); fallback must skip it
    assert not f.dpp4i_ps_expanded and not f.dpp4i_suspect_expanded and f.dpp4i_any_expanded


def test_concomitant_listing_stays_in_background(db):
    f = flags(db, "105")
    assert not f.dpp4i_suspect_expanded and f.dpp4i_any_expanded and f.ev_dpp4i_pancreatitis


def test_same_stem_non_member_not_exposed(db):
    f = flags(db, "104")  # vildagliptin
    assert not f.dpp4i_any_expanded and f.dpp4i_stem_unverified


# --- counting units and cells --------------------------------------------------------------------------

def test_many_to_many_counts_case_once(db):
    # Case 100 v1 had two drugs and four reactions; the case contributes one unit.
    where = analyze.universe("case")
    c = analyze.cells(db, where, "sglt2i_suspect_expanded", "ev_sglt2i_dka")
    assert one(db, "SELECT count(*) FROM drug_rv d JOIN reac_rv r USING (primaryid) WHERE primaryid = '1001'") == 8
    assert c["a"] == 2  # cases 100 and 109; 106 is deleted
    assert c["a"] + c["b"] + c["c"] + c["d"] == c["n"]


def test_version_level_counts_each_version(db):
    c = analyze.cells(db, analyze.universe("version"), "sglt2i_suspect_expanded", "ev_sglt2i_dka")
    assert c["a"] == 3  # 1001, 1002, 1093


def test_deletions_change_universe(db):
    with_del = analyze.cells(db, analyze.universe("case"), "sglt2i_suspect_expanded", "ev_sglt2i_dka")
    without = analyze.cells(db, analyze.universe("case", apply_deletions=False), "sglt2i_suspect_expanded", "ev_sglt2i_dka")
    assert without["a"] == with_del["a"] + 1 and without["n"] == with_del["n"] + 1


def test_role_and_mapping_move_expected_units(db):
    U = analyze.universe("case")
    v1 = analyze.cells(db, U, "dpp4i_suspect_expanded", "ev_dpp4i_arthralgia")
    v2 = analyze.cells(db, U, "dpp4i_suspect_strict", "ev_dpp4i_arthralgia")
    v3 = analyze.cells(db, U, "dpp4i_ps_expanded", "ev_dpp4i_arthralgia")
    # 107 (fallback PS, strict) is in all; 103 (JANUVIA as SS, no PROD_AI) only under suspect + expanded.
    assert (v1["a"], v2["a"], v3["a"]) == (2, 1, 1)


# --- statistics ------------------------------------------------------------------------------------------

def test_ror_arithmetic():
    r = ror(10, 90, 20, 880)
    assert math.isclose(r["ror"], (10 * 880) / (90 * 20))
    se = math.sqrt(1 / 10 + 1 / 90 + 1 / 20 + 1 / 880)
    assert math.isclose(r["ci_low"], math.exp(math.log(r["ror"]) - 1.959963984540054 * se))


def test_zero_cell_and_low_support():
    assert ror(0, 10, 5, 100)["status"] == "not_computed_zero_cell"
    assert ror(2, 10, 5, 100)["status"] == "not_evaluated_low_support"
    assert ror(2, 10, 5, 100)["ror"] is None


def test_parser_joins_embedded_line_break(tmp_path):
    zp = tmp_path / "t.zip"
    body = "primaryid$caseid$pt$drug_rec_act\r\n1$1$Head\r\nache$\r\n2$2$Rash$\r\n3$3$x$y$z$extra\r\n"
    with zipfile.ZipFile(zp, "w") as zf:
        zf.writestr("ASCII/REAC25Q1.txt", body)
    with zipfile.ZipFile(zp) as zf:
        st = _parse_member(zf, "ASCII/REAC25Q1.txt", "REAC", "2025Q1", tmp_path / "r.parquet", tmp_path / "rej.tsv")
    assert st["data_rows"] == 2 and st["joined_rows"] == 1 and st["rejected_rows"] == 1
    df = pd.read_parquet(tmp_path / "r.parquet")
    assert df.pt.tolist() == ["Head ache", "Rash"]
