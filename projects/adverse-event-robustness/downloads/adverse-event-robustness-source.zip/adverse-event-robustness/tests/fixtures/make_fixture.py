"""Build two tiny SYNTHETIC quarterly archives in the FDA ASCII layout.

Every record here is invented to exercise a specific rule (version ordering, ties, FAQ 29 duplicates,
deletions, the FAQ 30 primary-suspect fallback, DN rows, many-to-many drug and reaction rows, salt and
brand-name matching, same-stem non-members). None of it is real adverse-event data and none of it is
used in any study result.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path

DEMO_H = ("primaryid$caseid$caseversion$i_f_code$event_dt$mfr_dt$init_fda_dt$fda_dt$rept_cod$auth_num$mfr_num$"
          "mfr_sndr$lit_ref$age$age_cod$age_grp$sex$e_sub$wt$wt_cod$rept_dt$to_mfr$occp_cod$reporter_country$occr_country")
DRUG_H = ("primaryid$caseid$drug_seq$role_cod$drugname$prod_ai$val_vbm$route$dose_vbm$cum_dose_chr$cum_dose_unit$"
          "dechal$rechal$lot_num$exp_dt$nda_num$dose_amt$dose_unit$dose_form$dose_freq")
REAC_H = "primaryid$caseid$pt$drug_rec_act"
OUTC_H = "primaryid$caseid$outc_cod"


def demo(pid, cid, ver, fda_dt, init_dt, i_f="I"):
    f = [pid, cid, ver, i_f, "", "", init_dt, fda_dt, "EXP", "", "", "SYNTHETIC", "", "", "", "", "F", "Y", "", "",
         fda_dt, "", "MD", "US", "US"]
    return "$".join(f)


def drug(pid, cid, seq, role, name, ai):
    f = [pid, cid, str(seq), role, name, ai, "1", "", "", "", "", "", "", "", "", "", "", "", "", ""]
    return "$".join(f)


def reac(pid, cid, pt):
    return "$".join([pid, cid, pt, ""])


# Quarter 1 (labelled 2025Q1 inside the synthetic demo project)
Q1 = {
    "DEMO": [
        demo("1001", "100", "1", "20250110", "20250110"),          # case 100 v1, superseded by v2 in Q2
        demo("1011", "101", "1", "20250111", "20250111"),          # SGLT2 (salt) as SS only
        demo("1021", "102", "1", "20250112", "20250112"),          # DPP-4 brand name, PROD_AI missing
        demo("1031", "103", "1", "20250113", "20250113"),          # unexposed v1, exposed v2
        demo("1041", "104", "1", "20250114", "20250114"),          # same-stem non-member (vildagliptin)
        demo("1051", "105", "1", "20250115", "20250115"),          # DPP-4 concomitant only (background)
        demo("1061", "106", "1", "20250116", "20250116"),          # deleted in Q2
        demo("1071", "107", "1", "20250117", "20250117"),          # no PS row: FAQ 30 fallback
        demo("1081", "108", "1", "20250118", "20250118"),          # same PRIMARYID re-sent in Q2 (FAQ 29)
        demo("1115", "111", "5", "20250301", "20240105", "F"),     # tie on version with 11105 in Q2
        demo("1121", "112", "1", "20250119", "20250119"),          # DN first row and no PS
    ],
    "DRUG": [
        drug("1001", "100", 1, "PS", "JARDIANCE", "EMPAGLIFLOZIN"),
        drug("1001", "100", 2, "C", "METFORMIN", "METFORMIN HYDROCHLORIDE"),
        drug("1011", "101", 1, "PS", "LISINOPRIL", "LISINOPRIL"),
        drug("1011", "101", 2, "SS", "FARXIGA", "DAPAGLIFLOZIN PROPANEDIOL"),
        drug("1021", "102", 1, "PS", "JANUVIA 100MG", ""),
        drug("1031", "103", 1, "PS", "ATORVASTATIN", "ATORVASTATIN CALCIUM"),
        drug("1041", "104", 1, "PS", "GALVUS", "VILDAGLIPTIN"),
        drug("1051", "105", 1, "PS", "IBUPROFEN", "IBUPROFEN"),
        drug("1051", "105", 2, "C", "JANUVIA", "SITAGLIPTIN PHOSPHATE"),
        drug("1061", "106", 1, "PS", "EMPAGLIFLOZIN", "EMPAGLIFLOZIN"),
        drug("1071", "107", 1, "C", "TRADJENTA", "LINAGLIPTIN"),
        drug("1071", "107", 2, "SS", "ASPIRIN", "ASPIRIN"),
        drug("1081", "108", 1, "PS", "ASPIRIN", "ASPIRIN"),
        drug("1115", "111", 1, "PS", "ASPIRIN", "ASPIRIN"),
        drug("1121", "112", 1, "DN", "ONGLYZA", "SAXAGLIPTIN HYDROCHLORIDE"),
        drug("1121", "112", 2, "C", "OMEPRAZOLE", "OMEPRAZOLE"),
    ],
    "REAC": [
        reac("1001", "100", "Diabetic ketoacidosis"), reac("1001", "100", "Nausea"),
        reac("1001", "100", "Vomiting"), reac("1001", "100", "Dehydration"),
        reac("1011", "101", "Fournier's gangrene"),
        reac("1021", "102", "Pemphigoid"),
        reac("1031", "103", "Arthralgia"),
        reac("1041", "104", "Pemphigoid"),
        reac("1051", "105", "Pancreatitis acute"),
        reac("1061", "106", "Ketoacidosis"),
        reac("1071", "107", "Arthralgia"),
        reac("1081", "108", "Headache"),
        reac("1115", "111", "Headache"),
        reac("1121", "112", "Pancreatitis"),
    ],
    "OUTC": ["$".join(["1001", "100", "HO"])],
    "DELE": [],
}

Q2 = {
    "DEMO": [
        demo("1002", "100", "2", "20250410", "20250110", "F"),
        demo("1032", "103", "2", "20250413", "20250113", "F"),
        demo("1093", "109", "3", "20250415", "20230105", "F"),     # follow-up only, first received before window
        demo("1081", "108", "1", "20250418", "20250118"),          # FAQ 29 duplicate: later extract wins
        demo("11105", "111", "5", "20250415", "20240105", "F"),    # tie on version 5; later FDA_DT wins
    ],
    "DRUG": [
        drug("1002", "100", 1, "PS", "JARDIANCE", "EMPAGLIFLOZIN"),
        drug("1032", "103", 1, "PS", "ATORVASTATIN", "ATORVASTATIN CALCIUM"),
        drug("1032", "103", 2, "SS", "JANUVIA", ""),
        drug("1093", "109", 1, "PS", "STEGLATRO", "ERTUGLIFLOZIN PIDOLATE"),
        drug("1081", "108", 1, "PS", "ONGLYZA", "SAXAGLIPTIN HYDROCHLORIDE"),
        drug("11105", "111", 1, "PS", "ASPIRIN", "ASPIRIN"),
    ],
    "REAC": [
        reac("1002", "100", "Euglycaemic diabetic ketoacidosis"),
        reac("1002", "100", "Nausea"),
        reac("1032", "103", "Arthralgia"),
        reac("1093", "109", "Diabetic ketoacidosis"),
        reac("1081", "108", "Pancreatitis"),
        reac("11105", "111", "Arthralgia"),
    ],
    "OUTC": [],
    "DELE": ["106"],
}

# Background filler: unexposed cases so every cell of every table is populated.
FILLER_PT = ["Headache", "Nausea", "Arthralgia", "Pancreatitis", "Ketoacidosis", "Pemphigoid", "Fournier's gangrene",
             "Fatigue", "Rash", "Dizziness"]
for i in range(60):
    pid, cid = f"2{i:03d}1", f"2{i:03d}"
    Q1["DEMO"].append(demo(pid, cid, "1", "20250201", "20250201"))
    Q1["DRUG"].append(drug(pid, cid, 1, "PS", "ACETAMINOPHEN", "ACETAMINOPHEN"))
    Q1["REAC"].append(reac(pid, cid, FILLER_PT[i % len(FILLER_PT)]))
# Exposed filler without the events, so b cells are populated.
for i, (name, ai) in enumerate([("JARDIANCE", "EMPAGLIFLOZIN"), ("FARXIGA", "DAPAGLIFLOZIN"),
                                ("JANUVIA", "SITAGLIPTIN"), ("TRADJENTA", "LINAGLIPTIN")] * 3):
    pid, cid = f"3{i:03d}1", f"3{i:03d}"
    Q1["DEMO"].append(demo(pid, cid, "1", "20250202", "20250202"))
    Q1["DRUG"].append(drug(pid, cid, 1, "PS", name, ai))
    Q1["REAC"].append(reac(pid, cid, "Fatigue"))


def _member(lines, header):
    body = "\r\n".join(([header] if header else []) + lines) + "\r\n"
    return body.encode("latin-1")


def write_quarter(path: Path, data: dict, yyq: str) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(f"ASCII/DEMO{yyq}.txt", _member(data["DEMO"], DEMO_H))
        zf.writestr(f"ASCII/DRUG{yyq}.txt", _member(data["DRUG"], DRUG_H))
        zf.writestr(f"ASCII/REAC{yyq}.txt", _member(data["REAC"], REAC_H))
        zf.writestr(f"ASCII/OUTC{yyq}.txt", _member(data["OUTC"], OUTC_H))
        zf.writestr(f"Deleted/DELETE{yyq}.txt", ("\n" + "\n".join(data["DELE"]) + "\n").encode())
        zf.writestr("SYNTHETIC_FIXTURE_README.txt", b"Synthetic records for software tests. Not FDA data.\n")


def build(outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    p1, p2 = outdir / "faers_ascii_2025Q1.zip", outdir / "faers_ascii_2025Q2.zip"
    write_quarter(p1, Q1, "25Q1")
    write_quarter(p2, Q2, "25Q2")
    return {"2025Q1": p1, "2025Q2": p2}


if __name__ == "__main__":
    import sys
    print(build(Path(sys.argv[1] if len(sys.argv) > 1 else "fixture_out")))
