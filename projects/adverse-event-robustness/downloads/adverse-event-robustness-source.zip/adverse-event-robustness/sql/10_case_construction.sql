-- Case construction from the column-limited Parquet copies of the quarterly ASCII files.
-- {parquet} is replaced with the project Parquet directory at run time.
-- Semantics follow FDA ASC_NTS (PRIMARYID = CASEID || CASEVERSION; CASEVERSION 1 = initial)
-- and the FAQ file shipped with each extract (identical case/version in two extracts: use the later record;
-- deleted-case lists published from 2019Q1 onward).

-- 1. Every DEMO row as delivered, with its extract quarter.
CREATE OR REPLACE TABLE demo_raw AS
SELECT * FROM read_parquet('{parquet}/demo/*.parquet');

-- 2. One row per PRIMARYID (report version). When the same PRIMARYID appears in more than one extract,
--    the row from the later extract is kept, together with that extract's DRUG/REAC/OUTC rows.
CREATE OR REPLACE TABLE report_version AS
WITH d AS (
    SELECT *,
        TRY_CAST(caseversion AS INTEGER) AS cv_field,
        CASE WHEN caseid IS NOT NULL AND starts_with(primaryid, caseid) AND length(primaryid) > length(caseid)
             THEN TRY_CAST(substr(primaryid, length(caseid) + 1) AS INTEGER) END AS cv_derived,
        row_number() OVER (PARTITION BY primaryid ORDER BY src_quarter DESC, fda_dt DESC NULLS LAST) AS rn_pid,
        count(*) OVER (PARTITION BY primaryid) AS n_extracts_with_pid
    FROM demo_raw
    WHERE primaryid IS NOT NULL
)
SELECT
    primaryid, caseid,
    caseversion AS caseversion_raw,
    COALESCE(cv_field, cv_derived, 0) AS caseversion_num,
    CASE WHEN cv_field IS NOT NULL THEN 'field'
         WHEN cv_derived IS NOT NULL THEN 'derived_from_primaryid'
         ELSE 'missing_ranked_lowest' END AS version_source,
    (cv_field IS NOT NULL AND cv_derived IS NOT NULL AND cv_field <> cv_derived) AS version_field_conflict,
    i_f_code, event_dt, mfr_dt, init_fda_dt, fda_dt, rept_cod, mfr_sndr, lit_ref, age, age_cod, sex, occp_cod,
    reporter_country, occr_country, rept_dt, src_quarter, n_extracts_with_pid
FROM d
WHERE rn_pid = 1;

-- 3. Deleted CASEIDs listed in any acquired extract.
CREATE OR REPLACE TABLE deleted_case AS
SELECT caseid, min(src_quarter) AS first_listed_in, max(src_quarter) AS last_listed_in, count(*) AS n_listings
FROM read_parquet('{parquet}/dele/*.parquet')
WHERE caseid IS NOT NULL AND regexp_full_match(caseid, '[0-9]+')
GROUP BY caseid;

-- 4. Latest available version per CASEID within the acquired window.
--    Order: highest case version, then latest FDA receipt date, then later extract, then larger PRIMARYID.
CREATE OR REPLACE TABLE case_latest AS
WITH ranked AS (
    SELECT rv.*,
        row_number() OVER w AS rn,
        count(*) OVER (PARTITION BY caseid) AS n_versions_in_window,
        min(caseversion_num) OVER (PARTITION BY caseid) AS min_version_in_window,
        count(*) FILTER (WHERE caseversion_num = max_v) OVER (PARTITION BY caseid) AS n_rows_at_max_version
    FROM (SELECT *, max(caseversion_num) OVER (PARTITION BY caseid) AS max_v FROM report_version) rv
    WINDOW w AS (PARTITION BY caseid ORDER BY caseversion_num DESC, fda_dt DESC NULLS LAST,
                 src_quarter DESC, primaryid DESC)
)
SELECT r.* EXCLUDE (rn, max_v),
    (dc.caseid IS NOT NULL) AS is_deleted,
    dc.first_listed_in AS deleted_first_listed_in,
    (dc.caseid IS NOT NULL AND r.src_quarter > dc.last_listed_in) AS version_after_deletion_listing
FROM ranked r
LEFT JOIN deleted_case dc USING (caseid)
WHERE rn = 1;

-- 5. Alternative ordering diagnostic: latest FDA receipt date first. Counts disagreements only.
CREATE OR REPLACE TABLE case_latest_by_fda_dt AS
SELECT caseid, primaryid FROM (
    SELECT caseid, primaryid,
        row_number() OVER (PARTITION BY caseid ORDER BY fda_dt DESC NULLS LAST, caseversion_num DESC,
                           src_quarter DESC, primaryid DESC) AS rn
    FROM report_version) WHERE rn = 1;

-- 6. Report-version unit table (diagnostic comparator): every retained PRIMARYID, deletion flag by CASEID.
CREATE OR REPLACE TABLE version_unit AS
SELECT rv.primaryid, rv.caseid, rv.src_quarter, rv.caseversion_num,
    (dc.caseid IS NOT NULL) AS is_deleted,
    (cl.primaryid IS NOT NULL) AS is_case_latest
FROM report_version rv
LEFT JOIN deleted_case dc USING (caseid)
LEFT JOIN case_latest cl ON cl.primaryid = rv.primaryid;

-- 7. Drug and reaction rows attached to retained report versions (same PRIMARYID and same extract).
CREATE OR REPLACE TABLE drug_rv AS
SELECT d.primaryid, d.src_quarter, TRY_CAST(d.drug_seq AS BIGINT) AS drug_seq, upper(trim(d.role_cod)) AS role_cod,
    d.drugname, d.prod_ai
FROM read_parquet('{parquet}/drug/*.parquet') d
JOIN report_version rv ON rv.primaryid = d.primaryid AND rv.src_quarter = d.src_quarter;

CREATE OR REPLACE TABLE reac_rv AS
SELECT r.primaryid, r.src_quarter, r.pt
FROM read_parquet('{parquet}/reac/*.parquet') r
JOIN report_version rv ON rv.primaryid = r.primaryid AND rv.src_quarter = r.src_quarter;

-- 8. FDA FAQ rule for reports lacking a primary suspect: treat the first listed drug (lowest DRUG_SEQ) as PS.
--    Rows coded DN (Drug Not Administered, a ROLE_COD value documented from the 2024Q4 extract onward)
--    are never designated.
CREATE OR REPLACE TABLE ps_designation AS
WITH s AS (
    SELECT primaryid, bool_or(role_cod = 'PS') AS has_ps,
           min(drug_seq) FILTER (WHERE coalesce(role_cod, '') <> 'DN') AS first_seq
    FROM drug_rv GROUP BY primaryid
)
SELECT primaryid, has_ps, first_seq FROM s;
