"""Load the frozen Crossref Retraction Watch snapshot as a notice table.

One row per Retraction Watch record. ``RetractionNature`` is kept as the
source's own vocabulary (Retraction, Correction, Expression of concern,
Reinstatement). Identifiers are normalized with the same rules as references.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import pandas as pd

from .dates import from_rw
from .identifiers import normalize_doi, normalize_pmid

NATURE_TO_CLAIM = {
    "Retraction": "retraction",
    "Correction": "correction",
    "Expression of concern": "expression_of_concern",
    "Reinstatement": "reinstatement",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_notices(csv_path: Path) -> pd.DataFrame:
    raw = pd.read_csv(csv_path, dtype=str, keep_default_na=False, encoding="utf-8")
    raw = raw.loc[:, [c for c in raw.columns if not c.startswith("Unnamed")]]
    rows = []
    for r in raw.to_dict("records"):
        od = normalize_doi(r["OriginalPaperDOI"])
        nd = normalize_doi(r["RetractionDOI"])
        nd_date = from_rw(r["RetractionDate"])
        od_date = from_rw(r["OriginalPaperDate"], source="retraction_watch_original")
        nature = r["RetractionNature"].strip()
        rows.append(
            {
                "rw_record_id": r["Record ID"].strip(),
                "rw_nature": nature,
                "claim_type": NATURE_TO_CLAIM.get(nature, "unrecognized"),
                "title": r["Title"],
                "authors": r["Author"],
                "journal": r["Journal"],
                "publisher": r["Publisher"],
                "article_type": r["ArticleType"],
                "reason": r["Reason"],
                "urls": r["URLS"],
                "notice_date_raw": r["RetractionDate"],
                "notice_date_start": nd_date.start,
                "notice_date_end": nd_date.end,
                "notice_doi_raw": r["RetractionDOI"],
                "notice_doi": nd.normalized,
                "notice_doi_status": nd.status,
                "notice_pmid": normalize_pmid(r["RetractionPubMedID"]),
                "original_date_raw": r["OriginalPaperDate"],
                "original_year": od_date.start.year if od_date.known else None,
                "original_doi_raw": r["OriginalPaperDOI"],
                "original_doi": od.normalized,
                "original_doi_status": od.status,
                "original_pmid": normalize_pmid(r["OriginalPaperPubMedID"]),
            }
        )
    df = pd.DataFrame(rows)
    if not df["rw_record_id"].is_unique:
        raise ValueError("Retraction Watch Record ID is not unique in the snapshot")
    return df


def source_columns() -> list[str]:
    return [
        "Record ID", "Title", "Subject", "Institution", "Journal", "Publisher", "Country",
        "Author", "URLS", "ArticleType", "RetractionDate", "RetractionDOI",
        "RetractionPubMedID", "OriginalPaperDate", "OriginalPaperDOI",
        "OriginalPaperPubMedID", "RetractionNature", "Reason", "Paywalled", "Notes",
    ]
