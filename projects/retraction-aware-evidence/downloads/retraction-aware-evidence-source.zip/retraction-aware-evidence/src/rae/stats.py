"""Review-level cluster bootstrap for ratio-of-sums proportions."""

from __future__ import annotations

import numpy as np
import pandas as pd


class ClusterBootstrap:
    """Resample reviews with replacement, reusing one weight matrix for all metrics.

    A proportion over reference occurrences is a ratio of review-level sums
    (numerator and denominator), so each replicate is W @ num / W @ den with W
    the multinomial resampling counts.
    """

    def __init__(self, clusters: pd.Series, replicates: int, seed: int):
        self.index = pd.Index(sorted(clusters.dropna().unique()))
        n = len(self.index)
        rng = np.random.default_rng(seed)
        self.W = rng.multinomial(n, np.full(n, 1.0 / n), size=replicates).astype(np.float64)
        self.replicates = replicates
        self.seed = seed

    def _sums(self, df: pd.DataFrame, cluster: str, col: str) -> np.ndarray:
        s = df.groupby(cluster)[col].sum()
        return s.reindex(self.index, fill_value=0).to_numpy(dtype=np.float64)

    def ratio(self, df: pd.DataFrame, cluster: str, num: str, den: str | None = None) -> dict:
        d = df.copy()
        if den is None:
            d["_den"] = 1.0
            den = "_den"
        n_vec = self._sums(d, cluster, num)
        d_vec = self._sums(d, cluster, den)
        total_n, total_d = float(n_vec.sum()), float(d_vec.sum())
        est = total_n / total_d if total_d else float("nan")
        with np.errstate(invalid="ignore", divide="ignore"):
            reps = (self.W @ n_vec) / (self.W @ d_vec)
        reps = reps[np.isfinite(reps)]
        lo, hi = (np.percentile(reps, [2.5, 97.5]) if len(reps) else (float("nan"), float("nan")))
        return {"numerator": int(round(total_n)), "denominator": int(round(total_d)), "estimate": est,
                "ci_low": float(lo), "ci_high": float(hi), "ci_method": f"review cluster bootstrap, {self.replicates} resamples, seed {self.seed}"}


def wilson(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return float(centre - half), float(centre + half)
