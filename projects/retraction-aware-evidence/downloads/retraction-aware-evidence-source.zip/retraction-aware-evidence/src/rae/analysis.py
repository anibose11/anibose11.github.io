"""Analysis stage: prespecified tables, intervals, sensitivity analyses.

Every table written here has an explicit grain. Occurrence-level proportions
carry review-level cluster bootstrap intervals. Outputs go to
``outputs/tables`` (CSV), ``outputs/figures`` and ``outputs/workbooks``.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .config import Config
from .figures import make_figures
from .outputs import write_aggregate_workbook, write_review_queue
from .dates import DateInterval, from_medline_date, from_parts, timing as interval_timing
from .stats import ClusterBootstrap, wilson

CLAIM_ORDER = ["retraction", "expression_of_concern", "correction", "reinstatement", "update"]
LEDGER_ORDER = ["verified_pubmed_record", "doi_not_in_pubmed", "record_not_found", "ambiguous", "endpoint_unavailable",
                "malformed_identifier_only", "no_identifier"]
TIMING_ORDER = ["before_review", "within_lead_window", "after_review", "indeterminate"]


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_id(cfg: Config) -> str:
    """Deterministic run id from the frozen inputs and configuration."""
    interim = cfg.path("interim")
    h = hashlib.sha256()
    h.update(cfg["retraction_watch"]["sha256"].encode())
    h.update((interim / "frame_manifest.csv").read_bytes())
    for f in sorted(interim.glob("*.parquet")):
        h.update(f.name.encode())
        h.update(_sha(f).encode())
    h.update(json.dumps(cfg.data, sort_keys=True, default=str).encode())
    return h.hexdigest()[:16]


def load(cfg: Config) -> dict:
    p = cfg.path("processed")
    i = cfg.path("interim")
    d = {
        "ledger": pd.read_parquet(p / "occurrence_ledger.parquet"),
        "ledger_tag": pd.read_parquet(p / "occurrence_ledger_tagged_only.parquet"),
        "claims": pd.read_parquet(p / "claims.parquet"),
        "claims_tag": pd.read_parquet(p / "claims_tagged_only.parquet"),
        "agreement": pd.read_parquet(p / "rw_identifier_agreement.parquet"),
        "cited_notices": pd.read_parquet(p / "cited_notices.parquet"),
        "works": pd.read_parquet(p / "works.parquet"),
        "fuzzy": pd.read_parquet(p / "fuzzy_review_queue.parquet"),
        "review_dates": pd.read_parquet(p / "review_dates.parquet"),
        "occ": pd.read_parquet(i / "occurrences.parquet"),
        "idents": pd.read_parquet(i / "occurrence_identifiers.parquet"),
        "reviews": pd.read_parquet(i / "reviews.parquet"),
        "retrieval": pd.read_csv(i / "review_retrieval.csv", dtype=str),
        "parse": pd.read_csv(i / "review_parse.csv"),
        "frame": pd.read_csv(i / "frame_manifest.csv", dtype={"pmid": str}),
        "contexts": pd.read_parquet(i / "citation_contexts.parquet"),
        "expanded": pd.read_parquet(p / "expanded_identifiers.parquet"),
    }
    return d


def _fmt_row(name: str, res: dict, **extra) -> dict:
    return {"metric": name, **extra, **res}


def identifier_coverage(d: dict, boot: ClusterBootstrap) -> pd.DataFrame:
    rows = []
    for variant, led in (("all_identifiers", d["ledger"]), ("tagged_only", d["ledger_tag"])):
        x = led[["occurrence_id", "review_pmcid", "has_doi", "has_pmid", "has_pmcid", "n_usable_ids"]].copy()
        x["any_id"] = (x["n_usable_ids"] > 0).astype(int)
        x["doi"] = x["has_doi"].astype(int)
        x["pmid"] = x["has_pmid"].astype(int)
        x["pmcid"] = x["has_pmcid"].astype(int)
        x["doi_and_pmid"] = (x["has_doi"] & x["has_pmid"]).astype(int)
        x["doi_only"] = (x["has_doi"] & ~x["has_pmid"] & ~x["has_pmcid"]).astype(int)
        x["pmid_or_pmcid_no_doi"] = (~x["has_doi"] & (x["has_pmid"] | x["has_pmcid"])).astype(int)
        for col, label in [("any_id", "any usable DOI, PMID or PMCID"), ("doi", "DOI"), ("pmid", "PMID"), ("pmcid", "PMCID"),
                           ("doi_and_pmid", "DOI and PMID"), ("doi_only", "DOI without PMID or PMCID"),
                           ("pmid_or_pmcid_no_doi", "PMID or PMCID without DOI")]:
            rows.append(_fmt_row(label, boot.ratio(x, "review_pmcid", col), variant=variant, grain="reference occurrence"))
    return pd.DataFrame(rows)


def provenance_table(d: dict) -> pd.DataFrame:
    i = d["idents"]
    t = i.assign(usable=i["normalized"].notna()).groupby(["kind", "provenance", "usable"]).size().reset_index(name="identifier_strings")
    return t


def ledger_table(d: dict, boot: ClusterBootstrap) -> pd.DataFrame:
    rows = []
    for variant, led in (("all_identifiers", d["ledger"]), ("tagged_only", d["ledger_tag"])):
        x = led[["occurrence_id", "review_pmcid", "ledger_category"]].copy()
        for cat in LEDGER_ORDER:
            x["_ind"] = (x["ledger_category"] == cat).astype(int)
            rows.append(_fmt_row(cat, boot.ratio(x, "review_pmcid", "_ind"), variant=variant, grain="reference occurrence"))
    return pd.DataFrame(rows)


def _flag_frame(led: pd.DataFrame, claims: pd.DataFrame, arm: str, claim_type: str | None, source: str | None = None,
                exclude_ambiguous: bool = False) -> pd.DataFrame:
    c = claims[claims["arm"] == arm]
    if claim_type:
        c = c[c["claim_type"] == claim_type]
    if source:
        c = c[c["source"] == source]
    flagged = set(c["occurrence_id"])
    x = led[["occurrence_id", "review_pmcid", "ledger_category", "work_id"]].copy()
    x["_ind"] = x["occurrence_id"].isin(flagged).astype(int)
    if exclude_ambiguous:
        x.loc[x["ledger_category"] == "ambiguous", "_ind"] = 0
    return x


def arm_table(d: dict, boot: ClusterBootstrap, led_key="ledger", claims_key="claims", variant="all_identifiers") -> pd.DataFrame:
    led, claims = d[led_key], d[claims_key]
    rows = []
    for arm in ("A", "B", "C"):
        for ct in [None] + CLAIM_ORDER:
            if arm != "C" and ct == "update":
                continue
            x = _flag_frame(led, claims, arm, ct)
            r = boot.ratio(x, "review_pmcid", "_ind")
            c = claims[(claims["arm"] == arm) & ((claims["claim_type"] == ct) if ct else True)]
            occ_ids = set(c["occurrence_id"])
            sub = led[led["occurrence_id"].isin(occ_ids)]
            unique_resolved = sub[sub["ledger_category"] != "ambiguous"]
            rows.append(
                {
                    "variant": variant, "arm": arm, "claim_type": ct or "any status claim",
                    "occurrences_flagged": r["numerator"], "occurrences_total": r["denominator"],
                    "share": r["estimate"], "ci_low": r["ci_low"], "ci_high": r["ci_high"],
                    "occurrences_flagged_unambiguous": len(unique_resolved),
                    "reviews_with_flag": int(sub["review_pmcid"].nunique()),
                    "unique_works_flagged": int(unique_resolved["work_id"].dropna().nunique()),
                    "notices_linked": int(c.drop_duplicates(["source", "notice_key"]).shape[0]),
                    "rw_records_linked": int(c.loc[c["source"] == "retraction_watch", "notice_key"].nunique()),
                    "pubmed_notices_linked": int(c.loc[c["source"] == "pubmed", "notice_key"].nunique()),
                }
            )
    return pd.DataFrame(rows)


def increments(d: dict) -> pd.DataFrame:
    """What each step adds: B minus A (crosswalk) and C minus B (PubMed relations)."""
    claims = d["claims"]
    rows = []
    for ct in [None] + CLAIM_ORDER:
        def occs(arm):
            c = claims[claims["arm"] == arm]
            if ct:
                c = c[c["claim_type"] == ct]
            return set(c["occurrence_id"])

        a, b, c = occs("A"), occs("B"), occs("C")
        rows.append({"claim_type": ct or "any status claim", "arm_A": len(a), "arm_B": len(b), "arm_C": len(c),
                     "added_by_crosswalk_B_not_A": len(b - a), "in_A_not_B": len(a - b),
                     "added_by_pubmed_C_not_B": len(c - b), "in_B_not_C": len(b - c)})
    return pd.DataFrame(rows)


def source_overlap(d: dict) -> pd.DataFrame:
    """Per occurrence and claim type: claimed by Retraction Watch, PubMed, or both (arm C)."""
    c = d["claims"][d["claims"]["arm"] == "C"]
    g = c.groupby(["occurrence_id", "claim_type"])["source"].agg(lambda s: "|".join(sorted(set(s)))).reset_index()
    g["sources"] = g["source"].map({"retraction_watch": "Retraction Watch only", "pubmed": "PubMed only",
                                     "pubmed|retraction_watch": "both"})
    t = g.groupby(["claim_type", "sources"]).size().reset_index(name="occurrences")
    led = d["ledger"].set_index("occurrence_id")
    g["work_id"] = g["occurrence_id"].map(led["work_id"])
    w = g.dropna(subset=["work_id"]).drop_duplicates(["work_id", "claim_type", "sources"]).groupby(["claim_type", "sources"]).size()
    t["unique_works"] = [int(w.get((r.claim_type, r.sources), 0)) for r in t.itertuples()]
    return t


def match_basis_table(d: dict) -> pd.DataFrame:
    c = d["claims"][(d["claims"]["arm"] == "C")]
    led = d["ledger"].set_index("occurrence_id")
    c = c.assign(ledger_category=c["occurrence_id"].map(led["ledger_category"]))
    c["confidence"] = np.where(c["ledger_category"] == "ambiguous", "ambiguous_identifiers", c["match_basis"])
    return c.groupby(["source", "claim_type", "confidence"]).size().reset_index(name="claims")


def agreement_table(d: dict) -> pd.DataFrame:
    a = d["agreement"]
    return a.groupby(["rw_doi_agreement", "rw_pmid_agreement"]).size().reset_index(name="claims")


def timing_table(d: dict, claims_key="claims", variant="all_identifiers") -> pd.DataFrame:
    c = d[claims_key]
    c = c[c["arm"] == "C"]
    rows = []
    for col, label in [("timing_primary", "first online date (primary)"), ("timing_issue", "issue date (S2)"),
                       ("timing_six_month", "first online date, 183-day lead (S3)")]:
        for ct in [None] + CLAIM_ORDER:
            sub = c if ct is None else c[c["claim_type"] == ct]
            # occurrence level: one timing per occurrence and claim type. A
            # determinate class is kept only when every claim of that type agrees
            g = sub.groupby(["occurrence_id", "claim_type"])[col].agg(lambda s: s.iloc[0] if s.nunique() == 1 else "indeterminate")
            vc = g.value_counts()
            n = int(len(g))
            det = int(n - vc.get("indeterminate", 0))
            lo, hi = wilson(det, n)
            rows.append({"variant": variant, "timing_reference": label, "claim_type": ct or "any status claim", "flagged_occurrence_claims": n,
                         **{k: int(vc.get(k, 0)) for k in TIMING_ORDER}, "determinate": det,
                         "determinate_share": det / n if n else float("nan"), "wilson_low": lo, "wilson_high": hi})
    return pd.DataFrame(rows)


def timing_by_source(d: dict) -> pd.DataFrame:
    c = d["claims"][d["claims"]["arm"] == "C"]
    return c.groupby(["source", "claim_type", "timing_primary"]).size().reset_index(name="claims")


def indeterminate_reasons(d: dict) -> pd.DataFrame:
    c = d["claims"][(d["claims"]["arm"] == "C") & (d["claims"]["timing_primary"] == "indeterminate")].copy()
    reason = np.where(c["notice_date_start"].isna(), "notice date unavailable",
                      np.where(c["online_start"].isna(), "review date unavailable", "intervals overlap"))
    c["reason"] = reason
    return c.groupby(["source", "claim_type", "reason"]).size().reset_index(name="claims")


REFSOURCE_DATE = re.compile(r"\b((?:19|20)\d\d)(?:\s+([A-Z][a-z]{2})(?:-[A-Z][a-z]{2})?(?:\s+(\d{1,2}))?)?")


def refsource_interval(refsource: str) -> DateInterval:
    """Date interval from a PubMed RefSource string (amendment A1, exploratory)."""
    if not isinstance(refsource, str) or not refsource:
        return DateInterval(None, None, "unknown", "refsource")
    m = re.search(r"\b(?:19|20)\d\d\s+[A-Z][a-z]{2}-[A-Z][a-z]{2}\b", refsource)
    if m:
        return from_medline_date(m.group(0), "refsource")
    m = REFSOURCE_DATE.search(refsource)
    if not m:
        return DateInterval(None, None, "unknown", "refsource")
    return from_parts(m.group(1), m.group(2), m.group(3), "refsource")


def refsource_amendment(d: dict) -> pd.DataFrame:
    """Amendment A1 (post hoc, exploratory): timing for PubMed relations without a notice PMID."""
    c = d["claims"]
    c = c[(c["arm"] == "C") & (c["source"] == "pubmed") & (c["notice_date_source"] == "notice_record_unavailable")].copy()
    rows = []
    for r in c.itertuples(index=False):
        iv = refsource_interval(r.refsource)
        rev = DateInterval(pd.Timestamp(r.online_start).date() if pd.notna(r.online_start) else None,
                           pd.Timestamp(r.online_end).date() if pd.notna(r.online_end) else None, "x")
        rows.append({"claim_type": r.claim_type, "parsed_precision": iv.precision, "timing_refsource": interval_timing(iv, rev)})
    t = pd.DataFrame(rows, columns=["claim_type", "parsed_precision", "timing_refsource"])
    if t.empty:
        return pd.DataFrame(columns=["claim_type", "relations_without_notice_pmid", "date_parsed", "before_review", "after_review", "indeterminate", "label"])
    out = t.groupby("claim_type").agg(
        relations_without_notice_pmid=("timing_refsource", "size"),
        date_parsed=("parsed_precision", lambda s: int((s != "unknown").sum())),
        day_precision=("parsed_precision", lambda s: int((s == "day").sum())),
        month_or_range_precision=("parsed_precision", lambda s: int(s.isin(["month", "range"]).sum())),
        year_precision=("parsed_precision", lambda s: int((s == "year").sum())),
        before_review=("timing_refsource", lambda s: int((s == "before_review").sum())),
        after_review=("timing_refsource", lambda s: int((s == "after_review").sum())),
        indeterminate=("timing_refsource", lambda s: int((s == "indeterminate").sum())),
    ).reset_index()
    out["label"] = "post hoc amendment A1, exploratory and not part of the primary results"
    return out


def cohort_flow(d: dict) -> pd.DataFrame:
    fr, ret, parse = d["frame"], d["retrieval"], d["parse"]
    occ = d["occ"]
    rows = [
        ("PubMed frame records (query run 2026-10-07)", len(fr)),
        ("Selected by identifier hash order", int(fr["selected"].sum())),
        ("Selected with a PubMed record", int((ret["pubmed_status"] == "found").sum())),
        ("Selected with a PMCID", int(ret["pmcid"].notna().sum())),
        ("Open-access version in the PMC cloud dataset", int((ret["status"] == "retrieved").sum())),
        ("JATS XML parsed", int(parse["parse_status"].isin(["parsed", "no_reference_list"]).sum())),
        ("Reviews with a reference list", int((parse["parse_status"] == "parsed").sum())),
        ("Reference occurrences", len(occ)),
    ]
    out = pd.DataFrame(rows, columns=["step", "count"])
    return out


def review_level(d: dict) -> pd.DataFrame:
    led, claims = d["ledger"], d["claims"]
    n_rev = led["review_pmcid"].nunique()
    rows = []
    for arm in ("A", "B", "C"):
        for ct in [None, "retraction", "expression_of_concern", "correction"]:
            c = claims[claims["arm"] == arm]
            if ct:
                c = c[c["claim_type"] == ct]
            k = c.merge(led[["occurrence_id", "review_pmcid"]], on="occurrence_id")["review_pmcid"].nunique()
            lo, hi = wilson(int(k), int(n_rev))
            rows.append({"arm": arm, "claim_type": ct or "any status claim", "reviews_with_flag": int(k), "reviews": int(n_rev),
                         "share": k / n_rev, "wilson_low": lo, "wilson_high": hi})
    return pd.DataFrame(rows)


def by_year(d: dict) -> pd.DataFrame:
    led = d["ledger"].merge(d["review_dates"][["pmcid", "online_start"]], left_on="review_pmcid", right_on="pmcid", how="left")
    led["review_year"] = pd.to_datetime(led["online_start"]).dt.year
    flagged = set(d["claims"].loc[(d["claims"]["arm"] == "C") & (d["claims"]["claim_type"] == "retraction"), "occurrence_id"])
    led["retraction_flag"] = led["occurrence_id"].isin(flagged)
    g = led.groupby("review_year").agg(
        reviews=("review_pmcid", "nunique"), occurrences=("occurrence_id", "size"),
        any_identifier=("n_usable_ids", lambda s: float((s > 0).mean())),
        doi=("has_doi", "mean"), pmid=("has_pmid", "mean"),
        verified_pubmed_record=("ledger_category", lambda s: float((s == "verified_pubmed_record").mean())),
        occurrences_with_retraction_claim=("retraction_flag", "sum"),
    ).reset_index()
    return g


def sensitivity_table(d: dict, boot: ClusterBootstrap) -> pd.DataFrame:
    rows = []
    led, claims = d["ledger"], d["claims"]
    # primary
    for label, lk, ck in (("primary (all identifiers)", "ledger", "claims"), ("S1 tagged identifiers only", "ledger_tag", "claims_tag")):
        for ct in ("retraction", "expression_of_concern", "correction"):
            x = _flag_frame(d[lk], d[ck], "C", ct)
            r = boot.ratio(x, "review_pmcid", "_ind")
            rows.append({"analysis": label, "measure": f"occurrences with a {ct} claim (arm C)", **r})
        x = d[lk][["review_pmcid", "n_usable_ids"]].assign(_ind=lambda t: (t["n_usable_ids"] > 0).astype(int))
        rows.append({"analysis": label, "measure": "occurrences with any usable identifier", **boot.ratio(x, "review_pmcid", "_ind")})
    # S4 unique works
    c = claims[claims["arm"] == "C"].merge(led[["occurrence_id", "work_id", "ledger_category"]], on="occurrence_id")
    works_total = led["work_id"].dropna().nunique()
    for ct in ("retraction", "expression_of_concern", "correction"):
        k = c[(c["claim_type"] == ct) & (c["ledger_category"] != "ambiguous")]["work_id"].dropna().nunique()
        lo, hi = wilson(int(k), int(works_total))
        rows.append({"analysis": "S4 unique cited works", "measure": f"works with a {ct} claim (arm C)", "numerator": int(k),
                     "denominator": int(works_total), "estimate": k / works_total, "ci_low": lo, "ci_high": hi, "ci_method": "Wilson (works are not independent of reviews)"})
    # S5 excluding cited notices
    notice_occ = set(d["cited_notices"]["occurrence_id"])
    led5 = led[~led["occurrence_id"].isin(notice_occ)]
    for ct in ("retraction", "expression_of_concern", "correction"):
        x = _flag_frame(led5, claims, "C", ct)
        rows.append({"analysis": "S5 excluding references that cite a notice", "measure": f"occurrences with a {ct} claim (arm C)", **boot.ratio(x, "review_pmcid", "_ind")})
    return pd.DataFrame(rows)


def notices_table(d: dict) -> pd.DataFrame:
    c = d["claims"][d["claims"]["arm"] == "C"].merge(d["ledger"][["occurrence_id", "work_id"]], on="occurrence_id")
    per_work = c.dropna(subset=["work_id"]).groupby("work_id").agg(
        notices=("notice_key", "nunique"), claim_types=("claim_type", lambda s: "|".join(sorted(set(s)))),
        sources=("source", lambda s: "|".join(sorted(set(s)))), citing_occurrences=("occurrence_id", "nunique"),
    ).reset_index()
    return per_work


def no_identifier_types(d: dict) -> pd.DataFrame:
    """JATS publication-type attribute of occurrences without any identifier."""
    led = d["ledger"]
    ids = set(led.loc[led["ledger_category"] == "no_identifier", "occurrence_id"])
    o = d["occ"][d["occ"]["occurrence_id"].isin(ids)]
    t = o["publication_type"].replace("", "not stated").value_counts().rename_axis("jats_publication_type").reset_index(name="occurrences")
    t["share"] = t["occurrences"] / t["occurrences"].sum()
    return t


def retraction_text_signals(cfg: Config) -> pd.DataFrame:
    """Lexical signals for retraction-flagged occurrences. No stance is inferred."""
    q = pd.read_csv(cfg.path("tables") / "review_queue.csv")
    r = q[q["claim_type"] == "retraction"]
    g = r.groupby("occurrence_id").agg(
        timing=("timing_primary", lambda s: s.iloc[0] if s.nunique() == 1 else "indeterminate"),
        reference_text_mentions_retraction=("reference_text_mentions_retraction", "max"),
        sentence_available=("citing_sentences", lambda s: bool(isinstance(s.iloc[0], str) and s.iloc[0] and not s.iloc[0].startswith("withheld"))),
        sentence_mentions_retraction=("citing_sentence_mentions_retraction", "max"),
    )
    out = g.groupby("timing").agg(
        occurrences=("reference_text_mentions_retraction", "size"),
        reference_text_mentions_retraction=("reference_text_mentions_retraction", "sum"),
        citing_sentence_available=("sentence_available", "sum"),
        citing_sentence_mentions_retraction=("sentence_mentions_retraction", "sum"),
    ).reset_index()
    out["note"] = "lexical match on 'retract' only, not a judgment of how the study was used"
    return out


def tableau_exports(cfg: Config, d: dict, out: dict) -> list[str]:
    """Flat CSVs for a Tableau workbook. See docs/tableau_spec.md for grain and rules."""
    tdir = cfg.root / "outputs" / "tableau"
    tdir.mkdir(parents=True, exist_ok=True)
    rd = d["review_dates"][["pmcid", "online_start"]].rename(columns={"pmcid": "review_pmcid"})
    rd["review_year"] = pd.to_datetime(rd["online_start"]).dt.year
    led = d["ledger"].merge(rd[["review_pmcid", "review_year"]], on="review_pmcid", how="left")
    c = d["claims"][d["claims"]["arm"] == "C"].merge(led[["occurrence_id", "review_pmcid", "review_year", "ledger_category"]], on="occurrence_id")
    flagged = c[["occurrence_id", "review_pmcid", "review_year", "claim_type", "source", "source_label", "notice_key", "match_basis",
                 "ledger_category", "timing_primary", "timing_issue", "timing_six_month"]].copy()
    flagged["match_confidence"] = np.where(flagged["ledger_category"] == "ambiguous", "ambiguous_identifiers", flagged["match_basis"])
    flagged["row_grain"] = "claim (occurrence x source x notice)"
    flagged["suppression_flag"] = "none"
    flagged.to_csv(tdir / "tableau_claims.csv", index=False)
    by_year = led.groupby(["review_year", "ledger_category"]).size().reset_index(name="occurrences")
    by_year["year_total_occurrences"] = by_year.groupby("review_year")["occurrences"].transform("sum")
    by_year["row_grain"] = "review year x ledger category (reference occurrences)"
    by_year["suppression_flag"] = "none"
    by_year.to_csv(tdir / "tableau_ledger_by_year.csv", index=False)
    denom = led.groupby("review_year").agg(reviews=("review_pmcid", "nunique"), occurrences=("occurrence_id", "size")).reset_index()
    denom.to_csv(tdir / "tableau_denominators_by_year.csv", index=False)
    head = pd.concat([
        out["identifier_coverage"].assign(table="identifier_coverage"),
        out["coverage_ledger"].assign(table="coverage_ledger"),
    ], ignore_index=True)[["table", "variant", "metric", "numerator", "denominator", "estimate", "ci_low", "ci_high", "ci_method"]]
    head["filter_rule"] = "precomputed, do not filter or re-aggregate"
    head["suppression_flag"] = "none"
    head.to_csv(tdir / "tableau_headline_intervals.csv", index=False)
    return [str(p.relative_to(cfg.root)) for p in sorted(tdir.glob("*.csv"))]


def analyze(cfg: Config) -> dict:
    d = load(cfg)
    rid = run_id(cfg)
    tables = cfg.path("tables")
    boot = ClusterBootstrap(d["ledger"]["review_pmcid"], int(cfg["analysis"]["bootstrap_replicates"]), int(cfg["analysis"]["bootstrap_seed"]))
    out = {
        "cohort_flow": cohort_flow(d),
        "identifier_coverage": identifier_coverage(d, boot),
        "identifier_provenance": provenance_table(d),
        "coverage_ledger": ledger_table(d, boot),
        "arm_comparison": pd.concat([arm_table(d, boot), arm_table(d, boot, "ledger_tag", "claims_tag", "tagged_only")], ignore_index=True),
        "arm_increments": increments(d),
        "source_overlap": source_overlap(d),
        "match_confidence": match_basis_table(d),
        "rw_identifier_agreement": agreement_table(d),
        "timing": pd.concat([timing_table(d), timing_table(d, "claims_tag", "tagged_only")], ignore_index=True),
        "timing_by_source": timing_by_source(d),
        "timing_indeterminate_reasons": indeterminate_reasons(d),
        "amendment_a1_refsource_timing": refsource_amendment(d),
        "review_level": review_level(d),
        "by_review_year": by_year(d),
        "sensitivity": sensitivity_table(d, boot),
        "works_with_claims": notices_table(d),
        "cited_notices_summary": d["cited_notices"].groupby(["source", "claim_type"]).size().reset_index(name="occurrences"),
        "fuzzy_queue_summary": (d["fuzzy"].groupby("claim_type").agg(candidates=("rw_record_id", "size"), occurrences=("occurrence_id", "nunique")).reset_index()
                                if len(d["fuzzy"]) else pd.DataFrame(columns=["claim_type", "candidates", "occurrences"])),
    }
    for name, df in out.items():
        df.to_csv(tables / f"{name}.csv", index=False)
    figs = make_figures(cfg, out)
    queue = write_review_queue(cfg, d)
    extra = {"no_identifier_types": no_identifier_types(d), "retraction_text_signals": retraction_text_signals(cfg)}
    for name, df in extra.items():
        df.to_csv(tables / f"{name}.csv", index=False)
    out.update(extra)
    tableau = tableau_exports(cfg, d, out)
    agg = write_aggregate_workbook(cfg, out, rid)
    meta = {"run_id": rid, "tables": sorted(f"{k}.csv" for k in out), "figures": figs, "review_queue": queue, "aggregate_workbook": agg,
            "tableau": tableau}
    (tables / "analysis_meta.json").write_text(json.dumps(meta, indent=1, default=str))
    return meta
