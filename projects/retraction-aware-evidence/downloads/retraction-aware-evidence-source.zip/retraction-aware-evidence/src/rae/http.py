"""Rate-limited HTTP client with an immutable on-disk response cache.

Every response that passes validation is stored gzip-compressed under a key
derived from the request. A request log records the URL, parameters (without
any email address), status, content hash and retrieval time, so a later run can
show exactly which responses an analysis used. Responses that fail validation
(for example an HTML error page returned with status 200) are never cached.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import httpx

PRIVATE_PARAMS = {"email", "api_key"}


class FetchError(RuntimeError):
    """Raised when a request still fails after the allowed attempts."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


@dataclass
class CachedResponse:
    content: bytes
    status: int
    content_type: str
    sha256: str
    from_cache: bool
    retrieved_utc: str

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self):
        return json.loads(self.content)


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _public(params: dict | None) -> dict:
    return {k: v for k, v in sorted((params or {}).items()) if k not in PRIVATE_PARAMS}


def cache_key(method: str, url: str, params: dict | None, data: dict | None) -> str:
    blob = json.dumps(
        {"m": method.upper(), "u": url, "p": _public(params), "d": _public(data)},
        sort_keys=True,
        ensure_ascii=True,
    )
    return hashlib.sha256(blob.encode()).hexdigest()


class RateLimiter:
    def __init__(self, min_interval: float):
        self.min_interval = min_interval
        self._lock = threading.Lock()
        self._last = 0.0

    def wait(self) -> None:
        if self.min_interval <= 0:
            return
        with self._lock:
            now = time.monotonic()
            delay = self._last + self.min_interval - now
            if delay > 0:
                time.sleep(delay)
            self._last = time.monotonic()


class CachedClient:
    def __init__(
        self,
        cache_dir: Path,
        min_interval: float = 0.5,
        max_attempts: int = 5,
        timeout: float = 120.0,
        user_agent: str = "retraction-aware-evidence/1.0 (research reference audit)",
        transport: httpx.BaseTransport | None = None,
        sleep=time.sleep,
    ):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.cache_dir / "request_log.jsonl"
        self.limiter = RateLimiter(min_interval)
        self.max_attempts = max_attempts
        self.offline = os.environ.get("RAE_OFFLINE") == "1"
        self._client = httpx.Client(timeout=timeout, headers={"User-Agent": user_agent}, follow_redirects=True, transport=transport)
        self._sleep = sleep
        self._log_lock = threading.Lock()

    def close(self) -> None:
        self._client.close()

    def _paths(self, key: str) -> tuple[Path, Path]:
        sub = self.cache_dir / key[:2]
        return sub / f"{key}.gz", sub / f"{key}.json"

    def _log(self, entry: dict) -> None:
        with self._log_lock, open(self.log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, sort_keys=True) + "\n")

    def get_cached(self, key: str) -> CachedResponse | None:
        body_path, meta_path = self._paths(key)
        if body_path.exists() and meta_path.exists():
            meta = json.loads(meta_path.read_text())
            content = gzip.decompress(body_path.read_bytes())
            if hashlib.sha256(content).hexdigest() != meta["sha256"]:
                raise FetchError(f"cache corruption for {key}")
            return CachedResponse(content, meta["status"], meta["content_type"], meta["sha256"], True, meta["retrieved_utc"])
        return None

    def request(
        self,
        method: str,
        url: str,
        params: dict | None = None,
        data: dict | None = None,
        validate: Callable[[bytes, str], bool] | None = None,
        use_cache: bool = True,
        accept_status: tuple[int, ...] = (200,),
    ) -> CachedResponse:
        key = cache_key(method, url, params, data)
        if use_cache:
            hit = self.get_cached(key)
            if hit is not None:
                return hit
        if self.offline:
            raise FetchError(f"offline mode and no cached response for {method} {url}")
        last_status = None
        last_error = ""
        for attempt in range(1, self.max_attempts + 1):
            self.limiter.wait()
            try:
                resp = self._client.request(method, url, params=params, data=data)
                status = resp.status_code
                last_status = status
                ctype = resp.headers.get("content-type", "")
                content = resp.content
                ok = status in accept_status
                if ok and validate is not None:
                    ok = bool(validate(content, ctype))
                    if not ok:
                        last_error = "validation failed"
                elif not ok:
                    last_error = f"HTTP {status}"
                self._log(
                    {
                        "utc": utc_now(),
                        "method": method.upper(),
                        "url": url,
                        "params": _public(params),
                        "data_keys": sorted(_public(data).keys()),
                        "data_sha256": hashlib.sha256(json.dumps(_public(data), sort_keys=True).encode()).hexdigest() if data else None,
                        "status": status,
                        "attempt": attempt,
                        "accepted": ok,
                        "bytes": len(content),
                        "sha256": hashlib.sha256(content).hexdigest(),
                        "key": key,
                    }
                )
                if ok:
                    digest = hashlib.sha256(content).hexdigest()
                    retrieved = utc_now()
                    if use_cache:
                        body_path, meta_path = self._paths(key)
                        body_path.parent.mkdir(parents=True, exist_ok=True)
                        tmp = body_path.with_suffix(".tmp")
                        tmp.write_bytes(gzip.compress(content, mtime=0))
                        tmp.replace(body_path)
                        meta_path.write_text(
                            json.dumps(
                                {
                                    "method": method.upper(),
                                    "url": url,
                                    "params": _public(params),
                                    "data": _public(data),
                                    "status": status,
                                    "content_type": ctype,
                                    "sha256": digest,
                                    "bytes": len(content),
                                    "retrieved_utc": retrieved,
                                },
                                sort_keys=True,
                            )
                        )
                    return CachedResponse(content, status, ctype, digest, False, retrieved)
                if status in (400, 404) and status not in accept_status:
                    break
                retry_after = resp.headers.get("retry-after")
                pause = float(retry_after) if retry_after and retry_after.isdigit() else min(30.0, 1.5 * 2 ** (attempt - 1))
            except httpx.HTTPError as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                self._log({"utc": utc_now(), "method": method.upper(), "url": url, "params": _public(params), "attempt": attempt, "accepted": False, "error": last_error})
                pause = min(30.0, 1.5 * 2 ** (attempt - 1))
            self._sleep(pause)
        raise FetchError(f"{method} {url} failed after {self.max_attempts} attempts: {last_error}", last_status)


def looks_like_xml(content: bytes, ctype: str) -> bool:
    head = content[:600].lstrip().lower()
    if head.startswith(b"<!doctype html") or b"<html" in head:
        return False
    return head.startswith(b"<?xml") or head.startswith(b"<!doctype") or head.startswith(b"<")


def looks_like_json(content: bytes, ctype: str) -> bool:
    try:
        obj = json.loads(content)
    except Exception:
        return False
    if isinstance(obj, dict) and "error" in obj and isinstance(obj["error"], str):
        return False
    return True
