"""Frame query, frozen manifest and deterministic selection."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from .http import CachedClient, utc_now
from .pubmed import esearch


def selection_key(salt: str, pmid: str) -> str:
    return hashlib.sha256((salt + str(pmid)).encode("utf-8")).hexdigest()


def build_manifest(pmids: list[str], salt: str) -> pd.DataFrame:
    df = pd.DataFrame({"pmid": sorted(set(pmids), key=int)})
    df["selection_key"] = [selection_key(salt, p) for p in df["pmid"]]
    df = df.sort_values("selection_key", kind="mergesort").reset_index(drop=True)
    df["selection_rank"] = range(1, len(df) + 1)
    return df


def freeze_frame(client: CachedClient, cfg, interim: Path, raw: Path) -> pd.DataFrame:
    """Run the frame query once and freeze the manifest.

    If a frozen manifest already exists it is returned unchanged, because the
    live query result changes as PubMed is updated.
    """
    manifest_path = interim / "frame_manifest.csv"
    if manifest_path.exists():
        return pd.read_csv(manifest_path, dtype={"pmid": str})
    res = esearch(client, cfg, cfg["frame"]["query"], retmax=10000)
    count = int(res["count"])
    ids = res["idlist"]
    if count > 10000 or len(ids) != count:
        raise RuntimeError(f"frame returned {len(ids)} of {count} ids, so split the query by year")
    out_dir = raw / "pubmed_frame"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "esearch_frame.json").write_text(
        json.dumps(
            {
                "retrieved_utc": utc_now(),
                "query": cfg["frame"]["query"],
                "querytranslation": res.get("querytranslation"),
                "count": count,
                "idlist": ids,
            },
            indent=1,
        )
    )
    df = build_manifest(ids, cfg["frame"]["selection_salt"])
    df["selected"] = df["selection_rank"] <= int(cfg["frame"]["sample_size"])
    df.to_csv(manifest_path, index=False)
    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    (interim / "frame_manifest.sha256").write_text(f"{digest}  frame_manifest.csv\nfrozen_utc {utc_now()}\n")
    return df
