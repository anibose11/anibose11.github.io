"""Package stage: source archive, static site, handoff files and the portfolio bundle."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from jinja2 import Environment, FileSystemLoader, StrictUndefined

from .config import Config
from .numbers import Numbers

SLUG = "retraction-aware-evidence"
OUTER = "10-retraction-aware-evidence-PROJECT-BUNDLE.zip"

# Allowlist for the source archive (glob patterns relative to the project root).
SOURCE_ALLOW = [
    "README.md", "LICENSE", "NOTICE", "CITATION.cff", "pyproject.toml", "requirements.lock", "source_manifest.json",
    "config/*.yaml", "src/rae/*.py", "sql/*.sql", "tests/*.py", "tests/fixtures/*", "site_src/*", "scripts/*.py",
    "docs/*.md", "docs/*.csv",
    "report/report.qmd", "report/report.css",
    "manuscript/manuscript.qmd", "manuscript/manuscript.css", "manuscript/references.json", "manuscript/biomed-central.csl", "manuscript/refs/raw_csl.json",
    "evidence/claims.json",
    "outputs/tables/*.csv", "outputs/tables/*.json", "outputs/figures/*.svg", "outputs/figures/*.png",
    "outputs/workbooks/*.xlsx", "outputs/tableau/*.csv",
    "data/interim/frame_manifest.csv", "data/interim/frame_manifest.sha256", "data/interim/review_retrieval.csv",
    "data/interim/review_parse.csv", "data/interim/acquire_summary.json",
    "data/raw/pubmed_frame/esearch_frame.json", "data/raw/literature_search/pubmed_searches.json",
    "data/raw/source_docs/pubmed_250101.dtd", "data/raw/source_docs/pmc_s3_README.txt",
    "data/raw/source_docs/retraction_watch_README_fe345427.md",
    "validation/human_validation_worksheet.xlsx",
]
FORBIDDEN = re.compile(r"/Users/|/private/tmp/|/var/folders/|api_key=|NCBI_EMAIL=\S+@")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _fmt_size(n: int) -> str:
    return f"{n / 1024:.0f} KB" if n < 1024 * 1024 else f"{n / 1024 / 1024:.1f} MB"


def write_lock(cfg: Config) -> None:
    out = subprocess.run([sys.executable, "-m", "pip", "freeze", "--exclude-editable"], capture_output=True, text=True).stdout
    lines = [l for l in out.splitlines() if l and not l.startswith("-e ") and "retraction-aware-evidence" not in l]
    (cfg.root / "requirements.lock").write_text("# pip freeze of the environment used for the study run (Python %s)\n" % sys.version.split()[0] + "\n".join(lines) + "\n")


def write_source_manifest(cfg: Config) -> Path:
    root = cfg.root
    rw = cfg["retraction_watch"]
    rw_path = root / "data/raw/retraction_watch" / f"retraction_watch_{rw['commit']}.csv"
    frame = json.loads((root / "data/raw/pubmed_frame/esearch_frame.json").read_text())
    ret = pd.read_csv(root / "data/interim/review_retrieval.csv", dtype=str)
    logs = {}
    for name in ("ncbi", "pmc_cloud"):
        p = cfg.path("cache") / name / "request_log.jsonl"
        n = acc = 0
        if p.exists():
            for line in p.read_text().splitlines():
                n += 1
                acc += json.loads(line).get("accepted", False) is True
        logs[name] = {"requests_logged": n, "accepted": acc}
    docs = []
    for f in sorted((root / "data/raw/source_docs").rglob("*")):
        if f.is_file():
            docs.append({"file": str(f.relative_to(root)), "bytes": f.stat().st_size, "sha256": sha256(f), "retrieved": "2026-10-07"})
    manifest = {
        "generated": "2026-10-07",
        "sources": [
            {"name": "Crossref Retraction Watch data", "url": f"{rw['repository']}/-/raw/{rw['commit']}/{rw['file']}",
             "documentation": rw["documentation"], "version": f"commit {rw['commit']} ({rw['commit_title']})", "reference_period": "records up to 2026-10-06",
             "accessed": "2026-10-07", "bytes": rw_path.stat().st_size if rw_path.exists() else None, "sha256": rw["sha256"], "content_type": "text/csv (served as text/plain)",
             "permitted_use": "Described by Crossref as openly available. The repository has no license file, and no explicit license statement was found in the documentation read on 2026-10-07. Not redistributed here.",
             "redistributed": False},
            {"name": "PubMed frame query (NCBI E-utilities ESearch)", "query": frame["query"], "query_translation": frame["querytranslation"],
             "retrieved_utc": frame["retrieved_utc"], "records": frame["count"], "frozen_manifest": "data/interim/frame_manifest.csv",
             "frozen_manifest_sha256": sha256(root / "data/interim/frame_manifest.csv"),
             "permitted_use": "NCBI E-utilities. Identifiers and dates are factual metadata, and the NCBI disclaimer applies.", "redistributed": "PMIDs only"},
            {"name": "PMC Article Datasets on AWS (pmc-oa-opendata)", "url": "https://pmc-oa-opendata.s3.amazonaws.com/", "registry": "https://registry.opendata.aws/ncbi-pmc",
             "accessed": "2026-10-07", "articles": int((ret["status"] == "retrieved").sum()),
             "xml_bytes_total": int(pd.to_numeric(ret["bytes"], errors="coerce").sum()),
             "integrity": "MD5 from each article's JSON metadata matched for every XML. Per-article SHA-256 values are in data/interim/review_retrieval.csv",
             "permitted_use": "Article-level licenses, mostly Creative Commons. Full text is not redistributed, and citing sentences come only from Creative Commons reviews.",
             "redistributed": "citing sentences for CC-licensed reviews, reference strings and identifiers"},
            {"name": "PubMed records of cited works and notices (NCBI E-utilities EFetch, ESearch)", "accessed": "2026-10-07",
             "rate": "at most 2 requests per second, no API key", "cache": "data/cache/ncbi (not redistributed, each response stored with SHA-256)",
             "request_log_summary": logs["ncbi"], "redistributed": "identifiers, relation types and dates"},
            {"name": "PMC ID Converter API", "url": cfg["ncbi"]["idconv_base"], "accessed": "2026-10-07", "redistributed": "identifiers"},
        ],
        "documentation_snapshots": docs,
        "retrieval_timing": "All logged NCBI requests were made on Wednesday 2026-10-07, batched and limited to 2 per second: 458 between 10:02 and 10:21 UTC and 33 at 11:07 UTC (DOI searches added after a citation-text parsing fix). This was outside NCBI's suggested 9 PM to 5 AM Eastern window for large jobs. Other runs were served from the cache.",
        "rebuild_limits": "PubMed and PMC are updated continuously. The frame manifest is frozen and every response used is cached and hashed, but a rerun without the cache retrieves current records and may differ. The Retraction Watch file is pinned by commit and SHA-256.",
        "pmc_cloud_request_log_summary": logs["pmc_cloud"],
    }
    out = root / "source_manifest.json"
    out.write_text(json.dumps(manifest, indent=1))
    return out


def build_source_zip(cfg: Config, dest: Path) -> dict:
    root = cfg.root
    files = []
    for pat in SOURCE_ALLOW:
        files.extend(sorted(p for p in root.glob(pat) if p.is_file()))
    private = {root / "docs" / "journal_fit.md", root / "src" / "rae" / "release.py"}  # journal-only material stays outside the public archive
    files = sorted(set(files) - private)
    problems = []
    for f in files:
        if f.suffix in (".py", ".md", ".json", ".yaml", ".csv", ".sql", ".qmd", ".css", ".j2", ".toml", ".cff", ".txt", ".lock", ".sha256", ".dtd") or f.name in ("LICENSE", "NOTICE"):
            text = f.read_text(errors="replace")
            if FORBIDDEN.search(text) and f.name != "package.py":
                problems.append(str(f.relative_to(root)))
    if problems:
        raise RuntimeError(f"machine-specific paths or secrets found in: {problems}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in files:
            info = zipfile.ZipInfo(f"{SLUG}/{f.relative_to(root)}", date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, f.read_bytes())
    return {"files": len(files), "bytes": dest.stat().st_size, "sha256": sha256(dest)}


def _arms_rows(n: Numbers) -> list[dict]:
    names = [("retraction", "Retraction"), ("expression_of_concern", "Expression of concern"), ("correction", "Correction"),
             ("reinstatement", "Reinstatement"), ("update", "Update (PubMed only)"), ("any_status_claim", "Any claim")]
    rows = []
    for key, label in names:
        rows.append({"name": label, "a": n.fmt(f"inc_{key}_arm_A"), "b": n.fmt(f"inc_{key}_arm_B"), "c": n.fmt(f"inc_{key}_arm_C"),
                     "reviews": n.fmt(f"armC_{key}_reviews"), "works": n.fmt(f"armC_{key}_works")})
    return rows


def build_site(cfg: Config, staging: Path, source_zip: Path) -> list[Path]:
    n = Numbers(cfg)
    root = cfg.root
    site = staging / "site" / "projects" / SLUG
    (site / "assets").mkdir(parents=True, exist_ok=True)
    (site / "downloads").mkdir(parents=True, exist_ok=True)
    for f in ("fig1_coverage_ledger", "fig2_source_overlap", "fig3_timing", "figS1_coverage_by_year"):
        for ext in ("svg", "png"):
            shutil.copy(root / "outputs/figures" / f"{f}.{ext}", site / "assets" / f"{f}.{ext}")
    shutil.copy(root / "report/report.html", site / "report.html")
    shutil.copy(source_zip, site / "downloads" / f"{SLUG}-source.zip")
    shutil.copy(root / "outputs/workbooks/review_queue.xlsx", site / "downloads" / "review_queue.xlsx")
    shutil.copy(root / "outputs/workbooks/aggregate_results.xlsx", site / "downloads" / "aggregate_results.xlsx")
    tz = site / "downloads" / "result_tables.zip"
    with zipfile.ZipFile(tz, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted((root / "outputs/tables").glob("*.csv")) + sorted((root / "outputs/tableau").glob("*.csv")) + [root / "evidence/claims.json"]:
            info = zipfile.ZipInfo(f"result_tables/{f.parent.name}/{f.name}", date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, f.read_bytes())
    shutil.copy(root / "docs/analysis_plan.md", site / "downloads" / "analysis_plan_with_amendments.md")
    downloads = [
        (f"{SLUG}-source.zip", "Source archive", "Code, SQL, configuration, tests, docs, frozen manifests and result tables"),
        ("review_queue.xlsx", "Review queue workbook", "Every flagged reference with identifiers, claims, dates, timing and source links"),
        ("aggregate_results.xlsx", "Aggregate results workbook", "All result tables with a definitions sheet, units and intervals"),
        ("result_tables.zip", "Result tables (CSV)", "Result tables, Tableau-ready exports and the claims ledger"),
        ("analysis_plan_with_amendments.md", "Analysis plan", "Timestamped plan with three dated amendments (Markdown)"),
    ]
    dl = [{"file": f, "label": l, "desc": d, "size": _fmt_size((site / "downloads" / f).stat().st_size)} for f, l, d in downloads]
    val = json.loads((root / "outputs/tables/validation_report.json").read_text())
    det = val.get("determinism", {})
    ctx = {
        "reviews": n.fmt("reviews_with_refs"), "occurrences": n.fmt("occurrences"), "frame": n.fmt("frame_records"),
        "cov_any": n.fmt("cov_any_id"), "noid": n.fmt("ledger_no_identifier"), "noid_n": n.fmt_count("ledger_no_identifier"),
        "verified": n.fmt_count("ledger_verified_pubmed_record"), "doi_only": n.fmt_count("ledger_doi_not_in_pubmed"),
        "amb": n.fmt_count("ledger_ambiguous"), "amb_pct": n.fmt("ledger_ambiguous"), "malformed": n.fmt_count("ledger_malformed_identifier_only"),
        "crosswalk_added": n.fmt("inc_any_status_claim_added_by_crosswalk_B_not_A"),
        "ret_occ": n.fmt("armC_retraction_occ"), "ret_reviews": n.fmt("armC_retraction_reviews"), "ret_works": n.fmt("armC_retraction_works"),
        "ret_both": n.fmt("overlap_retraction_both"), "ret_rw": n.fmt("overlap_retraction_rw_only"), "ret_pm": n.fmt("overlap_retraction_pm_only"),
        "eoc_occ": n.fmt("armC_expression_of_concern_occ"), "eoc_both": n.fmt("overlap_expression_of_concern_both"),
        "eoc_rw": n.fmt("overlap_expression_of_concern_rw_only"), "eoc_pm": n.fmt("overlap_expression_of_concern_pm_only"),
        "cor_occ": n.fmt("armC_correction_occ"), "cor_both": n.fmt("overlap_correction_both"), "cor_pm": n.fmt("overlap_correction_pm_only"),
        "ret_before": n.fmt("timing_primary_retraction_before_review"), "ret_after": n.fmt("timing_primary_retraction_after_review"),
        "ret_indet": n.fmt("timing_primary_retraction_indeterminate"), "a1": n.fmt("a1_correction_relations_without_notice_pmid"),
        "tests": val["software_tests"]["summary"].replace(" in ", " tests in ").split(" in ")[0].replace("passed tests", "tests passed") if val["software_tests"]["passed"] else "Software tests did not all pass",
        "reconciled": n.fmt("val_claims_reconciled"), "checked": n.fmt("val_claims_checked"),
        "det": f"all {det.get('files_compared', 0)} output tables exactly" if det.get("all_identical") else "the outputs with the differences listed in the validation report",
    }
    hr_path = root / "validation" / "human_review_summary.json"
    ctx["human"] = json.loads(hr_path.read_text()).get("site_sentence", "") if hr_path.exists() else ""
    ts = pd.read_csv(root / "outputs/tables/timing_by_source.csv")
    g = lambda ct, src, tm: int(ts[(ts.claim_type == ct) & (ts.source == src) & (ts.timing_primary == tm)]["claims"].sum())
    ctx.update({"t_rw_before": g("retraction", "retraction_watch", "before_review"), "t_rw_after": g("retraction", "retraction_watch", "after_review"),
                "t_pm_before": g("retraction", "pubmed", "before_review"), "t_pm_after": g("retraction", "pubmed", "after_review"),
                "t_pm_indet": g("retraction", "pubmed", "indeterminate"), "t_cor_indet": f"{g('correction', 'pubmed', 'indeterminate'):,}"})
    env = Environment(loader=FileSystemLoader(str(root / "site_src")), undefined=StrictUndefined, autoescape=True)
    html = env.get_template("index.html.j2").render(n=ctx, arms=_arms_rows(n), downloads=dl)
    (site / "index.html").write_text(html)
    return sorted(p for p in (staging / "site").rglob("*") if p.is_file())


def write_handoff(cfg: Config, staging: Path, public_files: list[Path], src_info: dict) -> list[Path]:
    root = cfg.root
    n = Numbers(cfg)
    hand = staging / "handoff"
    hand.mkdir(parents=True, exist_ok=True)
    val = json.loads((root / "outputs/tables/validation_report.json").read_text())
    human = root / "validation" / "human_review_summary.json"
    human_done = human.exists()
    findings = []
    for key, text in [
        ("cov_any_id", "Reference occurrences with a usable DOI, PMID or PMCID"),
        ("ledger_verified_pubmed_record", "Reference occurrences resolving to one verified PubMed record"),
        ("ledger_no_identifier", "Reference occurrences with no identifier"),
        ("inc_any_status_claim_arm_A", "Occurrences flagged by exact DOI against Retraction Watch (arm A)"),
        ("inc_any_status_claim_added_by_crosswalk_B_not_A", "Occurrences added by verified identifier crosswalks (arm B minus A)"),
        ("inc_any_status_claim_arm_C", "Occurrences flagged after adding PubMed relations (arm C)"),
        ("armC_retraction_occ", "Occurrences with a retraction claim (arm C)"),
        ("armC_retraction_reviews", "Reviews citing at least one work with a retraction claim"),
        ("overlap_retraction_pm_only", "Retraction-flagged occurrences recorded only in PubMed"),
        ("overlap_retraction_rw_only", "Retraction-flagged occurrences recorded only in Retraction Watch"),
        ("timing_primary_retraction_before_review", "Retraction notices dated before the review's first online date"),
        ("timing_primary_retraction_after_review", "Retraction notices dated after the review's first online date"),
        ("timing_primary_correction_det_share", "Correction-flagged occurrences with determinate timing"),
    ]:
        it = n.items[key]
        findings.append({"finding": text, "value": n.fmt(key), "numerator": it["numerator"], "denominator": it["denominator"],
                         "evidence_path": it["path"], "selector": it["selector"]})
    files = []
    for p in public_files:
        files.append({"path": str(p.relative_to(staging)), "bytes": p.stat().st_size, "sha256": sha256(p)})
    meta = {
        "slug": SLUG,
        "title": "Retraction-aware evidence linkage for cardiometabolic reviews",
        "featured": False,
        "summary": "An audit of 62,740 references in 1,000 open-access cardiometabolic systematic reviews against a frozen Crossref Retraction Watch snapshot and PubMed relations. Identifier crosswalks changed little. The status source changed which studies were flagged, and notice dates were sometimes indeterminate or disagreed across sources.",
        "status": {
            "computational_completion": "complete: acquire, build, analyze, validate, render and package ran on the full cohort",
            "manuscript": "final version formatted for Research Integrity and Peer Review (Research article), prepared after the author's verification and instructions of 2026-10-07. Not submitted." if human_done else "complete draft. The author's independent verification is not yet recorded. Not submitted.",
            "unresolved_prerequisites": (["recommended before submission: reserve a Zenodo DOI for the source archive and send it back (see the DOI deposit package)",
                                          "at submission: decide on the article processing charge or request a waiver", "at submission: add an ORCID if available"] if human_done
                                         else ["author's independent verification of flagged claims and the 100-reference parse sample"]),
        },
        "data_versions": {
            "retraction_watch": f"GitLab crossref/retraction-watch-data commit {cfg['retraction_watch']['commit']} (data for 2026-10-06), SHA-256 {cfg['retraction_watch']['sha256']}",
            "pubmed": "E-utilities responses retrieved 2026-10-07, cached with SHA-256",
            "pmc": "PMC Article Datasets on AWS, retrieved 2026-10-07; MD5 verified",
            "frame_manifest_sha256": sha256(root / "data/interim/frame_manifest.csv"),
        },
        "key_limitations": [
            "A deterministic sample of PMC open-access reviews selected through PubMed indexing, not a census.",
            "Matches are agreement with two sources at snapshot dates, not sensitivity to all real retractions.",
            "Retraction Watch and PubMed are not independent, so their agreement is not confirmation.",
            "Flagged retraction counts are small (46 occurrences).",
            "A citation does not show use of a study's data, and no pooled effects were re-analyzed.",
        ],
        "paths": {"page": f"site/projects/{SLUG}/index.html", "report": f"site/projects/{SLUG}/report.html",
                  "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip"},
        "executed_commands": ["rae acquire", "rae build", "rae analyze", "rae validate", "rae render", "rae package"],
        "validation": {"software_tests": val["software_tests"]["summary"], "clean_room": "passed" if json.loads((root / ".local/clean_room.json").read_text())["passed"] else "failed", "claims_reconciled": f"{val['claim_reconciliation']['claims_reconciled']}/{val['claim_reconciliation']['claims_checked']}",
                       "offline_rerun_identical": val.get("determinism", {}).get("all_identical"), "source_archive": src_info},
        "measured_findings": findings,
        "public_files": files,
    }
    j = hand / f"{SLUG}.json"
    j.write_text(json.dumps(meta, indent=1))
    return [j]


def _zip_dir(src: Path, out: Path, prefix: str = "") -> int:
    """Write a deterministic zip of src, with every path under prefix."""
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in sorted(p for p in src.rglob("*") if p.is_file()):
            info = zipfile.ZipInfo(prefix + str(f.relative_to(src)), date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, f.read_bytes())
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        count = len(z.namelist())
    if bad:
        raise RuntimeError(f"zip integrity failure in {out.name} at {bad}")
    return count


def package(cfg: Config) -> dict:
    root = cfg.root
    write_lock(cfg)
    write_source_manifest(cfg)
    build_dir = root / ".local" / "build"
    if build_dir.exists():
        shutil.rmtree(build_dir)
    staging = build_dir / "bundle"
    src_zip = build_dir / f"{SLUG}-source.zip"
    src_info = build_source_zip(cfg, src_zip)
    public = build_site(cfg, staging, src_zip)
    clean_path = root / ".local" / "clean_room.json"
    if os.environ.get("RAE_SKIP_CLEAN_ROOM") == "1" and clean_path.exists():
        clean = json.loads(clean_path.read_text())
        if clean.get("source_sha256") != src_info["sha256"]:
            raise RuntimeError("source archive changed since the last clean-room run, so rerun without RAE_SKIP_CLEAN_ROOM")
    else:
        clean = clean_room(src_zip, build_dir / "clean_room")
        clean["source_sha256"] = src_info["sha256"]
        clean_path.write_text(json.dumps(clean, indent=1))
    if not clean["passed"]:
        raise RuntimeError(f"clean-room check failed: {clean['steps'][-1]}")
    write_handoff_docs(cfg, clean, src_info)
    write_handoff(cfg, staging, public, src_info)
    try:
        from . import release
    except ImportError:  # the public source archive builds the portfolio bundle only
        release = None
    if release is not None:
        meta_path = staging / "handoff" / f"{SLUG}.json"
        meta = json.loads(meta_path.read_text())
        meta["other_packages"] = {"journal_submission": f"deliverables/{release.JOURNAL_ZIP}", "doi_deposit": f"deliverables/{release.DOI_ZIP}",
                                  "guide": "deliverables/WHAT_GOES_WHERE.md", "note": "Kept outside this bundle."}
        meta_path.write_text(json.dumps(meta, indent=1))
    for extra in ("handoff/retraction-aware-evidence-validation.md", "handoff/verified_results.md"):
        p = root / extra
        if not p.exists():
            raise RuntimeError(f"missing {extra}, so write it before packaging")
        shutil.copy(p, staging / extra)
    deliv = root / "deliverables"
    deliv.mkdir(parents=True, exist_ok=True)
    for old in deliv.glob("10-*.zip"):
        old.unlink()
    out = deliv / OUTER
    entries = _zip_dir(staging, out)
    digest = sha256(out)
    (deliv / (OUTER + ".sha256")).write_text(f"{digest}  {OUTER}\n")
    result = {"outer_zip": str(out.relative_to(root)), "bytes": out.stat().st_size, "mib": round(out.stat().st_size / 1048576, 2), "sha256": digest,
              "entries": entries, "source_archive": src_info}
    if release is not None:
        journal = release.build_journal(cfg, build_dir / "journal", src_zip)
        doi = release.build_doi(cfg, build_dir / "doi", src_zip)
        release.write_what_goes_where(root, out, journal, doi)
        for key, z in (("journal_zip", journal), ("doi_zip", doi)):
            result[key] = {"path": str(z.relative_to(root)), "bytes": z.stat().st_size, "sha256": sha256(z)}
    return result


def clean_room(src_zip: Path, workdir: Path) -> dict:
    """Extract the source archive into an empty directory, install it, run the tests and the demo."""
    if workdir.exists():
        shutil.rmtree(workdir)
    workdir.mkdir(parents=True)
    with zipfile.ZipFile(src_zip) as z:
        z.extractall(workdir)
    proj = workdir / SLUG
    steps = []

    def run(cmd, timeout=1800):
        p = subprocess.run(cmd, cwd=proj, capture_output=True, text=True, timeout=timeout, env={**os.environ, "RAE_ROOT": str(proj)})
        tail = (p.stdout.strip().splitlines() or [""])[-1] if p.returncode == 0 else (p.stdout + p.stderr)[-1500:]
        steps.append({"command": " ".join(str(c) for c in cmd).replace(str(proj), "<clean dir>"), "returncode": p.returncode, "tail": tail})
        return p.returncode == 0

    ok = run([sys.executable, "-m", "venv", ".venv"])
    ok = ok and run([str(proj / ".venv/bin/pip"), "install", "-q", "-e", ".[test]"])
    ok = ok and run([str(proj / ".venv/bin/python"), "-m", "pytest", "-q", "-p", "no:cacheprovider"])
    ok = ok and run([str(proj / ".venv/bin/rae"), "demo"])
    demo_out = proj / "outputs/demo/FIXTURE_audit_not_study_data.xlsx"
    return {"passed": bool(ok and demo_out.exists()), "steps": steps, "python": sys.version.split()[0],
            "note": "Tests and demo use synthetic fixtures only. This shows that the archive installs and runs, not that the study reran."}


def write_handoff_docs(cfg: Config, clean: dict, src_info: dict) -> None:
    root = cfg.root
    n = Numbers(cfg)
    val = json.loads((root / "outputs/tables/validation_report.json").read_text())
    site = root / "validation" / "site_check.json"
    sc = json.loads(site.read_text()) if site.exists() else None
    vis = root / "validation" / "visual_check.json"
    vc = json.loads(vis.read_text()) if vis.exists() else None
    human = root / "validation" / "human_review_summary.json"
    hr = json.loads(human.read_text()) if human.exists() else None
    det = val.get("determinism", {})
    lines = [
        "# Validation record: retraction-aware-evidence",
        "",
        f"Run id {n.meta['run_id']}. Generated {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}.",
        "",
        "Three different kinds of evidence are kept apart: software testing, source reconciliation, and checks by a person.",
        "",
        "## Software testing",
        f"- Unit and end-to-end tests on synthetic fixtures: {val['software_tests']['summary']}.",
        "- Fixtures cover DOI punctuation and resolver prefixes, percent-encoded SICI DOIs, malformed DOIs that must not be repaired, duplicated notices, a notice DOI cited in place of the article, conflicting PMIDs (ambiguous), a failed request (endpoint unavailable, not 'no event'), incomplete and interval dates, the six-month rule, and offline audits.",
        f"- Clean-room install from the source archive ({src_info['files']} files, {src_info['bytes']:,} bytes, SHA-256 {src_info['sha256']}): {'passed' if clean['passed'] else 'FAILED'} with Python {clean['python']}.",
    ]
    for s in clean["steps"]:
        cmd = re.sub(r"^/.*?/bin/python3(\.\d+)?(?= )", "python3", s["command"])
        tail = s["tail"].strip()
        if "rae demo" in cmd and s["returncode"] == 0:
            tail = "wrote outputs/demo/FIXTURE_audit_not_study_data.xlsx"
        lines.append(f"  - `{cmd}`: exit {s['returncode']}" + (f" ({tail[:160]})" if tail else ""))
    lines += [
        f"- {clean['note']}",
        "",
        "## Source reconciliation (automated, not independent expert validation)",
        f"- Every arm C claim re-read from the raw Retraction Watch CSV (Python `csv`) and the raw cached PubMed XML (`xml.etree`): {val['claim_reconciliation']['claims_reconciled']} of {val['claim_reconciliation']['claims_checked']} confirmed.",
        f"- Count reconciliation: {'all checks passed' if val['count_reconciliation']['all_passed'] else 'FAILED'} ({', '.join(k for k, v in val['count_reconciliation']['checks'].items() if v)}).",
        f"- SQL timing against the Python interval rule: {val['timing_sql_vs_python']['mismatches']} mismatches in {val['timing_sql_vs_python']['claims']} claim rows.",
        f"- Title matcher mechanics: recovered {val['fuzzy_mechanics_check']['recovered_by_title_rule']} of {val['fuzzy_mechanics_check']['identifier_linked_occurrences']} identifier-linked occurrences with identifiers hidden.",
        f"- Determinism ({det.get('mode', 'not run')}): {det.get('files_compared', 0)} tables compared, with tolerance {det.get('tolerance_floats')} for floats and exact equality otherwise. Result: {'all identical' if det.get('all_identical') else 'differences ' + json.dumps(det.get('differences'))}.",
        "- No stochastic model is used. The bootstrap is seeded (20261007), so intervals are reproduced exactly.",
        "",
        "## Public site checks",
    ]
    if sc:
        lines += [f"- Served the extracted bundle over local HTTP ({sc['server']}). Checked {sc['pages']} pages, {sc['links_checked']} local links and assets ({len(sc['broken'])} broken) and {sc['anchors_checked']} in-page anchors ({len(sc['broken_anchors'])} broken). Downloads verified by size and SHA-256: {sc['downloads_ok']}."]
        if sc["broken"] or sc["broken_anchors"]:
            lines.append(f"- Problems: {sc['broken'] + sc['broken_anchors']}")
    else:
        lines.append("- Not yet run for this build.")
    if vc:
        lines += [f"- Visual inspection in the browser pane: {vc['summary']}"]
        for item in vc.get("notes", []):
            lines.append(f"  - {item}")
    else:
        lines.append("- Visual inspection: not yet recorded for this build.")
    lines += ["", "## Checks by a person"]
    if hr:
        lines.append(f"- {hr['handoff_line']}")
    else:
        lines.append("- The author's independent verification (worksheet `validation/human_validation_worksheet.xlsx`: 120 flagged-claim rows and a 100-reference stratified parse sample) has not yet been recorded for this build.")
    lines += ["", "## Not claimed", "- No external scientific validation of Retraction Watch or PubMed themselves.", "- No Tableau workbook or REDCap import was built or tested. A Tableau specification and flat exports are provided.", "- Nothing has been deployed, published or submitted."]
    (root / "handoff" / "retraction-aware-evidence-validation.md").write_text("\n".join(lines) + "\n")

    f = n.fmt
    vr = [
        "# Verified results (private handoff for later editing)",
        "",
        "Only methods that were run and results that were measured are listed. Each line names its evidence file. Nothing here describes deployment, users, adoption, time savings, publication or peer review, because none of those happened.",
        "",
        "## Methods actually run",
        f"- Froze a PubMed frame of {f('frame_records')} open-access cardiometabolic systematic reviews and meta-analyses (2015 to 2025) and selected {f('selected_reviews')} by SHA-256 order of PMID (data/interim/frame_manifest.csv).",
        f"- Parsed {f('occurrences')} reference occurrences from PMC JATS XML retrieved through the PMC Article Datasets on AWS, MD5-verified (outputs/tables/cohort_flow.csv).",
        "- Linked references to a pinned Crossref Retraction Watch snapshot (commit fe345427, data for 2026-10-06) by exact DOI, by verified NCBI identifier crosswalks, and with PubMed CommentsCorrections relations, in DuckDB SQL (sql/).",
        "- Classified notice timing with date intervals and reported occurrence-level proportions with review-level cluster bootstrap intervals (2,000 resamples).",
        f"- Built a CLI (`rae`) with acquire, build, analyze, validate, render, package, recheck and a bibliography `audit` command. Tests: {val['software_tests']['summary']}. Offline rerun identical: {det.get('all_identical')}.",
        "",
        "## Measured results (1,000 PMC open-access reviews, data for 2026-10-06 and 2026-10-07)",
    ]
    for key, text in [("cov_any_id", "reference occurrences with a usable DOI, PMID or PMCID"), ("ledger_verified_pubmed_record", "resolved to one verified PubMed record"),
                      ("ledger_no_identifier", "had no identifier"), ("inc_any_status_claim_arm_A", "occurrences flagged by exact DOI (Retraction Watch)"),
                      ("inc_any_status_claim_added_by_crosswalk_B_not_A", "added by verified crosswalks, both ambiguous"),
                      ("inc_any_status_claim_arm_C", "occurrences flagged with PubMed relations added"),
                      ("armC_retraction_occ", "occurrences with a retraction claim"), ("armC_retraction_reviews", "reviews citing a work with a retraction claim"),
                      ("overlap_retraction_pm_only", "retraction-flagged occurrences only in PubMed"), ("overlap_retraction_rw_only", "retraction-flagged occurrences only in Retraction Watch"),
                      ("timing_primary_retraction_before_review", "retraction notices before the review's online date"),
                      ("timing_primary_retraction_after_review", "retraction notices after the review's online date"),
                      ("timing_primary_correction_det_share", "correction-flagged occurrences with determinate timing")]:
        it = n.items[key]
        vr.append(f"- {f(key)} {text} ({it['path']}, {it['selector']}).")
    vr += ["", ("Status of the manuscript: final version formatted for Research Integrity and Peer Review. Not submitted." if hr else "Status of the manuscript: complete draft formatted for Research Integrity and Peer Review. Not submitted. The author's independent verification is not yet recorded.")]
    (root / "handoff" / "verified_results.md").write_text("\n".join(vr) + "\n")
