"""Configuration loading and project paths."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml


def project_root() -> Path:
    env = os.environ.get("RAE_ROOT")
    if env:
        return Path(env).resolve()
    return Path(__file__).resolve().parents[2]


@dataclass
class Config:
    root: Path
    data: dict

    def __getitem__(self, key):
        return self.data[key]

    def path(self, name: str) -> Path:
        p = self.root / self.data["paths"][name]
        p.mkdir(parents=True, exist_ok=True)
        return p


def load_config(path: str | os.PathLike | None = None) -> Config:
    root = project_root()
    cfg_path = Path(path) if path else root / "config" / "config.yaml"
    with open(cfg_path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    data["frame"]["query"] = " ".join(data["frame"]["query"].split())
    return Config(root=root, data=data)
