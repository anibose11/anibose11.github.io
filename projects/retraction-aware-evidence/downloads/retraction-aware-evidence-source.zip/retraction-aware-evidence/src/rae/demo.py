"""Fast demo on the synthetic fixtures. Not study data and not evidence that the study ran."""

from __future__ import annotations

from .bibliography import audit_file
from .config import Config


def demo(cfg: Config) -> dict:
    fx = cfg.root / "tests" / "fixtures"
    out = cfg.root / "outputs" / "demo" / "FIXTURE_audit_not_study_data.xlsx"
    res = audit_file(cfg, str(fx / "fixture_bibliography.csv"), str(out), "2020-01-15", offline=True, rw_csv=fx / "fixture_rw.csv")
    res["label"] = "synthetic fixture run, tests mechanics only"
    return res
