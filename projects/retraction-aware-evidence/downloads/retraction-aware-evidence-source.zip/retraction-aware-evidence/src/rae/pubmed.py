"""PubMed retrieval through E-utilities and parsing of PubMed XML records.

Only documented E-utilities endpoints are used (ESearch, EFetch). Requests are
POSTed in batches, cached, and split into smaller batches when a batch fails.
An identifier is "not found" only when a successful response omits it. An
identifier whose request kept failing is "failed" and is never treated as
"no record" or "no notice".
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field

from lxml import etree

from .dates import DateInterval, from_medline_date, from_parts
from .http import CachedClient, FetchError, looks_like_json, looks_like_xml
from .identifiers import normalize_doi, normalize_pmcid, normalize_pmid

# PubMed CommentsCorrections RefType values (pubmed_250101.dtd) that carry a
# post-publication status for the record that holds them.
STATUS_REFTYPES = {
    "RetractionIn": "retraction",
    "RetractedandRepublishedIn": "retraction",
    "ExpressionOfConcernIn": "expression_of_concern",
    "ErratumIn": "correction",
    "CorrectedandRepublishedIn": "correction",
    "UpdateIn": "update",
}
# Current NLM publication type names (https://www.nlm.nih.gov/mesh/pubtypes.html,
# read 2026-10-07): "Retraction Notice" labels the notice and "Retracted
# Publication" labels the retracted article. "Retraction of Publication" is the
# earlier name of the notice type and is kept for older records.
NOTICE_PUBTYPES = {
    "Retraction Notice": "retraction_notice",
    "Retraction of Publication": "retraction_notice",
    "Published Erratum": "erratum_notice",
    "Expression of Concern": "expression_of_concern_notice",
}
RETRACTED_PUBTYPE = "Retracted Publication"


@dataclass
class PubmedRecord:
    pmid: str
    kind: str  # article or book
    title: str = ""
    journal: str = ""
    dois: list[str] = field(default_factory=list)
    pmcid: str | None = None
    pubtypes: list[str] = field(default_factory=list)
    relations: list[dict] = field(default_factory=list)  # reftype, refsource, pmid
    electronic_date: DateInterval | None = None
    issue_date: DateInterval | None = None
    first_author: str = ""
    year: int | None = None

    def best_date(self) -> DateInterval:
        if self.electronic_date is not None and self.electronic_date.known:
            return self.electronic_date
        if self.issue_date is not None:
            return self.issue_date
        return DateInterval(None, None, "unknown", "pubmed")


def _params(cfg) -> dict:
    p = {"tool": cfg["ncbi"]["tool"]}
    email = os.environ.get("NCBI_EMAIL")
    if email:
        p["email"] = email
    return p


def _eutils_xml_ok(content: bytes, ctype: str) -> bool:
    if not looks_like_xml(content, ctype):
        return False
    head = content[:2000]
    if b"<ERROR>" in head or b"<eFetchResult>" in head and b"<ERROR>" in content:
        return False
    try:
        etree.fromstring(content, parser=etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=True))
    except etree.XMLSyntaxError:
        return False
    return True


def esearch(client: CachedClient, cfg, term: str, retmax: int = 10000, db: str = "pubmed") -> dict:
    data = {"db": db, "term": term, "retmax": str(retmax), "retmode": "json", **_params(cfg)}

    def ok(content, ctype):
        if not looks_like_json(content, ctype):
            return False
        import json

        obj = json.loads(content)
        return "esearchresult" in obj and "ERROR" not in obj["esearchresult"]

    resp = client.request("POST", cfg["ncbi"]["eutils_base"] + "esearch.fcgi", data=data, validate=ok)
    return resp.json()["esearchresult"]


def _text(el) -> str:
    return "".join(el.itertext()).strip() if el is not None else ""


def _date_from(el, source: str) -> DateInterval | None:
    if el is None:
        return None
    md = el.findtext("MedlineDate")
    if md:
        return from_medline_date(md, source)
    return from_parts(el.findtext("Year"), el.findtext("Month") or el.findtext("Season"), el.findtext("Day"), source)


def parse_record(el) -> PubmedRecord | None:
    tag = etree.QName(el).localname
    if tag == "PubmedArticle":
        pmid = normalize_pmid(el.findtext("MedlineCitation/PMID"))
        if not pmid:
            return None
        art = el.find("MedlineCitation/Article")
        rec = PubmedRecord(pmid=pmid, kind="article")
        rec.title = _text(art.find("ArticleTitle")) if art is not None else ""
        rec.journal = (art.findtext("Journal/ISOAbbreviation") or art.findtext("Journal/Title") or "") if art is not None else ""
        dois: list[str] = []
        for aid in el.findall("PubmedData/ArticleIdList/ArticleId"):
            idtype = aid.get("IdType")
            if idtype == "doi":
                d = normalize_doi(aid.text).normalized
                if d and d not in dois:
                    dois.append(d)
            elif idtype == "pmc":
                rec.pmcid = normalize_pmcid(aid.text)
        if art is not None:
            for loc in art.findall("ELocationID"):
                if loc.get("EIdType") == "doi" and loc.get("ValidYN", "Y") == "Y":
                    d = normalize_doi(loc.text).normalized
                    if d and d not in dois:
                        dois.append(d)
            rec.pubtypes = [_text(p) for p in art.findall("PublicationTypeList/PublicationType")]
            elec = [a for a in art.findall("ArticleDate") if (a.get("DateType") or "").lower() == "electronic"]
            rec.electronic_date = _date_from(elec[0], "pubmed_article_date") if elec else None
            rec.issue_date = _date_from(art.find("Journal/JournalIssue/PubDate"), "pubmed_issue_date")
            au = art.find("AuthorList/Author")
            if au is not None:
                rec.first_author = au.findtext("LastName") or au.findtext("CollectiveName") or ""
        rec.dois = dois
        for cc in el.findall("MedlineCitation/CommentsCorrectionsList/CommentsCorrections"):
            rec.relations.append(
                {
                    "reftype": cc.get("RefType"),
                    "refsource": cc.findtext("RefSource") or "",
                    "pmid": normalize_pmid(cc.findtext("PMID")),
                }
            )
        d = rec.best_date()
        rec.year = d.start.year if d.known else None
        return rec
    if tag == "PubmedBookArticle":
        pmid = normalize_pmid(el.findtext("BookDocument/PMID"))
        if not pmid:
            return None
        rec = PubmedRecord(pmid=pmid, kind="book")
        rec.title = _text(el.find("BookDocument/ArticleTitle")) or _text(el.find("BookDocument/Book/BookTitle"))
        for aid in el.findall("PubmedBookData/ArticleIdList/ArticleId") + el.findall("BookDocument/ArticleIdList/ArticleId"):
            if aid.get("IdType") == "doi":
                d = normalize_doi(aid.text).normalized
                if d and d not in rec.dois:
                    rec.dois.append(d)
        rec.pubtypes = [_text(p) for p in el.findall("BookDocument/PublicationType")]
        rec.issue_date = _date_from(el.find("BookDocument/Book/PubDate"), "pubmed_book_date")
        d = rec.best_date()
        rec.year = d.start.year if d.known else None
        return rec
    return None


def efetch_records(client: CachedClient, cfg, pmids: list[str], batch: int | None = None):
    """Fetch PubMed XML records.

    Returns (records, not_found, failed) where records maps PMID to
    PubmedRecord, not_found holds PMIDs absent from a successful response and
    failed holds PMIDs whose request failed after retries and batch splitting.
    """
    batch = batch or cfg["ncbi"]["efetch_batch"]
    url = cfg["ncbi"]["eutils_base"] + "efetch.fcgi"
    ids = sorted({p for p in (normalize_pmid(x) for x in pmids) if p}, key=int)
    records: dict[str, PubmedRecord] = {}
    not_found: set[str] = set()
    failed: set[str] = set()
    parser = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=True)

    def run(chunk: list[str]):
        data = {"db": "pubmed", "id": ",".join(chunk), "retmode": "xml", **_params(cfg)}
        try:
            resp = client.request("POST", url, data=data, validate=_eutils_xml_ok)
        except FetchError:
            if len(chunk) == 1:
                failed.add(chunk[0])
                return
            mid = len(chunk) // 2
            run(chunk[:mid])
            run(chunk[mid:])
            return
        root = etree.fromstring(resp.content, parser=parser)
        got = set()
        for el in root:
            rec = parse_record(el)
            if rec is not None:
                records[rec.pmid] = rec
                got.add(rec.pmid)
        for p in chunk:
            if p not in got:
                not_found.add(p)

    for i in range(0, len(ids), batch):
        run(ids[i : i + batch])
    return records, not_found, failed


def _quote_doi(doi: str) -> str:
    return '"' + doi.replace('"', "") + '"[aid]'


def doi_search(client: CachedClient, cfg, dois: list[str], batch: int | None = None):
    """Search PubMed for DOIs. Returns (candidates, failed).

    candidates maps each DOI that was searched successfully to the set of PMIDs
    the search returned for its batch. The caller verifies DOI equality on the
    fetched records. A search hit is never accepted on its own.
    """
    batch = batch or cfg["ncbi"]["doi_search_batch"]
    todo = sorted({d for d in dois if d})
    batch_hits: dict[str, set[str]] = {}
    failed: set[str] = set()

    def run(chunk: list[str]):
        term = " OR ".join(_quote_doi(d) for d in chunk)
        try:
            res = esearch(client, cfg, term, retmax=max(500, 5 * len(chunk)))
        except FetchError:
            if len(chunk) == 1:
                failed.add(chunk[0])
                return
            mid = len(chunk) // 2
            run(chunk[:mid])
            run(chunk[mid:])
            return
        if res.get("errorlist") and res["errorlist"].get("phrasesnotfound") is None and res["errorlist"].get("fieldsnotfound"):
            if len(chunk) == 1:
                failed.add(chunk[0])
                return
            mid = len(chunk) // 2
            run(chunk[:mid])
            run(chunk[mid:])
            return
        hits = set(res.get("idlist", []))
        if int(res.get("count", "0")) > len(hits):
            if len(chunk) == 1:
                failed.add(chunk[0])
                return
            mid = len(chunk) // 2
            run(chunk[:mid])
            run(chunk[mid:])
            return
        for d in chunk:
            batch_hits[d] = hits

    for i in range(0, len(todo), batch):
        run(todo[i : i + batch])
    return batch_hits, failed
