"""Build stage: linkage arms, coverage ledger, claims, timing and works.

Runs entirely from cached inputs in ``data/interim`` plus the frozen Retraction
Watch snapshot. Joins are written in SQL (``sql/``) and run in DuckDB. Python
handles the union-find for unique works and the fuzzy review queue.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from .config import Config
from .fuzzy import fuzzy_candidates
from .identifiers import normalize_doi, normalize_pmid
from .retraction_watch import load_notices

log = logging.getLogger("rae.build")
SQL_FILES = ["01_identifiers.sql", "02_crosswalk.sql", "03_ledger.sql", "04_claims.sql"]


class CardinalityError(AssertionError):
    pass


def check_unique(df: pd.DataFrame, cols: list[str], name: str) -> None:
    if df.duplicated(cols).any():
        n = int(df.duplicated(cols).sum())
        raise CardinalityError(f"{name}: {n} duplicate keys on {cols}")


def review_dates(interim: Path) -> pd.DataFrame:
    """First public online date and issue date per review, as intervals."""
    rv = pd.read_parquet(interim / "reviews.parquet")
    pm = pd.read_parquet(interim / "review_pubmed.parquet")
    pm = pm.rename(columns={"pmid": "pmid_frame"})
    df = rv.merge(pm[["pmid_frame", "elec_start", "elec_end", "elec_precision", "issue_start", "issue_end", "issue_precision"]],
                  on="pmid_frame", how="left", validate="one_to_one")
    rows = []
    for r in df.itertuples(index=False):
        if pd.notna(r.jats_epub_start):
            on = (r.jats_epub_start, r.jats_epub_end, "jats_epub", r.jats_epub_precision)
        elif pd.notna(r.elec_start):
            on = (r.elec_start, r.elec_end, "pubmed_article_date", r.elec_precision)
        elif pd.notna(r.issue_start):
            on = (r.issue_start, r.issue_end, "pubmed_issue_date", r.issue_precision)
        elif pd.notna(r.jats_issue_start):
            on = (r.jats_issue_start, r.jats_issue_end, "jats_issue", r.jats_issue_precision)
        else:
            on = (None, None, "unknown", "unknown")
        if pd.notna(r.jats_issue_start):
            iss = (r.jats_issue_start, r.jats_issue_end, "jats_issue", r.jats_issue_precision)
        elif pd.notna(r.issue_start):
            iss = (r.issue_start, r.issue_end, "pubmed_issue_date", r.issue_precision)
        else:
            iss = (None, None, "unknown", "unknown")
        rows.append(
            {
                "pmcid": r.pmcid,
                "online_start": on[0], "online_end": on[1], "online_source": on[2], "online_precision": on[3],
                "issue_start": iss[0], "issue_end": iss[1], "issue_source": iss[2], "issue_precision": iss[3],
            }
        )
    out = pd.DataFrame(rows)
    for c in ["online_start", "online_end", "issue_start", "issue_end"]:
        out[c] = pd.to_datetime(out[c]).dt.date
    check_unique(out, ["pmcid"], "review_dates")
    return out


def _norm_conv(conv: pd.DataFrame) -> pd.DataFrame:
    conv = conv.copy()
    conv["pmid"] = conv["pmid"].map(lambda x: normalize_pmid(x) if pd.notna(x) else None)
    conv["doi"] = conv["doi"].map(lambda x: normalize_doi(x).normalized if pd.notna(x) else None)
    return conv


def _connect(cfg: Config, rw: pd.DataFrame, rdates: pd.DataFrame, variant: str, interim: Path | None = None) -> duckdb.DuckDBPyConnection:
    interim = Path(interim) if interim is not None else cfg.path("interim")
    con = duckdb.connect()
    con.execute("SET threads TO 4")
    for name, fname in [
        ("occurrences", "occurrences.parquet"),
        ("occurrence_identifiers", "occurrence_identifiers.parquet"),
        ("cited_pubmed", "cited_pubmed.parquet"),
        ("cited_pubmed_dois", "cited_pubmed_dois.parquet"),
        ("cited_pubmed_relations", "cited_pubmed_relations.parquet"),
        ("cited_pmid_status", "cited_pmid_status.parquet"),
        ("doi_search", "doi_pmid_search.parquet"),
        ("notice_pubmed", "notice_pubmed.parquet"),
    ]:
        con.execute(f"CREATE TABLE {name} AS SELECT * FROM read_parquet(?)", [str(interim / fname)])
    conv = _norm_conv(pd.read_parquet(interim / "cited_pmcid_conversion.parquet"))
    con.register("pmcid_conv_df", conv)
    con.execute("CREATE TABLE pmcid_conv AS SELECT * FROM pmcid_conv_df")
    con.register("rw_df", rw)
    con.execute("CREATE TABLE rw AS SELECT * FROM rw_df")
    con.register("review_dates_df", rdates)
    con.execute("CREATE TABLE review_dates AS SELECT * FROM review_dates_df")
    if variant == "all":
        con.execute("CREATE VIEW ids_in AS SELECT * FROM occurrence_identifiers")
    elif variant == "tag":
        con.execute("CREATE VIEW ids_in AS SELECT * FROM occurrence_identifiers WHERE provenance = 'tag'")
    else:
        raise ValueError(variant)
    con.execute(f"SET VARIABLE lead_days = {int(cfg['analysis']['six_month_rule_days'])}")
    return con


def _run_sql(con, root: Path, files: list[str]) -> None:
    for f in files:
        con.execute((root / "sql" / f).read_text())


def run_variant(cfg: Config, rw: pd.DataFrame, rdates: pd.DataFrame, variant: str, interim: Path | None = None) -> dict[str, pd.DataFrame]:
    interim = Path(interim) if interim is not None else cfg.path("interim")
    con = _connect(cfg, rw, rdates, variant, interim)
    _run_sql(con, cfg.root, SQL_FILES)
    # claims_all: arm label + claims from each arm
    con.execute(
        """
        CREATE OR REPLACE TABLE claims_all AS
        SELECT 'A' AS arm, occurrence_id, source, notice_key, claim_type, source_label, match_basis, matched_on,
               CAST(NULL AS VARCHAR) AS cited_pmid, CAST(NULL AS VARCHAR) AS notice_pmid, CAST(NULL AS VARCHAR) AS refsource,
               CAST(notice_date_start AS DATE) AS notice_date_start, CAST(notice_date_end AS DATE) AS notice_date_end,
               'retraction_watch' AS notice_date_source
        FROM claims_a
        UNION ALL
        SELECT 'B', occurrence_id, source, notice_key, claim_type, source_label, match_basis, matched_on,
               NULL, NULL, NULL, notice_date_start, notice_date_end, 'retraction_watch'
        FROM claims_b
        UNION ALL
        SELECT 'C', occurrence_id, source, notice_key, claim_type, source_label, match_basis, matched_on,
               NULL, NULL, NULL, notice_date_start, notice_date_end, 'retraction_watch'
        FROM claims_b
        UNION ALL
        SELECT 'C', occurrence_id, source, notice_key, claim_type, source_label, match_basis, matched_on,
               cited_pmid, notice_pmid, refsource, notice_date_start, notice_date_end, notice_date_source
        FROM claims_pubmed_dated
        """
    )
    _run_sql(con, cfg.root, ["05_timing.sql"])
    out = {
        "ledger": con.execute("SELECT * FROM occ_ledger ORDER BY occurrence_id").df(),
        "claims": con.execute("SELECT * FROM claims_timed ORDER BY arm, occurrence_id, source, notice_key").df(),
        "agreement": con.execute("SELECT * FROM claims_b_agreement ORDER BY occurrence_id, notice_key").df(),
        "cited_notices": con.execute("SELECT * FROM cited_notices ORDER BY occurrence_id, source, notice_key").df(),
        "expanded_ids": con.execute("SELECT * FROM occ_expanded_ids ORDER BY occurrence_id, kind, id, origin").df(),
        "pmid_status": con.execute("SELECT * FROM occ_pmid_status ORDER BY occurrence_id, pmid, via").df(),
        "occ_ids": con.execute("SELECT * FROM occ_ids ORDER BY occurrence_id, kind, id").df(),
    }
    con.close()
    n_occ = len(pd.read_parquet(interim / "occurrences.parquet", columns=["occurrence_id"]))
    if len(out["ledger"]) != n_occ:
        raise CardinalityError(f"ledger rows {len(out['ledger'])} != occurrences {n_occ}")
    check_unique(out["ledger"], ["occurrence_id"], "ledger")
    check_unique(out["claims"], ["arm", "occurrence_id", "source", "notice_key", "claim_type", "source_label"], "claims")
    return out


class UnionFind:
    def __init__(self):
        self.parent: dict[str, str] = {}

    def find(self, x: str) -> str:
        self.parent.setdefault(x, x)
        root = x
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[x] != root:
            self.parent[x], x = root, self.parent[x]
        return root

    def union(self, a: str, b: str) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            if ra < rb:
                self.parent[rb] = ra
            else:
                self.parent[ra] = rb


def assign_works(ledger: pd.DataFrame, expanded: pd.DataFrame, occ_ids: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Unique cited works as connected components of identifiers.

    Only occurrences that are not ambiguous contribute edges. A component that
    still holds more than one found PubMed record is reported as a conflict and
    its occurrences get no work id.
    """
    ok = set(ledger.loc[~ledger["ledger_category"].isin(["ambiguous", "no_identifier", "malformed_identifier_only"]), "occurrence_id"])
    uf = UnionFind()
    ex = expanded[expanded["occurrence_id"].isin(ok)]
    pm_extra = occ_ids[(occ_ids["occurrence_id"].isin(ok)) & (occ_ids["kind"] == "pmcid")][["occurrence_id", "kind", "id"]]
    allids = pd.concat([ex[["occurrence_id", "kind", "id"]], pm_extra], ignore_index=True).drop_duplicates()
    allids["node"] = allids["kind"] + ":" + allids["id"]
    for occ_id, nodes in allids.groupby("occurrence_id")["node"]:
        nodes = sorted(nodes)
        for n in nodes[1:]:
            uf.union(nodes[0], n)
        uf.find(nodes[0])
    allids["root"] = allids["node"].map(uf.find)
    found_pm = ledger.loc[ledger["occurrence_id"].isin(ok) & (ledger["n_found"] == 1), ["occurrence_id", "found_pmids"]].copy()
    found_pm["pmid"] = found_pm["found_pmids"].map(lambda v: list(v)[0])  # n_found == 1 guarantees one element
    comp = allids.groupby("root").agg(nodes=("node", lambda s: sorted(set(s)))).reset_index()
    root_of_occ = allids.groupby("occurrence_id")["root"].first()
    found_pm["root"] = found_pm["occurrence_id"].map(root_of_occ)
    pm_per_root = found_pm.groupby("root")["pmid"].agg(lambda s: sorted(set(s)))
    comp["found_pmids"] = comp["root"].map(pm_per_root).map(lambda v: v if isinstance(v, list) else [])
    comp["conflict"] = comp["found_pmids"].map(len) > 1

    def label(row):
        if row["found_pmids"]:
            return "pmid:" + row["found_pmids"][0]
        pm = [n for n in row["nodes"] if n.startswith("pmid:")]
        if pm:
            return sorted(pm, key=lambda n: int(n.split(":")[1]))[0]
        return sorted(row["nodes"])[0]

    comp["work_id"] = comp.apply(label, axis=1)
    comp.loc[comp["conflict"], "work_id"] = None
    work_of_root = comp.set_index("root")["work_id"]
    occ_work = pd.DataFrame({"occurrence_id": root_of_occ.index, "root": root_of_occ.values})
    occ_work["work_id"] = occ_work["root"].map(work_of_root)
    occ_work["work_conflict"] = occ_work["root"].map(comp.set_index("root")["conflict"])
    works = comp[~comp["conflict"]][["work_id", "nodes", "found_pmids"]].copy()
    works["n_nodes"] = works["nodes"].map(len)
    works["nodes"] = works["nodes"].map(lambda v: "|".join(v))
    works["found_pmids"] = works["found_pmids"].map(lambda v: "|".join(v))
    check_unique(works, ["work_id"], "works")
    return occ_work[["occurrence_id", "work_id", "work_conflict"]], works


RW_DB_COLUMNS = ["rw_record_id", "rw_nature", "claim_type", "original_doi", "original_pmid", "notice_doi", "notice_pmid",
                 "notice_date_start", "notice_date_end", "original_year", "title", "journal"]


def rw_for_db(rw: pd.DataFrame) -> pd.DataFrame:
    rw_db = rw[RW_DB_COLUMNS].copy()
    for c in ["notice_date_start", "notice_date_end"]:
        rw_db[c] = pd.to_datetime(rw_db[c]).dt.date
    return rw_db


def build(cfg: Config) -> dict:
    interim = cfg.path("interim")
    processed = cfg.path("processed")
    rw_path = cfg.path("raw") / "retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv"
    rw = load_notices(rw_path)
    rw_db = rw_for_db(rw)
    rdates = review_dates(interim)
    rdates.to_parquet(processed / "review_dates.parquet", index=False)
    summary: dict = {"rw_records": len(rw)}

    results = {}
    for variant in ("all", "tag"):
        res = run_variant(cfg, rw_db, rdates, variant)
        occ_work, works = assign_works(res["ledger"], res["expanded_ids"], res["occ_ids"])
        res["ledger"] = res["ledger"].merge(occ_work, on="occurrence_id", how="left", validate="one_to_one")
        res["works"] = works
        results[variant] = res
        suffix = "" if variant == "all" else "_tagged_only"
        led = res["ledger"].copy()
        led["found_pmids"] = led["found_pmids"].map(lambda v: "|".join(v) if isinstance(v, (list, tuple, np.ndarray)) and len(v) else "")
        led.to_parquet(processed / f"occurrence_ledger{suffix}.parquet", index=False)
        res["claims"].to_parquet(processed / f"claims{suffix}.parquet", index=False)
        res["agreement"].to_parquet(processed / f"rw_identifier_agreement{suffix}.parquet", index=False)
        res["cited_notices"].to_parquet(processed / f"cited_notices{suffix}.parquet", index=False)
        works.to_parquet(processed / f"works{suffix}.parquet", index=False)
        if variant == "all":
            res["expanded_ids"].to_parquet(processed / "expanded_identifiers.parquet", index=False)
            res["pmid_status"].to_parquet(processed / "occurrence_pmid_status.parquet", index=False)
        summary[f"{variant}_ledger"] = led["ledger_category"].value_counts().to_dict()
        summary[f"{variant}_claims_by_arm"] = res["claims"].groupby("arm").size().to_dict()
        summary[f"{variant}_works"] = len(works)
        summary[f"{variant}_work_conflicts"] = int(res["ledger"]["work_conflict"].fillna(False).sum())

    # Fuzzy review queue for occurrences with no arm B Retraction Watch link
    led = results["all"]["ledger"]
    linked = set(results["all"]["claims"].loc[results["all"]["claims"]["arm"] == "B", "occurrence_id"])
    occ = pd.read_parquet(interim / "occurrences.parquet")
    cand = fuzzy_candidates(occ[~occ["occurrence_id"].isin(linked)], rw, results["all"]["expanded_ids"], cfg)
    cand.to_parquet(processed / "fuzzy_review_queue.parquet", index=False)
    summary["fuzzy_candidates"] = len(cand)
    summary["fuzzy_occurrences"] = int(cand["occurrence_id"].nunique()) if len(cand) else 0
    (processed / "build_summary.json").write_text(json.dumps(summary, indent=1, default=str))
    return summary
