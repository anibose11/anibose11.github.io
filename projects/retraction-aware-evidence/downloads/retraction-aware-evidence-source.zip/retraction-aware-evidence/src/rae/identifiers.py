"""Identifier parsing and conservative normalization.

The original string is always kept next to the normalized value. Normalization
only removes presentation (labels, resolver prefixes, percent-encoding, case and
trailing sentence punctuation). It never repairs a DOI by guessing.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import unquote

DOI_SHAPE = re.compile(r"^10\.\d{4,9}/\S+$")
DOI_PREFIX = re.compile(
    r"^(?:(?:https?://)?(?:dx\.|www\.)?doi\.org/|doi\s*:\s*|doi\s+|info:doi/)",
    re.IGNORECASE,
)
DOI_IN_TEXT = re.compile(r"(?<![\w.])(10\.\d{4,9}/[^\s\"'<>\u201c\u201d]+)")
PMID_IN_TEXT = re.compile(r"\bPMID\s*:?\s*(\d{1,9})\b", re.IGNORECASE)
PMCID_IN_TEXT = re.compile(r"\b(PMC\d{4,9})\b")
INVISIBLE = dict.fromkeys(map(ord, "\u00a0\u200b\u200c\u200d\u2060\ufeff"), " ")
TRAILING = ".,;:'\""


@dataclass(frozen=True)
class DoiResult:
    raw: str
    normalized: str | None
    status: str  # "ok", "empty", "malformed"


def normalize_doi(raw: str | None) -> DoiResult:
    """Return the normalized DOI or a reason it could not be used."""
    if raw is None:
        return DoiResult("", None, "empty")
    original = str(raw)
    s = original.translate(INVISIBLE).strip()
    if not s or s.lower() in {"unavailable", "n/a", "na", "none", "0"}:
        return DoiResult(original, None, "empty")
    for _ in range(3):
        stripped = DOI_PREFIX.sub("", s).strip()
        if stripped == s:
            break
        s = stripped
    if "%" in s:
        s = unquote(s)
    s = s.lower()
    changed = True
    while changed and s:
        changed = False
        if s[-1] in TRAILING:
            s = s[:-1]
            changed = True
        elif s.endswith(")") and s.count("(") < s.count(")"):
            s = s[:-1]
            changed = True
        elif s.endswith("]") and s.count("[") < s.count("]"):
            s = s[:-1]
            changed = True
    if DOI_SHAPE.match(s):
        return DoiResult(original, s, "ok")
    return DoiResult(original, None, "malformed")


def normalize_pmid(raw: str | int | None) -> str | None:
    if raw is None:
        return None
    s = str(raw).strip()
    if s.lower().startswith("pmid"):
        s = re.sub(r"^pmid\s*:?\s*", "", s, flags=re.IGNORECASE)
    if re.fullmatch(r"\d+", s):
        s = s.lstrip("0")
        if s and len(s) <= 9:
            return s
    return None


def normalize_pmcid(raw: str | None) -> str | None:
    if raw is None:
        return None
    s = str(raw).strip().upper()
    if re.fullmatch(r"\d{4,9}", s):
        s = "PMC" + s
    m = re.fullmatch(r"PMC(\d{4,9})(?:\.\d+)?", s)
    if m:
        return "PMC" + str(int(m.group(1)))
    return None


def dois_in_text(text: str) -> list[str]:
    """Raw DOI candidates found in free text, in order, without duplicates."""
    seen: list[str] = []
    for m in DOI_IN_TEXT.finditer(text or ""):
        cand = m.group(1)
        if cand not in seen:
            seen.append(cand)
    return seen


def pmids_in_text(text: str) -> list[str]:
    out: list[str] = []
    for m in PMID_IN_TEXT.finditer(text or ""):
        p = normalize_pmid(m.group(1))
        if p and p not in out:
            out.append(p)
    return out


def pmcids_in_text(text: str) -> list[str]:
    out: list[str] = []
    for m in PMCID_IN_TEXT.finditer(text or ""):
        p = normalize_pmcid(m.group(1))
        if p and p not in out:
            out.append(p)
    return out


def doi_from_url(url: str) -> str | None:
    """Raw DOI part of a resolver URL, or None if the URL is not a DOI link."""
    if not url:
        return None
    m = re.match(r"^\s*(?:https?://)?(?:dx\.|www\.)?doi\.org/(.+)$", url, flags=re.IGNORECASE)
    return m.group(1).strip() if m else None
