"""Date intervals with explicit precision, and interval-based timing.

A date with a day is a one-day interval. A year and month spans the month, a
year alone spans the year, and a missing date is unknown. Timing between a notice and a
review is only called "before" or "after" when the two intervals do not overlap.
"""

from __future__ import annotations

import calendar
import re
from dataclasses import dataclass
from datetime import date, timedelta

MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m}
MONTHS.update({m.lower(): i for i, m in enumerate(calendar.month_name) if m})


@dataclass(frozen=True)
class DateInterval:
    start: date | None
    end: date | None
    precision: str  # day, month, year, range, unknown
    source: str = ""

    @property
    def known(self) -> bool:
        return self.start is not None and self.end is not None

    def iso(self) -> str:
        if not self.known:
            return ""
        if self.start == self.end:
            return self.start.isoformat()
        return f"{self.start.isoformat()}/{self.end.isoformat()}"


UNKNOWN = DateInterval(None, None, "unknown")


def _month_end(y: int, m: int) -> date:
    return date(y, m, calendar.monthrange(y, m)[1])


def _month_num(value: str | None) -> int | None:
    if value is None:
        return None
    v = str(value).strip().lower().rstrip(".")
    if not v:
        return None
    if v.isdigit():
        n = int(v)
        return n if 1 <= n <= 12 else None
    return MONTHS.get(v[:3]) if v[:3] in MONTHS else MONTHS.get(v)


def from_parts(year, month=None, day=None, source: str = "") -> DateInterval:
    try:
        y = int(str(year).strip())
    except (TypeError, ValueError):
        return DateInterval(None, None, "unknown", source)
    if not 1000 <= y <= 2100:
        return DateInterval(None, None, "unknown", source)
    m = _month_num(month)
    if m is None:
        return DateInterval(date(y, 1, 1), date(y, 12, 31), "year", source)
    try:
        d = int(str(day).strip()) if day not in (None, "") else None
    except ValueError:
        d = None
    if d is not None:
        try:
            dt = date(y, m, d)
            return DateInterval(dt, dt, "day", source)
        except ValueError:
            pass
    return DateInterval(date(y, m, 1), _month_end(y, m), "month", source)


def from_medline_date(text: str | None, source: str = "") -> DateInterval:
    """Parse PubMed MedlineDate strings such as '2019 Jan-Feb' or '2018-2019'."""
    if not text:
        return DateInterval(None, None, "unknown", source)
    years = [int(y) for y in re.findall(r"\b(1[89]\d\d|20\d\d|2100)\b", text)]
    if not years:
        return DateInterval(None, None, "unknown", source)
    months = [MONTHS[w.lower()[:3]] for w in re.findall(r"[A-Za-z]{3,}", text) if w.lower()[:3] in MONTHS]
    y0, y1 = min(years), max(years)
    if len(set(years)) == 1 and months:
        return DateInterval(date(y0, min(months), 1), _month_end(y0, max(months)), "range", source)
    return DateInterval(date(y0, 1, 1), date(y1, 12, 31), "range" if y0 != y1 else "year", source)


def from_rw(text: str | None, source: str = "retraction_watch") -> DateInterval:
    """Parse Retraction Watch dates of the form 'M/D/YYYY 0:00'."""
    if not text:
        return DateInterval(None, None, "unknown", source)
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})", text)
    if not m:
        return DateInterval(None, None, "unknown", source)
    mo, d, y = (int(x) for x in m.groups())
    try:
        dt = date(y, mo, d)
    except ValueError:
        return DateInterval(None, None, "unknown", source)
    return DateInterval(dt, dt, "day", source)


def timing(notice: DateInterval, review: DateInterval, lead_days: int = 0) -> str:
    """Classify a notice relative to a review.

    before_review: the whole notice interval ends before the review interval
    starts (with ``lead_days`` > 0, at least that many days before).
    within_lead_window: only possible with ``lead_days`` > 0; the notice is
    clearly earlier than the review but by less than the lead.
    after_review: the notice interval starts after the review interval ends.
    Everything else is indeterminate.
    """
    if not notice.known or not review.known:
        return "indeterminate"
    if notice.end < review.start:
        if lead_days <= 0 or notice.end + timedelta(days=lead_days) <= review.start:
            return "before_review"
        return "within_lead_window"
    if notice.start > review.end:
        return "after_review"
    return "indeterminate"
