"""Render stage: references, claims ledger, Quarto report and manuscript."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from .config import Config
from .numbers import Numbers

KEYS = {
    "pmid:31666272": "avenell2019", "pmid:40268307": "xu2025", "pmid:40163084": "granapossamai2025", "pmid:35210962": "brown2022",
    "pmid:35779825": "kataoka2022", "pmid:37463764": "bakker2024", "pmid:40156496": "sebo2026performance", "pmid:39973475": "sebo2026accuracy",
    "pmid:32843870": "theismahon2020", "pmid:31260017": "grey2019", "pmid:33557605": "bolland2022", "pmid:28758029": "vaught2017",
    "pmid:29288863": "gray2018", "pmid:42498084": "begagic2026", "pmid:42415189": "bocina2026", "pmid:17938396": "vonelm2007",
    "doi:10.31222/osf.io/gvfk5_v4": "salami2026", "doi:10.1038/d41586-024-02747-1": "cabanac2024", "doi:10.1162/qss_a_00155": "hsiao2021",
    "doi:10.1002/asi.23913": "schmidt2018", "doi:10.1111/j.1467-9868.2007.00593.x": "field2007", "doi:10.1145/3299869.3320212": "raasveldt2019",
    "doi:10.5281/zenodo.5960048": "allaire2022", "doi:10.5195/jmla.2023.1826": "boruff2023",
}
ACCESSED = {"date-parts": [[2026, 10, 7]]}
MANUAL = [
    {"id": "crossrefrwdocs", "type": "webpage", "title": "Retraction Watch", "container-title": "Crossref documentation",
     "author": [{"literal": "Crossref"}], "issued": {"date-parts": [[2025, 1, 19]]}, "URL": "https://www.crossref.org/documentation/retrieve-metadata/retraction-watch/", "accessed": ACCESSED},
    {"id": "rwdata", "type": "webpage", "title": "Retraction Watch data (retraction_watch.csv), data for 2026-10-06, commit fe345427b516f7d507d67db5e1119d738cc25455",
     "author": [{"literal": "Crossref"}, {"literal": "Retraction Watch"}], "publisher": "GitLab", "issued": {"date-parts": [[2026, 10, 6]]},
     "URL": "https://gitlab.com/crossref/retraction-watch-data", "accessed": ACCESSED},
    {"id": "pmcaws", "type": "webpage", "title": "NIH NLM NCBI PubMed Central (PMC) Article Datasets: full-text biomedical and life sciences journal articles on AWS",
     "author": [{"literal": "National Library of Medicine"}], "issued": {"date-parts": [[2026]]}, "URL": "https://registry.opendata.aws/ncbi-pmc", "accessed": ACCESSED},
    {"id": "pmcoa", "type": "webpage", "title": "PMC Open Access Subset", "author": [{"literal": "National Library of Medicine"}],
     "issued": {"date-parts": [[2026, 8, 24]]}, "URL": "https://pmc.ncbi.nlm.nih.gov/tools/openftlist/", "accessed": ACCESSED},
    {"id": "eutils", "type": "webpage", "title": "A general introduction to the E-utilities. In: Entrez Programming Utilities Help", "author": [{"family": "Sayers", "given": "E"}],
     "container-title": "National Center for Biotechnology Information",
     "issued": {"date-parts": [[2022, 11, 17]]}, "URL": "https://www.ncbi.nlm.nih.gov/books/NBK25497/", "accessed": ACCESSED},
    {"id": "idconv", "type": "webpage", "title": "PMC ID Converter API", "author": [{"literal": "National Library of Medicine"}],
     "issued": {"date-parts": [[2026]]}, "URL": "https://pmc.ncbi.nlm.nih.gov/tools/id-converter-api/", "accessed": ACCESSED},
    {"id": "nlmpubtypes", "type": "webpage", "title": "Publication characteristics (publication types) with scope notes", "author": [{"literal": "National Library of Medicine"}],
     "issued": {"date-parts": [[2026]]}, "URL": "https://www.nlm.nih.gov/mesh/pubtypes.html", "accessed": ACCESSED},
    {"id": "pubmeddtd", "type": "webpage", "title": "PubMed XML DTD, pubmed_250101.dtd", "author": [{"literal": "National Library of Medicine"}],
     "issued": {"date-parts": [[2025]]}, "URL": "https://dtd.nlm.nih.gov/ncbi/pubmed/out/pubmed_250101.dtd", "accessed": ACCESSED},
    {"id": "zotero2019", "type": "post-weblog", "title": "Retracted item notifications with Retraction Watch integration", "author": [{"family": "Stillman", "given": "D"}],
     "container-title": "Zotero blog", "issued": {"date-parts": [[2019, 6, 14]]}, "URL": "https://www.zotero.org/blog/retracted-item-notifications/", "accessed": ACCESSED},
]
KEEP = {"id", "type", "title", "author", "container-title", "container-title-short", "volume", "issue", "page", "issued", "DOI", "PMID", "PMCID",
        "URL", "publisher", "publisher-place", "accessed", "genre", "number", "collection-title", "event-title"}


def compile_references(cfg: Config) -> Path:
    raw = json.loads((cfg.root / "manuscript" / "refs" / "raw_csl.json").read_text())
    items = []
    for k, v in raw.items():
        it = {}
        for kk, vv in v.items():
            if kk not in KEEP:
                continue
            if isinstance(vv, list) and kk != "author":
                vv = vv[0] if vv else None
            if vv in (None, "", []):
                continue
            it[kk] = vv
        it["author"] = [{a: b for a, b in au.items() if a in ("family", "given", "literal")} for au in it.get("author", [])]
        if "published-print" in v and k.startswith("doi:"):
            it["issued"] = v["published-print"]
        it["id"] = KEYS[k]
        if k.startswith("pmid:"):
            it["PMID"] = k.split(":")[1]
        if it["id"] == "salami2026":
            it["type"] = "article-journal"
            it["container-title"] = "MetaArXiv [Preprint, version 4]"
            it.pop("publisher", None)
            it["URL"] = "https://doi.org/10.31222/osf.io/gvfk5_v4"
        if it["id"] == "schmidt2018":
            it["title"] = "An analysis of the validity of retraction annotation in PubMed and the Web of Science"
        if it["id"] == "allaire2022":
            it["type"] = "software"
        for a in it.get("author", []):
            if it["id"] == "boruff2023" and a.get("family", "").endswith(", AHIP"):
                a["family"] = a["family"].replace(", AHIP", "")
        items.append(it)
    items.extend(MANUAL)
    out = cfg.root / "manuscript" / "references.json"
    out.write_text(json.dumps(items, indent=1, ensure_ascii=False))
    return out


def write_claims(cfg: Config) -> Path:
    n = Numbers(cfg)
    out = cfg.root / "evidence" / "claims.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(n.claims_json(), indent=1, default=str))
    return out


def format_submission_docx(path: Path) -> None:
    """Double spacing, continuous line numbers and page numbers for submission."""
    from docx import Document
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    doc = Document(str(path))
    for name in ("Normal", "Body Text", "First Paragraph", "Compact", "Bibliography", "Abstract"):
        try:
            doc.styles[name].paragraph_format.line_spacing = 2.0
        except KeyError:
            pass
    for section in doc.sections:
        sect = section._sectPr
        for old in sect.findall(qn("w:lnNumType")):
            sect.remove(old)
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:restart"), "continuous")
        sect.append(ln)
        footer = section.footer
        para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = para.add_run()
        for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
            if tag:
                fc = OxmlElement("w:fldChar")
                fc.set(qn("w:fldCharType"), tag)
                run._r.append(fc)
            else:
                it = OxmlElement("w:instrText")
                it.set(qn("xml:space"), "preserve")
                it.text = text
                run._r.append(it)
    doc.core_properties.author = "Animesh Bose"
    doc.core_properties.comments = ""
    doc.save(str(path))
    from .editorial_format import finish
    path.write_bytes(finish(path.read_bytes(), supplement=path.name.startswith(("supplement", "ESM2")))[0])


def _quarto(cfg: Config) -> Path:
    local = cfg.root / ".local" / "tools" / "quarto" / "bin" / "quarto"
    if local.exists():
        return local
    found = shutil.which("quarto")
    if not found:
        raise RuntimeError("Quarto not found: install Quarto 1.10 or set it on PATH (see README)")
    return Path(found)


def render(cfg: Config) -> dict:
    refs = compile_references(cfg)
    claims = write_claims(cfg)
    for doc_dir in ("manuscript", "report"):
        fig_dir = cfg.root / doc_dir / "figures"
        fig_dir.mkdir(parents=True, exist_ok=True)
        for f in cfg.path("figures").glob("*.*"):
            shutil.copy(f, fig_dir / f.name)
    quarto = _quarto(cfg)
    env = dict(os.environ)
    venv_py = cfg.root / ".venv" / "bin" / "python"
    env["QUARTO_PYTHON"] = str(venv_py if venv_py.exists() else shutil.which("python3"))
    env["RAE_ROOT"] = str(cfg.root)
    results = {}
    jobs = [
        (cfg.root / "report" / "report.qmd", ["--to", "html"]),
        (cfg.root / "manuscript" / "manuscript.qmd", ["--to", "docx"]),
        (cfg.root / "manuscript" / "manuscript.qmd", ["--to", "html"]),
        (cfg.root / "manuscript" / "manuscript.qmd", ["--to", "typst"]),
        (cfg.root / "submission" / "cover_letter.md", ["--to", "docx"]),
        (cfg.root / "submission" / "strobe_checklist.md", ["--to", "typst"]),
        (cfg.root / "submission" / "additional_file_2.qmd", ["--to", "typst"]),
    ]
    for qmd, args in jobs:
        job_env = {**env, "RAE_FORMAT": args[1]}
        proc = subprocess.run([str(quarto), "render", str(qmd), *args], cwd=qmd.parent, env=job_env, capture_output=True, text=True)
        results[f"{qmd.name} {' '.join(args)}"] = "ok" if proc.returncode == 0 else proc.stderr[-2000:]
        if proc.returncode != 0:
            raise RuntimeError(f"quarto render failed for {qmd.name} {args}:\n{proc.stderr[-3000:]}")
    docx = cfg.root / "manuscript" / "manuscript.docx"
    if docx.exists():
        format_submission_docx(docx)
    version = subprocess.run([str(quarto), "--version"], capture_output=True, text=True).stdout.strip()
    manifest = {"renderer": f"Quarto {version}", "python": env["QUARTO_PYTHON"].split("/")[-1], "outputs": results,
                "references": str(refs.relative_to(cfg.root)), "claims": str(claims.relative_to(cfg.root))}
    (cfg.path("tables") / "render_manifest.json").write_text(json.dumps(manifest, indent=1))
    return manifest
