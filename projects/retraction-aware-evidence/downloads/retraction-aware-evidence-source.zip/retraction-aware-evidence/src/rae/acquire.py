"""Acquisition stage: frozen status snapshot, frame, review XML, cited records.

All network access in the project happens here. Every response goes through
the cache in ``data/cache`` so later stages and reruns can work offline
(``RAE_OFFLINE=1``).
"""

from __future__ import annotations

import hashlib
import json
import logging
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd

from .config import Config
from .frame import freeze_frame
from .http import CachedClient, FetchError, utc_now
from .jats import citation_contexts, parse_references, parse_review_meta, parse_xml
from .pmc import choose_version, get_metadata, get_xml, idconv, list_versions
from .pubmed import NOTICE_PUBTYPES, RETRACTED_PUBTYPE, STATUS_REFTYPES, doi_search, efetch_records
from .retraction_watch import sha256_file

log = logging.getLogger("rae.acquire")


def clients(cfg: Config) -> tuple[CachedClient, CachedClient]:
    cache = cfg.path("cache")
    ncbi = CachedClient(cache / "ncbi", min_interval=cfg["ncbi"]["min_interval_seconds"], max_attempts=cfg["ncbi"]["max_attempts"])
    s3 = CachedClient(cache / "pmc_cloud", min_interval=0.0, max_attempts=cfg["ncbi"]["max_attempts"])
    return ncbi, s3


def ensure_rw_snapshot(cfg: Config, client: CachedClient) -> Path:
    rw = cfg["retraction_watch"]
    out_dir = cfg.path("raw") / "retraction_watch"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"retraction_watch_{rw['commit']}.csv"
    if not path.exists():
        url = f"{rw['repository']}/-/raw/{rw['commit']}/{rw['file']}"

        def ok(content, ctype):
            return content[:40].startswith(b"Record ID,Title,Subject")

        resp = client.request("GET", url, validate=ok, use_cache=False)
        path.write_bytes(resp.content)
    digest = sha256_file(path)
    if digest != rw["sha256"]:
        raise RuntimeError(f"Retraction Watch snapshot hash mismatch: {digest}")
    return path


def records_to_tables(records: dict) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rec_rows, doi_rows, rel_rows = [], [], []
    for pmid, r in records.items():
        e = r.electronic_date
        i = r.issue_date
        notice_kinds = sorted({NOTICE_PUBTYPES[p] for p in r.pubtypes if p in NOTICE_PUBTYPES})
        rec_rows.append(
            {
                "pmid": pmid,
                "kind": r.kind,
                "title": r.title,
                "journal": r.journal,
                "pmcid": r.pmcid,
                "first_author": r.first_author,
                "year": r.year,
                "pubtypes": "|".join(r.pubtypes),
                "has_retracted_pubtype": RETRACTED_PUBTYPE in r.pubtypes,
                "notice_kind": "|".join(notice_kinds),
                "elec_start": e.start if e is not None else None,
                "elec_end": e.end if e is not None else None,
                "elec_precision": e.precision if e is not None else "unknown",
                "issue_start": i.start if i is not None else None,
                "issue_end": i.end if i is not None else None,
                "issue_precision": i.precision if i is not None else "unknown",
            }
        )
        for d in r.dois:
            doi_rows.append({"pmid": pmid, "doi": d})
        for rel in r.relations:
            rel_rows.append({"pmid": pmid, "reftype": rel["reftype"], "refsource": rel["refsource"], "rel_pmid": rel["pmid"]})
    recs = pd.DataFrame(rec_rows)
    dois = pd.DataFrame(doi_rows, columns=["pmid", "doi"])
    rels = pd.DataFrame(rel_rows, columns=["pmid", "reftype", "refsource", "rel_pmid"])
    return recs, dois, rels


def _retrieve_review(s3: CachedClient, cfg: Config, pmcid: str) -> dict:
    out = {"pmcid": pmcid, "status": None, "version_prefix": None, "license_code": None, "is_pmc_openaccess": None,
           "is_manuscript": None, "is_retracted_flag": None, "n_versions": 0}
    try:
        versions = list_versions(s3, cfg, pmcid)
    except FetchError as exc:
        out["status"] = "listing_failed"
        out["error"] = str(exc)
        return out
    out["n_versions"] = len(versions)
    if not versions:
        out["status"] = "no_cloud_version"
        return out
    metas = []
    for v in versions:
        try:
            m = get_metadata(s3, cfg, v)
            m["_prefix"] = v
            metas.append(m)
        except FetchError as exc:
            out["error"] = str(exc)
    if not metas:
        out["status"] = "metadata_failed"
        return out
    chosen = choose_version(metas)
    if chosen is None:
        out["status"] = "not_open_access"
        return out
    out.update(
        {
            "version_prefix": chosen["_prefix"],
            "license_code": chosen.get("license_code"),
            "is_pmc_openaccess": chosen.get("is_pmc_openaccess"),
            "is_manuscript": chosen.get("is_manuscript"),
            "is_retracted_flag": chosen.get("is_retracted"),
            "cloud_pmid": chosen.get("pmid"),
            "cloud_doi": chosen.get("doi"),
        }
    )
    try:
        content, info = get_xml(s3, chosen)
    except FetchError as exc:
        out["status"] = "xml_failed"
        out["error"] = str(exc)
        return out
    out.update({k: info[k] for k in ("xml_url", "md5_expected", "md5_observed", "sha256", "bytes", "retrieved_utc")})
    out["status"] = "retrieved"
    return out


def acquire(cfg: Config) -> dict:
    interim = cfg.path("interim")
    raw = cfg.path("raw")
    ncbi, s3 = clients(cfg)
    summary: dict = {"started_utc": utc_now()}

    rw_path = ensure_rw_snapshot(cfg, s3)
    summary["rw_snapshot"] = str(rw_path.relative_to(cfg.root))

    frame = freeze_frame(ncbi, cfg, interim, raw)
    summary["frame_size"] = len(frame)
    selected = frame[frame["selected"]].copy()
    summary["selected"] = len(selected)

    # 1. PubMed records of the selected reviews
    rev_records, rev_nf, rev_failed = efetch_records(ncbi, cfg, selected["pmid"].tolist())
    rv, rv_dois, rv_rels = records_to_tables(rev_records)
    rv.to_parquet(interim / "review_pubmed.parquet", index=False)
    rv_dois.to_parquet(interim / "review_pubmed_dois.parquet", index=False)
    rv_rels.to_parquet(interim / "review_pubmed_relations.parquet", index=False)

    # 2. PMCIDs: PubMed record first, ID Converter for the rest
    pmcid_of = {p: r.pmcid for p, r in rev_records.items() if r.pmcid}
    missing = [p for p in selected["pmid"] if p not in pmcid_of]
    conv, conv_failed = idconv(ncbi, cfg, missing, "pmid") if missing else ({}, set())
    for p, rec in conv.items():
        if rec.get("pmcid"):
            pmcid_of[p] = rec["pmcid"]
    sel_rows = []
    for p in selected["pmid"]:
        sel_rows.append(
            {
                "pmid": p,
                "pubmed_status": "failed" if p in rev_failed else ("not_found" if p in rev_nf else "found"),
                "pmcid": pmcid_of.get(p),
                "idconv_failed": p in conv_failed,
            }
        )
    sel = pd.DataFrame(sel_rows)

    # 3. Review XML from the PMC cloud dataset
    with ThreadPoolExecutor(max_workers=cfg["pmc_cloud"]["workers"]) as pool:
        results = list(pool.map(lambda c: _retrieve_review(s3, cfg, c), [c for c in sel["pmcid"] if c]))
    ret = pd.DataFrame(results)
    sel = sel.merge(ret, on="pmcid", how="left")
    sel.loc[sel["pmcid"].isna(), "status"] = "no_pmcid"
    sel.to_csv(interim / "review_retrieval.csv", index=False)

    # 4. Parse XML: review metadata, references, citation contexts
    rev_meta_rows, occ_rows, ident_rows, ctx_rows, parse_rows = [], [], [], [], []
    for row in sel[sel["status"] == "retrieved"].itertuples(index=False):
        resp = s3.get_cached(_xml_key(row.xml_url))
        if resp is None:
            parse_rows.append({"pmcid": row.pmcid, "parse_status": "xml_missing_from_cache"})
            continue
        try:
            root = parse_xml(resp.content)
        except Exception as exc:  # malformed XML is recorded, not fatal
            parse_rows.append({"pmcid": row.pmcid, "parse_status": "xml_parse_error", "error": str(exc)[:300]})
            continue
        meta = parse_review_meta(root)
        refs = parse_references(root, row.pmcid)
        ctx = citation_contexts(root)
        parse_rows.append({"pmcid": row.pmcid, "parse_status": "parsed" if refs else "no_reference_list", "n_occurrences": len(refs)})
        rev_meta_rows.append(
            {
                "pmcid": row.pmcid,
                "pmid_frame": row.pmid,
                "jats_pmid": meta.pmid,
                "jats_doi": meta.doi,
                "title": meta.title,
                "journal": meta.journal,
                "article_type": meta.article_type,
                "jats_epub_start": meta.epub.start,
                "jats_epub_end": meta.epub.end,
                "jats_epub_precision": meta.epub.precision,
                "jats_issue_start": meta.issue.start,
                "jats_issue_end": meta.issue.end,
                "jats_issue_precision": meta.issue.precision,
                "pub_dates_raw": json.dumps(meta.pub_dates_raw),
                "license_code": row.license_code,
                "license_href": meta.license_href,
                "version_prefix": row.version_prefix,
                "xml_sha256": row.sha256,
            }
        )
        for r in refs:
            ids = r.pop("identifiers")
            occ_rows.append(r)
            for kind, rawv, norm, prov in ids:
                ident_rows.append({"occurrence_id": r["occurrence_id"], "kind": kind, "raw": rawv, "normalized": norm, "provenance": prov})
        for rid, sents in ctx.items():
            for k, s in enumerate(sents, start=1):
                ctx_rows.append({"review_pmcid": row.pmcid, "ref_id": rid, "sentence_index": k, "sentence": s})
    reviews = pd.DataFrame(rev_meta_rows)
    occ = pd.DataFrame(occ_rows)
    idents = pd.DataFrame(ident_rows, columns=["occurrence_id", "kind", "raw", "normalized", "provenance"])
    ctxs = pd.DataFrame(ctx_rows, columns=["review_pmcid", "ref_id", "sentence_index", "sentence"])
    parse = pd.DataFrame(parse_rows)
    reviews.to_parquet(interim / "reviews.parquet", index=False)
    occ.to_parquet(interim / "occurrences.parquet", index=False)
    idents.to_parquet(interim / "occurrence_identifiers.parquet", index=False)
    ctxs.to_parquet(interim / "citation_contexts.parquet", index=False)
    parse.to_csv(interim / "review_parse.csv", index=False)
    if not occ["occurrence_id"].is_unique:
        raise RuntimeError("occurrence_id is not unique")

    summary.update(resolve_cited(cfg, ncbi, idents, interim))

    summary.update(
        {
            "review_pubmed_found": len(rev_records),
            "reviews_retrieved": int((sel["status"] == "retrieved").sum()),
            "reviews_parsed_with_refs": int((parse.get("parse_status") == "parsed").sum()) if len(parse) else 0,
            "occurrences": len(occ),
            "finished_utc": utc_now(),
        }
    )
    (interim / "acquire_summary.json").write_text(json.dumps(summary, indent=1, default=str))
    ncbi.close()
    s3.close()
    return summary


def resolve_cited(cfg: Config, ncbi: CachedClient, idents: pd.DataFrame, interim: Path) -> dict:
    """Resolve cited identifiers through NCBI and write the lookup tables.

    Shared by the study pipeline and by ``rae audit`` for user bibliographies.
    """
    # 5. Cited PMCIDs to PMIDs
    good = idents[idents["normalized"].notna()]
    cited_pmcids = sorted(set(good.loc[good.kind == "pmcid", "normalized"]))
    pmc_conv, pmc_conv_failed = idconv(ncbi, cfg, cited_pmcids, "pmcid") if cited_pmcids else ({}, set())
    conv_rows = [
        {"pmcid": k, "pmid": v.get("pmid"), "doi": v.get("doi"), "status": v.get("status", "ok"), "errmsg": v.get("errmsg")}
        for k, v in pmc_conv.items()
    ] + [{"pmcid": k, "pmid": None, "doi": None, "status": "request_failed", "errmsg": None} for k in pmc_conv_failed]
    pd.DataFrame(conv_rows, columns=["pmcid", "pmid", "doi", "status", "errmsg"]).to_parquet(interim / "cited_pmcid_conversion.parquet", index=False)

    # 6. Cited PMIDs
    cited_pmids = set(good.loc[good.kind == "pmid", "normalized"])
    cited_pmids |= {str(v["pmid"]) for v in pmc_conv.values() if v.get("pmid")}
    records, not_found, failed = efetch_records(ncbi, cfg, sorted(cited_pmids))

    # 7. DOI search for occurrences without a found record, or whose record DOI disagrees
    rec_dois = {p: set(r.dois) for p, r in records.items()}
    conv_pmid = {k: str(v["pmid"]) for k, v in pmc_conv.items() if v.get("pmid")}
    by_occ = good.groupby("occurrence_id")
    need: set[str] = set()
    # Computed for all identifiers and again for tagged identifiers only, so the
    # tagged-only sensitivity analysis has every lookup it needs.
    for occ_id, g_all in by_occ:
        for g in (g_all, g_all[g_all.provenance == "tag"]):
            dois = set(g.loc[g.kind == "doi", "normalized"])
            if not dois:
                continue
            found = {p for p in g.loc[g.kind == "pmid", "normalized"] if p in records}
            found |= {conv_pmid[c] for c in g.loc[g.kind == "pmcid", "normalized"] if c in conv_pmid and conv_pmid[c] in records}
            if not found:
                need |= dois
            else:
                covered = set().union(*(rec_dois.get(p, set()) for p in found))
                need |= dois - covered
    hits, doi_failed = doi_search(ncbi, cfg, sorted(need))
    extra = sorted({p for s in hits.values() for p in s} - set(records))
    verify_failed: set[str] = set()
    if extra:
        r2, nf2, f2 = efetch_records(ncbi, cfg, extra)
        records.update(r2)
        verify_failed = set(f2)
    doi_rows = []
    for d in sorted(need):
        if d in doi_failed:
            doi_rows.append({"doi": d, "status": "query_failed", "pmid": None})
            continue
        verified = sorted(p for p in hits.get(d, set()) if p in records and d in set(records[p].dois))
        if not verified and hits.get(d, set()) & verify_failed:
            doi_rows.append({"doi": d, "status": "verification_failed", "pmid": None})
        elif not verified:
            doi_rows.append({"doi": d, "status": "not_found", "pmid": None})
        for p in verified:
            doi_rows.append({"doi": d, "status": "verified", "pmid": p})
    pd.DataFrame(doi_rows, columns=["doi", "status", "pmid"]).to_parquet(interim / "doi_pmid_search.parquet", index=False)

    # 8. Notice records referenced by status relations
    notice_pmids = set()
    for r in records.values():
        for rel in r.relations:
            if rel["reftype"] in STATUS_REFTYPES and rel["pmid"]:
                notice_pmids.add(rel["pmid"])
    todo = sorted(notice_pmids - set(records))
    nrec, nnf, nfail = efetch_records(ncbi, cfg, todo) if todo else ({}, set(), set())

    cited_tab, cited_dois, cited_rels = records_to_tables(records)
    cited_tab.to_parquet(interim / "cited_pubmed.parquet", index=False)
    cited_dois.to_parquet(interim / "cited_pubmed_dois.parquet", index=False)
    cited_rels.to_parquet(interim / "cited_pubmed_relations.parquet", index=False)
    ntab, _, _ = records_to_tables({**{p: records[p] for p in notice_pmids if p in records}, **nrec})
    ntab.to_parquet(interim / "notice_pubmed.parquet", index=False)
    status_rows = (
        [{"pmid": p, "status": "found"} for p in sorted(records, key=int) if p in cited_pmids]
        + [{"pmid": p, "status": "not_found"} for p in sorted(not_found, key=int)]
        + [{"pmid": p, "status": "request_failed"} for p in sorted(failed, key=int)]
    )
    pd.DataFrame(status_rows).to_parquet(interim / "cited_pmid_status.parquet", index=False)
    notice_status = (
        [{"pmid": p, "status": "found"} for p in sorted(notice_pmids, key=int) if p in records or p in nrec]
        + [{"pmid": p, "status": "not_found"} for p in sorted(nnf, key=int)]
        + [{"pmid": p, "status": "request_failed"} for p in sorted(nfail, key=int)]
    )
    pd.DataFrame(notice_status, columns=["pmid", "status"]).to_parquet(interim / "notice_pmid_status.parquet", index=False)

    return {
        "cited_pmcids": len(cited_pmcids),
        "cited_pmids_requested": len(cited_pmids),
        "cited_pmids_found": len([p for p in cited_pmids if p in records]),
        "cited_pmids_not_found": len(not_found),
        "cited_pmids_failed": len(failed),
        "dois_searched": len(need),
        "dois_search_failed": len(doi_failed),
        "notice_pmids": len(notice_pmids),
    }


def _xml_key(url: str) -> str:
    from .http import cache_key

    return cache_key("GET", url, None, None)
