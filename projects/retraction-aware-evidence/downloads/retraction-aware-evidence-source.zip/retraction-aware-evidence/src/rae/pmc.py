"""PMC retrieval through the documented automated services.

Review full text comes from the PMC Article Datasets on AWS (the PMC Cloud
Service), which the PMC Open Access Subset page lists as a permitted automated
retrieval route. Identifier conversion uses the PMC ID Converter API.
"""

from __future__ import annotations

import hashlib
import os
import re
from urllib.parse import parse_qs, urlparse

from lxml import etree

from .http import CachedClient, FetchError, looks_like_json, looks_like_xml
from .identifiers import normalize_doi, normalize_pmcid, normalize_pmid


def _params(cfg) -> dict:
    p = {"tool": cfg["ncbi"]["tool"], "format": "json"}
    email = os.environ.get("NCBI_EMAIL")
    if email:
        p["email"] = email
    return p


def idconv(client: CachedClient, cfg, ids: list[str], idtype: str):
    """Convert identifiers with the PMC ID Converter API.

    Returns (records, failed). records maps each requested ID to the record
    returned by the service (which may carry an error status when the article
    is not in PMC).
    """
    out: dict[str, dict] = {}
    failed: set[str] = set()
    todo = sorted(set(ids))
    for i in range(0, len(todo), 200):
        chunk = todo[i : i + 200]
        params = {**_params(cfg), "ids": ",".join(chunk), "idtype": idtype}

        def ok(content, ctype):
            if not looks_like_json(content, ctype):
                return False
            import json

            obj = json.loads(content)
            return obj.get("status") == "ok" and "records" in obj

        try:
            resp = client.request("GET", cfg["ncbi"]["idconv_base"], params=params, validate=ok)
        except FetchError:
            failed.update(chunk)
            continue
        for rec in resp.json()["records"]:
            req = rec.get("requested-id")
            if req is not None:
                out[str(req)] = rec
    return out, failed


def list_versions(client: CachedClient, cfg, pmcid: str) -> list[str]:
    base = cfg["pmc_cloud"]["base"]
    params = {"list-type": "2", "prefix": f"{pmcid}.", "delimiter": "/"}
    resp = client.request("GET", base, params=params, validate=looks_like_xml)
    root = etree.fromstring(resp.content)
    ns = {"s3": root.nsmap.get(None, "")}
    prefixes = [p.text.rstrip("/") for p in root.findall(".//s3:CommonPrefixes/s3:Prefix", ns)] if ns["s3"] else [
        p.text.rstrip("/") for p in root.findall(".//CommonPrefixes/Prefix")
    ]
    valid = [p for p in prefixes if re.fullmatch(rf"{pmcid}\.\d+", p)]
    return sorted(valid, key=lambda p: int(p.split(".")[1]))


def get_metadata(client: CachedClient, cfg, version_prefix: str) -> dict:
    url = f"{cfg['pmc_cloud']['base']}{version_prefix}/{version_prefix}.json"
    resp = client.request("GET", url, validate=looks_like_json)
    return resp.json()


def choose_version(metas: list[dict]) -> dict | None:
    """Plan rule: prefer the open-access, non-manuscript file, then the highest version."""
    oa = [m for m in metas if m.get("is_pmc_openaccess") is True]
    pub = [m for m in oa if m.get("is_manuscript") is not True]
    pool = pub or oa
    if not pool:
        return None
    return max(pool, key=lambda m: int(m.get("version") or 0))


def md5_from_url(url: str) -> str | None:
    q = parse_qs(urlparse(url).query)
    vals = q.get("md5")
    return vals[0] if vals else None


def get_xml(client: CachedClient, meta: dict) -> tuple[bytes, dict]:
    url = meta.get("xml_url")
    if not url:
        raise FetchError("metadata has no xml_url")
    https = url
    if url.startswith("s3://pmc-oa-opendata/"):
        https = "https://pmc-oa-opendata.s3.amazonaws.com/" + url[len("s3://pmc-oa-opendata/") :]
    parsed = urlparse(https)
    plain = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
    expected = md5_from_url(url)

    def ok(content, ctype):
        if not looks_like_xml(content, ctype):
            return False
        if expected and hashlib.md5(content).hexdigest() != expected:
            return False
        return True

    resp = client.request("GET", plain, validate=ok)
    info = {
        "xml_url": plain,
        "md5_expected": expected,
        "md5_observed": hashlib.md5(resp.content).hexdigest(),
        "sha256": resp.sha256,
        "bytes": len(resp.content),
        "retrieved_utc": resp.retrieved_utc,
    }
    return resp.content, info


def normalize_meta_ids(meta: dict) -> dict:
    return {
        "pmcid": normalize_pmcid(meta.get("pmcid")),
        "pmid": normalize_pmid(meta.get("pmid")),
        "doi": normalize_doi(meta.get("doi")).normalized,
    }
