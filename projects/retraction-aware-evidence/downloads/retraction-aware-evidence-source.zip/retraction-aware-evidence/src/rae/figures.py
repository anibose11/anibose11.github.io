"""Static figures (SVG for the web page, PNG at 300 dpi and PDF for the manuscript).

Palette: three category colors in a fixed order (blue, orange, aqua) and a
muted gray for "indeterminate", on a light surface. Every bar carries a direct
count label or the chart has a table next to it in the report.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
GRAY_FILL = "#b9b8b1"

LEDGER_LABELS = {
    "verified_pubmed_record": "One verified PubMed record",
    "doi_not_in_pubmed": "DOI only, not in PubMed",
    "record_not_found": "PMID with no PubMed record",
    "ambiguous": "Identifiers point to different records",
    "endpoint_unavailable": "Lookup failed",
    "malformed_identifier_only": "Malformed identifier only",
    "no_identifier": "No DOI, PMID or PMCID",
}
CLAIM_LABELS = {"retraction": "Retraction", "expression_of_concern": "Expression of concern", "correction": "Correction",
                "reinstatement": "Reinstatement", "update": "Update"}


def _style():
    plt.rcParams.update(
        {
            "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
            "font.size": 10,
            "axes.edgecolor": AXIS,
            "axes.labelcolor": INK2,
            "axes.linewidth": 0.8,
            "xtick.color": MUTED,
            "ytick.color": INK2,
            "text.color": INK,
            "figure.facecolor": SURFACE,
            "axes.facecolor": SURFACE,
            "savefig.facecolor": SURFACE,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def _save(fig, outdir: Path, name: str) -> list[str]:
    paths = []
    meta = {"svg": {"Date": None}, "png": {"Software": None}, "pdf": {"CreationDate": None, "ModDate": None, "Producer": None}}
    for ext, kw in (("svg", {}), ("png", {"dpi": 300}), ("pdf", {})):
        p = outdir / f"{name}.{ext}"
        fig.savefig(p, bbox_inches="tight", metadata=meta[ext], **kw)
        paths.append(str(p))
    plt.close(fig)
    return paths


def fig_ledger(ledger: pd.DataFrame, outdir: Path) -> list[str]:
    t = ledger[ledger["variant"] == "all_identifiers"].copy()
    t = t[t["numerator"] > 0]
    t["label"] = t["metric"].map(LEDGER_LABELS)
    t = t.sort_values("numerator")
    fig, ax = plt.subplots(figsize=(7.2, 0.42 * len(t) + 0.9))
    ax.barh(t["label"], t["numerator"], height=0.55, color=BLUE)
    total = int(t["denominator"].iloc[0])
    xmax = t["numerator"].max()
    for y, (n, p) in enumerate(zip(t["numerator"], t["estimate"])):
        pct = "<0.1%" if 0 < p < 0.001 else f"{p * 100:.1f}%"
        ax.text(n + xmax * 0.012, y, f"{n:,} ({pct})", va="center", ha="left", color=INK2, fontsize=9)
    ax.set_xlim(0, xmax * 1.28)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.set_xlabel(f"Reference occurrences (n = {total:,} in 1,000 reviews)")
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{int(v):,}"))
    return _save(fig, outdir, "fig1_coverage_ledger")


def _stacked_share(ax, rows: list[tuple[str, list[int]]], colors: list[str], names: list[str]):
    for y, (label, counts) in enumerate(rows):
        total = sum(counts)
        left = 0.0
        for k, (n, col) in enumerate(zip(counts, colors)):
            if n == 0:
                continue
            w = n / total
            ax.barh(y, w - 0.004, left=left + 0.002, height=0.55, color=col)
            if w >= 0.08:
                txt_col = "white" if col in (BLUE, ORANGE) else INK
                ax.text(left + w / 2, y, f"{n:,}", ha="center", va="center", fontsize=8.5, color=txt_col)
            left += w
        ax.text(1.015, y, f"n = {total:,}", va="center", ha="left", fontsize=8.5, color=INK2)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([r[0] for r in rows])
    ax.invert_yaxis()
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    handles = [matplotlib.patches.Patch(color=c, label=n) for c, n in zip(colors, names)]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.16), ncol=len(names), frameon=False, fontsize=9)


def fig_source_overlap(overlap: pd.DataFrame, outdir: Path) -> list[str]:
    rows = []
    for ct in ("retraction", "expression_of_concern", "correction"):
        sub = overlap[overlap["claim_type"] == ct].set_index("sources")["occurrences"]
        counts = [int(sub.get("both", 0)), int(sub.get("Retraction Watch only", 0)), int(sub.get("PubMed only", 0))]
        if sum(counts):
            rows.append((CLAIM_LABELS[ct], counts))
    fig, ax = plt.subplots(figsize=(7.2, 0.55 * len(rows) + 1.3))
    _stacked_share(ax, rows, [BLUE, ORANGE, AQUA], ["Both sources", "Retraction Watch only", "PubMed only"])
    ax.set_xlabel("Share of flagged reference occurrences")
    return _save(fig, outdir, "fig2_source_overlap")


def fig_timing(timing_src: pd.DataFrame, outdir: Path) -> list[str]:
    rows = []
    src_label = {"retraction_watch": "Retraction Watch", "pubmed": "PubMed"}
    for ct in ("retraction", "expression_of_concern", "correction"):
        for src in ("retraction_watch", "pubmed"):
            sub = timing_src[(timing_src["claim_type"] == ct) & (timing_src["source"] == src)].set_index("timing_primary")["claims"]
            counts = [int(sub.get("before_review", 0)), int(sub.get("after_review", 0)), int(sub.get("indeterminate", 0))]
            if sum(counts):
                rows.append((f"{CLAIM_LABELS[ct]}, {src_label[src]}", counts))
    fig, ax = plt.subplots(figsize=(7.2, 0.5 * len(rows) + 1.3))
    _stacked_share(ax, rows, [BLUE, ORANGE, GRAY_FILL], ["Notice before review online", "Notice after review online", "Indeterminate"])
    ax.set_xlabel("Share of claims (one claim per occurrence, notice and source)")
    return _save(fig, outdir, "fig3_timing")


def fig_by_year(by_year: pd.DataFrame, outdir: Path) -> list[str]:
    t = by_year.dropna(subset=["review_year"]).sort_values("review_year")
    fig, ax = plt.subplots(figsize=(7.2, 3.2))
    ax.plot(t["review_year"], t["any_identifier"], color=BLUE, linewidth=2, marker="o", markersize=4.5, label="Any DOI, PMID or PMCID")
    ax.plot(t["review_year"], t["verified_pubmed_record"], color=ORANGE, linewidth=2, marker="o", markersize=4.5, label="One verified PubMed record")
    for col, c in (("any_identifier", BLUE), ("verified_pubmed_record", ORANGE)):
        last = t.iloc[-1]
        ax.annotate(f"{last[col] * 100:.0f}%", (last["review_year"], last[col]), xytext=(6, 0), textcoords="offset points", va="center", fontsize=8.5, color=INK2)
    ax.set_ylim(0.6, 1.0)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_xticks(t["review_year"].astype(int).tolist())
    ax.set_xticklabels([f"{int(y)}\n{int(n)}" for y, n in zip(t["review_year"], t["reviews"])], fontsize=8.5)
    ax.text(-0.01, -0.105, "reviews", transform=ax.transAxes, ha="right", va="top", fontsize=8.5, color=MUTED)
    ax.set_xlabel("Year the review first appeared online")
    ax.set_ylabel("Share of reference occurrences")
    ax.legend(frameon=False, loc="lower left", fontsize=9)
    return _save(fig, outdir, "figS1_coverage_by_year")


def make_figures(cfg, out: dict) -> list[str]:
    _style()
    outdir = cfg.path("figures")
    paths = []
    paths += fig_ledger(out["coverage_ledger"], outdir)
    paths += fig_source_overlap(out["source_overlap"], outdir)
    paths += fig_timing(out["timing_by_source"], outdir)
    paths += fig_by_year(out["by_review_year"], outdir)
    root = str(cfg.root) + "/"
    return [p.replace(root, "") for p in paths]
