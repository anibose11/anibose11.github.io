"""Restrained journal formatting; no text, references, fields or figures changed."""
import io,zipfile
from lxml import etree
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'

def sub(parent,name,attrs):
    e=parent.find(W+name)
    if e is None:
        e=etree.Element(W+name)
        if name in ('pPr','rPr','tblPr','trPr','tcPr'):parent.insert(0,e)
        else:parent.append(e)
    for k,v in attrs.items():e.set(W+k,str(v))
    return e

def finish(data,supplement=False):
    changes={};notes=[]
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        styles=etree.fromstring(z.read('word/styles.xml'))
        for st in styles.findall(W+'style'):
            name=st.find(W+'name');name=name.get(W+'val','') if name is not None else ''
            if name.lower().startswith(('heading','title','subtitle')):
                rp=sub(st,'rPr',{});color=sub(rp,'color',{'val':'000000'})
                for a in ('themeColor','themeTint','themeShade'):color.attrib.pop(W+a,None)
                pp=st.find(W+'pPr')
                if pp is not None:
                    for x in list(pp.findall(W+'pBdr')):pp.remove(x)
        tree=etree.fromstring(z.read('word/document.xml'))
        paras=list(tree.iter(W+'p'))
        for p in paras:
            pp=p.find(W+'pPr');ps=pp.find(W+'pStyle') if pp is not None else None
            style=ps.get(W+'val','').lower() if ps is not None else ''
            if style.startswith(('heading','title','subtitle')):
                if pp is not None:
                    for x in list(pp.findall(W+'pBdr')):pp.remove(x)
                for r in p.findall(W+'r'):
                    rp=sub(r,'rPr',{});c=sub(rp,'color',{'val':'000000'})
                    for a in ('themeColor','themeTint','themeShade'):c.attrib.pop(W+a,None)
        if paras:
            first=paras[0];text=''.join(t.text or '' for t in first.iter(W+'t'))
            if text.startswith(('When hospital quality','Stability of county diabetes')):
                for table in tree.iter(W+'tbl'):
                    for index,row in enumerate(table.findall(W+'tr')):
                        rp=sub(row,'trPr',{});sub(rp,'cantSplit',{})
                        if index==0:sub(rp,'tblHeader',{})
                body=tree.find(W+'body')
                for current,following in zip(list(body),list(body)[1:]):
                    if current.tag==W+'p' and following.tag==W+'tbl':sub(sub(current,'pPr',{}),'keepNext',{})
                notes.append('Tables repeat headers and keep each data row intact')
            if text.startswith(('When hospital quality','Stability of county diabetes','Processing choices and reporting odds ratios','Identifier coverage, status sources')):
                pp=sub(first,'pPr',{});sub(pp,'pStyle',{'val':'Title'})
                for x in list(pp.findall(W+'pBdr')):pp.remove(x)
                for r in first.findall(W+'r'):
                    rp=sub(r,'rPr',{});sub(rp,'sz',{'val':'32'});sub(rp,'szCs',{'val':'32'});sub(rp,'b',{});sub(rp,'color',{'val':'000000'})
                notes.append('Restrained black manuscript title; decorative title border removed')
        all_text=' '.join(t.text or '' for t in tree.iter(W+'t'))
        if 'Dear Editors,' in all_text and 'Population Health Metrics' in all_text:
            for p in tree.find(W+'body').findall(W+'p'):
                sub(sub(p,'pPr',{}),'spacing',{'before':0,'after':80,'line':240,'lineRule':'auto'})
            notes.append('Single-spaced cover letter with restrained paragraph spacing keeps the signature on the letter page')
        # Quarto's narrow n column split four-digit counts in the timing table.
        for table in tree.iter(W+'tbl'):
            rows=table.findall(W+'tr')
            if not rows:continue
            headers=[''.join(t.text or '' for t in c.iter(W+'t')) for c in rows[0].findall(W+'tc')]
            if headers!=['Claim type','Review date','n','Before','Within lead','After','Indeterminate','Determinate, % (95% CI)']:continue
            widths=[1200,1160,700,700,740,640,1300,1480]
            pr=sub(table,'tblPr',{});sub(pr,'tblW',{'w':7920,'type':'dxa'});sub(pr,'tblLayout',{'type':'fixed'})
            grid=table.find(W+'tblGrid')
            for e in list(grid):grid.remove(e)
            for width in widths:etree.SubElement(grid,W+'gridCol').set(W+'w',str(width))
            for ri,row in enumerate(rows):
                rp=sub(row,'trPr',{});sub(rp,'cantSplit',{})
                if ri==0:sub(rp,'tblHeader',{})
                for ci,cell in enumerate(row.findall(W+'tc')):
                    cp=sub(cell,'tcPr',{});sub(cp,'tcW',{'w':widths[ci],'type':'dxa'})
                    mar=sub(cp,'tcMar',{})
                    for side in ('left','right'):sub(mar,side,{'w':50,'type':'dxa'})
                    for p in cell.iter(W+'p'):
                        sub(sub(p,'pPr',{}),'spacing',{'line':240,'lineRule':'auto','before':60,'after':60})
                        for run in p.iter(W+'r'):
                            sub(sub(run,'rPr',{}),'sz',{'val':20});sub(sub(run,'rPr',{}),'szCs',{'val':20})
            notes.append('Timing table uses wider count columns so numbers remain intact')
        if supplement:
            # Keep each table's caption or introductory note with its first row.
            body=tree.find(W+'body')
            for current,following in zip(list(body),list(body)[1:]):
                if current.tag==W+'p' and following.tag==W+'tbl':
                    sub(sub(current,'pPr',{}),'keepNext',{})
            for sec in tree.iter(W+'sectPr'):
                sub(sec,'pgSz',{'w':15840,'h':12240,'orient':'landscape'})
                sub(sec,'pgMar',{'top':900,'bottom':900,'left':900,'right':900})
            for st in styles.findall(W+'style'):
                name=st.find(W+'name');name=name.get(W+'val','') if name is not None else ''
                if name.lower() in ('normal','body text','first paragraph','compact'):
                    rp=sub(st,'rPr',{});sub(rp,'sz',{'val':22});sub(rp,'szCs',{'val':22})
                    pp=sub(st,'pPr',{});sub(pp,'spacing',{'line':240,'lineRule':'auto'})
            for table in tree.iter(W+'tbl'):
                rows=table.findall(W+'tr');cols=len(rows[0].findall(W+'tc')) if rows else 0
                if not cols:continue
                widths=[1]*cols
                if cols==11:widths=[1.15,1.45,.65,.7,.7,.7,.8,.75,.85,.7,.85]
                elif cols==6:widths=[1.1,1.4,.9,.9,1.0,2.1]
                elif cols==8:widths=[1.15,1.2,1.1,1.1,2.0,1.7,.9,1.6]
                total=14040;twips=[int(total*x/sum(widths)) for x in widths];twips[-1]+=total-sum(twips)
                pr=sub(table,'tblPr',{});sub(pr,'tblW',{'w':total,'type':'dxa'});sub(pr,'tblLayout',{'type':'fixed'})
                borders=sub(pr,'tblBorders',{})
                for side in ('top','bottom','left','right','insideH','insideV'):sub(borders,side,{'val':'single','sz':4,'color':'D9D9D9'})
                grid=table.find(W+'tblGrid')
                if grid is not None:
                    for e in list(grid):grid.remove(e)
                else:grid=etree.SubElement(table,W+'tblGrid')
                for width in twips:subel=etree.SubElement(grid,W+'gridCol');subel.set(W+'w',str(width))
                for ri,row in enumerate(rows):
                    trpr=sub(row,'trPr',{})
                    for x in list(trpr.findall(W+'trHeight')):trpr.remove(x)
                    sub(trpr,'cantSplit',{})
                    if ri==0:sub(trpr,'tblHeader',{})
                    for ci,cell in enumerate(row.findall(W+'tc')):
                        cp=sub(cell,'tcPr',{});sub(cp,'tcW',{'w':twips[ci],'type':'dxa'});sub(cp,'vAlign',{'val':'center'})
                        mar=sub(cp,'tcMar',{})
                        for side in ('top','bottom','left','right'):sub(mar,side,{'w':75,'type':'dxa'})
                        if ri==0:sub(cp,'shd',{'fill':'F2F2F2','val':'clear'})
                        for p in cell.iter(W+'p'):
                            pp=sub(p,'pPr',{});sub(pp,'spacing',{'line':240,'lineRule':'auto','after':0,'before':0})
                            for run in p.iter(W+'r'):
                                rp=sub(run,'rPr',{});sub(rp,'sz',{'val':20});sub(rp,'szCs',{'val':20})
                                if ri==0:sub(rp,'b',{})
            notes.append('Landscape supplementary tables with readable labels, fixed widths, padding, repeat headers and rows kept together')
        changes['word/styles.xml']=etree.tostring(styles,xml_declaration=True,encoding='UTF-8')
        changes['word/document.xml']=etree.tostring(tree,xml_declaration=True,encoding='UTF-8')
        for name in z.namelist():
            if name.startswith('word/footer') and name.endswith('.xml'):
                footer=etree.fromstring(z.read(name))
                for p in footer.iter(W+'p'):sub(sub(p,'pPr',{}),'suppressLineNumbers',{})
                changes[name]=etree.tostring(footer,xml_declaration=True,encoding='UTF-8')
        out=io.BytesIO()
        with zipfile.ZipFile(out,'w') as w:
            for item in z.infolist():w.writestr(item,changes.get(item.filename,z.read(item.filename)))
        return out.getvalue(),[{'note':n} for n in notes]+[{'note':'Black heading styles; original body typography retained'}]
