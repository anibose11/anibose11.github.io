"""Title/year candidate queue for references without an exact link.

These candidates are a review queue for a person. They are never counted as
confirmed matches and never enter the status tables.
"""

from __future__ import annotations

import re
import unicodedata

import numpy as np
import pandas as pd
from rapidfuzz import fuzz, process

STATUS_PREFIX = re.compile(r"^(retracted|retraction|withdrawn|expression of concern|notice of retraction)\s*[:.\-]\s*", re.I)
STATUS_SUFFIX = re.compile(r"\[(retracted|retraction|withdrawn)[^\]]*\]", re.I)


def normalize_title(t: str | None) -> str:
    if not t:
        return ""
    t = STATUS_SUFFIX.sub(" ", str(t))
    t = STATUS_PREFIX.sub("", t.strip())
    t = unicodedata.normalize("NFKD", t)
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    t = re.sub(r"[^0-9a-z]+", " ", t.lower())
    return re.sub(r"\s+", " ", t).strip()


def fuzzy_candidates(occ: pd.DataFrame, rw: pd.DataFrame, expanded_ids: pd.DataFrame, cfg) -> pd.DataFrame:
    min_score = float(cfg["linkage"]["fuzzy_min_score"])
    min_chars = int(cfg["linkage"]["fuzzy_min_title_chars"])
    tol = int(cfg["linkage"]["fuzzy_year_tolerance"])
    refs = occ[["occurrence_id", "article_title", "year", "first_author"]].copy()
    refs["nt"] = refs["article_title"].map(normalize_title)
    refs = refs[(refs["nt"].str.len() >= min_chars) & refs["year"].notna()]
    rwt = rw[["rw_record_id", "title", "original_year", "original_doi", "claim_type", "rw_nature", "authors", "journal"]].copy()
    rwt["nt"] = rwt["title"].map(normalize_title)
    rwt = rwt[(rwt["nt"].str.len() >= min_chars) & rwt["original_year"].notna()]
    occ_dois = expanded_ids[expanded_ids["kind"] == "doi"].groupby("occurrence_id")["id"].agg(set)
    out = []
    for y, grp in refs.groupby("year"):
        pool = rwt[(rwt["original_year"] >= y - tol) & (rwt["original_year"] <= y + tol)]
        if pool.empty:
            continue
        mat = process.cdist(grp["nt"].tolist(), pool["nt"].tolist(), scorer=fuzz.token_sort_ratio,
                            score_cutoff=min_score, dtype=np.uint8, workers=4)
        ri, ci = np.nonzero(mat)
        for i, j in zip(ri, ci):
            r = grp.iloc[i]
            w = pool.iloc[j]
            dois = occ_dois.get(r["occurrence_id"], set())
            if dois and w["original_doi"] and w["original_doi"] not in dois:
                continue  # identifiers on both sides disagree, so not the same work
            out.append(
                {
                    "occurrence_id": r["occurrence_id"],
                    "rw_record_id": w["rw_record_id"],
                    "title_score": int(mat[i, j]),
                    "reference_title": r["article_title"],
                    "rw_title": w["title"],
                    "reference_year": int(r["year"]),
                    "rw_original_year": int(w["original_year"]),
                    "reference_first_author": r["first_author"],
                    "rw_authors": w["authors"],
                    "rw_journal": w["journal"],
                    "rw_nature": w["rw_nature"],
                    "claim_type": w["claim_type"],
                    "candidate_label": "unverified_title_candidate",
                }
            )
    cols = ["occurrence_id", "rw_record_id", "title_score", "reference_title", "rw_title", "reference_year", "rw_original_year",
            "reference_first_author", "rw_authors", "rw_journal", "rw_nature", "claim_type", "candidate_label"]
    df = pd.DataFrame(out, columns=cols)
    return df.sort_values(["occurrence_id", "title_score", "rw_record_id"], ascending=[True, False, True]).reset_index(drop=True)
