"""Parse review metadata, reference lists and citation sentences from JATS XML.

One reference occurrence is one citation inside a ``<ref>`` of the main
article's back matter. ``<citation-alternatives>`` hold alternative renderings
of the same citation, so only one of them is used (element-citation first).
References inside ``<sub-article>`` or ``<response>`` are not part of the
review's own reference list and are skipped.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from lxml import etree

from .dates import DateInterval, from_parts
from .identifiers import (
    doi_from_url,
    dois_in_text,
    normalize_doi,
    normalize_pmcid,
    normalize_pmid,
    pmcids_in_text,
    pmids_in_text,
)

XLINK = "{http://www.w3.org/1999/xlink}href"
CITATION_TAGS = ("element-citation", "mixed-citation", "nlm-citation", "citation")
STATUS_WORDS = {
    "retract": re.compile(r"\bretract", re.I),
    "withdrawn": re.compile(r"\bwithdraw", re.I),
    "expression_of_concern": re.compile(r"expression of concern", re.I),
    "erratum_or_correction": re.compile(r"\berrat|\bcorrigend|\bcorrection to\b", re.I),
}


def _local(el) -> str:
    return etree.QName(el).localname if isinstance(el.tag, str) else ""


def _text(el) -> str:
    if el is None:
        return ""
    return re.sub(r"\s+", " ", "".join(el.itertext())).strip()


def _spaced_text(el) -> str:
    """Text with a space at every element boundary, for citation display.

    Structured citations (element-citation) carry no whitespace between
    child elements, so plain concatenation glues names and titles together.
    """
    parts: list[str] = []

    def walk(e):
        parts.append(" ")
        if e.text:
            parts.append(e.text)
        for c in e:
            walk(c)
        parts.append(" ")
        if e is not el and e.tail:
            parts.append(e.tail)

    walk(el)
    t = re.sub(r"\s+", " ", "".join(parts)).strip()
    t = re.sub(r"\s+([,.;:)\]])", r"\1", t)
    return re.sub(r"([(\[])\s+", r"\1", t)


@dataclass
class ReviewMeta:
    pmcid: str | None
    pmid: str | None
    doi: str | None
    title: str
    journal: str
    article_type: str
    epub: DateInterval
    issue: DateInterval
    pub_dates_raw: list[dict] = field(default_factory=list)
    license_href: str = ""


def _is_within_subarticle(el) -> bool:
    p = el.getparent()
    while p is not None:
        if _local(p) in ("sub-article", "response"):
            return True
        p = p.getparent()
    return False


def parse_review_meta(root) -> ReviewMeta:
    front = root.find(".//front/article-meta")
    if front is None:
        front = root.find(".//article-meta")
    ids = {}
    if front is not None:
        for aid in front.findall("article-id"):
            t = aid.get("pub-id-type")
            ids.setdefault(t, aid.text or "")
    pmcid = normalize_pmcid(ids.get("pmc") or ids.get("pmcid") or ids.get("pmcaid"))
    pmid = normalize_pmid(ids.get("pmid"))
    doi = normalize_doi(ids.get("doi")).normalized
    title = _text(front.find("title-group/article-title")) if front is not None else ""
    journal = _text(root.find(".//front/journal-meta/journal-title-group/journal-title")) or _text(
        root.find(".//front/journal-meta/journal-title")
    )
    raw_dates = []
    epubs: list[DateInterval] = []
    issues: list[DateInterval] = []
    if front is not None:
        for pd in front.findall("pub-date"):
            ptype = (pd.get("pub-type") or "").lower()
            dtype = (pd.get("date-type") or "").lower()
            fmt = (pd.get("publication-format") or "").lower()
            iv = from_parts(pd.findtext("year"), pd.findtext("month") or pd.findtext("season"), pd.findtext("day"), f"jats:{ptype or dtype}:{fmt}")
            raw_dates.append(
                {
                    "pub_type": ptype,
                    "date_type": dtype,
                    "format": fmt,
                    "year": pd.findtext("year"),
                    "month": pd.findtext("month"),
                    "day": pd.findtext("day"),
                    "season": pd.findtext("season"),
                }
            )
            if ptype in ("epub", "epub-ppub") or (dtype == "pub" and fmt == "electronic"):
                epubs.append(iv)
            if ptype in ("ppub", "collection", "epub-ppub") or dtype == "collection" or (dtype == "pub" and fmt == "print"):
                issues.append(iv)
    known_epub = [d for d in epubs if d.known]
    epub = min(known_epub, key=lambda d: (d.start, d.end)) if known_epub else DateInterval(None, None, "unknown", "jats")
    known_issue = [d for d in issues if d.known]
    issue = min(known_issue, key=lambda d: (d.start, d.end)) if known_issue else DateInterval(None, None, "unknown", "jats")
    lic = root.find(".//front/article-meta/permissions/license")
    lic_href = lic.get(XLINK, "") if lic is not None else ""
    if not lic_href and lic is not None:
        ali = lic.find("{http://www.niso.org/schemas/ali/1.0/}license_ref")
        lic_href = (ali.text or "") if ali is not None else ""
    return ReviewMeta(pmcid, pmid, doi, title, journal, root.get("article-type", ""), epub, issue, raw_dates, lic_href)


def _citations_in_ref(ref) -> list:
    cits = []
    for child in ref:
        name = _local(child)
        if name == "citation-alternatives":
            alts = [c for c in child if _local(c) in CITATION_TAGS]
            alts.sort(key=lambda c: CITATION_TAGS.index(_local(c)))
            if alts:
                cits.append(alts[0])
        elif name in CITATION_TAGS:
            cits.append(child)
    return cits


def _first_author(cit) -> str:
    for pg in cit.iter():
        if _local(pg) == "name":
            sn = pg.find("surname")
            if sn is not None and sn.text:
                return sn.text.strip()
        if _local(pg) == "collab":
            return _text(pg)
    return ""


TAGGED_ID_ELEMENTS = ("pub-id", "object-id", "ext-link", "uri")


def _untagged_text(cit) -> str:
    """Citation text with identifier-bearing elements replaced by a space.

    Mining DOIs from the plain concatenation would glue adjacent tagged
    identifiers together (a DOI followed by a PMID becomes one long DOI).
    """
    parts: list[str] = []

    def walk(el):
        if _local(el) in TAGGED_ID_ELEMENTS:
            parts.append(" ")
            if el.tail:
                parts.append(el.tail)
            return
        parts.append(" ")
        if el.text:
            parts.append(el.text)
        for c in el:
            walk(c)
        parts.append(" ")
        if el is not cit and el.tail:
            parts.append(el.tail)

    walk(cit)
    return re.sub(r"\s+", " ", "".join(parts)).strip()


def parse_reference(cit, ref_id: str, label: str, position: int, cit_index: int, pmcid: str) -> dict:
    full = _spaced_text(cit)
    free = _untagged_text(cit)
    ids = []  # (kind, raw, normalized_or_None, provenance)
    for pid in cit.iter():
        if _local(pid) == "pub-id" or (_local(pid) == "object-id"):
            t = (pid.get("pub-id-type") or "").lower()
            raw = (pid.text or "").strip()
            if t == "doi":
                ids.append(("doi", raw, normalize_doi(raw).normalized, "tag"))
            elif t == "pmid":
                ids.append(("pmid", raw, normalize_pmid(raw), "tag"))
            elif t in ("pmcid", "pmc"):
                ids.append(("pmcid", raw, normalize_pmcid(raw), "tag"))
    for link in cit.iter():
        if _local(link) in ("ext-link", "uri"):
            href = link.get(XLINK) or ""
            ltype = (link.get("ext-link-type") or "").lower()
            raw = doi_from_url(href)
            if raw is None and ltype == "doi":
                raw = href or (link.text or "")
            if raw is None:
                raw = doi_from_url((link.text or "").strip())
            if raw:
                ids.append(("doi", raw, normalize_doi(raw).normalized, "link"))
            m = re.search(r"(?:pubmed\.ncbi\.nlm\.nih\.gov/|ncbi\.nlm\.nih\.gov/pubmed/)(\d{1,9})\b", href)
            if m:
                ids.append(("pmid", m.group(1), normalize_pmid(m.group(1)), "link"))
            m = re.search(r"(PMC\d{4,9})", href)
            if m:
                ids.append(("pmcid", m.group(1), normalize_pmcid(m.group(1)), "link"))
    tagged_norm = {(k, n) for k, _, n, prov in ids if n}
    for raw in dois_in_text(free):
        n = normalize_doi(raw).normalized
        if n and ("doi", n) not in tagged_norm:
            ids.append(("doi", raw, n, "text"))
            tagged_norm.add(("doi", n))
        elif not n:
            ids.append(("doi", raw, None, "text"))
    for p in pmids_in_text(free):
        if ("pmid", p) not in tagged_norm:
            ids.append(("pmid", p, p, "text"))
            tagged_norm.add(("pmid", p))
    for p in pmcids_in_text(free):
        if ("pmcid", p) not in tagged_norm:
            ids.append(("pmcid", p, p, "text"))
            tagged_norm.add(("pmcid", p))

    def first(tag):
        for el in cit.iter():
            if _local(el) == tag:
                return _text(el)
        return ""

    year_txt = first("year")
    m = re.search(r"(1[89]\d\d|20\d\d)", year_txt or "")
    year = int(m.group(1)) if m else None
    flags = {k: bool(rx.search(full)) for k, rx in STATUS_WORDS.items()}
    return {
        "occurrence_id": f"{pmcid}|{ref_id or 'pos' + str(position)}|{cit_index}",
        "review_pmcid": pmcid,
        "ref_id": ref_id,
        "ref_label": label,
        "ref_position": position,
        "citation_index": cit_index,
        "citation_tag": _local(cit),
        "publication_type": cit.get("publication-type") or cit.get("citation-type") or "",
        "article_title": first("article-title") or first("chapter-title"),
        "source": first("source"),
        "year": year,
        "volume": first("volume"),
        "fpage": first("fpage") or first("elocation-id"),
        "first_author": _first_author(cit),
        "ref_text": full,
        "identifiers": ids,
        **{f"text_mentions_{k}": v for k, v in flags.items()},
    }


def parse_references(root, pmcid: str) -> list[dict]:
    back = root.find("back")
    candidates = back.findall(".//ref") if back is not None else []
    if not candidates:
        candidates = [r for r in root.iter() if _local(r) == "ref" and r.getparent() is not None and _local(r.getparent()) == "ref-list"]
    refs = [r for r in candidates if not _is_within_subarticle(r)]
    out = []
    for pos, ref in enumerate(refs, start=1):
        ref_id = ref.get("id") or ""
        label = _text(ref.find("label"))
        cits = _citations_in_ref(ref)
        for ci, cit in enumerate(cits, start=1):
            out.append(parse_reference(cit, ref_id, label, pos, ci, pmcid))
    return out


MARK = "\x00"
SENT_END = re.compile(r"[.!?]((?:[\s,;\-\u2013\u2014]*\x00)*)\s+(?=[A-Z(\[\x00])")


def _sentences(text: str) -> list[tuple[int, int]]:
    """Sentence spans. Citation markers right after the full stop stay with the sentence."""
    spans = []
    start = 0
    for m in SENT_END.finditer(text):
        spans.append((start, m.end(1)))
        start = m.end()
    spans.append((start, len(text)))
    return spans


def citation_contexts(root, max_sentences: int = 3, max_chars: int = 400) -> dict[str, list[str]]:
    """Map reference id to the sentences in the body that cite it.

    Only explicit ``<xref ref-type="bibr" rid="...">`` links are used. Ranges
    written as two linked endpoints ("3-7") are not expanded.
    """
    body = root.find("body")
    if body is None:
        return {}
    out: dict[str, list[str]] = {}
    for p in body.iter():
        if _local(p) != "p":
            continue
        parts: list[str] = []
        markers: list[tuple[list[str], str]] = []

        def walk(el):
            if _local(el) == "xref" and (el.get("ref-type") == "bibr"):
                markers.append(((el.get("rid") or "").split(), _text(el)))
                parts.append(MARK)
                if el.tail:
                    parts.append(el.tail)
                return
            if _local(el) in ("table-wrap", "fig", "disp-formula", "list", "p") and el is not p:
                if el.tail:
                    parts.append(el.tail)
                return
            if el.text:
                parts.append(el.text)
            for c in el:
                walk(c)
            if el is not p and el.tail:
                parts.append(el.tail)

        walk(p)
        if not markers:
            continue
        text = "".join(parts)
        mark_pos = [i for i, ch in enumerate(text) if ch == MARK]
        for (s0, e0) in _sentences(text):
            idx = [k for k, pos in enumerate(mark_pos) if s0 <= pos < max(e0, s0 + 1)]
            if not idx:
                continue
            seg = text[s0:e0]
            rendered = []
            k_iter = iter(idx)
            for ch in seg:
                if ch == MARK:
                    k = next(k_iter)
                    label = markers[k][1]
                    rendered.append(label if label else "")
                else:
                    rendered.append(ch)
            sent = re.sub(r"\s+", " ", "".join(rendered)).strip()
            if len(sent) > max_chars:
                sent = sent[: max_chars - 3].rstrip() + "..."
            for k in idx:
                for rid in markers[k][0]:
                    lst = out.setdefault(rid, [])
                    if sent not in lst and len(lst) < max_sentences:
                        lst.append(sent)
    return out


def parse_xml(content: bytes):
    parser = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=True, recover=False)
    return etree.fromstring(content, parser=parser)
