"""Headline numbers with their evidence paths.

Every number quoted in the manuscript, report, portfolio page and handoff is
read from here, and each one records the output file, the selector inside it,
numerator, denominator and scope. ``evidence/claims.json`` is written from
the same dictionary.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from .config import Config


def _pct(x: float, digits: int = 1) -> str:
    return f"{x * 100:.{digits}f}%"


class Numbers:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.t = cfg.path("tables")
        self.items: dict[str, dict] = {}
        self.meta = json.loads((self.t / "analysis_meta.json").read_text())
        self._load()

    def _csv(self, name: str) -> pd.DataFrame:
        return pd.read_csv(self.t / f"{name}.csv")

    def add(self, key, value, path, selector, numerator=None, denominator=None, scope="", unit=""):
        self.items[key] = {"value": value, "numerator": numerator, "denominator": denominator, "scope": scope, "unit": unit,
                           "path": str((self.t / path).relative_to(self.cfg.root)) if not str(path).startswith(("data/", "outputs/")) else path,
                           "selector": selector}

    def v(self, key):
        return self.items[key]["value"]

    def _load(self):
        cf = self._csv("cohort_flow").set_index("step")["count"]
        self.add("frame_records", int(cf["PubMed frame records (query run 2026-10-07)"]), "cohort_flow.csv", "step=PubMed frame records", unit="PubMed records")
        self.add("selected_reviews", int(cf["Selected by identifier hash order"]), "cohort_flow.csv", "step=Selected by identifier hash order", unit="reviews")
        self.add("retrieved_reviews", int(cf["Open-access version in the PMC cloud dataset"]), "cohort_flow.csv", "step=Open-access version in the PMC cloud dataset", unit="reviews")
        self.add("reviews_with_refs", int(cf["Reviews with a reference list"]), "cohort_flow.csv", "step=Reviews with a reference list", unit="reviews")
        self.add("occurrences", int(cf["Reference occurrences"]), "cohort_flow.csv", "step=Reference occurrences", unit="reference occurrences")

        root = self.cfg.root
        occ = pd.read_parquet(root / "data/interim/occurrences.parquet", columns=["review_pmcid"])
        per = occ.groupby("review_pmcid").size()
        for k, v in (("refs_per_review_median", per.median()), ("refs_per_review_q1", per.quantile(0.25)), ("refs_per_review_q3", per.quantile(0.75)),
                     ("refs_per_review_min", per.min()), ("refs_per_review_max", per.max())):
            self.add(k, int(round(float(v))), "data/interim/occurrences.parquet", f"{k} of occurrence counts per review_pmcid", unit="reference occurrences per review")
        ret = pd.read_csv(root / "data/interim/review_retrieval.csv", dtype=str)
        lic = ret["license_code"].fillna("not stated").value_counts()
        for name, cnt in lic.items():
            self.add("license_" + name.replace(" ", "_").replace("-", "_"), int(cnt), "data/interim/review_retrieval.csv", f"license_code={name}", unit="reviews")
        self.add("author_manuscripts", int((ret["is_manuscript"] == "True").sum()), "data/interim/review_retrieval.csv", "is_manuscript=True", unit="reviews")
        works = pd.read_parquet(root / "data/processed/works.parquet", columns=["work_id"])
        self.add("unique_works", int(len(works)), "data/processed/works.parquet", "row count", unit="unique cited works")
        agr = self._csv("rw_identifier_agreement")
        both = agr[(agr["rw_doi_agreement"] == "agrees") & (agr["rw_pmid_agreement"] == "agrees")]["claims"].sum()
        self.add("rw_agree_both", int(both), "rw_identifier_agreement.csv", "rw_doi_agreement=agrees and rw_pmid_agreement=agrees", int(both), int(agr["claims"].sum()), "arm B Retraction Watch claims", "count")
        mc = self._csv("match_confidence")
        amb = mc[mc["confidence"] == "ambiguous_identifiers"]["claims"].sum()
        self.add("flagged_claims_ambiguous", int(amb), "match_confidence.csv", "confidence=ambiguous_identifiers (sum)", int(amb), int(mc["claims"].sum()), "arm C claims", "count")

        ic = self._csv("identifier_coverage")
        ic = ic[ic["variant"] == "all_identifiers"].set_index("metric")
        for key, metric in [("any_id", "any usable DOI, PMID or PMCID"), ("doi", "DOI"), ("pmid", "PMID"), ("pmcid", "PMCID"),
                            ("doi_only", "DOI without PMID or PMCID"), ("doi_and_pmid", "DOI and PMID")]:
            r = ic.loc[metric]
            self.add(f"cov_{key}", float(r["estimate"]), "identifier_coverage.csv", f"variant=all_identifiers, metric={metric}",
                     int(r["numerator"]), int(r["denominator"]), "reference occurrences, 1,000 reviews", "share")
            self.items[f"cov_{key}"]["ci"] = [float(r["ci_low"]), float(r["ci_high"])]

        lg = self._csv("coverage_ledger")
        lg = lg[lg["variant"] == "all_identifiers"].set_index("metric")
        for cat in lg.index:
            r = lg.loc[cat]
            self.add(f"ledger_{cat}", float(r["estimate"]), "coverage_ledger.csv", f"variant=all_identifiers, metric={cat}",
                     int(r["numerator"]), int(r["denominator"]), "reference occurrences", "share")
            self.items[f"ledger_{cat}"]["ci"] = [float(r["ci_low"]), float(r["ci_high"])]

        inc = self._csv("arm_increments").set_index("claim_type")
        for ct in inc.index:
            k = ct.replace(" ", "_")
            for col in ["arm_A", "arm_B", "arm_C", "added_by_crosswalk_B_not_A", "added_by_pubmed_C_not_B"]:
                self.add(f"inc_{k}_{col}", int(inc.loc[ct, col]), "arm_increments.csv", f"claim_type={ct}, column={col}", unit="reference occurrences")

        ac = self._csv("arm_comparison")
        ac = ac[ac["variant"] == "all_identifiers"]
        for r in ac.itertuples(index=False):
            k = f"arm{r.arm}_{r.claim_type.replace(' ', '_')}"
            self.add(f"{k}_occ", int(r.occurrences_flagged), "arm_comparison.csv", f"variant=all_identifiers, arm={r.arm}, claim_type={r.claim_type}, column=occurrences_flagged",
                     int(r.occurrences_flagged), int(r.occurrences_total), "reference occurrences", "count")
            self.items[f"{k}_occ"]["share"] = float(r.share)
            self.items[f"{k}_occ"]["ci"] = [float(r.ci_low), float(r.ci_high)]
            self.add(f"{k}_reviews", int(r.reviews_with_flag), "arm_comparison.csv", f"arm={r.arm}, claim_type={r.claim_type}, column=reviews_with_flag", unit="reviews")
            self.add(f"{k}_works", int(r.unique_works_flagged), "arm_comparison.csv", f"arm={r.arm}, claim_type={r.claim_type}, column=unique_works_flagged", unit="unique cited works")
            self.add(f"{k}_unamb", int(r.occurrences_flagged_unambiguous), "arm_comparison.csv", f"arm={r.arm}, claim_type={r.claim_type}, column=occurrences_flagged_unambiguous", unit="reference occurrences")
            self.add(f"{k}_rw_records", int(r.rw_records_linked), "arm_comparison.csv", f"arm={r.arm}, claim_type={r.claim_type}, column=rw_records_linked", unit="Retraction Watch records")
            self.add(f"{k}_pm_notices", int(r.pubmed_notices_linked), "arm_comparison.csv", f"arm={r.arm}, claim_type={r.claim_type}, column=pubmed_notices_linked", unit="PubMed notices")

        so = self._csv("source_overlap")
        for r in so.itertuples(index=False):
            s = {"both": "both", "Retraction Watch only": "rw_only", "PubMed only": "pm_only"}[r.sources]
            self.add(f"overlap_{r.claim_type}_{s}", int(r.occurrences), "source_overlap.csv", f"claim_type={r.claim_type}, sources={r.sources}", unit="reference occurrences")

        tm = self._csv("timing")
        tm = tm[tm["variant"] == "all_identifiers"]
        ref = {"first online date (primary)": "primary", "issue date (S2)": "s2", "first online date, 183-day lead (S3)": "s3"}
        for r in tm.itertuples(index=False):
            k = f"timing_{ref[r.timing_reference]}_{r.claim_type.replace(' ', '_')}"
            for col in ["before_review", "within_lead_window", "after_review", "indeterminate", "determinate", "flagged_occurrence_claims"]:
                self.add(f"{k}_{col}", int(getattr(r, col)), "timing.csv", f"variant=all_identifiers, timing_reference={r.timing_reference}, claim_type={r.claim_type}, column={col}", unit="occurrence-claim-type pairs")
            self.add(f"{k}_det_share", float(r.determinate_share), "timing.csv", f"timing_reference={r.timing_reference}, claim_type={r.claim_type}, column=determinate_share",
                     int(r.determinate), int(r.flagged_occurrence_claims), "flagged occurrences", "share")
            self.items[f"{k}_det_share"]["ci"] = [float(r.wilson_low), float(r.wilson_high)]

        a1 = self._csv("amendment_a1_refsource_timing").set_index("claim_type")
        for ct in a1.index:
            for col in ["relations_without_notice_pmid", "date_parsed", "before_review", "after_review", "indeterminate"]:
                self.add(f"a1_{ct}_{col}", int(a1.loc[ct, col]), "amendment_a1_refsource_timing.csv", f"claim_type={ct}, column={col}", unit="PubMed relations")

        rl = self._csv("review_level")
        for r in rl.itertuples(index=False):
            self.add(f"reviews_{r.arm}_{r.claim_type.replace(' ', '_')}", int(r.reviews_with_flag), "review_level.csv", f"arm={r.arm}, claim_type={r.claim_type}",
                     int(r.reviews_with_flag), int(r.reviews), "reviews", "count")
            self.items[f"reviews_{r.arm}_{r.claim_type.replace(' ', '_')}"]["ci"] = [float(r.wilson_low), float(r.wilson_high)]

        cn = self._csv("cited_notices_summary")
        self.add("cited_notice_occurrences_total", int(cn["occurrences"].sum()), "cited_notices_summary.csv", "sum of occurrences", unit="occurrence-notice pairs")
        for r in cn.itertuples(index=False):
            self.add(f"cited_notice_{r.source}_{r.claim_type}", int(r.occurrences), "cited_notices_summary.csv", f"source={r.source}, claim_type={r.claim_type}", unit="occurrence-notice pairs")

        fz = self._csv("fuzzy_queue_summary")
        self.add("fuzzy_candidates", int(fz["candidates"].sum()) if len(fz) else 0, "fuzzy_queue_summary.csv", "sum of candidates", unit="candidate pairs")

        sens = self._csv("sensitivity")
        codes = {"primary (all identifiers)": "primary", "S1 tagged identifiers only": "s1", "S4 unique cited works": "s4",
                 "S5 excluding references that cite a notice": "s5"}
        for r in sens.itertuples(index=False):
            if "usable identifier" in r.measure:
                m = "any_id"
            else:
                m = next(ct for ct in ("retraction", "expression_of_concern", "correction") if f" {ct} " in f" {r.measure} ")
            key = f"sens_{codes[r.analysis]}_{m}"
            self.add(key, float(r.estimate), "sensitivity.csv", f"analysis={r.analysis}, measure={r.measure}", int(r.numerator), int(r.denominator), r.measure, "share")

        ir = self._csv("timing_indeterminate_reasons")
        for (src, ct, reason), grp in ir.groupby(["source", "claim_type", "reason"]):
            key = f"indet_{src}_{ct}_" + reason.replace(" ", "_")
            self.add(key, int(grp["claims"].sum()), "timing_indeterminate_reasons.csv", f"source={src}, claim_type={ct}, reason={reason}", unit="claims")
        nt = self._csv("no_identifier_types").set_index("jats_publication_type")
        for typ in ("journal", "book"):
            if typ in nt.index:
                self.add(f"noid_{typ}_share", float(nt.loc[typ, "share"]), "no_identifier_types.csv", f"jats_publication_type={typ}, column=share",
                         int(nt.loc[typ, "occurrences"]), int(nt["occurrences"].sum()), "occurrences without identifiers", "share")
        ts = self._csv("retraction_text_signals").set_index("timing")
        for tmg in ts.index:
            for col in ("occurrences", "reference_text_mentions_retraction", "citing_sentence_available", "citing_sentence_mentions_retraction"):
                self.add(f"signal_{tmg}_{col}", int(ts.loc[tmg, col]), "retraction_text_signals.csv", f"timing={tmg}, column={col}", unit="retraction-flagged occurrences")
        self.add("signal_any_sentence_mentions", int(ts["citing_sentence_mentions_retraction"].sum()), "retraction_text_signals.csv", "sum of citing_sentence_mentions_retraction", unit="retraction-flagged occurrences")
        self.add("signal_sentences_available", int(ts["citing_sentence_available"].sum()), "retraction_text_signals.csv", "sum of citing_sentence_available", unit="retraction-flagged occurrences")

        by = self._csv("by_review_year").set_index("review_year")
        for yr in (2014, 2026):
            self.add(f"reviews_online_{yr}", int(by.loc[yr, "reviews"]) if yr in by.index else 0, "by_review_year.csv", f"review_year={yr}, column=reviews", unit="reviews")
        sv = self._csv("sensitivity")
        def sn(analysis, needle):
            r = sv[(sv["analysis"] == analysis) & sv["measure"].str.contains(needle, regex=False)]
            return int(r["numerator"].iloc[0])
        P, S1, S5 = "primary (all identifiers)", "S1 tagged identifiers only", "S5 excluding references that cite a notice"
        for ct in ("retraction", "expression_of_concern", "correction"):
            self.add(f"s1_drop_{ct}", sn(P, f" {ct} ") - sn(S1, f" {ct} "), "sensitivity.csv", f"primary minus S1 numerator, {ct}", unit="reference occurrences")
            self.add(f"s5_drop_{ct}", sn(P, f" {ct} ") - sn(S5, f" {ct} "), "sensitivity.csv", f"primary minus S5 numerator, {ct}", unit="reference occurrences")
        cov = self._csv("identifier_coverage")
        cv = cov[cov["metric"] == "any usable DOI, PMID or PMCID"].set_index("variant")["estimate"]
        self.add("s1_cov_diff_pp", round(float((cv["all_identifiers"] - cv["tagged_only"]) * 100), 2), "identifier_coverage.csv", "any-identifier estimate, all minus tagged_only, percentage points", unit="percentage points")

        bs = json.loads((root / "data/processed/build_summary.json").read_text())
        self.add("rw_records", int(bs["rw_records"]), "data/processed/build_summary.json", "rw_records", unit="Retraction Watch records")
        rc_path = self.t / "recheck_flagged_claims.csv"
        if rc_path.exists():
            rc = pd.read_csv(rc_path, dtype=str)
            pm = rc[rc["source"] == "pubmed"]
            rw = rc[rc["source"] == "retraction_watch"]
            dated = pm["pubmed_notice_date_fresh"].dropna()
            self.add("rc_rows", len(rc), "recheck_flagged_claims.csv", "row count", unit="claim rows")
            self.add("rc_pm_rows", len(pm), "recheck_flagged_claims.csv", "source=pubmed", unit="claim rows")
            self.add("rc_pm_confirmed", int((pm["pubmed_fresh"] == "confirmed").sum()), "recheck_flagged_claims.csv", "source=pubmed, pubmed_fresh=confirmed",
                     int((pm["pubmed_fresh"] == "confirmed").sum()), len(pm), "PubMed claim rows", "count")
            self.add("rc_pm_dates_same", int((dated == "same").sum()), "recheck_flagged_claims.csv", "pubmed_notice_date_fresh=same",
                     int((dated == "same").sum()), len(dated), "PubMed claims with a dated notice", "count")
            self.add("rc_rw_rows", len(rw), "recheck_flagged_claims.csv", "source=retraction_watch", unit="claim rows")
            self.add("rc_rw_crossref_confirmed", int((rw["crossref"] == "record confirmed").sum()), "recheck_flagged_claims.csv",
                     "source=retraction_watch, crossref=record confirmed", int((rw["crossref"] == "record confirmed").sum()), len(rw), "Retraction Watch claim rows", "count")
        rp_path = self.t / "recheck_parse_sample.csv"
        if rp_path.exists():
            rp = pd.read_csv(rp_path, dtype=str)
            self.add("rc_parse_rows", len(rp), "recheck_parse_sample.csv", "row count", unit="reference occurrences")
            self.add("rc_parse_agree", int((rp["regex_status"] == "agree").sum()), "recheck_parse_sample.csv", "regex_status=agree", unit="reference occurrences")
            self.add("rc_parse_text", int((rp["pmc_text_status"] == "all parsed ids present").sum()), "recheck_parse_sample.csv", "pmc_text_status=all parsed ids present", unit="reference occurrences")

        val_path = self.t / "validation_report.json"
        if val_path.exists():
            val = json.loads(val_path.read_text())
            self.add("val_claims_checked", int(val["claim_reconciliation"]["claims_checked"]), "validation_report.json", "claim_reconciliation.claims_checked", unit="claims")
            self.add("val_claims_reconciled", int(val["claim_reconciliation"]["claims_reconciled"]), "validation_report.json", "claim_reconciliation.claims_reconciled", unit="claims")
            self.add("val_tests", val["software_tests"]["summary"], "validation_report.json", "software_tests.summary")
            if "determinism" in val:
                self.add("val_determinism_identical", bool(val["determinism"]["all_identical"]), "validation_report.json", "determinism.all_identical")
                self.add("val_determinism_files", int(val["determinism"]["files_compared"]), "validation_report.json", "determinism.files_compared")
            fm = val["fuzzy_mechanics_check"]
            self.add("val_fuzzy_recovered", int(fm["recovered_by_title_rule"]), "validation_report.json", "fuzzy_mechanics_check.recovered_by_title_rule",
                     int(fm["recovered_by_title_rule"]), int(fm["identifier_linked_occurrences"]), "identifier-linked occurrences", "count")

    def fmt(self, key, kind="auto", digits=1):
        it = self.items[key]
        v = it["value"]
        if kind == "pct":
            if isinstance(v, int) and it.get("denominator"):
                return _pct(it["numerator"] / it["denominator"], digits)
            return _pct(v, digits)
        if kind == "ci":
            lo, hi = it["ci"]
            return f"{_pct(lo, digits)} to {_pct(hi, digits)}"
        if isinstance(v, bool):
            return "yes" if v else "no"
        if isinstance(v, int):
            return f"{v:,}"
        if isinstance(v, float):
            return _pct(v, digits)
        return str(v)

    def fmt_count(self, key) -> str:
        """Numerator of a share item, formatted as a count."""
        return f"{int(self.items[key]['numerator']):,}"

    def claims_json(self) -> dict:
        root = self.cfg.root
        hashes = {
            "retraction_watch_csv_sha256": self.cfg["retraction_watch"]["sha256"],
            "frame_manifest_sha256": hashlib.sha256((root / "data/interim/frame_manifest.csv").read_bytes()).hexdigest(),
        }
        for k, it in self.items.items():
            p = root / it["path"]
            it["output_sha256"] = hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
        return {
            "run_id": self.meta["run_id"],
            "configuration": "config/config.yaml",
            "source_hashes": hashes,
            "units_note": "Reference occurrences, unique cited works, reviews and notices are separate units and are never added together.",
            "claims": self.items,
        }
