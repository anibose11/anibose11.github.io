"""Audit a user-supplied bibliography with the same linkage as the study.

Accepted formats (see docs/bibliography_format.md):

* CSV with a header row. Recognized columns (case-insensitive): ``id``,
  ``doi``, ``pmid``, ``pmcid``, ``title``, ``year``, ``first_author``,
  ``source``. At least one of doi, pmid, pmcid or title must be present.
* RIS. ``DO`` is read as a DOI, ``UR`` links to doi.org or PubMed are read as
  links, and ``PMID:``/``PMCID:`` strings anywhere in the record are read as
  free-text identifiers. ``TI``/``T1``, ``PY``/``Y1``, ``AU``/``A1`` and
  ``T2``/``JO`` give title, year, first author and source.
"""

from __future__ import annotations

import csv
import re
import shutil
import tempfile
from pathlib import Path

import pandas as pd

from .acquire import clients, resolve_cited
from .build import rw_for_db, run_variant
from .config import Config
from .identifiers import doi_from_url, dois_in_text, normalize_doi, normalize_pmcid, normalize_pmid, pmcids_in_text, pmids_in_text
from .outputs import write_audit_workbook
from .retraction_watch import load_notices

BIB_REVIEW = "BIBLIOGRAPHY"


def _row(idx: int, title: str, year, author: str, source: str, ids: list[tuple[str, str, str | None, str]], text: str) -> tuple[dict, list[dict]]:
    occ_id = f"{BIB_REVIEW}|{idx}|1"
    m = re.search(r"(1[89]\d\d|20\d\d)", str(year or ""))
    occ = {
        "occurrence_id": occ_id, "review_pmcid": BIB_REVIEW, "ref_id": str(idx), "ref_label": str(idx), "ref_position": idx,
        "citation_index": 1, "citation_tag": "bibliography", "publication_type": "", "article_title": title or "",
        "source": source or "", "year": int(m.group(1)) if m else None, "volume": "", "fpage": "", "first_author": author or "",
        "ref_text": text, "text_mentions_retract": bool(re.search(r"\bretract", text, re.I)),
        "text_mentions_withdrawn": bool(re.search(r"\bwithdraw", text, re.I)),
        "text_mentions_expression_of_concern": bool(re.search(r"expression of concern", text, re.I)),
        "text_mentions_erratum_or_correction": bool(re.search(r"\berrat|\bcorrigend|\bcorrection to\b", text, re.I)),
    }
    rows = [{"occurrence_id": occ_id, "kind": k, "raw": raw, "normalized": n, "provenance": prov} for k, raw, n, prov in ids]
    return occ, rows


def parse_csv(path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    occs, idents = [], []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        cols = {c.lower().strip(): c for c in (reader.fieldnames or [])}
        if not ({"doi", "pmid", "pmcid", "title"} & set(cols)):
            raise ValueError("CSV needs at least one of the columns doi, pmid, pmcid, title")
        for i, rec in enumerate(reader, start=1):
            get = lambda k: (rec.get(cols[k]) or "").strip() if k in cols else ""
            ids = []
            if get("doi"):
                ids.append(("doi", get("doi"), normalize_doi(get("doi")).normalized, "tag"))
            if get("pmid"):
                ids.append(("pmid", get("pmid"), normalize_pmid(get("pmid")), "tag"))
            if get("pmcid"):
                ids.append(("pmcid", get("pmcid"), normalize_pmcid(get("pmcid")), "tag"))
            text = " ".join(v for v in rec.values() if v)
            occ, rows = _row(int(get("id")) if get("id").isdigit() else i, get("title"), get("year"), get("first_author"), get("source"), ids, text)
            occs.append(occ)
            idents.extend(rows)
    return pd.DataFrame(occs), pd.DataFrame(idents, columns=["occurrence_id", "kind", "raw", "normalized", "provenance"])


def parse_ris(path: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    occs, idents = [], []
    rec: list[tuple[str, str]] = []
    i = 0

    def flush():
        nonlocal i
        if not rec:
            return
        i += 1
        get = lambda *tags: next((v for t, v in rec if t in tags), "")
        ids = []
        for t, v in rec:
            if t == "DO":
                ids.append(("doi", v, normalize_doi(v).normalized, "tag"))
            elif t in ("UR", "L1", "L2"):
                raw = doi_from_url(v)
                if raw:
                    ids.append(("doi", raw, normalize_doi(raw).normalized, "link"))
                m = re.search(r"(?:pubmed\.ncbi\.nlm\.nih\.gov/|ncbi\.nlm\.nih\.gov/pubmed/)(\d{1,9})\b", v)
                if m:
                    ids.append(("pmid", m.group(1), normalize_pmid(m.group(1)), "link"))
        text = " ".join(v for _, v in rec)
        seen = {(k, n) for k, _, n, _ in ids if n}
        for raw in dois_in_text(" ".join(v for t, v in rec if t not in ("DO", "UR", "L1", "L2"))):
            n = normalize_doi(raw).normalized
            if n and ("doi", n) not in seen:
                ids.append(("doi", raw, n, "text"))
                seen.add(("doi", n))
        for p in pmids_in_text(text):
            if ("pmid", p) not in seen:
                ids.append(("pmid", p, p, "text"))
        for p in pmcids_in_text(text):
            if ("pmcid", p) not in seen:
                ids.append(("pmcid", p, p, "text"))
        occ, rows = _row(i, get("TI", "T1"), get("PY", "Y1", "DA"), get("AU", "A1").split(",")[0], get("T2", "JO", "JF"), ids, text)
        occs.append(occ)
        idents.extend(rows)
        rec.clear()

    with open(path, encoding="utf-8-sig") as fh:
        for line in fh:
            m = re.match(r"^([A-Z][A-Z0-9])  - ?(.*)$", line.rstrip("\n"))
            if not m:
                continue
            tag, val = m.group(1), m.group(2).strip()
            if tag == "ER":
                flush()
            else:
                rec.append((tag, val))
    flush()
    return pd.DataFrame(occs), pd.DataFrame(idents, columns=["occurrence_id", "kind", "raw", "normalized", "provenance"])


def _empty_lookups(interim: Path) -> None:
    S = lambda: pd.Series(dtype="string")
    pd.DataFrame({c: S() for c in ["pmcid", "pmid", "doi", "status", "errmsg"]}).to_parquet(interim / "cited_pmcid_conversion.parquet", index=False)
    pd.DataFrame(
        {
            "pmid": S(), "kind": S(), "title": S(), "journal": S(),
            "pmcid": S(), "first_author": S(), "year": pd.Series(dtype="Int64"),
            "pubtypes": S(), "has_retracted_pubtype": pd.Series(dtype=bool), "notice_kind": S(),
            "elec_start": pd.Series(dtype="datetime64[us]"), "elec_end": pd.Series(dtype="datetime64[us]"), "elec_precision": S(),
            "issue_start": pd.Series(dtype="datetime64[us]"), "issue_end": pd.Series(dtype="datetime64[us]"), "issue_precision": S(),
        }
    ).to_parquet(interim / "cited_pubmed.parquet", index=False)
    for name in ("cited_pubmed.parquet",):
        shutil.copy(interim / name, interim / "notice_pubmed.parquet")
    pd.DataFrame({c: S() for c in ["pmid", "doi"]}).to_parquet(interim / "cited_pubmed_dois.parquet", index=False)
    pd.DataFrame({c: S() for c in ["pmid", "reftype", "refsource", "rel_pmid"]}).to_parquet(interim / "cited_pubmed_relations.parquet", index=False)
    pd.DataFrame({c: S() for c in ["pmid", "status"]}).to_parquet(interim / "cited_pmid_status.parquet", index=False)
    pd.DataFrame({c: S() for c in ["doi", "status", "pmid"]}).to_parquet(interim / "doi_pmid_search.parquet", index=False)


def audit_file(cfg: Config, bib_path: str, out_path: str, review_date: str | None, offline: bool, rw_csv: Path | None = None) -> dict:
    bib = Path(bib_path)
    occ, idents = parse_ris(bib) if bib.suffix.lower() in (".ris", ".txt") else parse_csv(bib)
    work = Path(tempfile.mkdtemp(prefix="rae_audit_"))
    try:
        occ.to_parquet(work / "occurrences.parquet", index=False)
        idents.to_parquet(work / "occurrence_identifiers.parquet", index=False)
        if offline:
            _empty_lookups(work)
        else:
            ncbi, s3 = clients(cfg)
            resolve_cited(cfg, ncbi, idents, work)
            ncbi.close()
            s3.close()
        d = pd.to_datetime(review_date).date() if review_date else None
        rdates = pd.DataFrame(
            [{"pmcid": BIB_REVIEW, "online_start": d, "online_end": d, "online_source": "user_supplied" if d else "unknown",
              "online_precision": "day" if d else "unknown", "issue_start": d, "issue_end": d, "issue_source": "user_supplied" if d else "unknown",
              "issue_precision": "day" if d else "unknown"}]
        )
        rdates["online_start"] = pd.to_datetime(rdates["online_start"]).dt.date
        rdates["online_end"] = pd.to_datetime(rdates["online_end"]).dt.date
        rdates["issue_start"] = pd.to_datetime(rdates["issue_start"]).dt.date
        rdates["issue_end"] = pd.to_datetime(rdates["issue_end"]).dt.date
        rw_path = rw_csv or cfg.path("raw") / "retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv"
        rw = load_notices(rw_path)
        res = run_variant(cfg, rw_for_db(rw), rdates, "all", work)
        summary = write_audit_workbook(Path(out_path), occ, idents, res, rw, offline=offline, review_date=review_date,
                                       rw_label=rw_path.name)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    return summary
