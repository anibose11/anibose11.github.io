"""Command-line interface: ``rae <stage>``.

Stages: acquire, build, analyze, validate, render, package, all.
``rae audit <bibliography>`` checks a user-supplied bibliography file.
``rae demo`` runs the pipeline mechanics on the labeled test fixture only.
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time

from .config import load_config


def _setup_logging(cfg) -> None:
    logdir = cfg.root / ".local" / "logs"
    logdir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(logdir / "rae.log"), logging.StreamHandler(sys.stderr)],
    )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="rae", description="Retraction-aware evidence linkage for review reference lists")
    ap.add_argument("--config", default=None, help="path to config.yaml")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("acquire", help="download and cache all inputs (network)")
    sub.add_parser("build", help="parse, link and classify from cached inputs")
    sub.add_parser("analyze", help="compute tables, intervals, figures and workbooks")
    sub.add_parser("validate", help="source reconciliation and determinism checks")
    sub.add_parser("render", help="render the Quarto report and manuscript")
    sub.add_parser("package", help="build the source archive, site and outer bundle")
    sub.add_parser("all", help="acquire, build, analyze, validate, render, package")
    a = sub.add_parser("audit", help="audit a bibliography file (CSV or RIS) against the snapshot")
    a.add_argument("bibliography")
    a.add_argument("--out", default="audit_output.xlsx")
    a.add_argument("--review-date", default=None, help="date the reviewed document was first public (YYYY-MM-DD)")
    a.add_argument("--offline", action="store_true", help="do not query NCBI, match identifiers as given")
    sub.add_parser("demo", help="run the mechanics on the labeled fixture (not study data)")
    sub.add_parser("recheck", help="re-check flagged claims and the parse sample against fresh records (network)")
    args = ap.parse_args(argv)

    cfg = load_config(args.config)
    _setup_logging(cfg)
    t0 = time.time()
    stages = ["acquire", "build", "analyze", "validate", "render", "package"] if args.cmd == "all" else [args.cmd]
    for stage in stages:
        if stage == "acquire":
            from .acquire import acquire

            print(json.dumps(acquire(cfg), indent=1, default=str))
        elif stage == "build":
            from .build import build

            print(json.dumps(build(cfg), indent=1, default=str))
        elif stage == "analyze":
            from .analysis import analyze

            print(json.dumps(analyze(cfg), indent=1, default=str))
        elif stage == "validate":
            from .validate import validate

            res = validate(cfg)
            print(json.dumps(res, indent=1, default=str))
            if not res.get("all_passed", False):
                return 1
        elif stage == "render":
            from .render import render

            print(json.dumps(render(cfg), indent=1, default=str))
        elif stage == "package":
            from .package import package

            print(json.dumps(package(cfg), indent=1, default=str))
        elif stage == "audit":
            from .bibliography import audit_file

            print(json.dumps(audit_file(cfg, args.bibliography, args.out, args.review_date, args.offline), indent=1, default=str))
        elif stage == "recheck":
            from .recheck import recheck

            print(json.dumps(recheck(cfg), indent=1, default=str))
        elif stage == "demo":
            from .demo import demo

            print(json.dumps(demo(cfg), indent=1, default=str))
    logging.getLogger("rae").info("finished %s in %.1fs", args.cmd, time.time() - t0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
