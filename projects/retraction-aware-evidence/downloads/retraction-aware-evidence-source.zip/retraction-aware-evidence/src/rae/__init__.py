"""Retraction-aware evidence linkage for systematic review reference lists."""

__version__ = "1.0.0"
