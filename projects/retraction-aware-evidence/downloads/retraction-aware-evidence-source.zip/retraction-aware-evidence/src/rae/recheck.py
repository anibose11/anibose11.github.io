"""Re-check stage (network): flagged claims and the parse sample against fresh records.

This repeats the checks of the author's verification protocol in software, with
inputs that do not come from the study cache:

1. Flagged claims (the same rows as the review worksheet): PubMed records of the
   cited article and of the notice are fetched again, and Crossref's REST API
   ``updated-by`` field is read for the cited DOI. That field carries Retraction
   Watch records (with their record IDs) and publisher-deposited updates.
2. Parse sample (the same 100 occurrences as the worksheet): identifiers are
   re-extracted from the raw ``<ref>`` XML with regular expressions, a method
   separate from the lxml parser, and looked up in PMC's own plain-text rendering
   of each review from the PMC Article Datasets.

These are software checks. They do not replace the author's own review.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from lxml import etree

from .config import Config
from .http import CachedClient, FetchError, looks_like_json, looks_like_xml
from .identifiers import normalize_doi, normalize_pmcid, normalize_pmid
from .pubmed import STATUS_REFTYPES, efetch_records

CROSSREF_TYPE = {
    "retraction": "retraction", "partial_retraction": "retraction", "withdrawal": "retraction", "removal": "retraction",
    "expression_of_concern": "expression_of_concern",
    "correction": "correction", "erratum": "correction", "corrigendum": "correction",
    "reinstatement": "reinstatement",
}


def _crossref(client: CachedClient, doi: str) -> dict | None:
    try:
        resp = client.request("GET", f"https://api.crossref.org/works/{doi}", validate=looks_like_json, accept_status=(200, 404))
    except FetchError:
        return {"_error": "request_failed"}
    if resp.status == 404:
        return {"_error": "not_found"}
    return resp.json().get("message", {})


def recheck_claims(cfg: Config, today: str) -> pd.DataFrame:
    root = cfg.root
    q = pd.read_csv(root / "outputs/tables/review_queue.csv", dtype=str)
    rows = q[q["claim_type"].isin(["retraction", "expression_of_concern", "reinstatement"]) | (q["first_arm_linked"] == "B")].copy()
    cache = cfg.path("cache") / f"recheck_{today}"
    ncbi = CachedClient(cache / "ncbi", min_interval=cfg["ncbi"]["min_interval_seconds"])
    xref = CachedClient(cache / "crossref", min_interval=0.5,
                        user_agent="retraction-aware-evidence/1.0 (research reference audit, no mailto)")
    pmids = set(rows["verified_pubmed_record"].dropna().str.split("|").explode())
    pmids |= {k for k in rows.loc[rows["source"] == "pubmed", "notice_key"] if str(k).isdigit()}
    recs, nf, failed = efetch_records(ncbi, cfg, sorted(p for p in pmids if p))
    xcache: dict[str, dict | None] = {}
    import csv

    rw_path = root / "data/raw/retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv"
    with open(rw_path, newline="", encoding="utf-8") as fh:
        rw_doi = {row["Record ID"].strip(): (normalize_doi(row["OriginalPaperDOI"]).normalized or "") for row in csv.DictReader(fh)}
    out = []
    for r in rows.itertuples(index=False):
        res = {"occurrence_id": r.occurrence_id, "source": r.source, "notice_key": r.notice_key, "claim_type": r.claim_type,
               "notice_date": r.notice_date, "timing_primary": r.timing_primary}
        cited = (r.verified_pubmed_record or "").split("|")[0] if isinstance(r.verified_pubmed_record, str) else ""
        rec = recs.get(cited)
        if r.source == "pubmed":
            if rec is None:
                res["pubmed_fresh"] = "cited record unavailable"
            elif str(r.notice_key).startswith("pubtype:"):
                res["pubmed_fresh"] = "confirmed" if "Retracted Publication" in rec.pubtypes else "pubtype absent"
            elif str(r.notice_key).startswith("unlinked:"):
                hit = [x for x in rec.relations if not x["pmid"] and STATUS_REFTYPES.get(x["reftype"]) == r.claim_type]
                res["pubmed_fresh"] = "confirmed" if hit else "relation absent"
            else:
                hit = [x for x in rec.relations if x["pmid"] == r.notice_key and STATUS_REFTYPES.get(x["reftype"]) == r.claim_type]
                res["pubmed_fresh"] = "confirmed" if hit else "relation absent"
                notice = recs.get(r.notice_key)
                if notice is not None and isinstance(r.notice_date, str) and r.notice_date:
                    d = notice.best_date()
                    shown = d.start.isoformat() if d.start == d.end else f"{d.start.isoformat()} to {d.end.isoformat()}"
                    res["pubmed_notice_date_fresh"] = "same" if shown == r.notice_date else f"differs: {shown}"
        else:
            if rec is not None:
                has = rec.has_retracted_pubtype if hasattr(rec, "has_retracted_pubtype") else ("Retracted Publication" in rec.pubtypes)
                rel = {STATUS_REFTYPES.get(x["reftype"]) for x in rec.relations}
                res["pubmed_fresh"] = "also in PubMed" if (r.claim_type in rel or (r.claim_type == "retraction" and has)) else "not in PubMed"
        # Query the article's own DOI: the Retraction Watch original-paper DOI for
        # Retraction Watch claims, the PubMed record's DOI for PubMed claims, and the
        # reference's DOI only when neither exists.
        doi = ""
        if r.source == "retraction_watch" and rw_doi.get(str(r.notice_key)):
            doi = rw_doi[str(r.notice_key)]
        elif rec is not None and rec.dois:
            doi = rec.dois[0]
        elif isinstance(r.cited_doi, str):
            doi = r.cited_doi.split("; ")[0]
        if doi:
            if doi not in xcache:
                xcache[doi] = _crossref(xref, doi)
            m = xcache[doi] or {}
            if "_error" in m:
                res["crossref"] = m["_error"]
            else:
                ups = m.get("updated-by", []) or []
                rw = [u for u in ups if u.get("source") == "retraction-watch"]
                pub = [u for u in ups if u.get("source") == "publisher" and CROSSREF_TYPE.get(u.get("type")) == r.claim_type]
                if r.source == "retraction_watch":
                    match = [u for u in rw if str(u.get("record-id")) == str(r.notice_key)]
                    if match:
                        u = match[0]
                        dp = u.get("updated", {}).get("date-parts", [[None]])[0]
                        d = "-".join(f"{x:02d}" if i else str(x) for i, x in enumerate(dp)) if dp and dp[0] else ""
                        same_type = CROSSREF_TYPE.get(u.get("type")) == r.claim_type
                        res["crossref"] = "record confirmed" if same_type and d == r.notice_date else f"record found, type {u.get('type')}, date {d}"
                    else:
                        res["crossref"] = "record id not listed"
                else:
                    any_same = [u for u in ups if CROSSREF_TYPE.get(u.get("type")) == r.claim_type]
                    res["crossref"] = "same claim type listed" if any_same else "claim type not listed"
                res["crossref_publisher_update_same_type"] = bool(pub)
        else:
            res["crossref"] = "no DOI to query"
        out.append(res)
    df = pd.DataFrame(out)
    df.to_csv(root / "outputs/tables/recheck_flagged_claims.csv", index=False)
    return df


DOI_RX = re.compile(rb"10\.\d{4,9}/[^\s\"'<>&]+")
PMID_TAG = re.compile(rb'pub-id-type="pmid"[^>]*>\s*(\d{1,9})\s*<')
PMID_TXT = re.compile(rb"PMID:?\s*(\d{1,9})", re.I)
PMCID_RX = re.compile(rb"PMC\d{4,9}")


def _ref_xml(xml: bytes, ref_id: str) -> bytes | None:
    m = re.search(rb'<ref\b[^>]*\bid="' + re.escape(ref_id.encode()) + rb'"[^>]*>.*?</ref>', xml, re.S)
    return m.group(0) if m else None


def recheck_parse_sample(cfg: Config, today: str) -> pd.DataFrame:
    root = cfg.root
    import openpyxl

    wb = openpyxl.load_workbook(root / "validation" / "human_validation_worksheet.xlsx", read_only=True)
    ws = wb["Parse sample"]
    rows = list(ws.iter_rows(values_only=True))
    head = rows[0]
    sample = [dict(zip(head, r)) for r in rows[1:] if r[0]]
    idents = pd.read_parquet(root / "data/interim/occurrence_identifiers.parquet")
    ret = pd.read_csv(root / "data/interim/review_retrieval.csv", dtype=str).set_index("pmcid")
    s3_main = CachedClient(cfg.path("cache") / "pmc_cloud", min_interval=0)
    s3_new = CachedClient(cfg.path("cache") / f"recheck_{today}" / "pmc_txt", min_interval=0.1)
    out = []
    for s in sample:
        occ = s["occurrence_id"]
        pmcid, ref_id, _ = occ.split("|")
        mine = idents[(idents["occurrence_id"] == occ) & idents["normalized"].notna()]
        my = {(k, v) for k, v in zip(mine["kind"], mine["normalized"])}
        xml_url = ret.loc[pmcid, "xml_url"]
        from .http import cache_key

        cached = s3_main.get_cached(cache_key("GET", xml_url, None, None))
        frag = _ref_xml(cached.content, ref_id) if cached else None
        res = {"occurrence_id": occ, "stratum": s["stratum"], "parser_ids": len(my)}
        if frag is None:
            res["regex_status"] = "ref element not found"
            out.append(res)
            continue
        cits = re.findall(rb"<(element-citation|mixed-citation|nlm-citation|citation)\b", frag)
        n_cit = len(cits)
        rx = set()
        for d in DOI_RX.findall(frag):
            n = normalize_doi(d.decode("utf-8", "replace")).normalized
            if n:
                rx.add(("doi", n))
        for p in PMID_TAG.findall(frag) + PMID_TXT.findall(frag):
            n = normalize_pmid(p.decode())
            if n:
                rx.add(("pmid", n))
        for p in PMCID_RX.findall(frag):
            n = normalize_pmcid(p.decode())
            if n:
                rx.add(("pmcid", n))
        res["regex_ids"] = len(rx)
        res["citations_in_ref"] = n_cit
        if n_cit > 1:
            res["regex_status"] = "agree" if my <= rx else "parser has ids regex lacks"
            res["note"] = "ref holds several citations, and the regex sees the whole ref"
        else:
            res["regex_status"] = "agree" if my == rx else ("parser missing " + "; ".join(sorted(f"{k}:{v}" for k, v in rx - my)) if rx - my else "") + (
                (" | parser extra " + "; ".join(sorted(f"{k}:{v}" for k, v in my - rx))) if my - rx else "")
        prefix = ret.loc[pmcid, "version_prefix"]
        txt_url = f"{cfg['pmc_cloud']['base']}{prefix}/{prefix}.txt"
        try:
            t = s3_new.request("GET", txt_url, validate=lambda c, ct: len(c) > 100).text.lower()
            missing = [f"{k}:{v}" for k, v in my if v.lower() not in t]
            res["pmc_text_status"] = "all parsed ids present" if not missing else "missing in PMC text: " + "; ".join(missing)
        except FetchError:
            res["pmc_text_status"] = "text unavailable"
        out.append(res)
    df = pd.DataFrame(out)
    df.to_csv(root / "outputs/tables/recheck_parse_sample.csv", index=False)
    return df


def recheck(cfg: Config) -> dict:
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    claims = recheck_claims(cfg, today)
    parse = recheck_parse_sample(cfg, today)
    summary = {
        "run_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "flagged_claim_rows": len(claims),
        "pubmed_fresh": claims["pubmed_fresh"].fillna("not applicable").value_counts().to_dict() if "pubmed_fresh" in claims else {},
        "pubmed_notice_date_fresh": claims.get("pubmed_notice_date_fresh", pd.Series(dtype=str)).dropna().value_counts().to_dict(),
        "crossref_by_source": claims.groupby("source")["crossref"].value_counts().unstack(fill_value=0).to_dict("index"),
        "parse_sample_rows": len(parse),
        "parse_regex": parse["regex_status"].value_counts().to_dict(),
        "parse_pmc_text": parse["pmc_text_status"].fillna("not checked").value_counts().to_dict() if "pmc_text_status" in parse else {},
        "note": "Software re-check against freshly retrieved PubMed and Crossref records and PMC's plain-text rendering. It does not replace the author's review.",
    }
    (cfg.root / "outputs/tables/recheck_summary.json").write_text(json.dumps(summary, indent=1, default=str))
    return summary
