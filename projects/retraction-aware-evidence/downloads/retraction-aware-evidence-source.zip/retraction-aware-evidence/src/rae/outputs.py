"""Excel outputs: the evidence-maintenance review queue and the aggregate workbook.

The review queue lists every reference occurrence with a status claim in arm C,
one row per claim, with identifiers, the source's claim, timing, match
confidence and source links. Citation sentences are shown only for reviews
whose PMC license code is a Creative Commons license. Otherwise the cell says
the text is withheld. No cell states or implies whether a citation endorses or
criticizes the cited study.
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill("solid", fgColor="EEF2F7")
BOLD = Font(bold=True)

QUEUE_DEFINITIONS = [
    ("Grain", "One row per reference occurrence and status claim. A reference occurrence is one citation in one review's reference list."),
    ("claim_type", "retraction, expression_of_concern, correction, reinstatement (Retraction Watch only) or update (PubMed UpdateIn)."),
    ("source", "retraction_watch: Crossref Retraction Watch CSV at the pinned commit. pubmed: CommentsCorrections relation or the Retracted Publication type on the cited PubMed record."),
    ("notice_key", "Retraction Watch Record ID, or the PMID of the PubMed notice. 'pubtype:<pmid>' means the record carries the Retracted Publication type without a linked notice."),
    ("match_confidence", "doi_exact: a DOI written in the reference equals the source DOI. pmid_exact: a PMID in the reference equals the source PMID. ncbi_crosswalk: linked only through an NCBI-verified identifier (PubMed record DOI or PMC ID Converter). pubmed_relation or pubmed_publication_type: relation on the verified PubMed record. ambiguous_identifiers: the reference's identifiers point to more than one record, so check by hand."),
    ("timing_primary", "Notice date interval against the review's first public online date interval. before_review or after_review only when the intervals do not overlap, otherwise indeterminate."),
    ("timing_six_month", "Sensitivity rule from Brown et al. (2022): before_review only when the notice is at least 183 days before the review, and within_lead_window when it is earlier by less than that."),
    ("Not a judgment", "A row records metadata agreement with a status source as of the snapshot. It is not an assessment of the cited study, the review, or anyone's conduct, and citation after a notice does not show endorsement."),
]


def _rel(path, root) -> str:
    """Path relative to the project root when inside it, else absolute."""
    try:
        return str(Path(path).resolve().relative_to(Path(root).resolve()))
    except ValueError:
        return str(path)


def _cell(v):
    if v is None or (isinstance(v, float) and pd.isna(v)) or v is pd.NaT:
        return None
    if isinstance(v, pd.Timestamp):
        return v.date().isoformat() if v == v.normalize() else v.isoformat()
    if hasattr(v, "isoformat") and not isinstance(v, str):
        return v.isoformat()
    if hasattr(v, "__len__") and not isinstance(v, (str, bytes)):
        return "|".join(str(x) for x in v)
    try:
        if pd.isna(v):
            return None
    except (TypeError, ValueError):
        pass
    return v


def _autosize(ws, max_width=70):
    for col in ws.columns:
        width = max((len(str(c.value)) if c.value is not None else 0) for c in col[:200])
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(10, width + 2), max_width)


def _write_df(ws, df: pd.DataFrame, wrap_cols: tuple[str, ...] = ()):
    ws.append(list(df.columns))
    for c in ws[1]:
        c.font = BOLD
        c.fill = HEADER_FILL
    for row in df.itertuples(index=False):
        ws.append([_cell(v) for v in row])
    ws.freeze_panes = "A2"
    _autosize(ws)
    for name in wrap_cols:
        if name in df.columns:
            idx = list(df.columns).index(name) + 1
            ws.column_dimensions[get_column_letter(idx)].width = 70
            for cell in ws.iter_cols(min_col=idx, max_col=idx, min_row=2):
                for c in cell:
                    c.alignment = Alignment(wrap_text=True, vertical="top")


def _date_iv(s, e) -> str:
    if pd.isna(s):
        return ""
    s, e = pd.Timestamp(s).date(), pd.Timestamp(e).date()
    return s.isoformat() if s == e else f"{s.isoformat()} to {e.isoformat()}"


def build_queue(d: dict, rw_commit: str) -> pd.DataFrame:
    led = d["ledger"].set_index("occurrence_id")
    occ = d["occ"].set_index("occurrence_id")
    rv = d["reviews"].set_index("pmcid")
    ids = d["idents"][d["idents"]["normalized"].notna()]
    idmap = ids.groupby(["occurrence_id", "kind"])["normalized"].agg(lambda s: "; ".join(sorted(set(s)))).unstack()
    ctx = d["contexts"]
    ctx_first = ctx.sort_values("sentence_index").groupby(["review_pmcid", "ref_id"])["sentence"].agg(lambda s: " | ".join(s))
    c = d["claims"][d["claims"]["arm"] == "C"].copy()
    first_arm = d["claims"].groupby(["occurrence_id", "source", "notice_key", "claim_type"])["arm"].min()
    rows = []
    for r in c.itertuples(index=False):
        o = occ.loc[r.occurrence_id]
        L = led.loc[r.occurrence_id]
        review = rv.loc[o["review_pmcid"]] if o["review_pmcid"] in rv.index else None
        lic = (review["license_code"] if review is not None else None) or ""
        cc = isinstance(lic, str) and lic.upper().startswith("CC")
        sent = ctx_first.get((o["review_pmcid"], o["ref_id"]), "") if cc else "withheld: review license is not a Creative Commons license"
        doi = idmap.loc[r.occurrence_id, "doi"] if r.occurrence_id in idmap.index and "doi" in idmap.columns else ""
        pmid = idmap.loc[r.occurrence_id, "pmid"] if r.occurrence_id in idmap.index and "pmid" in idmap.columns else ""
        pmcid = idmap.loc[r.occurrence_id, "pmcid"] if r.occurrence_id in idmap.index and "pmcid" in idmap.columns else ""
        found = L["found_pmids"] or ""
        conf = "ambiguous_identifiers" if L["ledger_category"] == "ambiguous" else r.match_basis
        if r.source == "retraction_watch":
            src_link = f"https://gitlab.com/crossref/retraction-watch-data/-/blob/{rw_commit}/retraction_watch.csv (Record ID {r.notice_key})"
        elif str(r.notice_key).isdigit():
            src_link = f"https://pubmed.ncbi.nlm.nih.gov/{r.notice_key}/"
        else:
            src_link = f"https://pubmed.ncbi.nlm.nih.gov/{found.split('|')[0]}/" if found else ""
        rows.append(
            {
                "review_pmcid": o["review_pmcid"],
                "review_title": review["title"] if review is not None else "",
                "review_journal": review["journal"] if review is not None else "",
                "review_license": lic,
                "review_first_online": _date_iv(r.online_start, r.online_end),
                "review_date_source": r.online_source,
                "review_link": f"https://pmc.ncbi.nlm.nih.gov/articles/{o['review_pmcid']}/",
                "occurrence_id": r.occurrence_id,
                "reference_label": o["ref_label"],
                "reference_text": o["ref_text"],
                "cited_doi": doi if isinstance(doi, str) else "",
                "cited_pmid": pmid if isinstance(pmid, str) else "",
                "cited_pmcid": pmcid if isinstance(pmcid, str) else "",
                "verified_pubmed_record": found,
                "ledger_category": L["ledger_category"],
                "claim_type": r.claim_type,
                "source": r.source,
                "source_label": r.source_label,
                "notice_key": r.notice_key,
                "notice_date": _date_iv(r.notice_date_start, r.notice_date_end),
                "notice_date_source": r.notice_date_source,
                "timing_primary": r.timing_primary,
                "timing_issue": r.timing_issue,
                "timing_six_month": r.timing_six_month,
                "match_confidence": conf,
                "matched_on": r.matched_on,
                "first_arm_linked": first_arm.get((r.occurrence_id, r.source, r.notice_key, r.claim_type), "C"),
                "cited_doi_link": f"https://doi.org/{doi.split('; ')[0]}" if isinstance(doi, str) and doi else "",
                "cited_pubmed_link": f"https://pubmed.ncbi.nlm.nih.gov/{found.split('|')[0]}/" if found else "",
                "status_source_link": src_link,
                "reference_text_mentions_retraction": bool(o["text_mentions_retract"]),
                "citing_sentences": sent,
                "citing_sentence_mentions_retraction": bool(cc and "retract" in str(sent).lower()),
            }
        )
    q = pd.DataFrame(rows)
    order = {"retraction": 0, "expression_of_concern": 1, "reinstatement": 2, "correction": 3, "update": 4}
    q["_o"] = q["claim_type"].map(order)
    q = q.sort_values(["_o", "review_pmcid", "occurrence_id", "source"]).drop(columns="_o").reset_index(drop=True)
    return q


def write_review_queue(cfg, d: dict) -> str:
    q = build_queue(d, cfg["retraction_watch"]["commit"])
    out = cfg.path("workbooks") / "review_queue.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Read me"
    ws.append(["Reference status review queue"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append(["Status snapshot", f"Crossref Retraction Watch CSV, commit {cfg['retraction_watch']['commit']} ({cfg['retraction_watch']['commit_title']}). PubMed records retrieved 2026-10-07."])
    ws.append(["Cohort", "1,000 open-access systematic reviews and meta-analyses (diabetes, obesity, heart failure; 2015 to 2025) drawn by identifier hash from a PubMed frame of 7,993."])
    ws.append([])
    for k, v in QUEUE_DEFINITIONS:
        ws.append([k, v])
        ws.cell(ws.max_row, 1).font = BOLD
        ws.cell(ws.max_row, 2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 120
    high = q[q["claim_type"].isin(["retraction", "expression_of_concern", "reinstatement"])]
    ws2 = wb.create_sheet("Retraction and concern")
    _write_df(ws2, high, wrap_cols=("reference_text", "citing_sentences", "review_title"))
    ws3 = wb.create_sheet("Corrections and updates")
    _write_df(ws3, q[q["claim_type"].isin(["correction", "update"])].drop(columns=["citing_sentences", "citing_sentence_mentions_retraction"]),
              wrap_cols=("reference_text", "review_title"))
    cn = d["cited_notices"].merge(d["occ"][["occurrence_id", "review_pmcid", "ref_label", "ref_text"]], on="occurrence_id", how="left")
    ws4 = wb.create_sheet("References citing a notice")
    _write_df(ws4, cn, wrap_cols=("ref_text",))
    fz = d["fuzzy"]
    ws5 = wb.create_sheet("Title candidates (unverified)")
    if len(fz):
        _write_df(ws5, fz)
    else:
        ws5.append(["No title/year candidates met the prespecified rule (token sort ratio >= 90, title >= 30 characters, year within 1) among occurrences without an identifier link."])
    wb.save(out)
    q.to_csv(cfg.path("tables") / "review_queue.csv", index=False)
    return _rel(out, cfg.root)


AGG_DEFINITIONS = [
    ("cohort_flow", "Review-level counts from the PubMed frame to parsed reference lists."),
    ("identifier_coverage", "Grain: reference occurrence. numerator and denominator are occurrence counts, estimate = numerator / denominator, and ci_low and ci_high are review-level cluster bootstrap 95% percentile intervals."),
    ("coverage_ledger", "Grain: reference occurrence. Mutually exclusive ledger categories (see analysis plan section 7)."),
    ("arm_comparison", "Grain: reference occurrence. Arm A matches exact DOIs against Retraction Watch, arm B matches verified expanded identifiers against Retraction Watch, and arm C adds PubMed relations. Unique works and notices are separate units."),
    ("arm_increments", "Occurrence counts flagged in each arm and the set differences between arms."),
    ("source_overlap", "Arm C, per occurrence and claim type: claimed by Retraction Watch only, PubMed only, or both. The sources share upstream notices, so agreement is not independent confirmation."),
    ("timing", "Arm C, one row per occurrence and claim type. A determinate class requires all claims of that type to agree. Wilson intervals for the determinate share."),
    ("sensitivity", "Fixed sensitivity analyses S1, S4, S5 (S2 and S3 are timing rows in the timing table)."),
    ("review_level", "Grain: review. Reviews with at least one flagged occurrence, with Wilson intervals."),
    ("Suppression", "No cell suppression is applied, because the data are public bibliographic metadata with no person-level information. Small counts are shown as counts."),
    ("Filtering", "Proportions must not be recomputed from filtered rows of these aggregates without the occurrence-level tables, because intervals are not additive."),
]


def write_aggregate_workbook(cfg, out: dict, run_id: str) -> str:
    path = cfg.path("workbooks") / "aggregate_results.xlsx"
    wb = Workbook()
    ws = wb.active
    ws.title = "Definitions"
    ws.append(["Aggregate results", f"run id {run_id}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    for k, v in AGG_DEFINITIONS:
        ws.append([k, v])
        ws.cell(ws.max_row, 1).font = BOLD
        ws.cell(ws.max_row, 2).alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 120
    for name in ["cohort_flow", "identifier_coverage", "coverage_ledger", "arm_comparison", "arm_increments", "source_overlap",
                 "match_confidence", "rw_identifier_agreement", "timing", "timing_by_source", "timing_indeterminate_reasons",
                 "review_level", "by_review_year", "sensitivity", "cited_notices_summary", "fuzzy_queue_summary"]:
        df = out[name]
        _write_df(wb.create_sheet(name[:31]), df)
    wb.save(path)
    return _rel(path, cfg.root)


def _join_ids(v) -> str:
    if isinstance(v, str):
        return v
    if v is None or (not hasattr(v, "__len__") and pd.isna(v)):
        return ""
    return "|".join(str(x) for x in v)


def write_audit_workbook(path: Path, occ: pd.DataFrame, idents: pd.DataFrame, res: dict, rw: pd.DataFrame, offline: bool,
                         review_date: str | None, rw_label: str) -> dict:
    led = res["ledger"]
    claims = res["claims"][res["claims"]["arm"] == "C"]
    q = claims.merge(occ[["occurrence_id", "ref_label", "article_title", "year", "ref_text"]], on="occurrence_id", how="left")
    q = q.merge(led[["occurrence_id", "ledger_category"]], on="occurrence_id", how="left")
    q["match_confidence"] = q.apply(lambda r: "ambiguous_identifiers" if r["ledger_category"] == "ambiguous" else r["match_basis"], axis=1)
    keep = ["ref_label", "article_title", "year", "claim_type", "source", "source_label", "notice_key", "notice_date_start",
            "notice_date_end", "timing_primary", "timing_six_month", "match_confidence", "matched_on", "ledger_category", "ref_text"]
    q = q[keep]
    wb = Workbook()
    ws = wb.active
    ws.title = "Read me"
    ws.append(["Bibliography status audit"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append(["Status snapshot", rw_label])
    ws.append(["NCBI lookups", "not run (offline mode): identifiers were matched as written" if offline else "run: PubMed records, DOI search and PMC ID Converter"])
    ws.append(["Review date", review_date or "not supplied: timing is indeterminate"])
    for k, v in QUEUE_DEFINITIONS:
        ws.append([k, v])
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 110
    _write_df(wb.create_sheet("Status claims"), q, wrap_cols=("ref_text",))
    lg = led.merge(occ[["occurrence_id", "ref_label", "article_title"]], on="occurrence_id")
    lg["found_pmids"] = lg["found_pmids"].map(_join_ids)
    _write_df(wb.create_sheet("Coverage ledger"), lg[["ref_label", "article_title", "ledger_category", "has_doi", "has_pmid", "has_pmcid", "found_pmids", "failure_detail"]])
    _write_df(wb.create_sheet("Cited notices"), res["cited_notices"])
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return {"output": str(path), "references": len(occ), "status_claims": len(q),
            "ledger": led["ledger_category"].value_counts().to_dict(), "cited_notices": len(res["cited_notices"])}
