"""Validation stage.

Three kinds of checks, reported separately:

1. Software tests (pytest on synthetic fixtures).
2. Source reconciliation: every status claim is re-checked against the raw
   Retraction Watch CSV row (read with the csv module) and the raw cached
   PubMed XML (parsed with xml.etree, not lxml), with an independent minimal
   identifier comparison. Counts are reconciled across stages.
3. Determinism: build and analyze are re-run offline from cached inputs into a
   scratch directory and compared with the main outputs.

None of these is external scientific validation. The human review worksheet
written here is for a person to complete. Nothing in this module fills it in.
"""

from __future__ import annotations

import copy
import csv
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from urllib.parse import unquote

import numpy as np
import pandas as pd

from .config import Config
from .dates import DateInterval, timing as py_timing


def _rel(path, root) -> str:
    """Path relative to the project root when inside it, else absolute."""
    try:
        return str(Path(path).resolve().relative_to(Path(root).resolve()))
    except ValueError:
        return str(path)


def _simple_doi(s: str | None) -> str:
    """Deliberately separate, minimal DOI comparison for reconciliation."""
    if not s:
        return ""
    s = unquote(s.strip()).lower()
    for p in ("https://doi.org/", "http://doi.org/", "https://dx.doi.org/", "http://dx.doi.org/", "doi:"):
        if s.startswith(p):
            s = s[len(p):].strip()
    return s.rstrip(".;,")


def run_pytest(cfg: Config) -> dict:
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q", "--no-header", "-p", "no:cacheprovider", str(cfg.root / "tests")],
                          capture_output=True, text=True, cwd=cfg.root)
    tail = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else proc.stderr[-300:]
    return {"passed": proc.returncode == 0, "summary": tail}


def _raw_rw(cfg: Config) -> dict[str, dict]:
    path = cfg.path("raw") / "retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv"
    with open(path, newline="", encoding="utf-8") as fh:
        return {row["Record ID"].strip(): row for row in csv.DictReader(fh)}


def _pubmed_index(cfg: Config) -> dict[str, dict]:
    """PMID -> relations, pubtypes and DOIs from every cached efetch response."""
    idx: dict[str, dict] = {}
    cache = cfg.path("cache") / "ncbi"
    for meta_path in cache.glob("*/*.json"):
        meta = json.loads(meta_path.read_text())
        if not meta["url"].endswith("efetch.fcgi"):
            continue
        body = gzip.decompress(meta_path.with_suffix(".gz").read_bytes())
        root = ET.fromstring(body)
        for art in root.findall("PubmedArticle"):
            pmid = (art.findtext("MedlineCitation/PMID") or "").strip()
            rels = [(cc.get("RefType"), (cc.findtext("PMID") or "").strip()) for cc in art.findall("MedlineCitation/CommentsCorrectionsList/CommentsCorrections")]
            pts = ["".join(p.itertext()).strip() for p in art.findall("MedlineCitation/Article/PublicationTypeList/PublicationType")]
            dois = {_simple_doi(a.text) for a in art.findall("PubmedData/ArticleIdList/ArticleId") if a.get("IdType") == "doi"}
            dois |= {_simple_doi(e.text) for e in art.findall("MedlineCitation/Article/ELocationID") if e.get("EIdType") == "doi"}
            idx[pmid] = {"rels": rels, "pubtypes": pts, "dois": dois}
    return idx


RW_TO_CLAIM = {"Retraction": "retraction", "Correction": "correction", "Expression of concern": "expression_of_concern", "Reinstatement": "reinstatement"}
PM_TO_CLAIM = {"RetractionIn": "retraction", "RetractedandRepublishedIn": "retraction", "ExpressionOfConcernIn": "expression_of_concern",
               "ErratumIn": "correction", "CorrectedandRepublishedIn": "correction", "UpdateIn": "update"}


def reconcile_claims(cfg: Config) -> dict:
    p, i = cfg.path("processed"), cfg.path("interim")
    claims = pd.read_parquet(p / "claims.parquet")
    exp = pd.read_parquet(p / "expanded_identifiers.parquet")
    raw_ids = pd.read_parquet(i / "occurrence_identifiers.parquet")
    rw = _raw_rw(cfg)
    pm = _pubmed_index(cfg)
    exp_by = exp.groupby("occurrence_id")
    raw_by = raw_ids.groupby("occurrence_id")
    rows = []
    for c in claims[claims["arm"] == "C"].itertuples(index=False):
        ok, why = True, []
        if c.source == "retraction_watch":
            row = rw.get(c.notice_key)
            if row is None:
                ok, why = False, ["record missing from raw CSV"]
            else:
                if RW_TO_CLAIM.get(row["RetractionNature"].strip()) != c.claim_type:
                    ok = False
                    why.append("nature mismatch")
                m, d, y = row["RetractionDate"].split(" ")[0].split("/")
                if pd.Timestamp(int(y), int(m), int(d)) != pd.Timestamp(c.notice_date_start):
                    ok = False
                    why.append("date mismatch")
                rw_doi = _simple_doi(row["OriginalPaperDOI"]) if row["OriginalPaperDOI"].lower() not in ("", "unavailable") else ""
                rw_pmid = row["OriginalPaperPubMedID"].strip().lstrip("0")
                ref_raw = raw_by.get_group(c.occurrence_id) if c.occurrence_id in raw_by.groups else pd.DataFrame(columns=["kind", "raw"])
                ref_dois = {_simple_doi(x) for x in ref_raw.loc[ref_raw["kind"] == "doi", "raw"]}
                ref_pmids = {str(x).strip().lstrip("0") for x in ref_raw.loc[ref_raw["kind"] == "pmid", "raw"]}
                direct = (rw_doi and rw_doi in ref_dois) or (rw_pmid and rw_pmid in ref_pmids)
                via = False
                if not direct:
                    e = exp_by.get_group(c.occurrence_id)
                    for pmid in e.loc[e["kind"] == "pmid", "id"]:
                        rec = pm.get(pmid)
                        if rec and ((rw_doi and rw_doi in rec["dois"]) or (rw_pmid and rw_pmid == pmid)):
                            via = True
                if not (direct or via):
                    ok = False
                    why.append("identifier not confirmed in raw sources")
                basis = "direct" if direct else ("via_raw_pubmed_record" if via else "unconfirmed")
        else:
            cited = str(c.cited_pmid)
            rec = pm.get(cited)
            basis = "raw_pubmed_record"
            if rec is None:
                ok, why = False, ["cited record missing from raw cache"]
            elif str(c.notice_key).startswith("pubtype:"):
                if "Retracted Publication" not in rec["pubtypes"]:
                    ok = False
                    why.append("Retracted Publication type not in raw record")
            else:
                hit = [t for t, n in rec["rels"] if n == str(c.notice_key) and PM_TO_CLAIM.get(t) == c.claim_type]
                if str(c.notice_key).startswith("unlinked:"):
                    hit = [t for t, n in rec["rels"] if not n and PM_TO_CLAIM.get(t) == c.claim_type]
                if not hit:
                    ok = False
                    why.append("relation not in raw record")
        rows.append({"occurrence_id": c.occurrence_id, "source": c.source, "notice_key": c.notice_key, "claim_type": c.claim_type,
                     "reconciled": ok, "basis": basis, "problems": "; ".join(why)})
    rec = pd.DataFrame(rows)
    out = cfg.path("tables") / "validation_claim_reconciliation.csv"
    rec.to_csv(out, index=False)
    return {"claims_checked": len(rec), "claims_reconciled": int(rec["reconciled"].sum()),
            "by_source": rec.groupby("source")["reconciled"].agg(["size", "sum"]).astype(int).to_dict("index"),
            "basis": rec["basis"].value_counts().to_dict(), "failures": rec.loc[~rec["reconciled"]].head(20).to_dict("records"),
            "table": _rel(out, cfg.root)}


def reconcile_counts(cfg: Config) -> dict:
    p, i = cfg.path("processed"), cfg.path("interim")
    occ = pd.read_parquet(i / "occurrences.parquet")
    led = pd.read_parquet(p / "occurrence_ledger.parquet")
    led_t = pd.read_parquet(p / "occurrence_ledger_tagged_only.parquet")
    claims = pd.read_parquet(p / "claims.parquet")
    parse = pd.read_csv(i / "review_parse.csv")
    ret = pd.read_csv(i / "review_retrieval.csv", dtype=str)
    frame = pd.read_csv(i / "frame_manifest.csv", dtype={"pmid": str})
    checks = {}
    checks["ledger_rows_equal_occurrences"] = len(led) == len(occ) == len(led_t)
    checks["ledger_ids_unique"] = bool(led["occurrence_id"].is_unique)
    checks["parse_counts_sum_to_occurrences"] = int(parse["n_occurrences"].sum()) == len(occ)
    checks["per_review_counts_match"] = bool((occ.groupby("review_pmcid").size().sort_index().values ==
                                              parse.set_index("pmcid")["n_occurrences"].sort_index().values).all())
    checks["frame_selected_1000"] = int(frame["selected"].sum()) == int(cfg["frame"]["sample_size"])
    checks["retrieval_rows_equal_selected"] = len(ret) == int(frame["selected"].sum())
    checks["xml_md5_all_match"] = bool((ret["md5_expected"] == ret["md5_observed"]).all())
    rwB = set(map(tuple, claims[(claims.arm == "B")][["occurrence_id", "notice_key"]].values))
    rwA = set(map(tuple, claims[(claims.arm == "A")][["occurrence_id", "notice_key"]].values))
    rwC = set(map(tuple, claims[(claims.arm == "C") & (claims.source == "retraction_watch")][["occurrence_id", "notice_key"]].values))
    checks["arm_A_subset_of_B"] = rwA <= rwB
    checks["arm_C_retraction_watch_equals_B"] = rwC == rwB
    digest = hashlib.sha256((i / "frame_manifest.csv").read_bytes()).hexdigest()
    recorded = (i / "frame_manifest.sha256").read_text().split()[0]
    checks["frame_manifest_hash_unchanged"] = digest == recorded
    rwp = cfg.path("raw") / "retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv"
    checks["rw_snapshot_hash_matches_config"] = hashlib.sha256(rwp.read_bytes()).hexdigest() == cfg["retraction_watch"]["sha256"]
    return {"checks": checks, "all_passed": all(checks.values()), "frame_manifest_sha256": digest}


def timing_equivalence(cfg: Config) -> dict:
    """SQL timing equals the Python interval rule on every claim."""
    c = pd.read_parquet(cfg.path("processed") / "claims.parquet")
    bad = 0
    for r in c.itertuples(index=False):
        n = DateInterval(pd.Timestamp(r.notice_date_start).date() if pd.notna(r.notice_date_start) else None,
                         pd.Timestamp(r.notice_date_end).date() if pd.notna(r.notice_date_end) else None, "x")
        v = DateInterval(pd.Timestamp(r.online_start).date() if pd.notna(r.online_start) else None,
                         pd.Timestamp(r.online_end).date() if pd.notna(r.online_end) else None, "x")
        if py_timing(n, v) != r.timing_primary or py_timing(n, v, int(cfg["analysis"]["six_month_rule_days"])) != r.timing_six_month:
            bad += 1
    return {"claims": len(c), "mismatches": bad, "passed": bad == 0}


def fuzzy_recovery(cfg: Config) -> dict:
    """Mechanics check: does the title rule find the identifier-linked occurrences?"""
    from .fuzzy import fuzzy_candidates
    from .retraction_watch import load_notices

    c = pd.read_parquet(cfg.path("processed") / "claims.parquet")
    occ = pd.read_parquet(cfg.path("interim") / "occurrences.parquet")
    rw = load_notices(cfg.path("raw") / "retraction_watch" / f"retraction_watch_{cfg['retraction_watch']['commit']}.csv")
    b = c[c["arm"] == "B"][["occurrence_id", "notice_key"]]
    linked = set(b["occurrence_id"])
    cand = fuzzy_candidates(occ[occ["occurrence_id"].isin(linked)], rw, pd.DataFrame(columns=["occurrence_id", "kind", "id"]), cfg)
    hits = set(map(tuple, cand[["occurrence_id", "rw_record_id"]].values)) & set(map(tuple, b.values))
    return {"identifier_linked_occurrences": len(linked), "recovered_by_title_rule": len({h[0] for h in hits}),
            "note": "Identifiers hidden, matched on title, year within 1 and token sort ratio >= 90 only. A mechanics check, not a sensitivity estimate."}


def _compare_frames(a: pd.DataFrame, b: pd.DataFrame, tol: float) -> tuple[bool, str]:
    if list(a.columns) != list(b.columns) or len(a) != len(b):
        return False, f"shape/columns differ {a.shape} vs {b.shape}"
    a = a.sort_values(list(a.columns)).reset_index(drop=True) if len(a) else a
    b = b.sort_values(list(b.columns)).reset_index(drop=True) if len(b) else b
    for col in a.columns:
        x, y = a[col], b[col]
        if pd.api.types.is_float_dtype(x) and pd.api.types.is_float_dtype(y):
            diff = np.nanmax(np.abs(x.to_numpy() - y.to_numpy())) if len(x) else 0.0
            if not (np.isnan(diff) or diff <= tol) or not (x.isna() == y.isna()).all():
                return False, f"{col}: max abs diff {diff}"
        else:
            if not x.astype(str).equals(y.astype(str)):
                return False, f"{col}: values differ"
    return True, "identical"


def determinism(cfg: Config) -> dict:
    from .analysis import analyze
    from .build import build

    tmp = Path(tempfile.mkdtemp(prefix="rae_rerun_"))
    data = copy.deepcopy(cfg.data)
    for k in ("processed", "tables", "figures", "workbooks"):
        data["paths"][k] = str(tmp / k)
    cfg2 = Config(root=cfg.root, data=data)
    old = os.environ.get("RAE_OFFLINE")
    os.environ["RAE_OFFLINE"] = "1"
    try:
        build(cfg2)
        analyze(cfg2)
    finally:
        if old is None:
            os.environ.pop("RAE_OFFLINE", None)
        else:
            os.environ["RAE_OFFLINE"] = old
    tol = float(cfg["analysis"]["proportion_tolerance"])
    results = {}
    for sub, pattern, reader in (("processed", "*.parquet", pd.read_parquet), ("tables", "*.csv", pd.read_csv)):
        for f in sorted((cfg.path(sub)).glob(pattern)):
            if f.name.startswith(("validation_", "recheck_")):
                continue
            g = tmp / sub / f.name
            if not g.exists():
                results[f"{sub}/{f.name}"] = "missing in rerun"
                continue
            ok, msg = _compare_frames(reader(f), reader(g), tol)
            results[f"{sub}/{f.name}"] = msg
    same = all(v == "identical" for v in results.values())
    shutil.rmtree(tmp, ignore_errors=True)
    return {"mode": "offline rerun of build and analyze from cached inputs", "tolerance_floats": tol, "files_compared": len(results),
            "all_identical": same, "differences": {k: v for k, v in results.items() if v != "identical"}}


def human_worksheet(cfg: Config) -> dict:
    """Worksheet for the independent human review. Columns for the reviewer are left blank."""
    from openpyxl import Workbook
    from openpyxl.styles import Font

    q = pd.read_csv(cfg.path("tables") / "review_queue.csv")
    led = pd.read_parquet(cfg.path("processed") / "occurrence_ledger.parquet")
    occ = pd.read_parquet(cfg.path("interim") / "occurrences.parquet")
    ids = pd.read_parquet(cfg.path("interim") / "occurrence_identifiers.parquet")
    flagged = q[q["claim_type"].isin(["retraction", "expression_of_concern", "reinstatement"]) | (q["first_arm_linked"] == "B")]
    rng = np.random.default_rng(int(cfg["analysis"]["bootstrap_seed"]))
    sample = []
    quota = {"verified_pubmed_record": 40, "no_identifier": 20, "doi_not_in_pubmed": 20, "ambiguous": 20}
    for cat, k in quota.items():
        pool = led[led["ledger_category"] == cat]["occurrence_id"].sort_values().to_numpy()
        pick = rng.choice(pool, size=min(k, len(pool)), replace=False)
        sample.extend((cat, x) for x in sorted(pick))
    srows = []
    occ_i = occ.set_index("occurrence_id")
    id_by = ids.groupby("occurrence_id")
    for cat, o in sample:
        g = id_by.get_group(o) if o in id_by.groups else pd.DataFrame(columns=["kind", "raw", "provenance"])
        srows.append({"stratum": cat, "occurrence_id": o, "review_link": f"https://pmc.ncbi.nlm.nih.gov/articles/{o.split('|')[0]}/",
                      "reference_label": occ_i.loc[o, "ref_label"], "reference_text": occ_i.loc[o, "ref_text"],
                      "parsed_identifiers": "; ".join(f"{k}={r} ({p})" for k, r, p in g[["kind", "raw", "provenance"]].values),
                      "pipeline_category": cat, "reviewer_parse_correct (Y/N)": "", "reviewer_category_correct (Y/N)": "", "reviewer_note": ""})
    path = cfg.root / "validation" / "human_validation_worksheet.xlsx"
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Instructions"
    for line in [
        "Independent review worksheet. Fill in the blank reviewer columns and leave the pipeline columns unchanged.",
        "Sheet 'Flagged claims': every retraction, expression of concern and reinstatement claim, and every link first made by the crosswalk.",
        "For each row open the status source (Retraction Watch record or PubMed notice) and the publisher notice, and record whether the identifier, claim type, notice date and timing class are correct.",
        "Sheet 'Parse sample': a stratified random sample (seed 20261007) of 100 reference occurrences. Compare the parsed identifiers with the reference as shown on the PMC page.",
        "Record disagreements in the note column. Do not edit the pipeline columns.",
    ]:
        ws.append([line])
    ws["A1"].font = Font(bold=True)
    ws.column_dimensions["A"].width = 160
    f = flagged.copy()
    for col in ["reviewer_identifier_correct (Y/N)", "reviewer_claim_type_correct (Y/N)", "reviewer_notice_date_correct (Y/N)",
                "reviewer_timing_correct (Y/N)", "reviewer_note"]:
        f[col] = ""
    from .outputs import _write_df

    _write_df(wb.create_sheet("Flagged claims"), f, wrap_cols=("reference_text", "citing_sentences"))
    _write_df(wb.create_sheet("Parse sample"), pd.DataFrame(srows), wrap_cols=("reference_text",))
    wb.save(path)
    return {"worksheet": _rel(path, cfg.root), "flagged_rows": len(f), "parse_sample_rows": len(srows)}


def validate(cfg: Config, include_determinism: bool = True) -> dict:
    res = {"run_utc": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")}
    res["software_tests"] = run_pytest(cfg)
    res["count_reconciliation"] = reconcile_counts(cfg)
    res["claim_reconciliation"] = reconcile_claims(cfg)
    res["timing_sql_vs_python"] = timing_equivalence(cfg)
    res["fuzzy_mechanics_check"] = fuzzy_recovery(cfg)
    res["human_review_worksheet"] = human_worksheet(cfg)
    if include_determinism:
        res["determinism"] = determinism(cfg)
    res["all_passed"] = bool(
        res["software_tests"]["passed"]
        and res["count_reconciliation"]["all_passed"]
        and res["claim_reconciliation"]["claims_checked"] == res["claim_reconciliation"]["claims_reconciled"]
        and res["timing_sql_vs_python"]["passed"]
        and (res.get("determinism", {"all_identical": True})["all_identical"])
    )
    out = cfg.path("tables") / "validation_report.json"
    out.write_text(json.dumps(res, indent=1, default=str))
    return res
