"""Check the extracted bundle's site over local HTTP: pages, links, assets, anchors, downloads.

Usage: python scripts/check_site.py <bundle_dir> <base_url> <out_json>
<bundle_dir> is the extracted outer bundle (containing site/ and handoff/);
<base_url> serves <bundle_dir>/site at its root.
"""

from __future__ import annotations

import hashlib
import json
import sys
import urllib.request
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

SLUG = "retraction-aware-evidence"


class Collector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs: list[str] = []
        self.ids: set[str] = set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        for k in ("href", "src"):
            if a.get(k):
                self.refs.append(a[k])
        if a.get("id"):
            self.ids.add(a["id"])


def fetch(url: str) -> tuple[int, bytes]:
    try:
        with urllib.request.urlopen(url, timeout=20) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, b""


def main(bundle: str, base: str, out: str) -> int:
    bundle_dir = Path(bundle)
    base = base.rstrip("/") + "/"
    start = urljoin(base, f"projects/{SLUG}/")
    pages = [start, urljoin(start, "report.html")]
    broken, broken_anchors, checked, anchors_checked = [], [], set(), 0
    page_ids: dict[str, set[str]] = {}
    for page in pages:
        status, body = fetch(page)
        if status != 200:
            broken.append({"url": page, "status": status})
            continue
        c = Collector()
        c.feed(body.decode("utf-8", errors="replace"))
        page_ids[page] = c.ids
        for ref in c.refs:
            if ref.startswith(("http://", "https://", "mailto:", "data:")):
                continue
            target = urljoin(page, ref)
            path_only = target.split("#")[0]
            if urlparse(target).netloc != urlparse(base).netloc:
                continue
            if path_only not in checked and path_only.startswith(base):
                checked.add(path_only)
                s, _ = fetch(path_only)
                if s != 200:
                    broken.append({"from": page, "ref": ref, "status": s})
            if "#" in ref:
                anchors_checked += 1
                frag = ref.split("#", 1)[1]
                tgt_page = path_only if path_only != page.split("#")[0] else page
                ids = page_ids.get(tgt_page)
                if ids is None:
                    s, b = fetch(tgt_page)
                    cc = Collector()
                    cc.feed(b.decode("utf-8", errors="replace"))
                    ids = page_ids[tgt_page] = cc.ids
                if frag and frag not in ids:
                    broken_anchors.append({"from": page, "ref": ref})
    meta = json.loads((bundle_dir / "handoff" / f"{SLUG}.json").read_text())
    downloads_ok = True
    for f in meta["public_files"]:
        if "/downloads/" not in f["path"]:
            continue
        rel = f["path"].split("site/", 1)[1]
        s, b = fetch(urljoin(base, rel))
        if s != 200 or len(b) != f["bytes"] or hashlib.sha256(b).hexdigest() != f["sha256"]:
            downloads_ok = False
            broken.append({"download": rel, "status": s})
    res = {"server": base, "pages": len(pages), "links_checked": len(checked), "broken": broken, "anchors_checked": anchors_checked,
           "broken_anchors": broken_anchors, "downloads_ok": downloads_ok}
    Path(out).write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))
    return 0 if not broken and not broken_anchors and downloads_ok else 1


if __name__ == "__main__":
    raise SystemExit(main(*sys.argv[1:4]))
