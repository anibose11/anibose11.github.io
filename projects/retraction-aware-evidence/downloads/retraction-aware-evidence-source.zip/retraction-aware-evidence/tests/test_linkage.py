"""End-to-end linkage on synthetic tables (fixtures only, never study data).

Covers: exact DOI matches, the expanded crosswalk, duplicated notices, a cited
notice DOI (notice/article swap), conflicting PMID relationships, a failed
request, PubMed relations, incomplete review dates and the six-month rule.
"""

from datetime import date
from pathlib import Path

import pandas as pd
import pytest

from rae.build import assign_works, run_variant, rw_for_db
from rae.config import Config, load_config
from rae.retraction_watch import load_notices

FIX = Path(__file__).parent / "fixtures"
S = lambda: pd.Series(dtype="string")


def _occ(occ_id, review):
    return {"occurrence_id": occ_id, "review_pmcid": review, "ref_id": occ_id, "ref_label": occ_id, "ref_position": 1, "citation_index": 1,
            "citation_tag": "fixture", "publication_type": "", "article_title": "", "source": "", "year": 2015, "volume": "", "fpage": "",
            "first_author": "", "ref_text": "", "text_mentions_retract": False, "text_mentions_withdrawn": False,
            "text_mentions_expression_of_concern": False, "text_mentions_erratum_or_correction": False}


@pytest.fixture(scope="module")
def result(tmp_path_factory):
    d = tmp_path_factory.mktemp("interim")
    occ = [_occ(f"o{i}", "R2" if i == 2 else "R1") for i in range(1, 13)]
    pd.DataFrame(occ).to_parquet(d / "occurrences.parquet", index=False)
    ids = [
        ("o1", "doi", "10.5555/fx.one", "tag"),
        ("o2", "doi", "10.5555/fx.one", "link"),
        ("o3", "pmid", "99000003", "tag"),          # crosswalk: record DOI is fx.three
        ("o4", "doi", "10.5555/fx.notice", "tag"),  # cites the notice of FX-1
        ("o5", "doi", "10.5555/fx.three", "tag"),   # duplicated notices FX-3a and FX-3b
        ("o6", "pmid", "99000006", "tag"),          # record 99000006 has DOI fx.six ...
        ("o6", "doi", "10.5555/fx.other", "tag"),   # ... but this DOI belongs to 99000007
        ("o7", "pmid", "99000008", "tag"),          # request failed
        ("o8", "pmid", "99000009", "tag"),          # PubMed RetractionIn relation
        ("o10", "pmid", "99000011", "tag"),         # Retracted Publication type, no linked notice
        ("o11", "pmid", "99000012", "tag"),         # not found
        ("o12", "doi", "10.5555/fx.nowhere", "tag"),
    ]
    rows = [{"occurrence_id": a, "kind": k, "raw": v, "normalized": v, "provenance": p} for a, k, v, p in ids]
    rows.append({"occurrence_id": "o9", "kind": "doi", "raw": "10/5555/broken", "normalized": None, "provenance": "tag"})
    pd.DataFrame(rows).astype({"normalized": "string"}).to_parquet(d / "occurrence_identifiers.parquet", index=False)
    pd.DataFrame({c: S() for c in ["pmcid", "pmid", "doi", "status", "errmsg"]}).to_parquet(d / "cited_pmcid_conversion.parquet", index=False)
    recs = pd.DataFrame(
        [
            {"pmid": "99000003", "has_retracted_pubtype": False, "notice_kind": ""},
            {"pmid": "99000006", "has_retracted_pubtype": False, "notice_kind": ""},
            {"pmid": "99000007", "has_retracted_pubtype": False, "notice_kind": ""},
            {"pmid": "99000009", "has_retracted_pubtype": True, "notice_kind": ""},
            {"pmid": "99000011", "has_retracted_pubtype": True, "notice_kind": ""},
        ]
    )
    for c in ["kind", "title", "journal", "pmcid", "first_author", "pubtypes", "elec_precision", "issue_precision"]:
        recs[c] = pd.Series([""] * len(recs), dtype="string")
    recs["year"] = pd.Series([2015] * len(recs), dtype="Int64")
    for c in ["elec_start", "elec_end", "issue_start", "issue_end"]:
        recs[c] = pd.Series([pd.NaT] * len(recs), dtype="datetime64[us]")
    recs.to_parquet(d / "cited_pubmed.parquet", index=False)
    pd.DataFrame({"pmid": ["99000003", "99000006", "99000007"], "doi": ["10.5555/fx.three", "10.5555/fx.six", "10.5555/fx.other"]}).to_parquet(d / "cited_pubmed_dois.parquet", index=False)
    pd.DataFrame({"pmid": ["99000009"], "reftype": ["RetractionIn"], "refsource": ["Fixture J. 2021"], "rel_pmid": ["99000010"]}).to_parquet(d / "cited_pubmed_relations.parquet", index=False)
    pd.DataFrame({"pmid": ["99000003", "99000006", "99000008", "99000009", "99000011", "99000012"],
                  "status": ["found", "found", "request_failed", "found", "found", "not_found"]}).to_parquet(d / "cited_pmid_status.parquet", index=False)
    pd.DataFrame({"doi": ["10.5555/fx.other", "10.5555/fx.nowhere", "10.5555/fx.one", "10.5555/fx.notice", "10.5555/fx.three"],
                  "status": ["verified", "not_found", "not_found", "not_found", "not_found"],
                  "pmid": ["99000007", None, None, None, None]}).to_parquet(d / "doi_pmid_search.parquet", index=False)
    notice = recs.iloc[:0].copy()
    notice = pd.concat([notice, pd.DataFrame([{"pmid": "99000010", "has_retracted_pubtype": False, "notice_kind": "retraction_notice"}])], ignore_index=True)
    notice["elec_start"] = pd.to_datetime(["2021-06-01"]).astype("datetime64[us]")
    notice["elec_end"] = notice["elec_start"]
    notice.to_parquet(d / "notice_pubmed.parquet", index=False)
    rdates = pd.DataFrame(
        [
            {"pmcid": "R1", "online_start": date(2020, 1, 15), "online_end": date(2020, 1, 15), "online_source": "fixture", "online_precision": "day",
             "issue_start": date(2020, 1, 1), "issue_end": date(2020, 12, 31), "issue_source": "fixture", "issue_precision": "year"},
            {"pmcid": "R2", "online_start": date(2019, 3, 1), "online_end": date(2019, 3, 31), "online_source": "fixture", "online_precision": "month",
             "issue_start": date(2019, 3, 1), "issue_end": date(2019, 3, 31), "issue_source": "fixture", "issue_precision": "month"},
        ]
    )
    rw = load_notices(FIX / "fixture_rw.csv")
    base = load_config()
    cfg = Config(root=base.root, data=base.data)
    res = run_variant(cfg, rw_for_db(rw), rdates, "all", d)
    res["works_map"], res["works"] = assign_works(res["ledger"], res["expanded_ids"], res["occ_ids"])
    return res


def _cat(res, occ):
    return res["ledger"].set_index("occurrence_id").loc[occ, "ledger_category"]


def _claims(res, arm, occ=None):
    c = res["claims"][res["claims"]["arm"] == arm]
    return c if occ is None else c[c["occurrence_id"] == occ]


def test_ledger_categories(result):
    assert _cat(result, "o3") == "verified_pubmed_record"
    assert _cat(result, "o6") == "ambiguous"
    assert _cat(result, "o7") == "endpoint_unavailable"
    assert _cat(result, "o9") == "malformed_identifier_only"
    assert _cat(result, "o11") == "record_not_found"
    assert _cat(result, "o12") == "doi_not_in_pubmed"
    assert _cat(result, "o1") == "doi_not_in_pubmed"


def test_exact_doi_arm(result):
    a = _claims(result, "A")
    assert set(a["occurrence_id"]) == {"o1", "o2", "o5"}
    assert set(_claims(result, "A", "o1")["notice_key"]) == {"FX-1"}


def test_crosswalk_adds_link(result):
    b3 = _claims(result, "B", "o3")
    assert list(b3["notice_key"]) == ["FX-3a", "FX-3b"] or set(b3["notice_key"]) == {"FX-3a", "FX-3b"}
    assert set(b3["match_basis"]) == {"ncbi_crosswalk"}
    assert _claims(result, "A", "o3").empty


def test_duplicated_notices_one_work(result):
    o5 = _claims(result, "B", "o5")
    assert len(o5) == 2  # two notices kept as two claims
    wm = result["works_map"].set_index("occurrence_id")
    assert wm.loc["o5", "work_id"] == wm.loc["o3", "work_id"]  # same study through DOI and crosswalk


def test_cited_notice_not_counted_as_article(result):
    assert _claims(result, "B", "o4").empty
    cn = result["cited_notices"]
    assert set(cn.loc[cn["occurrence_id"] == "o4", "notice_key"]) == {"FX-1"}


def test_failed_request_is_not_no_event(result):
    assert _claims(result, "C", "o7").empty
    assert _cat(result, "o7") == "endpoint_unavailable"


def test_pubmed_relation_and_pubtype(result):
    c8 = _claims(result, "C", "o8")
    assert set(c8["notice_key"]) == {"99000010"}  # RetractionIn suppresses the pubtype-only claim
    assert c8["notice_date_start"].iloc[0] == pd.Timestamp("2021-06-01")
    assert c8["timing_primary"].iloc[0] == "after_review"
    c10 = _claims(result, "C", "o10")
    assert set(c10["notice_key"]) == {"pubtype:99000011"}
    assert c10["timing_primary"].iloc[0] == "indeterminate"  # no notice date


def test_timing_and_six_month(result):
    o1 = _claims(result, "A", "o1").iloc[0]
    assert o1["timing_primary"] == "before_review"
    o2 = _claims(result, "A", "o2").iloc[0]  # review R2 is only known to the month
    assert o2["timing_primary"] == "indeterminate"
    o5 = _claims(result, "B", "o5").iloc[0]  # notice 2019-12-01, review 2020-01-15
    assert o5["timing_primary"] == "before_review"
    assert o5["timing_six_month"] == "within_lead_window"


def test_ambiguous_has_no_work(result):
    wm = result["works_map"].set_index("occurrence_id")
    assert "o6" not in wm.index or pd.isna(wm.loc["o6", "work_id"])
