"""Reference-list parsing on the synthetic JATS fixture."""

from pathlib import Path

from rae.jats import citation_contexts, parse_references, parse_review_meta, parse_xml

FIX = Path(__file__).parent / "fixtures" / "fixture_review.xml"


def _refs():
    root = parse_xml(FIX.read_bytes())
    return root, parse_references(root, "PMC9900001")


def test_review_meta_dates_and_license():
    root, _ = _refs()
    meta = parse_review_meta(root)
    assert meta.pmcid == "PMC9900001" and meta.pmid == "99000100" and meta.doi == "10.5555/fx.review"
    assert meta.epub.precision == "day" and meta.epub.start.isoformat() == "2020-01-15"
    assert meta.issue.precision == "year"
    assert meta.license_href.endswith("/by/4.0/")


def test_occurrence_units():
    _, refs = _refs()
    ids = [r["occurrence_id"] for r in refs]
    # R3 has citation-alternatives (one occurrence), R5 holds two citations (two
    # occurrences), and the sub-article reference is excluded.
    assert ids == ["PMC9900001|R1|1", "PMC9900001|R2|1", "PMC9900001|R3|1", "PMC9900001|R4|1", "PMC9900001|R5|1", "PMC9900001|R5|2"]


def test_identifier_provenance():
    _, refs = _refs()
    by = {r["occurrence_id"]: {(k, n, p) for k, _, n, p in r["identifiers"]} for r in refs}
    assert by["PMC9900001|R1|1"] == {("doi", "10.5555/fx.one", "tag"), ("pmid", "99000001", "tag")}
    assert by["PMC9900001|R2|1"] == {("doi", "10.5555/fx.two", "link"), ("pmid", "99000002", "text")}
    assert by["PMC9900001|R3|1"] == {("doi", "10.5555/fx.three", "tag")}
    # tagged DOI followed directly by a tagged PMID must not produce a glued DOI
    assert by["PMC9900001|R4|1"] == {("doi", "10.5555/fx.four", "tag"), ("pmid", "99000004", "tag")}
    assert by["PMC9900001|R5|1"] == set()
    assert by["PMC9900001|R5|2"] == {("doi", "10.5555/fx.five", "text")}


def test_text_flags():
    _, refs = _refs()
    r4 = [r for r in refs if r["ref_id"] == "R4"][0]
    assert r4["text_mentions_retract"] is True


def test_citation_contexts_with_superscripts():
    root, _ = _refs()
    ctx = citation_contexts(root)
    assert ctx["R1"] == ["The first trial reported a benefit.1"]
    assert ctx["R2"] == ["A later analysis disagreed [2]."]
    assert ctx["R3"] == ctx["R4"] == ["The retracted trial was excluded.3,4"]


def test_structured_citation_text_is_spaced():
    _, refs = _refs()
    r1 = [r for r in refs if r["ref_id"] == "R1"][0]
    assert "Alpha A" in r1["ref_text"] and "Tagged identifiers" in r1["ref_text"]
    assert "AlphaA" not in r1["ref_text"]


def test_retracted_label_detected_after_author_names():
    from rae.jats import parse_xml, parse_references
    xml = (b"<article><back><ref-list><ref id='X'><element-citation><person-group><name><surname>Jin</surname>"
           b"<given-names>R</given-names></name></person-group><article-title>Retracted: A fixture</article-title>"
           b"<year>2019</year></element-citation></ref></ref-list></back></article>")
    refs = parse_references(parse_xml(xml), "PMC9900002")
    assert refs[0]["text_mentions_retract"] is True
    assert refs[0]["ref_text"].startswith("Jin R Retracted")
