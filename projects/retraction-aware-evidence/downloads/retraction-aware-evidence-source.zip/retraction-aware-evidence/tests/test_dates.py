"""Incomplete dates and interval timing (fixtures only)."""

from datetime import date

from rae.dates import DateInterval, from_medline_date, from_parts, from_rw, timing


def test_parts_precision():
    assert from_parts("2019", "3", "5").precision == "day"
    m = from_parts("2019", "Feb", None)
    assert (m.start, m.end, m.precision) == (date(2019, 2, 1), date(2019, 2, 28), "month")
    y = from_parts("2019")
    assert (y.start, y.end, y.precision) == (date(2019, 1, 1), date(2019, 12, 31), "year")
    assert from_parts(None).precision == "unknown"
    assert from_parts("2019", "Spring").precision == "year"
    assert from_parts("2019", "2", "30").precision == "month"  # invalid day falls back to the month


def test_medline_dates():
    a = from_medline_date("2019 Jan-Feb")
    assert (a.start, a.end) == (date(2019, 1, 1), date(2019, 2, 28))
    b = from_medline_date("2018-2019")
    assert (b.start, b.end) == (date(2018, 1, 1), date(2019, 12, 31))
    assert from_medline_date("").precision == "unknown"


def test_rw_dates():
    d = from_rw("3/5/2019 0:00")
    assert d.start == d.end == date(2019, 3, 5)
    assert from_rw("").precision == "unknown"
    assert from_rw("13/45/2019 0:00").precision == "unknown"


def test_timing_intervals():
    notice = from_rw("3/5/2019 0:00")
    assert timing(notice, from_parts("2020", "1", "15")) == "before_review"
    assert timing(notice, from_parts("2019", "3")) == "indeterminate"  # month interval contains the notice day
    assert timing(notice, from_parts("2019")) == "indeterminate"
    assert timing(notice, from_parts("2018", "12", "31")) == "after_review"
    assert timing(notice, DateInterval(None, None, "unknown")) == "indeterminate"
    assert timing(DateInterval(None, None, "unknown"), from_parts("2020")) == "indeterminate"
    same_day = from_parts("2019", "3", "5")
    assert timing(notice, same_day) == "indeterminate"


def test_six_month_rule():
    notice = from_rw("12/1/2019 0:00")
    review = from_parts("2020", "1", "15")
    assert timing(notice, review) == "before_review"
    assert timing(notice, review, lead_days=183) == "within_lead_window"
    assert timing(from_rw("1/1/2019 0:00"), review, lead_days=183) == "before_review"
