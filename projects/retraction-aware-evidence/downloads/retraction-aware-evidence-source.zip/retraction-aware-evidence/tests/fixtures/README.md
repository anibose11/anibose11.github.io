# Test fixtures

Everything in this folder is synthetic and exists only to test software
mechanics. None of it is study data and none of it is used in any reported
result.

- Identifiers use the DOI prefix `10.5555/fx.` and PMIDs from `99000001`
  upward so they cannot be mistaken for real records.
- Retraction Watch style records use the record IDs `FX-...`.
- `fixture_review.xml` is a hand-written JATS file that exercises the parser.
- `fixture_bibliography.csv` and `fixture_rw.csv` drive the `rae demo`
  command.
