"""The bibliography audit on fixtures (offline): mechanics only, not study data."""

from pathlib import Path

import openpyxl

from rae.bibliography import audit_file, parse_csv, parse_ris
from rae.config import load_config

FIX = Path(__file__).parent / "fixtures"


def test_offline_fixture_audit(tmp_path):
    cfg = load_config()
    out = tmp_path / "audit.xlsx"
    res = audit_file(cfg, str(FIX / "fixture_bibliography.csv"), str(out), "2020-01-15", offline=True, rw_csv=FIX / "fixture_rw.csv")
    assert res["references"] == 6
    assert res["status_claims"] == 5  # FX-1, FX-2, FX-3a, FX-3b, FX-4
    assert res["ledger"] == {"doi_not_in_pubmed": 4, "not_looked_up": 1, "no_identifier": 1}
    assert res["cited_notices"] == 1  # reference 5 cites the FX-1 notice DOI
    wb = openpyxl.load_workbook(out)
    assert {"Read me", "Status claims", "Coverage ledger", "Cited notices"} <= set(wb.sheetnames)


def test_ris_parsing(tmp_path):
    ris = tmp_path / "x.ris"
    ris.write_text("TY  - JOUR\nTI  - A fixture\nPY  - 2015\nDO  - https://doi.org/10.5555/FX.ONE\nN1  - PMID: 99000001\nER  - \n"
                   "TY  - JOUR\nTI  - Another\nUR  - https://pubmed.ncbi.nlm.nih.gov/99000004/\nER  - \n")
    occ, ids = parse_ris(ris)
    assert len(occ) == 2
    got = {(k, n, p) for k, n, p in ids[["kind", "normalized", "provenance"]].itertuples(index=False)}
    assert ("doi", "10.5555/fx.one", "tag") in got and ("pmid", "99000001", "text") in got and ("pmid", "99000004", "link") in got


def test_csv_requires_identifier_column(tmp_path):
    p = tmp_path / "bad.csv"
    p.write_text("foo,bar\n1,2\n")
    try:
        parse_csv(p)
    except ValueError:
        return
    raise AssertionError("expected ValueError")
