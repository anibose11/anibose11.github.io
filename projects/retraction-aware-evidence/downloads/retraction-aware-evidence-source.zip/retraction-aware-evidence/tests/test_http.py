"""Failed requests, error pages and caching (mock transport, no network)."""

import httpx
import pytest

from rae.http import CachedClient, FetchError, looks_like_json, looks_like_xml


@pytest.fixture(autouse=True)
def online_by_default(monkeypatch):
    # The tests set offline mode themselves, so a shell RAE_OFFLINE must not leak in.
    monkeypatch.delenv("RAE_OFFLINE", raising=False)


def test_failed_request_raises_after_retries(tmp_path):
    calls = []

    def handler(request):
        calls.append(1)
        return httpx.Response(503, text="busy")

    c = CachedClient(tmp_path, min_interval=0, max_attempts=3, transport=httpx.MockTransport(handler), sleep=lambda s: None)
    with pytest.raises(FetchError):
        c.request("GET", "https://example.test/x")
    assert len(calls) == 3


def test_error_page_with_200_is_rejected_and_not_cached(tmp_path):
    def handler(request):
        return httpx.Response(200, text="<!DOCTYPE html><html><body>Error</body></html>", headers={"content-type": "text/html"})

    c = CachedClient(tmp_path, min_interval=0, max_attempts=2, transport=httpx.MockTransport(handler), sleep=lambda s: None)
    with pytest.raises(FetchError):
        c.request("GET", "https://example.test/x", validate=looks_like_xml)
    assert not list(tmp_path.glob("*/*.gz"))


def test_rate_limit_json_rejected():
    assert not looks_like_json(b'{"error":"API rate limit exceeded","count":"11"}', "application/json")
    assert looks_like_json(b'{"esearchresult": {}}', "application/json")


def test_cache_hit_and_offline(tmp_path, monkeypatch):
    n = []

    def handler(request):
        n.append(1)
        return httpx.Response(200, text="<?xml version='1.0'?><a/>")

    c = CachedClient(tmp_path, min_interval=0, transport=httpx.MockTransport(handler), sleep=lambda s: None)
    r1 = c.request("GET", "https://example.test/y", params={"q": "1", "email": "x@example.test"}, validate=looks_like_xml)
    r2 = c.request("GET", "https://example.test/y", params={"q": "1"}, validate=looks_like_xml)
    assert len(n) == 1 and r2.from_cache and r1.sha256 == r2.sha256
    log = (tmp_path / "request_log.jsonl").read_text()
    assert "x@example.test" not in log  # email never logged or cached
    monkeypatch.setenv("RAE_OFFLINE", "1")
    c2 = CachedClient(tmp_path, min_interval=0, transport=httpx.MockTransport(handler))
    with pytest.raises(FetchError):
        c2.request("GET", "https://example.test/not-cached")
