"""DOI punctuation, resolver prefixes and identifier parsing (fixtures only)."""

import pytest

from rae.identifiers import doi_from_url, dois_in_text, normalize_doi, normalize_pmcid, normalize_pmid


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("10.5555/fx.one", "10.5555/fx.one"),
        ("10.5555/FX.ONE", "10.5555/fx.one"),
        ("https://doi.org/10.5555/FX.ONE.", "10.5555/fx.one"),
        ("http://dx.doi.org/10.5555/fx.one", "10.5555/fx.one"),
        ("doi.org/10.5555/fx.one", "10.5555/fx.one"),
        ("doi:10.5555/fx.one", "10.5555/fx.one"),
        ("DOI: 10.5555/fx.one;", "10.5555/fx.one"),
        ("doi: https://doi.org/10.5555/fx.one", "10.5555/fx.one"),
        (" 10.5555/fx.one ", "10.5555/fx.one"),
        ("10.5555/fx.one).", "10.5555/fx.one"),
        ("10.5555/fx.one,", "10.5555/fx.one"),
        # balanced parentheses and angle brackets belong to the DOI (SICI style)
        ("10.1002/(SICI)1097-0258(19980430)17:8<857::AID-SIM777>3.0.CO;2-E", "10.1002/(sici)1097-0258(19980430)17:8<857::aid-sim777>3.0.co;2-e"),
        # percent-encoding as found in Retraction Watch
        ("10.1002/1096-9098(200007)74:3%3C201::AID-JSO8%3E3.0.CO;2-5", "10.1002/1096-9098(200007)74:3<201::aid-jso8>3.0.co;2-5"),
    ],
)
def test_normalize_doi_ok(raw, expected):
    res = normalize_doi(raw)
    assert res.status == "ok"
    assert res.normalized == expected
    assert res.raw == raw


@pytest.mark.parametrize("raw", ["xx10.1007/978-3-030-00524-5_9", "10/1093/bioinformatics/btad073", "101177/135965350701200214", "smw-12785", "10.12/x"])
def test_normalize_doi_malformed_is_not_repaired(raw):
    res = normalize_doi(raw)
    assert res.status == "malformed"
    assert res.normalized is None


@pytest.mark.parametrize("raw", ["", "unavailable", "Unavailable", None, "  "])
def test_normalize_doi_empty(raw):
    assert normalize_doi(raw).status == "empty"


def test_pmid_and_pmcid():
    assert normalize_pmid("PMID: 0099000001") == "99000001"
    assert normalize_pmid("0") is None
    assert normalize_pmid("12a") is None
    assert normalize_pmcid("pmc9900001") == "PMC9900001"
    assert normalize_pmcid("PMC9900001.2") == "PMC9900001"
    assert normalize_pmcid("9900001") == "PMC9900001"
    assert normalize_pmcid("PMCX") is None


def test_dois_in_text_and_url():
    txt = "See doi:10.5555/fx.one and https://doi.org/10.5555/fx.two."
    assert dois_in_text(txt) == ["10.5555/fx.one", "10.5555/fx.two."]
    assert normalize_doi(dois_in_text(txt)[1]).normalized == "10.5555/fx.two"
    assert doi_from_url("https://dx.doi.org/10.5555/fx.one") == "10.5555/fx.one"
    assert doi_from_url("https://example.org/10.5555/fx.one") is None


def test_notice_doi_is_not_article_doi():
    # A retraction notice DOI normalizes like any DOI. Telling it apart is the
    # linkage layer's job (see test_linkage.py::test_cited_notice_not_counted_as_article).
    assert normalize_doi("10.5555/fx.notice").normalized != normalize_doi("10.5555/fx.one").normalized


def test_pubmed_notice_types_current_and_legacy():
    from rae.pubmed import NOTICE_PUBTYPES, RETRACTED_PUBTYPE

    assert NOTICE_PUBTYPES["Retraction Notice"] == "retraction_notice"
    assert NOTICE_PUBTYPES["Retraction of Publication"] == "retraction_notice"
    assert RETRACTED_PUBTYPE == "Retracted Publication"
    assert RETRACTED_PUBTYPE not in NOTICE_PUBTYPES
