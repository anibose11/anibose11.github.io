# Tableau import and interaction specification

No Tableau workbook was built or tested. These are verified flat tables and the rules a workbook must follow.

## Files (`outputs/tableau/`)

| File | Row grain | Measures | Denominator |
|---|---|---|---|
| `tableau_claims.csv` | one status claim: occurrence x source x notice (arm C) | count rows, count distinct `occurrence_id` and `review_pmcid` | `tableau_denominators_by_year.csv` |
| `tableau_ledger_by_year.csv` | review year x ledger category | `occurrences` | `year_total_occurrences` in the same row |
| `tableau_denominators_by_year.csv` | review year | `reviews`, `occurrences` | itself |
| `tableau_headline_intervals.csv` | one precomputed proportion | `estimate`, `ci_low`, `ci_high` | `denominator` |

Units: reference occurrences, reviews and notices are different units. Never sum claims to get studies, because one occurrence can carry several claims (two sources, or several notices).

## Allowed interactions

- Filter `tableau_claims.csv` by `claim_type`, `source`, `timing_primary`, `match_confidence`, `review_year`. Show counts of distinct `occurrence_id`, not row counts, when the question is "how many references".
- A share by review year is `COUNTD(occurrence_id)` from the claims file over `occurrences` from the denominators file for the same year. Do not compute shares across a filter on `source` or `claim_type` against the all-occurrence denominator without labeling the numerator's filter.
- Proportions with intervals come only from `tableau_headline_intervals.csv`. They are review-level cluster bootstrap intervals and cannot be recomputed from filtered rows. Show them as fixed marks with error bars, and do not let filters change them.

## Suppression

None. All values are counts of public bibliographic metadata, with no person-level data. Small counts (for example 4 Retraction Watch only retraction occurrences) are shown as counts, without percentages on their own.

## Suggested views

1. Coverage ledger by review year (stacked bars of `occurrences`, labeled with `year_total_occurrences`).
2. Claims by type and source (bars of distinct occurrences, color = source, legend always shown).
3. Timing by claim type (bars of claims by `timing_primary`, with indeterminate in a neutral gray).
