# Bibliography file formats for `rae audit`

## CSV

UTF-8 with a header row. Column names are case-insensitive. At least one of `doi`, `pmid`, `pmcid` or `title` must be present.

| Column | Content | Notes |
|---|---|---|
| `id` | Your reference number | Optional. Integers are kept as labels |
| `doi` | DOI in any common form | `10.x/y`, `doi:10.x/y`, `https://doi.org/10.x/y` are all accepted, and the original is kept |
| `pmid` | PubMed ID | Leading `PMID:` and zero padding are accepted |
| `pmcid` | PMC ID | With or without the `PMC` prefix |
| `title`, `year`, `first_author`, `source` | Bibliographic fields | Used for display and the title queue only |

Identifiers in these columns are treated as tagged. Identifiers found elsewhere in a row are not used.

## RIS

Standard two-letter tags, records ending with `ER  -`.

- `DO` is read as a tagged DOI.
- `UR`, `L1`, `L2` links to doi.org or PubMed are read as link identifiers.
- `PMID:` and `PMCID:` strings anywhere in the record are read as free-text identifiers.
- `TI`/`T1` title, `PY`/`Y1`/`DA` year, `AU`/`A1` first author, `T2`/`JO`/`JF` source.

## Output

The audit writes an Excel workbook with four sheets:

- a read-me sheet with the snapshot, whether NCBI lookups ran and the review date used
- status claims, one row per reference and claim, with source, notice key and date, timing and match confidence
- a coverage ledger for every reference
- references that cite a notice

Supply `--review-date` (the date your document was first public) to get timing classes. Without it, timing is indeterminate.
