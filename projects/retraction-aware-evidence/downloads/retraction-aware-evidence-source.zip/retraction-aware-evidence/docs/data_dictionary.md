# Data dictionary and lineage

Every analysis column traces to a source field. Keys are stable across reruns. Missing values are never filled. The state columns say why a value is absent.

## Value states

| State | Meaning | Where it appears |
|---|---|---|
| zero | Counted and none found | counts in `outputs/tables/*.csv` |
| absent | The source has no such field or value (for example no notice PMID in a PubMed relation) | `notice_date_source = notice_record_unavailable` |
| unavailable | A request failed after retries | `ledger_category = endpoint_unavailable`, `failure_detail` |
| not evaluated | Not looked up (offline bibliography audits only) | `ledger_category = not_looked_up` |
| inapplicable | The question does not apply (for example reinstatement for PubMed) | no row is created |
| suppressed | Not used: the data are public bibliographic metadata | none |

## Sources to interim tables (`data/interim/`)

| Table | Grain and key | Source fields |
|---|---|---|
| `frame_manifest.csv` | PubMed record, `pmid` | ESearch `idlist`, `selection_key` = SHA-256(salt + PMID), `selection_rank`, `selected` |
| `review_retrieval.csv` | selected review, `pmid` | PubMed `ArticleIdList/pmc`, PMC cloud JSON (`pmcid`, `version`, `license_code`, `is_pmc_openaccess`, `is_manuscript`, `is_retracted`, `xml_url` with MD5), local SHA-256 |
| `reviews.parquet` | review, `pmcid` | JATS `article-id`, `article-title`, `journal-title`, `pub-date` (all types kept in `pub_dates_raw`), `license/@xlink:href` |
| `review_pubmed.parquet` | review, `pmid` | PubMed `ArticleDate[@DateType=Electronic]`, `JournalIssue/PubDate`, `PublicationType` |
| `occurrences.parquet` | reference occurrence, `occurrence_id` = `PMCID|ref id|citation index` | JATS `ref/@id`, `label`, the `element-citation` or `mixed-citation` children (`article-title`, `source`, `year`, `volume`, `fpage`, first `surname`), full text and lexical flags |
| `occurrence_identifiers.parquet` | identifier string, (`occurrence_id`, `kind`, `raw`, `provenance`) | `pub-id[@pub-id-type=doi|pmid|pmcid]` (tag), `ext-link` or `uri` (link), untagged citation text (text). `normalized` follows `identifiers.py` |
| `citation_contexts.parquet` | (`review_pmcid`, `ref_id`, `sentence_index`) | body `p` text around `xref[@ref-type=bibr]/@rid` |
| `cited_pmcid_conversion.parquet` | cited PMCID | PMC ID Converter `pmid`, `doi`, `status` |
| `cited_pubmed.parquet` | PubMed record, `pmid` | `ArticleTitle`, journal, `pmc`, first author, `PublicationType` list, `ArticleDate`, `PubDate` (as intervals) |
| `cited_pubmed_dois.parquet` | (`pmid`, `doi`) | `ArticleIdList/ArticleId[@IdType=doi]`, `ELocationID[@EIdType=doi]` |
| `cited_pubmed_relations.parquet` | relation | `CommentsCorrections/@RefType`, `RefSource`, `PMID` |
| `cited_pmid_status.parquet` | PMID | found / not_found / request_failed |
| `doi_pmid_search.parquet` | (`doi`, `pmid`) | ESearch `"<doi>"[aid]` hits, accepted as `verified` only when the fetched record carries the same DOI |
| `notice_pubmed.parquet` | notice record, `pmid` | as `cited_pubmed` for PMIDs named in status relations |

Retraction Watch columns are mapped in `retraction_watch.py`:

- `Record ID` becomes `rw_record_id`.
- `RetractionNature` becomes `rw_nature` and `claim_type`.
- `RetractionDate` becomes `notice_date_start` and `notice_date_end` (one day).
- `RetractionDOI` and `RetractionPubMedID` become `notice_doi` and `notice_pmid`.
- `OriginalPaperDOI` and `OriginalPaperPubMedID` become `original_doi` and `original_pmid`.
- `OriginalPaperDate` becomes `original_year`.
- `Title`, `Author` and `Journal` are kept for the title queue.

## Processed tables (`data/processed/`)

| Table | Grain | Built by |
|---|---|---|
| `occurrence_ledger.parquet` | reference occurrence (1:1 with occurrences) | `sql/01` to `sql/03`, with `work_id` from union-find in `build.py` |
| `claims.parquet` | (arm, occurrence, source, notice, claim type) | `sql/04` and `sql/05`. One row per claim, never one per "worst" label |
| `rw_identifier_agreement.parquet` | arm B claim | `sql/04` |
| `cited_notices.parquet` | (occurrence, source, notice) | `sql/04` |
| `works.parquet` | unique cited work | union-find over verified identifiers of unambiguous occurrences |
| `fuzzy_review_queue.parquet` | candidate pair | `fuzzy.py`; never joined to claims |
| `review_dates.parquet` | review | JATS epub, then PubMed electronic date, then issue date |
| `*_tagged_only.parquet` | as above, tagged identifiers only | sensitivity S1 |

## Join cardinality checks

- Ledger rows equal occurrence rows, and `occurrence_id` is unique (`build.run_variant`, `validate.reconcile_counts`).
- `review_dates` has one row per review (`check_unique`), and reviews join PubMed review records one to one (`validate="one_to_one"`).
- Claims are unique on (arm, occurrence, source, notice key, claim type, source label).
- Retraction Watch `Record ID` is unique in the snapshot.
- Arm A Retraction Watch claims are a subset of arm B, and arm C Retraction Watch claims equal arm B.
