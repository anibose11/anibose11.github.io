# Implementation change log

Changes to code after the first full build, with their effect. Analysis-plan changes are recorded separately as amendments in `docs/analysis_plan.md`.

| Time (UTC) | Change | Found by | Effect on results |
|---|---|---|---|
| 2026-10-07T10:36Z | PubMed notice publication type "Retraction Notice" recognized (plan amendment A3) | Reconciling the cited-notice table | Cited-notice table and S5 only |
| 2026-10-07T10:58Z | Offline bibliography audits label PMIDs that were never looked up as `not_looked_up` instead of "no PubMed record" | Fixture demo | None for the study (every PMID was looked up) |
| 2026-10-07T11:06Z | Citation text is assembled with a space at every element boundary, so structured citations no longer run author names and titles together | Inspecting the review queue workbook | Reference text display, the lexical "retract" flag, and identifier mining from untagged citation text. The full pipeline was rerun |
| 2026-10-07T20:47Z | Added `rae recheck`: flagged claims and the parse sample re-checked against freshly retrieved PubMed and Crossref records and PMC plain text | Final verification before submission | None on results. The manuscript's description of one DOI pair was corrected (the reference used the Crossref-registered DOI and the status sources list its alias) |
| 2026-10-07T20:55Z | Figures exported at 300 dpi and as vector PDF, submission package added to the bundle, declarations and title page finalized | Journal formatting | None on results |
| 2026-10-07T21:10Z | Plain-language edit of the manuscript, report, project page, documentation and code comments | Author's review | None on results |
| 2026-10-07T21:25Z | HTTP tests clear `RAE_OFFLINE` before running, so a shell setting cannot make them fail | Validation run with `RAE_OFFLINE=1` | None on results |
| 2026-10-07T21:40Z | Report stylesheet removes the browser's default side margin on figures, which pushed tables 24 px past a 375 px screen | Mobile check of the extracted bundle | None on results |
| 2026-10-07T21:55Z | Packaging split into three files: the portfolio bundle (site and handoff only), a journal submission package and a DOI deposit package, with a guide to what goes where. Journal-only text is kept outside the public archive | Author's standing instructions for the project series | None on results |
