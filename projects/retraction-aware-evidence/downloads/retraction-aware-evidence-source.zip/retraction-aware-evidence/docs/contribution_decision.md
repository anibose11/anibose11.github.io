# Contribution decision

Written 2026-10-07T09:44Z, before the review corpus was retrieved and before any reference was linked to a status source. The only data seen at this point were the Retraction Watch field distribution (record counts by `RetractionNature`, checked while validating the download) and the size of the PubMed frame (7,993 records).

## Who could use the output

A research analyst or information specialist who maintains the evidence table behind a systematic review or meta-analysis in cardiometabolic medicine. The same check is useful to review authors just before submission or when planning an update, and to editorial staff who run reference checks.

## What decision it supports

Which cited studies need a person to look at their post-publication status (retraction, expression of concern, correction, reinstatement), and whether the notice was already public when the review first appeared online or was issued afterwards. The first case is a question about the review's search and screening; the second is an evidence-maintenance trigger. Neither case says anything about whether the review's conclusions hold.

## Narrow unresolved question

Published work on retracted studies in evidence syntheses mostly starts from known retracted items and searches forward for citing reviews (Avenell et al. 2019; Kataoka et al. 2022; Brown et al. 2022; Xu et al. 2025), or screens citing papers with a tool built on Crossref and Retraction Watch data (Graña Possamai et al. 2025, using the Feet of Clay Detector). Reference managers such as Zotero match DOIs and PMIDs against Retraction Watch for retractions only. Separate work compares retraction indexing across databases (Sebo et al. 2026; Salami, McCumber and Schneider, preprint v4 2026).

What is less well measured is the backward, reference-list view that an analyst actually has: starting from a review's own reference list, how much of it can be checked at all, and how much the answer depends on (1) which identifiers are used, (2) which status source is consulted, and (3) how precise the dates are. The question for this project is:

> In a fixed, deterministically drawn cohort of open-access cardiometabolic systematic reviews and meta-analyses, how do identifier coverage, status-source coverage and date precision change the set of cited studies that a reference audit flags, and how often is the timing of a flagged notice relative to the review determinate?

## Comparator

An exact-DOI-only match of each reference against the frozen Retraction Watch snapshot. This is the simplest check an analyst can run from a DOI list. The comparison arms are:

1. exact DOI only, Retraction Watch only;
2. verified expanded identifiers (DOI, PMID, PMCID and NCBI-verified DOI/PMID crosswalks), Retraction Watch only;
3. arm 2 plus PubMed's own update relations (`CommentsCorrections` and the "Retracted Publication" publication type).

Crossref and Retraction Watch are one integrated source since 2023, and PubMed relations are partly fed by the same publisher notices, so agreement between arm 3 sources is reported as overlap and never as independent confirmation.

## Estimand

Reference-occurrence-level proportions in the sampled cohort (one row per review-reference occurrence), with review-level cluster bootstrap intervals. The target frame is PubMed records retrieved by the prespecified query: PubMed publication type Systematic Review or Meta-Analysis, diabetes, obesity or heart failure by MeSH or title, publication date 2015 through 2025, PubMed's "pubmed pmc open access" filter. Unique cited works and notices are reported as separate units.

## What counts as a useful negative result

- If the expanded crosswalk links few or no additional flagged studies, DOI-only checking is adequate for this corpus and the remaining gap sits in references without any identifier. That is worth knowing.
- If no reference in the cohort links to a retraction, the coverage and chronology ledger is still the result. The disease scope and date window will not be changed after seeing the hit count.
- If most timing classifications are indeterminate, that is a finding about date precision in the sources, not a failure of the audit.

## How the work is framed

This is not the first study of retracted work in systematic reviews, and the tool is not the first to match references against Retraction Watch. The work is framed as a reusable, status-type-aware and time-aware reference audit tool, with an empirically measured coverage gap in one clinical domain. Its specific additions are: a backward audit from genuine JATS reference lists; a ledger that keeps "no identifier", "endpoint unavailable", "ambiguous identifiers", "record not found" and "verified record with no recorded event" apart; separate handling of retraction, correction, expression of concern and reinstatement claims with each source's date; and interval-based timing that admits indeterminacy. It does not estimate effects on pooled results, does not judge any study or review, and makes no clinical claims.
