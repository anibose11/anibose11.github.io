# Literature and software search

Run on 2026-10-07 (UTC) before any linkage result existed. Raw search responses, PubMed summaries and the candidate records are saved under `data/raw/literature_search/` (`pubmed_searches.json` holds each query, its translation, count, returned PMIDs and run time).

## PubMed searches (E-utilities, `db=pubmed`)

| ID | Query | Count | Purpose |
|---|---|---|---|
| S1 | `(retract*[Title]) AND ("systematic review*"[Title] OR "meta-analys*"[Title] OR "evidence synthes*"[Title] OR guideline*[Title])` | 1,313 | Studies of retracted work in evidence syntheses. Most hits are retraction notices for individual reviews or unrelated uses of "retraction" (dentistry). Screened by title. |
| S2 | `(retract*[Title/Abstract]) AND ("Retraction Watch"[Title/Abstract] OR Crossref[Title/Abstract]) AND (coverage[Title/Abstract] OR indexing[Title/Abstract] OR consisten*[Title/Abstract] OR database*[Title/Abstract])` | 126 | Status-source coverage and indexing. |
| S3 | `("retracted"[Title] OR "retraction"[Title]) AND (citation*[Title] OR cited[Title] OR citing[Title]) AND ("post-retraction"[Title/Abstract] OR "after retraction"[Title/Abstract])` | 7 | Post-retraction citation. |
| T1 | `VITALITY[Title/Abstract] AND retract*[Title/Abstract]` | 34 | Locate the VITALITY study. |
| T2 | `retracted[Title] AND trials[Title] AND (systematic reviews[Title] OR guidelines[Title])` | 3 | Retracted trials in reviews and guidelines. |
| T3 | `retracted publications[Title] AND pharmacy[Title] AND systematic reviews[Title]` | 1 | Known-item check. |
| T4 | `Avenell A[Author] AND retract*[Title/Abstract] AND 2019[dp]` | 3 | Known-item check for the entry-point paper. |
| T5 | `retraction[Title] AND (indexing[Title] OR indexation[Title] OR coverage[Title]) AND (database*[Title/Abstract])` | 0 | Indexing studies (none indexed under this exact form). |
| T6 | `residue[Title] AND retractions[Title]` | 1 | Known-item check. |

## Web and software searches

- Zotero retracted-item notifications (blog post, 14 June 2019): read in full.
- Feet of Clay Detector (Problematic Paper Screener): the tool page redirects to a script-rendered page and could not be retrieved as text, so the method is cited through Cabanac (2024, Nature comment, doi:10.1038/d41586-024-02747-1) and through its use in Graña Possamai et al. (2025).
- Salami, McCumber and Schneider, "Analyzing the consistency of retraction indexing": located through a web search, with metadata and PDF retrieved from the OSF API (version 4, posted 2026-08-05).

## Inclusion decisions

Included as closest prior work (see `docs/prior_art.csv`): studies that link systematic reviews to retracted or otherwise updated cited studies, studies that measure status-source coverage, and tools that match a bibliography against Retraction Watch. Excluded: single-discipline surveys of retraction counts without a citation component, retraction notices for individual reviews, and papers that use "retraction" in a surgical or orthodontic sense.

Also cited in the manuscript for context, after reading the full text or abstract: Avenell et al. 2019 (PMC6830710, full text), Bakker et al. 2024 (PMC10982619, full text), Bolland, Grey and Avenell 2022 (abstract), Grey, Avenell and Bolland 2019 (abstract), Sebo and Sebo 2026a (abstract), Cabanac 2024 (bibliographic record only).

## Verified identifiers of the closest work

| Work | PMID | PMCID | DOI |
|---|---|---|---|
| Xu et al. 2025, BMJ | 40268307 | PMC12015725 | 10.1136/bmj-2024-082068 |
| Graña Possamai et al. 2025, JAMA Intern Med | 40163084 | PMC11959482 | 10.1001/jamainternmed.2025.0256 |
| Brown et al. 2022, J Med Libr Assoc | 35210962 | PMC8830339 | 10.5195/jmla.2022.1280 |
| Kataoka et al. 2022, J Clin Epidemiol | 35779825 | none | 10.1016/j.jclinepi.2022.06.015 |
| Avenell et al. 2019, BMJ Open | 31666272 | PMC6830710 | 10.1136/bmjopen-2019-031909 |
| Bakker et al. 2024, BMJ Evid Based Med | 37463764 | PMC10982619 | 10.1136/bmjebm-2022-111921 |
| Sebo and Sebo 2026, Account Res (performance) | 40156496 | none | 10.1080/08989621.2025.2484555 |
| Sebo and Sebo 2026, Account Res (accuracy) | 39973475 | none | 10.1080/08989621.2025.2465621 |
| Salami et al. 2026, MetaArXiv preprint v4 | none | none | 10.31222/osf.io/gvfk5_v4 |
| Cabanac 2024, Nature | none | none | 10.1038/d41586-024-02747-1 |
