-- Distinct usable identifiers per reference occurrence for the active variant.
-- ids_in is occurrence_identifiers, filtered to tagged identifiers for the
-- tagged-only sensitivity analysis.
CREATE OR REPLACE TABLE occ_ids AS
SELECT occurrence_id,
       kind,
       normalized AS id,
       string_agg(DISTINCT provenance, '|' ORDER BY provenance) AS provenance
FROM ids_in
WHERE normalized IS NOT NULL
GROUP BY occurrence_id, kind, normalized;

CREATE OR REPLACE TABLE occ_id_presence AS
SELECT o.occurrence_id,
       count(i.kind) AS n_raw_ids,
       count(i.normalized) AS n_usable_ids,
       coalesce(bool_or(i.kind = 'doi' AND i.normalized IS NOT NULL), false) AS has_doi,
       coalesce(bool_or(i.kind = 'pmid' AND i.normalized IS NOT NULL), false) AS has_pmid,
       coalesce(bool_or(i.kind = 'pmcid' AND i.normalized IS NOT NULL), false) AS has_pmcid
FROM occurrences o
LEFT JOIN ids_in i USING (occurrence_id)
GROUP BY o.occurrence_id;
