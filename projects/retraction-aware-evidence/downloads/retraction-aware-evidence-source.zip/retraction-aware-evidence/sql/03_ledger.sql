-- Mutually exclusive coverage ledger, one row per reference occurrence.
CREATE OR REPLACE TABLE occ_ledger AS
SELECT o.occurrence_id,
       o.review_pmcid,
       p.has_doi, p.has_pmid, p.has_pmcid, p.n_raw_ids, p.n_usable_ids,
       coalesce(f.n_found, 0) AS n_found,
       f.found_pmids,
       fl.failure_detail,
       fl.occurrence_id IS NOT NULL AS any_failure,
       dc.occurrence_id IS NOT NULL AS doi_record_conflict,
       CASE
         WHEN p.n_raw_ids = 0 THEN 'no_identifier'
         WHEN p.n_usable_ids = 0 THEN 'malformed_identifier_only'
         WHEN coalesce(f.n_found, 0) > 1 OR dc.occurrence_id IS NOT NULL THEN 'ambiguous'
         WHEN coalesce(f.n_found, 0) = 1 THEN 'verified_pubmed_record'
         WHEN fl.occurrence_id IS NOT NULL THEN 'endpoint_unavailable'
         WHEN nl.occurrence_id IS NOT NULL THEN 'not_looked_up'
         WHEN p.has_doi THEN 'doi_not_in_pubmed'
         ELSE 'record_not_found'
       END AS ledger_category
FROM occurrences o
JOIN occ_id_presence p USING (occurrence_id)
LEFT JOIN occ_found f USING (occurrence_id)
LEFT JOIN occ_failures fl USING (occurrence_id)
LEFT JOIN (SELECT DISTINCT occurrence_id FROM occ_doi_conflict) dc USING (occurrence_id)
LEFT JOIN occ_not_looked_up nl USING (occurrence_id);
