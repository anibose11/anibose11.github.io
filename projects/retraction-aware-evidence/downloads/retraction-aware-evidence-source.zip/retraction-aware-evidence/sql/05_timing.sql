-- Interval timing of each claim against the review's first public online date
-- (primary), its issue date (S2) and with a 183-day lead (S3).
CREATE OR REPLACE TABLE claims_timed AS
SELECT c.*,
       rd.online_start, rd.online_end, rd.online_source, rd.online_precision,
       rd.issue_start AS review_issue_start, rd.issue_end AS review_issue_end,
       CASE WHEN c.notice_date_end IS NULL OR rd.online_start IS NULL THEN 'indeterminate'
            WHEN c.notice_date_end < rd.online_start THEN 'before_review'
            WHEN c.notice_date_start > rd.online_end THEN 'after_review'
            ELSE 'indeterminate' END AS timing_primary,
       CASE WHEN c.notice_date_end IS NULL OR rd.issue_start IS NULL THEN 'indeterminate'
            WHEN c.notice_date_end < rd.issue_start THEN 'before_review'
            WHEN c.notice_date_start > rd.issue_end THEN 'after_review'
            ELSE 'indeterminate' END AS timing_issue,
       CASE WHEN c.notice_date_end IS NULL OR rd.online_start IS NULL THEN 'indeterminate'
            WHEN c.notice_date_end + CAST(getvariable('lead_days') AS INTEGER) <= rd.online_start THEN 'before_review'
            WHEN c.notice_date_end < rd.online_start THEN 'within_lead_window'
            WHEN c.notice_date_start > rd.online_end THEN 'after_review'
            ELSE 'indeterminate' END AS timing_six_month
FROM claims_all c
JOIN occurrences o USING (occurrence_id)
JOIN review_dates rd ON rd.pmcid = o.review_pmcid;
