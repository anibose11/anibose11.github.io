-- Expanded identifier set per occurrence (arm B).
CREATE OR REPLACE TABLE occ_expanded_ids AS
SELECT occurrence_id, kind, id, 'reference' AS origin FROM occ_ids WHERE kind IN ('doi', 'pmid')
UNION
SELECT occurrence_id, 'pmid', pmid, via FROM occ_pmid_status WHERE status = 'found' AND via <> 'reference_pmid'
UNION
SELECT s.occurrence_id, 'doi', d.doi, 'pubmed_record'
FROM occ_pmid_status s JOIN cited_pubmed_dois d ON d.pmid = s.pmid
WHERE s.status = 'found'
UNION
SELECT o.occurrence_id, 'doi', c.doi, 'pmcid_id_converter'
FROM occ_ids o JOIN pmcid_conv c ON o.kind = 'pmcid' AND c.pmcid = o.id
WHERE c.doi IS NOT NULL;

-- Arm A: exact DOI from the reference against Retraction Watch only.
CREATE OR REPLACE TABLE claims_a AS
SELECT DISTINCT o.occurrence_id, 'retraction_watch' AS source, r.rw_record_id AS notice_key,
       r.claim_type, r.rw_nature AS source_label, 'doi_exact' AS match_basis, 'doi:reference' AS matched_on,
       r.notice_date_start, r.notice_date_end
FROM occ_ids o JOIN rw r ON o.kind = 'doi' AND r.original_doi = o.id;

-- Arm B: verified expanded identifiers against Retraction Watch.
CREATE OR REPLACE TABLE claims_b AS
SELECT occurrence_id, 'retraction_watch' AS source, rw_record_id AS notice_key, claim_type,
       rw_nature AS source_label,
       CASE WHEN bool_or(kind = 'doi' AND origin = 'reference') THEN 'doi_exact'
            WHEN bool_or(kind = 'pmid' AND origin = 'reference') THEN 'pmid_exact'
            ELSE 'ncbi_crosswalk' END AS match_basis,
       string_agg(DISTINCT kind || ':' || origin, '|' ORDER BY kind || ':' || origin) AS matched_on,
       min(notice_date_start) AS notice_date_start,
       min(notice_date_end) AS notice_date_end
FROM (
  SELECT e.occurrence_id, e.kind, e.origin, r.rw_record_id, r.claim_type, r.rw_nature, r.notice_date_start, r.notice_date_end
  FROM occ_expanded_ids e JOIN rw r ON e.kind = 'doi' AND r.original_doi = e.id
  UNION ALL
  SELECT e.occurrence_id, e.kind, e.origin, r.rw_record_id, r.claim_type, r.rw_nature, r.notice_date_start, r.notice_date_end
  FROM occ_expanded_ids e JOIN rw r ON e.kind = 'pmid' AND r.original_pmid = e.id
)
GROUP BY occurrence_id, rw_record_id, claim_type, rw_nature;

-- Agreement of the matched Retraction Watch record's own identifiers with the
-- occurrence's expanded identifiers.
CREATE OR REPLACE TABLE claims_b_agreement AS
SELECT c.occurrence_id, c.notice_key,
       CASE WHEN r.original_doi IS NULL THEN 'rw_doi_absent'
            WHEN EXISTS (SELECT 1 FROM occ_expanded_ids e WHERE e.occurrence_id = c.occurrence_id AND e.kind = 'doi' AND e.id = r.original_doi) THEN 'agrees'
            WHEN NOT EXISTS (SELECT 1 FROM occ_expanded_ids e WHERE e.occurrence_id = c.occurrence_id AND e.kind = 'doi') THEN 'no_doi_to_compare'
            ELSE 'disagrees' END AS rw_doi_agreement,
       CASE WHEN r.original_pmid IS NULL THEN 'rw_pmid_absent'
            WHEN EXISTS (SELECT 1 FROM occ_expanded_ids e WHERE e.occurrence_id = c.occurrence_id AND e.kind = 'pmid' AND e.id = r.original_pmid) THEN 'agrees'
            WHEN NOT EXISTS (SELECT 1 FROM occ_expanded_ids e WHERE e.occurrence_id = c.occurrence_id AND e.kind = 'pmid') THEN 'no_pmid_to_compare'
            ELSE 'disagrees' END AS rw_pmid_agreement
FROM claims_b c JOIN rw r ON r.rw_record_id = c.notice_key;

-- PubMed relations on the cited record (added in arm C).
CREATE OR REPLACE TABLE claims_pubmed AS
SELECT DISTINCT s.occurrence_id, 'pubmed' AS source,
       coalesce(rel.rel_pmid, 'unlinked:' || s.pmid || ':' || rel.reftype || ':' || rel.refsource) AS notice_key,
       CASE rel.reftype
         WHEN 'RetractionIn' THEN 'retraction'
         WHEN 'RetractedandRepublishedIn' THEN 'retraction'
         WHEN 'ExpressionOfConcernIn' THEN 'expression_of_concern'
         WHEN 'ErratumIn' THEN 'correction'
         WHEN 'CorrectedandRepublishedIn' THEN 'correction'
         WHEN 'UpdateIn' THEN 'update' END AS claim_type,
       rel.reftype AS source_label, 'pubmed_relation' AS match_basis, 'pmid:' || s.pmid AS matched_on,
       s.pmid AS cited_pmid, rel.rel_pmid AS notice_pmid, rel.refsource
FROM occ_pmid_status s
JOIN cited_pubmed_relations rel ON rel.pmid = s.pmid
WHERE s.status = 'found'
  AND rel.reftype IN ('RetractionIn', 'RetractedandRepublishedIn', 'ExpressionOfConcernIn',
                      'ErratumIn', 'CorrectedandRepublishedIn', 'UpdateIn')
UNION
SELECT DISTINCT s.occurrence_id, 'pubmed', 'pubtype:' || s.pmid, 'retraction', 'Retracted Publication',
       'pubmed_publication_type', 'pmid:' || s.pmid, s.pmid, NULL, NULL
FROM occ_pmid_status s
JOIN cited_pubmed p ON p.pmid = s.pmid
WHERE s.status = 'found' AND p.has_retracted_pubtype
  AND NOT EXISTS (SELECT 1 FROM cited_pubmed_relations r
                  WHERE r.pmid = s.pmid AND r.reftype IN ('RetractionIn', 'RetractedandRepublishedIn'));

CREATE OR REPLACE TABLE claims_pubmed_dated AS
SELECT c.*,
       CAST(coalesce(n.elec_start, n.issue_start) AS DATE) AS notice_date_start,
       CAST(coalesce(n.elec_end, n.issue_end) AS DATE) AS notice_date_end,
       CASE WHEN n.pmid IS NULL THEN 'notice_record_unavailable'
            WHEN n.elec_start IS NOT NULL THEN 'pubmed_article_date'
            WHEN n.issue_start IS NOT NULL THEN 'pubmed_issue_date'
            ELSE 'no_date' END AS notice_date_source
FROM claims_pubmed c
LEFT JOIN notice_pubmed n ON n.pmid = c.notice_pmid;

-- References that cite a notice rather than the article it concerns.
CREATE OR REPLACE TABLE cited_notices AS
SELECT DISTINCT o.occurrence_id, 'retraction_watch' AS source, r.rw_record_id AS notice_key,
       r.claim_type, 'doi' AS matched_kind
FROM occ_ids o JOIN rw r ON o.kind = 'doi' AND r.notice_doi = o.id
WHERE NOT EXISTS (SELECT 1 FROM rw r2 WHERE r2.original_doi = o.id)
UNION
SELECT DISTINCT o.occurrence_id, 'retraction_watch', r.rw_record_id, r.claim_type, 'pmid'
FROM occ_ids o JOIN rw r ON o.kind = 'pmid' AND r.notice_pmid = o.id
WHERE NOT EXISTS (SELECT 1 FROM rw r2 WHERE r2.original_pmid = o.id)
UNION
SELECT DISTINCT s.occurrence_id, 'pubmed', s.pmid, p.notice_kind, 'pubmed_publication_type'
FROM occ_pmid_status s JOIN cited_pubmed p ON p.pmid = s.pmid
WHERE s.status = 'found' AND p.notice_kind <> '';
