-- PubMed record candidates per occurrence and how each was reached.
CREATE OR REPLACE TABLE occ_pmid_candidates AS
SELECT DISTINCT occurrence_id, id AS pmid, 'reference_pmid' AS via
FROM occ_ids WHERE kind = 'pmid'
UNION
SELECT DISTINCT o.occurrence_id, c.pmid, 'pmcid_id_converter'
FROM occ_ids o JOIN pmcid_conv c ON o.kind = 'pmcid' AND c.pmcid = o.id
WHERE c.pmid IS NOT NULL
UNION
SELECT DISTINCT o.occurrence_id, s.pmid, 'doi_search_verified'
FROM occ_ids o JOIN doi_search s ON o.kind = 'doi' AND s.doi = o.id AND s.status = 'verified';

CREATE OR REPLACE TABLE occ_pmid_status AS
SELECT c.occurrence_id, c.pmid, c.via,
       CASE WHEN p.pmid IS NOT NULL THEN 'found'
            WHEN st.status IS NOT NULL THEN st.status
            ELSE 'not_requested' END AS status
FROM occ_pmid_candidates c
LEFT JOIN cited_pubmed p ON p.pmid = c.pmid
LEFT JOIN cited_pmid_status st ON st.pmid = c.pmid;

CREATE OR REPLACE TABLE occ_found AS
SELECT occurrence_id,
       list(DISTINCT pmid ORDER BY pmid) AS found_pmids,
       count(DISTINCT pmid) AS n_found
FROM occ_pmid_status WHERE status = 'found'
GROUP BY occurrence_id;

CREATE OR REPLACE TABLE occ_failures AS
SELECT occurrence_id, string_agg(DISTINCT what, '|' ORDER BY what) AS failure_detail
FROM (
  SELECT occurrence_id, 'pmid_request_failed' AS what FROM occ_pmid_status WHERE status = 'request_failed'
  UNION ALL
  SELECT o.occurrence_id, 'pmcid_conversion_failed'
  FROM occ_ids o JOIN pmcid_conv c ON o.kind = 'pmcid' AND c.pmcid = o.id
  WHERE c.status = 'request_failed'
  UNION ALL
  SELECT o.occurrence_id, 'doi_search_' || s.status
  FROM occ_ids o JOIN doi_search s ON o.kind = 'doi' AND s.doi = o.id
  WHERE s.status IN ('query_failed', 'verification_failed')
)
GROUP BY occurrence_id;

-- A found record whose DOIs exist but match none of the reference's DOIs.
CREATE OR REPLACE TABLE occ_doi_conflict AS
SELECT DISTINCT f.occurrence_id, f.pmid
FROM occ_pmid_status f
WHERE f.status = 'found'
  AND EXISTS (SELECT 1 FROM occ_ids o WHERE o.occurrence_id = f.occurrence_id AND o.kind = 'doi')
  AND EXISTS (SELECT 1 FROM cited_pubmed_dois d WHERE d.pmid = f.pmid)
  AND NOT EXISTS (
      SELECT 1 FROM occ_ids o JOIN cited_pubmed_dois d ON d.doi = o.id
      WHERE o.occurrence_id = f.occurrence_id AND o.kind = 'doi' AND d.pmid = f.pmid);

-- PMIDs that were never looked up (only possible in offline bibliography audits).
CREATE OR REPLACE TABLE occ_not_looked_up AS
SELECT DISTINCT occurrence_id FROM occ_pmid_status WHERE status = 'not_requested';
