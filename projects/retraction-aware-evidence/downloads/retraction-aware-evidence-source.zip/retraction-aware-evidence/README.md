# Retraction-aware evidence linkage

This project audits the reference lists of systematic reviews for retractions and related notices. For every cited study it reports whether the reference can be checked at all, what Crossref Retraction Watch and PubMed each record about it (retraction, expression of concern, correction, reinstatement), and whether the notice appeared before or after the review, using date intervals instead of single dates.

The study applies the tool to 1,000 open-access systematic reviews and meta-analyses on diabetes, obesity and heart failure (2015 to 2025). It checks 62,740 reference occurrences against a frozen Retraction Watch snapshot (data for 2026-10-06) and PubMed records retrieved on 2026-10-07. The report and the manuscript, with the results, limitations and methods, are included as Quarto sources (`report/report.qmd` and `manuscript/manuscript.qmd`). Their rendered versions are not in this archive.

The audit works with metadata only. A flag means a status source records a notice for the cited work. It is not a judgment of the study, the review or anyone's conduct, and citing a study after its notice does not show endorsement.

## Quick start

Requires Python 3.11 or later. Quarto 1.10 is needed only to render the report and manuscript.

```bash
python3 -m venv .venv
.venv/bin/pip install -e ".[test,report]"
.venv/bin/python -m pytest -q          # software tests on synthetic fixtures
.venv/bin/rae demo                     # fast run on the labeled fixtures (not study data)
```

`rae demo` writes `outputs/demo/FIXTURE_audit_not_study_data.xlsx`. It shows the mechanics only and is not evidence that the study ran.

## Full study

```bash
.venv/bin/rae acquire    # network: Retraction Watch snapshot, PubMed frame, PMC XML, cited PubMed records
.venv/bin/rae build      # parsing, linkage arms A/B/C, coverage ledger, claims, timing, unique works
.venv/bin/rae analyze    # tables, bootstrap intervals, figures, workbooks
.venv/bin/rae validate   # tests, source reconciliation, offline rerun comparison, review worksheet
.venv/bin/rae render     # Quarto report and manuscript
.venv/bin/rae package    # source archive, static page and outer bundle
.venv/bin/rae recheck    # network: re-check flagged claims and the parse sample against fresh PubMed and Crossref records
```

- `acquire` takes about 15 minutes. NCBI asks for no more than 3 requests per second without an API key. The client sends 2 per second, batches requests and caches every response under `data/cache/` with its SHA-256. Set `NCBI_EMAIL` to send a contact address with E-utilities requests. No address is stored in the repository.
- The frame manifest is frozen on first run (`data/interim/frame_manifest.csv` and its hash). Re-running `acquire` reuses it, because the live PubMed query changes over time.
- With a populated cache, `RAE_OFFLINE=1` runs everything without network access. Without the cache, a rerun retrieves current PubMed and PMC responses, which can differ from the frozen run. The request log records the hash of each response actually used.
- The source archive does not include the cache or the raw Retraction Watch CSV. The snapshot is pinned by commit and SHA-256 in `config/config.yaml`, and `acquire` refuses a file whose hash differs.

## Auditing your own bibliography

```bash
.venv/bin/rae audit my_refs.csv --review-date 2025-06-01 --out my_audit.xlsx
.venv/bin/rae audit my_refs.ris --offline
```

Accepted formats are described in `docs/bibliography_format.md`. The audit runs the same SQL linkage as the study and writes a workbook with status claims, a coverage ledger and references that cite a notice. `--offline` skips NCBI lookups and matches identifiers exactly as written.

## Layout

| Path | Contents |
|---|---|
| `src/rae/` | Python package: retrieval, JATS parsing, linkage, analysis, validation, rendering, packaging |
| `sql/` | DuckDB SQL for identifiers, crosswalks, ledger, claims and timing |
| `config/config.yaml` | Frame query, pinned snapshot, rate limits, analysis settings |
| `docs/` | Contribution decision, analysis plan with amendments, prior art, literature search, data dictionary, bibliography format, Tableau specification, implementation change log |
| `tests/` | Unit and end-to-end tests. `tests/fixtures/` holds synthetic fixtures only |
| `outputs/tables/` | Result tables (CSV) with explicit grain, and `validation_report.json` |
| `outputs/workbooks/` | `review_queue.xlsx` and `aggregate_results.xlsx` |
| `outputs/figures/` | Figures as SVG and PNG (300 dpi) |
| `evidence/claims.json` | Every headline number with its file, selector, numerator, denominator and hashes |
| `validation/human_validation_worksheet.xlsx` | Worksheet of the flagged claims and the 100-reference parse sample used for the manual check described in the Methods. The reviewer columns are blank in this copy; the automated reconciliation is in `outputs/tables/validation_report.json` |
| `report/`, `manuscript/` | Quarto sources, styles and reference files for the report and manuscript (the rendered outputs are not included) |

## Data sources and terms

- Crossref Retraction Watch data, GitLab `crossref/retraction-watch-data`, commit `fe345427b516f7d507d67db5e1119d738cc25455`. Crossref describes the data as openly available, and the repository carries no license file. The raw CSV is not redistributed here.
- PubMed records through the NCBI E-utilities. See the NCBI disclaimer and copyright notice (https://www.ncbi.nlm.nih.gov/About/disclaimer.html). This project is not endorsed by NLM, NIH or HHS.
- Review full text from the PMC Article Datasets on AWS (https://registry.opendata.aws/ncbi-pmc), accessed 2026-10-07. Article licenses vary, so citing sentences appear in outputs only for reviews with a Creative Commons license code, with the PMCID for attribution.
- `manuscript/biomed-central.csl` is from the Citation Style Language project, licensed CC BY-SA 3.0.

## License and citation

Code in this repository is released under the MIT License (`LICENSE`). Data from third parties keep their own terms. Citation metadata is in `CITATION.cff`. No DOI has been assigned.
