# Install every R package listed in R/packages.lock.csv into the project library .Rlib,
# at the listed version, in dependency order. Uses the CRAN binary when its version matches
# the lock; otherwise installs that exact version from the CRAN source archive.
lib <- file.path(getwd(), ".Rlib")
dir.create(lib, showWarnings = FALSE)
.libPaths(c(lib, .libPaths()))
options(repos = c(CRAN = "https://cloud.r-project.org"))
lock <- read.csv("R/packages.lock.csv", stringsAsFactors = FALSE)
order <- c("Rcpp", "RcppArmadillo", "numDeriv", "minqa", "mitools", "DBI", "jsonlite", "data.table", "survey")
order <- c(order, setdiff(lock$Package, order))
avail <- tryCatch(available.packages(), error = function(e) NULL)
for (p in order) {
  want <- lock$Version[lock$Package == p]
  if (length(want) == 0) next
  have <- tryCatch(as.character(packageVersion(p, lib.loc = lib)), error = function(e) NA)
  if (!is.na(have) && have == want) next
  cur <- if (!is.null(avail) && p %in% rownames(avail)) avail[p, "Version"] else NA
  if (!is.na(cur) && cur == want) {
    install.packages(p, lib = lib, dependencies = FALSE, quiet = TRUE)
  } else {
    url <- sprintf("https://cloud.r-project.org/src/contrib/Archive/%s/%s_%s.tar.gz", p, p, want)
    install.packages(url, lib = lib, repos = NULL, type = "source", dependencies = FALSE, quiet = TRUE)
  }
}
cat("R packages ready:", paste(order, collapse = ", "), "\n")
