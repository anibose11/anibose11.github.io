# Design-based estimation for the insurance-continuity study.
#
# Usage: Rscript R/analysis.R <year>        (year = 2024 primary, 2023 replication)
#
# The full person file stays in the survey design. Every estimate is a domain estimate
# taken with subset() on that design, so variance estimation uses all strata and PSUs.
# Outputs: outputs/tables/*_<year>.csv and outputs/estimates_<year>.json.

args <- commandArgs(trailingOnly = TRUE)
year <- if (length(args) >= 1) args[[1]] else "2024"
root <- Sys.getenv("INSCONT_ROOT", unset = "")
if (!nzchar(root)) {
  # Rscript encodes spaces in --file= as "~+~"
  script <- gsub("~+~", " ", sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1]), fixed = TRUE)
  root <- normalizePath(file.path(dirname(script), ".."))
}
setwd(root)
if (dir.exists(file.path(root, ".Rlib"))) .libPaths(c(file.path(root, ".Rlib"), .libPaths()))

suppressPackageStartupMessages({
  library(survey)
  library(data.table)
  library(jsonlite)
})
cfg <- fromJSON("config/study.json")
tab_dir <- "outputs/tables"
dir.create(tab_dir, showWarnings = FALSE, recursive = TRUE)

options(survey.lonely.psu = "adjust")
options(digits = 15)

d <- fread(sprintf("data/processed/analysis_%s.csv", year), colClasses = list(character = "person_id"))
n_records <- nrow(d)

des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)

# ---------------------------------------------------------------- design checks
psu_per_stratum <- d[, .(n_psu = uniqueN(psu)), by = stratum]
domain_psu <- d[domain_c == 1, .(n_psu = uniqueN(psu)), by = stratum]
design_checks <- list(
  n_records = n_records,
  n_strata = nrow(psu_per_stratum),
  n_psus = sum(psu_per_stratum$n_psu),
  singleton_strata_full_frame = sum(psu_per_stratum$n_psu == 1),
  domain_c_strata = nrow(domain_psu),
  domain_c_psus = sum(domain_psu$n_psu),
  domain_c_singleton_strata = sum(domain_psu$n_psu == 1),
  full_design_df = degf(des),
  lonely_psu_option = getOption("survey.lonely.psu"),
  note = "With subset() domains, strata keep all their PSUs; lonely-PSU adjustment applies only if a stratum has one PSU in the full frame."
)

# ---------------------------------------------------------------- helpers
rel <- cfg$reliability

nchs_flag <- function(p, se, lo_kg, hi_kg, n, df) {
  # NCHS Data Presentation Standards for Proportions (Parker et al. 2017), using the Korn-Graubard interval.
  if (is.na(p)) return("not_estimable")
  if (p == 0 || p == 1) return("degenerate_all_or_none")
  if (any(is.na(c(se, lo_kg, hi_kg)))) return("not_estimable")
  var_srs <- p * (1 - p) / n
  n_eff <- if (se > 0 && p > 0 && p < 1) min(n, n * var_srs / se^2) else n
  width <- hi_kg - lo_kg
  if (n_eff < rel$nchs_proportion_min_effective_n) return("suppress_effective_n")
  if (width >= rel$nchs_abs_ci_width_max) return("suppress_abs_width")
  if (width > 0.05 && p > 0 && (width / p) > rel$nchs_rel_ci_width_max) return("suppress_rel_width")
  if (df < rel$nchs_min_df) return("review_df")
  # Complementary proportion (Parker et al. 2017): if 1 - p would fail the relative width rule, footnote it.
  if (width > 0.05 && (1 - p) > 0 && (width / (1 - p)) > rel$nchs_rel_ci_width_max) return("review_complement")
  "ok"
}

mean_flag <- function(est, se, n) {
  if (is.na(est)) return("not_estimable")
  if (n < rel$min_unweighted_n) return("flag_small_n")
  if (is.na(se)) return("flag_se_not_estimable")
  if (est != 0 && abs(se / est) > rel$mean_rse_max) return("flag_rse_over_30pct")
  "ok"
}

prop_row <- function(design_sub, var, label, group, n_override = NULL) {
  f <- as.formula(paste0("~I(", var, " == 1)"))
  n <- if (is.null(n_override)) nrow(design_sub$variables) else n_override
  num <- sum(design_sub$variables[[var]] == 1)
  if (n == 0) return(data.table(group = group, measure = label, estimate = NA_real_))
  if (num == 0 || num == n) {
    return(data.table(group = group, measure = label, stat = "proportion", estimate = as.numeric(num == n), se = 0,
                      ci_low = NA_real_, ci_high = NA_real_, ci_method = "none (all or none in group)",
                      kg_low = NA_real_, kg_high = NA_real_, n_unweighted = n, numerator_unweighted = num,
                      weighted_denominator = sum(weights(design_sub)), design_df = degf(design_sub),
                      reliability = "degenerate_all_or_none"))
  }
  lg <- svyciprop(f, design_sub, method = "logit", level = 0.95)
  kg <- svyciprop(f, design_sub, method = "beta", level = 0.95)
  p <- as.numeric(lg)
  se <- as.numeric(SE(lg))
  ci <- as.numeric(attr(lg, "ci"))
  cik <- as.numeric(attr(kg, "ci"))
  dfv <- degf(design_sub)
  data.table(group = group, measure = label, stat = "proportion", estimate = p, se = se,
             ci_low = ci[1], ci_high = ci[2], ci_method = "logit",
             kg_low = cik[1], kg_high = cik[2], n_unweighted = n, numerator_unweighted = num,
             weighted_denominator = sum(weights(design_sub)), design_df = dfv,
             reliability = nchs_flag(p, se, cik[1], cik[2], n, dfv))
}

mean_row <- function(design_sub, var, label, group) {
  n <- nrow(design_sub$variables)
  if (n == 0) return(data.table(group = group, measure = label, estimate = NA_real_))
  m <- svymean(as.formula(paste0("~", var)), design_sub)
  est <- as.numeric(coef(m)); se <- as.numeric(SE(m))
  dfv <- degf(design_sub)
  tq <- qt(0.975, dfv)
  data.table(group = group, measure = label, stat = "mean", estimate = est, se = se,
             ci_low = est - tq * se, ci_high = est + tq * se, ci_method = "t(df) Taylor",
             kg_low = NA_real_, kg_high = NA_real_, n_unweighted = n, numerator_unweighted = NA_integer_,
             weighted_denominator = sum(weights(design_sub)), design_df = dfv,
             reliability = mean_flag(est, se, n))
}

quant_rows <- function(design_sub, var, label, group, qs = c(0.5, 0.9)) {
  n <- nrow(design_sub$variables)
  if (n < 2) return(NULL)
  q <- svyquantile(as.formula(paste0("~", var)), design_sub, quantiles = qs, ci = TRUE,
                   interval.type = "mean", se = TRUE)
  qq <- q[[var]]
  rbindlist(lapply(seq_along(qs), function(i) {
    data.table(group = group, measure = sprintf("%s p%02d", label, round(100 * qs[i])), stat = "quantile",
               estimate = qq[i, "quantile"], se = qq[i, "se"], ci_low = qq[i, "ci.2.5"], ci_high = qq[i, "ci.97.5"],
               ci_method = "Woodruff (svyquantile interval.type = mean)", kg_low = NA_real_, kg_high = NA_real_,
               n_unweighted = n, numerator_unweighted = NA_integer_, weighted_denominator = sum(weights(design_sub)),
               design_df = degf(design_sub), reliability = mean_flag(qq[i, "quantile"], qq[i, "se"], n))
  }))
}

ratio_row <- function(design_sub, num, den, label, group) {
  n <- nrow(design_sub$variables)
  r <- svyratio(as.formula(paste0("~", num)), as.formula(paste0("~", den)), design_sub)
  est <- as.numeric(coef(r)); se <- as.numeric(SE(r))
  dfv <- degf(design_sub); tq <- qt(0.975, dfv)
  data.table(group = group, measure = label, stat = "ratio", estimate = est, se = se,
             ci_low = est - tq * se, ci_high = est + tq * se, ci_method = "t(df) Taylor ratio",
             kg_low = NA_real_, kg_high = NA_real_, n_unweighted = n, numerator_unweighted = NA_integer_,
             weighted_denominator = sum(weights(design_sub)), design_df = dfv, reliability = mean_flag(est, se, n))
}

rx_summary <- function(design_sub, group) {
  users <- subset(design_sub, any_fill == 1)
  out <- list(
    prop_row(design_sub, "any_fill", "Any prescription fill", group),
    mean_row(design_sub, "rx_fills", "Mean fills (incl. refills)", group),
    mean_row(design_sub, "rx_oop", "Mean OOP Rx spending incl. zeros (USD)", group),
    mean_row(users, "rx_oop", "Mean OOP Rx spending among users (USD)", group),
    quant_rows(users, "rx_oop", "OOP Rx spending among users (USD)", group),
    prop_row(users, "oop_zero_flag", "Users with zero OOP", group),
    mean_row(design_sub, "rx_total_exp", "Mean total Rx expenditure, all payers (USD)", group)
  )
  if (sum(design_sub$variables$rx_total_exp) > 0)
    out[[length(out) + 1]] <- ratio_row(design_sub, "rx_oop", "rx_total_exp", "OOP share of total Rx expenditure", group)
  rbindlist(out, fill = TRUE)
}

# derived indicators used above
d[, oop_zero_flag := as.integer(any_fill == 1 & rx_oop == 0)]
d[, gap_flag := as.integer(cls_gap == 1)]
d[, alt_gap_flag := as.integer(alt_gap3 == 1)]
d[, switch_flag := as.integer(switch_without_gap == 1)]
d[, state_change_flag := as.integer(state_change_without_gap == 1)]
des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)

# ---------------------------------------------------------------- primary estimate
dC <- subset(des, domain_c == 1)
dC_ins <- subset(des, domain_c == 1 & year_end_insured == 1)
n_den <- nrow(dC_ins$variables)
n_ind <- sum(dC_ins$variables$cls_indeterminate == 1)
# Complete-information proportion (indeterminate persons excluded); bounds below if any are indeterminate.
dC_ins_ci <- if (n_ind > 0) subset(des, domain_c == 1 & year_end_insured == 1 & cls_indeterminate == 0) else dC_ins
primary <- prop_row(dC_ins_ci, "gap_flag", "Year-end insured with >=1 uninsured month", "Domain C, insured on 12/31")
deff_primary <- as.numeric(deff(svymean(~gap_flag, dC_ins_ci, deff = TRUE)))
bounds <- NULL
if (n_ind > 0) {
  lo <- svymean(~I(cls_gap == 1), dC_ins)
  hi <- svymean(~I(cls_gap == 1 | cls_indeterminate == 1), dC_ins)
  bounds <- list(lower = as.numeric(coef(lo))[2], upper = as.numeric(coef(hi))[2], n_indeterminate = n_ind)
}
primary_alt <- prop_row(dC_ins, "alt_gap_flag", "Year-end insured with >=3 consecutive uninsured months", "Domain C, insured on 12/31")

# ---------------------------------------------------------------- lead cross-tab
classes <- c("insured_year_end_continuous", "insured_year_end_gap", "uninsured_year_end", "indeterminate")
xt <- rbindlist(lapply(classes, function(k) {
  d[, tmp_cls := as.integer(continuity_class == k)]
  dd <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)
  sub <- subset(dd, domain_c == 1)
  n_k <- sum(sub$variables$tmp_cls == 1)
  tot <- svytotal(~tmp_cls, sub)
  pr <- if (n_k > 0) prop_row(sub, "tmp_cls", k, "Domain C, all") else
    data.table(group = "Domain C, all", measure = k, stat = "proportion", estimate = 0, se = 0, ci_low = 0, ci_high = 0,
               ci_method = "none (empty class)", kg_low = 0, kg_high = 0, n_unweighted = nrow(sub$variables),
               numerator_unweighted = 0L, weighted_denominator = sum(weights(sub)), design_df = degf(sub), reliability = "empty")
  pr[, `:=`(class = k, weighted_total = as.numeric(coef(tot)), weighted_total_se = as.numeric(SE(tot)))]
  pr
}), fill = TRUE)
d[, tmp_cls := NULL]

# year-end status in frame Y (classification-specific, includes part-year in scope)
dY <- subset(des, frame_y == 1)
ye_frame_y <- prop_row(dY, "year_end_insured", "Insured on 12/31", "Frame Y (in scope 12/31, includes part-year)")
ye_domain_c <- prop_row(dC, "year_end_insured", "Insured on 12/31", "Domain C (in scope all 12 months)")

# ---------------------------------------------------------------- gap details
dGap <- subset(des, domain_c == 1 & cls_gap == 1)
n_gap <- nrow(dGap$variables)
band_counts <- d[domain_c == 1 & cls_gap == 1, .N, by = gap_months_band]
show_bands <- all(c("1-2", "3-11") %in% band_counts$gap_months_band) &&
  min(band_counts[gap_months_band %in% c("1-2", "3-11")]$N) >= cfg$duration_bands$min_unweighted_per_band
gap_detail <- list(mean_row(dGap, "n_months_uncovered", "Mean uninsured months", "Year-end insured with gap"))
for (pat in c("uninsured_at_start_then_insured", "gap_after_insured_period", "multiple_gaps", "uninsured_through_december")) {
  d[, tmp := as.integer(gap_pattern == pat)]
  dd <- subset(svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d), domain_c == 1 & cls_gap == 1)
  if (sum(dd$variables$tmp) > 0) gap_detail[[length(gap_detail) + 1]] <- prop_row(dd, "tmp", paste("Pattern:", pat), "Year-end insured with gap")
  else gap_detail[[length(gap_detail) + 1]] <- data.table(group = "Year-end insured with gap", measure = paste("Pattern:", pat), stat = "proportion",
                                                          estimate = 0, n_unweighted = n_gap, numerator_unweighted = 0L, reliability = "empty")
}
for (st in c("private_only", "public_only", "private_and_public")) {
  d[, tmp := as.integer(december_state == st)]
  dd <- subset(svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d), domain_c == 1 & cls_gap == 1)
  if (sum(dd$variables$tmp) > 0) gap_detail[[length(gap_detail) + 1]] <- prop_row(dd, "tmp", paste("December source:", st), "Year-end insured with gap")
  dd2 <- subset(svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d), domain_c == 1 & cls_continuous == 1)
  if (sum(dd2$variables$tmp) > 0) gap_detail[[length(gap_detail) + 1]] <- prop_row(dd2, "tmp", paste("December source:", st), "Year-end insured, continuous")
}
if (show_bands) {
  d[, tmp := as.integer(gap_months_band == "1-2")]
  dd <- subset(svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d), domain_c == 1 & cls_gap == 1)
  gap_detail[[length(gap_detail) + 1]] <- prop_row(dd, "tmp", "Uninsured months 1-2 (vs 3-11)", "Year-end insured with gap")
}
d[, tmp := NULL]
gap_detail <- rbindlist(gap_detail, fill = TRUE)
des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)

# share uninsured in each calendar month among the year-end insured with a gap
monthly_unc <- rbindlist(lapply(1:12, function(i) {
  v <- sprintf("unc_m%02d", i)
  sub <- subset(des, domain_c == 1 & cls_gap == 1)
  r <- prop_row(sub, v, sprintf("Uninsured in month %d", i), "Year-end insured with gap")
  r[, month := i]
  r
}), fill = TRUE)

switch_rows <- rbindlist(list(
  prop_row(subset(des, domain_c == 1 & cls_continuous == 1), "switch_flag", "Change in coverage sources without an uninsured month", "Year-end insured, continuous"),
  prop_row(subset(des, domain_c == 1 & cls_continuous == 1), "state_change_flag", "Change between private/public/both without an uninsured month", "Year-end insured, continuous")
), fill = TRUE)

# ---------------------------------------------------------------- monthly transitions (domain C)
st <- c("P", "U", "B", "N")
st_lab <- c(P = "Private only", U = "Public only", B = "Private and public", N = "Uninsured")
for (a in st) d[, (paste0("from_", a)) := rowSums(.SD), .SDcols = paste0("tr_", a, st)]
des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)
dC <- subset(des, domain_c == 1)
trans <- rbindlist(lapply(st, function(a) rbindlist(lapply(st, function(b) {
  num <- paste0("tr_", a, b); den <- paste0("from_", a)
  n_from <- sum(dC$variables[[den]] > 0)
  if (sum(dC$variables[[den]]) == 0) return(NULL)
  r <- svyratio(as.formula(paste0("~", num)), as.formula(paste0("~", den)), dC)
  data.table(from_state = st_lab[[a]], to_state = st_lab[[b]], share = as.numeric(coef(r)), se = as.numeric(SE(r)),
             unweighted_transitions = sum(dC$variables[[num]]), unweighted_persons_with_from_state = n_from,
             weighted_transitions = sum(weights(dC) * dC$variables[[num]]))
}))))

# ---------------------------------------------------------------- prescription outcomes
d[, cls_label := fcase(continuity_class == "insured_year_end_continuous", "A",
                       continuity_class == "insured_year_end_gap", "B",
                       continuity_class == "uninsured_year_end", "C",
                       default = "D")]
d[, alt_label := fcase(continuity_class_alt == "insured_year_end_continuous", "A_alt",
                       continuity_class_alt == "insured_year_end_gap", "B_alt",
                       continuity_class_alt == "uninsured_year_end", "C",
                       default = "D")]
des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)

groups <- list(
  list("C1 Domain C: all", "domain_c == 1"),
  list("C2 Domain C: insured on 12/31 (A+B)", "domain_c == 1 & year_end_insured == 1"),
  list("C3 Domain C: A insured all 12 months", "domain_c == 1 & cls_continuous == 1"),
  list("C4 Domain C: B insured on 12/31 with gap", "domain_c == 1 & cls_gap == 1"),
  list("C5 Domain C: C uninsured on 12/31", "domain_c == 1 & cls_uninsured_ye == 1"),
  list("Y1 Frame Y: insured on 12/31", "frame_y == 1 & year_end_insured == 1"),
  list("Y2 Frame Y: uninsured on 12/31", "frame_y == 1 & year_end_insured == 0"),
  list("R2a Domain C: insured on 12/31, no 3+ month gap", "domain_c == 1 & alt_label == 'A_alt'"),
  list("R2b Domain C: insured on 12/31 with 3+ month gap", "domain_c == 1 & alt_label == 'B_alt'")
)
rx <- rbindlist(lapply(groups, function(g) {
  sub <- eval(parse(text = sprintf("subset(des, %s)", g[[2]])))
  if (nrow(sub$variables) == 0) return(NULL)
  rx_summary(sub, g[[1]])
}), fill = TRUE)

rx_states <- d[domain_c == 1, .N, by = .(cls_label, rx_state)][order(cls_label, rx_state)]

# contrasts: B vs A, C vs A for mean OOP incl zeros, mean OOP among users, any fill
contr <- function(var, cond, label) {
  sub <- eval(parse(text = sprintf("subset(des, domain_c == 1 & cls_label %%in%% c('A','B','C') %s)", cond)))
  by <- svyby(as.formula(paste0("~", var)), ~cls_label, sub, svymean, covmat = TRUE)
  cf <- coef(by)
  out <- list()
  for (k in c("B", "C")) {
    if (!all(c("A", k) %in% names(cf))) next
    w <- setNames(rep(0, length(cf)), names(cf)); w["A"] <- -1; w[k] <- 1
    sc <- svycontrast(by, w)
    dfv <- degf(sub); tq <- qt(0.975, dfv)
    out[[k]] <- data.table(measure = label, contrast = paste0(k, " minus A"), estimate = as.numeric(sc),
                           se = as.numeric(SE(sc)), ci_low = as.numeric(sc) - tq * as.numeric(SE(sc)),
                           ci_high = as.numeric(sc) + tq * as.numeric(SE(sc)), design_df = dfv)
  }
  rbindlist(out)
}
contrasts <- rbindlist(list(
  contr("rx_oop", "", "Mean OOP incl. zeros (USD)"),
  contr("rx_oop", "& any_fill == 1", "Mean OOP among users (USD)"),
  contr("any_fill", "", "Any fill (proportion)"),
  contr("rx_fills", "", "Mean fills")
))

# imputation information (2024 only)
imput <- NULL
if ("rx_records" %in% names(d)) {
  d[, rx_any_imputed := as.integer(rx_records_fully_imputed + rx_records_partially_imputed > 0)]
  des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)
  imput <- rbindlist(lapply(c("A", "B", "C"), function(k) {
    sub <- subset(des, domain_c == 1 & cls_label == k & any_fill == 1)
    rbindlist(list(
      prop_row(sub, "rx_any_imputed", "Users with >=1 fill with fully or partially imputed payments", paste("Class", k)),
      ratio_row(sub, "rx_oop_from_imputed_records", "rx_oop_event_sum", "Share of OOP dollars from fills with imputed payments", paste("Class", k)),
      ratio_row(sub, "rx_records_fully_imputed", "rx_records", "Share of fills fully imputed", paste("Class", k))
    ), fill = TRUE)
  }), fill = TRUE)
}

# part-year in scope (frame Y outside domain C)
part_year <- d[part_year_in_frame_y == 1, .(n_unweighted = .N, weighted = sum(weight)), by = .(continuity_class, year_end_insured)]

# ---------------------------------------------------------------- Table 1: characteristics by class
char_vars <- list(age_group = c("18-44", "45-64"), sex_label = c("Male", "Female"),
                  race_eth4 = c("Hispanic", "Non-Hispanic White", "Non-Hispanic Black", "Non-Hispanic Asian, other, or multiple"),
                  income2 = c("Below 200% FPL", "200% FPL or more"),
                  region_label = c("Northeast", "Midwest", "South", "West"))
char_groups <- list(list("All", "domain_c == 1"), list("A", "domain_c == 1 & cls_label == 'A'"),
                    list("B", "domain_c == 1 & cls_label == 'B'"), list("C", "domain_c == 1 & cls_label == 'C'"))
table1 <- rbindlist(lapply(char_groups, function(g) {
  rbindlist(lapply(names(char_vars), function(v) {
    rbindlist(lapply(char_vars[[v]], function(lv) {
      d[, tmp_c := as.integer(get(v) == lv)]
      dd <- eval(parse(text = sprintf("subset(svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d), %s)", g[[2]])))
      r <- prop_row(dd, "tmp_c", lv, g[[1]])
      r[, variable := v]
      r
    }), fill = TRUE)
  }), fill = TRUE)
}), fill = TRUE)
d[, tmp_c := NULL]
des <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)

# ---------------------------------------------------------------- two-part model (support-gated)
sp <- cfg$two_part_support
m <- d[domain_c == 1 & cls_label %in% c("A", "B", "C")]
m_pos <- m[rx_oop > 0]
dC_m <- subset(des, domain_c == 1 & cls_label %in% c("A", "B", "C"))
support <- list(
  part1_outcome = "OOP > 0",
  part1_minority = min(sum(m$rx_oop > 0), sum(m$rx_oop == 0)),
  positive_total = nrow(m_pos),
  positive_per_group = as.list(table(factor(m_pos$cls_label, levels = c("A", "B", "C")))),
  design_df = degf(dC_m),
  rules = sp
)
support$part1_ok <- support$part1_minority >= sp$min_part1_minority
support$part2_ok <- support$positive_total >= sp$min_positive_total &&
  all(unlist(support$positive_per_group) >= sp$min_positive_per_group) && support$design_df >= sp$min_design_df
support$decision <- if (support$part1_ok && support$part2_ok) "two_part_model" else if (support$part2_ok) "part2_only" else "descriptive_only"

model_out <- list(decision = support$decision)
if (support$decision != "descriptive_only") {
  d[, cls_f := factor(cls_label, levels = c("A", "B", "C"))]
  d[, age_f := factor(age_group, levels = c("18-44", "45-64"))]
  d[, sex_f := factor(sex_label, levels = c("Male", "Female"))]
  d[, race_f := factor(race_eth4, levels = c("Non-Hispanic White", "Hispanic", "Non-Hispanic Black", "Non-Hispanic Asian, other, or multiple"))]
  d[, inc_f := factor(income2, levels = c("200% FPL or more", "Below 200% FPL"))]
  d[, pos := as.integer(rx_oop > 0)]
  des2 <- svydesign(ids = ~psu, strata = ~stratum, weights = ~weight, nest = TRUE, data = d)
  dm <- subset(des2, domain_c == 1 & cls_label %in% c("A", "B", "C"))
  f_cov <- "cls_f + age_f + sex_f + race_f + inc_f"
  p1 <- if (support$part1_ok) svyglm(as.formula(paste("pos ~", f_cov)), dm, family = quasibinomial()) else NULL
  p2 <- svyglm(as.formula(paste("rx_oop ~", f_cov)), subset(dm, pos == 1), family = Gamma(link = "log"),
               start = c(log(mean(m_pos$rx_oop)), rep(0, sp$n_parameters)))
  coef_tab <- function(fit, part) {
    if (is.null(fit)) return(NULL)
    s <- summary(fit)$coefficients
    data.table(part = part, term = rownames(s), estimate = s[, 1], se = s[, 2],
               exp_estimate = exp(s[, 1]), exp_ci_low = exp(s[, 1] - qt(0.975, fit$df.residual) * s[, 2]),
               exp_ci_high = exp(s[, 1] + qt(0.975, fit$df.residual) * s[, 2]), df_residual = fit$df.residual)
  }
  coefs <- rbindlist(list(coef_tab(p1, "Part 1: P(OOP > 0), odds ratio"),
                          coef_tab(p2, "Part 2: mean OOP among persons with OOP > 0, ratio of means")))
  # Standardized margins with jackknife (JKn) replicates; both parts refit in every replicate.
  rdes <- as.svrepdesign(des2, type = "JKn")
  rdm <- subset(rdes, domain_c == 1 & cls_label %in% c("A", "B", "C"))
  conv <- new.env(); conv$n <- 0L; conv$fail1 <- 0L; conv$fail2 <- 0L
  theta <- function(w, data) {
    data <- as.data.frame(data)
    keep <- w > 0
    dat <- data[keep, ]; ww <- w[keep]
    # Normalize weights: glm's binomial starting values break down with weights in the thousands.
    # Point estimates and margins are invariant to this rescaling.
    ww <- ww / mean(ww)
    fp2 <- suppressWarnings(glm(as.formula(paste("rx_oop ~", f_cov)), data = dat[dat$pos == 1, ],
                                weights = ww[dat$pos == 1], family = Gamma(link = "log"),
                                start = c(log(weighted.mean(dat$rx_oop[dat$pos == 1], ww[dat$pos == 1])), rep(0, sp$n_parameters)),
                                control = glm.control(maxit = 100)))
    fp1 <- if (support$part1_ok) suppressWarnings(glm(as.formula(paste("pos ~", f_cov)), data = dat, weights = ww,
                                                     family = quasibinomial(), control = glm.control(maxit = 100))) else NULL
    conv$n <- conv$n + 1L
    if (!fp2$converged) conv$fail2 <- conv$fail2 + 1L
    if (!is.null(fp1) && !fp1$converged) conv$fail1 <- conv$fail1 + 1L
    res <- c()
    for (g in c("A", "B", "C")) {
      nd <- dat; nd$cls_f <- factor(g, levels = c("A", "B", "C"))
      mu2 <- predict(fp2, newdata = nd, type = "response")
      val <- if (!is.null(fp1)) predict(fp1, newdata = nd, type = "response") * mu2 else mu2
      res[g] <- sum(ww * val) / sum(ww)
    }
    if (support$decision == "part2_only") {
      # conditional margins standardize over persons with positive OOP only
      pos_keep <- dat$pos == 1
      for (g in c("A", "B", "C")) {
        nd <- dat[pos_keep, ]; nd$cls_f <- factor(g, levels = c("A", "B", "C"))
        res[g] <- sum(ww[pos_keep] * predict(fp2, newdata = nd, type = "response")) / sum(ww[pos_keep])
      }
    }
    c(res, B_minus_A = res[["B"]] - res[["A"]], C_minus_A = res[["C"]] - res[["A"]])
  }
  wr <- withReplicates(rdm, theta, return.replicates = TRUE)
  est <- as.numeric(coef(wr)); se <- as.numeric(SE(wr))
  rdf <- degf(rdm)
  margins <- data.table(quantity = c("Standardized mean OOP: A", "Standardized mean OOP: B", "Standardized mean OOP: C",
                                     "Standardized difference B minus A", "Standardized difference C minus A"),
                        estimate = est, se = se, ci_low = est - qt(0.975, rdf) * se, ci_high = est + qt(0.975, rdf) * se,
                        replicate_df = rdf, n_replicates = ncol(weights(rdm, type = "replication")),
                        variance_method = "JKn jackknife from design, both parts refit per replicate")
  margins[, `:=`(fits_total = conv$n, part1_nonconverged = conv$fail1, part2_nonconverged = conv$fail2)]
  model_out$coefficients <- coefs
  model_out$margins <- margins
  model_out$scale <- if (support$decision == "part2_only") "conditional on OOP > 0" else "all persons (two-part)"
  fwrite(coefs, file.path(tab_dir, sprintf("model_coefficients_%s.csv", year)))
  fwrite(margins, file.path(tab_dir, sprintf("model_standardized_margins_%s.csv", year)))
}

# ---------------------------------------------------------------- write outputs
fwrite(rbindlist(list(primary, primary_alt), fill = TRUE), file.path(tab_dir, sprintf("primary_estimate_%s.csv", year)))
fwrite(xt, file.path(tab_dir, sprintf("yearend_by_continuity_%s.csv", year)))
fwrite(rbindlist(list(ye_frame_y, ye_domain_c), fill = TRUE), file.path(tab_dir, sprintf("yearend_status_by_frame_%s.csv", year)))
fwrite(gap_detail, file.path(tab_dir, sprintf("gap_details_%s.csv", year)))
fwrite(switch_rows, file.path(tab_dir, sprintf("switch_without_gap_%s.csv", year)))
fwrite(monthly_unc, file.path(tab_dir, sprintf("monthly_uninsured_gap_group_%s.csv", year)))
fwrite(trans, file.path(tab_dir, sprintf("monthly_transitions_%s.csv", year)))
fwrite(rx, file.path(tab_dir, sprintf("rx_outcomes_%s.csv", year)))
fwrite(rx_states, file.path(tab_dir, sprintf("rx_states_unweighted_%s.csv", year)))
fwrite(contrasts, file.path(tab_dir, sprintf("rx_contrasts_%s.csv", year)))
fwrite(part_year, file.path(tab_dir, sprintf("part_year_frame_y_%s.csv", year)))
fwrite(table1, file.path(tab_dir, sprintf("table1_characteristics_%s.csv", year)))
if (!is.null(imput)) fwrite(imput, file.path(tab_dir, sprintf("rx_imputation_%s.csv", year)))

est_json <- list(
  year = year,
  design = design_checks,
  primary = as.list(primary), primary_design_effect = deff_primary,
  primary_bounds_if_indeterminate = bounds,
  primary_n_indeterminate_in_denominator = n_ind,
  primary_alt_gap3 = as.list(primary_alt),
  duration_bands_shown = show_bands, duration_band_counts = band_counts,
  two_part_support = support,
  model = if (is.null(model_out$margins)) list(decision = model_out$decision) else
    list(decision = model_out$decision, scale = model_out$scale, margins = model_out$margins),
  r_version = R.version.string,
  survey_version = as.character(packageVersion("survey")),
  data_table_version = as.character(packageVersion("data.table"))
)
write(toJSON(est_json, auto_unbox = TRUE, digits = NA, pretty = TRUE, na = "null"), sprintf("outputs/estimates_%s.json", year))
cat(sprintf("[analyze] %s primary: %.6f (%.6f, %.6f) n=%d num=%d; decision=%s\n", year, primary$estimate,
            primary$ci_low, primary$ci_high, primary$n_unweighted, primary$numerator_unweighted, support$decision))
