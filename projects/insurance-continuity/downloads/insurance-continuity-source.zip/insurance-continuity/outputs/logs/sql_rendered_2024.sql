-- ===== 01_person.sql =====
-- Person table: one row per Full Year Consolidated record, standardized names.
-- The year placeholder is the two-digit data year. Source: fyc (raw columns).
CREATE OR REPLACE TABLE person AS
SELECT
    DUPERSID            AS person_id,
    PANEL               AS panel,
    KEYNESS             AS keyness,
    INSCOPE             AS inscope_ever,
    INSC1231            AS inscope_1231,
    INSCOP31            AS inscop_r31,
    INSCOP42            AS inscop_r42,
    INSCOP53            AS inscop_r53,
    INSCOP24          AS inscop_yy,
    ELGRND24          AS elig_yy,
    ENDRFM24          AS end_ref_month,
    ENDRFY24          AS end_ref_year,
    AGE24X            AS age,
    SEX                 AS sex,
    RACETHX             AS race_eth,
    POVCAT24          AS poverty_cat,
    REGION24          AS region,
    DIABDX_M18          AS diabetes,
    INS24X            AS ins_1231,
    INSAT24X          AS ins_any_last_round,
    INSDE24X          AS ins_dec,
    UNINS24           AS unins_year,
    INSCOV24          AS inscov_year,
    INSURC24          AS insurc_year,
    RXTOT24           AS rx_fills,
    RXSLF24           AS rx_oop,
    RXEXP24           AS rx_total_exp,
    PERWT24F          AS weight,
    VARSTR              AS stratum,
    VARPSU              AS psu
FROM fyc;


-- ===== 02_person_month.sql =====
-- Person-month table: 12 rows per person.
-- The unpivot placeholder below expands to one column group per month, e.g.
--   (INSJA24X, PRIJA24, PUBJA24X, MCRJA24X, MCDJA24X, TRIJA24X, VAPJA24, GVAJA24, IHSJA24) AS "01"
-- Coverage state per month (any-coverage indicator decides insured vs uninsured):
--   private_only, public_only, private_and_public, uninsured, not_in_scope, missing
CREATE OR REPLACE TABLE person_month AS
WITH long AS (
    UNPIVOT (SELECT DUPERSID, INSJA24X, PRIJA24, PUBJA24X, MCRJA24X, MCDJA24X, TRIJA24X, VAPJA24, GVAJA24, IHSJA24, INSFE24X, PRIFE24, PUBFE24X, MCRFE24X, MCDFE24X, TRIFE24X, VAPFE24, GVAFE24, IHSFE24, INSMA24X, PRIMA24, PUBMA24X, MCRMA24X, MCDMA24X, TRIMA24X, VAPMA24, GVAMA24, IHSMA24, INSAP24X, PRIAP24, PUBAP24X, MCRAP24X, MCDAP24X, TRIAP24X, VAPAP24, GVAAP24, IHSAP24, INSMY24X, PRIMY24, PUBMY24X, MCRMY24X, MCDMY24X, TRIMY24X, VAPMY24, GVAMY24, IHSMY24, INSJU24X, PRIJU24, PUBJU24X, MCRJU24X, MCDJU24X, TRIJU24X, VAPJU24, GVAJU24, IHSJU24, INSJL24X, PRIJL24, PUBJL24X, MCRJL24X, MCDJL24X, TRIJL24X, VAPJL24, GVAJL24, IHSJL24, INSAU24X, PRIAU24, PUBAU24X, MCRAU24X, MCDAU24X, TRIAU24X, VAPAU24, GVAAU24, IHSAU24, INSSE24X, PRISE24, PUBSE24X, MCRSE24X, MCDSE24X, TRISE24X, VAPSE24, GVASE24, IHSSE24, INSOC24X, PRIOC24, PUBOC24X, MCROC24X, MCDOC24X, TRIOC24X, VAPOC24, GVAOC24, IHSOC24, INSNO24X, PRINO24, PUBNO24X, MCRNO24X, MCDNO24X, TRINO24X, VAPNO24, GVANO24, IHSNO24, INSDE24X, PRIDE24, PUBDE24X, MCRDE24X, MCDDE24X, TRIDE24X, VAPDE24, GVADE24, IHSDE24 FROM fyc)
    ON (INSJA24X, PRIJA24, PUBJA24X, MCRJA24X, MCDJA24X, TRIJA24X, VAPJA24, GVAJA24, IHSJA24) AS "01",
       (INSFE24X, PRIFE24, PUBFE24X, MCRFE24X, MCDFE24X, TRIFE24X, VAPFE24, GVAFE24, IHSFE24) AS "02",
       (INSMA24X, PRIMA24, PUBMA24X, MCRMA24X, MCDMA24X, TRIMA24X, VAPMA24, GVAMA24, IHSMA24) AS "03",
       (INSAP24X, PRIAP24, PUBAP24X, MCRAP24X, MCDAP24X, TRIAP24X, VAPAP24, GVAAP24, IHSAP24) AS "04",
       (INSMY24X, PRIMY24, PUBMY24X, MCRMY24X, MCDMY24X, TRIMY24X, VAPMY24, GVAMY24, IHSMY24) AS "05",
       (INSJU24X, PRIJU24, PUBJU24X, MCRJU24X, MCDJU24X, TRIJU24X, VAPJU24, GVAJU24, IHSJU24) AS "06",
       (INSJL24X, PRIJL24, PUBJL24X, MCRJL24X, MCDJL24X, TRIJL24X, VAPJL24, GVAJL24, IHSJL24) AS "07",
       (INSAU24X, PRIAU24, PUBAU24X, MCRAU24X, MCDAU24X, TRIAU24X, VAPAU24, GVAAU24, IHSAU24) AS "08",
       (INSSE24X, PRISE24, PUBSE24X, MCRSE24X, MCDSE24X, TRISE24X, VAPSE24, GVASE24, IHSSE24) AS "09",
       (INSOC24X, PRIOC24, PUBOC24X, MCROC24X, MCDOC24X, TRIOC24X, VAPOC24, GVAOC24, IHSOC24) AS "10",
       (INSNO24X, PRINO24, PUBNO24X, MCRNO24X, MCDNO24X, TRINO24X, VAPNO24, GVANO24, IHSNO24) AS "11",
       (INSDE24X, PRIDE24, PUBDE24X, MCRDE24X, MCDDE24X, TRIDE24X, VAPDE24, GVADE24, IHSDE24) AS "12"
    INTO NAME month_key VALUE any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
                              tricare_cov, va_cov, other_public_cov, ihs_cov
)
SELECT
    DUPERSID                         AS person_id,
    CAST(month_key AS INTEGER)       AS month,
    any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
    tricare_cov, va_cov, other_public_cov, ihs_cov,
    CASE
        WHEN any_cov = -1 THEN 'not_in_scope'
        WHEN any_cov IS NULL OR any_cov NOT IN (1, 2) THEN 'missing'
        WHEN any_cov = 2 THEN 'uninsured'
        WHEN private_cov = 1 AND public_cov = 1 THEN 'private_and_public'
        WHEN private_cov = 1 THEN 'private_only'
        WHEN public_cov = 1 THEN 'public_only'
        ELSE 'insured_source_unresolved'
    END AS coverage_state,
    -- number of distinct coverage sources recorded in the month (multi-source months count once as insured)
    (CASE WHEN private_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN medicare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN medicaid_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN tricare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN va_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN other_public_cov = 1 THEN 1 ELSE 0 END) AS n_sources
FROM long;


-- ===== 03_reconcile.sql =====
-- Reconciliation of the person-month table with AHRQ annual indicators, on documented definitions.
-- Each row: check name, persons checked, mismatches. Expected mismatches: 0 unless noted.
CREATE OR REPLACE TABLE pm_summary AS
SELECT
    person_id,
    COUNT(*)                                                     AS n_rows,
    SUM(CASE WHEN any_cov = 1 THEN 1 ELSE 0 END)                 AS m_cov,
    SUM(CASE WHEN any_cov = 2 THEN 1 ELSE 0 END)                 AS m_unc,
    SUM(CASE WHEN any_cov = -1 THEN 1 ELSE 0 END)                AS m_oos,
    SUM(CASE WHEN coverage_state = 'missing' THEN 1 ELSE 0 END)  AS m_mis,
    MAX(CASE WHEN any_cov <> -1 AND (private_cov = 1 OR tricare_cov = 1) THEN 1 ELSE 0 END) AS any_private_or_tricare,
    MAX(CASE WHEN any_cov <> -1 AND public_cov = 1 THEN 1 ELSE 0 END)                       AS any_public,
    SUM(CASE WHEN any_cov = 1 AND NOT (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END) AS m_any_without_source,
    SUM(CASE WHEN any_cov = 2 AND (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END)     AS m_source_without_any,
    SUM(CASE WHEN any_cov = 2 AND ihs_cov = 1 THEN 1 ELSE 0 END)                             AS m_ihs_only_uninsured,
    MAX(CASE WHEN month = 12 THEN any_cov END)                   AS dec_any
FROM person_month
GROUP BY person_id;

CREATE OR REPLACE TABLE reconciliation AS
SELECT 'person_month_rows_equal_12_per_person' AS check_name,
       COUNT(*) AS n_checked, SUM(CASE WHEN n_rows <> 12 THEN 1 ELSE 0 END) AS n_mismatch,
       'Every person has exactly 12 person-month rows' AS definition
FROM pm_summary
UNION ALL
SELECT 'persons_in_person_month_equal_person_table', (SELECT COUNT(*) FROM person),
       ABS((SELECT COUNT(*) FROM person) - (SELECT COUNT(*) FROM pm_summary)),
       'Person count unchanged by the reshape'
UNION ALL
SELECT 'unins_year_matches_all_inscope_months_uninsured', COUNT(*),
       SUM(CASE WHEN (p.unins_year = 1) <> (s.m_cov = 0 AND s.m_unc > 0) THEN 1 ELSE 0 END),
       'UNINS = 1 exactly when every in-scope month has INSmm = 2 (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_3_iff_unins_year', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 3) <> (p.unins_year = 1) THEN 1 ELSE 0 END),
       'INSCOV = 3 exactly when UNINS = 1'
FROM person p
UNION ALL
SELECT 'inscov_1_iff_any_private_or_tricare_month', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 1) <> (s.any_private_or_tricare = 1) THEN 1 ELSE 0 END),
       'INSCOV = 1 exactly when any in-scope month has private or TRICARE/CHAMPVA coverage (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_2_iff_public_only', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 2) <> (s.any_private_or_tricare = 0 AND s.any_public = 1) THEN 1 ELSE 0 END),
       'INSCOV = 2 exactly when public coverage in some month and no private/TRICARE month'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'monthly_any_equals_private_or_public', COUNT(*),
       SUM(CASE WHEN any_cov IN (1, 2) AND ((any_cov = 1) <> (private_cov = 1 OR public_cov = 1)) THEN 1 ELSE 0 END),
       'INSmm = 1 exactly when PRImm = 1 or PUBmm = 1 (person-months)'
FROM person_month
UNION ALL
SELECT 'monthly_scope_code_consistent_across_sources', COUNT(*),
       SUM(CASE WHEN (any_cov = -1) <> (private_cov = -1) OR (any_cov = -1) <> (public_cov = -1) THEN 1 ELSE 0 END),
       'Out-of-scope code -1 appears in INS, PRI, and PUB for the same person-months'
FROM person_month
UNION ALL
SELECT 'year_end_insured_implies_december_insured_if_in_scope_in_december', SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 AND p.ins_dec <> 1 THEN 1 ELSE 0 END),
       'INS(12/31) = 1 implies INSDE = 1 for persons in scope in December'
FROM person p
UNION ALL
SELECT 'info_year_end_value_recorded_at_departure_date', SUM(CASE WHEN p.ins_1231 = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec = -1 THEN 1 ELSE 0 END),
       'Informational: INS(12/31) = 1 with December out of scope; AHRQ records 12/31 coverage as of the date a person left the RU (documentation C-122)'
FROM person p
UNION ALL
SELECT 'insdec_matches_person_month_december', COUNT(*),
       SUM(CASE WHEN p.ins_dec IS DISTINCT FROM s.dec_any THEN 1 ELSE 0 END),
       'INSDE in the person table equals the December row of the person-month table'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'info_december_insured_but_not_on_1231', SUM(CASE WHEN p.ins_dec = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_dec = 1 AND p.ins_1231 = 2 THEN 1 ELSE 0 END),
       'Informational, not an error: covered at some time in December but not on 12/31 (coverage ended in December)'
FROM person p
UNION ALL
SELECT 'info_ihs_only_months_counted_uninsured', (SELECT COUNT(*) FROM person_month),
       (SELECT SUM(m_ihs_only_uninsured) FROM pm_summary),
       'Informational: months with IHS coverage and no other source; AHRQ does not count IHS as coverage'
;


-- ===== 04_classify.sql =====
-- Independent SQL implementation of the continuity classes, used only to cross-check
-- the Python audit function (inscont.continuity.classify_continuity).
CREATE OR REPLACE TABLE sql_class AS
SELECT
    p.person_id,
    CASE
        WHEN p.ins_1231 IS NULL OR p.ins_1231 NOT IN (1, 2) THEN 'indeterminate'
        WHEN p.ins_1231 = 2 THEN 'uninsured_year_end'
        WHEN s.m_unc > 0 THEN 'insured_year_end_gap'
        WHEN s.m_oos + s.m_mis > 0 THEN 'indeterminate'
        ELSE 'insured_year_end_continuous'
    END AS continuity_class_sql,
    s.m_unc AS n_months_uncovered_sql,
    s.m_oos AS n_months_out_of_scope_sql
FROM person p JOIN pm_summary s USING (person_id);


-- ===== transitions (inline) =====

    CREATE OR REPLACE TABLE transitions AS
    SELECT a.person_id, a.coverage_state AS from_state, b.coverage_state AS to_state, COUNT(*) AS n
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1, 2, 3;
    CREATE OR REPLACE TABLE source_changes AS
    SELECT a.person_id,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND (
                 a.private_cov IS DISTINCT FROM b.private_cov OR a.medicare_cov IS DISTINCT FROM b.medicare_cov OR
                 a.medicaid_cov IS DISTINCT FROM b.medicaid_cov OR a.tricare_cov IS DISTINCT FROM b.tricare_cov OR
                 a.va_cov IS DISTINCT FROM b.va_cov OR a.other_public_cov IS DISTINCT FROM b.other_public_cov)
               THEN 1 ELSE 0 END) AS n_source_set_changes_while_insured,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND a.coverage_state <> b.coverage_state THEN 1 ELSE 0 END)
               AS n_state_changes_while_insured
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1;
    

-- ===== 05_rx_person.sql =====
-- Prescribed medicines (HC-254A) aggregated to persons, with imputation information.
-- IMPFLAG: 2 = complete pharmacy component data, 4 = fully imputed, 5 = partially imputed.
CREATE OR REPLACE TABLE rx_person AS
SELECT
    DUPERSID                                                   AS person_id,
    COUNT(*)                                                   AS rx_records,
    SUM(RXSF24X)                                               AS rx_oop_event_sum,
    SUM(RXXP24X)                                               AS rx_exp_event_sum,
    SUM(CASE WHEN IMPFLAG = 2 THEN 1 ELSE 0 END)               AS rx_records_complete_pc,
    SUM(CASE WHEN IMPFLAG = 4 THEN 1 ELSE 0 END)               AS rx_records_fully_imputed,
    SUM(CASE WHEN IMPFLAG = 5 THEN 1 ELSE 0 END)               AS rx_records_partially_imputed,
    SUM(CASE WHEN IMPFLAG IN (4, 5) THEN RXSF24X ELSE 0 END)   AS rx_oop_from_imputed_records,
    SUM(CASE WHEN DIABEQUIP = 1 THEN 1 ELSE 0 END)             AS rx_records_diabetic_supplies,
    SUM(CASE WHEN IMPFLAG NOT IN (2, 4, 5) OR IMPFLAG IS NULL THEN 1 ELSE 0 END) AS rx_records_other_impflag
FROM rx_events
GROUP BY DUPERSID;

CREATE OR REPLACE TABLE rx_reconciliation AS
SELECT 'rx_event_persons_found_in_fyc' AS check_name,
       (SELECT COUNT(*) FROM rx_person) AS n_checked,
       (SELECT COUNT(*) FROM rx_person r WHERE NOT EXISTS (SELECT 1 FROM person p WHERE p.person_id = r.person_id)) AS n_mismatch,
       'Every person with an HC-254A record exists in the FYC person table' AS definition
UNION ALL
SELECT 'rx_fills_equal_event_record_count', COUNT(*),
       SUM(CASE WHEN p.rx_fills <> COALESCE(r.rx_records, 0) THEN 1 ELSE 0 END),
       'RXTOT equals the number of HC-254A records for the person (0 when none)'
FROM person p LEFT JOIN rx_person r USING (person_id)
UNION ALL
SELECT 'rx_oop_equals_event_sum_within_1_dollar', COUNT(*),
       SUM(CASE WHEN ABS(p.rx_oop - COALESCE(r.rx_oop_event_sum, 0)) > 1.0 THEN 1 ELSE 0 END),
       'RXSLF equals the rounded sum of RXSF across the person''s HC-254A records (tolerance $1 for rounding)'
FROM person p LEFT JOIN rx_person r USING (person_id)
UNION ALL
SELECT 'rx_exp_equals_event_sum_within_1_dollar', COUNT(*),
       SUM(CASE WHEN ABS(p.rx_total_exp - COALESCE(r.rx_exp_event_sum, 0)) > 1.0 THEN 1 ELSE 0 END),
       'RXEXP equals the rounded sum of RXXP across the person''s HC-254A records (tolerance $1)'
FROM person p LEFT JOIN rx_person r USING (person_id)
;
