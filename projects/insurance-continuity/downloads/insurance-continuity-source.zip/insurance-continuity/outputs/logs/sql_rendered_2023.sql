-- ===== 01_person.sql =====
-- Person table: one row per Full Year Consolidated record, standardized names.
-- The year placeholder is the two-digit data year. Source: fyc (raw columns).
CREATE OR REPLACE TABLE person AS
SELECT
    DUPERSID            AS person_id,
    PANEL               AS panel,
    KEYNESS             AS keyness,
    INSCOPE             AS inscope_ever,
    INSC1231            AS inscope_1231,
    INSCOP31            AS inscop_r31,
    INSCOP42            AS inscop_r42,
    INSCOP53            AS inscop_r53,
    INSCOP23          AS inscop_yy,
    ELGRND23          AS elig_yy,
    ENDRFM23          AS end_ref_month,
    ENDRFY23          AS end_ref_year,
    AGE23X            AS age,
    SEX                 AS sex,
    RACETHX             AS race_eth,
    POVCAT23          AS poverty_cat,
    REGION23          AS region,
    DIABDX_M18          AS diabetes,
    INS23X            AS ins_1231,
    INSAT23X          AS ins_any_last_round,
    INSDE23X          AS ins_dec,
    UNINS23           AS unins_year,
    INSCOV23          AS inscov_year,
    INSURC23          AS insurc_year,
    RXTOT23           AS rx_fills,
    RXSLF23           AS rx_oop,
    RXEXP23           AS rx_total_exp,
    PERWT23F          AS weight,
    VARSTR              AS stratum,
    VARPSU              AS psu
FROM fyc;


-- ===== 02_person_month.sql =====
-- Person-month table: 12 rows per person.
-- The unpivot placeholder below expands to one column group per month, e.g.
--   (INSJA24X, PRIJA24, PUBJA24X, MCRJA24X, MCDJA24X, TRIJA24X, VAPJA24, GVAJA24, IHSJA24) AS "01"
-- Coverage state per month (any-coverage indicator decides insured vs uninsured):
--   private_only, public_only, private_and_public, uninsured, not_in_scope, missing
CREATE OR REPLACE TABLE person_month AS
WITH long AS (
    UNPIVOT (SELECT DUPERSID, INSJA23X, PRIJA23, PUBJA23X, MCRJA23X, MCDJA23X, TRIJA23X, VAPJA23, GVAJA23, IHSJA23, INSFE23X, PRIFE23, PUBFE23X, MCRFE23X, MCDFE23X, TRIFE23X, VAPFE23, GVAFE23, IHSFE23, INSMA23X, PRIMA23, PUBMA23X, MCRMA23X, MCDMA23X, TRIMA23X, VAPMA23, GVAMA23, IHSMA23, INSAP23X, PRIAP23, PUBAP23X, MCRAP23X, MCDAP23X, TRIAP23X, VAPAP23, GVAAP23, IHSAP23, INSMY23X, PRIMY23, PUBMY23X, MCRMY23X, MCDMY23X, TRIMY23X, VAPMY23, GVAMY23, IHSMY23, INSJU23X, PRIJU23, PUBJU23X, MCRJU23X, MCDJU23X, TRIJU23X, VAPJU23, GVAJU23, IHSJU23, INSJL23X, PRIJL23, PUBJL23X, MCRJL23X, MCDJL23X, TRIJL23X, VAPJL23, GVAJL23, IHSJL23, INSAU23X, PRIAU23, PUBAU23X, MCRAU23X, MCDAU23X, TRIAU23X, VAPAU23, GVAAU23, IHSAU23, INSSE23X, PRISE23, PUBSE23X, MCRSE23X, MCDSE23X, TRISE23X, VAPSE23, GVASE23, IHSSE23, INSOC23X, PRIOC23, PUBOC23X, MCROC23X, MCDOC23X, TRIOC23X, VAPOC23, GVAOC23, IHSOC23, INSNO23X, PRINO23, PUBNO23X, MCRNO23X, MCDNO23X, TRINO23X, VAPNO23, GVANO23, IHSNO23, INSDE23X, PRIDE23, PUBDE23X, MCRDE23X, MCDDE23X, TRIDE23X, VAPDE23, GVADE23, IHSDE23 FROM fyc)
    ON (INSJA23X, PRIJA23, PUBJA23X, MCRJA23X, MCDJA23X, TRIJA23X, VAPJA23, GVAJA23, IHSJA23) AS "01",
       (INSFE23X, PRIFE23, PUBFE23X, MCRFE23X, MCDFE23X, TRIFE23X, VAPFE23, GVAFE23, IHSFE23) AS "02",
       (INSMA23X, PRIMA23, PUBMA23X, MCRMA23X, MCDMA23X, TRIMA23X, VAPMA23, GVAMA23, IHSMA23) AS "03",
       (INSAP23X, PRIAP23, PUBAP23X, MCRAP23X, MCDAP23X, TRIAP23X, VAPAP23, GVAAP23, IHSAP23) AS "04",
       (INSMY23X, PRIMY23, PUBMY23X, MCRMY23X, MCDMY23X, TRIMY23X, VAPMY23, GVAMY23, IHSMY23) AS "05",
       (INSJU23X, PRIJU23, PUBJU23X, MCRJU23X, MCDJU23X, TRIJU23X, VAPJU23, GVAJU23, IHSJU23) AS "06",
       (INSJL23X, PRIJL23, PUBJL23X, MCRJL23X, MCDJL23X, TRIJL23X, VAPJL23, GVAJL23, IHSJL23) AS "07",
       (INSAU23X, PRIAU23, PUBAU23X, MCRAU23X, MCDAU23X, TRIAU23X, VAPAU23, GVAAU23, IHSAU23) AS "08",
       (INSSE23X, PRISE23, PUBSE23X, MCRSE23X, MCDSE23X, TRISE23X, VAPSE23, GVASE23, IHSSE23) AS "09",
       (INSOC23X, PRIOC23, PUBOC23X, MCROC23X, MCDOC23X, TRIOC23X, VAPOC23, GVAOC23, IHSOC23) AS "10",
       (INSNO23X, PRINO23, PUBNO23X, MCRNO23X, MCDNO23X, TRINO23X, VAPNO23, GVANO23, IHSNO23) AS "11",
       (INSDE23X, PRIDE23, PUBDE23X, MCRDE23X, MCDDE23X, TRIDE23X, VAPDE23, GVADE23, IHSDE23) AS "12"
    INTO NAME month_key VALUE any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
                              tricare_cov, va_cov, other_public_cov, ihs_cov
)
SELECT
    DUPERSID                         AS person_id,
    CAST(month_key AS INTEGER)       AS month,
    any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
    tricare_cov, va_cov, other_public_cov, ihs_cov,
    CASE
        WHEN any_cov = -1 THEN 'not_in_scope'
        WHEN any_cov IS NULL OR any_cov NOT IN (1, 2) THEN 'missing'
        WHEN any_cov = 2 THEN 'uninsured'
        WHEN private_cov = 1 AND public_cov = 1 THEN 'private_and_public'
        WHEN private_cov = 1 THEN 'private_only'
        WHEN public_cov = 1 THEN 'public_only'
        ELSE 'insured_source_unresolved'
    END AS coverage_state,
    -- number of distinct coverage sources recorded in the month (multi-source months count once as insured)
    (CASE WHEN private_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN medicare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN medicaid_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN tricare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN va_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN other_public_cov = 1 THEN 1 ELSE 0 END) AS n_sources
FROM long;


-- ===== 03_reconcile.sql =====
-- Reconciliation of the person-month table with AHRQ annual indicators, on documented definitions.
-- Each row: check name, persons checked, mismatches. Expected mismatches: 0 unless noted.
CREATE OR REPLACE TABLE pm_summary AS
SELECT
    person_id,
    COUNT(*)                                                     AS n_rows,
    SUM(CASE WHEN any_cov = 1 THEN 1 ELSE 0 END)                 AS m_cov,
    SUM(CASE WHEN any_cov = 2 THEN 1 ELSE 0 END)                 AS m_unc,
    SUM(CASE WHEN any_cov = -1 THEN 1 ELSE 0 END)                AS m_oos,
    SUM(CASE WHEN coverage_state = 'missing' THEN 1 ELSE 0 END)  AS m_mis,
    MAX(CASE WHEN any_cov <> -1 AND (private_cov = 1 OR tricare_cov = 1) THEN 1 ELSE 0 END) AS any_private_or_tricare,
    MAX(CASE WHEN any_cov <> -1 AND public_cov = 1 THEN 1 ELSE 0 END)                       AS any_public,
    SUM(CASE WHEN any_cov = 1 AND NOT (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END) AS m_any_without_source,
    SUM(CASE WHEN any_cov = 2 AND (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END)     AS m_source_without_any,
    SUM(CASE WHEN any_cov = 2 AND ihs_cov = 1 THEN 1 ELSE 0 END)                             AS m_ihs_only_uninsured,
    MAX(CASE WHEN month = 12 THEN any_cov END)                   AS dec_any
FROM person_month
GROUP BY person_id;

CREATE OR REPLACE TABLE reconciliation AS
SELECT 'person_month_rows_equal_12_per_person' AS check_name,
       COUNT(*) AS n_checked, SUM(CASE WHEN n_rows <> 12 THEN 1 ELSE 0 END) AS n_mismatch,
       'Every person has exactly 12 person-month rows' AS definition
FROM pm_summary
UNION ALL
SELECT 'persons_in_person_month_equal_person_table', (SELECT COUNT(*) FROM person),
       ABS((SELECT COUNT(*) FROM person) - (SELECT COUNT(*) FROM pm_summary)),
       'Person count unchanged by the reshape'
UNION ALL
SELECT 'unins_year_matches_all_inscope_months_uninsured', COUNT(*),
       SUM(CASE WHEN (p.unins_year = 1) <> (s.m_cov = 0 AND s.m_unc > 0) THEN 1 ELSE 0 END),
       'UNINS = 1 exactly when every in-scope month has INSmm = 2 (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_3_iff_unins_year', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 3) <> (p.unins_year = 1) THEN 1 ELSE 0 END),
       'INSCOV = 3 exactly when UNINS = 1'
FROM person p
UNION ALL
SELECT 'inscov_1_iff_any_private_or_tricare_month', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 1) <> (s.any_private_or_tricare = 1) THEN 1 ELSE 0 END),
       'INSCOV = 1 exactly when any in-scope month has private or TRICARE/CHAMPVA coverage (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_2_iff_public_only', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 2) <> (s.any_private_or_tricare = 0 AND s.any_public = 1) THEN 1 ELSE 0 END),
       'INSCOV = 2 exactly when public coverage in some month and no private/TRICARE month'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'monthly_any_equals_private_or_public', COUNT(*),
       SUM(CASE WHEN any_cov IN (1, 2) AND ((any_cov = 1) <> (private_cov = 1 OR public_cov = 1)) THEN 1 ELSE 0 END),
       'INSmm = 1 exactly when PRImm = 1 or PUBmm = 1 (person-months)'
FROM person_month
UNION ALL
SELECT 'monthly_scope_code_consistent_across_sources', COUNT(*),
       SUM(CASE WHEN (any_cov = -1) <> (private_cov = -1) OR (any_cov = -1) <> (public_cov = -1) THEN 1 ELSE 0 END),
       'Out-of-scope code -1 appears in INS, PRI, and PUB for the same person-months'
FROM person_month
UNION ALL
SELECT 'year_end_insured_implies_december_insured_if_in_scope_in_december', SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 AND p.ins_dec <> 1 THEN 1 ELSE 0 END),
       'INS(12/31) = 1 implies INSDE = 1 for persons in scope in December'
FROM person p
UNION ALL
SELECT 'info_year_end_value_recorded_at_departure_date', SUM(CASE WHEN p.ins_1231 = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec = -1 THEN 1 ELSE 0 END),
       'Informational: INS(12/31) = 1 with December out of scope; AHRQ records 12/31 coverage as of the date a person left the RU (documentation C-122)'
FROM person p
UNION ALL
SELECT 'insdec_matches_person_month_december', COUNT(*),
       SUM(CASE WHEN p.ins_dec IS DISTINCT FROM s.dec_any THEN 1 ELSE 0 END),
       'INSDE in the person table equals the December row of the person-month table'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'info_december_insured_but_not_on_1231', SUM(CASE WHEN p.ins_dec = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_dec = 1 AND p.ins_1231 = 2 THEN 1 ELSE 0 END),
       'Informational, not an error: covered at some time in December but not on 12/31 (coverage ended in December)'
FROM person p
UNION ALL
SELECT 'info_ihs_only_months_counted_uninsured', (SELECT COUNT(*) FROM person_month),
       (SELECT SUM(m_ihs_only_uninsured) FROM pm_summary),
       'Informational: months with IHS coverage and no other source; AHRQ does not count IHS as coverage'
;


-- ===== 04_classify.sql =====
-- Independent SQL implementation of the continuity classes, used only to cross-check
-- the Python audit function (inscont.continuity.classify_continuity).
CREATE OR REPLACE TABLE sql_class AS
SELECT
    p.person_id,
    CASE
        WHEN p.ins_1231 IS NULL OR p.ins_1231 NOT IN (1, 2) THEN 'indeterminate'
        WHEN p.ins_1231 = 2 THEN 'uninsured_year_end'
        WHEN s.m_unc > 0 THEN 'insured_year_end_gap'
        WHEN s.m_oos + s.m_mis > 0 THEN 'indeterminate'
        ELSE 'insured_year_end_continuous'
    END AS continuity_class_sql,
    s.m_unc AS n_months_uncovered_sql,
    s.m_oos AS n_months_out_of_scope_sql
FROM person p JOIN pm_summary s USING (person_id);


-- ===== transitions (inline) =====

    CREATE OR REPLACE TABLE transitions AS
    SELECT a.person_id, a.coverage_state AS from_state, b.coverage_state AS to_state, COUNT(*) AS n
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1, 2, 3;
    CREATE OR REPLACE TABLE source_changes AS
    SELECT a.person_id,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND (
                 a.private_cov IS DISTINCT FROM b.private_cov OR a.medicare_cov IS DISTINCT FROM b.medicare_cov OR
                 a.medicaid_cov IS DISTINCT FROM b.medicaid_cov OR a.tricare_cov IS DISTINCT FROM b.tricare_cov OR
                 a.va_cov IS DISTINCT FROM b.va_cov OR a.other_public_cov IS DISTINCT FROM b.other_public_cov)
               THEN 1 ELSE 0 END) AS n_source_set_changes_while_insured,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND a.coverage_state <> b.coverage_state THEN 1 ELSE 0 END)
               AS n_state_changes_while_insured
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1;
    