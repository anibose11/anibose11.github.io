"""Render stage: figures, workbook, claims, manuscript, supplement, submission files, report, and site.

All numbers come from inscont.results (which reads the output tables). The manuscript
text lives in manuscript/*_template.md; this module fills it, numbers the citations,
and writes Markdown, HTML, and Word versions.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import html
import json
import re
from pathlib import Path

import jinja2
import markdown as md
import pandas as pd

from . import figures, paths, references, results, workbook

CLASS_LABEL = {"A": "A. Insured all 12 months", "B": "B. Insured on 12/31, ≥1 uninsured month", "C": "C. Uninsured on 12/31"}
MINUS = "−"
FLAG_NOTE = ("† Does not meet the National Center for Health Statistics (NCHS) presentation standard for proportions. ‡ Relative standard error above "
             "30% or not estimable, or fewer than 30 people. § Meets the NCHS standard but calls for review (fewer than 8 design degrees of freedom, "
             "or the complementary proportion would not meet it).")
DAGGER_NOTE = "† Does not meet the National Center for Health Statistics presentation standard for proportions."


def pct(x, d=1):
    return "" if pd.isna(x) else f"{100 * x:.{d}f}"


def mark(rel) -> str:
    rel = str(rel)
    if rel.startswith("suppress"):
        return " †"
    if rel.startswith("flag"):
        return " ‡"
    if rel.startswith("review"):
        return " §"
    return ""


def neg(s: str) -> str:
    """Typographic minus for negative numbers (not hyphens in ranges or words)."""
    return re.sub(r"(?<![\w\-.])-(?=\$?\d)", MINUS, s)


def cell_prop(r) -> str:
    if pd.isna(r["estimate"]):
        return "NA"
    if pd.isna(r.get("ci_low")):
        return f"{pct(r['estimate'])}"
    return f"{pct(r['estimate'])} ({pct(r['ci_low'])} to {pct(r['ci_high'])})" + mark(r.get("reliability", "ok"))


def cell_num(r, usd=False, d=1) -> str:
    if pd.isna(r["estimate"]):
        return "NA"
    f = (lambda v: f"${v:,.0f}") if usd else (lambda v: f"{v:,.{d}f}")
    lo = "NA" if pd.isna(r.get("ci_low")) else f(max(r["ci_low"], 0) if usd else r["ci_low"])
    hi = "not estimable" if pd.isna(r.get("ci_high")) else f(r["ci_high"])
    return f"{f(r['estimate'])} ({lo} to {hi})" + mark(r.get("reliability", "ok"))


def cell_ratio_pct(r) -> str:
    lo, hi = max(r["ci_low"], 0), min(r["ci_high"], 1)
    return f"{100 * r['estimate']:.1f} ({100 * lo:.1f} to {100 * hi:.1f})" + mark(r.get("reliability", "ok"))


def md_table(headers: list[str], rows: list[list[str]]) -> str:
    esc = lambda x: str(x).replace("|", "/")
    out = ["| " + " | ".join(esc(h) for h in headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(esc(x) for x in r) + " |")
    return "\n".join(out)


def table1(year="2024") -> str:
    t = pd.read_csv(paths.TABLES / f"table1_characteristics_{year}.csv")
    order = [("age_group", "Age, y", ["18-44", "45-64"]), ("sex_label", "Sex", ["Female", "Male"]),
             ("race_eth4", "Race and ethnicity", ["Hispanic", "Non-Hispanic Black", "Non-Hispanic White", "Non-Hispanic Asian, other, or multiple"]),
             ("income2", "Family income", ["Below 200% FPL", "200% FPL or more"]),
             ("region_label", "Census region", ["Northeast", "Midwest", "South", "West"])]
    groups = ["All", "A", "B", "C"]
    n = {g: int(t[t["group"] == g]["n_unweighted"].iloc[0]) for g in groups}
    rows = [["Unweighted n"] + [f"{n[g]:,}" for g in groups]]
    for var, lab, levels in order:
        rows.append([f"**{lab}**", "", "", "", ""])
        for lv in levels:
            r = [t[(t["group"] == g) & (t["variable"] == var) & (t["measure"] == lv)].iloc[0] for g in groups]
            label = lv.replace("Below 200% FPL", "Below 200% of the federal poverty level").replace("200% FPL or more", "200% of the federal poverty level or more")
            rows.append([f"&nbsp;&nbsp;{label}"] + [cell_prop(x) for x in r])
    return md_table(["Characteristic", "All", "A. Insured all 12 months", "B. Insured 12/31, gap", "C. Uninsured 12/31"], rows)


def table2(year="2024") -> str:
    rx = pd.read_csv(paths.TABLES / f"rx_outcomes_{year}.csv")
    cols = [("C2 Domain C: insured on 12/31 (A+B)", "Insured on 12/31 (A+B)"), ("C3 Domain C: A insured all 12 months", "A. All 12 months"),
            ("C4 Domain C: B insured on 12/31 with gap", "B. 12/31 with gap"), ("C5 Domain C: C uninsured on 12/31", "C. Uninsured 12/31"),
            ("Y1 Frame Y: insured on 12/31", "Insured on 12/31, classification-specific")]
    meas = [("Any prescription fill", "Any fill, %", "prop"), ("Mean fills (incl. refills)", "Fills per person, mean", "num"),
            ("Mean OOP Rx spending incl. zeros (USD)", "OOP spending, mean incl. zeros, $", "usd"),
            ("Mean OOP Rx spending among users (USD)", "OOP spending among users, mean, $", "usd"),
            ("OOP Rx spending among users (USD) p50", "OOP spending among users, median, $", "usd"),
            ("OOP Rx spending among users (USD) p90", "OOP spending among users, 90th percentile, $", "usd"),
            ("Users with zero OOP", "Users with $0 OOP, %", "prop"),
            ("Mean total Rx expenditure, all payers (USD)", "Total Rx expenditure, mean, $", "usd")]
    rows = []
    nrow = ["Unweighted n"]
    for g, _ in cols:
        nrow.append(f"{int(rx[(rx['group'] == g) & (rx['measure'] == 'Any prescription fill')]['n_unweighted'].iloc[0]):,}")
    rows.append(nrow)
    for m, lab, kind in meas:
        row = [lab]
        for g, _ in cols:
            r = rx[(rx["group"] == g) & (rx["measure"] == m)].iloc[0]
            row.append(cell_prop(r) if kind == "prop" else cell_num(r, usd=(kind == "usd")))
        rows.append(row)
    return md_table(["Measure"] + [c[1] for c in cols], rows)


def _usd_signed(v: float) -> str:
    return f"{MINUS}${abs(v):,.0f}" if v < 0 else f"${v:,.0f}"


def table3() -> str:
    rows = []
    for year in ("2024", "2023"):
        p = pd.read_csv(paths.TABLES / f"primary_estimate_{year}.csv")
        for _, r in p.iterrows():
            lab = "≥1 uninsured month" if ">=1" in r["measure"] else "≥3 consecutive uninsured months"
            rows.append([f"{year}", f"Share of year-end insured with a gap ({lab}), %", cell_prop(r),
                         f"{int(r['numerator_unweighted'])}/{int(r['n_unweighted'])}"])
    for year in ("2024", "2023"):
        m = pd.read_csv(paths.TABLES / f"model_standardized_margins_{year}.csv")
        for _, r in m.iterrows():
            lab = {"Standardized mean OOP: A": "Standardized mean OOP, class A, $", "Standardized mean OOP: B": "Standardized mean OOP, class B, $",
                   "Standardized mean OOP: C": "Standardized mean OOP, class C, $", "Standardized difference B minus A": "Standardized difference, B minus A, $",
                   "Standardized difference C minus A": "Standardized difference, C minus A, $"}[r["quantity"]]
            rows.append([year, lab, f"{_usd_signed(r['estimate'])} ({_usd_signed(r['ci_low'])} to {_usd_signed(r['ci_high'])})", f"{int(r['n_replicates'])} jackknife replicates"])
    return md_table(["Year", "Quantity", "Estimate (95% CI)", "Unweighted n or variance basis"], rows)


GAP_LABELS = {
    "Mean uninsured months": "Uninsured months in 2024, mean",
    "Pattern: uninsured_at_start_then_insured": "Uninsured in January, then insured through December, %",
    "Pattern: gap_after_insured_period": "Single gap after an insured period, %",
    "Pattern: multiple_gaps": "More than 1 gap, %",
    "Pattern: uninsured_through_december": "Uninsured through December, %",
    "December source: private_only": "December coverage: private only, %",
    "December source: public_only": "December coverage: public only, %",
    "December source: private_and_public": "December coverage: private and public, %",
    "Uninsured months 1-2 (vs 3-11)": "1 to 2 uninsured months (vs 3 to 11), %",
}
TERM_LABELS = {
    "(Intercept)": "Intercept", "cls_fB": "Class B vs A", "cls_fC": "Class C vs A", "age_f45-64": "Age 45 to 64 vs 18 to 44",
    "sex_fFemale": "Female vs male", "race_fHispanic": "Hispanic vs non-Hispanic White",
    "race_fNon-Hispanic Black": "Non-Hispanic Black vs non-Hispanic White",
    "race_fNon-Hispanic Asian, other, or multiple": "Non-Hispanic Asian, other, or multiple race vs non-Hispanic White",
    "inc_fBelow 200% FPL": "Income below 200% of the federal poverty level vs 200% or more",
}
DIAG_LABELS = {
    "Share of weighted OOP dollars from the top 1% of persons": "Share of out-of-pocket dollars from the top 1% of people",
    "Share of weighted OOP dollars from the top 5% of persons": "Share of out-of-pocket dollars from the top 5% of people",
    "Maximum annual OOP, insured_year_end_continuous": "Largest annual out-of-pocket amount, class A",
    "Maximum annual OOP, insured_year_end_gap": "Largest annual out-of-pocket amount, class B",
    "Maximum annual OOP, uninsured_year_end": "Largest annual out-of-pocket amount, class C",
    "Mean OOP excluding the domain top 1%, insured_year_end_continuous": "Mean out-of-pocket spending excluding the domain top 1%, class A",
    "Mean OOP excluding the domain top 1%, insured_year_end_gap": "Mean out-of-pocket spending excluding the domain top 1%, class B",
    "Mean OOP excluding the domain top 1%, uninsured_year_end": "Mean out-of-pocket spending excluding the domain top 1%, class C",
}
EXCL_LABELS = {
    "Adults 18 to 64, positive weight: diabetes = 2 (no)": "Adults 18 to 64 with positive weight: diabetes reported no",
    "Adults 18 to 64, positive weight: diabetes = -7 (refused)": "Adults 18 to 64 with positive weight: diabetes question refused",
    "Adults 18 to 64, positive weight: diabetes = -8 (don't know)": "Adults 18 to 64 with positive weight: diabetes don't know",
    "Adults 18 to 64, positive weight: diabetes = -1 (inapplicable)": "Adults 18 to 64 with positive weight: diabetes inapplicable",
    "Adults 18 to 64, positive weight: diabetes other codes": "Adults 18 to 64 with positive weight: other diabetes codes",
    "Diabetes cohort not in scope on 12/31": "Diabetes cohort not in scope on 12/31",
    "Diabetes cohort in scope 12/31 without substantive year-end value": "Diabetes cohort in scope on 12/31 without a year-end coverage value",
    "Frame Y but part-year in scope (described separately)": "In scope on 12/31 but not all year (described in Section S1.2)",
    "Frame Y, ref. period ends before December": "In scope on 12/31 with reference period ending before December",
}
CHECK_LABELS = {
    "person_month_rows_equal_12_per_person": "Each person has 12 person-month rows",
    "persons_in_person_month_equal_person_table": "Person count unchanged by the reshape",
    "unins_year_matches_all_inscope_months_uninsured": "Uninsured-all-year indicator equals all in-scope months uninsured",
    "inscov_3_iff_unins_year": "Annual coverage indicator 'uninsured' equals uninsured all year",
    "inscov_1_iff_any_private_or_tricare_month": "Annual 'any private' equals any month with private or TRICARE coverage",
    "inscov_2_iff_public_only": "Annual 'public only' equals public coverage with no private or TRICARE month",
    "monthly_any_equals_private_or_public": "Monthly any coverage equals private or public coverage (person-months)",
    "monthly_scope_code_consistent_across_sources": "Out-of-scope months coded the same across coverage sources",
    "year_end_insured_implies_december_insured_if_in_scope_in_december": "Insured on 12/31 implies insured in December (in scope in December)",
    "info_year_end_value_recorded_at_departure_date": "Informational: 12/31 value recorded at the date a person left the household",
    "insdec_matches_person_month_december": "December indicator equals the December person-month row",
    "info_december_insured_but_not_on_1231": "Informational: covered in December but not on 12/31",
    "info_ihs_only_months_counted_uninsured": "Informational: months with Indian Health Service coverage only",
    "python_audit_function_equals_sql_classification": "Classification function agrees with independent SQL classification",
    "python_and_sql_uncovered_month_counts_equal": "Uninsured-month counts agree between the two implementations",
    "no_nulls_in_person_table": "No missing values in the person table",
    "codebook_weighted_and_unweighted_frequencies": "Weighted and unweighted frequencies equal the AHRQ codebook",
    "rx_event_persons_found_in_fyc": "Every person in the prescription file is in the person file",
    "rx_fills_equal_event_record_count": "Fill count equals the number of prescription records",
    "rx_oop_equals_event_sum_within_1_dollar": "Out-of-pocket total equals the sum over prescription records (within $1)",
    "rx_exp_equals_event_sum_within_1_dollar": "Total expenditure equals the sum over prescription records (within $1)",
}
STATE_LABELS = {"no_recorded_fill": "No recorded fill", "fills_zero_oop": "Fills with $0 out-of-pocket", "fills_positive_oop": "Fills with positive out-of-pocket",
                "missing_expenditure": "Missing expenditure"}


def supplementary_tables() -> str:
    T = paths.TABLES
    parts = []
    sc = pd.read_csv(T / "scope_agreement_frame_y_2024.csv")
    rows = [["In scope all 12 months (monthly rule)" if r["monthly_rule_full_year_scope"] else "Not in scope all 12 months (monthly rule)",
             int(r.get("True", 0)), int(r.get("False", 0))] for _, r in sc.iterrows()]
    parts.append("### Table S1. Monthly scope rule versus round-level scope variables, 2024\n\nAdults 18 to 64 with diagnosed diabetes and positive weight who were in scope on December 31 with a year-end coverage value. Columns: in scope for the whole reference period in each round covering 2024 (INSCOP31, INSCOP42, and INSCOP24 all equal 1). Unweighted counts.\n\n" +
                 md_table(["Monthly rule", "Round-level: in scope throughout", "Round-level: not in scope throughout"], rows))
    tr = pd.read_csv(T / "monthly_transitions_2024.csv")
    rows = [[r["from_state"], r["to_state"], f"{100 * r['share']:.2f} ({100 * r['se']:.2f})", f"{int(r['unweighted_transitions']):,}", f"{int(r['unweighted_persons_with_from_state']):,}"] for _, r in tr.iterrows()]
    parts.append("### Table S2. Month-to-month coverage transitions, primary domain, 2024\n\nShare of person-month transitions out of each coverage state (rows sum to 100% within a from-state), with linearized standard errors from ratio estimators.\n\n" +
                 md_table(["From", "To", "Share, % (SE)", "Transitions, n", "People with from-state, n"], rows))
    gd = pd.read_csv(T / "gap_details_2024.csv")
    rows = []
    for _, r in gd.iterrows():
        lab = GAP_LABELS.get(r["measure"], r["measure"])
        grp = "Class B" if r["group"].endswith("with gap") else "Class A"
        if r.get("reliability") == "empty":
            val = "0"
        elif r["measure"] == "Mean uninsured months":
            val = cell_num(r)
        else:
            val = cell_prop(r)
        rows.append([grp, lab, val, int(r["n_unweighted"])])
    parts.append("### Table S3. Characteristics of gaps in class B, with December coverage source in classes A and B, 2024\n\n" + FLAG_NOTE + "\n\n" +
                 md_table(["Group", "Measure", "Estimate (95% CI)", "Unweighted n"], rows))
    sw = pd.read_csv(T / "switch_without_gap_2024.csv")
    sw_labels = {"Change in coverage sources without an uninsured month": "Change in coverage categories held (private, Medicare, Medicaid, TRICARE, VA, other public), no uninsured month",
                 "Change between private/public/both without an uninsured month": "Change between private only, public only, and both, no uninsured month"}
    parts.append("### Table S4. Changes in coverage without an uninsured month, class A, 2024\n\nChanges between private insurers cannot be identified in the public-use file.\n\n" +
                 md_table(["Measure", "Estimate, % (95% CI)", "Unweighted n"], [[sw_labels.get(r["measure"], r["measure"]), cell_prop(r), int(r["n_unweighted"])] for _, r in sw.iterrows()]))
    mc = pd.read_csv(T / "model_coefficients_2024.csv")
    part_lab = lambda p: "Part 1: any out-of-pocket spending (odds ratio)" if p.startswith("Part 1") else "Part 2: mean among people with spending (ratio of means)"
    parts.append("### Table S5. Two-part model coefficients, 2024 (survey-weighted; descriptive)\n\nReference levels: class A, age 18 to 44, male, non-Hispanic White, income 200% of the federal poverty level or more.\n\n" +
                 md_table(["Part", "Term", "Exponentiated estimate (95% CI)"], [[part_lab(r["part"]), TERM_LABELS.get(r["term"], r["term"]), f"{r['exp_estimate']:.2f} ({r['exp_ci_low']:.2f} to {r['exp_ci_high']:.2f})"] for _, r in mc.iterrows()]))
    im = pd.read_csv(T / "rx_imputation_2024.csv")
    im_labels = {"Users with >=1 fill with fully or partially imputed payments": "Users with ≥1 fill with fully or partially imputed payments, %",
                 "Share of OOP dollars from fills with imputed payments": "Share of out-of-pocket dollars from fills with imputed payments, %",
                 "Share of fills fully imputed": "Share of fills with fully imputed payments, %"}
    parts.append("### Table S6. Imputation information from the 2024 Prescribed Medicines file, users in the primary domain\n\n" + FLAG_NOTE + "\n\n" +
                 md_table(["Group", "Measure", "Estimate (95% CI)", "Unweighted n"], [[r["group"], im_labels.get(r["measure"], r["measure"]), (cell_prop(r) if r["stat"] == "proportion" else cell_ratio_pct(r)), int(r["n_unweighted"])] for _, r in im.iterrows()]))
    cb = pd.read_csv(T / "codebook_frequency_reconciliation_2024.csv")
    rows = [[r["variable"], r["code"], str(r["label"]).title() if isinstance(r["label"], str) else "", f"{int(r['codebook_unweighted']):,}", f"{int(r['computed_unweighted']):,}",
             "" if pd.isna(r["codebook_weighted"]) else f"{r['codebook_weighted']:,.0f}", "" if pd.isna(r["abs_diff_weighted"]) else f"{r['abs_diff_weighted']:.2f}"] for _, r in cb.iterrows()]
    parts.append("### Table S7. Computed frequencies versus the AHRQ HC-256 codebook\n\nWeighted values agree to within the codebook's rounding (absolute difference under 1).\n\n" +
                 md_table(["Variable", "Code", "Label", "Codebook n", "Computed n", "Codebook weighted", "Absolute difference, weighted"], rows))
    r23 = pd.read_csv(T / "rx_outcomes_2023.csv")
    rows = []
    gl = {"C3 Domain C: A insured all 12 months": "A. Insured all 12 months", "C4 Domain C: B insured on 12/31 with gap": "B. Insured 12/31, gap",
          "C5 Domain C: C uninsured on 12/31": "C. Uninsured 12/31", "C2 Domain C: insured on 12/31 (A+B)": "Insured on 12/31 (A+B)"}
    ml = {"Any prescription fill": "Any fill, %", "Mean fills (incl. refills)": "Fills per person, mean",
          "Mean OOP Rx spending incl. zeros (USD)": "OOP spending, mean incl. zeros, $", "OOP Rx spending among users (USD) p50": "OOP spending among users, median, $"}
    for g in gl:
        for m in ml:
            r = r23[(r23["group"] == g) & (r23["measure"] == m)].iloc[0]
            kind = "prop" if m == "Any prescription fill" else ("num" if "fills" in m else "usd")
            rows.append([gl[g], ml[m], cell_prop(r) if kind == "prop" else cell_num(r, usd=kind == "usd"), int(r["n_unweighted"])])
    parts.append("### Table S8. Prescription outcomes, 2023 replication (HC-251)\n\nNominal 2023 dollars. " + FLAG_NOTE + "\n\n" + md_table(["Group", "Measure", "Estimate (95% CI)", "Unweighted n"], rows))
    dg = pd.read_csv(T / "diagnostic_oop_concentration.csv")
    parts.append("### Table S9. Concentration of out-of-pocket spending in the primary domain (post hoc diagnostic, no inference)\n\n" +
                 md_table(["Year", "Diagnostic", "Value"], [[r["year"], DIAG_LABELS.get(r["diagnostic"], r["diagnostic"]), (f"{100 * r['value']:.1f}%" if r["value"] < 1.5 else f"${r['value']:,.0f}")] for _, r in dg.iterrows()]))
    ex = pd.read_csv(T / "cohort_exclusions_2024.csv")
    parts.append("### Table S10. Exclusions and records outside the primary domain, 2024\n\nUnweighted counts.\n\n" +
                 md_table(["Group", "Unweighted n"], [[EXCL_LABELS.get(r["group"], r["group"]), f"{int(r['n_unweighted']):,}"] for _, r in ex.iterrows()]))
    dd = pd.read_csv(T / "data_dictionary.csv")
    dd = dd[dd["data_year"] == 2024]
    parts.append("### Table S11. Source-to-analysis data dictionary, 2024\n\nAHRQ source variables for each analysis variable and the transformation applied. The same mapping with 2023 variable names applies to the replication.\n\n" +
                 md_table(["Analysis variable", "AHRQ source variables", "Transformation", "Reserved-code handling"],
                          [[r["analysis_variable"].replace("_", " "), r["source_variables"], r["transformation"], r["reserved_code_handling"]] for _, r in dd.iterrows()]))
    return "\n\n".join(parts)


def supplementary_figures(prefix: str) -> str:
    figs = [("figS1_cohort_flow_2024", "Figure S1. Cohort flow, 2024. Unweighted record counts at each cumulative step and the classification of the primary domain."),
            ("figS2_robustness_gap_definitions", "Figure S2. Share of the year-end insured with a gap by gap definition and year. Separate design-based estimates; years are not pooled."),
            ("figS3_monthly_uninsured_gap_group_2024", "Figure S3. Share uninsured in each month among class B, 2024. Subgroup estimates do not meet the NCHS presentation standard and describe timing only."),
            ("fig1_yearend_vs_continuity_2023", "Figure S4. Year-end status versus monthly continuity, 2023 replication.")]
    return "\n\n".join(f"![{cap}]({prefix}{name}.png)\n\n*{cap}*" for name, cap in figs)


def recon_table() -> str:
    roll = pd.read_csv(paths.TABLES / "validation_reconciliation_rollup.csv")
    rows = [[r["year"], "Source reconciliation" if r["kind"] == "source reconciliation" else "Software cross-check",
             CHECK_LABELS.get(r["check"], r["check"]), f"{int(r['n_checked']):,}", int(r["n_mismatch"]),
             "Informational" if r["informational"] else ("Pass" if r["n_mismatch"] == 0 else "Fail")]
            for _, r in roll.iterrows()]
    return md_table(["Year", "Kind", "Check", "Records checked", "Mismatches", "Status"], rows)


def rx_state_table() -> str:
    rows = []
    for year in ("2024", "2023"):
        s = pd.read_csv(paths.TABLES / f"rx_states_unweighted_{year}.csv")
        for _, r in s.iterrows():
            rows.append([year, CLASS_LABEL.get(r["cls_label"], r["cls_label"]), STATE_LABELS.get(r["rx_state"], r["rx_state"]), int(r["N"])])
    return "Unweighted counts of prescription states in the primary domain. No record had missing expenditure.\n\n" + md_table(["Year", "Class", "State", "Unweighted n"], rows)


def release_rows() -> str:
    man = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
    rows = []
    for k, v in man["releases"].items():
        dp = v["detail_page_check"]
        dz = v["files"]["data_zip"]
        rows.append(f"| {v['puf']}: {dp['page_title']} | {v['role'].replace('_', ' ')} | {v['reference_period']} | {dp['release_date']} | "
                    f"{dz['path'].split('/')[-1]}, SHA-256 {dz['sha256'][:16]}... |")
    return "\n".join(rows)


def amendments() -> str:
    """Numbered amendment items from the analysis plan, without the internal recording notes."""
    plan = (paths.DOCS / "analysis_plan.md").read_text(encoding="utf-8")
    i = plan.find("## Amendments")
    items = [ln.replace("`", "") for ln in plan[i:].splitlines() if re.match(r"^\d+\. ", ln)]
    return "\n".join(items)


def word_count(text: str) -> int:
    t = re.sub(r"<sup>.*?</sup>", "", text)
    t = re.sub(r"^#+ .*$", "", t, flags=re.M)
    t = re.sub(r"[*_`|]", " ", t)
    return len(re.findall(r"[A-Za-z0-9$%][A-Za-z0-9$%.,'\-/]*", t))


def section(text: str, start: str, end: str | None) -> str:
    i = text.find(start)
    j = text.find(end, i + 1) if end else len(text)
    return text[i:j]


def manuscript_title() -> str:
    first = (paths.MANUSCRIPT / "manuscript_template.md").read_text(encoding="utf-8").splitlines()[0]
    return first.lstrip("# ").strip()


def build_context() -> dict:
    ctx, claims = results.collect()
    est = json.loads((paths.OUTPUTS / "estimates_2024.json").read_text(encoding="utf-8"))
    est23 = json.loads((paths.OUTPUTS / "estimates_2023.json").read_text(encoding="utf-8"))
    ctx["survey_version"] = est["survey_version"]
    ctx["r_version"] = est["r_version"]
    m = re.search(r"R version (\d+\.\d+\.\d+)", est["r_version"])
    ctx["r_version_short"] = f"R version {m.group(1)}" if m else est["r_version"]
    ctx["n_psus_2023"] = str(est23["design"]["n_psus"])
    plan = (paths.DOCS / "analysis_plan.md").read_text(encoding="utf-8")
    ctx["n_amendments"] = str(len(re.findall(r"^\d+\. ", plan[plan.find("## Amendments"):], flags=re.M)))
    a = pd.read_csv(paths.PROCESSED / "analysis_2024.csv", dtype={"person_id": str})
    py = a[a["part_year_in_frame_y"] == 1]
    if len(py) == 1:
        r = py.iloc[0]
        ctx["part_year_desc"] = (f"The one adult in scope on December 31 but not all year was {'insured' if r['year_end_insured'] == 1 else 'uninsured'} on December 31 "
                                 f"and in scope for {12 - int(r['n_months_out_of_scope'])} months; with {int(r['n_months_out_of_scope'])} months unobserved, "
                                 f"that person's continuity is indeterminate.")
    else:
        ctx["part_year_desc"] = f"{len(py)} adults were in scope on December 31 but not all year."
    sc = pd.read_csv(paths.TABLES / "scope_agreement_frame_y_2024.csv")
    agree = int(sc.loc[sc["monthly_rule_full_year_scope"] == False, "False"].sum() + sc.loc[sc["monthly_rule_full_year_scope"] == True, "True"].sum())  # noqa: E712
    total = int(sc[["False", "True"]].to_numpy().sum())
    ctx["scope_agreement_sentence"] = (f"Among the {total:,} adults with diabetes who were in scope on December 31 with a year-end coverage value, the monthly rule and the round-level scope variables "
                                       f"agreed for {agree:,} (Table S1).")
    aud = pd.read_csv(paths.TABLES / "audit_rules_2024.csv").set_index("item")["n"]
    ctx["rule_counts_2024"] = (f"rule 1 to {int(aud['rule_1']):,} records, rule 2 to {int(aud['rule_2']):,}, rule 3 to {int(aud['rule_3']):,}, "
                               f"rule 4 to {int(aud['rule_4']):,}, and rule 5 to {int(aud['rule_5']):,} (all ages and scope patterns)")
    ctx["release_rows"] = release_rows()
    ctx["recon_table"] = recon_table()
    ctx["rx_state_table"] = rx_state_table()
    ctx["amendments"] = amendments()
    ctx["claims"] = claims
    return ctx


def render_text(template_name: str, ctx: dict) -> str:
    env = jinja2.Environment(undefined=jinja2.StrictUndefined, autoescape=False, keep_trailing_newline=True)
    tmpl = env.from_string((paths.MANUSCRIPT / template_name).read_text(encoding="utf-8"))
    return tmpl.render(**ctx)


def manuscript_parts(ctx: dict) -> dict:
    """Numbered body, references, tables, and legends, shared by the report and the journal files."""
    body = neg(render_text("manuscript_template.md", ctx))
    refs = references.reference_strings()
    body, numbered = references.number_citations(body, refs)
    reflist = "\n".join(f"{n}. {html.escape(s, quote=False)}" for n, k, s in numbered)
    tables = {
        1: ("Table 1. Characteristics of adults aged 18 to 64 with diagnosed diabetes, by coverage continuity class, MEPS 2024",
            "Weighted percentages (95% CI, logit). CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey. Primary domain: in scope all 12 months. "
            "Class A, insured on December 31 and in all 12 months; class B, insured on December 31 with at least 1 uninsured month; class C, uninsured on December 31. "
            f"{DAGGER_NOTE}", table1()),
        2: ("Table 2. Annual prescription use and out-of-pocket spending by coverage representation, MEPS 2024",
            "Estimates (95% CI). CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey; OOP, out-of-pocket (self or family payments for all "
            "prescribed medicines, nominal 2024 dollars); Rx, prescription. The first 4 columns share the primary-domain denominator; the last column uses the "
            "classification-specific denominator (everyone in scope on December 31, including part-year in scope). Class definitions as in Table 1. Medians and "
            f"90th percentiles use Woodruff intervals. {FLAG_NOTE}", neg(table2())),
        3: ("Table 3. Robustness of the primary estimate and standardized out-of-pocket spending, MEPS 2024 and 2023",
            "CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey; OOP, out-of-pocket. Proportions use logit 95% CIs with the unweighted "
            "numerator and denominator. Standardized means come from a survey-weighted two-part model adjusted for age group, sex, race and ethnicity, and family "
            "income, with jackknife replicate CIs. Class A, insured on December 31 and in all 12 months; class B, insured on December 31 with at least 1 uninsured "
            "month; class C, uninsured on December 31. Years are estimated separately and not pooled.", table3()),
    }
    legends = [
        "**Figure 1.** The same adults classified by year-end coverage (left) and by monthly continuity (right), Medical Expenditure Panel Survey 2024. "
        "Bar heights are weighted shares of adults aged 18 to 64 with diagnosed diabetes in scope all year; labels on the right bar give unweighted counts.",
        "**Figure 2.** Annual out-of-pocket prescription spending by continuity class, Medical Expenditure Panel Survey 2024. Points are design-based estimates "
        "and lines are 95% confidence intervals; medians use Woodruff intervals. Group sizes are unweighted; user subgroups are smaller. * Relative standard error "
        "above 30% or not estimable, or fewer than 30 people.",
    ]
    counts = {"abstract_words": word_count(section(body, "## Abstract", "**Key Words:**")),
              "main_text_words": word_count(section(body, "## Introduction", None)),
              "references": len(numbered), "tables": 3, "figures": 2}
    return {"body": body, "numbered": numbered, "reflist": reflist, "tables": tables, "legends": legends, "counts": counts}


def assemble_manuscript(ctx: dict, fig_prefix: str) -> tuple[str, list, dict]:
    """Readable full version (tables and figures included) for the report and the Markdown file."""
    pt = manuscript_parts(ctx)
    tabs = "\n\n".join(f"### {t}\n\n{leg}\n\n{body}" for t, leg, body in pt["tables"].values())
    legs = "\n\n".join(pt["legends"])
    text = (pt["body"] + f"\n## References\n\n{pt['reflist']}\n\n## Tables\n\n{tabs}\n\n## Figure legends\n\n{legs}\n\n"
            f"![Figure 1]({fig_prefix}fig1_yearend_vs_continuity_2024.png)\n\n![Figure 2]({fig_prefix}fig2_oop_spending_2024.png)\n")
    return text, pt["numbered"], pt["counts"]


CSS = """
:root { --bg:#fbfbf9; --text:#1c1c1a; --muted:#55544f; --rule:#dddcd6; --accent:#1f5fa8; --soft:#f1f0ec; --mark:#eb6834; }
html { color-scheme: light; }
* { box-sizing: border-box; }
html { -webkit-text-size-adjust: 100%; }
body { margin:0; background:var(--bg); color:var(--text); font: 17px/1.6 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; }
a { color: var(--accent); text-underline-offset: 2px; }
a:focus-visible, button:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }
.skip { position:absolute; left:-999px; top:0; background:#fff; padding:8px 12px; }
.skip:focus { left:16px; top:16px; z-index:10; }
header.site, main, footer { max-width: 1040px; margin: 0 auto; padding: 0 16px; }
header.site { padding-top: 20px; padding-bottom: 8px; font-size: 15px; color: var(--muted); display:flex; gap:16px; flex-wrap:wrap; justify-content:space-between; }
main { padding-bottom: 64px; }
.prose { max-width: 720px; }
h1 { font-size: clamp(28px, 4vw, 40px); line-height: 1.2; letter-spacing: -0.01em; margin: 24px 0 12px; }
h2 { font-size: 24px; line-height: 1.3; margin: 48px 0 12px; padding-top: 12px; border-top: 1px solid var(--rule); }
h3 { font-size: 19px; margin: 28px 0 8px; }
p { margin: 0 0 14px; overflow-wrap: break-word; }
li { overflow-wrap: anywhere; }
.lede { font-size: 20px; color: var(--muted); max-width: 720px; }
.question { background: var(--soft); border-left: 4px solid var(--accent); padding: 14px 16px; margin: 20px 0; max-width: 760px; }
figure { margin: 24px 0; }
figure img { width: 100%; height: auto; border: 1px solid var(--rule); background: #fcfcfb; }
figcaption { font-size: 15px; color: var(--muted); margin-top: 8px; max-width: 760px; }
.stats { display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin: 24px 0; }
.stat { border: 1px solid var(--rule); border-radius: 8px; padding: 14px; background: #fff; }
.stat .v { font-size: 28px; font-weight: 600; }
.stat .l { font-size: 15px; color: var(--muted); }
.table-wrap { overflow-x: auto; margin: 12px 0 20px; border: 1px solid var(--rule); border-radius: 6px; background:#fff; }
table { border-collapse: collapse; width: 100%; font-size: 14px; font-variant-numeric: tabular-nums; }
th, td { text-align: left; padding: 7px 10px; border-bottom: 1px solid var(--rule); vertical-align: top; }
th { background: var(--soft); font-weight: 600; }
code { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 0.9em; background: var(--soft); padding: 1px 4px; border-radius: 4px; }
pre { background: var(--soft); padding: 12px; overflow-x: auto; border-radius: 6px; font-size: 14px; }
ul.files { padding-left: 20px; }
.toc { font-size: 15px; }
.note { font-size: 15px; color: var(--muted); }
sup { line-height: 0; }
footer { color: var(--muted); font-size: 14px; border-top: 1px solid var(--rule); padding-top: 16px; padding-bottom: 32px; }
@media (max-width: 640px) { body { font-size: 16px; } h2 { font-size: 21px; } .lede { font-size: 18px; }
  figure { overflow-x: auto; -webkit-overflow-scrolling: touch; }
  figure img { min-width: 680px; }
  figure figcaption { position: sticky; left: 0; max-width: calc(100vw - 32px); } }
"""


def md_to_html(text: str) -> str:
    h = md.markdown(text, extensions=["tables", "attr_list", "toc", "sane_lists"], output_format="html5")
    h = re.sub(r"<table>", '<div class="table-wrap"><table>', h)
    h = h.replace("</table>", "</table></div>")
    h = re.sub(r'<p><img alt="([^"]*)" src="([^"]+)" ?/?></p>', r'<figure><img alt="\1" src="\2" loading="lazy"></figure>', h)
    return h


def html_page(title: str, body: str, description: str, crumbs: str = "") -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(description)}">
<link rel="stylesheet" href="assets/site.css?v={hashlib.sha256(CSS.encode()).hexdigest()[:10]}">
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site"><span>{crumbs}</span><span><a href="index.html">Project page</a> | <a href="report.html">Full report</a></span></header>
<main id="main">
{body}
</main>
<footer>Data: Agency for Healthcare Research and Quality, Medical Expenditure Panel Survey public-use files HC-256, HC-254A, and HC-251. I calculated these estimates. AHRQ has not endorsed them.</footer>
</body>
</html>
"""


PAGEBREAK = "<!-- pagebreak -->"


def write_docx(text: str, out: Path, base_dir: Path, author: str = "", title: str = "", double: bool = False,
               page_numbers: bool = False, images: bool = True, table_font: int = 9, landscape: bool = False) -> None:
    """Markdown subset to Word. Journal mode: 12-point Times New Roman, 1-inch margins, double spacing
    for text (tables single spaced), page number in the footer and no other header or footer text."""
    from docx import Document
    from docx.enum.text import WD_BREAK, WD_LINE_SPACING
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches, Pt

    doc = Document()
    cp = doc.core_properties
    cp.author = author
    cp.last_modified_by = author
    cp.title = title
    cp.comments = ""
    cp.subject = ""
    cp.keywords = ""
    cp.category = ""
    import datetime as _dt
    _now = _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0, tzinfo=None)
    cp.created = _now
    cp.modified = _now
    cp.revision = 1
    for sec in doc.sections:
        if landscape:
            from docx.enum.section import WD_ORIENT
            sec.orientation = WD_ORIENT.LANDSCAPE
            sec.page_width, sec.page_height = sec.page_height, sec.page_width
        sec.left_margin = sec.right_margin = sec.top_margin = sec.bottom_margin = Inches(1)
        if page_numbers:
            p = sec.footer.paragraphs[0]
            p.alignment = 2  # right
            run = p.add_run()
            for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
                if tag:
                    el = OxmlElement("w:fldChar")
                    el.set(qn("w:fldCharType"), tag)
                else:
                    el = OxmlElement("w:instrText")
                    el.set(qn("xml:space"), "preserve")
                    el.text = txt
                run._r.append(el)
    for name in ("Normal", "Heading 1", "Heading 2", "Heading 3", "Heading 4", "Title"):
        try:
            st = doc.styles[name]
        except KeyError:
            continue
        st.font.name = "Times New Roman"
        st.font.size = Pt(12)
        st.font.color.rgb = None
        if double:
            st.paragraph_format.line_spacing_rule = WD_LINE_SPACING.DOUBLE
        st.paragraph_format.space_after = Pt(0) if double else Pt(6)

    def add_inline(par, s: str) -> None:
        s = html.unescape(s.replace("&nbsp;", " ")).replace("`", "")
        tokens = re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|<sup>[^<]+</sup>)", s)
        for tk in tokens:
            if not tk:
                continue
            if tk.startswith("**"):
                par.add_run(tk[2:-2]).bold = True
            elif tk.startswith("<sup>"):
                par.add_run(tk[5:-6]).font.superscript = True
            elif tk.startswith("*") and tk.endswith("*") and len(tk) > 2:
                par.add_run(tk[1:-1]).italic = True
            else:
                par.add_run(tk)

    lines = text.split("\n")
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.strip() == PAGEBREAK:
            doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        elif ln.startswith("#"):
            level = len(ln) - len(ln.lstrip("#"))
            h = doc.add_heading(ln.lstrip("#").strip(), level=min(level, 4))
            for r in h.runs:
                r.font.name = "Times New Roman"
                r.font.color.rgb = None
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"-+", c) for c in cells):
                    rows.append(cells)
                i += 1
            ncol = max(len(r) for r in rows)
            t = doc.add_table(rows=len(rows), cols=ncol)
            t.style = "Table Grid"
            if doc.paragraphs and doc.paragraphs[-1].text:
                doc.paragraphs[-1].paragraph_format.keep_with_next = True
            for ri, row in enumerate(t.rows):
                trpr = row._tr.get_or_add_trPr()
                trpr.append(OxmlElement("w:cantSplit"))
                if ri == 0:
                    trpr.append(OxmlElement("w:tblHeader"))
            for ri, r in enumerate(rows):
                for ci in range(ncol):
                    cell = t.cell(ri, ci)
                    cell.text = ""
                    par = cell.paragraphs[0]
                    par.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
                    add_inline(par, r[ci] if ci < len(r) else "")
                    for run in par.runs:
                        run.font.size = Pt(table_font)
                        if ri == 0:
                            run.bold = True
            continue
        elif ln.startswith("!["):
            m = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", ln)
            if m and images:
                p = (base_dir / m.group(2)).resolve()
                if p.exists():
                    doc.add_picture(str(p), width=Inches(6.3))
                    following = next((x for x in lines[i + 1:] if x.strip()), "")
                    if following.startswith("*Figure"):
                        doc.paragraphs[-1].paragraph_format.keep_with_next = True
        elif ln.strip():
            par = doc.add_paragraph()
            add_inline(par, ln)
            if par._p.getprevious() is not None and par._p.getprevious().tag == qn("w:tbl"):
                par.paragraph_format.keep_together = True
        i += 1
    doc.save(out)


def run() -> dict:
    from . import runtime
    runtime.write()
    figures.run()
    wb = workbook.run()
    claims = results.write_claims()
    ctx = build_context()
    paths.MANUSCRIPT.mkdir(exist_ok=True)

    # Manuscript (blinded) and supplement, with figure paths relative to the manuscript folder.
    man_text, numbered, counts = assemble_manuscript(ctx, "../outputs/figures/")
    (paths.MANUSCRIPT / "manuscript.md").write_text(man_text, encoding="utf-8")
    references.write_verified_list(numbered, paths.DOCS / "references_verified.csv")
    ctx_s = dict(ctx)
    ctx_s["supp_figures"] = supplementary_figures("../outputs/figures/")
    ctx_s["supp_tables"] = supplementary_tables()
    supp_text = neg(render_text("supplement_template.md", ctx_s))
    (paths.MANUSCRIPT / "supplement.md").write_text(supp_text, encoding="utf-8")
    from . import site
    site_info = site.build(ctx, man_text, supp_text, counts)
    try:
        from . import submission  # private journal package; not part of the public source archive
    except ImportError:
        submission = None
    sub_info = submission.build(ctx, supp_text) if submission else "journal package module not present"
    stamp = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    manifest = {"rendered_utc": stamp, "renderer": f"python-markdown {md.__version__} with a project HTML template; python-docx for Word files (Quarto and pandoc not available on this machine)",
                "counts": counts, "claims": len(claims["claims"]), "workbook": wb, "site": site_info,
                "journal_package": "built" if isinstance(sub_info, dict) else sub_info}
    (paths.LOGS / "render_manifest.json").write_text(json.dumps(manifest, indent=2, default=str), encoding="utf-8")
    print(f"[render] words: abstract {counts['abstract_words']}, main {counts['main_text_words']}; references {counts['references']}; claims {len(claims['claims'])}")
    return manifest
