"""Figures drawn from the analysis output tables (never from person-level data directly).

Classes A, B, and C are drawn in blue, orange, and aqua; each pair was checked to be
distinguishable on a light background. Aqua is below 3:1 contrast with the background,
so every mark is labeled directly and each figure has a table view in the report.
"""

from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle  # noqa: E402
import pandas as pd  # noqa: E402

from . import paths  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"
C_A, C_B, C_C, C_D = "#2a78d6", "#eb6834", "#1baf7a", "#9a9893"

plt.rcParams.update({
    "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 10.5, "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.titlecolor": INK, "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "svg.fonttype": "none",
})


def blend(color: str, alpha: float, base: str = SURFACE) -> str:
    """Solid color equal to `color` at `alpha` over `base`."""
    c = [int(color[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(base[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(alpha * x + (1 - alpha) * y):02x}" for x, y in zip(c, b))


def _save(fig, name: str) -> list[str]:
    out = []
    for ext in ("png", "svg"):
        p = paths.FIGURES / f"{name}.{ext}"
        fig.savefig(p, dpi=200 if ext == "png" else None, bbox_inches="tight")
        out.append(paths.rel(p))
    plt.close(fig)
    return out


def pct(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}%"


def fig_flow(year: str = "2024", notes: bool = True, compact: bool = False) -> list[str]:
    """Lead figure: the same people under the year-end indicator and under monthly continuity."""
    xt = pd.read_csv(paths.TABLES / f"yearend_by_continuity_{year}.csv").set_index("class")
    prim = pd.read_csv(paths.TABLES / f"primary_estimate_{year}.csv").iloc[0]
    sA, sB, sC = (float(xt.loc[k, "estimate"]) for k in ("insured_year_end_continuous", "insured_year_end_gap", "uninsured_year_end"))
    sD = float(xt.loc["indeterminate", "estimate"]) if "indeterminate" in xt.index else 0.0
    nA, nB, nC = (int(xt.loc[k, "numerator_unweighted"]) for k in ("insured_year_end_continuous", "insured_year_end_gap", "uninsured_year_end"))
    n_all = int(xt["n_unweighted"].iloc[0])

    fig, ax = plt.subplots(figsize=(6.9, 4.3) if compact else (9.2, 4.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(-0.08, 1.14)
    ax.axis("off")
    gap = 0.006
    xl, xr, w = (0.19, 0.50, 0.09) if compact else (0.17, 0.58, 0.10)
    fl, ft = (8.5, 9.0) if compact else (10, 10.5)

    def seg(x, y0, h, color, label_lines, inside=True):
        ax.add_patch(Rectangle((x, y0 + gap / 2), w, max(h - gap, 0.001), color=color, lw=0))

    # Left bar: year-end indicator. Top = insured on 12/31 (A + B), bottom = uninsured on 12/31 (C).
    top_ins = 1.0
    ins_h = sA + sB
    seg(xl, top_ins - ins_h, ins_h, "#5f6b7a", [])
    seg(xl, top_ins - ins_h - sC, sC, C_C, [])
    ax.text(xl + w / 2, 1.05, "Year-end indicator\n(covered on 12/31)", ha="center", va="bottom", color=INK, fontsize=ft, weight="bold")
    ax.text(xl - 0.012, top_ins - ins_h / 2, f"Insured on 12/31\n{pct(ins_h)}", va="center", ha="right", color=INK, fontsize=fl)
    ax.text(xl - 0.012, top_ins - ins_h - sC / 2, f"Uninsured on 12/31\n{pct(sC)}", va="center", ha="right", color=INK, fontsize=fl)

    # Right bar: monthly continuity.
    yA0 = top_ins - sA
    yB0 = yA0 - sB
    yC0 = yB0 - sC
    seg(xr, yA0, sA, C_A, [])
    seg(xr, yB0, sB, C_B, [])
    seg(xr, yC0, sC, C_C, [])
    ax.text(xr + w / 2, 1.05, "Monthly continuity\n(all 12 months observed)", ha="center", va="bottom", color=INK, fontsize=ft, weight="bold")

    # Bands from the left segments to the right classes.
    def band(y_top_l, y_bot_l, y_top_r, y_bot_r, color, alpha):
        # Pre-blended with the surface so vector formats without transparency (EPS) look the same.
        ax.add_patch(Polygon([(xl + w, y_top_l - gap / 2), (xr, y_top_r - gap / 2), (xr, y_bot_r + gap / 2), (xl + w, y_bot_l + gap / 2)],
                             closed=True, color=blend(color, alpha), lw=0))
    band(top_ins, top_ins - sA, top_ins, yA0, C_A, 0.16)
    band(top_ins - sA, top_ins - ins_h, yA0, yB0, C_B, 0.35)
    band(top_ins - ins_h, top_ins - ins_h - sC, yB0, yC0, C_C, 0.14)

    lx = xr + w + (0.035 if compact else 0.05)
    ax.text(lx, yA0 + sA / 2, f"Insured all 12 months\n{pct(sA)} (n = {nA:,})", va="center", color=INK, fontsize=fl)
    yb_lab = yB0 + sB / 2 + 0.07
    ax.annotate(f"Insured on 12/31, uninsured for at\nleast one month: {pct(sB)} (n = {nB:,})", xy=(xr + w + 0.004, yB0 + sB / 2),
                xytext=(lx, yb_lab), va="center", color=INK, fontsize=fl, weight="bold",
                arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8, shrinkA=2, shrinkB=0))
    yc_lab = yC0 + sC / 2 - 0.07
    ax.annotate(f"Uninsured on 12/31\n{pct(sC)} (n = {nC:,})", xy=(xr + w + 0.004, yC0 + sC / 2), xytext=(lx, yc_lab),
                va="center", color=INK, fontsize=fl, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.8, shrinkA=2, shrinkB=0))
    note = (f"Weighted shares of US adults aged 18 to 64 with diagnosed diabetes, in scope all of {year} (unweighted n = {n_all:,}). "
            f"Among those insured on 12/31, {pct(prim['estimate'])} (95% CI {pct(prim['ci_low'])} to {pct(prim['ci_high'])}) "
            f"had at least one fully uninsured month.")
    if sD > 0:
        note += f" Indeterminate continuity: {pct(sD)}."
    if notes:
        fig.text(0.02, 0.0, note + f"\nSource: AHRQ MEPS {'HC-256' if year == '2024' else 'HC-251'}, Full Year Consolidated File; design-based estimates.",
                 color=INK2, fontsize=8.6, wrap=True, ha="left", va="top")
    return _save(fig, f"fig1_yearend_vs_continuity_{year}")


def fig_spending(year: str = "2024", notes: bool = True, compact: bool = False) -> list[str]:
    """Annual OOP prescription spending: mean incl. zeros, mean and median among users, with 95% CIs."""
    rx = pd.read_csv(paths.TABLES / f"rx_outcomes_{year}.csv")
    groups = [("C3 Domain C: A insured all 12 months", "Insured all\n12 months", C_A),
              ("C4 Domain C: B insured on 12/31 with gap", "Insured on 12/31,\n≥1 uninsured month", C_B),
              ("C5 Domain C: C uninsured on 12/31", "Uninsured\non 12/31", C_C)]
    measures = [("Mean OOP Rx spending incl. zeros (USD)", "Mean, all persons\n(zeros included)"),
                ("Mean OOP Rx spending among users (USD)", "Mean among persons\nwith any fill"),
                ("OOP Rx spending among users (USD) p50", "Median among persons\nwith any fill")]
    if compact:
        fig, axes = plt.subplots(3, 1, figsize=(6.9, 6.4), sharey=False)
        measures = [(k, lab.replace("\n", " ")) for k, lab in measures]
    else:
        fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.9), sharey=False)
    for ax, (mkey, mlab) in zip(axes, measures):
        vals = []
        for gkey, glab, col in groups:
            r = rx[(rx["group"] == gkey) & (rx["measure"] == mkey)]
            if r.empty:
                continue
            r = r.iloc[0]
            vals.append((glab, col, r["estimate"], r["ci_low"], r["ci_high"], int(r["n_unweighted"]), r["reliability"]))
        ys = list(range(len(vals)))[::-1]
        top = max(v[4] for v in vals) * 1.25
        for y, (glab, col, est, lo, hi, n, flag) in zip(ys, vals):
            ax.plot([max(lo, 0), hi], [y, y], color=col, lw=2, solid_capstyle="round")
            ax.plot([est], [y], "o", ms=8, color=col, mec=SURFACE, mew=2)
            lab = f"${est:,.0f}"
            if flag not in ("ok",):
                lab += " *"
            ax.text(hi + top * 0.02, y, lab, va="center", color=INK, fontsize=9.5)
        ax.set_yticks(ys)
        show_labels = compact or ax is axes[0]
        ax.set_yticklabels([f"{v[0]}\n(n = {v[5]:,})" if not compact else f"{v[0].replace(chr(10), ' ')} (n = {v[5]:,})" for v in vals]
                           if show_labels else [""] * len(vals), fontsize=8.5 if compact else 9)
        ax.set_xlim(0, top * 1.15)
        ax.set_title(mlab, fontsize=10, color=INK, loc="left")
        ax.grid(axis="x", color=GRID, lw=0.8)
        ax.set_axisbelow(True)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.tick_params(axis="y", length=0)
        ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"${v:,.0f}"))
        if compact:
            ax.xaxis.set_major_locator(matplotlib.ticker.MaxNLocator(nbins=5, steps=[1, 2, 2.5, 5, 10]))
    if notes:
        fig.text(0.01, -0.06, (f"Annual out-of-pocket (self or family) payments for all prescribed medicines, {year} US dollars, adults 18 to 64 with diagnosed diabetes "
                               f"in scope all year. Points are design-based estimates; lines are 95% CIs (Woodruff intervals for medians). "
                               f"n in the left labels is the unweighted group size; user subgroups are smaller (see table). * flagged as imprecise (RSE > 30% or n < 30)."),
                 color=INK2, fontsize=8.4, wrap=True, ha="left", va="top")
    fig.tight_layout()
    return _save(fig, f"fig2_oop_spending_{year}")


def fig_monthly(year: str = "2024") -> list[str]:
    m = pd.read_csv(paths.TABLES / f"monthly_uninsured_gap_group_{year}.csv").sort_values("month")
    labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    fig, ax = plt.subplots(figsize=(8.4, 3.4))
    x = m["month"].to_numpy()
    ax.fill_between(x, m["ci_low"], m["ci_high"], color=C_B, alpha=0.10, lw=0)
    ax.plot(x, m["estimate"], color=C_B, lw=2, solid_capstyle="round")
    ax.plot(x, m["estimate"], "o", ms=6, color=C_B, mec=SURFACE, mew=2)
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_ylim(0, 1)
    ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    ax.grid(axis="y", color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    n = int(m["n_unweighted"].iloc[0])
    jan = m.iloc[0]
    ax.text(1.15, jan["estimate"], f"{pct(jan['estimate'], 0)} uninsured in January", va="bottom", color=INK, fontsize=9.5)
    ax.set_title(f"Share uninsured in each month, people insured on 12/31 who had a gap (n = {n:,})", loc="left", fontsize=10.5, color=INK)
    fig.text(0.01, -0.03, "Weighted shares with 95% CIs (logit). December is covered by definition of the group. Monthly coverage means coverage on at least one day of the month.\n"
             "These subgroup estimates (n = 70) do not meet the NCHS presentation standard for proportions (CI width of 30 points or more for January to July); read them as a description of timing, not as precise rates.",
             color=INK2, fontsize=8.4, wrap=True, ha="left", va="top")
    fig.tight_layout()
    return _save(fig, f"figS3_monthly_uninsured_gap_group_{year}")


def fig_cohort_flow(year: str = "2024") -> list[str]:
    flow = pd.read_csv(paths.TABLES / f"cohort_flow_{year}.csv")
    cls = pd.read_csv(paths.TABLES / f"class_counts_unweighted_{year}.csv").set_index("continuity_class")["n_unweighted"]
    excl = pd.read_csv(paths.TABLES / f"cohort_exclusions_{year}.csv").set_index("group")["n_unweighted"]
    fig, ax = plt.subplots(figsize=(8.6, 7.4))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ys = [9.3, 7.9, 6.5, 5.1, 3.7, 2.3]
    for (i, r), y in zip(flow.iterrows(), ys):
        ax.add_patch(FancyBboxPatch((0.3, y - 0.45), 5.6, 0.9, boxstyle="round,pad=0.02,rounding_size=0.08", fc="#f2f1ee", ec=GRID, lw=1))
        desc = (r["description"].replace(" (frame Y)", "").replace(" (primary domain C)", " (primary domain)")
                .replace("Positive person weight (PERWT > 0)", "Positive full-year person weight"))
        ax.text(0.5, y + 0.12, desc, va="center", fontsize=9.4, color=INK)
        ax.text(0.5, y - 0.2, f"n = {int(r['n_unweighted']):,} records", va="center", fontsize=9, color=INK2)
        if i < len(flow) - 1:
            ax.annotate("", xy=(3.1, ys[i + 1] + 0.47), xytext=(3.1, y - 0.47), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=1))
    n = flow["n_unweighted"].astype(int).tolist()
    side = [
        f"Zero person weight: {n[0] - n[1]:,}",
        f"Outside ages 18 to 64 on 12/31\n(includes not in scope then): {n[1] - n[2]:,}",
        "Diabetes not reported: " + f"{n[2] - n[3]:,}\n(no {int(excl.get('Adults 18 to 64, positive weight: diabetes = 2 (no)', 0)):,}; refused "
        f"{int(excl.get('Adults 18 to 64, positive weight: diabetes = -7 (refused)', 0)):,}; don't know "
        f"{int(excl.get('Adults 18 to 64, positive weight: diabetes = -8 (don\'t know)', 0)):,})",
        f"Not in scope on 12/31 or no year-end value: {n[3] - n[4]:,}",
        f"Part-year in scope, described separately: {n[4] - n[5]:,}",
    ]
    for i, t in enumerate(side):
        ymid = (ys[i] + ys[i + 1]) / 2
        ax.add_patch(FancyBboxPatch((6.2, ymid - 0.33), 3.75, 0.66, boxstyle="round,pad=0.02,rounding_size=0.08", fc=SURFACE, ec=GRID, lw=1))
        ax.text(6.33, ymid, t, va="center", fontsize=8.2, color=INK2)
        ax.annotate("", xy=(6.2, ymid), xytext=(3.1, ymid), arrowprops=dict(arrowstyle="-", color=GRID, lw=1))
    labels = [("insured_year_end_continuous", "Insured all\n12 months", C_A), ("insured_year_end_gap", "Insured 12/31,\n≥1 uninsured month", C_B),
              ("uninsured_year_end", "Uninsured\non 12/31", C_C), ("indeterminate", "Continuity\nindeterminate", C_D)]
    xs = [0.3, 2.75, 5.2, 7.65]
    for (k, lab, col), x in zip(labels, xs):
        ax.add_patch(FancyBboxPatch((x, 0.25), 2.2, 1.05, boxstyle="round,pad=0.02,rounding_size=0.08", fc=SURFACE, ec=col, lw=2))
        ax.text(x + 0.15, 0.95, lab, va="center", fontsize=8.8, color=INK)
        ax.text(x + 0.15, 0.45, f"n = {int(cls.get(k, 0)):,}", va="center", fontsize=9, color=INK2)
        ax.annotate("", xy=(x + 1.1, 1.32), xytext=(3.1, ys[-1] - 0.47), arrowprops=dict(arrowstyle="-|>", color=INK2, lw=0.8))
    return _save(fig, f"figS1_cohort_flow_{year}")


def fig_robustness() -> list[str]:
    rows = []
    for year in ("2024", "2023"):
        p = pd.read_csv(paths.TABLES / f"primary_estimate_{year}.csv")
        for _, r in p.iterrows():
            lab = "≥1 uninsured month" if r["measure"].startswith("Year-end insured with >=1") else "≥3 consecutive uninsured months"
            rows.append((f"{year}: {lab}", r["estimate"], r["ci_low"], r["ci_high"], int(r["n_unweighted"]), int(r["numerator_unweighted"]),
                         C_B if year == "2024" else "#7d7a73"))
    fig, ax = plt.subplots(figsize=(8.2, 2.9))
    ys = list(range(len(rows)))[::-1]
    for y, (lab, est, lo, hi, n, k, col) in zip(ys, rows):
        ax.plot([lo, hi], [y, y], color=col, lw=2, solid_capstyle="round")
        ax.plot([est], [y], "o", ms=8, color=col, mec=SURFACE, mew=2)
        ax.text(hi + 0.004, y, f"{pct(est)} ({pct(lo)} to {pct(hi)}); {k:,}/{n:,}", va="center", fontsize=9, color=INK)
    ax.set_yticks(ys)
    ax.set_yticklabels([r[0] for r in rows], fontsize=9.2)
    ax.xaxis.set_major_locator(matplotlib.ticker.MultipleLocator(0.02))
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0, decimals=0))
    xmax = max(r[3] for r in rows)
    ax.set_xlim(0, xmax * 1.9)
    ax.grid(axis="x", color=GRID, lw=0.8)
    ax.set_axisbelow(True)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.set_title("Share of people insured on 12/31 with a within-year gap, by gap definition and year", loc="left", fontsize=10.2, color=INK)
    fig.text(0.01, -0.04, "Separate design-based estimates for each year (not pooled; Panel 28 contributes to both years). Labels show estimate (95% CI); unweighted numerator/denominator.",
             color=INK2, fontsize=8.4, wrap=True, ha="left", va="top")
    fig.tight_layout()
    return _save(fig, "figS2_robustness_gap_definitions")


def submission_artwork(outdir) -> list[str]:
    """Figures 1 and 2 for journal upload: no legend text in the file; vector PDF and EPS, and 1200 dpi TIFF."""
    outdir.mkdir(parents=True, exist_ok=True)
    made = []
    for fn, label in ((fig_flow, "figure 1"), (fig_spending, "figure 2")):
        orig_save = globals()["_save"]

        def capture(fig, nm, _label=label):
            for ext, kw in (("pdf", {}), ("eps", {}), ("tiff", {"dpi": 1200})):
                p = outdir / f"{_label}.{ext}"
                fig.savefig(p, bbox_inches="tight", pad_inches=0.02, **kw)
                if ext == "tiff":
                    from PIL import Image
                    with Image.open(p) as im:
                        im.convert("RGB").save(p, compression="tiff_lzw", dpi=(1200, 1200))
                made.append(p.name)
            plt.close(fig)
            return made
        globals()["_save"] = capture
        try:
            fn("2024", notes=False, compact=True)
        finally:
            globals()["_save"] = orig_save
    return made


def run() -> dict:
    paths.FIGURES.mkdir(parents=True, exist_ok=True)
    out = {}
    out["fig1"] = fig_flow("2024")
    out["fig1_2023"] = fig_flow("2023")
    out["fig2"] = fig_spending("2024")
    out["figS3"] = fig_monthly("2024")
    out["figS1"] = fig_cohort_flow("2024")
    out["figS2"] = fig_robustness()
    (paths.LOGS / "figures.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    return out
