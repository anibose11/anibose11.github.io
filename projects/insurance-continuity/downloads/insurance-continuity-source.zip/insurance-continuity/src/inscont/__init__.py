"""Coverage continuity classification and analysis pipeline for MEPS Full Year Consolidated files."""

__version__ = "1.0.0"
