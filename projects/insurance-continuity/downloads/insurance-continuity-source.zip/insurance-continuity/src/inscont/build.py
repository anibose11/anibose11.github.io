"""Build stage: raw MEPS files -> audited person and person-month tables.

For each configured year this stage
1. reads only the documented variables from the AHRQ Stata file,
2. runs the SQL transformations in sql/ with DuckDB (rendered SQL is saved for audit),
3. classifies continuity with the reusable audit function and cross-checks it against
   an independent SQL implementation,
4. reconciles the person-month table and weighted frequencies with AHRQ's annual
   indicators and printed codebook values,
5. builds frames, the cohort flow, scope agreement, and person-level transition counts,
6. aggregates the 2024 prescribed medicines file with imputation flags and reconciles it
   with the person-level totals,
7. writes data/processed/analysis_<year>.csv for the R survey analysis.
"""

from __future__ import annotations

import json
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from . import acquire, codebook, paths
from .continuity import CLASSES, classify_continuity

STATE_CODES = {"private_only": "P", "public_only": "U", "private_and_public": "B", "uninsured": "N"}


def _verify_raw_hashes() -> dict:
    """Stop if a raw file no longer matches the manifest or the analyzed release (for example, AHRQ replaced it)."""
    man = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
    acquire._EXPECTED.clear()
    acquire._load_expected()
    acquire.ACCEPT_NEW = any("accepted" in str(rec.get("expected_checksum", "")) for e in man["releases"].values() for rec in e["files"].values())
    for entry in man["releases"].values():
        for rec in entry["files"].values():
            acquire.check_expected(rec["path"], rec["sha256"])
    for key, entry in man["releases"].items():
        for kind, rec in entry["files"].items():
            p = paths.ROOT / rec["path"]
            if acquire.sha256_file(p) != rec["sha256"]:
                raise RuntimeError(f"Raw file hash changed: {rec['path']}")
            if kind == "data_zip":
                x = paths.ROOT / rec["extracted"]
                if acquire.sha256_file(x) != rec["extracted_sha256"]:
                    raise RuntimeError(f"Extracted file hash changed: {rec['extracted']}")
    return man


def variables_for_year(cfg: dict, yy: str) -> tuple[list[str], dict[str, list[str]]]:
    monthly = {fam: [t.format(mm=m, yy=yy) for m in cfg["months"]] for fam, t in cfg["monthly_templates"].items()}
    person = [t.format(yy=yy) for t in cfg["person_templates"].values()] + [f"INSDE{yy}X"]
    cols = list(dict.fromkeys(person + [c for fam in monthly.values() for c in fam]))
    return cols, monthly


def read_stata_subset(path: Path, columns: list[str]) -> tuple[pd.DataFrame, dict]:
    with pd.io.stata.StataReader(path) as rdr:
        labels = rdr.variable_labels()
    df = pd.read_stata(path, columns=columns, convert_categoricals=False, convert_missing=False)
    return df, {c: labels.get(c) for c in columns}


def render_sql(name: str, **kw) -> str:
    text = (paths.ROOT / "sql" / name).read_text(encoding="utf-8")
    for k, v in kw.items():
        text = text.replace("{" + k + "}", v)
    return text


FAM_ORDER = ["any", "private", "public", "medicare", "medicaid", "tricare", "va", "other_public", "ihs"]


def unpivot_parts(monthly: dict[str, list[str]]) -> tuple[str, str]:
    """Column groups for the DuckDB UNPIVOT (one group per month) and the flat column list."""
    groups = []
    for i in range(12):
        group_cols = ", ".join(monthly[f][i] for f in FAM_ORDER)
        groups.append(f'({group_cols}) AS "{i + 1:02d}"')
    return ",\n       ".join(groups), ", ".join(monthly[f][i] for i in range(12) for f in FAM_ORDER)


def _weighted_codebook_check(df: pd.DataFrame, entries: dict, yy: str) -> pd.DataFrame:
    """Compare weighted and unweighted frequencies with the values AHRQ printed in the codebook."""
    w = df[f"PERWT{yy}F"]
    rows = []
    for var in [f"INS{yy}X", f"INSCOV{yy}", f"UNINS{yy}", f"INSJA{yy}X", f"INSDE{yy}X", "DIABDX_M18", "INSC1231", f"INSURC{yy}"]:
        ent = entries.get(var)
        if not ent:
            continue
        for row in ent["rows"]:
            try:
                code = float(row["value"])
            except ValueError:
                continue
            mask = df[var] == code
            calc_w = float(w[mask].sum())
            rows.append({"variable": var, "code": row["value"], "label": row["label"],
                         "codebook_unweighted": row["unweighted"], "computed_unweighted": int(mask.sum()),
                         "codebook_weighted": row["weighted"], "computed_weighted": round(calc_w, 2),
                         "abs_diff_weighted": None if row["weighted"] is None else round(abs(calc_w - row["weighted"]), 2)})
    tot = entries.get(f"INS{yy}X", {}).get("total_weighted")
    rows.append({"variable": f"PERWT{yy}F (sum, all records)", "code": "total", "label": "",
                 "codebook_unweighted": entries.get(f"INS{yy}X", {}).get("total_unweighted"), "computed_unweighted": int(len(df)),
                 "codebook_weighted": tot, "computed_weighted": round(float(w.sum()), 2),
                 "abs_diff_weighted": None if tot is None else round(abs(float(w.sum()) - tot), 2)})
    out = pd.DataFrame(rows)
    out["unweighted_match"] = out["codebook_unweighted"] == out["computed_unweighted"]
    out["weighted_match_within_1"] = out["abs_diff_weighted"].apply(lambda v: v is None or (v == v and v <= 1.0))
    return out


def _transitions_sql() -> str:
    return """
    CREATE OR REPLACE TABLE transitions AS
    SELECT a.person_id, a.coverage_state AS from_state, b.coverage_state AS to_state, COUNT(*) AS n
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1, 2, 3;
    CREATE OR REPLACE TABLE source_changes AS
    SELECT a.person_id,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND (
                 a.private_cov IS DISTINCT FROM b.private_cov OR a.medicare_cov IS DISTINCT FROM b.medicare_cov OR
                 a.medicaid_cov IS DISTINCT FROM b.medicaid_cov OR a.tricare_cov IS DISTINCT FROM b.tricare_cov OR
                 a.va_cov IS DISTINCT FROM b.va_cov OR a.other_public_cov IS DISTINCT FROM b.other_public_cov)
               THEN 1 ELSE 0 END) AS n_source_set_changes_while_insured,
           SUM(CASE WHEN a.any_cov = 1 AND b.any_cov = 1 AND a.coverage_state <> b.coverage_state THEN 1 ELSE 0 END)
               AS n_state_changes_while_insured
    FROM person_month a JOIN person_month b ON a.person_id = b.person_id AND b.month = a.month + 1
    GROUP BY 1;
    """


def build_year(year: str, cfg: dict, cbs: dict, man: dict, con: duckdb.DuckDBPyConnection) -> dict:
    rel = cfg["releases"][year]
    yy = rel["yy"]
    pid = rel["puf_id"]
    cols, monthly = variables_for_year(cfg, yy)
    entries = cbs[year]
    missing_vars = [c for c in cols if c not in entries]
    if missing_vars:
        raise RuntimeError(f"Variables not in {rel['puf']} codebook: {missing_vars}")
    df, dta_labels = read_stata_subset(paths.RAW / pid / rel["archive_member"], cols)
    n_records = len(df)
    if df["DUPERSID"].duplicated().any():
        raise RuntimeError("Duplicate DUPERSID in FYC")
    con.register("fyc_df", df)
    con.execute("CREATE OR REPLACE TABLE fyc AS SELECT * FROM fyc_df")
    con.unregister("fyc_df")

    groups_sql, all_monthly = unpivot_parts(monthly)
    sql_log = paths.LOGS / f"sql_rendered_{year}.sql"
    rendered = []
    for name, kw in [("01_person.sql", {"yy": yy, "puf": rel["puf"]}),
                     ("02_person_month.sql", {"unpivot_groups": groups_sql, "all_monthly_columns": all_monthly}),
                     ("03_reconcile.sql", {}), ("04_classify.sql", {})]:
        q = render_sql(name, **kw)
        rendered.append(f"-- ===== {name} =====\n{q}")
        con.execute(q)
    con.execute(_transitions_sql())
    rendered.append("-- ===== transitions (inline) =====\n" + _transitions_sql())
    sql_log.write_text("\n\n".join(rendered), encoding="utf-8")

    person = con.execute("SELECT * FROM person ORDER BY person_id").df()
    pm_counts = con.execute("SELECT COUNT(*) AS n, COUNT(DISTINCT person_id) AS persons FROM person_month").fetchone()
    if pm_counts[0] != 12 * n_records or pm_counts[1] != n_records:
        raise RuntimeError(f"Person-month reshape changed counts: {pm_counts} vs {n_records} persons")

    # Reusable audit function on the documented monthly indicators.
    df_sorted = df.sort_values("DUPERSID").reset_index(drop=True)
    res = classify_continuity(df_sorted[["DUPERSID"] + monthly["any"]], df_sorted[f"INS{yy}X"],
                              month_columns=monthly["any"], id_column="DUPERSID",
                              out_of_scope=[cfg["codes"]["inapplicable"]], missing=cfg["codes"]["reserved_missing"],
                              alt_min_consecutive=cfg["gap_definitions"]["alternative"]["min_consecutive_months"])
    cls = res.persons.rename(columns={"DUPERSID": "person_id"})
    sqlc = con.execute("SELECT * FROM sql_class ORDER BY person_id").df()
    chk = cls.merge(sqlc, on="person_id", how="outer", validate="one_to_one", indicator=True)
    if (chk["_merge"] != "both").any():
        raise RuntimeError("Python and SQL classification person sets differ")
    disagree = int((chk["continuity_class"] != chk["continuity_class_sql"]).sum())
    disagree_months = int((chk["n_months_uncovered"] != chk["n_months_uncovered_sql"]).sum())

    recon = con.execute("SELECT * FROM reconciliation").df()
    recon = pd.concat([recon, pd.DataFrame([
        {"check_name": "python_audit_function_equals_sql_classification", "n_checked": len(chk), "n_mismatch": disagree,
         "definition": "inscont.continuity.classify_continuity and sql/04_classify.sql assign the same class to every person"},
        {"check_name": "python_and_sql_uncovered_month_counts_equal", "n_checked": len(chk), "n_mismatch": disagree_months,
         "definition": "Uncovered-month counts agree between the two implementations"},
    ])], ignore_index=True)
    nulls = {c: int(person[c].isna().sum()) for c in person.columns}
    recon = pd.concat([recon, pd.DataFrame([{"check_name": "no_nulls_in_person_table", "n_checked": len(person),
                                             "n_mismatch": int(sum(nulls.values())),
                                             "definition": "Stata reserved codes are numeric; no nulls expected"}])], ignore_index=True)

    pms = con.execute("SELECT person_id, m_cov, m_unc, m_oos, m_mis FROM pm_summary").df()
    src = con.execute("SELECT * FROM source_changes").df()
    dec_state = con.execute("SELECT person_id, coverage_state AS december_state FROM person_month WHERE month = 12").df()
    jan_state = con.execute("SELECT person_id, coverage_state AS january_state FROM person_month WHERE month = 1").df()
    tr = con.execute("SELECT * FROM transitions").df()
    tr = tr[tr["from_state"].isin(STATE_CODES) & tr["to_state"].isin(STATE_CODES)].copy()
    tr["col"] = "tr_" + tr["from_state"].map(STATE_CODES) + tr["to_state"].map(STATE_CODES)
    trw = tr.pivot_table(index="person_id", columns="col", values="n", aggfunc="sum", fill_value=0).reset_index()
    for a in STATE_CODES.values():
        for b in STATE_CODES.values():
            if f"tr_{a}{b}" not in trw:
                trw[f"tr_{a}{b}"] = 0

    a = (person.merge(cls, on="person_id", how="left", validate="one_to_one")
         .merge(pms, on="person_id", how="left", validate="one_to_one")
         .merge(src, on="person_id", how="left", validate="one_to_one")
         .merge(dec_state, on="person_id", how="left", validate="one_to_one")
         .merge(jan_state, on="person_id", how="left", validate="one_to_one")
         .merge(trw, on="person_id", how="left", validate="one_to_one"))
    unc = pd.DataFrame({"person_id": df_sorted["DUPERSID"].to_numpy()})
    for i, c in enumerate(monthly["any"], start=1):
        unc[f"unc_m{i:02d}"] = (df_sorted[c].to_numpy() == cfg["codes"]["no"]).astype(int)
    a = a.merge(unc, on="person_id", how="left", validate="one_to_one")
    tcols = [c for c in a.columns if c.startswith("tr_")]
    a[tcols] = a[tcols].fillna(0).astype(int)
    if len(a) != n_records:
        raise RuntimeError("Person count changed during joins")

    # Frames and domains.
    dm = cfg["domain"]
    a["pos_weight"] = a["weight"] > 0
    a["adult_18_64"] = a["age"].between(dm["age_min"], dm["age_max"])
    a["diabetes_yes"] = a["diabetes"] == 1
    a["inscope_1231_yes"] = a["inscope_1231"] == 1
    a["year_end_substantive"] = a["ins_1231"].isin([1, 2])
    a["full_year_scope"] = (a["m_oos"] == 0) & (a["end_ref_month"] == 12) & (a["end_ref_year"] == int("20" + yy))
    a["frame_y"] = a["pos_weight"] & a["adult_18_64"] & a["diabetes_yes"] & a["inscope_1231_yes"] & a["year_end_substantive"]
    a["domain_c"] = a["frame_y"] & a["full_year_scope"]
    a["part_year_in_frame_y"] = a["frame_y"] & ~a["full_year_scope"]
    a["year_end_insured"] = a["ins_1231"] == 1
    a["cls_continuous"] = a["continuity_class"] == "insured_year_end_continuous"
    a["cls_gap"] = a["continuity_class"] == "insured_year_end_gap"
    a["cls_uninsured_ye"] = a["continuity_class"] == "uninsured_year_end"
    a["cls_indeterminate"] = a["continuity_class"] == "indeterminate"
    a["alt_gap3"] = a["continuity_class_alt"] == "insured_year_end_gap"
    a["round_scope_all"] = (a["inscop_r31"] == 1) & (a["inscop_r42"] == 1) & (a["inscop_yy"] == 1)
    a["switch_without_gap"] = a["cls_continuous"] & (a["n_source_set_changes_while_insured"] > 0)
    a["state_change_without_gap"] = a["cls_continuous"] & (a["n_state_changes_while_insured"] > 0)
    a["gap_months_band"] = np.select([a["n_months_uncovered"].between(1, 2), a["n_months_uncovered"].between(3, 11)],
                                     ["1-2", "3-11"], default="")

    # Prescription outcome states.
    neg_oop = (a["rx_oop"] < 0) | a["rx_oop"].isna()
    a["rx_state"] = np.select([neg_oop, a["rx_fills"] == 0, (a["rx_fills"] > 0) & (a["rx_oop"] == 0), a["rx_fills"] > 0],
                              ["missing_expenditure", "no_recorded_fill", "fills_zero_oop", "fills_positive_oop"],
                              default="unclassified")
    a["any_fill"] = a["rx_fills"] > 0
    a["oop_positive"] = a["rx_oop"] > 0
    a["oop_zero_among_users"] = np.where(a["any_fill"], (a["rx_oop"] == 0).astype(float), np.nan)

    # Covariates (prespecified).
    a["age_group"] = np.select([a["age"].between(18, 44), a["age"].between(45, 64)], ["18-44", "45-64"], default="other")
    a["sex_label"] = a["sex"].map({1: "Male", 2: "Female"})
    a["race_eth4"] = a["race_eth"].map({1: "Hispanic", 2: "Non-Hispanic White", 3: "Non-Hispanic Black",
                                        4: "Non-Hispanic Asian, other, or multiple", 5: "Non-Hispanic Asian, other, or multiple"})
    a["income2"] = np.select([a["poverty_cat"].isin([1, 2, 3]), a["poverty_cat"].isin([4, 5])],
                             ["Below 200% FPL", "200% FPL or more"], default="missing")
    a["region_label"] = a["region"].map({1: "Northeast", 2: "Midwest", 3: "South", 4: "West", -1: "Inapplicable"})

    out = {"year": year, "puf": rel["puf"], "n_records": n_records}

    # Prescribed medicines events (2024 only).
    rx_recon = None
    if year == "2024" and "2024rx" in cfg["releases"]:
        rxc = cfg["releases"]["2024rx"]
        rx, _ = read_stata_subset(paths.RAW / rxc["puf_id"] / rxc["archive_member"], cfg["rx_event_vars"])
        if rx["RXRECIDX"].duplicated().any():
            raise RuntimeError("Duplicate RXRECIDX in HC-254A")
        con.register("rx_df", rx)
        con.execute("CREATE OR REPLACE TABLE rx_events AS SELECT * FROM rx_df")
        con.unregister("rx_df")
        q = render_sql("05_rx_person.sql")
        con.execute(q)
        with open(sql_log, "a", encoding="utf-8") as fh:
            fh.write("\n\n-- ===== 05_rx_person.sql =====\n" + q)
        rxp = con.execute("SELECT * FROM rx_person").df()
        rx_recon = con.execute("SELECT * FROM rx_reconciliation").df()
        a = a.merge(rxp, on="person_id", how="left", validate="one_to_one")
        for c in [c for c in rxp.columns if c != "person_id"]:
            a[c] = a[c].fillna(0)
        a["rx_share_records_imputed"] = np.where(a["rx_records"] > 0,
                                                 (a["rx_records_fully_imputed"] + a["rx_records_partially_imputed"]) / a["rx_records"].replace(0, np.nan),
                                                 np.nan)
        a["rx_share_oop_from_imputed"] = np.where(a["rx_oop_event_sum"] > 0,
                                                  a["rx_oop_from_imputed_records"] / a["rx_oop_event_sum"].replace(0, np.nan), np.nan)
        out["rx_event_records"] = int(len(rx))
        out["rx_event_persons"] = int(rxp.shape[0])
        if len(a) != n_records:
            raise RuntimeError("Person count changed after joining prescribed medicines")

    # Cohort flow (unweighted counts, every step on the same full record set).
    steps = [
        ("All records on the public-use file", pd.Series(True, index=a.index)),
        ("Positive person weight (PERWT > 0)", a["pos_weight"]),
        ("Age 18 to 64 on 12/31", a["pos_weight"] & a["adult_18_64"]),
        ("Ever told had diabetes (DIABDX_M18 = 1)", a["pos_weight"] & a["adult_18_64"] & a["diabetes_yes"]),
        ("In scope on 12/31 with a year-end coverage value (frame Y)", a["frame_y"]),
        ("In scope all 12 months (primary domain C)", a["domain_c"]),
    ]
    flow = pd.DataFrame([{"step": i + 1, "description": d, "n_unweighted": int(m.sum()),
                          "weighted_population": round(float(a.loc[m, "weight"].sum()), 0)} for i, (d, m) in enumerate(steps)])
    pre = a["pos_weight"] & a["adult_18_64"]
    excl = pd.DataFrame([
        {"group": "Adults 18 to 64, positive weight: diabetes = 2 (no)", "n_unweighted": int((pre & (a["diabetes"] == 2)).sum())},
        {"group": "Adults 18 to 64, positive weight: diabetes = -7 (refused)", "n_unweighted": int((pre & (a["diabetes"] == -7)).sum())},
        {"group": "Adults 18 to 64, positive weight: diabetes = -8 (don't know)", "n_unweighted": int((pre & (a["diabetes"] == -8)).sum())},
        {"group": "Adults 18 to 64, positive weight: diabetes = -1 (inapplicable)", "n_unweighted": int((pre & (a["diabetes"] == -1)).sum())},
        {"group": "Adults 18 to 64, positive weight: diabetes other codes", "n_unweighted": int((pre & ~a["diabetes"].isin([1, 2, -7, -8, -1])).sum())},
        {"group": "Diabetes cohort not in scope on 12/31", "n_unweighted": int((pre & a["diabetes_yes"] & ~a["inscope_1231_yes"]).sum())},
        {"group": "Diabetes cohort in scope 12/31 without substantive year-end value", "n_unweighted": int((pre & a["diabetes_yes"] & a["inscope_1231_yes"] & ~a["year_end_substantive"]).sum())},
        {"group": "Frame Y but part-year in scope (described separately)", "n_unweighted": int(a["part_year_in_frame_y"].sum())},
        {"group": "Frame Y, ref. period ends before December", "n_unweighted": int((a["frame_y"] & (a["end_ref_month"] != 12)).sum())},
    ])
    class_counts = (a[a["domain_c"]].groupby("continuity_class").size().reindex(CLASSES, fill_value=0)
                    .rename("n_unweighted").reset_index())

    scope = pd.crosstab(a.loc[a["frame_y"], "full_year_scope"], a.loc[a["frame_y"], "round_scope_all"],
                        rownames=["monthly_rule_full_year_scope"], colnames=["round_level_inscop_all_1"]).reset_index()
    scope_all = pd.crosstab(a.loc[a["pos_weight"], "full_year_scope"], a.loc[a["pos_weight"], "round_scope_all"],
                            rownames=["monthly_rule_full_year_scope"], colnames=["round_level_inscop_all_1"]).reset_index()

    wcheck = _weighted_codebook_check(df, entries, yy)

    # Write outputs.
    T = paths.TABLES
    flow.to_csv(T / f"cohort_flow_{year}.csv", index=False)
    excl.to_csv(T / f"cohort_exclusions_{year}.csv", index=False)
    class_counts.to_csv(T / f"class_counts_unweighted_{year}.csv", index=False)
    recon.to_csv(T / f"reconciliation_{year}.csv", index=False)
    res.audit.to_csv(T / f"audit_rules_{year}.csv", index=False)
    res.month_codes.to_csv(T / f"audit_month_codes_{year}.csv", index=False)
    scope.to_csv(T / f"scope_agreement_frame_y_{year}.csv", index=False)
    scope_all.to_csv(T / f"scope_agreement_all_positive_weight_{year}.csv", index=False)
    wcheck.to_csv(T / f"codebook_frequency_reconciliation_{year}.csv", index=False)
    if rx_recon is not None:
        rx_recon.to_csv(T / f"rx_reconciliation_{year}.csv", index=False)
    bool_cols = [c for c in a.columns if a[c].dtype == bool]
    a[bool_cols] = a[bool_cols].astype(int)
    a.to_csv(paths.PROCESSED / f"analysis_{year}.csv", index=False)
    con.execute(f"COPY person_month TO '{(paths.PROCESSED / f'person_month_{year}.parquet').as_posix()}' (FORMAT PARQUET)")
    (paths.INTERIM / f"dta_variable_labels_{year}.json").write_text(json.dumps(dta_labels, indent=1), encoding="utf-8")

    out.update({
        "frame_y_n": int(a["frame_y"].sum()), "domain_c_n": int(a["domain_c"].sum()),
        "class_counts_domain_c": {r.continuity_class: int(r.n_unweighted) for r in class_counts.itertuples()},
        "reconciliation_failures": recon[(recon["n_mismatch"] > 0) & ~recon["check_name"].str.startswith("info_")][["check_name", "n_mismatch"]].to_dict("records"),
        "codebook_frequency_mismatches": int((~wcheck["unweighted_match"] | ~wcheck["weighted_match_within_1"]).sum()),
        "rx_reconciliation_failures": None if rx_recon is None else rx_recon[rx_recon["n_mismatch"] > 0][["check_name", "n_mismatch"]].to_dict("records"),
    })
    return out


def run() -> dict:
    cfg = paths.load_config()
    paths.ensure_dirs()
    man = _verify_raw_hashes()
    cbs = codebook.build_codebooks()
    summary = {}
    for year in ("2024", "2023"):
        con = duckdb.connect()
        summary[year] = build_year(year, cfg, cbs, man, con)
        con.close()
        print(f"[build] {year}: {json.dumps(summary[year], default=str)[:900]}")
    (paths.LOGS / "build_summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    from . import dictionary
    dictionary.write_dictionary(cfg, cbs)
    return summary
