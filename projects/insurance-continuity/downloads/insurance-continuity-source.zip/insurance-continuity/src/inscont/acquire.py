"""Download and verify MEPS public-use files.

Each file is streamed to a temporary path, checked for the expected content type and
magic bytes (so an HTML error page cannot pass as data), hashed, and then moved into
data/raw/<puf_id>/. Archives are extracted only for expected members, with path and
size checks. Results are recorded in source_manifest.json.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import html
import json
import re
import shutil
import time
import zipfile
from pathlib import Path

import requests

from . import paths

USER_AGENT = "inscont-research-pipeline/1.0 (+reproducible MEPS analysis)"
MAX_ATTEMPTS = 4
TIMEOUT = (20, 300)
MAX_UNCOMPRESSED = 600 * 1024 * 1024

EXPECTED = {
    "data_zip": ("application/zip", b"PK\x03\x04"),
    "documentation_pdf": ("application/pdf", b"%PDF"),
    "codebook_pdf": ("application/pdf", b"%PDF"),
    "r_statements_txt": ("text/plain", None),
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _get(url: str, stream: bool = False) -> requests.Response:
    last = None
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            r = requests.get(url, stream=stream, timeout=TIMEOUT, headers={"User-Agent": USER_AGENT}, allow_redirects=True)
            if r.status_code == 200:
                return r
            last = RuntimeError(f"HTTP {r.status_code} for {url}")
        except requests.RequestException as exc:  # network errors are retried
            last = exc
        time.sleep(min(2 ** attempt, 20))
    raise RuntimeError(f"Failed after {MAX_ATTEMPTS} attempts: {url}: {last}")


def _looks_like_html(head: bytes) -> bool:
    h = head.lstrip()[:200].lower()
    return h.startswith(b"<!doctype html") or h.startswith(b"<html") or b"<head" in h


_PREVIOUS: dict[str, dict] = {}


def _load_previous() -> None:
    """Index earlier manifest records by path so cached files keep their original download metadata."""
    if paths.SOURCE_MANIFEST.exists():
        old = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
        for rel_entry in old.get("releases", {}).values():
            for rec in rel_entry.get("files", {}).values():
                _PREVIOUS[rec["path"]] = rec


ACCEPT_NEW = False
_EXPECTED: dict[str, dict] = {}


def _load_expected() -> None:
    p = paths.ROOT / "config" / "expected_checksums.json"
    if p.exists():
        _EXPECTED.update(json.loads(p.read_text(encoding="utf-8"))["files"])


def check_expected(rel_path: str, digest: str) -> str:
    """Compare a file with the checksum recorded for the analyzed release."""
    exp = _EXPECTED.get(rel_path)
    if exp is None:
        return "no recorded checksum"
    if exp["sha256"] == digest:
        return "matches analyzed release"
    if ACCEPT_NEW:
        return "differs from analyzed release (accepted with --accept-new-release)"
    raise RuntimeError(f"{rel_path}: SHA-256 {digest[:12]} differs from the analyzed release {exp['sha256'][:12]}. "
                       "AHRQ may have revised the file. Results would no longer reproduce the study; rerun with "
                       "./icont acquire --accept-new-release only if you intend to analyze the new version.")


def download(url: str, dest: Path, kind: str) -> dict:
    """Stream url to dest with content checks. Reuses an existing file (immutable release cache)."""
    ctype_expected, magic = EXPECTED[kind]
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and dest.stat().st_size > 0:
        with open(dest, "rb") as fh:
            head = fh.read(512)
        _check_bytes(head, magic, kind, dest)
        digest = sha256_file(dest)
        status = check_expected(paths.rel(dest), digest)
        prev = _PREVIOUS.get(paths.rel(dest))
        if prev and prev.get("sha256") == digest:
            rec = {k: v for k, v in prev.items() if k not in ("archive_members", "extracted", "extracted_bytes", "extracted_sha256")}
            rec["cached"] = True
            rec["expected_checksum"] = status
            rec.setdefault("retrieved_utc", _EXPECTED.get(paths.rel(dest), {}).get("retrieved_utc"))
            return rec
        return {"url": url, "path": paths.rel(dest), "bytes": dest.stat().st_size, "sha256": digest,
                "content_type": "not recorded (file present before manifest)", "cached": True, "expected_checksum": status,
                "retrieved_utc": _EXPECTED.get(paths.rel(dest), {}).get("retrieved_utc")}
    r = _get(url, stream=True)
    ctype = r.headers.get("Content-Type", "").split(";")[0].strip().lower()
    if not ctype.startswith(ctype_expected.split("/")[0]) or (ctype_expected != "text/plain" and ctype != ctype_expected):
        raise RuntimeError(f"Unexpected content type {ctype!r} for {url}; expected {ctype_expected}")
    tmp = dest.with_suffix(dest.suffix + ".part")
    with open(tmp, "wb") as fh:
        for chunk in r.iter_content(1 << 20):
            fh.write(chunk)
    with open(tmp, "rb") as fh:
        head = fh.read(512)
    _check_bytes(head, magic, kind, tmp)
    declared = r.headers.get("Content-Length")
    if declared and int(declared) != tmp.stat().st_size:
        tmp.unlink()
        raise RuntimeError(f"Truncated download for {url}: {tmp.stat().st_size} != {declared}")
    tmp.replace(dest)
    digest = sha256_file(dest)
    status = check_expected(paths.rel(dest), digest)
    return {"url": r.url, "path": paths.rel(dest), "bytes": dest.stat().st_size, "sha256": digest,
            "content_type": ctype, "last_modified_header": r.headers.get("Last-Modified"), "cached": False,
            "expected_checksum": status, "retrieved_utc": _now()}


def _check_bytes(head: bytes, magic: bytes | None, kind: str, p: Path) -> None:
    if magic is not None and not head.startswith(magic):
        raise RuntimeError(f"{p.name}: magic bytes do not match {kind}")
    if magic is None and _looks_like_html(head):
        raise RuntimeError(f"{p.name}: received an HTML page instead of {kind}")


def safe_extract(zpath: Path, member: str, outdir: Path) -> dict:
    with zipfile.ZipFile(zpath) as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"Corrupt member {bad} in {zpath.name}")
        infos = zf.infolist()
        names = [i.filename for i in infos]
        for i in infos:
            pn = Path(i.filename)
            if pn.is_absolute() or ".." in pn.parts:
                raise RuntimeError(f"Unsafe path {i.filename!r} in {zpath.name}")
        total = sum(i.file_size for i in infos)
        if total > MAX_UNCOMPRESSED:
            raise RuntimeError(f"{zpath.name} expands to {total} bytes, above limit")
        match = [i for i in infos if i.filename.lower() == member.lower()]
        if not match:
            raise RuntimeError(f"{zpath.name} does not contain {member}; members: {names}")
        info = match[0]
        out = outdir / Path(info.filename).name.lower()
        if not out.exists() or out.stat().st_size != info.file_size:
            with zf.open(info) as src, open(out, "wb") as dst:
                shutil.copyfileobj(src, dst)
        digest = sha256_file(out)
        return {"archive_members": [{"name": i.filename, "bytes": i.file_size,
                                     "date_time": "%04d-%02d-%02d %02d:%02d:%02d" % i.date_time} for i in infos],
                "extracted": paths.rel(out), "extracted_bytes": out.stat().st_size, "extracted_sha256": digest,
                "extracted_expected_checksum": check_expected(paths.rel(out), digest)}


def _page_text(url: str) -> tuple[str, str]:
    r = _get(url)
    raw = r.text
    txt = re.sub(r"<script.*?</script>", " ", raw, flags=re.S)
    txt = html.unescape(re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", txt)))
    return raw, txt


def verify_detail_page(puf: str, url: str, title_expected: str, release_expected: str, snapshot: Path) -> dict:
    raw, txt = _page_text(url)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_text(raw, encoding="utf-8")
    m = re.search(r"MEPS " + re.escape(puf) + r":\s*(.+?)\s+printer-friendly", txt)
    rel_m = re.search(r"Release date:\s*([A-Za-z]+ \d{4})", txt)
    title = m.group(1).strip() if m else None
    release = rel_m.group(1) if rel_m else None
    ok = bool(title and title_expected in title and release == release_expected)
    return {"detail_page": url, "page_title": title, "release_date": release, "title_matches": ok,
            "snapshot": paths.rel(snapshot), "snapshot_sha256": sha256_file(snapshot)}


def probe_newer(cfg: dict, snapdir: Path) -> list[dict]:
    out = []
    pat = cfg["newer_release_probe"]["title_pattern"]
    for puf in cfg["newer_release_probe"]["puf_numbers"]:
        url = f"https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber={puf}"
        try:
            _, txt = _page_text(url)
        except RuntimeError as exc:
            out.append({"puf": puf, "status": f"unreachable: {exc}"})
            continue
        m = re.search(r"MEPS " + re.escape(puf) + r":\s*(.+?)\s+printer-friendly", txt)
        title = m.group(1).strip() if m else None
        out.append({"puf": puf, "page_title": title, "is_newer_full_year_consolidated": bool(title and pat in title)})
    return out


def run() -> dict:
    cfg = paths.load_config()
    paths.ensure_dirs()
    _load_previous()
    _load_expected()
    manifest = {"generated_utc": _now(), "publisher": "Agency for Healthcare Research and Quality (AHRQ)",
                "survey": "Medical Expenditure Panel Survey Household Component (MEPS-HC)",
                "permitted_use": ("Public-use file. AHRQ data use requirements printed in each PUF documentation: "
                                  "statistical reporting and analysis only; no attempt to identify individuals; "
                                  "no linkage to individually identifiable records except as permitted; cite AHRQ and MEPS."),
                "releases": {}}
    for key, rel_cfg in cfg["releases"].items():
        puf_id = rel_cfg["puf_id"]
        d = paths.RAW / puf_id
        entry = {"puf": rel_cfg["puf"], "role": rel_cfg["role"], "reference_period": f"calendar year 20{rel_cfg['yy']}",
                 "access_date_utc": None, "detail_page_checked_utc": _now(), "files": {}}
        entry["detail_page_check"] = verify_detail_page(rel_cfg["puf"], rel_cfg["detail_page"], rel_cfg["title_expected"],
                                                        rel_cfg["release_date_expected"], d / f"{puf_id}_detail_page.html")
        if not entry["detail_page_check"]["title_matches"]:
            raise RuntimeError(f"Detail page check failed for {rel_cfg['puf']}: {entry['detail_page_check']}")
        for kind, url in rel_cfg["files"].items():
            name = url.rsplit("/", 1)[-1]
            info = download(url, d / name, kind)
            if kind == "data_zip":
                info.update(safe_extract(d / name, rel_cfg["archive_member"], d))
            entry["files"][kind] = info
            print(f"[acquire] {rel_cfg['puf']} {kind}: {info['bytes']:,} bytes sha256={info['sha256'][:12]}")
        times = [f.get("retrieved_utc") for f in entry["files"].values() if f.get("retrieved_utc")]
        entry["access_date_utc"] = min(times) if times else _now()
        manifest["releases"][key] = entry
    manifest["newer_release_probe"] = {"checked_utc": _now(), "results": probe_newer(cfg, paths.RAW / "_probe")}
    newer = [r for r in manifest["newer_release_probe"]["results"] if r.get("is_newer_full_year_consolidated")]
    manifest["newest_compatible_full_year_release"] = "HC-256 (2024)" if not newer else newer
    manifest["notes"] = [
        "Release year, data reference period, record update date, and retrieval date are recorded separately.",
        "Each file is compared with config/expected_checksums.json (the versions analyzed in this study); acquire stops on a mismatch unless --accept-new-release is given, and build re-checks every raw file against this manifest.",
        "Raw files are kept locally under data/raw and are not redistributed in the source archive.",
    ]
    with open(paths.SOURCE_MANIFEST, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    return manifest


if __name__ == "__main__":
    run()
