"""Command-line entry point: icont <stage>.

Stages: acquire, build, analyze, validate, render, package, all, demo, test, rerun, bundle.
Each stage writes its outputs to project-relative paths and appends to .local/CHECKPOINT.md.
"""

from __future__ import annotations

import argparse
import datetime as dt
import subprocess
import sys

from . import paths

STAGES = ["acquire", "build", "analyze", "validate", "render", "package"]


NEXT = {
    "acquire": "./icont build",
    "build": "./icont analyze",
    "analyze": "./icont validate",
    "validate": "./icont render",
    "render": "./icont package",
    "package": "python3 scripts/clean_room_check.py && python3 scripts/check_site.py && ./icont bundle",
    "bundle": "author review of site/projects/insurance-continuity/report.html and submission/; after any edit run ./icont render && ./icont package",
    "rerun": "./icont render",
}
ARTIFACTS = {
    "acquire": ["source_manifest.json", "data/raw/"],
    "build": ["data/processed/analysis_2024.csv", "data/processed/analysis_2023.csv", "outputs/tables/reconciliation_2024.csv"],
    "analyze": ["outputs/estimates_2024.json", "outputs/estimates_2023.json", "outputs/tables/"],
    "validate": ["outputs/tables/validation_reconciliation_rollup.csv", "outputs/logs/validation_summary.json"],
    "render": ["manuscript/manuscript.md", "submission/", "site/projects/insurance-continuity/", "evidence/claims.json"],
    "package": ["site/projects/insurance-continuity/downloads/insurance-continuity-source.zip", "deliverables/01-insurance-continuity-PROJECT-BUNDLE.zip"],
    "bundle": ["handoff/", "deliverables/01-insurance-continuity-PROJECT-BUNDLE.zip"],
    "rerun": ["outputs/tables/rerun_comparison.csv", "outputs/logs/rerun_check.json"],
}


def checkpoint(stage: str, note: str = "") -> None:
    paths.LOCAL.mkdir(parents=True, exist_ok=True)
    cp = paths.LOCAL / "CHECKPOINT.md"
    if not cp.exists():
        cp.write_text("# Checkpoint\n\nPrivate resume log. Not packaged.\n\n", encoding="utf-8")
    stamp = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    with open(cp, "a", encoding="utf-8") as fh:
        fh.write(f"- {stamp} completed `./icont {stage}`{(' ' + note) if note else ''}. Artifacts: "
                 f"{', '.join(ARTIFACTS.get(stage, []))}. Next: `{NEXT.get(stage, '')}`\n")


def run_stage(stage: str, args: argparse.Namespace) -> None:
    if stage == "acquire":
        from . import acquire
        acquire.ACCEPT_NEW = bool(getattr(args, "accept_new_release", False))
        acquire.run()
    elif stage == "build":
        from . import build
        build.run()
    elif stage == "analyze":
        from . import analyze
        analyze.run()
    elif stage == "validate":
        from . import validate
        validate.run()
    elif stage == "render":
        from . import render
        render.run()
    elif stage == "package":
        from . import package
        package.run()
    elif stage == "bundle":
        from . import package
        package.run(rebuild_source=False)
    elif stage == "rerun":
        from . import validate
        validate.rerun_check()
    elif stage == "demo":
        from . import demo
        demo.run()
        return
    elif stage == "test":
        sys.exit(subprocess.call([sys.executable, "-m", "pytest", "-q", str(paths.ROOT / "tests")]))
    else:
        raise SystemExit(f"Unknown stage {stage}")
    checkpoint(stage)


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(prog="icont", description=__doc__)
    ap.add_argument("stage", choices=STAGES + ["all", "demo", "test", "rerun", "bundle"])
    ap.add_argument("--accept-new-release", action="store_true", help="acquire: accept AHRQ files that differ from the analyzed versions")
    args = ap.parse_args(argv)
    if args.stage == "all":
        for s in STAGES:
            print(f"== {s} ==", flush=True)
            run_stage(s, args)
    else:
        run_stage(args.stage, args)


if __name__ == "__main__":
    main()
