"""Fast demo on 8 synthetic records (tests/fixtures/demo_people.csv).

This shows how the continuity audit function and the variance cross-check work. The
records are invented; nothing here is study evidence. Outputs go to outputs/demo/ and
never mix with the real study outputs.
"""

from __future__ import annotations

import pandas as pd

from . import paths
from .continuity import classify_continuity
from .validate import taylor_domain_proportion


def run() -> None:
    df = pd.read_csv(paths.ROOT / "tests" / "fixtures" / "demo_people.csv", dtype={"person_id": str})
    months = [f"m{i:02d}" for i in range(1, 13)]
    res = classify_continuity(df[["person_id"] + months], df["year_end"], month_columns=months, id_column="person_id")
    out = paths.OUTPUTS / "demo"
    out.mkdir(parents=True, exist_ok=True)
    persons = res.persons.merge(df[["person_id", "note"]], on="person_id")
    persons.to_csv(out / "demo_classes.csv", index=False)
    res.audit.to_csv(out / "demo_audit.csv", index=False)
    df2 = df.merge(res.persons[["person_id", "continuity_class"]], on="person_id")
    df2["gap"] = (df2["continuity_class"] == "insured_year_end_gap").astype(int)
    dom = df2["continuity_class"].isin(["insured_year_end_continuous", "insured_year_end_gap"])
    est = taylor_domain_proportion(df2, "gap", dom)
    print("SYNTHETIC DEMO (8 invented records; not study evidence)")
    print(persons[["person_id", "continuity_class", "continuity_class_alt", "n_months_uncovered", "note"]].to_string(index=False))
    print(f"\nShare with a gap among determinate year-end insured (synthetic): {est['estimate']:.3f} (SE {est['se']:.3f})")
    print(f"Outputs written to {paths.rel(out)}/")
