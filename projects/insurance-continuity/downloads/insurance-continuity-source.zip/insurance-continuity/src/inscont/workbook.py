"""Aggregate Excel workbook and Tableau-ready exports.

Only precomputed, design-based aggregates are written. No person-level records. Every
estimate row carries its grain, unit, denominator, confidence bounds, and a
reliability/suppression flag. Tableau users filter rows; they never recompute
survey statistics from these aggregates.
"""

from __future__ import annotations

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from . import paths

TABLEAU_DIR = paths.OUTPUTS / "tableau"

UNIT = {
    "proportion": "proportion (0 to 1)",
    "mean": "see measure (USD for spending, count for fills, months for durations)",
    "quantile": "USD, nominal for the data year",
    "ratio": "ratio of weighted totals",
}


def _unit(measure: str, stat: str) -> str:
    m = measure.lower()
    if stat == "proportion":
        return "proportion (0 to 1)"
    if "usd" in m or "spending" in m or "expenditure" in m:
        return "US dollars, nominal for the data year"
    if "fills" in m:
        return "fills per person per year"
    if "months" in m:
        return "months"
    if stat == "ratio":
        return "ratio of weighted totals"
    return UNIT.get(stat, "")


def tableau_estimates() -> pd.DataFrame:
    frames = []
    for year in ("2024", "2023"):
        for fname, frame in [(f"primary_estimate_{year}.csv", "Primary estimate"), (f"yearend_by_continuity_{year}.csv", "Year-end by continuity"),
                             (f"yearend_status_by_frame_{year}.csv", "Year-end status by frame"), (f"rx_outcomes_{year}.csv", "Prescription outcomes"),
                             (f"gap_details_{year}.csv", "Gap details"), (f"switch_without_gap_{year}.csv", "Source change without gap"),
                             (f"monthly_uninsured_gap_group_{year}.csv", "Monthly uninsured share, gap group"),
                             (f"rx_imputation_{year}.csv", "Prescription imputation information")]:
            p = paths.TABLES / fname
            if not p.exists():
                continue
            df = pd.read_csv(p)
            df.insert(0, "table", frame)
            df.insert(0, "data_year", int(year))
            frames.append(df)
    t = pd.concat(frames, ignore_index=True, sort=False)
    keep = ["data_year", "table", "group", "measure", "stat", "estimate", "se", "ci_low", "ci_high", "ci_method", "kg_low", "kg_high",
            "n_unweighted", "numerator_unweighted", "weighted_denominator", "design_df", "reliability"]
    t = t[[c for c in keep if c in t.columns]].copy()
    t["unit"] = [_unit(str(m), str(s)) for m, s in zip(t["measure"], t["stat"])]
    t["suppress"] = t["reliability"].astype(str).str.startswith("suppress")
    t["imprecise_flag"] = t["reliability"].astype(str).str.startswith("flag")
    t["review_flag"] = t["reliability"].astype(str).str.startswith("review")
    t["grain"] = "one row per data year x table x population group x measure x statistic"
    t["permitted_filters"] = "data_year, table, population_group, measure, statistic (row filters only)"
    t["not_permitted"] = "summing, averaging, or re-weighting rows; computing new percentages from rows; pooling years"
    t.rename(columns={"reliability": "reliability_flag", "group": "population_group", "stat": "statistic"}, inplace=True)
    return t


def write_tableau() -> dict:
    TABLEAU_DIR.mkdir(parents=True, exist_ok=True)
    est = tableau_estimates()
    est.to_csv(TABLEAU_DIR / "estimates_long.csv", index=False)
    tr = []
    for year in ("2024", "2023"):
        p = paths.TABLES / f"monthly_transitions_{year}.csv"
        if p.exists():
            d = pd.read_csv(p)
            d.insert(0, "data_year", int(year))
            tr.append(d)
    trans = pd.concat(tr, ignore_index=True)
    trans["unit"] = "share of month-to-month transitions out of the from_state (rows sum to 1 within year and from_state)"
    trans["grain"] = "one row per data year x from_state x to_state; primary domain only"
    trans.to_csv(TABLEAU_DIR / "monthly_transitions.csv", index=False)
    fl = []
    for year in ("2024", "2023"):
        d = pd.read_csv(paths.TABLES / f"cohort_flow_{year}.csv")
        d.insert(0, "data_year", int(year))
        fl.append(d)
    flow = pd.concat(fl, ignore_index=True)
    flow["grain"] = "one row per data year x cohort step (cumulative filters)"
    flow.to_csv(TABLEAU_DIR / "cohort_flow.csv", index=False)
    return {"estimates_rows": len(est), "transition_rows": len(trans), "flow_rows": len(flow)}


def _sheet(wb, title: str, df: pd.DataFrame, note: str | None = None) -> None:
    ws = wb.create_sheet(title[:31])
    r0 = 1
    if note:
        ws.cell(row=1, column=1, value=note).font = Font(italic=True, color="52514E")
        ws.cell(row=1, column=1).alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=max(4, min(len(df.columns), 10)))
        ws.row_dimensions[1].height = 48
        r0 = 3
    for j, c in enumerate(df.columns, start=1):
        cell = ws.cell(row=r0, column=j, value=str(c))
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="EEEDEA")
    for i, row in enumerate(df.itertuples(index=False), start=r0 + 1):
        for j, v in enumerate(row, start=1):
            if isinstance(v, float) and pd.isna(v):
                v = None
            ws.cell(row=i, column=j, value=v)
    for j, c in enumerate(df.columns, start=1):
        width = min(60, max(10, len(str(c)) + 2, *(len(str(x)) + 2 for x in df[c].head(200))))
        ws.column_dimensions[get_column_letter(j)].width = width
    ws.freeze_panes = ws.cell(row=r0 + 1, column=1)


def write_workbook() -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = "README"
    readme = [
        "Insurance continuity and prescription spending among US adults with diabetes: aggregate results",
        "Data: AHRQ Medical Expenditure Panel Survey, HC-256 (2024 Full Year Consolidated, released August 2026) and HC-251 (2023, released August 2025); HC-254A (2024 Prescribed Medicines) for imputation flags.",
        "Every number is a design-based aggregate (Taylor linearization; strata VARSTR, PSUs VARPSU, weight PERWT24F or PERWT23F). No person-level records are included.",
        "Units: proportions are 0 to 1; spending is nominal US dollars of the data year (no deflator applied); fills are per person per year.",
        "Reliability: proportions use the NCHS Data Presentation Standards for Proportions (Korn-Graubard interval); means and quantiles are flagged when RSE > 30% or n < 30.",
        "Do not sum, average, or re-weight rows, compute new percentages from them, or pool the two years.",
        "Sheet 'Definitions' maps every analysis variable to its AHRQ source variable, codes, and transformation.",
        "Primary domain C: ages 18 to 64 on 12/31, ever told had diabetes (DIABDX_M18 = 1), positive weight, in scope all 12 months, in scope on 12/31.",
        "Classes: A insured on 12/31 and every month; B insured on 12/31 with at least one fully uninsured calendar month; C uninsured on 12/31; D indeterminate.",
    ]
    for i, t in enumerate(readme, start=1):
        ws.cell(row=i, column=1, value=t).alignment = Alignment(wrap_text=True, vertical="top")
    ws.column_dimensions["A"].width = 140
    ws.cell(row=1, column=1).font = Font(bold=True, size=12)

    T = paths.TABLES
    defs = pd.read_csv(T / "data_dictionary.csv")
    _sheet(wb, "Definitions", defs, "Source-to-analysis dictionary. Codebook descriptions and codes are read from the AHRQ codebooks by the pipeline.")
    _sheet(wb, "Cohort_flow_2024", pd.read_csv(T / "cohort_flow_2024.csv"), "Unweighted record counts; weighted population totals use PERWT24F.")
    _sheet(wb, "Cohort_exclusions_2024", pd.read_csv(T / "cohort_exclusions_2024.csv"))
    prim = pd.concat([pd.read_csv(T / f"primary_estimate_{y}.csv").assign(data_year=int(y)) for y in ("2024", "2023")])
    _sheet(wb, "Primary_estimate", prim, "Proportion of people insured on 12/31 who had a within-year gap (primary: >=1 uninsured month; alternative: >=3 consecutive). Logit 95% CI; Korn-Graubard bounds in kg_low/kg_high.")
    _sheet(wb, "Yearend_x_continuity_2024", pd.read_csv(T / "yearend_by_continuity_2024.csv"), "Weighted shares and totals of the four continuity classes in the primary domain.")
    _sheet(wb, "Rx_outcomes_2024", pd.read_csv(T / "rx_outcomes_2024.csv"), "Groups C1 to C5 share the primary domain (common denominator); Y1 and Y2 use frame Y (classification-specific, includes part-year in scope); R2a/R2b use the alternative gap definition.")
    _sheet(wb, "Rx_contrasts_2024", pd.read_csv(T / "rx_contrasts_2024.csv"), "Design-based differences between continuity classes (descriptive, not causal).")
    _sheet(wb, "Gap_details_2024", pd.read_csv(T / "gap_details_2024.csv"))
    _sheet(wb, "Transitions_2024", pd.read_csv(T / "monthly_transitions_2024.csv"), "Share of month-to-month transitions from each coverage state, primary domain.")
    if (T / "rx_imputation_2024.csv").exists():
        _sheet(wb, "Rx_imputation_2024", pd.read_csv(T / "rx_imputation_2024.csv"), "From HC-254A IMPFLAG: 2 complete pharmacy data, 4 fully imputed, 5 partially imputed.")
    for f, title in [("model_standardized_margins_2024.csv", "Model_margins_2024"), ("model_coefficients_2024.csv", "Model_coefficients_2024")]:
        if (T / f).exists():
            _sheet(wb, title, pd.read_csv(T / f), "Survey-weighted model; descriptive standardization only.")
    _sheet(wb, "Replication_2023_rx", pd.read_csv(T / "rx_outcomes_2023.csv"), "Prior-year replication (HC-251), reported separately; not pooled.")
    _sheet(wb, "Reconciliation", pd.read_csv(T / "validation_reconciliation_rollup.csv"))
    spec = pd.DataFrame([
        {"file": "estimates_long.csv", "grain": "data year x table x population group x measure x statistic", "filters_allowed": "data_year, table, population_group, measure",
         "show_with": "estimate with ci_low and ci_high; hide rows where suppress = TRUE; mark imprecise_flag", "never": "SUM/AVG of estimate; recomputed shares; pooled years"},
        {"file": "monthly_transitions.csv", "grain": "data year x from_state x to_state", "filters_allowed": "data_year, from_state",
         "show_with": "share and se; unweighted_transitions as a tooltip", "never": "summing shares across from_state"},
        {"file": "cohort_flow.csv", "grain": "data year x step", "filters_allowed": "data_year", "show_with": "n_unweighted and weighted_population", "never": "differences across years as trends"},
    ])
    _sheet(wb, "Tableau_fields", spec, "Import specification for the precomputed CSVs in outputs/tableau/. No dashboard is supplied and none was tested.")
    out = paths.OUTPUTS / "insurance_continuity_results.xlsx"
    wb.save(out)
    return paths.rel(out)


def run() -> dict:
    res = write_tableau()
    res["workbook"] = write_workbook()
    return res
