"""Project-relative paths. Nothing here depends on the machine the project runs on."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "config" / "study.json"
RAW = ROOT / "data" / "raw"
INTERIM = ROOT / "data" / "interim"
PROCESSED = ROOT / "data" / "processed"
OUTPUTS = ROOT / "outputs"
TABLES = OUTPUTS / "tables"
FIGURES = OUTPUTS / "figures"
LOGS = OUTPUTS / "logs"
DOCS = ROOT / "docs"
EVIDENCE = ROOT / "evidence"
HANDOFF = ROOT / "handoff"
SITE = ROOT / "site"
DELIVERABLES = ROOT / "deliverables"
MANUSCRIPT = ROOT / "manuscript"
SUBMISSION = ROOT / "submission"
LOCAL = ROOT / ".local"
SOURCE_MANIFEST = ROOT / "source_manifest.json"


def load_config() -> dict:
    with open(CONFIG, encoding="utf-8") as fh:
        return json.load(fh)


def ensure_dirs() -> None:
    for p in (RAW, INTERIM, PROCESSED, TABLES, FIGURES, LOGS, EVIDENCE, HANDOFF, LOCAL):
        p.mkdir(parents=True, exist_ok=True)


def rel(p: Path) -> str:
    """Path relative to the project root, with forward slashes."""
    return Path(p).resolve().relative_to(ROOT).as_posix()
