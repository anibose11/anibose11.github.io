"""Source-to-analysis data dictionary.

Each analysis variable is mapped to its AHRQ source variable(s), the codebook
description (read from the parsed codebook, not typed by hand), the codes used, the
transformation, how reserved codes are handled, and where the variable is used.
"""

from __future__ import annotations

import json

import pandas as pd

from . import paths

SPEC = [
    # analysis name, source template(s), transformation, reserved-code handling, used in
    ("person_id", ["DUPERSID"], "Copied. Unique key; uniqueness asserted in build.", "No reserved codes.", "All joins (one-to-one validated)"),
    ("panel", ["PANEL"], "Copied.", "None.", "Description; panel overlap note for replication"),
    ("weight", ["PERWT{yy}F"], "Copied. Full-year person weight.", "Zero weight kept in the design frame, excluded from frames by pos_weight.", "Survey design"),
    ("stratum", ["VARSTR"], "Copied.", "None.", "Survey design (strata)"),
    ("psu", ["VARPSU"], "Copied. Nested within stratum (nest = TRUE).", "None.", "Survey design (clusters)"),
    ("age", ["AGE{yy}X"], "Copied. Age on 12/31 of the data year.", "-1 (not in scope 12/31) fails the 18 to 64 filter.", "Frame filter; age_group covariate"),
    ("diabetes", ["DIABDX_M18"], "1 = ever told had diabetes (excluding gestational).", "-7, -8, -1 are not 'no'; counted in cohort exclusions and excluded from the cohort.", "Frame filter"),
    ("inscope_1231", ["INSC1231"], "1 = in scope on 12/31.", "2 = not in scope; excluded from frame Y.", "Frame Y"),
    ("end_ref_month", ["ENDRFM{yy}"], "Reference period end month.", "Must equal 12 for domain C.", "Domain C"),
    ("inscop_r31 / inscop_r42 / inscop_yy", ["INSCOP31", "INSCOP42", "INSCOP{yy}"], "Round-level scope status.", "Used only in the scope agreement audit, not as a filter.", "Scope audit"),
    ("ins_1231", ["INS{yy}X"], "Year-end coverage (covered on 12/31, or on the date the person left the RU).", "-1 = not eligible on 12/31; excluded from frame Y.", "Year-end classification"),
    ("ins_dec", ["INSDE{yy}X"], "Any coverage at any time in December.", "-1 = out of scope in December.", "Reconciliation"),
    ("any_cov (month 1 to 12)", ["INS{mm}{yy}X"], "Monthly any hospital/physician coverage (TRICARE/CHAMPVA, Medicare, Medicaid/CHIP, other public, private incl. Medigap, VA). IHS not counted.", "-1 = out of scope that month: never counted as uninsured; defines scope. Other negative codes or nulls = missing.", "Person-month table; continuity classes"),
    ("private_cov", ["PRI{mm}{yy}"], "Monthly any private hospital/physician coverage.", "-1 out of scope.", "Coverage state; reconciliation"),
    ("public_cov", ["PUB{mm}{yy}X"], "Monthly any public coverage (TRICARE/CHAMPVA, Medicare, Medicaid/CHIP, other public, VA).", "-1 out of scope.", "Coverage state; reconciliation"),
    ("medicare_cov", ["MCR{mm}{yy}X"], "Monthly Medicare (edited).", "-1 out of scope.", "Source changes"),
    ("medicaid_cov", ["MCD{mm}{yy}X"], "Monthly Medicaid/CHIP (edited).", "-1 out of scope.", "Source changes"),
    ("tricare_cov", ["TRI{mm}{yy}X"], "Monthly TRICARE/CHAMPVA (edited).", "-1 out of scope.", "Source changes; INSCOV reconciliation"),
    ("va_cov", ["VAP{mm}{yy}"], "Monthly VA coverage.", "-1 out of scope.", "Source changes"),
    ("other_public_cov", ["GVA{mm}{yy}"], "Monthly other public hospital/physician coverage (AHRQ: editing aid only).", "-1 out of scope.", "Source changes only"),
    ("ihs_cov", ["IHS{mm}{yy}"], "Monthly Indian Health Service. Not counted as coverage by AHRQ.", "-1 out of scope.", "Informational reconciliation"),
    ("coverage_state", ["INS{mm}{yy}X", "PRI{mm}{yy}", "PUB{mm}{yy}X"], "private_only, public_only, private_and_public, uninsured, not_in_scope, missing.", "Out of scope and missing kept as their own states.", "Transitions"),
    ("continuity_class", ["INS{yy}X", "INS{mm}{yy}X"], "inscont.continuity.classify_continuity rules 1 to 5.", "Unobserved months make continuity indeterminate unless a gap is observed.", "Primary classification"),
    ("continuity_class_alt", ["INS{yy}X", "INS{mm}{yy}X"], "As continuity_class, but a gap requires 3 or more consecutive uncovered months; 'insured_year_end_continuous' then means no such run.", "As above.", "Robustness check 2"),
    ("n_months_uncovered", ["INS{mm}{yy}X"], "Count of months with code 2.", "Out-of-scope and missing months not counted.", "Duration bands"),
    ("unins_year", ["UNINS{yy}"], "AHRQ annual indicator: uninsured all in-scope months.", "None.", "Reconciliation"),
    ("inscov_year", ["INSCOV{yy}"], "AHRQ annual coverage indicator (TRICARE grouped with private).", "None.", "Reconciliation"),
    ("rx_fills", ["RXTOT{yy}"], "Count of prescribed medicine fills and refills in the year.", "No reserved codes expected; checked.", "Any fill; mean fills"),
    ("rx_oop", ["RXSLF{yy}"], "Self/family prescription payments, nominal dollars of the data year.", "Negative or null would be 'missing_expenditure' (none expected: AHRQ imputes).", "OOP outcomes"),
    ("rx_total_exp", ["RXEXP{yy}"], "Total prescription payments from all sources.", "As above.", "Context; OOP share"),
    ("rx_state", ["RXTOT{yy}", "RXSLF{yy}"], "no_recorded_fill, fills_zero_oop, fills_positive_oop, missing_expenditure.", "Keeps no-fill, zero-OOP, and missing distinct.", "Outcome states"),
    ("rx_records_fully_imputed / partially_imputed / complete_pc", ["IMPFLAG (HC-254A)"], "Fill-level method of expenditure data creation, summed per person.", "2024 only; persons without fills get 0.", "Imputation description"),
    ("rx_oop_event_sum", ["RXSF24X (HC-254A)"], "Sum of fill-level OOP per person.", "2024 only.", "Reconciliation with RXSLF24"),
    ("age_group", ["AGE{yy}X"], "18-44, 45-64.", "None in frame.", "Adjustment set"),
    ("sex_label", ["SEX"], "Male, Female.", "None.", "Adjustment set"),
    ("race_eth4", ["RACETHX"], "Hispanic; NH White; NH Black; NH Asian, other, or multiple (codes 4 and 5 combined).", "None (edited/imputed by AHRQ).", "Adjustment set"),
    ("income2", ["POVCAT{yy}"], "Below 200% FPL (codes 1 to 3) versus 200% or more (codes 4 to 5).", "None (imputed by AHRQ).", "Adjustment set"),
    ("region_label", ["REGION{yy}"], "Census region on 12/31.", "-1 inapplicable.", "Description only"),
]


def write_dictionary(cfg: dict, cbs: dict) -> pd.DataFrame:
    rows = []
    for name, sources, transform, missing, used in SPEC:
        for year in ("2024", "2023"):
            yy = cfg["releases"][year]["yy"]
            puf = cfg["releases"][year]["puf"]
            src_names, descs, codes = [], [], []
            for s in sources:
                if "(HC-254A)" in s:
                    if year != "2024":
                        continue
                    base = s.split(" ")[0]
                    ent = cbs["2024rx"].get(base, {})
                    src_names.append(f"{base} [HC-254A]")
                    descs.append(ent.get("description") or "")
                    codes.append("; ".join(f"{r['value']} {r['label']}".strip() for r in ent.get("rows", [])[:8]))
                    continue
                if "{mm}" in s:
                    first = s.format(mm="JA", yy=yy)
                    last = s.format(mm="DE", yy=yy)
                    ent = cbs[year].get(first, {})
                    src_names.append(f"{first} .. {last}")
                else:
                    v = s.format(yy=yy)
                    ent = cbs[year].get(v, {})
                    src_names.append(v)
                descs.append(ent.get("description") or "")
                codes.append("; ".join(f"{r['value']} {r['label']}".strip() for r in ent.get("rows", [])[:8]))
            if not src_names:
                continue
            rows.append({"analysis_variable": name, "data_year": year, "source_file": puf if not any("HC-254A" in x for x in src_names) else "HC-254A",
                         "source_variables": " | ".join(src_names), "codebook_description": " | ".join(descs),
                         "codebook_codes_first_rows": " || ".join(codes), "transformation": transform,
                         "reserved_code_handling": missing, "used_in": used})
    df = pd.DataFrame(rows)
    df.to_csv(paths.TABLES / "data_dictionary.csv", index=False)
    (paths.DOCS / "data_dictionary.csv").write_text(df.to_csv(index=False), encoding="utf-8")
    return df
