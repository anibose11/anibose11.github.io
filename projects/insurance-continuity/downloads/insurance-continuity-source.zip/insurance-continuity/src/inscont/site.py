"""Static portfolio page and full report for site/projects/insurance-continuity/.

Everything is relative to the slug directory so the page works at
/projects/insurance-continuity/ in a later combined site. No JavaScript, no remote
fonts, system font stack only.
"""

from __future__ import annotations

import html
import re
import shutil

import pandas as pd

from . import paths
from .render import CSS, html_page, md_to_html

SLUG = "insurance-continuity"
ASSET_FIGS = ["fig1_yearend_vs_continuity_2024", "fig2_oop_spending_2024", "figS1_cohort_flow_2024",
              "figS2_robustness_gap_definitions", "figS3_monthly_uninsured_gap_group_2024", "fig1_yearend_vs_continuity_2023"]

DOWNLOADS = [
    ("outputs/insurance_continuity_results.xlsx", "insurance_continuity_results.xlsx", "Results workbook with a definitions sheet (Excel, aggregates only)"),
    ("outputs/tableau/estimates_long.csv", "tableau_estimates_long.csv", "Tableau-ready estimates with grain, units, CIs, and suppression flags (CSV)"),
    ("outputs/tableau/monthly_transitions.csv", "tableau_monthly_transitions.csv", "Month-to-month coverage transitions (CSV)"),
    ("outputs/tableau/cohort_flow.csv", "tableau_cohort_flow.csv", "Cohort flow counts (CSV)"),
    ("docs/tableau_spec.md", "tableau_spec.md", "Tableau import and filtering specification (Markdown)"),
    ("docs/data_dictionary.csv", "data_dictionary.csv", "Source-to-analysis data dictionary (CSV)"),
    ("docs/analysis_plan.md", "analysis_plan.md", "Time-stamped analysis plan with amendments (Markdown)"),
    ("docs/prior_art.csv", "prior_art.csv", "Related studies and tools (CSV)"),
    ("evidence/claims.json", "claims.json", "Reported values and source tables (JSON)"),
]


def slug_dir():
    return paths.SITE / "projects" / SLUG


def _fig(name: str, alt: str, caption: str) -> str:
    return (f'<figure><img src="assets/{name}.png" alt="{html.escape(alt)}" loading="lazy" width="1800">'
            f"<figcaption>{caption}</figcaption></figure>")


def lead_table(ctx: dict) -> str:
    xt = pd.read_csv(paths.TABLES / "yearend_by_continuity_2024.csv").set_index("class")
    rows = []
    labels = [("insured_year_end_continuous", "Insured on 12/31 and in all 12 months"),
              ("insured_year_end_gap", "Insured on 12/31 with at least 1 uninsured month"),
              ("uninsured_year_end", "Uninsured on 12/31"),
              ("indeterminate", "Continuity indeterminate")]
    for k, lab in labels:
        r = xt.loc[k]
        ci = "" if r["numerator_unweighted"] == 0 else f"{100 * r['ci_low']:.1f} to {100 * r['ci_high']:.1f}"
        rows.append(f"<tr><td>{lab}</td><td>{100 * r['estimate']:.1f}</td><td>{ci}</td><td>{int(r['numerator_unweighted']):,}</td>"
                    f"<td>{r['weighted_total'] / 1e6:.2f}</td></tr>")
    return ('<div class="table-wrap"><table><caption class="note" style="text-align:left;padding:8px 10px">Table view of the figure: primary domain, 2024 '
            f'(unweighted n = {ctx["n_domain_c_2024"]})</caption><thead><tr><th scope="col">Class</th><th scope="col">Weighted %</th>'
            '<th scope="col">95% CI</th><th scope="col">Unweighted n</th><th scope="col">Weighted people, millions</th></tr></thead><tbody>'
            + "".join(rows) + "</tbody></table></div>")


def index_html(ctx: dict, downloads: list[tuple[str, str, int]]) -> str:
    dl = "\n".join(f'<li><a href="downloads/{n}">{html.escape(d)}</a> <span class="note">({b / 1024:,.0f} KB)</span></li>' for n, d, b in downloads)
    body = f"""
<article>
<h1>Year-end coverage misses within-year gaps</h1>
<p class="lede">About one in twelve US adults aged 18 to 64 with diagnosed diabetes who were insured on December 31, 2024, had been uninsured earlier that year. I used the Medical Expenditure Panel Survey to compare their prescription use and spending with those insured all year.</p>
<p class="note">Animesh Bose, Norlowe Research</p>
<div class="question"><strong>Research question.</strong> Among US adults aged 18 to 64 with diagnosed diabetes who were insured on December 31, 2024, what share had at least one fully uninsured month that year, and how do annual prescription summaries change when monthly continuity is kept?</div>

{_fig("fig1_yearend_vs_continuity_2024", "Two stacked bars. Left: by the year-end indicator, 87.9 percent insured and 12.1 percent uninsured. Right: by monthly continuity, 80.4 percent insured all 12 months, 7.5 percent insured on December 31 after at least one uninsured month, and 12.1 percent uninsured on December 31.",
      f"The same {ctx['n_domain_c_2024']} adults under two coverage measures. Among those insured on December 31, {ctx['primary']} (95% CI, {ctx['primary_ci']}) had at least one fully uninsured month. Weighted shares; labels give unweighted counts.")}
{lead_table(ctx)}

<div class="stats" role="list">
<div class="stat" role="listitem"><div class="v">{ctx['primary']}</div><div class="l">of the year-end insured had a gap of at least 1 month in 2024 (95% CI, {ctx['primary_ci']}; {ctx['primary_num']} of {ctx['primary_n']} respondents)</div></div>
<div class="stat" role="listitem"><div class="v">{ctx['alt3']}</div><div class="l">had a gap of 3 or more consecutive months (95% CI, {ctx['alt3_ci']})</div></div>
<div class="stat" role="listitem"><div class="v">{ctx['primary_2023']}</div><div class="l">same measure in the separate 2023 replication (95% CI, {ctx['primary_2023_ci']})</div></div>
</div>

<h2>Out-of-scope and missing months are never counted as uninsured</h2>
<div class="prose">
<p>The analysis uses the AHRQ MEPS 2024 Full Year Consolidated file (HC-256, released August 2026), the 2024 Prescribed Medicines file for imputation flags, and the 2023 file for replication. MEPS records coverage on December 31 and, separately, any coverage in each calendar month. The primary domain is the {ctx['n_domain_c_2024']} adults aged 18 to 64 who reported ever being told they had diabetes and who were in scope for all 12 months, representing {ctx['w_domain_c_2024']} people.</p>
<p>Two decisions shaped the results. First, months when a person was outside the civilian noninstitutionalized population, and any month without usable information, are never counted as uninsured; they make continuity indeterminate unless a gap is observed. In the 2024 domain no month was missing, so the indeterminate class is empty, but the rule matters for anyone applying the classification to other data. Second, spending summaries are shown on a common denominator (the same people split by class) and on classification-specific denominators, so differences in who is in scope are not mistaken for coverage effects.</p>
<p>Estimates are design-based (Taylor linearization with the MEPS strata, primary sampling units, and full-year weight), with the whole file kept in the design and domains taken as subsets. A survey-weighted two-part model, fit only after a prespecified support rule was met, standardized spending for age, sex, race and ethnicity, and income, with jackknife replicate intervals.</p>
</div>

<h2>People with a gap filled fewer prescriptions, and their median spending was similar</h2>
{_fig("fig2_oop_spending_2024", "Dot and interval chart of annual out-of-pocket prescription spending for three groups: mean including zeros, mean among users, and median among users.",
      f"Annual out-of-pocket prescription spending by continuity class, 2024 dollars, with 95% CIs. Group sizes are unweighted; user subgroups are smaller.")}
<div class="prose">
<p>Adults insured on December 31 after a gap filled any prescription less often than the continuously insured ({ctx['anyfill_B']} vs {ctx['anyfill_A']}) and had fewer fills ({ctx['fills_B']} vs {ctx['fills_A']}). Their median out-of-pocket spending among users was about the same ({ctx['med_B']} vs {ctx['med_A']}). Their unadjusted mean was lower ({ctx['oop_B']} vs {ctx['oop_A']}), a difference partly driven by a few very large amounts among the continuously insured; the top 1% of people accounted for {ctx['top1_share']} of 2024 out-of-pocket dollars, and without them the means were {ctx['trim_A']} and {ctx['trim_B']}. Because the gap group is small, the summary for everyone insured on December 31 barely moved, with mean out-of-pocket spending of {ctx['oop_ye']} against {ctx['oop_A']} for the continuously insured. After adjustment the difference was {ctx['sm_BA']} (95% CI, {ctx['sm_BA_ci']}) in 2024 and {ctx['sm_BA_2023']} (95% CI, {ctx['sm_BA_2023_ci']}) in 2023, so the adjusted difference was imprecise and changed sign between years.</p>
</div>

<h2>The estimate is a lower bound and supports description only</h2>
<div class="prose">
<ul>
<li>A month counts as covered if any day was covered, so gaps shorter than a calendar month are invisible. The estimate is a lower bound on people with any uninsured day.</li>
<li>Coverage is self-reported in interview rounds and edited by AHRQ; the year-end and December values come from the same interviews.</li>
<li>Out-of-pocket spending describes payments made. It is not a measure of affordability or unmet need, and it covers all prescribed medicines, not only diabetes drugs.</li>
<li>The gap group has {ctx['primary_num']} respondents, so its subgroup estimates are imprecise, and a few very large amounts dominate the means.</li>
<li>Uninsured months are counted within 2024, so gaps that began in 2023 are truncated at January.</li>
<li>The design is cross-sectional and descriptive. Nothing here estimates what coverage gaps cause.</li>
</ul>
</div>

<h2>How the results were checked</h2>
<div class="prose">
<p>The pipeline reproduces AHRQ's annual uninsured and coverage indicators from the monthly data for every record, matches the codebook's printed weighted frequencies, and matches fill counts and out-of-pocket totals between the prescription and person files. An independent SQL classification and a separately written variance calculation agree with the main implementation. All {ctx['n_source_checks']} source reconciliation checks and {ctx['n_cross_checks']} software cross-checks passed. To reproduce:</p>
<pre><code>./setup.sh
./icont all      # acquire, build, analyze, validate, render, package
./icont test     # unit tests on synthetic fixtures
./icont demo     # fast demo on synthetic records (not study evidence)</code></pre>
</div>

<h2>Report and downloads</h2>
<ul class="files">
<li><a href="report.html">Full report, tables and references</a></li>
<li><a href="downloads/{SLUG}-source.zip">Source archive: code, SQL, R, configuration, tests, documentation, and result tables</a></li>
{dl}
</ul>
</article>
"""
    return html_page("Insurance continuity and prescription spending in diabetes", body,
                     "Within-year coverage gaps among US adults aged 18 to 64 with diabetes who were insured at year end, MEPS 2024: measurement study with design-based estimates.",
                     crumbs="Projects / insurance-continuity")


def report_html(ctx: dict, man_text: str, supp_text: str, counts: dict) -> str:
    t = man_text.replace("../outputs/figures/", "assets/")
    title_m = re.match(r"# (.+)\n", t)
    title = title_m.group(1) if title_m else "Report"
    t = t[title_m.end():] if title_m else t
    # Place figures and tables inline near their first mention.
    fig1 = "\n\n![Figure 1. Year-end status versus monthly continuity, MEPS 2024](assets/fig1_yearend_vs_continuity_2024.png)\n\n*Figure 1. The same adults classified by year-end coverage (left) and by monthly continuity (right). Weighted shares; labels give unweighted counts.*\n\n"
    fig2 = "\n\n![Figure 2. Out-of-pocket prescription spending by continuity class, MEPS 2024](assets/fig2_oop_spending_2024.png)\n\n*Figure 2. Annual out-of-pocket prescription spending by class, 2024 dollars, with 95% CIs.*\n\n"
    t = t.replace("### Year-End Status Versus Monthly Continuity\n\n", "### Year-End Status Versus Monthly Continuity\n\n" + fig1, 1)
    t = t.replace("### Prescription Use and Spending\n\n", "### Prescription Use and Spending\n\n" + fig2, 1)
    t = re.sub(r"## Figure legends.*", "", t, flags=re.S)
    supp = supp_text.replace("../outputs/figures/", "assets/")
    supp = re.sub(r"^# Supplemental Digital Content\n\n.*?\n\n", "", supp, count=1, flags=re.S)
    front = f"""
<p class="note">Author: Animesh Bose, BS, Norlowe Research. Data: AHRQ MEPS HC-256 (2024), HC-254A (2024), HC-251 (2023).</p>
<nav class="toc" aria-label="Report contents"><strong>Contents:</strong> <a href="#abstract">Abstract</a> | <a href="#introduction">Introduction</a> | <a href="#methods">Methods</a> | <a href="#results">Results</a> | <a href="#discussion">Discussion</a> | <a href="#references">References</a> | <a href="#tables">Tables</a> | <a href="#supplementary-material">Supplementary material</a> | <a href="#reproducibility">Reproducibility</a></nav>
"""
    repro = f"""
## Reproducibility

- Pipeline stages: `./icont acquire`, `build`, `analyze`, `validate`, `render`, `package` (or `./icont all`). `./icont rerun` rebuilds from cached raw files and compares every numeric output.
- Software: Python with pandas, DuckDB, matplotlib, openpyxl, and python-docx; {ctx['r_version_short']} with survey {ctx['survey_version']} and data.table. Versions are locked in `requirements.lock` and `R/packages.lock.csv`.
- Source files: SHA-256 checksums, URLs, release dates, and access dates are recorded for every AHRQ file, and `./icont acquire` stops if a download differs from the version analyzed here. Raw MEPS files are not redistributed.
- Evidence: `evidence/claims.json` maps each headline number to an output table, row, and column, with numerators, denominators, scope, and source checksums.
- Checks: unit tests on synthetic records, {ctx['n_source_checks']} reconciliation checks against the AHRQ source files, and {ctx['n_cross_checks']} software cross-checks all passed; my separate checks are described in Methods. External scientific validation, such as comparison with an independent data source, was not part of this study.
"""
    body_md = t + "\n\n## Supplementary material\n\n" + supp + "\n" + repro
    body = f"<article><h1>{html.escape(title)}</h1>{front}" + md_to_html(body_md) + "</article>"
    return html_page(title, body, "Full scientific report: within-year coverage gaps and prescription spending among US adults with diabetes, MEPS 2024.",
                     crumbs="Projects / insurance-continuity / report")


def build(ctx: dict, man_text: str, supp_text: str, counts: dict) -> dict:
    d = slug_dir()
    if d.exists():
        shutil.rmtree(d)
    (d / "assets").mkdir(parents=True)
    (d / "downloads").mkdir(parents=True)
    (d / "assets" / "site.css").write_text(CSS, encoding="utf-8")
    for f in ASSET_FIGS:
        shutil.copy2(paths.FIGURES / f"{f}.png", d / "assets" / f"{f}.png")
    downloads = []
    for src, name, desc in DOWNLOADS:
        p = paths.ROOT / src
        if p.exists():
            shutil.copy2(p, d / "downloads" / name)
            downloads.append((name, desc, p.stat().st_size))
    (d / "index.html").write_text(index_html(ctx, downloads), encoding="utf-8")
    (d / "report.html").write_text(report_html(ctx, man_text, supp_text, counts), encoding="utf-8")
    return {"slug_dir": paths.rel(d), "downloads": [n for n, _, _ in downloads]}
