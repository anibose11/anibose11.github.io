"""Analyze stage: run the R survey analysis for the primary year and the replication year."""

from __future__ import annotations

import os
import subprocess

from . import paths


def run() -> None:
    env = dict(os.environ)
    env["R_LIBS_USER"] = str(paths.ROOT / ".Rlib")
    env["INSCONT_ROOT"] = str(paths.ROOT)
    for year in ("2024", "2023"):
        log = paths.LOGS / f"analyze_{year}.log"
        with open(log, "w", encoding="utf-8") as fh:
            proc = subprocess.run(["Rscript", "--vanilla", str(paths.ROOT / "R" / "analysis.R"), year],
                                  cwd=paths.ROOT, env=env, stdout=fh, stderr=subprocess.STDOUT)
        tail = log.read_text(encoding="utf-8").strip().splitlines()[-3:]
        print("\n".join(tail))
        if proc.returncode != 0:
            raise RuntimeError(f"R analysis failed for {year}; see {paths.rel(log)}")
