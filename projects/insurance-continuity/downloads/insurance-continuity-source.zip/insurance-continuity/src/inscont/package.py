"""Package stage: source archive, handoff files, public-number check, and the outer bundle.

The source archive uses an explicit allowlist. Person-level data, environments, caches,
raw MEPS files, private handoff notes, submission files with contact details, and the
site and deliverables folders are never included.
"""

from __future__ import annotations

import datetime as dt
import fnmatch
import hashlib
import json
import re
import zipfile
from pathlib import Path

import pandas as pd

from . import paths, results, runtime

SLUG = "insurance-continuity"
BUNDLE = "01-insurance-continuity-PROJECT-BUNDLE.zip"
MAX_BUNDLE_BYTES = 28 * 1024 * 1024

ALLOW = [
    "README.md", "LICENSE", "NOTICE.md", "CITATION.cff", "icont", "setup.sh", "requirements.txt", "requirements.lock",
    "source_manifest.json", "config/*.json", "src/inscont/*.py", "sql/*.sql", "R/*.R", "R/packages.lock.csv",
    "tests/*.py", "tests/fixtures/*", "docs/*.md", "docs/*.csv", "docs/*.json", "scripts/*.py",
    "manuscript/*.md", "outputs/tables/*.csv", "outputs/figures/*.png", "outputs/figures/*.svg", "outputs/estimates_*.json",
    "outputs/tableau/*.csv", "outputs/insurance_continuity_results.xlsx", "outputs/demo/*.csv",
    "outputs/logs/build_summary.json", "outputs/logs/validation_summary.json", "outputs/logs/rerun_check.json",
    "outputs/logs/runtime_manifest.json", "outputs/logs/render_manifest.json", "outputs/logs/figures.json",
    "outputs/logs/sql_rendered_*.sql", "evidence/claims.json",
]
DENY = ["config/status.json", "src/inscont/submission.py", "data/*", ".venv/*", ".Rlib/*", ".local/*", "handoff/*", "deliverables/*", "site/*", "submission/*", "*/__pycache__/*",
        "*.pyc", "*.DS_Store", ".git/*", "outputs/logs/analyze_*.log", "outputs/logs/snapshot_*.json"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def allowlisted_files() -> list[Path]:
    out = []
    skip_dirs = {".venv", ".Rlib", ".local", "data", "deliverables", "site", "handoff", "submission", ".git", "__pycache__"}
    for p in sorted(paths.ROOT.rglob("*")):
        rel_parts = p.relative_to(paths.ROOT).parts
        if rel_parts and rel_parts[0] in skip_dirs or "__pycache__" in rel_parts:
            continue
        if p.is_symlink() or not p.is_file():
            continue
        r = p.relative_to(paths.ROOT).as_posix()
        if any(fnmatch.fnmatch(r, d) for d in DENY):
            continue
        if any(fnmatch.fnmatch(r, a) for a in ALLOW):
            out.append(p)
    return out


def scan_for_machine_paths(files: list[Path]) -> list[str]:
    bad = []
    # Built from fragments so this file does not match its own pattern.
    pat = re.compile("|".join(["/" + "Users/", "/" + "private/tmp", "/" + "home/[a-z]", "C:" + r"\\\\Users"]))
    for p in files:
        if p.suffix.lower() in (".png", ".xlsx", ".zip"):
            continue
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if pat.search(txt):
            bad.append(paths.rel(p))
    return bad


def private_terms_guard(files: list[Path]) -> list[str]:
    """Optional check against a private term list kept outside the archive (.local/), for text reserved for journal files."""
    tf = paths.LOCAL / "disclosure_terms.json"
    if not tf.exists():
        return []
    terms = json.loads(tf.read_text(encoding="utf-8")).get("terms", [])
    if not terms:
        return []
    pat = re.compile("|".join(re.escape(t) for t in terms))
    bad = []
    for p in files:
        if p.suffix.lower() in (".png", ".xlsx", ".zip", ".pdf", ".eps", ".tiff"):
            continue
        if pat.search(p.read_text(encoding="utf-8", errors="ignore")):
            bad.append(paths.rel(p))
    return bad


def person_level_guard(files: list[Path]) -> list[str]:
    """Reject any CSV that carries person identifiers."""
    bad = []
    for p in files:
        r = paths.rel(p)
        if r.startswith(("tests/fixtures/", "outputs/demo/")):
            continue  # invented records, labelled synthetic, permitted as fixtures
        if p.suffix == ".csv":
            head = p.read_text(encoding="utf-8", errors="ignore").split("\n", 1)[0].lower()
            if "dupersid" in head or "person_id" in head:
                bad.append(paths.rel(p))
    return bad


def write_zip(target: Path, members: list[tuple[Path, str]]) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        target.unlink()
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src, arc in members:
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 7, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o755 if arc.endswith(("icont", "setup.sh")) else 0o644) << 16
            zf.writestr(zi, src.read_bytes())
    with zipfile.ZipFile(target) as zf:
        if zf.testzip() is not None:
            raise RuntimeError(f"ZIP integrity check failed: {target}")


LITERATURE_VALUES = {"25.2%", "14.5%", "27.1%", "15.6%", "18.2%", "7.8%", "14.3%", "25.3%", "40%", "9.0%", "1%", "3%", "30%", "130%",
                     "200%", "95%", "5%"}  # cited-source figures and method thresholds, not study results


def _table_tokens() -> set:
    """Every value in the output tables formatted the way the pages print it."""
    toks = set()
    for f in paths.TABLES.glob("*.csv"):
        try:
            df = pd.read_csv(f)
        except Exception:
            continue
        for c in df.columns:
            if df[c].dtype.kind not in "fi":
                continue
            for v in df[c].dropna():
                v = float(v)
                if -1.5 <= v <= 1.5:
                    toks.add(f"{100 * v:.1f}%")
                    toks.add(f"{100 * v:.2f}%")
                    toks.add(f"{100 * v:.0f}%")
                toks.add(f"${abs(v):,.0f}")
                toks.add(f"{100 * abs(v):.1f}%")
    return toks


def public_number_check(ctx: dict) -> pd.DataFrame:
    """Every % and $ figure on the public pages must equal a value produced by the pipeline (or a cited-source figure)."""
    known = set(LITERATURE_VALUES) | _table_tokens()
    for k, v in ctx.items():
        if isinstance(v, str):
            for tok in re.findall(r"\$\d{1,3}(?:,\d{3})*|\d+(?:\.\d+)?%", v):
                known.add(tok)
    rows = []
    for page in ("index.html", "report.html"):
        txt = (paths.SITE / "projects" / SLUG / page).read_text(encoding="utf-8")
        txt = re.sub(r"<[^>]+>", " ", txt)
        for tok in re.findall(r"\$\d{1,3}(?:,\d{3})*|\d+(?:\.\d+)?%", txt):
            rows.append({"page": page, "token": tok, "matched_results_value": tok in known})
    df = pd.DataFrame(rows)
    df.to_csv(paths.TABLES / "validation_public_numbers.csv", index=False)
    return df


def handoff_files(ctx: dict, public: list[dict], source_zip: Path, status: dict) -> None:
    paths.HANDOFF.mkdir(exist_ok=True)
    man = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
    claims = json.loads((paths.EVIDENCE / "claims.json").read_text(encoding="utf-8"))
    keyed = {c["key"]: c for c in claims["claims"]}
    def finding(key: str, text: str) -> dict:
        c = keyed[key]
        return {"finding": text, "value": c["value"], "formatted": c["formatted"], "evidence_path": c["output_path"],
                "row_selector": c["row_selector"], "column": c["column"], "numerator_unweighted": c["numerator_unweighted"],
                "denominator_unweighted": c["denominator_unweighted"], "scope": c["analysis_scope"]}
    findings = [
        finding("primary", f"Share of adults 18-64 with diagnosed diabetes insured on 12/31/2024 who had >=1 fully uninsured month in 2024 (95% CI {ctx['primary_ci']})"),
        finding("alt3", f"Same, >=3 consecutive uninsured months (95% CI {ctx['alt3_ci']})"),
        finding("primary_2023", f"Separate 2023 replication of the primary estimate (95% CI {ctx['primary_2023_ci']})"),
        finding("anyfill_B", "Any prescription fill, insured on 12/31 with a gap (class B), 2024"),
        finding("anyfill_A", "Any prescription fill, insured all 12 months (class A), 2024"),
        finding("med_B", "Median OOP Rx spending among users, class B, 2024"),
        finding("med_A", "Median OOP Rx spending among users, class A, 2024"),
        finding("oop_ye", "Mean OOP Rx spending incl. zeros, all insured on 12/31 (A+B), 2024"),
        finding("oop_A", "Mean OOP Rx spending incl. zeros, class A, 2024"),
        finding("sm_BA", f"Standardized OOP difference B minus A, 2024 (95% CI {ctx['sm_BA_ci']})"),
    ]
    data_versions = {k: {"puf": v["puf"], "title": v["detail_page_check"]["page_title"], "release_date": v["detail_page_check"]["release_date"],
                         "reference_period": v["reference_period"], "access_date_utc": v["access_date_utc"],
                         "data_zip_sha256": v["files"]["data_zip"]["sha256"]} for k, v in man["releases"].items()}
    handoff = {
        "slug": SLUG,
        "title": "Insured on December 31, uninsured earlier in the year: within-year coverage gaps and prescription spending among US adults with diabetes",
        "featured": True,
        "summary": (f"Design-based analysis of MEPS 2024 (HC-256) estimating that {ctx['primary']} (95% CI {ctx['primary_ci']}) of adults 18-64 with diagnosed "
                    f"diabetes who were insured on December 31 had at least one fully uninsured month that year ({ctx['primary_2023']} in a 2023 replication), "
                    "with prescription use and out-of-pocket spending compared under year-end and monthly continuity classifications, and a reusable "
                    "coverage-continuity audit function."),
        "status": status,
        "data_versions": data_versions,
        "key_limitations": [
            "Monthly coverage counts a month as covered if any day was covered; gaps shorter than a month are invisible, so the estimate is a lower bound.",
            "Coverage is self-reported in interview rounds; the year-end and December values come from the same interviews.",
            f"Class B (year-end insured with a gap) has {ctx['primary_num']} unweighted respondents in 2024; several subgroup estimates fail the NCHS presentation standard.",
            "Out-of-pocket spending covers all prescribed medicines, includes imputed payments, and is not a measure of affordability.",
            "Cross-sectional and descriptive; no causal effects of coverage gaps are estimated.",
        ],
        "entry_page": f"site/projects/{SLUG}/index.html",
        "report": f"site/projects/{SLUG}/report.html",
        "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip",
        "executed_commands": ["./setup.sh", "./icont acquire", "./icont build", "./icont analyze", "./icont validate", "./icont rerun",
                              "./icont render", "./icont package", "./icont test", "./icont demo",
                              "python3 scripts/clean_room_check.py (extract final source archive; ./setup.sh; ./icont test; ./icont demo; ./icont acquire, build, analyze, validate; compare tables)",
                              "python3 scripts/check_site.py (extract outer bundle; serve site/ over local HTTP; check pages, links, anchors, images, downloads)",
                              "./icont bundle"],
        "measured_findings": findings,
        "run_id": ctx["run_id"],
        "public_files": public,
        "private_files_note": "submission/ in the outer bundle holds the journal submission files and is not for publication",
    }
    (paths.HANDOFF / f"{SLUG}.json").write_text(json.dumps(handoff, indent=2, default=str), encoding="utf-8")

    roll = pd.read_csv(paths.TABLES / "validation_reconciliation_rollup.csv")
    cross = pd.read_csv(paths.TABLES / "validation_primary_cross_check.csv")
    rr = json.loads((paths.LOGS / "rerun_check.json").read_text(encoding="utf-8")) if (paths.LOGS / "rerun_check.json").exists() else {}
    clean = json.loads((paths.LOGS / "clean_room.json").read_text(encoding="utf-8")) if (paths.LOGS / "clean_room.json").exists() else {}
    site_check = (paths.LOGS / "site_check.json")
    site_check = json.loads(site_check.read_text(encoding="utf-8")) if site_check.exists() else {}
    pubnum = pd.read_csv(paths.TABLES / "validation_public_numbers.csv")
    ip = paths.LOGS / "independent_validation.json"
    if ip.exists():
        iv = json.loads(ip.read_text(encoding="utf-8"))
        y4, y3 = iv["2024"], iv["2023"]
        indep_summary = (f"checksums {iv['checksums_match_manifest']} against the manifest and {iv['checksums_match_analyzed_release']} against the analyzed release; "
                         f"2024 cohort {y4['adults_diabetes_pos_weight']:,}, {y4['in_scope_1231']:,}, {y4['domain_all_year']:,}; classes A {y4['class_counts']['A']}, "
                         f"B {y4['class_counts']['B']}, C {y4['class_counts']['C']}, D {y4['class_counts']['D']}; primary proportion {y4['proportion']:.6f} (SE {y4['se']:.6f}), "
                         f"identical to the pipeline: {y4['matches_pipeline']}; 2023 identical: {y3['matches_pipeline']}; sampled classifications {y4['sampled_records_agree']}; "
                         f"manuscript numbers checked {iv['manuscript_numbers']['tokens_checked']}, unmatched {len(iv['manuscript_numbers']['unmatched'])}; "
                         f"DOIs resolved with matching titles {iv['references']['titles_match']} of {iv['references']['dois_checked']}")
    else:
        indep_summary = "not yet run"
    hard = roll[~roll["informational"]]
    v = f"""# Validation record: {SLUG}

Run ID: {ctx['run_id']}. Generated {dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()}.

Three kinds of computational checks are kept separate (sections 1 to 3), followed by my review (section 4). None is external scientific validation.

Editorial revision, October 12, 2026: the results below describe the original research run. The prose and packages were revised without rerunning acquisition or statistical analysis. A prior archive check applies to the hash recorded in that check, not automatically to this revised archive.

## 1. Software testing (synthetic fixtures only)

- Unit tests: {ctx['tests_summary'].split(' passed')[0]} unit tests, all passed (`./icont test`). They cover person-month reshaping, multiple sources in one month, missing months, out-of-scope months, a person insured in December but uninsured earlier (must be a gap), a change of coverage source without a gap (must not be a gap), annual expenditure states, unchanged person counts, duplicate-ID rejection, and a planted reconciliation error that the SQL must catch.
- Demo: `./icont demo` runs 8 invented records through the classifier. It is not study evidence.

## 2. Source reconciliation (real MEPS files)

- {int((hard['kind'] == 'source reconciliation').sum())} source reconciliation checks across 2024 and 2023 (the prescription-file checks apply to 2024); failures: {int(((hard['kind'] == 'source reconciliation') & (hard['n_mismatch'] > 0)).sum())}.
- Includes: 12 person-month rows per person and unchanged person counts; AHRQ annual indicators (UNINS, INSCOV) reproduced from the monthly table for every record; INSmm = PRImm or PUBmm for every person-month; out-of-scope codes consistent across sources; computed weighted and unweighted frequencies equal to the AHRQ codebook; HC-254A fill counts and out-of-pocket and total payment sums equal to the person-level RXTOT24, RXSLF24, and RXEXP24 for all 19,140 records.
- Informational, not errors: {ctx['n_departure_2024']} records in 2024 whose 12/31 value AHRQ recorded at their departure date (none in the analytic domain).

## 3. Software cross-checks (second implementations, not independent expert validation)

- {int((hard['kind'] == 'software cross-check').sum())} software cross-checks: an independent SQL classification agreed with the Python audit function for every record in both years, and uninsured-month counts agreed.
- An independent Python implementation of the with-replacement Taylor variance reproduced the primary estimate and standard error: 2024 difference in estimate {cross.loc[0, 'abs_diff_estimate']:.2e}, in SE {cross.loc[0, 'abs_diff_se']:.2e}; 2023 {cross.loc[1, 'abs_diff_estimate']:.2e} and {cross.loc[1, 'abs_diff_se']:.2e}.
- Rerun from cached raw files: {(format(rr['values_compared'], ',') + ' numeric values compared, ' + str(rr['values_differing']) + ' differing beyond tolerance ' + str(rr['tolerance_abs'])) if rr else 'not yet run'}.
- Public numbers: {int(pubnum['matched_results_value'].sum())} of {len(pubnum)} percentage and dollar figures on the project page and report match pipeline outputs or cited-source figures.
- Independent re-check (scripts/independent_validation.py, written separately from the pipeline and reading the AHRQ Stata files directly): {indep_summary}.
- Clean-room check of the source archive: {clean.get('summary', 'not yet run').rstrip('.')}.
- Site check: {site_check.get('summary', 'not yet run').rstrip('.')}.

## 4. Author review and validation

I checked the work using the steps below. Expected values are listed so each step can be checked against the outputs.

| Step | What I checked | Expected value or file |
|---|---|---|
| 1 | SHA-256 of the downloaded AHRQ files | `source_manifest.json` (HC-256 data zip begins {json.loads(paths.SOURCE_MANIFEST.read_text())['releases']['2024']['files']['data_zip']['sha256'][:12]}) |
| 2 | Cohort counts recomputed in a separately written script from `h256.dta` | {ctx['n_diabetes_2024']} adults 18-64 with diabetes and positive weight; {ctx['n_frame_y_2024']} in scope 12/31; {ctx['n_domain_c_2024']} in scope all year |
| 3 | Class counts in the primary domain | A {ctx['share_A_num']}, B {ctx['share_B_num']}, C {ctx['share_C_num']}, D 0 |
| 4 | Primary proportion and SE with survey software outside the pipeline | {ctx['primary_raw']:.4f} (SE {pd.read_csv(paths.TABLES / 'primary_estimate_2024.csv').iloc[0]['se']:.4f}), denominator {ctx['primary_n']}, numerator {ctx['primary_num']} |
| 5 | Monthly coverage sequences of 25 randomly sampled domain members against their classes | `scripts/sample_records_for_review.py` (seed 2024) |
| 6 | Every number in the text, tables, and figures against the output files | `evidence/claims.json`, `outputs/tables/` |
| 7 | Each cited source reread for the statements attributed to it | `docs/references_verified.csv`, `docs/prior_art.csv` |
"""
    (paths.HANDOFF / f"{SLUG}-validation.md").write_text(v, encoding="utf-8")

    vr = ["# Verified results (private handoff for resume editing)", "",
          f"Run ID {ctx['run_id']}. Only measured results with their evidence paths. No deployment, collaborator, adoption, publication, or citation is claimed.", "",
          "## Methods actually used", "",
          "- MEPS HC-256 (2024) and HC-251 (2023) Full Year Consolidated files; HC-254A (2024) Prescribed Medicines file for imputation flags and reconciliation.",
          "- Python and DuckDB SQL for acquisition, codebook parsing, person-month construction, classification, and reconciliation; R survey for design-based estimation (Taylor linearization; JKn replicates for the two-part model).",
          f"- A reusable coverage-continuity audit function with an explicit indeterminate class and audit table; {ctx['tests_summary'].split(' passed')[0]} unit tests on synthetic fixtures (all passed); {ctx['n_source_checks']} source reconciliation checks and {ctx['n_cross_checks']} software cross-checks with zero failures.", "",
          "## Measured results", ""]
    for f in findings:
        n_txt = f"n = {f['denominator_unweighted']}; " if f["denominator_unweighted"] is not None else ""
        vr.append(f"- {f['finding']}: {f['formatted']} ({n_txt}evidence: {f['evidence_path']}, {f['row_selector']}, column {f['column']})")
    vr += ["", "## Counts kept separate", "",
           f"- Source records: {ctx['n_records_2024']} (2024 file).",
           f"- Eligible primary domain: {ctx['n_domain_c_2024']} adults (2024).",
           f"- Test set: {ctx['tests_summary'].split(' passed')[0]} unit tests on synthetic fixtures (not study observations).",
           "- Model calls: none in the analysis pipeline.",
           f"- Detected data issues: 0 reconciliation failures; {ctx['n_departure_2024']} informational departure-date records in 2024."]
    (paths.HANDOFF / "verified_results.md").write_text("\n".join(vr) + "\n", encoding="utf-8")


def run(status: dict | None = None, rebuild_source: bool = True) -> dict:
    ctx, _ = results.collect()
    src_zip = paths.SITE / "projects" / SLUG / "downloads" / f"{SLUG}-source.zip"
    files = allowlisted_files()
    if rebuild_source:
        runtime.write()
        files = allowlisted_files()
        bad_paths = scan_for_machine_paths(files)
        if bad_paths:
            raise RuntimeError(f"Machine-specific paths found in packaged files: {bad_paths}")
        bad_person = person_level_guard(files)
        if bad_person:
            raise RuntimeError(f"Person-level identifiers in packaged CSVs: {bad_person}")
        site_files = [p for p in (paths.SITE / "projects" / SLUG).rglob("*") if p.is_file()]
        bad_terms = private_terms_guard(files + site_files)
        if bad_terms:
            raise RuntimeError(f"Reserved terms found in public files: {bad_terms}")
        contact = paths.LOCAL / "author_contact.json"
        if contact.exists():
            email = json.loads(contact.read_text(encoding="utf-8")).get("email", "")
            leaks = [paths.rel(p) for p in files if email and p.suffix.lower() not in (".png", ".xlsx") and email in p.read_text(encoding="utf-8", errors="ignore")]
            if leaks:
                raise RuntimeError(f"Author contact details found in packaged files: {leaks}")
        write_zip(src_zip, [(p, f"{SLUG}/" + paths.rel(p)) for p in files])
    pub_check = public_number_check(ctx)
    site_dir = paths.SITE / "projects" / SLUG
    public = [{"path": paths.rel(p), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in sorted(site_dir.rglob("*")) if p.is_file()]
    sp = paths.CONFIG.parent / "status.json"
    status = status or (json.loads(sp.read_text(encoding="utf-8")) if sp.exists() else
                        {"computational_completion": "complete (rebuilt from the public source archive)", "manuscript_status": "see manuscript/",
                         "submission_status": "not submitted", "unresolved_prerequisites": []})
    handoff_files(ctx, public, src_zip, status)
    bad_handoff = private_terms_guard([paths.HANDOFF / f"{SLUG}.json", paths.HANDOFF / f"{SLUG}-validation.md", paths.HANDOFF / "verified_results.md"])
    if bad_handoff:
        raise RuntimeError(f"Reserved terms found in handoff files: {bad_handoff}")
    members = [(p, paths.rel(p)) for p in sorted(site_dir.rglob("*")) if p.is_file()]
    members += [(paths.HANDOFF / f"{SLUG}.json", f"handoff/{SLUG}.json"),
                (paths.HANDOFF / f"{SLUG}-validation.md", f"handoff/{SLUG}-validation.md"),
                (paths.HANDOFF / "verified_results.md", "handoff/verified_results.md")]
    journal = paths.SUBMISSION / "medical-care"
    if journal.exists():
        notice = paths.SUBMISSION / "README-not-for-publication.md"
        notice.write_text("# Journal submission files: not for publication\n\nThe files in submission/medical-care/ are for upload to the journal's "
                          "submission system. They contain the corresponding author's contact details and journal-only declarations. Do not copy "
                          "this folder to the portfolio site; the site uses only site/projects/insurance-continuity/.\n", encoding="utf-8")
        members += [(notice, "submission/README-not-for-publication.md")]
        members += [(p, "submission/medical-care/" + p.name) for p in sorted(journal.iterdir()) if p.is_file()]
    bundle = paths.DELIVERABLES / BUNDLE
    write_zip(bundle, members)
    size = bundle.stat().st_size
    if size > MAX_BUNDLE_BYTES:
        raise RuntimeError(f"Bundle is {size} bytes, above the 28 MiB target")
    digest = sha256(bundle)
    (paths.DELIVERABLES / (BUNDLE + ".sha256")).write_text(f"{digest}  {BUNDLE}\n", encoding="utf-8")
    out = {"source_zip": paths.rel(src_zip), "source_files": len(files), "source_zip_bytes": src_zip.stat().st_size,
           "bundle": paths.rel(bundle), "bundle_bytes": size, "bundle_sha256": digest,
           "public_numbers_unmatched": pub_check[~pub_check["matched_results_value"]]["token"].tolist()}
    (paths.LOGS / "package_summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"[package] {json.dumps(out)}")
    return out
