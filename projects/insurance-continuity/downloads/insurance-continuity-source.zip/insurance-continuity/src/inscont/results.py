"""Collect every headline number from the output tables, with its evidence path.

The manuscript, report, portfolio page, handoff, and evidence/claims.json all read
numbers from here, so no result is typed by hand. Each claim records the output file,
the row selector, the column, numerator and denominator where they exist, scope, and
the source hashes and run ID.
"""

from __future__ import annotations

import hashlib
import json

import pandas as pd

from . import paths


def _fmt_pct(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}%"


def _fmt_usd(x: float) -> str:
    return f"${x:,.0f}"


class Collector:
    def __init__(self) -> None:
        self.claims: list[dict] = []
        self.ctx: dict = {}
        man = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
        self.source_hashes = {k: {kind: rec["sha256"] for kind, rec in v["files"].items()} for k, v in man["releases"].items()}
        self.run_id = run_id()

    def table(self, name: str) -> pd.DataFrame:
        return pd.read_csv(paths.TABLES / name)

    def row(self, name: str, **filters) -> pd.Series:
        df = self.table(name)
        m = pd.Series(True, index=df.index)
        for k, v in filters.items():
            m &= df[k] == v
        sub = df[m]
        if len(sub) != 1:
            raise KeyError(f"{name} {filters}: {len(sub)} rows")
        return sub.iloc[0]

    def add(self, key: str, value, formatted: str, file: str, selector: dict, column: str, scope: str,
            numerator=None, denominator=None, extra: dict | None = None, releases: list[str] | None = None) -> None:
        self.ctx[key] = formatted
        self.ctx[key + "_raw"] = value
        if releases is None:
            yr = selector.get("year") if isinstance(selector, dict) else None
            releases = ["2023"] if (str(yr) == "2023" or "2023" in file) else ["2024"]
        rec = {"key": key, "value": value, "formatted": formatted, "output_path": f"outputs/tables/{file}" if not file.startswith("outputs/") else file,
               "row_selector": selector, "column": column, "numerator_unweighted": numerator,
               "denominator_unweighted": denominator, "analysis_scope": scope,
               "configuration": "config/study.json",
               "source_sha256": {r: self.source_hashes.get(r, {}) for r in releases},
               "run_id": self.run_id}
        if extra:
            rec.update(extra)
        self.claims.append(rec)

    def prop(self, key: str, file: str, scope: str, **filters) -> pd.Series:
        r = self.row(file, **filters)
        self.add(key, float(r["estimate"]), _fmt_pct(r["estimate"]), file, filters, "estimate", scope,
                 int(r["numerator_unweighted"]) if pd.notna(r.get("numerator_unweighted")) else None, int(r["n_unweighted"]))
        if pd.notna(r.get("ci_low")):
            self.ctx[key + "_ci"] = f"{_fmt_pct(r['ci_low'])} to {_fmt_pct(r['ci_high'])}"
        self.ctx[key + "_n"] = f"{int(r['n_unweighted']):,}"
        if pd.notna(r.get("numerator_unweighted")):
            self.ctx[key + "_num"] = f"{int(r['numerator_unweighted']):,}"
        self.ctx[key + "_flag"] = str(r.get("reliability"))
        return r

    def usd(self, key: str, file: str, scope: str, **filters) -> pd.Series:
        r = self.row(file, **filters)
        self.add(key, float(r["estimate"]), _fmt_usd(r["estimate"]), file, filters, "estimate", scope, None, int(r["n_unweighted"]))
        if pd.notna(r.get("ci_low")) and pd.notna(r.get("ci_high")):
            self.ctx[key + "_ci"] = f"{_fmt_usd(r['ci_low'])} to {_fmt_usd(r['ci_high'])}"
        else:
            self.ctx[key + "_ci"] = "upper bound not estimable"
        self.ctx[key + "_n"] = f"{int(r['n_unweighted']):,}"
        self.ctx[key + "_flag"] = str(r.get("reliability"))
        return r

    def num(self, key: str, file: str, scope: str, column: str = "estimate", fmt: str = "{:.1f}", **filters) -> pd.Series:
        r = self.row(file, **filters)
        self.add(key, float(r[column]), fmt.format(r[column]), file, filters, column, scope, None,
                 int(r["n_unweighted"]) if "n_unweighted" in r and pd.notna(r["n_unweighted"]) else None)
        if "ci_low" in r and pd.notna(r.get("ci_low")):
            self.ctx[key + "_ci"] = f"{fmt.format(r['ci_low'])} to {fmt.format(r['ci_high'])}"
        return r


def run_id() -> str:
    """Deterministic run ID: hash of config, SQL, R, and Python source plus raw-file hashes."""
    h = hashlib.sha256()
    for p in sorted(list((paths.ROOT / "sql").glob("*.sql")) + list((paths.ROOT / "R").glob("*.R")) +
                    list((paths.ROOT / "src" / "inscont").glob("*.py")) + [paths.CONFIG]):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    man = json.loads(paths.SOURCE_MANIFEST.read_text(encoding="utf-8"))
    for k in sorted(man["releases"]):
        for kind in sorted(man["releases"][k]["files"]):
            h.update(man["releases"][k]["files"][kind]["sha256"].encode())
    return "run-" + h.hexdigest()[:12]


def collect() -> tuple[dict, list[dict]]:
    c = Collector()
    ctx = c.ctx
    for year in ("2024", "2023"):
        y = year
        flow = c.table(f"cohort_flow_{y}.csv")
        for i, key in enumerate(["records", "pos_weight", "adults", "diabetes", "frame_y", "domain_c"]):
            r = flow.iloc[i]
            c.add(f"n_{key}_{y}", int(r["n_unweighted"]), f"{int(r['n_unweighted']):,}", f"cohort_flow_{y}.csv", {"step": int(r["step"])},
                  "n_unweighted", "Cohort flow (unweighted records)")
            ctx[f"w_{key}_{y}"] = f"{r['weighted_population'] / 1e6:.1f} million"
        sfx = "" if y == "2024" else "_2023"
        c.prop(f"primary{sfx}", f"primary_estimate_{y}.csv", f"Domain C, insured on 12/31/{y}",
               measure="Year-end insured with >=1 uninsured month")
        c.prop(f"alt3{sfx}", f"primary_estimate_{y}.csv", f"Domain C, insured on 12/31/{y}",
               measure="Year-end insured with >=3 consecutive uninsured months")
        for k, lab in [("A", "insured_year_end_continuous"), ("B", "insured_year_end_gap"), ("C", "uninsured_year_end")]:
            r = c.prop(f"share_{k}{sfx}", f"yearend_by_continuity_{y}.csv", f"Domain C {y}, all classes", **{"class": lab})
            ctx[f"wt_{k}{sfx}"] = f"{r['weighted_total'] / 1e6:.2f} million"
            c.add(f"wtotal_{k}{sfx}", float(r["weighted_total"]), ctx[f"wt_{k}{sfx}"], f"yearend_by_continuity_{y}.csv",
                  {"class": lab}, "weighted_total", f"Domain C {y}", int(r["numerator_unweighted"]), None)
        c.prop(f"ye_insured_frame_y{sfx}", f"yearend_status_by_frame_{y}.csv", f"Frame Y {y}", group="Frame Y (in scope 12/31, includes part-year)")
        c.num(f"gap_mean_months{sfx}", f"gap_details_{y}.csv", f"Year-end insured with gap {y}", measure="Mean uninsured months")
        c.prop(f"gap_start_pattern{sfx}", f"gap_details_{y}.csv", f"Year-end insured with gap {y}", measure="Pattern: uninsured_at_start_then_insured")
        c.prop(f"switch_no_gap{sfx}", f"switch_without_gap_{y}.csv", f"Continuously insured {y}",
               measure="Change in coverage sources without an uninsured month")
        groups = {"all": "C1 Domain C: all", "ye": "C2 Domain C: insured on 12/31 (A+B)", "A": "C3 Domain C: A insured all 12 months",
                  "B": "C4 Domain C: B insured on 12/31 with gap", "C": "C5 Domain C: C uninsured on 12/31",
                  "Y1": "Y1 Frame Y: insured on 12/31", "Y2": "Y2 Frame Y: uninsured on 12/31",
                  "R2a": "R2a Domain C: insured on 12/31, no 3+ month gap", "R2b": "R2b Domain C: insured on 12/31 with 3+ month gap"}
        for gk, gl in groups.items():
            f = f"rx_outcomes_{y}.csv"
            c.prop(f"anyfill_{gk}{sfx}", f, gl, group=gl, measure="Any prescription fill")
            c.num(f"fills_{gk}{sfx}", f, gl, group=gl, measure="Mean fills (incl. refills)")
            c.usd(f"oop_{gk}{sfx}", f, gl, group=gl, measure="Mean OOP Rx spending incl. zeros (USD)")
            c.usd(f"oopu_{gk}{sfx}", f, gl, group=gl, measure="Mean OOP Rx spending among users (USD)")
            c.usd(f"med_{gk}{sfx}", f, gl, group=gl, measure="OOP Rx spending among users (USD) p50")
            c.usd(f"p90_{gk}{sfx}", f, gl, group=gl, measure="OOP Rx spending among users (USD) p90")
            c.prop(f"zero_{gk}{sfx}", f, gl, group=gl, measure="Users with zero OOP")
            c.usd(f"tot_{gk}{sfx}", f, gl, group=gl, measure="Mean total Rx expenditure, all payers (USD)")
        con = c.table(f"rx_contrasts_{y}.csv")
        for _, r in con.iterrows():
            key = {"Mean OOP incl. zeros (USD)": "d_oop", "Mean OOP among users (USD)": "d_oopu", "Any fill (proportion)": "d_anyfill",
                   "Mean fills": "d_fills"}[r["measure"]] + ("_BA" if r["contrast"].startswith("B") else "_CA") + sfx
            if "proportion" in r["measure"]:
                f = lambda v: f"{100 * v:.1f}"
                unit = " percentage points"
            elif "USD" in r["measure"]:
                f = lambda v: (f"-${abs(v):,.0f}" if v < 0 else f"${v:,.0f}")
                unit = ""
            else:
                f = lambda v: f"{v:.1f}"
                unit = ""
            c.add(key, float(r["estimate"]), f(r["estimate"]) + unit, f"rx_contrasts_{y}.csv", {"measure": r["measure"], "contrast": r["contrast"]},
                  "estimate", f"Domain C {y}, design-based contrast")
            ctx[key + "_ci"] = f"{f(r['ci_low'])} to {f(r['ci_high'])}"
        mg = c.table(f"model_standardized_margins_{y}.csv")
        for _, r in mg.iterrows():
            key = {"Standardized mean OOP: A": "sm_A", "Standardized mean OOP: B": "sm_B", "Standardized mean OOP: C": "sm_C",
                   "Standardized difference B minus A": "sm_BA", "Standardized difference C minus A": "sm_CA"}[r["quantity"]] + sfx
            val = float(r["estimate"])
            fv = (f"-${abs(val):,.0f}" if val < 0 else f"${val:,.0f}")
            c.add(key, val, fv, f"model_standardized_margins_{y}.csv", {"quantity": r["quantity"]}, "estimate", f"Domain C {y}, two-part model")
            lo, hi = float(r["ci_low"]), float(r["ci_high"])
            ctx[key + "_ci"] = f"{('-$' + format(abs(lo), ',.0f')) if lo < 0 else '$' + format(lo, ',.0f')} to {('-$' + format(abs(hi), ',.0f')) if hi < 0 else '$' + format(hi, ',.0f')}"
            ctx[f"model_replicates{sfx}"] = f"{int(r['n_replicates'])}"
            ctx[f"model_nonconverged{sfx}"] = f"{int(r['part1_nonconverged']) + int(r['part2_nonconverged'])}"
        est = json.loads((paths.OUTPUTS / f"estimates_{y}.json").read_text(encoding="utf-8"))
        c.add(f"deff{sfx}", float(est["primary_design_effect"]), f"{est['primary_design_effect']:.2f}", f"outputs/estimates_{y}.json",
              {"field": "primary_design_effect"}, "primary_design_effect", f"Domain C {y}, insured on 12/31")
        ctx[f"design_df{sfx}"] = str(int(est["primary"]["design_df"]))
        ctx[f"n_strata{sfx}"] = str(est["design"]["n_strata"])
        ctx[f"n_psus{sfx}"] = str(est["design"]["n_psus"])
        ctx[f"two_part_decision{sfx}"] = est["two_part_support"]["decision"]
        ctx[f"part1_minority{sfx}"] = str(est["two_part_support"]["part1_minority"])
        ctx[f"pos_B{sfx}"] = str(est["two_part_support"]["positive_per_group"]["B"])
        ctx[f"wden_primary{sfx}"] = f"{est['primary']['weighted_denominator'] / 1e6:.1f} million"
        t1 = c.table(f"table1_characteristics_{y}.csv")
        ctx[f"t1_{y}"] = t1
    # imputation
    imp = c.table("rx_imputation_2024.csv")
    for k in ("A", "B", "C"):
        r = imp[(imp["group"] == f"Class {k}") & (imp["measure"] == "Users with >=1 fill with fully or partially imputed payments")].iloc[0]
        c.add(f"imp_any_{k}", float(r["estimate"]), _fmt_pct(r["estimate"]), "rx_imputation_2024.csv",
              {"group": f"Class {k}", "measure": r["measure"]}, "estimate", f"Users in class {k}, 2024", int(r["numerator_unweighted"]), int(r["n_unweighted"]),
              releases=["2024", "2024rx"])
        r = imp[(imp["group"] == f"Class {k}") & (imp["measure"] == "Share of OOP dollars from fills with imputed payments")].iloc[0]
        c.add(f"imp_oop_{k}", float(r["estimate"]), _fmt_pct(r["estimate"]), "rx_imputation_2024.csv",
              {"group": f"Class {k}", "measure": r["measure"]}, "estimate", f"Users in class {k}, 2024", releases=["2024", "2024rx"])
    # transitions
    tr = c.table("monthly_transitions_2024.csv")
    def tshare(a, b):
        return float(tr[(tr["from_state"] == a) & (tr["to_state"] == b)]["share"].iloc[0])
    exit_unins = 1 - tshare("Uninsured", "Uninsured")
    c.add("monthly_exit_uninsured", exit_unins, _fmt_pct(exit_unins), "monthly_transitions_2024.csv",
          {"from_state": "Uninsured", "to_state": "Uninsured"}, "share", "Domain C 2024, person-month transitions", extra={"derivation": "1 minus share"})
    ent_unins = (tshare("Private only", "Uninsured"), tshare("Public only", "Uninsured"))
    ctx["monthly_private_to_unins"] = _fmt_pct(ent_unins[0], 2)
    ctx["monthly_public_to_unins"] = _fmt_pct(ent_unins[1], 2)
    # diagnostics and validation
    dg = c.table("diagnostic_oop_concentration.csv")
    for y in ("2024", "2023"):
        sfx = "" if y == "2024" else "_2023"
        r = dg[(dg["year"] == int(y)) & (dg["diagnostic"] == "Share of weighted OOP dollars from the top 1% of persons")].iloc[0]
        c.add(f"top1_share{sfx}", float(r["value"]), _fmt_pct(r["value"], 0), "diagnostic_oop_concentration.csv",
              {"year": int(y), "diagnostic": r["diagnostic"]}, "value", f"Domain C {y} (post hoc diagnostic)", None, None,
              {"n_unweighted_in_top": int(r["n_unweighted_in_top"])})
        ctx[f"top1_n{sfx}"] = str(int(r["n_unweighted_in_top"]))
        r = dg[(dg["year"] == int(y)) & (dg["diagnostic"] == "Maximum annual OOP, insured_year_end_continuous")].iloc[0]
        c.add(f"max_oop_A{sfx}", float(r["value"]), _fmt_usd(r["value"]), "diagnostic_oop_concentration.csv",
              {"year": int(y), "diagnostic": r["diagnostic"]}, "value", f"Domain C {y}, class A (post hoc diagnostic)")
        for k, lab in (("A", "insured_year_end_continuous"), ("B", "insured_year_end_gap")):
            r = dg[(dg["year"] == int(y)) & (dg["diagnostic"] == f"Mean OOP excluding the domain top 1%, {lab}")].iloc[0]
            c.add(f"trim_{k}{sfx}", float(r["value"]), _fmt_usd(r["value"]), "diagnostic_oop_concentration.csv",
                  {"year": int(y), "diagnostic": r["diagnostic"]}, "value", f"Domain C {y}, class {k} excluding the domain top 1% (post hoc diagnostic)")
    roll = c.table("validation_reconciliation_rollup.csv")
    hard = roll[~roll["informational"]]
    ctx["n_recon_checks"] = str(len(hard))
    ctx["n_recon_fail"] = str(int((hard["n_mismatch"] > 0).sum()))
    ctx["n_source_checks"] = str(int((hard["kind"] == "source reconciliation").sum()))
    ctx["n_source_fail"] = str(int(((hard["kind"] == "source reconciliation") & (hard["n_mismatch"] > 0)).sum()))
    ctx["n_cross_checks"] = str(int((hard["kind"] == "software cross-check").sum()))
    ctx["n_cross_fail"] = str(int(((hard["kind"] == "software cross-check") & (hard["n_mismatch"] > 0)).sum()))
    cross = c.table("validation_primary_cross_check.csv")
    ctx["cross_check_ok"] = bool(cross["agrees_within_1e-9"].all())
    ctx["n_departure_2024"] = str(int(roll[(roll["year"] == 2024) & (roll["check"] == "info_year_end_value_recorded_at_departure_date")]["n_mismatch"].iloc[0]))
    vs = json.loads((paths.LOGS / "validation_summary.json").read_text(encoding="utf-8"))
    ctx["tests_summary"] = vs["tests"]["summary"]
    rr = paths.LOGS / "rerun_check.json"
    if rr.exists():
        rj = json.loads(rr.read_text(encoding="utf-8"))
        ctx["rerun_values"] = f"{rj['values_compared']:,}"
        ctx["rerun_diffs"] = str(rj["values_differing"])
    ctx["run_id"] = c.run_id
    return ctx, c.claims


def write_claims() -> dict:
    ctx, claims = collect()
    paths.EVIDENCE.mkdir(parents=True, exist_ok=True)
    out = {"run_id": ctx["run_id"], "generated_from": "src/inscont/results.py",
           "note": ("Every headline number maps to an output table, row selector, and column. Source record counts, eligible cohort sizes, "
                    "and model statistics are separate keys. No model calls or annotation sets are involved in this study."),
           "claims": claims}
    (paths.EVIDENCE / "claims.json").write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    return out
