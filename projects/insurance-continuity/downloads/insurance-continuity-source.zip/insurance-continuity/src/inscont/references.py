"""AMA-style references built from Crossref metadata (cached) plus official reports.

Every DOI was resolved during the prior-art search; this module fetches the Crossref
record once, caches it in docs/references_crossref.json, and formats it. Official
AHRQ, NCHS, and statutory sources are listed with their URLs and access dates.
"""

from __future__ import annotations

import json
import re

import requests

from . import paths

ACCESSED = "Accessed October 7, 2026."

DOIS = {
    "gulley2011": "10.2105/AJPH.2010.191569",
    "wang2021": "10.2337/dc20-2833",
    "gai2020": "10.1186/s12913-020-05226-1",
    "cao2026": "10.3389/fpubh.2026.1965839",
    "short2012": "10.1177/1077558712454195",
    "graves2016": "10.1111/1475-6773.12449",
    "pascale2016": "10.1111/1475-6773.12312",
    "lester2025": "10.3122/jabfm.2024.240186R1",
    "huguet2026": "10.1001/jamahealthforum.2026.0034",
    "sommers2016": "10.1377/hlthaff.2016.0455",
    "roberts2016": "10.1097/MLR.0000000000000509",
    "bepo2024": "10.1007/s11606-024-08961-x",
    "fang2023": "10.1001/jama.2023.5747",
    "goldman2020": "10.1377/hlthaff.2019.00378",
    "abdus2014": "10.1097/MLR.0000000000000167",
    "lumley2004": "10.18637/jss.v009.i08",
    "woodruff1952": "10.1080/01621459.1952.10483443",
}

ABBREV = {
    "American Journal of Public Health": "Am J Public Health",
    "Diabetes Care": "Diabetes Care",
    "BMC Health Services Research": "BMC Health Serv Res",
    "Frontiers in Public Health": "Front Public Health",
    "Medical Care Research and Review": "Med Care Res Rev",
    "Health Services Research": "Health Serv Res",
    "The Journal of the American Board of Family Medicine": "J Am Board Fam Med",
    "Journal of the American Board of Family Medicine": "J Am Board Fam Med",
    "JAMA Health Forum": "JAMA Health Forum",
    "Health Affairs": "Health Aff (Millwood)",
    "Medical Care": "Med Care",
    "Journal of General Internal Medicine": "J Gen Intern Med",
    "JAMA": "JAMA",
    "Journal of Statistical Software": "J Stat Softw",
    "Journal of the American Statistical Association": "J Am Stat Assoc",
}

OFFICIAL = {
    "hc256": ("Agency for Healthcare Research and Quality. *MEPS HC-256: 2024 Full Year Consolidated Data File*. Agency for "
              "Healthcare Research and Quality; August 2026. " + ACCESSED +
              " https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-256"),
    "hc254a": ("Agency for Healthcare Research and Quality. *MEPS HC-254A: 2024 Prescribed Medicines File*. Agency for "
               "Healthcare Research and Quality; July 2026. " + ACCESSED +
               " https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-254A"),
    "hc251": ("Agency for Healthcare Research and Quality. *MEPS HC-251: 2023 Full Year Consolidated Data File*. Agency for "
              "Healthcare Research and Quality; August 2025. " + ACCESSED +
              " https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-251"),
    "chu2013": ("Chu MC. *The Uninsured in America, 1996-2012: Estimates for the U.S. Civilian Noninstitutionalized Population under Age 65*. "
                "Statistical Brief #420. Agency for Healthcare Research and Quality; August 2013. " + ACCESSED +
                " https://meps.ahrq.gov/data_files/publications/st420/stat420.pdf"),
    "rhoades2015": ("Rhoades JA. *Spells of Uninsurance: Estimates for the U.S. Civilian Noninstitutionalized Population under Age 65, 2013*. "
                    "Statistical Brief #476. Agency for Healthcare Research and Quality; June 2015. " + ACCESSED +
                    " https://meps.ahrq.gov/data_files/publications/st476/stat476.pdf"),
    "keenan2019": ("Keenan PS, Vistnes J. *Non-Elderly Adults Ever Uninsured During the Calendar Year, 2013-2016*. Research Findings #42. "
                   "Agency for Healthcare Research and Quality; June 2019. " + ACCESSED +
                   " https://meps.ahrq.gov/data_files/publications/rf42/rf42.pdf"),
    "vistnes2019": ("Vistnes J, Keenan P. *Uninsured All Year, 2013-2016: Estimates for Non-Elderly Adults by Selected Population Sub-groups "
                    "and State Medicaid Expansion Status*. Research Findings #40. Agency for Healthcare Research and Quality; "
                    "January 2019. " + ACCESSED + " https://meps.ahrq.gov/data_files/publications/rf40/rf40.pdf"),
    "parker2017": ("Parker JD, Talih M, Malec DJ, et al. National Center for Health Statistics data presentation standards for proportions. "
                   "*Vital Health Stat 2*. 2017;(175):1-22. " + ACCESSED + " https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf"),
    "usc5000a": ("Requirement to maintain minimum essential coverage, 26 USC §5000A(e)(4) (2018). " + ACCESSED +
                 " https://www.law.cornell.edu/uscode/text/26/5000A"),
    "macarthur2026": ("Mac Arthur NS, Abraham JM, Drew JAR, et al. Insurance coverage disruptions and associated access and utilization, "
                      "2008 to 2022. *Med Care Res Rev*. Published online October 1, 2026. doi:10.1177/10775587261484437"),
    "ahrqgithub": ("Agency for Healthcare Research and Quality. HHS-AHRQ/MEPS workshop exercise 5b (SAS and Stata) [computer program]. "
                   "GitHub repository, commit 02fbdd634959e97bd3584c3e9abdc62f84291d70; June 9, 2026. " + ACCESSED +
                   " https://github.com/HHS-AHRQ/MEPS"),
}


def _crossref_cache() -> dict:
    cache_path = paths.DOCS / "references_crossref.json"
    cache = json.loads(cache_path.read_text(encoding="utf-8")) if cache_path.exists() else {}
    changed = False
    for key, doi in DOIS.items():
        if key in cache:
            continue
        r = requests.get(f"https://api.crossref.org/works/{doi}", timeout=30,
                         headers={"User-Agent": "inscont-research-pipeline/1.0 (mailto withheld)"})
        r.raise_for_status()
        m = r.json()["message"]
        cache[key] = {"doi": doi, "title": m.get("title", [""])[0], "container": (m.get("container-title") or [""])[0],
                      "authors": [{"family": a.get("family", ""), "given": a.get("given", "")} for a in m.get("author", [])],
                      "volume": m.get("volume"), "issue": m.get("issue"), "page": m.get("page") or m.get("article-number"),
                      "year": (m.get("issued", {}).get("date-parts") or [[None]])[0][0]}
        changed = True
    if changed:
        cache_path.write_text(json.dumps(cache, indent=1, ensure_ascii=False), encoding="utf-8")
    return cache


# AMA uses sentence-case article titles. Titles below keep the source wording and punctuation and
# change only capitalization. Year/page overrides use the print issue where Crossref gives the online date.
OVERRIDES = {
    "gulley2011": {"title": "Ongoing coverage for ongoing care: access, utilization, and out-of-pocket spending among uninsured working-aged adults with chronic health care needs"},
    "wang2021": {"title": "National trends in out-of-pocket costs among U.S. adults with diabetes aged 18–64 years: 2001–2017"},
    "cao2026": {"title": "Duration of health insurance coverage gaps and subsequent cost-related barriers to care among adults aged 18–64 years with multimorbidity"},
    "short2012": {"title": "New estimates of gaps and transitions in health insurance"},
    "graves2016": {"title": "Health insurance dynamics: methodological considerations and a comparison of estimates from two surveys"},
    "pascale2016": {"title": "Understanding the new Current Population Survey health insurance questions", "year": 2016},
    "lester2025": {"title": "Insurance instability among community-based health center patients with diabetes post-Affordable Care Act Medicaid expansion"},
    "huguet2026": {"title": "Insurance churn and diabetes outcomes among patients with low income"},
    "sommers2016": {"title": "Insurance churning rates for low-income adults under health reform: lower than expected but still harmful for many"},
    "roberts2016": {"title": "Does churning in Medicaid affect health care use?"},
    "bepo2024": {"title": "Disparities in use of novel diabetes medications by insurance: a nationally representative cohort study"},
    "fang2023": {"title": "Cost-related insulin rationing in US adults younger than 65 years with diabetes", "page": "1700-1702"},
    "goldman2020": {"title": "Among low-income adults enrolled in Medicaid, churning decreased after the Affordable Care Act"},
    "abdus2014": {"title": "Part-year coverage and access to care for nonelderly adults"},
    "lumley2004": {"title": "Analysis of complex survey samples", "page": "1-19"},
    "woodruff1952": {"title": "Confidence intervals for medians and other position measures"},
}


def _initials(given: str) -> str:
    parts = re.split(r"[\s\-.]+", given.strip())
    return "".join(p[0].upper() for p in parts if p)


def _ama(rec: dict) -> str:
    au = rec["authors"]
    names = [f"{a['family']} {_initials(a['given'])}".strip() for a in au]
    if len(names) > 3:  # Medical Care: more than 3 authors -> first 3, then et al
        names = names[:3] + ["et al"]
    authors = ", ".join(names)
    title = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", rec["title"])).strip().rstrip(".")
    end = "" if title.endswith(("?", "!")) else "."
    journal = ABBREV.get(rec["container"], rec["container"])
    vol = rec.get("volume") or ""
    iss = f"({rec['issue']})" if rec.get("issue") else ""
    page = (rec.get("page") or "").replace("--", "-")
    loc = f"{rec['year']};{vol}{iss}:{page}" if page else f"{rec['year']};{vol}{iss}"
    return f"{authors}. {title}{end} *{journal}*. {loc}. doi:{rec['doi']}"


def reference_strings() -> dict[str, str]:
    cache = _crossref_cache()
    out = {k: _ama({**v, **OVERRIDES.get(k, {})}) for k, v in cache.items()}
    out.update(OFFICIAL)
    return out


def number_citations(text: str, refs: dict[str, str]) -> tuple[str, list[tuple[int, str, str]]]:
    """Replace [@a; @b] markers with AMA superscript numbers in order of first citation."""
    order: list[str] = []

    def repl(m: re.Match) -> str:
        keys = [k.strip().lstrip("@") for k in m.group(1).split(";")]
        nums = []
        for k in keys:
            if k not in refs:
                raise KeyError(f"Unknown reference key {k}")
            if k not in order:
                order.append(k)
            nums.append(order.index(k) + 1)
        nums = sorted(set(nums))
        # compress runs: 1,2,3 -> 1-3
        parts, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            parts.append(f"{nums[i]}-{nums[j]}" if j - i >= 2 else ",".join(str(n) for n in nums[i:j + 1]))
            i = j + 1
        return "<sup>" + ",".join(parts) + "</sup>"

    new = re.sub(r"\[(@[^\]]+)\]", repl, text)
    new = re.sub(r"([;:])(<sup>[^<]+</sup>)", r"\2\1", new)  # AMA: numbers go inside colons and semicolons
    return new, [(i + 1, k, refs[k]) for i, k in enumerate(order)]


ACCESS = {
    "chu2013": ("official report, full text read", "AHRQ PDF"), "rhoades2015": ("official report, full text read", "AHRQ PDF"),
    "short2012": ("full text read", "PubMed Central author manuscript"), "pascale2016": ("full text read", "PubMed Central"),
    "hc256": ("official documentation read", "AHRQ documentation and codebook"), "hc254a": ("official documentation read", "AHRQ documentation and codebook"),
    "hc251": ("official documentation read", "AHRQ documentation and codebook"),
    "lester2025": ("full text read", "PubMed Central"), "huguet2026": ("full text read", "PubMed Central"),
    "sommers2016": ("full text read", "Harvard DASH accepted manuscript"), "fang2023": ("full text read", "PubMed Central"),
    "keenan2019": ("official report, full text read", "AHRQ PDF"), "vistnes2019": ("official report, full text read", "AHRQ PDF"),
    "gulley2011": ("full text read", "PubMed Central"), "abdus2014": ("abstract only", "PubMed abstract; full text not accessible"),
    "gai2020": ("full text read", "PubMed Central"),
    "goldman2020": ("abstract only", "PubMed abstract; publisher full text returned HTTP 403; cited only for what the abstract states"),
    "macarthur2026": ("abstract only", "PubMed abstract; publisher full text returned HTTP 403; cited only for what the abstract states"),
    "wang2021": ("full text read", "PubMed Central author manuscript"), "bepo2024": ("full text read", "Europe PMC"),
    "usc5000a": ("statutory text read", "Cornell Legal Information Institute"),
    "lumley2004": ("methods reference for the survey software", "open-access article; cited for the software, not for findings"),
    "parker2017": ("official report, full text read", "CDC PDF"),
    "woodruff1952": ("methods reference for the quantile interval", "cited for the method implemented in the survey package"),
    "cao2026": ("full text read", "PubMed Central"), "roberts2016": ("full text read", "PubMed Central author manuscript"),
    "graves2016": ("full text read", "PubMed Central"), "ahrqgithub": ("program code read", "GitHub repository, exercise 5b SAS and Stata files"),
}


def write_verified_list(numbered, out_path) -> None:
    import csv
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["number", "key", "citation", "access_level", "source_read", "identifier_check"])
        for n, k, s in numbered:
            lvl, src = ACCESS.get(k, ("not recorded", ""))
            ident = "Crossref DOI resolved 2026-10-07" if (k in DOIS or "doi:" in s) else "official URL fetched 2026-10-07"
            w.writerow([n, k, s.replace("*", ""), lvl, src, ident])
