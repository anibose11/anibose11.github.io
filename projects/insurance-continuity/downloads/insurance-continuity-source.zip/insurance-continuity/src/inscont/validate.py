"""Validate stage.

Three kinds of checks are kept separate, as the report requires:

* Software testing: the pytest suite on synthetic fixtures.
* Source reconciliation: person-month table against AHRQ annual indicators, weighted
  frequencies against the printed codebook, and HC-254A fills against HC-256 totals.
* Software cross-check: the primary estimate and its standard error recomputed in
  Python with an independent implementation of the with-replacement stratified
  cluster (Taylor linearization) variance, compared with R survey.

None of these is external scientific validation.
"""

from __future__ import annotations

import json
import subprocess
import sys

import numpy as np
import pandas as pd

from . import paths


def taylor_domain_proportion(df: pd.DataFrame, y: str, domain: pd.Series) -> dict:
    """Domain proportion and its linearized variance, with-replacement PSUs nested in strata."""
    w = df["weight"].to_numpy(float)
    dmask = domain.to_numpy(bool)
    yv = df[y].to_numpy(float)
    nd = (w * dmask).sum()
    p = (w * dmask * yv).sum() / nd
    z = w * dmask * (yv - p) / nd
    t = pd.DataFrame({"stratum": df["stratum"].to_numpy(), "psu": df["psu"].to_numpy(), "z": z})
    psu_tot = t.groupby(["stratum", "psu"], as_index=False)["z"].sum()
    var = 0.0
    singletons = 0
    for _, g in psu_tot.groupby("stratum"):
        n_h = len(g)
        if n_h < 2:
            singletons += 1
            continue
        var += n_h / (n_h - 1) * ((g["z"] - g["z"].mean()) ** 2).sum()
    n_psu = len(psu_tot)
    n_strata = psu_tot["stratum"].nunique()
    return {"estimate": float(p), "se": float(np.sqrt(var)), "design_df_full": int(n_psu - n_strata),
            "singleton_strata": singletons}


def run_tests() -> dict:
    proc = subprocess.run([sys.executable, "-m", "pytest", "-q", str(paths.ROOT / "tests")], cwd=paths.ROOT,
                          capture_output=True, text=True)
    tail = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else proc.stderr[-400:]
    return {"returncode": proc.returncode, "summary": tail}


def reconciliation_rollup() -> pd.DataFrame:
    rows = []
    for year in ("2024", "2023"):
        r = pd.read_csv(paths.TABLES / f"reconciliation_{year}.csv")
        for rec in r.itertuples():
            rows.append({"year": year, "kind": "source reconciliation" if not rec.check_name.startswith("python_") else "software cross-check",
                         "check": rec.check_name, "n_checked": rec.n_checked, "n_mismatch": rec.n_mismatch,
                         "informational": rec.check_name.startswith("info_"), "definition": rec.definition})
        c = pd.read_csv(paths.TABLES / f"codebook_frequency_reconciliation_{year}.csv")
        rows.append({"year": year, "kind": "source reconciliation", "check": "codebook_weighted_and_unweighted_frequencies",
                     "n_checked": len(c), "n_mismatch": int((~c["unweighted_match"] | ~c["weighted_match_within_1"]).sum()),
                     "informational": False,
                     "definition": "Computed frequencies of INS(12/31), INSCOV, UNINS, INSJA, INSDE, DIABDX_M18, INSC1231, INSURC and the weight total equal the AHRQ codebook (weighted within 1 person-weight unit, which is the codebook rounding)"})
        rx = paths.TABLES / f"rx_reconciliation_{year}.csv"
        if rx.exists():
            for rec in pd.read_csv(rx).itertuples():
                rows.append({"year": year, "kind": "source reconciliation", "check": rec.check_name, "n_checked": rec.n_checked,
                             "n_mismatch": rec.n_mismatch, "informational": False, "definition": rec.definition})
    return pd.DataFrame(rows)


def cross_check_primary(year: str) -> dict:
    df = pd.read_csv(paths.PROCESSED / f"analysis_{year}.csv", dtype={"person_id": str})
    dom = (df["domain_c"] == 1) & (df["year_end_insured"] == 1)
    df["gap_flag"] = (df["cls_gap"] == 1).astype(int)
    py = taylor_domain_proportion(df, "gap_flag", dom)
    est = json.loads((paths.OUTPUTS / f"estimates_{year}.json").read_text(encoding="utf-8"))
    r_p, r_se = est["primary"]["estimate"], est["primary"]["se"]
    return {"year": year, "python_estimate": py["estimate"], "r_estimate": r_p, "abs_diff_estimate": abs(py["estimate"] - r_p),
            "python_se": py["se"], "r_se": r_se, "abs_diff_se": abs(py["se"] - r_se),
            "rel_diff_se": abs(py["se"] - r_se) / r_se if r_se else None,
            "python_full_design_df": py["design_df_full"], "r_full_design_df": est["design"]["full_design_df"],
            "singleton_strata": py["singleton_strata"],
            "agrees_within_1e-9": bool(abs(py["estimate"] - r_p) < 1e-9 and abs(py["se"] - r_se) < 1e-9)}


def flatten_outputs() -> dict:
    """Numeric content of every substantive output table, keyed by file/row/column."""
    flat = {}
    for f in sorted(paths.TABLES.glob("*.csv")):
        if f.name.startswith(("rerun_", "validation_")):
            continue
        df = pd.read_csv(f)
        for i, row in df.iterrows():
            for c, v in row.items():
                key = f"{f.name}|{i}|{c}"
                flat[key] = float(v) if isinstance(v, (int, float, np.integer, np.floating)) and not pd.isna(v) else (None if pd.isna(v) else str(v))
    return flat


def compare_snapshots(old: dict, new: dict, tol: float) -> pd.DataFrame:
    keys = sorted(set(old) | set(new))
    rows = []
    for k in keys:
        a, b = old.get(k, "<absent>"), new.get(k, "<absent>")
        if isinstance(a, float) and isinstance(b, float):
            ok = abs(a - b) <= tol  # absolute tolerance, as in the analysis plan
            diff = abs(a - b)
        else:
            ok = a == b
            diff = None
        if not ok:
            rows.append({"key": k, "first_run": a, "second_run": b, "abs_diff": diff})
    return pd.DataFrame(rows, columns=["key", "first_run", "second_run", "abs_diff"])


def rerun_check() -> dict:
    """Rebuild and reanalyze from cached raw files, then compare every numeric output."""
    cfg = paths.load_config()
    tol = cfg["rerun_tolerance_abs"]
    first = flatten_outputs()
    snap = paths.LOGS / "snapshot_before_rerun.json"
    snap.write_text(json.dumps(first), encoding="utf-8")
    from . import analyze, build
    build.run()
    analyze.run()
    second = flatten_outputs()
    diffs = compare_snapshots(first, second, tol)
    diffs.to_csv(paths.TABLES / "rerun_comparison.csv", index=False)
    res = {"values_compared": len(first), "values_differing": int(len(diffs)), "tolerance_abs": tol,
           "note": "Absolute tolerance on every numeric value, including weighted totals."}
    (paths.LOGS / "rerun_check.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(f"[rerun] {res}")
    return res


def spending_concentration() -> pd.DataFrame:
    """Post hoc descriptive diagnostic (amendment 4): how concentrated OOP spending is in domain C.

    Point estimates only (weighted shares), no inference. Used to interpret means with high RSE.
    """
    rows = []
    for year in ("2024", "2023"):
        df = pd.read_csv(paths.PROCESSED / f"analysis_{year}.csv", dtype={"person_id": str})
        d = df[(df["domain_c"] == 1)].copy()
        d = d.sort_values("rx_oop", ascending=False)
        w = d["weight"].to_numpy(float)
        tot = float((w * d["rx_oop"]).sum())
        cw = w.cumsum() / w.sum()
        for share in (0.01, 0.05):
            top = cw <= share
            rows.append({"year": year, "diagnostic": f"Share of weighted OOP dollars from the top {int(share * 100)}% of persons",
                         "value": float((w[top] * d["rx_oop"].to_numpy()[top]).sum() / tot), "n_unweighted_in_top": int(top.sum())})
        top1 = np.zeros(len(d), dtype=bool)
        top1[: int((cw <= 0.01).sum())] = True
        for cls in ("insured_year_end_continuous", "insured_year_end_gap", "uninsured_year_end"):
            g = d[d["continuity_class"] == cls]
            rows.append({"year": year, "diagnostic": f"Maximum annual OOP, {cls}", "value": float(g["rx_oop"].max()), "n_unweighted_in_top": 1})
            keep = (d["continuity_class"] == cls).to_numpy() & ~top1
            wk = d.loc[keep, "weight"].to_numpy(float)
            rows.append({"year": year, "diagnostic": f"Mean OOP excluding the domain top 1%, {cls}",
                         "value": float((wk * d.loc[keep, "rx_oop"].to_numpy()).sum() / wk.sum()),
                         "n_unweighted_in_top": int(((d["continuity_class"] == cls).to_numpy() & top1).sum())})
    out = pd.DataFrame(rows)
    out.to_csv(paths.TABLES / "diagnostic_oop_concentration.csv", index=False)
    return out


def run() -> dict:
    spending_concentration()
    tests = run_tests()
    roll = reconciliation_rollup()
    roll.to_csv(paths.TABLES / "validation_reconciliation_rollup.csv", index=False)
    cross = [cross_check_primary(y) for y in ("2024", "2023")]
    pd.DataFrame(cross).to_csv(paths.TABLES / "validation_primary_cross_check.csv", index=False)
    failures = roll[(roll["n_mismatch"] > 0) & ~roll["informational"]]
    hard = roll[~roll["informational"]]
    out = {"tests": tests, "reconciliation_checks": int(len(roll)),
           "source_reconciliation_checks": int((hard["kind"] == "source reconciliation").sum()),
           "software_cross_checks": int((hard["kind"] == "software cross-check").sum()) + len(cross),
           "informational_rows": int(roll["informational"].sum()),
           "reconciliation_failures": failures[["year", "check", "n_mismatch"]].to_dict("records"),
           "primary_cross_check": cross}
    (paths.LOGS / "validation_summary.json").write_text(json.dumps(out, indent=2, default=str), encoding="utf-8")
    print(f"[validate] tests: {tests['summary']}; reconciliation failures: {len(failures)}; "
          f"cross-check agrees: {[c['agrees_within_1e-9'] for c in cross]}")
    if tests["returncode"] != 0:
        raise RuntimeError("Unit tests failed")
    return out
