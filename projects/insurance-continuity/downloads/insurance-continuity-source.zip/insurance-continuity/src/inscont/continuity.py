"""Coverage-continuity audit function.

`classify_continuity` takes documented monthly any-coverage indicators (one column per
calendar month) and a year-end coverage indicator, and returns a continuity class for
every person plus an audit table showing how many records hit each rule.

Coding follows MEPS conventions by default (1 = covered, 2 = not covered, -1 = out of
scope, other negative reserved codes = missing), but every code set is a parameter so
the same function can be used with other monthly coverage sources.

Rules, applied in this order for each person:

1. Year-end value missing or unrecognized          -> "indeterminate" (reason: year_end_unavailable)
2. Year-end value = not covered                    -> "uninsured_year_end"
3. Year-end covered and any month = not covered    -> "insured_year_end_gap"
4. Year-end covered, no uncovered month, but some
   month out of scope, missing, or unrecognized    -> "indeterminate" (reason: months_unobserved)
5. Year-end covered and all months covered         -> "insured_year_end_continuous"

Out-of-scope and missing months are never counted as uninsured. A change of insurer or
source within covered months is not a gap because only the any-coverage indicator is
used. Gaps shorter than a calendar month cannot be seen in monthly data.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

CLASSES = [
    "insured_year_end_continuous",
    "insured_year_end_gap",
    "uninsured_year_end",
    "indeterminate",
]

CLASS_LABELS = {
    "insured_year_end_continuous": "Insured at year end, no uninsured month",
    "insured_year_end_gap": "Insured at year end, at least one uninsured month",
    "uninsured_year_end": "Uninsured at year end",
    "indeterminate": "Continuity indeterminate (coverage information unavailable)",
}


@dataclass
class ContinuityResult:
    persons: pd.DataFrame
    audit: pd.DataFrame
    month_codes: pd.DataFrame
    params: dict = field(default_factory=dict)


def _longest_run(mask: np.ndarray) -> np.ndarray:
    """Longest run of True along axis 1 for a 2-D boolean array."""
    best = np.zeros(mask.shape[0], dtype=int)
    cur = np.zeros(mask.shape[0], dtype=int)
    for j in range(mask.shape[1]):
        cur = np.where(mask[:, j], cur + 1, 0)
        best = np.maximum(best, cur)
    return best


def _n_spells(mask: np.ndarray) -> np.ndarray:
    """Number of separate runs of True along axis 1."""
    starts = mask.copy()
    starts[:, 1:] = mask[:, 1:] & ~mask[:, :-1]
    return starts.sum(axis=1)


def classify_continuity(
    monthly: pd.DataFrame,
    year_end: pd.Series | Sequence,
    *,
    month_columns: Sequence[str] | None = None,
    covered: Iterable = (1,),
    not_covered: Iterable = (2,),
    out_of_scope: Iterable = (-1,),
    missing: Iterable = (-2, -7, -8, -9, -10, -13, -14, -15),
    alt_min_consecutive: int = 3,
    id_column: str | None = None,
) -> ContinuityResult:
    """Classify within-year coverage continuity.

    Parameters
    ----------
    monthly:
        Wide frame, one row per person, one column per month in calendar order.
    year_end:
        Year-end coverage indicator aligned with `monthly` rows.
    month_columns:
        Month columns in calendar order. Defaults to every column except `id_column`.
    covered, not_covered, out_of_scope, missing:
        Code sets. Null values are always treated as missing. Values in none of the
        sets are counted as "unrecognized" and treated like missing.
    alt_min_consecutive:
        Minimum consecutive uncovered months for the alternative gap definition.
    """
    if month_columns is None:
        month_columns = [c for c in monthly.columns if c != id_column]
    month_columns = list(month_columns)
    if len(month_columns) == 0:
        raise ValueError("No month columns supplied")
    ye = pd.Series(year_end).reset_index(drop=True)
    if len(ye) != len(monthly):
        raise ValueError("year_end length does not match monthly rows")
    if id_column is not None and monthly[id_column].duplicated().any():
        raise ValueError("Duplicate person identifiers")

    cov, unc, oos, mis = (set(covered), set(not_covered), set(out_of_scope), set(missing))
    overlap = (cov & unc) | (cov & oos) | (cov & mis) | (unc & oos) | (unc & mis) | (oos & mis)
    if overlap:
        raise ValueError(f"Code sets overlap: {sorted(overlap)}")

    vals = monthly[month_columns].reset_index(drop=True)
    isnull = vals.isna().to_numpy()
    arr = vals.to_numpy(dtype=object)

    def member(codes: set) -> np.ndarray:
        if not codes:
            return np.zeros(arr.shape, dtype=bool)
        out = np.zeros(arr.shape, dtype=bool)
        for c in codes:
            out |= (arr == c) & ~isnull
        return out

    m_cov = member(cov)
    m_unc = member(unc)
    m_oos = member(oos)
    m_mis = member(mis) | isnull
    m_unrec = ~(m_cov | m_unc | m_oos | m_mis)

    ye_null = ye.isna().to_numpy()
    ye_arr = ye.to_numpy(dtype=object)
    ye_cov = np.isin(ye_arr, list(cov)) & ~ye_null
    ye_unc = np.isin(ye_arr, list(unc)) & ~ye_null
    ye_oos = np.isin(ye_arr, list(oos)) & ~ye_null
    ye_mis = (np.isin(ye_arr, list(mis)) & ~ye_null) | ye_null
    ye_unrec = ~(ye_cov | ye_unc | ye_oos | ye_mis)

    n_cov = m_cov.sum(axis=1)
    n_unc = m_unc.sum(axis=1)
    n_oos = m_oos.sum(axis=1)
    n_mis = m_mis.sum(axis=1)
    n_unrec = m_unrec.sum(axis=1)
    longest = _longest_run(m_unc)
    spells = _n_spells(m_unc)
    any_unc = n_unc > 0
    unobserved = (n_oos + n_mis + n_unrec) > 0

    ncol = len(month_columns)
    idx = np.arange(1, ncol + 1)
    first_unc = np.where(any_unc, np.argmax(m_unc, axis=1) + 1, 0)
    last_unc = np.where(any_unc, ncol - np.argmax(m_unc[:, ::-1], axis=1), 0)

    cls = np.empty(len(vals), dtype=object)
    reason = np.empty(len(vals), dtype=object)
    rule = np.zeros(len(vals), dtype=int)

    r1 = ~(ye_cov | ye_unc)
    r2 = ~r1 & ye_unc
    r3 = ~r1 & ye_cov & any_unc
    r4 = ~r1 & ye_cov & ~any_unc & unobserved
    r5 = ~r1 & ye_cov & ~any_unc & ~unobserved
    for r, k, c, why in ((r1, 1, "indeterminate", "year_end_unavailable"),
                         (r2, 2, "uninsured_year_end", ""),
                         (r3, 3, "insured_year_end_gap", ""),
                         (r4, 4, "indeterminate", "months_unobserved"),
                         (r5, 5, "insured_year_end_continuous", "")):
        cls[r] = c
        reason[r] = why
        rule[r] = k
    assert (rule > 0).all(), "every record must hit exactly one rule"

    # Alternative definition: a gap needs alt_min_consecutive consecutive uncovered months.
    alt_gap = longest >= alt_min_consecutive
    cls_alt = cls.copy()
    short_only = (cls == "insured_year_end_gap") & ~alt_gap
    # A person whose only gaps are short has no qualifying gap. If every other month is
    # observed, they are continuous under the alternative rule; otherwise indeterminate.
    cls_alt[short_only & ~unobserved] = "insured_year_end_continuous"
    cls_alt[short_only & unobserved] = "indeterminate"

    # Timing pattern among people with at least one uncovered month.
    pattern = np.full(len(vals), "none", dtype=object)
    last_month_cov = m_cov[:, -1]
    single = any_unc & (spells == 1)
    pattern[single & (first_unc == 1) & last_month_cov] = "uninsured_at_start_then_insured"
    pattern[single & (first_unc > 1) & last_month_cov] = "gap_after_insured_period"
    pattern[single & ~last_month_cov] = "uninsured_through_december"
    pattern[any_unc & (spells > 1)] = "multiple_gaps"

    # Consistency flags between the year-end indicator and the last month.
    flag_ye_cov_last_unc = ye_cov & m_unc[:, -1]
    flag_ye_unc_last_cov = ye_unc & m_cov[:, -1]

    persons = pd.DataFrame({
        "year_end_code": ye_arr,
        "n_months_covered": n_cov,
        "n_months_uncovered": n_unc,
        "n_months_out_of_scope": n_oos,
        "n_months_missing": n_mis,
        "n_months_unrecognized": n_unrec,
        "full_year_observed": ~unobserved,
        "longest_uncovered_run": longest,
        "n_gap_spells": spells,
        "first_uncovered_month": first_unc,
        "last_uncovered_month": last_unc,
        "gap_pattern": pattern,
        "continuity_class": cls,
        "continuity_class_alt": cls_alt,
        "indeterminate_reason": reason,
        "rule_hit": rule,
        "flag_year_end_covered_last_month_uncovered": flag_ye_cov_last_unc,
        "flag_year_end_uncovered_last_month_covered": flag_ye_unc_last_cov,
    })
    if id_column is not None:
        persons.insert(0, id_column, monthly[id_column].to_numpy())
    if len(persons) != len(monthly):
        raise AssertionError("person count changed during classification")

    rules = [
        (1, "Year-end value missing or unrecognized -> indeterminate", r1),
        (2, "Year-end not covered -> uninsured at year end", r2),
        (3, "Year-end covered, >=1 uncovered month -> insured at year end with gap", r3),
        (4, "Year-end covered, no uncovered month, >=1 month unobserved -> indeterminate", r4),
        (5, "Year-end covered, all months covered -> continuous", r5),
    ]
    audit_rows = [{"item": f"rule_{k}", "description": d, "n": int(m.sum())} for k, d, m in rules]
    audit_rows += [
        {"item": "persons_in", "description": "Rows supplied", "n": int(len(monthly))},
        {"item": "persons_out", "description": "Rows returned", "n": int(len(persons))},
        {"item": "year_end_covered", "description": "Year-end value in covered set", "n": int(ye_cov.sum())},
        {"item": "year_end_not_covered", "description": "Year-end value in not-covered set", "n": int(ye_unc.sum())},
        {"item": "year_end_out_of_scope", "description": "Year-end value in out-of-scope set", "n": int(ye_oos.sum())},
        {"item": "year_end_missing", "description": "Year-end value missing or null", "n": int(ye_mis.sum())},
        {"item": "year_end_unrecognized", "description": "Year-end value in no code set", "n": int(ye_unrec.sum())},
        {"item": "person_months_covered", "description": "Person-months covered", "n": int(m_cov.sum())},
        {"item": "person_months_uncovered", "description": "Person-months not covered", "n": int(m_unc.sum())},
        {"item": "person_months_out_of_scope", "description": "Person-months out of scope (never counted as uninsured)", "n": int(m_oos.sum())},
        {"item": "person_months_missing", "description": "Person-months missing (never counted as uninsured)", "n": int(m_mis.sum())},
        {"item": "person_months_unrecognized", "description": "Person-months with codes in no set", "n": int(m_unrec.sum())},
        {"item": "flag_year_end_covered_last_month_uncovered", "description": "Inconsistent: year-end covered but last month not covered", "n": int(flag_ye_cov_last_unc.sum())},
        {"item": "flag_year_end_uncovered_last_month_covered", "description": "Coverage ended during the last month (year-end not covered, last month covered)", "n": int(flag_ye_unc_last_cov.sum())},
        {"item": "alt_reclassified_continuous", "description": f"Gap class only via runs shorter than {alt_min_consecutive} months, all months observed", "n": int((short_only & ~unobserved).sum())},
        {"item": "alt_reclassified_indeterminate", "description": f"Gap class only via runs shorter than {alt_min_consecutive} months, some months unobserved", "n": int((short_only & unobserved).sum())},
    ]
    for c in CLASSES:
        audit_rows.append({"item": f"class:{c}", "description": CLASS_LABELS[c], "n": int((cls == c).sum())})
    audit = pd.DataFrame(audit_rows)

    codes = pd.DataFrame({
        "month": month_columns,
        "covered": m_cov.sum(axis=0),
        "not_covered": m_unc.sum(axis=0),
        "out_of_scope": m_oos.sum(axis=0),
        "missing": m_mis.sum(axis=0),
        "unrecognized": m_unrec.sum(axis=0),
    })
    params = {"covered": sorted(cov), "not_covered": sorted(unc), "out_of_scope": sorted(oos),
              "missing": sorted(mis), "alt_min_consecutive": alt_min_consecutive, "months": month_columns}
    return ContinuityResult(persons=persons, audit=audit, month_codes=codes, params=params)
