"""Parse AHRQ MEPS codebook PDFs into per-variable records.

Each record holds the description, format, type, column positions, and the value rows
with unweighted and weighted frequencies exactly as AHRQ printed them. These records
feed the data dictionary, the variable-existence checks, and the reconciliation of
weighted frequencies against the published codebook.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from pypdf import PdfReader

from . import paths

_ROW = re.compile(r"^(?P<value>-?\$?[\d,.]+(?:\s*-\s*-?\$?[\d,.]+)?|[A-Z][A-Z0-9 /'&<>().,+-]*?)\s+(?P<label>.*?)\s*(?P<unw>\d{1,3}(?:,\d{3})*)\s+(?P<w>\d{1,3}(?:,\d{3})*)\s*$")


def pdf_text(pdf: Path) -> str:
    """Layout-mode text with whitespace collapsed.

    Some AHRQ codebook PDFs (for example HC-251) draw each page bottom to top, which
    reverses the line order in layout mode, and split words across lines in plain mode.
    Pages whose "Name:" line comes after their "Description:" line are flipped back.
    """
    reader = PdfReader(str(pdf))
    pages = []
    for i, page in enumerate(reader.pages):
        lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in (page.extract_text(extraction_mode="layout") or "").split("\n")]
        lines = [ln for ln in lines if ln]
        name_idx = next((k for k, ln in enumerate(lines) if ln.startswith("Name:")), None)
        desc_idx = next((k for k, ln in enumerate(lines) if ln.startswith("Description:")), None)
        if name_idx is not None and desc_idx is not None and desc_idx < name_idx:
            lines.reverse()
        elif lines and lines[0].startswith("Page ") and " of " in lines[0]:
            lines.reverse()
        pages.append(f"\n=====PAGE {i + 1}=====\n" + "\n".join(lines))
    return "\n".join(pages)


def parse_entries(text: str) -> dict[str, dict]:
    text = re.sub(r"\n=====PAGE \d+=====\n", "\n", text)
    text = re.sub(r"^\s*(MEPS HC[- ]\w+ Codebook|Page \d+ of \d+)\s*$", "", text, flags=re.M)
    parts = re.split(r"\nName:\s*", text)
    out: dict[str, dict] = {}
    for part in parts[1:]:
        lines = part.split("\n")
        name = lines[0].strip()
        body = "\n".join(lines[1:])
        stop = body.find("\nTotal:")
        if stop >= 0:
            nl = body.find("\n", stop + 1)
            total_line = body[stop + 1: nl if nl > 0 else None].strip()
            body_core = body[:stop]
        else:
            total_line, body_core = "", body
        rec: dict = {"name": name, "rows": [], "total_line": total_line}
        for key in ("Description", "Format", "Type", "Start", "End"):
            m = re.search(rf"^{key}:\s*(.*)$", body_core, flags=re.M)
            rec[key.lower()] = m.group(1).strip() if m else None
        vt = body_core.find("Value Unweighted")
        if vt >= 0:
            for ln in body_core[vt:].split("\n")[1:]:
                ln = ln.strip()
                if not ln or ln.startswith(("MEPS HC", "Page ")):
                    continue
                m = re.match(r"^(?P<value>-?\d+(?:\.\d+)?)\s+(?P<label>.*?)\s+(?P<unw>\d{1,3}(?:,\d{3})*)\s+(?P<w>\d{1,3}(?:,\d{3})*)$", ln)
                if m:
                    rec["rows"].append({"value": m.group("value"), "label": m.group("label").strip(),
                                        "unweighted": int(m.group("unw").replace(",", "")),
                                        "weighted": int(m.group("w").replace(",", ""))})
                    continue
                m = re.match(r"^(?P<value>.+?)\s+(?P<unw>\d{1,3}(?:,\d{3})*)\s+(?P<w>\d{1,3}(?:,\d{3})*)$", ln)
                if m:
                    rec["rows"].append({"value": m.group("value").strip(), "label": "",
                                        "unweighted": int(m.group("unw").replace(",", "")),
                                        "weighted": int(m.group("w").replace(",", ""))})
                    continue
                m = re.match(r"^(?P<value>.+?)\s+(?P<unw>\d{1,3}(?:,\d{3})*)$", ln)
                if m:
                    rec["rows"].append({"value": m.group("value").strip(), "label": "",
                                        "unweighted": int(m.group("unw").replace(",", "")), "weighted": None})
        tm = re.match(r"Total:\s*([\d,]+)(?:\s+([\d,]+))?", total_line)
        if tm:
            rec["total_unweighted"] = int(tm.group(1).replace(",", ""))
            rec["total_weighted"] = int(tm.group(2).replace(",", "")) if tm.group(2) else None
        out[name] = rec
    return out


def build_codebooks() -> dict[str, dict]:
    cfg = paths.load_config()
    result = {}
    for key, rel_cfg in cfg["releases"].items():
        pid = rel_cfg["puf_id"]
        out = paths.INTERIM / f"{pid}_codebook.json"
        pdf = paths.RAW / pid / f"{pid}cb.pdf"
        if not out.exists() or out.stat().st_mtime < pdf.stat().st_mtime:
            entries = parse_entries(pdf_text(pdf))
            out.write_text(json.dumps(entries, indent=1), encoding="utf-8")
        result[key] = json.loads(out.read_text(encoding="utf-8"))
    return result


def required_variables(cfg: dict, yy: str) -> list[str]:
    names = []
    for tmpl in cfg["monthly_templates"].values():
        names += [tmpl.format(mm=m, yy=yy) for m in cfg["months"]]
    names += [t.format(yy=yy) for t in cfg["person_templates"].values()]
    names.append(f"INSDE{yy}X")
    return names


def check_variables(entries: dict, names: list[str]) -> list[dict]:
    return [{"variable": n, "in_codebook": n in entries,
             "description": entries.get(n, {}).get("description")} for n in names]
