"""Runtime manifest: machine, runtimes, package versions, and report renderer."""

from __future__ import annotations

import datetime as dt
import json
import os
import platform
import shutil
import subprocess
import sys
from importlib import metadata

from . import paths


def _cmd(args: list[str]) -> str:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=60).stdout.strip() or ""
    except Exception as exc:  # recorded, not raised
        return f"unavailable ({exc.__class__.__name__})"


def write() -> dict:
    pk = {}
    for name in ["pandas", "numpy", "duckdb", "pyarrow", "openpyxl", "matplotlib", "pytest", "requests", "pypdf", "Jinja2", "Markdown", "python-docx"]:
        try:
            pk[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            pk[name] = "not installed"
    du = shutil.disk_usage(paths.ROOT)
    try:
        mem = int(_cmd(["sysctl", "-n", "hw.memsize"]) or 0)
    except ValueError:
        mem = 0
    r_pk = {}
    lock = paths.ROOT / "R" / "packages.lock.csv"
    if lock.exists():
        import csv
        with open(lock, encoding="utf-8") as fh:
            for row in csv.DictReader(fh):
                r_pk[row["Package"]] = row["Version"]
    man = {
        "generated_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
        "os": f"{platform.system()} {platform.release()} ({platform.platform()})",
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
        "memory_bytes": mem,
        "disk_free_bytes_at_run": du.free,
        "python": sys.version.split()[0],
        "python_packages": pk,
        "r": _cmd(["Rscript", "--version"]) or _cmd(["R", "--version"]).splitlines()[0] if shutil.which("Rscript") else "not available",
        "r_packages_project_library": r_pk,
        "sql_engine": f"DuckDB {pk.get('duckdb')} (in-process)",
        "report_renderer": f"python-markdown {pk.get('Markdown')} with a project HTML template; Word files via python-docx {pk.get('python-docx')}. Quarto and pandoc were not installed; the pandoc wheel available for this machine was built for x86_64 and could not run.",
        "postgresql": "not used (DuckDB is the specified SQL engine for this project)",
        "docker": "not used",
        "network": "used for AHRQ downloads, Crossref metadata, and package installation",
    }
    (paths.LOGS / "runtime_manifest.json").write_text(json.dumps(man, indent=2), encoding="utf-8")
    return man
