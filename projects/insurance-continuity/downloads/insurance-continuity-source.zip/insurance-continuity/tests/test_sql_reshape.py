"""Tests for the DuckDB person-month reshape and reconciliation SQL on synthetic records."""

import duckdb
import pandas as pd

from inscont import build, paths

CFG = paths.load_config()
YY = "24"


def synthetic_fyc():
    """Four invented persons:
    A: private all year, insured 12/31.
    B: uninsured Jan-Mar, then Medicaid (public) Apr-Dec, insured 12/31.
    C: private Jan-Jun, Medicare + private (both) Jul-Dec; switches source with no gap.
    D: out of scope Jan-Feb (-1), uninsured otherwise, uninsured 12/31.
    """
    months = CFG["months"]
    recs = []
    plans = {
        "A": [("P",)] * 12,
        "B": [("N",)] * 3 + [("MCD",)] * 9,
        "C": [("P",)] * 6 + [("P", "MCR")] * 6,
        "D": [("O",)] * 2 + [("N",)] * 10,
    }
    for pid, plan in plans.items():
        r = {"DUPERSID": pid}
        for m, st in zip(months, plan):
            oos = "O" in st
            def code(flag):
                return -1 if oos else (1 if flag else 2)
            priv = "P" in st
            mcr, mcd = "MCR" in st, "MCD" in st
            pub = mcr or mcd
            r[f"INS{m}{YY}X"] = code(priv or pub)
            r[f"PRI{m}{YY}"] = code(priv)
            r[f"PUB{m}{YY}X"] = code(pub)
            r[f"MCR{m}{YY}X"] = code(mcr)
            r[f"MCD{m}{YY}X"] = code(mcd)
            r[f"TRI{m}{YY}X"] = code(False)
            r[f"VAP{m}{YY}"] = code(False)
            r[f"GVA{m}{YY}"] = code(False)
            r[f"IHS{m}{YY}"] = code(False)
        recs.append(r)
    df = pd.DataFrame(recs)
    person = {
        "PANEL": 29, "KEYNESS": 1, "INSCOPE": 1, "INSC1231": 1, "INSCOP31": 1, "INSCOP42": 1, "INSCOP53": 1,
        f"INSCOP{YY}": 1, f"ELGRND{YY}": 1, f"ENDRFM{YY}": 12, f"ENDRFY{YY}": 2024, f"AGE{YY}X": 50, "SEX": 1,
        "RACETHX": 2, f"POVCAT{YY}": 4, f"REGION{YY}": 3, "DIABDX_M18": 1, f"INSAT{YY}X": 1,
        f"RXTOT{YY}": 0, f"RXSLF{YY}": 0, f"RXEXP{YY}": 0, f"PERWT{YY}F": 1000.0, "VARSTR": 2001, "VARPSU": 1,
    }
    for k, v in person.items():
        df[k] = v
    df[f"INS{YY}X"] = [1, 1, 1, 2]
    df[f"UNINS{YY}"] = [2, 2, 2, 1]
    df[f"INSCOV{YY}"] = [1, 2, 1, 3]
    df[f"INSURC{YY}"] = [1, 2, 1, 3]
    return df


def run_sql(df):
    _, monthly = build.variables_for_year(CFG, YY)
    con = duckdb.connect()
    con.register("fyc_df", df)
    con.execute("CREATE TABLE fyc AS SELECT * FROM fyc_df")
    groups, allm = build.unpivot_parts(monthly)
    con.execute(build.render_sql("01_person.sql", yy=YY, puf="TEST"))
    con.execute(build.render_sql("02_person_month.sql", unpivot_groups=groups, all_monthly_columns=allm))
    con.execute(build.render_sql("03_reconcile.sql"))
    con.execute(build.render_sql("04_classify.sql"))
    return con


def test_reshape_has_12_rows_per_person_and_same_person_count():
    con = run_sql(synthetic_fyc())
    n, persons = con.execute("SELECT COUNT(*), COUNT(DISTINCT person_id) FROM person_month").fetchone()
    assert (n, persons) == (48, 4)
    assert con.execute("SELECT COUNT(*) FROM person").fetchone()[0] == 4


def test_month_order_and_states():
    con = run_sql(synthetic_fyc())
    b = con.execute("SELECT month, coverage_state FROM person_month WHERE person_id = 'B' ORDER BY month").fetchall()
    assert [m for m, _ in b] == list(range(1, 13))
    assert [s for _, s in b] == ["uninsured"] * 3 + ["public_only"] * 9
    c = con.execute("SELECT coverage_state, n_sources FROM person_month WHERE person_id = 'C' AND month = 12").fetchone()
    assert c == ("private_and_public", 2)
    d = con.execute("SELECT coverage_state FROM person_month WHERE person_id = 'D' AND month = 1").fetchone()[0]
    assert d == "not_in_scope"


def test_multi_source_month_counts_once_as_insured():
    con = run_sql(synthetic_fyc())
    m = con.execute("SELECT m_cov, m_unc FROM pm_summary WHERE person_id = 'C'").fetchone()
    assert m == (12, 0)


def test_sql_classes():
    con = run_sql(synthetic_fyc())
    got = dict(con.execute("SELECT person_id, continuity_class_sql FROM sql_class").fetchall())
    assert got == {"A": "insured_year_end_continuous", "B": "insured_year_end_gap",
                   "C": "insured_year_end_continuous", "D": "uninsured_year_end"}


def test_reconciliation_passes_on_consistent_records():
    con = run_sql(synthetic_fyc())
    rec = con.execute("SELECT check_name, n_mismatch FROM reconciliation WHERE check_name NOT LIKE 'info_%'").fetchall()
    bad = [r for r in rec if r[1] != 0]
    assert bad == []


def test_reconciliation_detects_a_planted_inconsistency():
    df = synthetic_fyc()
    df.loc[df["DUPERSID"] == "D", f"UNINS{YY}"] = 2  # D is uninsured in every in-scope month
    con = run_sql(df)
    n = con.execute("SELECT n_mismatch FROM reconciliation WHERE check_name = 'unins_year_matches_all_inscope_months_uninsured'").fetchone()[0]
    assert n == 1
