# Synthetic test fixtures

Everything in this folder is invented for software testing. None of it comes from MEPS
and none of it is used in any study result. Each fixture is a handful of hand-written
records that exercise one rule (for example, a person insured in December but
uninsured earlier in the year).
