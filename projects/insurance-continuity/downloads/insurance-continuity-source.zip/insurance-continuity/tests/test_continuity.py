"""Unit tests for the continuity audit function (synthetic fixtures only)."""

import numpy as np
import pandas as pd
import pytest

from inscont.continuity import classify_continuity

MONTHS = [f"m{i:02d}" for i in range(1, 13)]


def frame(rows):
    return pd.DataFrame(rows, columns=MONTHS)


def classify(rows, year_end, **kw):
    return classify_continuity(frame(rows), pd.Series(year_end), month_columns=MONTHS, **kw).persons


def test_continuous_all_year():
    p = classify([[1] * 12], [1])
    assert p.loc[0, "continuity_class"] == "insured_year_end_continuous"
    assert p.loc[0, "n_months_uncovered"] == 0


def test_insured_in_december_but_uninsured_earlier_is_a_gap():
    # Uninsured January to March, insured April to December, insured on 12/31.
    p = classify([[2, 2, 2] + [1] * 9], [1])
    assert p.loc[0, "continuity_class"] == "insured_year_end_gap"
    assert p.loc[0, "continuity_class"] != "insured_year_end_continuous"
    assert p.loc[0, "n_months_uncovered"] == 3
    assert p.loc[0, "gap_pattern"] == "uninsured_at_start_then_insured"


def test_single_mid_year_gap_month():
    p = classify([[1] * 6 + [2] + [1] * 5], [1])
    assert p.loc[0, "continuity_class"] == "insured_year_end_gap"
    assert p.loc[0, "gap_pattern"] == "gap_after_insured_period"
    assert p.loc[0, "first_uncovered_month"] == 7 and p.loc[0, "last_uncovered_month"] == 7


def test_multiple_gaps():
    p = classify([[2, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1]], [1])
    assert p.loc[0, "n_gap_spells"] == 2
    assert p.loc[0, "gap_pattern"] == "multiple_gaps"
    assert p.loc[0, "longest_uncovered_run"] == 2


def test_uninsured_at_year_end():
    p = classify([[1] * 11 + [2]], [2])
    assert p.loc[0, "continuity_class"] == "uninsured_year_end"


def test_missing_months_are_not_uninsured():
    # Two missing months (-8, null) and otherwise covered: continuity cannot be confirmed.
    p = classify([[1, -8, np.nan] + [1] * 9], [1])
    assert p.loc[0, "continuity_class"] == "indeterminate"
    assert p.loc[0, "indeterminate_reason"] == "months_unobserved"
    assert p.loc[0, "n_months_uncovered"] == 0
    assert p.loc[0, "n_months_missing"] == 2


def test_out_of_scope_months_are_not_uninsured():
    # Out of scope (institutionalized, abroad) January and February, then covered.
    p = classify([[-1, -1] + [1] * 10], [1])
    assert p.loc[0, "n_months_uncovered"] == 0
    assert p.loc[0, "n_months_out_of_scope"] == 2
    assert p.loc[0, "continuity_class"] == "indeterminate"


def test_observed_gap_with_some_missing_months_is_still_a_gap():
    p = classify([[-8, 2] + [1] * 10], [1])
    assert p.loc[0, "continuity_class"] == "insured_year_end_gap"


def test_year_end_missing_is_indeterminate():
    p = classify([[1] * 12], [-8])
    assert p.loc[0, "continuity_class"] == "indeterminate"
    assert p.loc[0, "indeterminate_reason"] == "year_end_unavailable"


def test_unrecognized_codes_counted_and_not_uninsured():
    p = classify([[1] * 11 + [7]], [1])
    assert p.loc[0, "n_months_unrecognized"] == 1
    assert p.loc[0, "continuity_class"] == "indeterminate"


def test_alternative_definition_three_consecutive_months():
    rows = [[2, 2] + [1] * 10, [2, 2, 2] + [1] * 9, [2, 1, 2, 1, 2] + [1] * 7]
    p = classify(rows, [1, 1, 1])
    assert list(p["continuity_class"]) == ["insured_year_end_gap"] * 3
    assert list(p["continuity_class_alt"]) == ["insured_year_end_continuous", "insured_year_end_gap", "insured_year_end_continuous"]


def test_alternative_definition_short_gap_with_unobserved_months_is_indeterminate():
    p = classify([[2, 2, -1] + [1] * 9], [1])
    assert p.loc[0, "continuity_class_alt"] == "indeterminate"


def test_inconsistency_flags():
    p = classify([[1] * 11 + [2], [1] * 12], [1, 2])
    assert bool(p.loc[0, "flag_year_end_covered_last_month_uncovered"])
    assert bool(p.loc[1, "flag_year_end_uncovered_last_month_covered"])


def test_person_count_and_ids_preserved():
    df = frame([[1] * 12, [2] * 12, [1] * 12])
    df.insert(0, "pid", ["a", "b", "c"])
    res = classify_continuity(df, pd.Series([1, 2, 1]), month_columns=MONTHS, id_column="pid")
    assert list(res.persons["pid"]) == ["a", "b", "c"]
    audit = res.audit.set_index("item")["n"]
    assert audit["persons_in"] == audit["persons_out"] == 3
    assert sum(audit[f"rule_{k}"] for k in range(1, 6)) == 3


def test_duplicate_ids_rejected():
    df = frame([[1] * 12, [1] * 12])
    df.insert(0, "pid", ["a", "a"])
    with pytest.raises(ValueError):
        classify_continuity(df, pd.Series([1, 1]), month_columns=MONTHS, id_column="pid")


def test_overlapping_code_sets_rejected():
    with pytest.raises(ValueError):
        classify([[1] * 12], [1], covered=(1,), not_covered=(1, 2))


def test_custom_codes():
    # A source coded 1 = covered, 0 = not covered, 9 = not observed.
    p = classify([[1] * 5 + [0] + [1] * 6, [1] * 11 + [9]], [1, 1], covered=(1,), not_covered=(0,), out_of_scope=(), missing=(9,))
    assert list(p["continuity_class"]) == ["insured_year_end_gap", "indeterminate"]
