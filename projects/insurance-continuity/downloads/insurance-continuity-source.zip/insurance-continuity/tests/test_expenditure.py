"""Annual prescription expenditure states (synthetic values only)."""

import numpy as np
import pandas as pd


def rx_state(fills, oop):
    fills = pd.Series(fills)
    oop = pd.Series(oop, dtype=float)
    neg = (oop < 0) | oop.isna()
    return np.select([neg, fills == 0, (fills > 0) & (oop == 0), fills > 0],
                     ["missing_expenditure", "no_recorded_fill", "fills_zero_oop", "fills_positive_oop"], default="unclassified")


def test_states_are_distinct():
    got = list(rx_state([0, 3, 3, 2, 1], [0, 0, 25.0, -9, np.nan]))
    assert got == ["no_recorded_fill", "fills_zero_oop", "fills_positive_oop", "missing_expenditure", "missing_expenditure"]


def test_build_uses_the_same_rule():
    # The build module must apply the same expression; guard against drift.
    import inspect
    from inscont import build
    src = inspect.getsource(build.build_year)
    assert '"missing_expenditure", "no_recorded_fill", "fills_zero_oop", "fills_positive_oop"' in src
