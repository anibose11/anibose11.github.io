# Notices

The MIT License in `LICENSE` covers only the code and documentation written for this project.

## MEPS data

The Medical Expenditure Panel Survey public-use files (HC-256, HC-254A, HC-251) are produced by the Agency for Healthcare Research and Quality (AHRQ). They are not redistributed here; `./icont acquire` downloads them from AHRQ. Their documentation states data use requirements, including that the data are used only for statistical reporting and analysis, that no one attempts to identify any individual, and that users cite AHRQ and MEPS as the data source. Anyone running this code agrees to those requirements. I calculated the estimates reported in this project. AHRQ has not endorsed them.

## Third-party software

Python and R packages are used under their own licenses (see `requirements.lock` and `R/packages.lock.csv`), including pandas (BSD-3-Clause), DuckDB (MIT), matplotlib (matplotlib license), openpyxl (MIT), python-docx (MIT), pypdf (BSD-3-Clause), Jinja2 (BSD-3-Clause), Markdown (BSD-3-Clause), survey (GPL-2 | GPL-3), and data.table (MPL-2.0).
