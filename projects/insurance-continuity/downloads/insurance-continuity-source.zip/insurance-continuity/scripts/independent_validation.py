"""Independent re-check of the headline results, written separately from the pipeline (abstract, text, tables, and legends are scanned for numbers).

It reads the AHRQ Stata files directly (no code from src/inscont), recomputes the cohort,
the continuity classes, and the primary proportion with its Taylor-linearized standard
error, re-derives 25 sampled classifications from raw monthly codes, compares every
number in the manuscript with the output tables, and re-resolves each cited DOI.
Writes outputs/logs/independent_validation.json.
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MONTHS = ["JA", "FE", "MA", "AP", "MY", "JU", "JL", "AU", "SE", "OC", "NO", "DE"]


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def classify_row(year_end: int, months: list[int]) -> str:
    """Plain restatement of the class rules, written without reference to the pipeline code."""
    if year_end not in (1, 2):
        return "D"
    if year_end == 2:
        return "C"
    if 2 in months:
        return "B"
    if any(m != 1 for m in months):
        return "D"
    return "A"


def taylor_se(y: np.ndarray, w: np.ndarray, d: np.ndarray, strat: np.ndarray, psu: np.ndarray) -> tuple[float, float]:
    """Ratio-estimator linearization for a domain proportion; with-replacement PSUs within strata."""
    wd = w * d
    p = float(np.sum(wd * y) / np.sum(wd))
    u = wd * (y - p) / np.sum(wd)
    df = pd.DataFrame({"h": strat, "c": psu, "u": u}).groupby(["h", "c"])["u"].sum().reset_index()
    v = 0.0
    for _, g in df.groupby("h"):
        k = len(g)
        if k > 1:
            v += k / (k - 1) * float(np.sum((g["u"] - g["u"].mean()) ** 2))
    return p, float(np.sqrt(v))


def check_year(yy: str, puf: str, expected: dict) -> dict:
    cols = (["DUPERSID", "PERWT%sF" % yy, "VARSTR", "VARPSU", "AGE%sX" % yy, "DIABDX_M18", "INSC1231", "INS%sX" % yy, "ENDRFM%s" % yy]
            + [f"INS{m}{yy}X" for m in MONTHS])
    raw = pd.read_stata(ROOT / f"data/raw/{puf}/{puf}.dta", columns=cols, convert_categoricals=False)
    mcols = [f"INS{m}{yy}X" for m in MONTHS]
    w = raw[f"PERWT{yy}F"].to_numpy(float)
    adult = raw[f"AGE{yy}X"].between(18, 64)
    diab = raw["DIABDX_M18"] == 1
    pos = raw[f"PERWT{yy}F"] > 0
    in1231 = (raw["INSC1231"] == 1) & raw[f"INS{yy}X"].isin([1, 2])
    allyear = (raw[mcols] != -1).all(axis=1) & (raw[f"ENDRFM{yy}"] == 12)
    n_diab = int((pos & adult & diab).sum())
    frame = pos & adult & diab & in1231
    dom = frame & allyear
    cls = np.array([classify_row(int(ye), [int(x) for x in ms]) for ye, ms in zip(raw[f"INS{yy}X"], raw[mcols].to_numpy())])
    counts = {k: int(((cls == k) & dom).sum()) for k in "ABCD"}
    den = dom & (raw[f"INS{yy}X"] == 1)
    y = (cls == "B").astype(float)
    p, se = taylor_se(y, w, den.to_numpy().astype(float), raw["VARSTR"].to_numpy(), raw["VARPSU"].to_numpy())
    out = {"records": len(raw), "adults_diabetes_pos_weight": n_diab, "in_scope_1231": int(frame.sum()), "domain_all_year": int(dom.sum()),
           "class_counts": counts, "denominator": int(den.sum()), "numerator": int((den & (cls == "B")).sum()),
           "proportion": p, "se": se}
    est = json.loads((ROOT / f"outputs/estimates_20{yy}.json").read_text())
    out["matches_pipeline"] = bool(abs(p - est["primary"]["estimate"]) < 1e-9 and abs(se - est["primary"]["se"]) < 1e-9
                                   and out["denominator"] == est["primary"]["n_unweighted"] and out["numerator"] == est["primary"]["numerator_unweighted"])
    if expected:
        out["matches_expected_counts"] = all(out[k] == v for k, v in expected.items())
    # 25 sampled records re-derived from raw monthly codes
    if yy == "24":
        sample = raw[dom].sample(n=25, random_state=2024)
        a = pd.read_csv(ROOT / "data/processed/analysis_2024.csv", usecols=["person_id", "continuity_class"], dtype={"person_id": str}).set_index("person_id")
        names = {"insured_year_end_continuous": "A", "insured_year_end_gap": "B", "uninsured_year_end": "C", "indeterminate": "D"}
        agree = 0
        for _, r in sample.iterrows():
            mine = classify_row(int(r[f"INS{yy}X"]), [int(r[c]) for c in mcols])
            agree += int(names[a.loc[r["DUPERSID"], "continuity_class"]] == mine)
        out["sampled_records_agree"] = f"{agree} of 25"
    return out


def manuscript_numbers() -> dict:
    """Every percentage and dollar figure in the rendered manuscript must appear in the claims or tables."""
    claims = json.loads((ROOT / "evidence/claims.json").read_text())["claims"]
    known = {c["formatted"] for c in claims}
    for c in claims:
        for tok in re.findall(r"\$\d{1,3}(?:,\d{3})*|\d+(?:\.\d+)?%", str(c["formatted"])):
            known.add(tok)
    for f in (ROOT / "outputs/tables").glob("*.csv"):
        df = pd.read_csv(f)
        for c in df.columns:
            if df[c].dtype.kind in "fi":
                for v in df[c].dropna():
                    known.update({f"{100 * abs(v):.1f}%", f"${abs(v):,.0f}", f"{100 * v:.0f}%"})
    literature = {"25.2%", "14.5%", "27.1%", "15.6%", "18.2%", "7.8%", "14.3%", "25.3%", "40%", "9.0%", "1%", "30%", "200%", "95%", "3%"}
    text = (ROOT / "manuscript/manuscript.md").read_text()
    parts = text.split("## References")
    body = parts[0] + (parts[1].split("## Tables", 1)[1] if len(parts) > 1 and "## Tables" in parts[1] else "")  # text plus tables and legends
    toks = re.findall(r"\$\d{1,3}(?:,\d{3})*|\d+(?:\.\d+)?%", body)
    unmatched = sorted({t for t in toks if t not in known and t not in literature})
    return {"tokens_checked": len(toks), "unmatched": unmatched}


def references_resolve() -> dict:
    refs = json.loads((ROOT / "docs/references_crossref.json").read_text())
    refs["macarthur2026"] = {"doi": "10.1177/10775587261484437", "title": "Insurance Coverage Disruptions and Associated Access and Utilization, 2008 to 2022"}
    ok, bad = 0, []
    for key, rec in refs.items():
        try:
            import requests  # certifi-backed TLS; the system urllib may lack CA certificates
            m = requests.get(f"https://api.crossref.org/works/{rec['doi']}", timeout=30,
                             headers={"User-Agent": "independent-check/1.0"}).json()["message"]
            t1 = re.sub(r"\W+", "", (m.get("title") or [""])[0].lower())
            t2 = re.sub(r"\W+", "", rec["title"].lower())
            ok += int(t1 == t2)
            if t1 != t2:
                bad.append(key)
        except Exception as exc:  # recorded, not raised
            bad.append(f"{key}: {exc.__class__.__name__}")
        time.sleep(0.2)
    return {"dois_checked": len(refs), "titles_match": ok, "problems": bad}


def main() -> None:
    man = json.loads((ROOT / "source_manifest.json").read_text())
    checks = []
    for rel in man["releases"].values():
        for rec in rel["files"].values():
            checks.append(sha256(ROOT / rec["path"]) == rec["sha256"])
    exp = json.loads((ROOT / "config/expected_checksums.json").read_text())["files"]
    checks_expected = [sha256(ROOT / p) == r["sha256"] for p, r in exp.items()]
    res = {
        "checksums_match_manifest": f"{sum(checks)} of {len(checks)}",
        "checksums_match_analyzed_release": f"{sum(checks_expected)} of {len(checks_expected)}",
        "2024": check_year("24", "h256", {"adults_diabetes_pos_weight": 1008, "in_scope_1231": 1002, "domain_all_year": 1001}),
        "2023": check_year("23", "h251", {}),
        "manuscript_numbers": manuscript_numbers(),
        "references": references_resolve(),
    }
    (ROOT / "outputs/logs/independent_validation.json").write_text(json.dumps(res, indent=2), encoding="utf-8")
    print(json.dumps(res, indent=1))
    ok = (res["2024"]["matches_pipeline"] and res["2023"]["matches_pipeline"] and res["2024"].get("matches_expected_counts")
          and not res["manuscript_numbers"]["unmatched"] and not res["references"]["problems"])
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
