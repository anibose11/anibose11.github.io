"""Serve the extracted outer bundle over local HTTP and check the project pages.

Checks status codes, every local link and image, in-page anchors, alt text, external
dependencies, and that the downloadable archives open. Writes outputs/logs/site_check.json.
Visual inspection at desktop and phone widths is done separately in a browser and recorded
in the same file under "visual_inspection" when supplied with --visual "<note>".
"""

from __future__ import annotations

import argparse
import datetime as dt
import io
import json
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "deliverables/01-insurance-continuity-PROJECT-BUNDLE.zip"
PORT = 8749


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.ids, self.imgs, self.alts, self.ext = [], set(), [], [], []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.add(a["id"])
        for key in ("href", "src"):
            v = a.get(key)
            if v and v.startswith(("http://", "https://", "//")):
                self.ext.append(v)
        if tag in ("a", "link") and a.get("href"):
            self.links.append(a["href"])
        if tag in ("img", "script") and a.get("src"):
            self.imgs.append(a["src"])
            if tag == "img":
                self.alts.append(bool(a.get("alt")))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--visual", default=None, help="note describing the browser inspection")
    args = ap.parse_args()
    tmp = Path(tempfile.mkdtemp(prefix="inscont_site_"))
    with zipfile.ZipFile(BUNDLE) as zf:
        names = zf.namelist()
        zf.extractall(tmp)
    top = sorted({n.split("/")[0] for n in names})
    srv = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1", "--directory", str(tmp / "site")],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.0)
    base = f"http://127.0.0.1:{PORT}/projects/insurance-continuity/"
    out = {"checked_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(), "bundle_top_level": top, "pages": {}, "broken": []}
    try:
        for page in ("", "index.html", "report.html"):
            url = base + page
            body = urllib.request.urlopen(url).read().decode("utf-8")
            p = Links()
            p.feed(body)
            n = 0
            for l in p.links + p.imgs:
                if l.startswith(("http://", "https://", "mailto:")):
                    continue
                n += 1
                if l.startswith("#"):
                    if l[1:] not in p.ids:
                        out["broken"].append([page, l, "missing anchor"])
                    continue
                try:
                    r = urllib.request.urlopen(urllib.parse.urljoin(url, l))
                    data = r.read()
                    if r.status != 200 or not data:
                        out["broken"].append([page, l, r.status])
                except Exception as exc:
                    out["broken"].append([page, l, str(exc)])
            out["pages"][page or "/projects/insurance-continuity/"] = {"links_and_assets_checked": n, "images": len(p.alts),
                                                                       "images_with_alt": sum(p.alts), "external_references": p.ext}
        z = urllib.request.urlopen(base + "downloads/insurance-continuity-source.zip").read()
        out["source_zip_opens"] = zipfile.ZipFile(io.BytesIO(z)).testzip() is None
    finally:
        srv.terminate()
    prev = ROOT / "outputs/logs/site_check.json"
    out["visual_inspection"] = args.visual or "not recorded for this build"
    out["bundle_sha256"] = __import__("hashlib").sha256(BUNDLE.read_bytes()).hexdigest()
    ok = (not out["broken"] and out["source_zip_opens"] and set(top) <= {"handoff", "site", "submission"} and {"handoff", "site"} <= set(top)
          and all(not v["external_references"] for v in out["pages"].values()))
    out["summary"] = (f"bundle top level {top}; pages served over local HTTP; {sum(v['links_and_assets_checked'] for v in out['pages'].values())} links, "
                      f"images, and anchors checked; {len(out['broken'])} broken; no external dependencies: "
                      f"{all(not v['external_references'] for v in out['pages'].values())}; visual: {out['visual_inspection']}")
    prev.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(out["summary"])
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
