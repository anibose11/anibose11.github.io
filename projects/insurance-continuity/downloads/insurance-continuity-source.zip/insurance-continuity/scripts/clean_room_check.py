"""Clean-room check of the final source archive.

Extracts site/projects/insurance-continuity/downloads/insurance-continuity-source.zip into an
empty temporary directory, runs the documented setup, unit tests, and demo, then runs the full
pipeline (fresh AHRQ download, build, analyze, validate) and compares every output table with
the tables shipped in the archive. Writes outputs/logs/clean_room.json and clean_room.log.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ZIP = ROOT / "site/projects/insurance-continuity/downloads/insurance-continuity-source.zip"
LOG = ROOT / "outputs/logs/clean_room.log"


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def run(cmd: list[str], cwd: Path, fh) -> int:
    fh.write(f"\n$ {' '.join(cmd)}\n")
    fh.flush()
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "R_LIBS_USER", "INSCONT_ROOT", "VIRTUAL_ENV")}
    return subprocess.run(cmd, cwd=cwd, stdout=fh, stderr=subprocess.STDOUT, env=env).returncode


def compare(base: Path, new: Path) -> tuple[int, list]:
    import pandas as pd
    n, diffs = 0, []
    for f in sorted(base.glob("*.csv")):
        if f.name.startswith(("rerun_", "validation_public")):
            continue
        g = new / f.name
        if not g.exists():
            diffs.append([f.name, "missing"])
            continue
        a, b = pd.read_csv(f), pd.read_csv(g)
        if a.shape != b.shape:
            diffs.append([f.name, "shape", a.shape, b.shape])
            continue
        for c in a.columns:
            for x, y in zip(a[c], b[c]):
                n += 1
                if pd.isna(x) and pd.isna(y):
                    continue
                if isinstance(x, (int, float)) and isinstance(y, (int, float)):
                    if abs(float(x) - float(y)) > 1e-9:
                        diffs.append([f.name, c, x, y])
                elif str(x) != str(y):
                    diffs.append([f.name, c, str(x), str(y)])
    return n, diffs


def main() -> None:
    tmp = Path(tempfile.mkdtemp(prefix="inscont_cleanroom_"))
    result = {"started_utc": dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat(),
              "archive": ZIP.relative_to(ROOT).as_posix(), "archive_sha256": sha256(ZIP), "steps": {}}
    with open(LOG, "w", encoding="utf-8") as fh, zipfile.ZipFile(ZIP) as zf:
        zf.extractall(tmp)
        for info in zf.infolist():  # restore file modes (extractall does not; unzip does)
            mode = (info.external_attr >> 16) & 0o777
            if mode:
                os.chmod(tmp / info.filename, mode)
        proj = tmp / "insurance-continuity"
        shutil.copytree(proj / "outputs" / "tables", tmp / "shipped_tables")
        for name, cmd in [("setup", ["./setup.sh"]), ("test", ["./icont", "test"]), ("demo", ["./icont", "demo"]),
                          ("acquire", ["./icont", "acquire"]), ("build", ["./icont", "build"]),
                          ("analyze", ["./icont", "analyze"]), ("validate", ["./icont", "validate"]),
                          ("render", ["./icont", "render"]), ("package", ["./icont", "package"])]:
            rc = run(cmd, proj, fh)
            result["steps"][name] = rc
            if rc != 0:
                break
    if all(v == 0 for v in result["steps"].values()) and len(result["steps"]) == 9:
        n, diffs = compare(tmp / "shipped_tables", proj / "outputs" / "tables")
        result.update({"values_compared": n, "differences": len(diffs), "first_differences": diffs[:20]})
        tests = (LOG.read_text(encoding="utf-8").split("$ ./icont test", 1)[1].split("$ ./icont demo", 1)[0].strip().splitlines() or [""])[-1]
        result["summary"] = (f"final source archive (sha256 {result['archive_sha256'][:12]}) extracted to an empty directory; setup succeeded; "
                             f"unit tests: {tests}; demo ran; full pipeline from a fresh AHRQ download (acquire, build, analyze, validate, render, package) reproduced "
                             f"{n:,} table values with {len(diffs)} differences beyond 1e-9")
    else:
        result["summary"] = f"clean-room run stopped: step return codes {result['steps']}; see outputs/logs/clean_room.log"
    result["finished_utc"] = dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    (ROOT / "outputs/logs/clean_room.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    if "reproduced" in result["summary"]:
        shutil.rmtree(tmp, ignore_errors=True)
    else:
        result["kept_for_inspection"] = str(tmp)
        (ROOT / "outputs/logs/clean_room.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(result["summary"])
    sys.exit(0 if "reproduced" in result["summary"] and result.get("differences", 1) == 0 else 1)


if __name__ == "__main__":
    main()
