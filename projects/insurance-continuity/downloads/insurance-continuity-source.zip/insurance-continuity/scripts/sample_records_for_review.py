"""Print 25 randomly sampled primary-domain members for a manual check of the classification.

Monthly codes are read straight from the AHRQ Stata file (h256.dta), not from pipeline
outputs, so the reviewer can classify each sequence by eye and compare with the
assigned class. Seed 2024. Prints DUPERSID only to the local terminal.
"""

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
MONTHS = ["JA", "FE", "MA", "AP", "MY", "JU", "JL", "AU", "SE", "OC", "NO", "DE"]

cols = ["DUPERSID", "INS24X"] + [f"INS{m}24X" for m in MONTHS]
raw = pd.read_stata(ROOT / "data/raw/h256/h256.dta", columns=cols, convert_categoricals=False)
cls = pd.read_csv(ROOT / "data/processed/analysis_2024.csv", usecols=["person_id", "domain_c", "continuity_class"], dtype={"person_id": str})
dom = cls[cls["domain_c"] == 1].sample(n=25, random_state=2024)
m = dom.merge(raw, left_on="person_id", right_on="DUPERSID", how="left", validate="one_to_one")
m["months_Jan_to_Dec"] = m[[f"INS{x}24X" for x in MONTHS]].astype(int).astype(str).agg("".join, axis=1)
print("Codes: 1 = covered, 2 = not covered, -1 = out of scope. INS24X is coverage on 12/31.")
print(m[["person_id", "INS24X", "months_Jan_to_Dec", "continuity_class"]].to_string(index=False))
