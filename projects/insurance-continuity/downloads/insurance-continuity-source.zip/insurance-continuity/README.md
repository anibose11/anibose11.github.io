# insurance-continuity

Within-year coverage gaps and prescription spending among US adults with diabetes, using the AHRQ Medical Expenditure Panel Survey (MEPS) 2024 Full Year Consolidated file (HC-256), with a 2023 replication (HC-251) and fill-level imputation flags from the 2024 Prescribed Medicines file (HC-254A).

**Question.** Among adults aged 18 to 64 with diagnosed diabetes who were insured on December 31, 2024, what weighted share had at least one fully uninsured month that year, and how do annual prescription use and out-of-pocket spending summaries change when monthly continuity is kept?

**Main result (2024).** 8.5% (95% CI 6.3% to 11.4%; 70 of 885 respondents) of the year-end insured had at least 1 uninsured month; 4.7% had 3 or more consecutive uninsured months. The 2023 estimate was 8.4%. `./icont render` writes the full report (`site/projects/insurance-continuity/report.html`, also included in the project bundle), and `evidence/claims.json` maps each headline number to its output table.

## Setup

Requirements: Python 3.11 or later, R 4.5 or later, and network access to meps.ahrq.gov for the first run. No sudo, Docker, database server, or credentials are needed.

```bash
./setup.sh
```

This creates `.venv/` (Python packages pinned in `requirements.lock`) and `.Rlib/` (every R package in `R/packages.lock.csv`, installed at the listed version).

## Pipeline

```bash
./icont acquire    # download and verify AHRQ files; writes source_manifest.json
./icont build      # DuckDB SQL: person and person-month tables, classification, reconciliation
./icont analyze    # R survey: design-based estimates for 2024 and 2023
./icont validate   # unit tests, reconciliation roll-up, independent variance cross-check
./icont render     # figures, workbook, claims, manuscript, supplement, report, site page
./icont package    # source archive, handoff files, outer bundle with checksums
./icont all        # all six stages in order
./icont rerun      # rebuild from cached raw files and compare every numeric output
./icont bundle     # rebuild the handoff files and outer bundle without rebuilding the source archive
./icont test       # unit tests only (synthetic fixtures)
./icont demo       # 8 synthetic records through the classifier (not study evidence)
```

Raw MEPS files are cached in `data/raw/` and are never redistributed. `./icont acquire` compares each download with `config/expected_checksums.json` (the versions analyzed in this study) and stops on a mismatch unless `--accept-new-release` is given.

## Layout

| Path | Contents |
|---|---|
| `config/study.json` | Releases, URLs, variable templates, domain rules, thresholds |
| `src/inscont/continuity.py` | Reusable coverage-continuity audit function |
| `src/inscont/` | Acquisition, codebook parsing, build, validation, figures, workbook, rendering, packaging |
| `sql/` | DuckDB transformations (person, person-month, reconciliation, SQL cross-check classification, prescription events) |
| `R/analysis.R` | Design-based estimation (survey package) |
| `tests/` | Unit tests and synthetic fixtures |
| `docs/` | Analysis plan, contribution decision, prior art, search log, data dictionary, Tableau specification |
| `outputs/` | Aggregate tables, figures, estimates JSON, workbook, Tableau CSVs, logs |
| `manuscript/` | Manuscript and supplement templates and rendered Markdown |
| `evidence/claims.json` | Every headline number mapped to its output table, row, and column |

## Using the classification function on other data

```python
from inscont.continuity import classify_continuity
res = classify_continuity(monthly_df, year_end_series, month_columns=[...],
                          covered=(1,), not_covered=(2,), out_of_scope=(-1,), missing=(-7, -8, -15))
res.persons   # one row per person: class, alternative class, month counts, gap pattern, flags
res.audit     # rule counts and code counts for checking
```

Out-of-scope and missing months are never treated as uninsured. A person insured at year end with any observed uninsured month is in the gap class; a person with no observed uninsured month but some unobserved months is indeterminate.

## Data use

MEPS public-use files are subject to the AHRQ data use requirements printed in their documentation. I calculated these estimates. AHRQ has not endorsed them. See `NOTICE.md`.

## License

Code: MIT (see `LICENSE`). MEPS data and third-party packages keep their own terms.
