#!/usr/bin/env bash
# One-time setup: project-local Python virtual environment and R library. No sudo, no global installs.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"
PY="${PYTHON:-python3}"
if [ ! -x .venv/bin/python ]; then "$PY" -m venv .venv; fi
.venv/bin/pip install --quiet --upgrade pip
if ! .venv/bin/pip install --quiet -r requirements.lock; then
  echo "Locked versions unavailable for this platform; installing current versions from requirements.txt" >&2
  .venv/bin/pip install --quiet -r requirements.txt
fi
if command -v Rscript >/dev/null 2>&1; then
  R_LIBS_USER="$HERE/.Rlib" Rscript --vanilla R/install.R
else
  echo "Rscript not found: install R (4.5 or later) to run the analyze stage. Other stages and tests run without R." >&2
fi
chmod +x icont
echo "Setup complete. Next: ./icont test, then ./icont all"
