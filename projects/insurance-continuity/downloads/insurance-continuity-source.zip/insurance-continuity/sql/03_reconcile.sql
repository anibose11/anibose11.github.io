-- Reconciliation of the person-month table with AHRQ annual indicators, on documented definitions.
-- Each row: check name, persons checked, mismatches. Expected mismatches: 0 unless noted.
CREATE OR REPLACE TABLE pm_summary AS
SELECT
    person_id,
    COUNT(*)                                                     AS n_rows,
    SUM(CASE WHEN any_cov = 1 THEN 1 ELSE 0 END)                 AS m_cov,
    SUM(CASE WHEN any_cov = 2 THEN 1 ELSE 0 END)                 AS m_unc,
    SUM(CASE WHEN any_cov = -1 THEN 1 ELSE 0 END)                AS m_oos,
    SUM(CASE WHEN coverage_state = 'missing' THEN 1 ELSE 0 END)  AS m_mis,
    MAX(CASE WHEN any_cov <> -1 AND (private_cov = 1 OR tricare_cov = 1) THEN 1 ELSE 0 END) AS any_private_or_tricare,
    MAX(CASE WHEN any_cov <> -1 AND public_cov = 1 THEN 1 ELSE 0 END)                       AS any_public,
    SUM(CASE WHEN any_cov = 1 AND NOT (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END) AS m_any_without_source,
    SUM(CASE WHEN any_cov = 2 AND (private_cov = 1 OR public_cov = 1) THEN 1 ELSE 0 END)     AS m_source_without_any,
    SUM(CASE WHEN any_cov = 2 AND ihs_cov = 1 THEN 1 ELSE 0 END)                             AS m_ihs_only_uninsured,
    MAX(CASE WHEN month = 12 THEN any_cov END)                   AS dec_any
FROM person_month
GROUP BY person_id;

CREATE OR REPLACE TABLE reconciliation AS
SELECT 'person_month_rows_equal_12_per_person' AS check_name,
       COUNT(*) AS n_checked, SUM(CASE WHEN n_rows <> 12 THEN 1 ELSE 0 END) AS n_mismatch,
       'Every person has exactly 12 person-month rows' AS definition
FROM pm_summary
UNION ALL
SELECT 'persons_in_person_month_equal_person_table', (SELECT COUNT(*) FROM person),
       ABS((SELECT COUNT(*) FROM person) - (SELECT COUNT(*) FROM pm_summary)),
       'Person count unchanged by the reshape'
UNION ALL
SELECT 'unins_year_matches_all_inscope_months_uninsured', COUNT(*),
       SUM(CASE WHEN (p.unins_year = 1) <> (s.m_cov = 0 AND s.m_unc > 0) THEN 1 ELSE 0 END),
       'UNINS = 1 exactly when every in-scope month has INSmm = 2 (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_3_iff_unins_year', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 3) <> (p.unins_year = 1) THEN 1 ELSE 0 END),
       'INSCOV = 3 exactly when UNINS = 1'
FROM person p
UNION ALL
SELECT 'inscov_1_iff_any_private_or_tricare_month', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 1) <> (s.any_private_or_tricare = 1) THEN 1 ELSE 0 END),
       'INSCOV = 1 exactly when any in-scope month has private or TRICARE/CHAMPVA coverage (documentation C-120)'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'inscov_2_iff_public_only', COUNT(*),
       SUM(CASE WHEN (p.inscov_year = 2) <> (s.any_private_or_tricare = 0 AND s.any_public = 1) THEN 1 ELSE 0 END),
       'INSCOV = 2 exactly when public coverage in some month and no private/TRICARE month'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'monthly_any_equals_private_or_public', COUNT(*),
       SUM(CASE WHEN any_cov IN (1, 2) AND ((any_cov = 1) <> (private_cov = 1 OR public_cov = 1)) THEN 1 ELSE 0 END),
       'INSmm = 1 exactly when PRImm = 1 or PUBmm = 1 (person-months)'
FROM person_month
UNION ALL
SELECT 'monthly_scope_code_consistent_across_sources', COUNT(*),
       SUM(CASE WHEN (any_cov = -1) <> (private_cov = -1) OR (any_cov = -1) <> (public_cov = -1) THEN 1 ELSE 0 END),
       'Out-of-scope code -1 appears in INS, PRI, and PUB for the same person-months'
FROM person_month
UNION ALL
SELECT 'year_end_insured_implies_december_insured_if_in_scope_in_december', SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec <> -1 AND p.ins_dec <> 1 THEN 1 ELSE 0 END),
       'INS(12/31) = 1 implies INSDE = 1 for persons in scope in December'
FROM person p
UNION ALL
SELECT 'info_year_end_value_recorded_at_departure_date', SUM(CASE WHEN p.ins_1231 = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_1231 = 1 AND p.ins_dec = -1 THEN 1 ELSE 0 END),
       'Informational: INS(12/31) = 1 with December out of scope; AHRQ records 12/31 coverage as of the date a person left the RU (documentation C-122)'
FROM person p
UNION ALL
SELECT 'insdec_matches_person_month_december', COUNT(*),
       SUM(CASE WHEN p.ins_dec IS DISTINCT FROM s.dec_any THEN 1 ELSE 0 END),
       'INSDE in the person table equals the December row of the person-month table'
FROM person p JOIN pm_summary s USING (person_id)
UNION ALL
SELECT 'info_december_insured_but_not_on_1231', SUM(CASE WHEN p.ins_dec = 1 THEN 1 ELSE 0 END),
       SUM(CASE WHEN p.ins_dec = 1 AND p.ins_1231 = 2 THEN 1 ELSE 0 END),
       'Informational, not an error: covered at some time in December but not on 12/31 (coverage ended in December)'
FROM person p
UNION ALL
SELECT 'info_ihs_only_months_counted_uninsured', (SELECT COUNT(*) FROM person_month),
       (SELECT SUM(m_ihs_only_uninsured) FROM pm_summary),
       'Informational: months with IHS coverage and no other source; AHRQ does not count IHS as coverage'
;
