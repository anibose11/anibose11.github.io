-- Independent SQL implementation of the continuity classes, used only to cross-check
-- the Python audit function (inscont.continuity.classify_continuity).
CREATE OR REPLACE TABLE sql_class AS
SELECT
    p.person_id,
    CASE
        WHEN p.ins_1231 IS NULL OR p.ins_1231 NOT IN (1, 2) THEN 'indeterminate'
        WHEN p.ins_1231 = 2 THEN 'uninsured_year_end'
        WHEN s.m_unc > 0 THEN 'insured_year_end_gap'
        WHEN s.m_oos + s.m_mis > 0 THEN 'indeterminate'
        ELSE 'insured_year_end_continuous'
    END AS continuity_class_sql,
    s.m_unc AS n_months_uncovered_sql,
    s.m_oos AS n_months_out_of_scope_sql
FROM person p JOIN pm_summary s USING (person_id);
