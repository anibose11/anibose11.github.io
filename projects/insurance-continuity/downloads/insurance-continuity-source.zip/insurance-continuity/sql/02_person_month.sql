-- Person-month table: 12 rows per person.
-- The unpivot placeholder below expands to one column group per month, e.g.
--   (INSJA24X, PRIJA24, PUBJA24X, MCRJA24X, MCDJA24X, TRIJA24X, VAPJA24, GVAJA24, IHSJA24) AS "01"
-- Coverage state per month (any-coverage indicator decides insured vs uninsured):
--   private_only, public_only, private_and_public, uninsured, not_in_scope, missing
CREATE OR REPLACE TABLE person_month AS
WITH long AS (
    UNPIVOT (SELECT DUPERSID, {all_monthly_columns} FROM fyc)
    ON {unpivot_groups}
    INTO NAME month_key VALUE any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
                              tricare_cov, va_cov, other_public_cov, ihs_cov
)
SELECT
    DUPERSID                         AS person_id,
    CAST(month_key AS INTEGER)       AS month,
    any_cov, private_cov, public_cov, medicare_cov, medicaid_cov,
    tricare_cov, va_cov, other_public_cov, ihs_cov,
    CASE
        WHEN any_cov = -1 THEN 'not_in_scope'
        WHEN any_cov IS NULL OR any_cov NOT IN (1, 2) THEN 'missing'
        WHEN any_cov = 2 THEN 'uninsured'
        WHEN private_cov = 1 AND public_cov = 1 THEN 'private_and_public'
        WHEN private_cov = 1 THEN 'private_only'
        WHEN public_cov = 1 THEN 'public_only'
        ELSE 'insured_source_unresolved'
    END AS coverage_state,
    -- number of distinct coverage sources recorded in the month (multi-source months count once as insured)
    (CASE WHEN private_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN medicare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN medicaid_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN tricare_cov = 1 THEN 1 ELSE 0 END)
  + (CASE WHEN va_cov = 1 THEN 1 ELSE 0 END) + (CASE WHEN other_public_cov = 1 THEN 1 ELSE 0 END) AS n_sources
FROM long;
