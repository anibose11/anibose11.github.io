-- Prescribed medicines (HC-254A) aggregated to persons, with imputation information.
-- IMPFLAG: 2 = complete pharmacy component data, 4 = fully imputed, 5 = partially imputed.
CREATE OR REPLACE TABLE rx_person AS
SELECT
    DUPERSID                                                   AS person_id,
    COUNT(*)                                                   AS rx_records,
    SUM(RXSF24X)                                               AS rx_oop_event_sum,
    SUM(RXXP24X)                                               AS rx_exp_event_sum,
    SUM(CASE WHEN IMPFLAG = 2 THEN 1 ELSE 0 END)               AS rx_records_complete_pc,
    SUM(CASE WHEN IMPFLAG = 4 THEN 1 ELSE 0 END)               AS rx_records_fully_imputed,
    SUM(CASE WHEN IMPFLAG = 5 THEN 1 ELSE 0 END)               AS rx_records_partially_imputed,
    SUM(CASE WHEN IMPFLAG IN (4, 5) THEN RXSF24X ELSE 0 END)   AS rx_oop_from_imputed_records,
    SUM(CASE WHEN DIABEQUIP = 1 THEN 1 ELSE 0 END)             AS rx_records_diabetic_supplies,
    SUM(CASE WHEN IMPFLAG NOT IN (2, 4, 5) OR IMPFLAG IS NULL THEN 1 ELSE 0 END) AS rx_records_other_impflag
FROM rx_events
GROUP BY DUPERSID;

CREATE OR REPLACE TABLE rx_reconciliation AS
SELECT 'rx_event_persons_found_in_fyc' AS check_name,
       (SELECT COUNT(*) FROM rx_person) AS n_checked,
       (SELECT COUNT(*) FROM rx_person r WHERE NOT EXISTS (SELECT 1 FROM person p WHERE p.person_id = r.person_id)) AS n_mismatch,
       'Every person with an HC-254A record exists in the FYC person table' AS definition
UNION ALL
SELECT 'rx_fills_equal_event_record_count', COUNT(*),
       SUM(CASE WHEN p.rx_fills <> COALESCE(r.rx_records, 0) THEN 1 ELSE 0 END),
       'RXTOT equals the number of HC-254A records for the person (0 when none)'
FROM person p LEFT JOIN rx_person r USING (person_id)
UNION ALL
SELECT 'rx_oop_equals_event_sum_within_1_dollar', COUNT(*),
       SUM(CASE WHEN ABS(p.rx_oop - COALESCE(r.rx_oop_event_sum, 0)) > 1.0 THEN 1 ELSE 0 END),
       'RXSLF equals the rounded sum of RXSF across the person''s HC-254A records (tolerance $1 for rounding)'
FROM person p LEFT JOIN rx_person r USING (person_id)
UNION ALL
SELECT 'rx_exp_equals_event_sum_within_1_dollar', COUNT(*),
       SUM(CASE WHEN ABS(p.rx_total_exp - COALESCE(r.rx_exp_event_sum, 0)) > 1.0 THEN 1 ELSE 0 END),
       'RXEXP equals the rounded sum of RXXP across the person''s HC-254A records (tolerance $1)'
FROM person p LEFT JOIN rx_person r USING (person_id)
;
