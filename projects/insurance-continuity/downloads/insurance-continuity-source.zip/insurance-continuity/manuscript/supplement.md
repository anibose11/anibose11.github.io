# Supplemental Digital Content 1

Insured on December 31, Uninsured Earlier in the Year: Within-Year Coverage Gaps and Prescription Spending Among US Adults With Diabetes

## Section S1. Methods details

### S1.1 Data releases and verification

| Release | Role | Reference period | Release date | File checked |
|---|---|---|---|---|
| HC-256: 2024 Full Year Consolidated Data File | primary | calendar year 2024 | August 2026 | h256dta.zip, SHA-256 653891861ec18574... |
| HC-251: 2023 Full Year Consolidated Data File | replication | calendar year 2023 | August 2025 | h251dta.zip, SHA-256 82e321f4b3720431... |
| HC-254A: 2024 Prescribed Medicines File | imputation flags and reconciliation | calendar year 2024 | July 2026 | h254adta.zip, SHA-256 8afe0228acf154e0... |

Each file was streamed from the AHRQ site, checked for the expected content type and file signature (so an HTML error page could not pass as data), hashed with SHA-256, and extracted only for its expected archive member. Official detail pages for later public-use file numbers were checked on the access date, and none was a 2025 Full Year Consolidated file, so HC-256 was the newest compatible release. Release year, data reference period, and access date are recorded separately for each file.

### S1.2 Scope rule

A month was treated as in scope when the monthly any-coverage indicator held a substantive value (1 or 2). MEPS codes months outside a person's in-scope period as −1. The primary domain also required in-scope status on December 31 (INSC1231 = 1) and a 2024 reference period ending in December (ENDRFM24 = 12). Among the 1,002 adults with diabetes who were in scope on December 31 with a year-end coverage value, the monthly rule and the round-level scope variables agreed for 1,002 (Table S1). The one adult in scope on December 31 but not all year was insured on December 31 and in scope for 9 months; with 3 months unobserved, that person's continuity is indeterminate.

### S1.3 Classification rules

The function applies these rules to each person in order. (1) A missing or unrecognized year-end value gives class D. (2) Uninsured on December 31 gives class C. (3) Insured on December 31 with any month coded uninsured gives class B. (4) Insured on December 31, no month coded uninsured, but any month out of scope, missing, or unrecognized gives class D. (5) Otherwise class A. Under the alternative definition, class B requires a run of at least 3 consecutive uninsured months; people whose only gaps are shorter move to class A if every month is observed and to class D otherwise. Across the full 2024 file the rules assigned rule 1 to 161 records, rule 2 to 1,896, rule 3 to 973, rule 4 to 319, and rule 5 to 15,791 (all ages and scope patterns).

### S1.4 Reconciliation with AHRQ indicators

| Year | Kind | Check | Records checked | Mismatches | Status |
|---|---|---|---|---|---|
| 2024 | Source reconciliation | Each person has 12 person-month rows | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Person count unchanged by the reshape | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Uninsured-all-year indicator equals all in-scope months uninsured | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Annual coverage indicator 'uninsured' equals uninsured all year | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Annual 'any private' equals any month with private or TRICARE coverage | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Annual 'public only' equals public coverage with no private or TRICARE month | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Monthly any coverage equals private or public coverage (person-months) | 229,680 | 0 | Pass |
| 2024 | Source reconciliation | Out-of-scope months coded the same across coverage sources | 229,680 | 0 | Pass |
| 2024 | Source reconciliation | Insured on 12/31 implies insured in December (in scope in December) | 17,047 | 0 | Pass |
| 2024 | Source reconciliation | Informational: 12/31 value recorded at the date a person left the household | 17,083 | 36 | Informational |
| 2024 | Source reconciliation | December indicator equals the December person-month row | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Informational: covered in December but not on 12/31 | 17,105 | 58 | Informational |
| 2024 | Source reconciliation | Informational: months with Indian Health Service coverage only | 229,680 | 210 | Informational |
| 2024 | Software cross-check | Classification function agrees with independent SQL classification | 19,140 | 0 | Pass |
| 2024 | Software cross-check | Uninsured-month counts agree between the two implementations | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | No missing values in the person table | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Weighted and unweighted frequencies equal the AHRQ codebook | 30 | 0 | Pass |
| 2024 | Source reconciliation | Every person in the prescription file is in the person file | 12,135 | 0 | Pass |
| 2024 | Source reconciliation | Fill count equals the number of prescription records | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Out-of-pocket total equals the sum over prescription records (within $1) | 19,140 | 0 | Pass |
| 2024 | Source reconciliation | Total expenditure equals the sum over prescription records (within $1) | 19,140 | 0 | Pass |
| 2023 | Source reconciliation | Each person has 12 person-month rows | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Person count unchanged by the reshape | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Uninsured-all-year indicator equals all in-scope months uninsured | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Annual coverage indicator 'uninsured' equals uninsured all year | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Annual 'any private' equals any month with private or TRICARE coverage | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Annual 'public only' equals public coverage with no private or TRICARE month | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Monthly any coverage equals private or public coverage (person-months) | 227,028 | 0 | Pass |
| 2023 | Source reconciliation | Out-of-scope months coded the same across coverage sources | 227,028 | 0 | Pass |
| 2023 | Source reconciliation | Insured on 12/31 implies insured in December (in scope in December) | 16,740 | 0 | Pass |
| 2023 | Source reconciliation | Informational: 12/31 value recorded at the date a person left the household | 16,781 | 41 | Informational |
| 2023 | Source reconciliation | December indicator equals the December person-month row | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Informational: covered in December but not on 12/31 | 16,815 | 75 | Informational |
| 2023 | Source reconciliation | Informational: months with Indian Health Service coverage only | 227,028 | 91 | Informational |
| 2023 | Software cross-check | Classification function agrees with independent SQL classification | 18,919 | 0 | Pass |
| 2023 | Software cross-check | Uninsured-month counts agree between the two implementations | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | No missing values in the person table | 18,919 | 0 | Pass |
| 2023 | Source reconciliation | Weighted and unweighted frequencies equal the AHRQ codebook | 30 | 0 | Pass |

Informational counts are not errors. They record people whose December 31 coverage AHRQ captured on the date they left the household (36 in 2024; none in the analytic domain), people covered at some time in December but not on December 31, and person-months with Indian Health Service coverage only, which AHRQ counts as uninsured.

### S1.5 Prescription expenditure states and imputation

Unweighted counts of prescription states in the primary domain. No record had missing expenditure.

| Year | Class | State | Unweighted n |
|---|---|---|---|
| 2024 | A. Insured all 12 months | Fills with positive out-of-pocket | 636 |
| 2024 | A. Insured all 12 months | Fills with $0 out-of-pocket | 130 |
| 2024 | A. Insured all 12 months | No recorded fill | 49 |
| 2024 | B. Insured on 12/31, ≥1 uninsured month | Fills with positive out-of-pocket | 49 |
| 2024 | B. Insured on 12/31, ≥1 uninsured month | Fills with $0 out-of-pocket | 7 |
| 2024 | B. Insured on 12/31, ≥1 uninsured month | No recorded fill | 14 |
| 2024 | C. Uninsured on 12/31 | Fills with positive out-of-pocket | 76 |
| 2024 | C. Uninsured on 12/31 | Fills with $0 out-of-pocket | 4 |
| 2024 | C. Uninsured on 12/31 | No recorded fill | 36 |
| 2023 | A. Insured all 12 months | Fills with positive out-of-pocket | 649 |
| 2023 | A. Insured all 12 months | Fills with $0 out-of-pocket | 111 |
| 2023 | A. Insured all 12 months | No recorded fill | 37 |
| 2023 | B. Insured on 12/31, ≥1 uninsured month | Fills with positive out-of-pocket | 46 |
| 2023 | B. Insured on 12/31, ≥1 uninsured month | Fills with $0 out-of-pocket | 7 |
| 2023 | B. Insured on 12/31, ≥1 uninsured month | No recorded fill | 10 |
| 2023 | C. Uninsured on 12/31 | Fills with positive out-of-pocket | 89 |
| 2023 | C. Uninsured on 12/31 | Fills with $0 out-of-pocket | 3 |
| 2023 | C. Uninsured on 12/31 | No recorded fill | 34 |

### S1.6 Two-part model support and specification

The support rule required at least 80 people with the less common part-1 outcome, at least 80 people with positive out-of-pocket spending, at least 25 with positive spending in each class, and at least 30 design degrees of freedom. In 2024 the less common part-1 outcome had 240 people and class B had 49 people with positive spending; in 2023 the figures were 202 and 46. Both parts were refit in each of 264 (2024) and 262 (2023) jackknife replicates, and every replicate fit converged. Weights were divided by their mean within each fit, which leaves estimates unchanged and avoids a known failure of the binomial starting values when weights are large.

### S1.7 Analysis plan amendments

The analysis plan was written and dated before any data were tabulated. All amendments were recorded on October 7, 2026. Amendments 1 to 4 are listed in the order made; amendments 5 to 8 were recorded after an internal review of the completed analysis, and each states when it was made relative to inspection of estimates. None changes the estimand, eligibility, classification rules, gap definitions, adjustment set, or robustness checks.

1. After the first build, before any survey estimate. The reconciliation check "INS(12/31) = 1 implies INSDE = 1" flagged 36 records in 2024 and 41 in 2023. All had December coded out of scope (−1). AHRQ documents that for persons who left the household before December 31, the 12/31 variable records coverage on the date they left. The check was restricted to persons in scope in December, and the departures are reported as an informational count. None of these records is in an analytic frame.
2. After the first model run. In the first run, the part-1 logistic model failed to converge in 257 of 264 jackknife replicates because R's binomial starting values break down with weights in the thousands, which inflated the replicate standard errors about eightfold. Weights inside each replicate fit are now divided by their mean, which leaves point estimates unchanged (the full-sample fit then reproduces the svyglm coefficients exactly). All replicate fits converge, and the count of non-converged fits is written to the output table. Only the corrected results are reported.
3. After estimates were seen. The month-by-month uninsured shares in the gap group (n = 70) do not meet the NCHS presentation standard for proportions, so that figure was moved from the main text to the supplement, with the caveat printed on it.
4. After estimates were seen (post hoc, descriptive). Because the 2024 class A mean had a relative standard error near 30%, a diagnostic of spending concentration was added: the weighted share of out-of-pocket dollars from the top 1% and 5% of persons, and the maximum annual out-of-pocket amount in each class. It is reported as a diagnostic with no inference and was not used to trim or recode any value.
5. Before the first analysis run, with no estimates seen. Design-based contrasts between classes for any fill and for mean fills were added to the analysis code alongside the prespecified contrasts for mean out-of-pocket spending. They are reported as descriptive differences.
6. Clarification, no change to the analysis. The plan described part 1 of the two-part model as "any fill" in one sentence and as P(OOP > 0) in another. The analysis used P(OOP > 0), consistent with modelling out-of-pocket spending, and the support rule was evaluated on that outcome.
7. After estimates were seen. The reliability flags were completed to match this plan and the NCHS standard: quantiles are now flagged by the 30% relative standard error rule (the first implementation checked only n < 30), and proportions whose complementary proportion would fail the relative width rule are marked for review. This changes footnotes only; no estimate changed.
8. After estimates were seen. (a) The plan listed fewer than 8 design degrees of freedom among the criteria for flagging a proportion as unreliable; following the NCHS standard, such proportions are marked for review rather than suppressed, and means and quantiles whose standard error cannot be estimated are also flagged. (b) The code now computes the primary proportion on the complete-information denominator whenever anyone in it is indeterminate, as this plan specified; no one was indeterminate, so no estimate changed. (c) The post hoc spending diagnostic (amendment 4) also reports class means excluding the top 1% of the domain. These changes affect footnotes and descriptive diagnostics only.

### S1.8 Literature search methods

Searches were run on October 7, 2026, in PubMed through the National Center for Biotechnology Information E-utilities, with full text read in PubMed Central or publisher open-access copies where available; digital object identifiers were verified with the Crossref API. Official AHRQ MEPS publications (Statistical Briefs and Research Findings), the MEPS documentation, and the agency's public code repository were also searched, together with general web searches for official pages. Representative PubMed queries were: ("Medical Expenditure Panel Survey"[tiab] OR MEPS[tiab]) AND (churn*[tiab] OR "part-year"[tiab] OR "coverage disruption*"[tiab] OR discontinu*[tiab] OR "insurance gap*"[tiab] OR "coverage gap*"[tiab] OR "continuous coverage"[tiab]); (churn*[tiab] OR discontinu*[tiab] OR lapse*[tiab] OR gap*[tiab]) AND (insurance[tiab] OR Medicaid[tiab] OR coverage[tiab]) AND diabetes[tiab] AND (prescription*[tiab] OR medication*[tiab] OR expenditure*[tiab] OR "out-of-pocket"[tiab] OR cost*[tiab]); and (insurance coverage) AND (survey) AND ("reference period" OR "point-in-time") AND (uninsured). Studies, agency reports, and software were included if they measured coverage within a year or over time, or related coverage continuity to prescription use or spending, with priority to US data, MEPS, and diabetes. Three cited articles were available only as abstracts and are cited only for statements in their abstracts.

## Section S2. Supplementary figures and tables

![Figure S1. Cohort flow, 2024. Unweighted record counts at each cumulative step and the classification of the primary domain.](../outputs/figures/figS1_cohort_flow_2024.png)

*Figure S1. Cohort flow, 2024. Unweighted record counts at each cumulative step and the classification of the primary domain.*

![Figure S2. Share of the year-end insured with a gap by gap definition and year. Separate design-based estimates; years are not pooled.](../outputs/figures/figS2_robustness_gap_definitions.png)

*Figure S2. Share of the year-end insured with a gap by gap definition and year. Separate design-based estimates; years are not pooled.*

![Figure S3. Share uninsured in each month among class B, 2024. Subgroup estimates do not meet the NCHS presentation standard and describe timing only.](../outputs/figures/figS3_monthly_uninsured_gap_group_2024.png)

*Figure S3. Share uninsured in each month among class B, 2024. Subgroup estimates do not meet the NCHS presentation standard and describe timing only.*

![Figure S4. Year-end status versus monthly continuity, 2023 replication.](../outputs/figures/fig1_yearend_vs_continuity_2023.png)

*Figure S4. Year-end status versus monthly continuity, 2023 replication.*

### Table S1. Monthly scope rule versus round-level scope variables, 2024

Adults 18 to 64 with diagnosed diabetes and positive weight who were in scope on December 31 with a year-end coverage value. Columns: in scope for the whole reference period in each round covering 2024 (INSCOP31, INSCOP42, and INSCOP24 all equal 1). Unweighted counts.

| Monthly rule | Round-level: in scope throughout | Round-level: not in scope throughout |
|---|---|---|
| Not in scope all 12 months (monthly rule) | 0 | 1 |
| In scope all 12 months (monthly rule) | 1001 | 0 |

### Table S2. Month-to-month coverage transitions, primary domain, 2024

Share of person-month transitions out of each coverage state (rows sum to 100% within a from-state), with linearized standard errors from ratio estimators.

| From | To | Share, % (SE) | Transitions, n | People with from-state, n |
|---|---|---|---|---|
| Private only | Private only | 98.98 (0.16) | 5,012 | 497 |
| Private only | Public only | 0.05 (0.03) | 2 | 497 |
| Private only | Private and public | 0.34 (0.09) | 21 | 497 |
| Private only | Uninsured | 0.64 (0.14) | 27 | 497 |
| Public only | Private only | 0.08 (0.06) | 2 | 417 |
| Public only | Public only | 98.79 (0.24) | 4,109 | 417 |
| Public only | Private and public | 0.32 (0.10) | 12 | 417 |
| Public only | Uninsured | 0.81 (0.20) | 33 | 417 |
| Private and public | Private only | 1.14 (0.44) | 9 | 79 |
| Private and public | Public only | 2.48 (0.71) | 17 | 79 |
| Private and public | Private and public | 96.38 (0.93) | 544 | 79 |
| Private and public | Uninsured | 0.00 (0.00) | 0 | 79 |
| Uninsured | Private only | 3.94 (0.78) | 41 | 176 |
| Uninsured | Public only | 2.57 (0.57) | 34 | 176 |
| Uninsured | Private and public | 0.04 (0.05) | 1 | 176 |
| Uninsured | Uninsured | 93.44 (0.98) | 1,147 | 176 |

### Table S3. Characteristics of gaps in class B, with December coverage source in classes A and B, 2024

† Does not meet the National Center for Health Statistics (NCHS) presentation standard for proportions. ‡ Relative standard error above 30% or not estimable, or fewer than 30 people. § Meets the NCHS standard but calls for review (fewer than 8 design degrees of freedom, or the complementary proportion would not meet it).

| Group | Measure | Estimate (95% CI) | Unweighted n |
|---|---|---|---|
| Class B | Uninsured months in 2024, mean | 3.8 (3.0 to 4.7) | 70 |
| Class B | Uninsured in January, then insured through December, % | 63.7 (45.4 to 78.7) † | 70 |
| Class B | Single gap after an insured period, % | 32.8 (19.8 to 49.0) † | 70 |
| Class B | More than 1 gap, % | 3.5 (0.6 to 19.3) † | 70 |
| Class B | Uninsured through December, % | 0 | 70 |
| Class B | December coverage: private only, % | 63.6 (47.4 to 77.3) † | 70 |
| Class A | December coverage: private only, % | 58.5 (54.0 to 62.8) | 815 |
| Class B | December coverage: public only, % | 35.6 (22.1 to 51.9) † | 70 |
| Class A | December coverage: public only, % | 33.8 (29.6 to 38.3) | 815 |
| Class B | December coverage: private and public, % | 0.8 (0.1 to 7.7) † | 70 |
| Class A | December coverage: private and public, % | 7.7 (5.6 to 10.5) | 815 |
| Class B | 1 to 2 uninsured months (vs 3 to 11), % | 44.7 (29.4 to 61.0) † | 70 |

### Table S4. Changes in coverage without an uninsured month, class A, 2024

Changes between private insurers cannot be identified in the public-use file.

| Measure | Estimate, % (95% CI) | Unweighted n |
|---|---|---|
| Change in coverage categories held (private, Medicare, Medicaid, TRICARE, VA, other public), no uninsured month | 10.4 (8.2 to 13.0) | 815 |
| Change between private only, public only, and both, no uninsured month | 5.2 (3.6 to 7.3) | 815 |

### Table S5. Two-part model coefficients, 2024 (survey-weighted; descriptive)

Reference levels: class A, age 18 to 44, male, non-Hispanic White, income 200% of the federal poverty level or more.

| Part | Term | Exponentiated estimate (95% CI) |
|---|---|---|
| Part 1: any out-of-pocket spending (odds ratio) | Intercept | 5.21 (2.99 to 9.07) |
| Part 1: any out-of-pocket spending (odds ratio) | Class B vs A | 0.56 (0.27 to 1.18) |
| Part 1: any out-of-pocket spending (odds ratio) | Class C vs A | 0.69 (0.35 to 1.36) |
| Part 1: any out-of-pocket spending (odds ratio) | Age 45 to 64 vs 18 to 44 | 1.33 (0.86 to 2.04) |
| Part 1: any out-of-pocket spending (odds ratio) | Female vs male | 1.44 (0.94 to 2.20) |
| Part 1: any out-of-pocket spending (odds ratio) | Hispanic vs non-Hispanic White | 0.60 (0.36 to 1.01) |
| Part 1: any out-of-pocket spending (odds ratio) | Non-Hispanic Black vs non-Hispanic White | 0.62 (0.36 to 1.07) |
| Part 1: any out-of-pocket spending (odds ratio) | Non-Hispanic Asian, other, or multiple race vs non-Hispanic White | 0.57 (0.30 to 1.09) |
| Part 1: any out-of-pocket spending (odds ratio) | Income below 200% of the federal poverty level vs 200% or more | 0.36 (0.25 to 0.51) |
| Part 2: mean among people with spending (ratio of means) | Intercept | 569.82 (283.59 to 1144.94) |
| Part 2: mean among people with spending (ratio of means) | Class B vs A | 0.68 (0.35 to 1.33) |
| Part 2: mean among people with spending (ratio of means) | Class C vs A | 2.16 (1.00 to 4.64) |
| Part 2: mean among people with spending (ratio of means) | Age 45 to 64 vs 18 to 44 | 2.46 (1.59 to 3.81) |
| Part 2: mean among people with spending (ratio of means) | Female vs male | 0.54 (0.31 to 0.94) |
| Part 2: mean among people with spending (ratio of means) | Hispanic vs non-Hispanic White | 0.65 (0.38 to 1.12) |
| Part 2: mean among people with spending (ratio of means) | Non-Hispanic Black vs non-Hispanic White | 1.07 (0.47 to 2.43) |
| Part 2: mean among people with spending (ratio of means) | Non-Hispanic Asian, other, or multiple race vs non-Hispanic White | 0.65 (0.29 to 1.50) |
| Part 2: mean among people with spending (ratio of means) | Income below 200% of the federal poverty level vs 200% or more | 0.62 (0.38 to 1.01) |

### Table S6. Imputation information from the 2024 Prescribed Medicines file, users in the primary domain

† Does not meet the National Center for Health Statistics (NCHS) presentation standard for proportions. ‡ Relative standard error above 30% or not estimable, or fewer than 30 people. § Meets the NCHS standard but calls for review (fewer than 8 design degrees of freedom, or the complementary proportion would not meet it).

| Group | Measure | Estimate (95% CI) | Unweighted n |
|---|---|---|---|
| Class A | Users with ≥1 fill with fully or partially imputed payments, % | 90.1 (87.1 to 92.5) | 766 |
| Class A | Share of out-of-pocket dollars from fills with imputed payments, % | 76.7 (62.4 to 91.0) | 766 |
| Class A | Share of fills with fully imputed payments, % | 34.0 (29.5 to 38.6) | 766 |
| Class B | Users with ≥1 fill with fully or partially imputed payments, % | 90.1 (77.9 to 95.9) § | 56 |
| Class B | Share of out-of-pocket dollars from fills with imputed payments, % | 46.0 (13.1 to 79.0) | 56 |
| Class B | Share of fills with fully imputed payments, % | 25.6 (11.7 to 39.5) | 56 |
| Class C | Users with ≥1 fill with fully or partially imputed payments, % | 89.1 (77.7 to 95.0) § | 80 |
| Class C | Share of out-of-pocket dollars from fills with imputed payments, % | 51.1 (4.0 to 98.3) ‡ | 80 |
| Class C | Share of fills with fully imputed payments, % | 52.4 (33.4 to 71.4) | 80 |

### Table S7. Computed frequencies versus the AHRQ HC-256 codebook

Weighted values agree to within the codebook's rounding (absolute difference under 1).

| Variable | Code | Label | Codebook n | Computed n | Codebook weighted | Absolute difference, weighted |
|---|---|---|---|---|---|---|
| INS24X | −1 | Inapplicable | 161 | 161 | 2,998,984 | 0.33 |
| INS24X | 1 | Yes | 17,083 | 17,083 | 303,194,046 | 0.35 |
| INS24X | 2 | No | 1,896 | 1,896 | 33,604,599 | 0.08 |
| INSCOV24 | 1 | Any Private | 11,036 | 11,036 | 219,767,087 | 0.44 |
| INSCOV24 | 2 | Public Only | 6,816 | 6,816 | 98,034,323 | 0.43 |
| INSCOV24 | 3 | Uninsured | 1,288 | 1,288 | 21,996,220 | 0.47 |
| UNINS24 | 1 | Yes | 1,288 | 1,288 | 21,996,220 | 0.47 |
| UNINS24 | 2 | No | 17,852 | 17,852 | 317,801,409 | 0.13 |
| INSJA24X | −1 | Inapplicable | 379 | 379 | 3,310,431 | 0.27 |
| INSJA24X | 1 | Yes | 16,842 | 16,842 | 300,835,181 | 0.10 |
| INSJA24X | 2 | No | 1,919 | 1,919 | 35,652,017 | 0.43 |
| INSDE24X | −1 | Inapplicable | 198 | 198 | 3,593,646 | 0.23 |
| INSDE24X | 1 | Yes | 17,105 | 17,105 | 303,962,138 | 0.13 |
| INSDE24X | 2 | No | 1,837 | 1,837 | 32,241,845 | 0.24 |
| DIABDX_M18 | −8 | Don't know | 14 | 14 | 153,954 | 0.42 |
| DIABDX_M18 | −7 | Refused | 10 | 10 | 43,954 | 0.01 |
| DIABDX_M18 | −1 | Inapplicable | 88 | 88 | 1,014,420 | 0.21 |
| DIABDX_M18 | 1 | Yes | 2,285 | 2,285 | 32,938,553 | 0.43 |
| DIABDX_M18 | 2 | No | 16,743 | 16,743 | 305,646,748 | 0.39 |
| INSC1231 | 1 | In-Scope On 12/31/2024 | 18,909 | 18,909 | 336,022,966 | 0.00 |
| INSC1231 | 2 | Not In-Scope On 12/31/2024 | 231 | 231 | 3,774,664 | 0.40 |
| INSURC24 | 1 | <65 Any Private | 9,080 | 9,080 | 193,358,937 | 0.46 |
| INSURC24 | 2 | <65 Public Only | 3,793 | 3,793 | 60,991,070 | 0.00 |
| INSURC24 | 3 | <65 Uninsured | 1,270 | 1,270 | 21,770,810 | 0.31 |
| INSURC24 | 4 | 65+ Edited Medicare Only | 2,140 | 2,140 | 27,809,268 | 0.13 |
| INSURC24 | 5 | 65+ Edited Medicare And Private | 1,891 | 1,891 | 25,396,671 | 0.01 |
| INSURC24 | 6 | 65+ Edited Medicare And Oth Pub Only | 881 | 881 | 9,218,140 | 0.38 |
| INSURC24 | 7 | 65+ Uninsured | 18 | 18 | 225,410 | 0.16 |
| INSURC24 | 8 | 65+ No Medicare And Any Public/Private | 67 | 67 | 1,027,322 | 0.43 |
| PERWT24F (sum, all records) | total |  | 19,140 | 19,140 | 339,797,630 | 0.40 |

### Table S8. Prescription outcomes, 2023 replication (HC-251)

Nominal 2023 dollars. † Does not meet the National Center for Health Statistics (NCHS) presentation standard for proportions. ‡ Relative standard error above 30% or not estimable, or fewer than 30 people. § Meets the NCHS standard but calls for review (fewer than 8 design degrees of freedom, or the complementary proportion would not meet it).

| Group | Measure | Estimate (95% CI) | Unweighted n |
|---|---|---|---|
| A. Insured all 12 months | Any fill, % | 95.6 (93.4 to 97.1) | 797 |
| A. Insured all 12 months | Fills per person, mean | 30.5 (27.7 to 33.4) | 797 |
| A. Insured all 12 months | OOP spending, mean incl. zeros, $ | $344 ($289 to $399) | 797 |
| A. Insured all 12 months | OOP spending among users, median, $ | $133 ($114 to $176) | 760 |
| B. Insured 12/31, gap | Any fill, % | 85.6 (72.5 to 93.1) § | 63 |
| B. Insured 12/31, gap | Fills per person, mean | 22.8 (11.3 to 34.3) | 63 |
| B. Insured 12/31, gap | OOP spending, mean incl. zeros, $ | $324 ($119 to $528) | 63 |
| B. Insured 12/31, gap | OOP spending among users, median, $ | $125 ($60 to $342) ‡ | 53 |
| C. Uninsured 12/31 | Any fill, % | 70.2 (58.5 to 79.8) | 126 |
| C. Uninsured 12/31 | Fills per person, mean | 12.1 (8.7 to 15.6) | 126 |
| C. Uninsured 12/31 | OOP spending, mean incl. zeros, $ | $735 ($45 to $1,424) ‡ | 126 |
| C. Uninsured 12/31 | OOP spending among users, median, $ | $119 ($75 to $211) | 92 |
| Insured on 12/31 (A+B) | Any fill, % | 94.8 (92.7 to 96.3) | 860 |
| Insured on 12/31 (A+B) | Fills per person, mean | 29.9 (27.2 to 32.5) | 860 |
| Insured on 12/31 (A+B) | OOP spending, mean incl. zeros, $ | $343 ($291 to $394) | 860 |
| Insured on 12/31 (A+B) | OOP spending among users, median, $ | $132 ($114 to $174) | 813 |

### Table S9. Concentration of out-of-pocket spending in the primary domain (post hoc diagnostic, no inference)

| Year | Diagnostic | Value |
|---|---|---|
| 2024 | Share of out-of-pocket dollars from the top 1% of people | 41.8% |
| 2024 | Share of out-of-pocket dollars from the top 5% of people | 61.6% |
| 2024 | Largest annual out-of-pocket amount, class A | $91,626 |
| 2024 | Mean out-of-pocket spending excluding the domain top 1%, class A | $383 |
| 2024 | Largest annual out-of-pocket amount, class B | $3,268 |
| 2024 | Mean out-of-pocket spending excluding the domain top 1%, class B | $240 |
| 2024 | Largest annual out-of-pocket amount, class C | $15,377 |
| 2024 | Mean out-of-pocket spending excluding the domain top 1%, class C | $399 |
| 2023 | Share of out-of-pocket dollars from the top 1% of people | 23.0% |
| 2023 | Share of out-of-pocket dollars from the top 5% of people | 44.9% |
| 2023 | Largest annual out-of-pocket amount, class A | $7,399 |
| 2023 | Mean out-of-pocket spending excluding the domain top 1%, class A | $312 |
| 2023 | Largest annual out-of-pocket amount, class B | $3,556 |
| 2023 | Mean out-of-pocket spending excluding the domain top 1%, class B | $324 |
| 2023 | Largest annual out-of-pocket amount, class C | $43,928 |
| 2023 | Mean out-of-pocket spending excluding the domain top 1%, class C | $236 |

### Table S10. Exclusions and records outside the primary domain, 2024

Unweighted counts.

| Group | Unweighted n |
|---|---|
| Adults 18 to 64 with positive weight: diabetes reported no | 9,116 |
| Adults 18 to 64 with positive weight: diabetes question refused | 0 |
| Adults 18 to 64 with positive weight: diabetes don't know | 4 |
| Adults 18 to 64 with positive weight: diabetes inapplicable | 0 |
| Adults 18 to 64 with positive weight: other diabetes codes | 0 |
| Diabetes cohort not in scope on 12/31 | 6 |
| Diabetes cohort in scope on 12/31 without a year-end coverage value | 0 |
| In scope on 12/31 but not all year (described in Section S1.2) | 1 |
| In scope on 12/31 with reference period ending before December | 0 |

### Table S11. Source-to-analysis data dictionary, 2024

AHRQ source variables for each analysis variable and the transformation applied. The same mapping with 2023 variable names applies to the replication.

| Analysis variable | AHRQ source variables | Transformation | Reserved-code handling |
|---|---|---|---|
| person id | DUPERSID | Copied. Unique key; uniqueness asserted in build. | No reserved codes. |
| panel | PANEL | Copied. | None. |
| weight | PERWT24F | Copied. Full-year person weight. | Zero weight kept in the design frame, excluded from frames by pos_weight. |
| stratum | VARSTR | Copied. | None. |
| psu | VARPSU | Copied. Nested within stratum (nest = TRUE). | None. |
| age | AGE24X | Copied. Age on 12/31 of the data year. | −1 (not in scope 12/31) fails the 18 to 64 filter. |
| diabetes | DIABDX_M18 | 1 = ever told had diabetes (excluding gestational). | −7, −8, −1 are not 'no'; counted in cohort exclusions and excluded from the cohort. |
| inscope 1231 | INSC1231 | 1 = in scope on 12/31. | 2 = not in scope; excluded from frame Y. |
| end ref month | ENDRFM24 | Reference period end month. | Must equal 12 for domain C. |
| inscop r31 / inscop r42 / inscop yy | INSCOP31 / INSCOP42 / INSCOP24 | Round-level scope status. | Used only in the scope agreement audit, not as a filter. |
| ins 1231 | INS24X | Year-end coverage (covered on 12/31, or on the date the person left the RU). | −1 = not eligible on 12/31; excluded from frame Y. |
| ins dec | INSDE24X | Any coverage at any time in December. | −1 = out of scope in December. |
| any cov (month 1 to 12) | INSJA24X .. INSDE24X | Monthly any hospital/physician coverage (TRICARE/CHAMPVA, Medicare, Medicaid/CHIP, other public, private incl. Medigap, VA). IHS not counted. | −1 = out of scope that month: never counted as uninsured; defines scope. Other negative codes or nulls = missing. |
| private cov | PRIJA24 .. PRIDE24 | Monthly any private hospital/physician coverage. | −1 out of scope. |
| public cov | PUBJA24X .. PUBDE24X | Monthly any public coverage (TRICARE/CHAMPVA, Medicare, Medicaid/CHIP, other public, VA). | −1 out of scope. |
| medicare cov | MCRJA24X .. MCRDE24X | Monthly Medicare (edited). | −1 out of scope. |
| medicaid cov | MCDJA24X .. MCDDE24X | Monthly Medicaid/CHIP (edited). | −1 out of scope. |
| tricare cov | TRIJA24X .. TRIDE24X | Monthly TRICARE/CHAMPVA (edited). | −1 out of scope. |
| va cov | VAPJA24 .. VAPDE24 | Monthly VA coverage. | −1 out of scope. |
| other public cov | GVAJA24 .. GVADE24 | Monthly other public hospital/physician coverage (AHRQ: editing aid only). | −1 out of scope. |
| ihs cov | IHSJA24 .. IHSDE24 | Monthly Indian Health Service. Not counted as coverage by AHRQ. | −1 out of scope. |
| coverage state | INSJA24X .. INSDE24X / PRIJA24 .. PRIDE24 / PUBJA24X .. PUBDE24X | private_only, public_only, private_and_public, uninsured, not_in_scope, missing. | Out of scope and missing kept as their own states. |
| continuity class | INS24X / INSJA24X .. INSDE24X | inscont.continuity.classify_continuity rules 1 to 5. | Unobserved months make continuity indeterminate unless a gap is observed. |
| continuity class alt | INS24X / INSJA24X .. INSDE24X | As continuity_class, but a gap requires 3 or more consecutive uncovered months; 'insured_year_end_continuous' then means no such run. | As above. |
| n months uncovered | INSJA24X .. INSDE24X | Count of months with code 2. | Out-of-scope and missing months not counted. |
| unins year | UNINS24 | AHRQ annual indicator: uninsured all in-scope months. | None. |
| inscov year | INSCOV24 | AHRQ annual coverage indicator (TRICARE grouped with private). | None. |
| rx fills | RXTOT24 | Count of prescribed medicine fills and refills in the year. | No reserved codes expected; checked. |
| rx oop | RXSLF24 | Self/family prescription payments, nominal dollars of the data year. | Negative or null would be 'missing_expenditure' (none expected: AHRQ imputes). |
| rx total exp | RXEXP24 | Total prescription payments from all sources. | As above. |
| rx state | RXTOT24 / RXSLF24 | no_recorded_fill, fills_zero_oop, fills_positive_oop, missing_expenditure. | Keeps no-fill, zero-OOP, and missing distinct. |
| rx records fully imputed / partially imputed / complete pc | IMPFLAG [HC-254A] | Fill-level method of expenditure data creation, summed per person. | 2024 only; persons without fills get 0. |
| rx oop event sum | RXSF24X [HC-254A] | Sum of fill-level OOP per person. | 2024 only. |
| age group | AGE24X | 18-44, 45-64. | None in frame. |
| sex label | SEX | Male, Female. | None. |
| race eth4 | RACETHX | Hispanic; NH White; NH Black; NH Asian, other, or multiple (codes 4 and 5 combined). | None (edited/imputed by AHRQ). |
| income2 | POVCAT24 | Below 200% FPL (codes 1 to 3) versus 200% or more (codes 4 to 5). | None (imputed by AHRQ). |
| region label | REGION24 | Census region on 12/31. | −1 inapplicable. |
