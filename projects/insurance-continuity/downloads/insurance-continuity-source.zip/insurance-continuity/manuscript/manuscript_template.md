# Insured on December 31, Uninsured Earlier in the Year: Within-Year Coverage Gaps and Prescription Spending Among US Adults With Diabetes

## Abstract

**Background:** Annual spending analyses often classify insurance by year-end status, although people insured on December 31 may have been uninsured earlier that year.

**Objectives:** To estimate how many adults with diabetes insured at year end had a fully uninsured month that year, and how prescription summaries change when monthly continuity is retained.

**Research Design:** Cross-sectional, design-based analysis of the 2024 Medical Expenditure Panel Survey Full Year Consolidated file, replicated in 2023.

**Subjects:** {{ n_domain_c_2024 }} adults aged 18 to 64 with diagnosed diabetes, in scope all year ({{ w_domain_c_2024 }} people).

**Measures:** Coverage on December 31; monthly continuity classes; prescription fills; out-of-pocket prescription spending.

**Results:** Among {{ primary_n }} adults insured on December 31, {{ primary }} (95% CI, {{ primary_ci }}) had at least 1 uninsured month (about {{ wt_B }} people) and {{ alt3 }} had 3 or more consecutive uninsured months; the 2023 estimate was {{ primary_2023 }}. Compared with the continuously insured, those with a gap less often filled any prescription ({{ anyfill_B }} vs {{ anyfill_A }}) and had fewer fills ({{ fills_B }} vs {{ fills_A }}). Median out-of-pocket spending among users was similar ({{ med_B }} vs {{ med_A }}); lower mean spending with a gap ({{ oop_B }} vs {{ oop_A }}) partly reflected a few very large amounts among the continuously insured. Pooled year-end summaries changed little (mean {{ oop_ye }} vs {{ oop_A }}), and adjusted spending differences were imprecise and reversed direction between years.

**Conclusions:** About 1 in 12 adults with diabetes counted as insured at year end had a coverage gap that year. Adults with gaps reported lower prescription use, while pooled spending summaries changed little.

**Key Words:** health insurance; coverage continuity; diabetes mellitus; prescription drugs; Medical Expenditure Panel Survey

## Introduction

Surveys measure health insurance over different reference periods: on the interview date, on a fixed date such as December 31, at any time in a year, or in each month. Estimates of the uninsured depend heavily on that choice. In the Medical Expenditure Panel Survey (MEPS), 25.2% of people younger than 65 were uninsured at some point in 2011 but 14.5% for the entire year,[@chu2013] and in 2013 the corresponding figures were 27.1% and 15.6%.[@rhoades2015] Panel data show that point-in-time counts understate how many people experience a gap over time,[@short2012] and even within a single instrument a calendar-year question and a point-in-time question give different answers.[@pascale2016]

The reference period matters when coverage is used to group people for an analysis of annual outcomes. Annual prescription use and spending accumulate month by month, but a year-end indicator records only the last day. MEPS releases both kinds of measure, a December 31 indicator and monthly indicators for every source of coverage,[@hc256] so the size of the mismatch can be measured directly.

Coverage continuity is a particular concern for people with diabetes, whose treatment depends on regular refills. In community health centers, patients with diabetes churned more often than patients without diabetes,[@lester2025] and the share with hemoglobin A1c above 9.0% changed less favorably after churn than among matched patients without churn.[@huguet2026] In a 2015 survey of low-income adults in 3 states, coverage changes that included an uninsured gap were associated with skipping medications because of cost, while changes without a gap were not, although those were linked to other problems such as changing doctors.[@sommers2016] Among insulin users younger than 65 who were adequately insured, 14.3% rationed insulin because of cost.[@fang2023]

Earlier studies, many using MEPS, link part-year uninsurance to lower use of care. In 2016, 18.2% of adults aged 18 to 64 with at least 1 diagnosed chronic condition, a group that included diabetes, were uninsured for at least 1 month,[@keenan2019] compared with 7.8% uninsured all year.[@vistnes2019] In 2002 to 2004, about 40% of working-age adults with part-year uninsurance gained coverage and kept it through the end of the year, and adults with chronic conditions who had short gaps filled fewer prescriptions than those insured all year.[@gulley2011] MEPS monthly data have also been used to track part-year coverage and access[@abdus2014] and multiyear coverage patterns.[@gai2020] In 2021 to 2022, 25.3% of nonelderly adults in MEPS had a coverage discontinuity, and those with discontinuities were less likely than adults with continuous private coverage to receive any prescriptions.[@macarthur2026] Medicaid churning among low-income adults has also been compared before and after the Affordable Care Act.[@goldman2020] 

Two recent MEPS studies of diabetes costs and medication use classified coverage over the whole year. One treated only people uninsured all year as uninsured and assigned everyone else to the coverage type held longest,[@wang2021] and the other assigned the payer held for at least 7 months and excluded the uninsured,[@bepo2024] so within-year gaps sit inside the insured groups.

No study identified in a literature search (Supplemental Digital Content 1, Text, Section S1.8, search methods) reports the share of adults with diabetes who were insured on December 31 but uninsured earlier in the same year, or shows how annual prescription summaries change when those people are separated out. This study gives that estimate for 2024, the most recent MEPS full-year file, with a 2023 replication. It also provides a reusable classification of monthly coverage that keeps out-of-scope and missing months separate from uninsured months. This descriptive study measures what a year-end indicator omits for this population. It does not estimate the effects of coverage gaps.

## Methods

### Data

MEPS Household Component data, released by the Agency for Healthcare Research and Quality (AHRQ), come from a nationally representative panel survey of the US civilian noninstitutionalized population. The 2024 Full Year Consolidated file (HC-256, released August 2026) contains {{ n_records_2024 }} person records from Panel 28 rounds 3 to 5 and Panel 29 rounds 1 to 3, of whom {{ n_pos_weight_2024 }} have a positive full-year weight.[@hc256] Fill-level imputation flags came from the 2024 Prescribed Medicines file (HC-254A).[@hc254a] The replication used the 2023 file (HC-251).[@hc251] An analysis plan with prespecified estimands, denominators, and robustness checks was written and dated before any data were tabulated; the {{ n_amendments }} later amendments, none of which changed an estimand, are listed in Supplemental Digital Content 1, Text, Section S1.7 (amendments).

### Study Population

The population was adults aged 18 to 64 on December 31, 2024, who reported ever being told by a doctor or other health professional that they had diabetes, excluding gestational diabetes. Responses of refused or don't know were not treated as no. The primary domain required a positive person weight, scope on December 31, and scope in all 12 months. MEPS codes monthly coverage as inapplicable in months a person was outside the civilian noninstitutionalized population, so a month was in scope when it carried a coverage value. The person's 2024 reference period also had to end in December. Of the {{ n_frame_y_2024 }} adults with diabetes in scope on December 31, {{ n_domain_c_2024 }} met these conditions; the remaining person is described in Supplemental Digital Content 1, Text, Section S1.2 (scope rule).

### Coverage Measures

Year-end status was the MEPS indicator of coverage on December 31, 2024. Monthly coverage used the edited indicators of any hospital or physician coverage in each month from Medicare, Medicaid or the Children's Health Insurance Program, TRICARE or the Civilian Health and Medical Program of the Department of Veterans Affairs, Veterans Affairs care, other public programs, or private insurance including Medigap. Indian Health Service coverage alone is not counted as insurance. MEPS counts a month as covered if coverage applied on any day of it.[@hc256]

Each person was assigned to 1 of 4 classes: (A) insured on December 31 and in every month; (B) insured on December 31 with at least 1 uninsured month; (C) uninsured on December 31; and (D) indeterminate, when the year-end value was unusable, or when a person insured on December 31 had no observed uninsured month but at least 1 month without usable information. 

Missing and out-of-scope months were never counted as uninsured. Coverage from 2 sources in the same month counted once, and a change of coverage source without an uninsured month was not a gap; changes between private insurers cannot be identified in the public-use file. Uninsured months were counted within calendar year 2024, so a gap that began in 2023 counts only from January. The prespecified alternative definition required at least 3 consecutive uninsured months, following the statutory short coverage gap of less than 3 months.[@usc5000a]

Classification was implemented as a reusable function that accepts any set of monthly indicators and code lists and returns each person's class with an audit table of rule counts. Monthly data were reshaped into a person-month table with structured query language (SQL) queries and reconciled with the annual MEPS indicators on their documented definitions before use (Supplemental Digital Content 1, Text, Section S1.4, reconciliation checks).

### Prescription Measures

Outcomes were any prescription fill in 2024, the number of fills including refills, and self or family out-of-pocket payments for all prescribed medicines, in nominal 2024 dollars. These cover all prescriptions and the diabetic supplies recorded in the MEPS prescribed medicines component, not only glucose-lowering drugs. No recorded fill, fills with zero out-of-pocket payment, and missing expenditure were kept as separate states. Total payments from all sources gave context. MEPS imputes missing payments,[@hc256] so the share of fills with fully or partially imputed payments was summarized from fill-level flags.[@hc254a] Out-of-pocket spending describes payments made; it does not measure affordability, unmet need, or access to every prescribed treatment.

### Statistical Analysis

Estimates used {{ r_version_short }} (R Foundation for Statistical Computing, Vienna, Austria) with the survey package version {{ survey_version }},[@lumley2004] with Taylor series linearization, the full-year weight, variance strata, and primary sampling units. The full file stayed in the design and domains were taken as subsets, so variance estimation used all {{ n_strata }} strata and {{ n_psus }} primary sampling units in 2024 ({{ n_psus_2023 }} in 2023). No stratum had a single primary sampling unit in the full file. Proportions have logit-transformed 95% CIs. Proportions were flagged with the National Center for Health Statistics presentation standards using Korn-Graubard intervals;[@parker2017] estimates that met the standard but called for review (fewer than 8 design degrees of freedom, or a complementary proportion that would not meet it) are marked. 

Means and quantiles were flagged when the relative standard error exceeded 30% or could not be estimated, or when the group had fewer than 30 people. Medians and 90th percentiles used survey quantiles with Woodruff intervals.[@woodruff1952] Differences between classes in any fill, number of fills, and mean spending are design-based contrasts. A post hoc diagnostic described how concentrated out-of-pocket spending was.

Summaries are shown 2 ways: on a common denominator, the primary domain split by class, and on classification-specific denominators, year-end status among everyone in scope on December 31. This keeps differences in scope or missing information from being read as coverage effects.

A prespecified adjustment set (age group, sex, race and ethnicity, and family income below or above 200% of the federal poverty level) was used to standardize out-of-pocket spending across classes A, B, and C with a two-part model: a survey-weighted logistic model for any out-of-pocket spending and a gamma model with log link for positive amounts. Standardized means set every domain member to each class in turn. Uncertainty came from jackknife replicate weights built from the design ({{ model_replicates }} in 2024 and {{ model_replicates_2023 }} in 2023), refitting both parts in every replicate. The model was fit only if a prespecified rule on event counts, positive spending observations, and design degrees of freedom was met; it was met in both years. No stepwise selection was used, and the model is descriptive.

Three robustness checks were prespecified: a common complete-information domain, the 3-consecutive-month gap definition, and a replication in 2023 with definitions verified separately against that file's documentation. Years were not pooled and were not tested against each other, because Panel 28 contributes to both.

### Validation

Synthetic-record tests covered reshaping, overlapping coverage sources, missing and out-of-scope months, gaps before December coverage, source changes without gaps, expenditure states, and unchanged person counts. All {{ n_source_checks }} source reconciliation checks passed. In both years, the person-month table reproduced the annual MEPS uninsured and coverage indicators for every record, and weighted frequencies matched the AHRQ codebook. In 2024, fill counts and out-of-pocket sums from the prescribed medicines file matched every person's reported totals.

In {{ n_cross_checks }} software cross-checks, a separately written SQL classification agreed on class and uninsured-month counts for every record in both years. A separate Taylor variance calculation reproduced the primary estimate and its standard error. Rerunning the pipeline from cached files reproduced every numeric output.

I confirmed the AHRQ file checksums and recomputed cohort counts, class counts, and the primary proportion and standard error in a separate script. I also checked the monthly coverage sequences of 25 randomly sampled domain members against their assigned classes and checked every reported number against the outputs. I reread each cited study, in full text where available and as an abstract otherwise, to confirm the statements attributed to it.

### Ethics

This study was a secondary analysis of publicly available, deidentified MEPS public-use files released by AHRQ. No participants were recruited, there was no contact with survey respondents, and no identifiable private information was accessed. No institutional review board approval or exemption determination was sought.

## Results

The 2024 file contained {{ n_records_2024 }} records; {{ n_diabetes_2024 }} were adults aged 18 to 64 with a positive weight and diagnosed diabetes, and {{ n_domain_c_2024 }} formed the primary domain (Supplemental Digital Content 1, Figure S1, cohort flow). Monthly coverage had no missing values in the domain, so no one was classified as indeterminate. Table 1 shows characteristics by class.

### Year-End Status Versus Monthly Continuity

By the year-end indicator, {{ ye_insured_frame_y }} of adults with diabetes were insured (Figure 1). Monthly data split that group: {{ share_A }} of the domain were insured in every month (class A), {{ share_B }} were insured on December 31 after at least 1 uninsured month (class B), and {{ share_C }} were uninsured on December 31 (class C). Among the {{ primary_n }} adults insured on December 31, {{ primary_num }} had a gap, a weighted {{ primary }} (95% CI, {{ primary_ci }}; design effect {{ deff }}), or about {{ wt_B }} people. Under the 3-consecutive-month definition, the share was {{ alt3 }} (95% CI, {{ alt3_ci }}).

People in class B averaged {{ gap_mean_months }} uninsured months within 2024 (95% CI, {{ gap_mean_months_ci }}). About two thirds of class B ({{ gap_start_pattern }}; 95% CI, {{ gap_start_pattern_ci }}) were uninsured in January and insured from a later month through December; this subgroup estimate does not meet the presentation standard and describes timing only (Supplemental Digital Content 1, Figure S3, monthly uninsured shares in class B). Changes in the categories of coverage held, such as gaining or losing Medicaid or private coverage, without an uninsured month were also common: {{ switch_no_gap }} of class A had one (95% CI, {{ switch_no_gap_ci }}). In month-to-month transitions, {{ monthly_exit_uninsured }} of uninsured person-months were followed by a covered month.

### Prescription Use and Spending

Class B used fewer prescriptions than class A (Table 2, Figure 2). Any fill was less common in class B ({{ anyfill_B }} vs {{ anyfill_A }}; difference {{ d_anyfill_BA }}, 95% CI, {{ d_anyfill_BA_ci }}; the class B proportion is marked for review in Table 2), and class B had fewer fills ({{ fills_B }} vs {{ fills_A }}; difference {{ d_fills_BA }}, 95% CI, {{ d_fills_BA_ci }}). Unadjusted mean out-of-pocket spending including zeros was lower in class B ({{ oop_B }} vs {{ oop_A }}; difference {{ d_oop_BA }}, 95% CI, {{ d_oop_BA_ci }}), while median spending among users was similar ({{ med_B }} vs {{ med_A }}). The difference in means partly reflected a few very large amounts. In the post hoc diagnostic, the top 1% of the domain accounted for {{ top1_share }} of out-of-pocket dollars, and the largest annual amount, {{ max_oop_A }}, was in class A; excluding that top 1%, mean spending was {{ trim_A }} in class A and {{ trim_B }} in class B. Class C had the lowest use ({{ anyfill_C }} with any fill) and a mean of {{ oop_C }}, an estimate flagged as imprecise.

Because class B is small, the year-end insured group looked much like class A. Its mean out-of-pocket spending was {{ oop_ye }} versus {{ oop_A }} for class A, any fill {{ anyfill_ye }} versus {{ anyfill_A }}, and mean fills {{ fills_ye }} versus {{ fills_A }}. The classification-specific year-end summaries were nearly identical to the common-denominator ones because only 1 person was in scope on December 31 for part of the year.

Imputed payments were common in every class. Among users, {{ imp_any_A }} in class A and {{ imp_any_B }} in class B had at least 1 fill with fully or partially imputed payments; the class B estimate rests on fewer than 8 design degrees of freedom (Supplemental Digital Content 1, Table S6, imputation information).

### Adjusted Comparison and Robustness

After standardization, mean out-of-pocket spending was {{ sm_A }} in class A and {{ sm_B }} in class B (difference {{ sm_BA }}; 95% CI, {{ sm_BA_ci }}) (Table 3). In 2023 the difference was {{ sm_BA_2023 }} (95% CI, {{ sm_BA_2023_ci }}). The share of year-end insured adults with a gap was {{ primary_2023 }} in 2023 (95% CI, {{ primary_2023_ci }}), and {{ alt3_2023 }} under the 3-month definition. In 2023, class B again less often filled any prescription than class A (difference {{ d_anyfill_BA_2023 }}; 95% CI, {{ d_anyfill_BA_2023_ci }}), and the unadjusted mean spending difference was {{ d_oop_BA_2023 }} (95% CI, {{ d_oop_BA_2023_ci }}).

## Discussion

About 1 in 12 working-age adults with diabetes who were insured on December 31, 2024, had spent at least 1 full month of that year without coverage, and about 1 in 20 had a gap of 3 months or more. The estimate was nearly the same in 2023. People with a gap filled fewer prescriptions and were less likely to fill any. Their median out-of-pocket spending was similar to that of the continuously insured, and their lower mean spending in 2024 partly reflected a few very large amounts in the continuously insured group. Because they are a small share of the insured, separating them out barely changed pooled summaries for the year-end insured.

These results fit earlier MEPS evidence. The 2016 AHRQ estimates for adults with chronic conditions imply that roughly 10 percentage points were uninsured for part of the year but not all of it,[@keenan2019; @vistnes2019] and the 2024 estimate here isolates the part of such a group that a year-end indicator records as insured. Gulley and colleagues found that adults with chronic conditions who had short gaps filled fewer prescriptions,[@gulley2011] and class B showed a similar pattern in 2024. Wang and colleagues reported that limiting their public and private insurance groups to adults covered all year lowered the high out-of-pocket cost rate only slightly (within 1%) and did not change trends;[@wang2021] the comparison of pooled year-end summaries here points the same way for person-level prescription spending. Multiyear MEPS typologies and studies of Medicaid churning describe instability over longer windows or in specific programs;[@gai2020; @macarthur2026; @goldman2020; @roberts2016] none of them crosses year-end status with monthly continuity among adults with diabetes, which is the contrast reported here.

For analysts, the choice of coverage measure depends on the question. When the aim is to describe annual spending for insured adults with diabetes, a year-end indicator loses little, at least at the level of means and medians in 2024 and 2023. For questions about prescription use, a year-end indicator combines people who had a gap with those continuously insured. About 1 in 12 of the year-end insured had a gap in these data. The lower use in class B could reflect forgone or deferred care. Coverage gaps have been associated with skipping medications because of cost,[@sommers2016] adults who lost Medicaid deferred office-based care until they were insured again,[@roberts2016] and longer gaps have been followed by later cost-related barriers to care,[@cao2026] but these data cannot separate that from differences in health or need. Lower spending in a group with less use should not be read as better financial protection.[@cao2026]

The classification function can be reused in other analyses. An AHRQ MEPS workshop program counts uninsured months but treats people whose months are all out of scope as fully insured and does not anchor the count to year-end status.[@ahrqgithub] The function used here keeps out-of-scope and missing months apart from uninsured months, reports an explicit indeterminate class, and produces an audit table, so the same rules can be applied to other years, populations, or enrollment files.

### Limitations

Coverage is self-reported in interview rounds and edited by AHRQ. Estimates of coverage dynamics depend on the survey instrument,[@graves2016] and self-reported Medicaid enrollment may lag true enrollment.[@roberts2016] Monthly indicators count a month as covered if any day was covered, so gaps shorter than a month, or inside a partly covered month, are invisible, and the estimate is a lower bound on people with any uninsured day. Uninsured months were counted within the calendar year, so gaps that began in the previous year are truncated at January; the mean number of uninsured months and the 3-consecutive-month estimate are therefore lower bounds. The year-end indicator and the December monthly indicator come from the same interviews, so the contrast is between reference periods rather than independent measurements. 

Diabetes is self-reported ever-diagnosed. The prescription outcome covers all medicines, not only diabetes treatment, and includes imputed payments. Class B is small (n = {{ primary_num }}), many of its subgroup estimates are imprecise, and adjusted spending differences reversed direction between years. Out-of-pocket means were dominated by a few very large amounts. 

The cross-sectional design supports description only. Results apply to the US civilian noninstitutionalized population, not to institutionalized people.

### Conclusions

A year-end coverage indicator counts about 1 in 12 working-age adults with diabetes as insured even though they went without coverage for at least 1 month that year. Separating these groups revealed differences in prescription use while changing pooled spending summaries little in 2023 and 2024. Studies that stratify annual outcomes by coverage can retain monthly continuity with the classification provided here.
