# Supplemental Digital Content 1

Insured on December 31, Uninsured Earlier in the Year: Within-Year Coverage Gaps and Prescription Spending Among US Adults With Diabetes

## Section S1. Methods details

### S1.1 Data releases and verification

| Release | Role | Reference period | Release date | File checked |
|---|---|---|---|---|
{{ release_rows }}

Each file was streamed from the AHRQ site, checked for the expected content type and file signature (so an HTML error page could not pass as data), hashed with SHA-256, and extracted only for its expected archive member. Official detail pages for later public-use file numbers were checked on the access date, and none was a 2025 Full Year Consolidated file, so HC-256 was the newest compatible release. Release year, data reference period, and access date are recorded separately for each file.

### S1.2 Scope rule

A month was treated as in scope when the monthly any-coverage indicator held a substantive value (1 or 2). MEPS codes months outside a person's in-scope period as -1. The primary domain also required in-scope status on December 31 (INSC1231 = 1) and a 2024 reference period ending in December (ENDRFM24 = 12). {{ scope_agreement_sentence }} {{ part_year_desc }}

### S1.3 Classification rules

The function applies these rules to each person in order. (1) A missing or unrecognized year-end value gives class D. (2) Uninsured on December 31 gives class C. (3) Insured on December 31 with any month coded uninsured gives class B. (4) Insured on December 31, no month coded uninsured, but any month out of scope, missing, or unrecognized gives class D. (5) Otherwise class A. Under the alternative definition, class B requires a run of at least 3 consecutive uninsured months; people whose only gaps are shorter move to class A if every month is observed and to class D otherwise. Across the full 2024 file the rules assigned {{ rule_counts_2024 }}.

### S1.4 Reconciliation with AHRQ indicators

{{ recon_table }}

Informational counts are not errors. They record people whose December 31 coverage AHRQ captured on the date they left the household ({{ n_departure_2024 }} in 2024; none in the analytic domain), people covered at some time in December but not on December 31, and person-months with Indian Health Service coverage only, which AHRQ counts as uninsured.

### S1.5 Prescription expenditure states and imputation

{{ rx_state_table }}

### S1.6 Two-part model support and specification

The support rule required at least 80 people with the less common part-1 outcome, at least 80 people with positive out-of-pocket spending, at least 25 with positive spending in each class, and at least 30 design degrees of freedom. In 2024 the less common part-1 outcome had {{ part1_minority }} people and class B had {{ pos_B }} people with positive spending; in 2023 the figures were {{ part1_minority_2023 }} and {{ pos_B_2023 }}. Both parts were refit in each of {{ model_replicates }} (2024) and {{ model_replicates_2023 }} (2023) jackknife replicates, and every replicate fit converged. Weights were divided by their mean within each fit, which leaves estimates unchanged and avoids a known failure of the binomial starting values when weights are large.

### S1.7 Analysis plan amendments

The analysis plan was written and dated before any data were tabulated. All amendments were recorded on October 7, 2026. Amendments 1 to 4 are listed in the order made; amendments 5 to 8 were recorded after an internal review of the completed analysis, and each states when it was made relative to inspection of estimates. None changes the estimand, eligibility, classification rules, gap definitions, adjustment set, or robustness checks.

{{ amendments }}

### S1.8 Literature search methods

Searches were run on October 7, 2026, in PubMed through the National Center for Biotechnology Information E-utilities, with full text read in PubMed Central or publisher open-access copies where available; digital object identifiers were verified with the Crossref API. Official AHRQ MEPS publications (Statistical Briefs and Research Findings), the MEPS documentation, and the agency's public code repository were also searched, together with general web searches for official pages. Representative PubMed queries were: ("Medical Expenditure Panel Survey"[tiab] OR MEPS[tiab]) AND (churn*[tiab] OR "part-year"[tiab] OR "coverage disruption*"[tiab] OR discontinu*[tiab] OR "insurance gap*"[tiab] OR "coverage gap*"[tiab] OR "continuous coverage"[tiab]); (churn*[tiab] OR discontinu*[tiab] OR lapse*[tiab] OR gap*[tiab]) AND (insurance[tiab] OR Medicaid[tiab] OR coverage[tiab]) AND diabetes[tiab] AND (prescription*[tiab] OR medication*[tiab] OR expenditure*[tiab] OR "out-of-pocket"[tiab] OR cost*[tiab]); and (insurance coverage) AND (survey) AND ("reference period" OR "point-in-time") AND (uninsured). Studies, agency reports, and software were included if they measured coverage within a year or over time, or related coverage continuity to prescription use or spending, with priority to US data, MEPS, and diabetes. Three cited articles were available only as abstracts and are cited only for statements in their abstracts.

## Section S2. Supplementary figures and tables

{{ supp_figures }}

{{ supp_tables }}
