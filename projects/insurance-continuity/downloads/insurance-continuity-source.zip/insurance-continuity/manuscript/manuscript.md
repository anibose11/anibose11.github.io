# Insured on December 31, Uninsured Earlier in the Year: Within-Year Coverage Gaps and Prescription Spending Among US Adults With Diabetes

## Abstract

**Background:** Annual spending analyses often classify insurance by year-end status, although people insured on December 31 may have been uninsured earlier that year.

**Objectives:** To estimate how many adults with diabetes insured at year end had a fully uninsured month that year, and how prescription summaries change when monthly continuity is retained.

**Research Design:** Cross-sectional, design-based analysis of the 2024 Medical Expenditure Panel Survey Full Year Consolidated file, replicated in 2023.

**Subjects:** 1,001 adults aged 18 to 64 with diagnosed diabetes, in scope all year (16.6 million people).

**Measures:** Coverage on December 31; monthly continuity classes; prescription fills; out-of-pocket prescription spending.

**Results:** Among 885 adults insured on December 31, 8.5% (95% CI, 6.3% to 11.4%) had at least 1 uninsured month (about 1.24 million people) and 4.7% had 3 or more consecutive uninsured months; the 2023 estimate was 8.4%. Compared with the continuously insured, those with a gap less often filled any prescription (78.8% vs 92.6%) and had fewer fills (20.1 vs 30.4). Median out-of-pocket spending among users was similar ($154 vs $152); lower mean spending with a gap ($240 vs $642) partly reflected a few very large amounts among the continuously insured. Pooled year-end summaries changed little (mean $608 vs $642), and adjusted spending differences were imprecise and reversed direction between years.

**Conclusions:** About 1 in 12 adults with diabetes counted as insured at year end had a coverage gap that year. Adults with gaps reported lower prescription use, while pooled spending summaries changed little.

**Key Words:** health insurance; coverage continuity; diabetes mellitus; prescription drugs; Medical Expenditure Panel Survey

## Introduction

Surveys measure health insurance over different reference periods: on the interview date, on a fixed date such as December 31, at any time in a year, or in each month. Estimates of the uninsured depend heavily on that choice. In the Medical Expenditure Panel Survey (MEPS), 25.2% of people younger than 65 were uninsured at some point in 2011 but 14.5% for the entire year,<sup>1</sup> and in 2013 the corresponding figures were 27.1% and 15.6%.<sup>2</sup> Panel data show that point-in-time counts understate how many people experience a gap over time,<sup>3</sup> and even within a single instrument a calendar-year question and a point-in-time question give different answers.<sup>4</sup>

The reference period matters when coverage is used to group people for an analysis of annual outcomes. Annual prescription use and spending accumulate month by month, but a year-end indicator records only the last day. MEPS releases both kinds of measure, a December 31 indicator and monthly indicators for every source of coverage,<sup>5</sup> so the size of the mismatch can be measured directly.

Coverage continuity is a particular concern for people with diabetes, whose treatment depends on regular refills. In community health centers, patients with diabetes churned more often than patients without diabetes,<sup>6</sup> and the share with hemoglobin A1c above 9.0% changed less favorably after churn than among matched patients without churn.<sup>7</sup> In a 2015 survey of low-income adults in 3 states, coverage changes that included an uninsured gap were associated with skipping medications because of cost, while changes without a gap were not, although those were linked to other problems such as changing doctors.<sup>8</sup> Among insulin users younger than 65 who were adequately insured, 14.3% rationed insulin because of cost.<sup>9</sup>

Earlier studies, many using MEPS, link part-year uninsurance to lower use of care. In 2016, 18.2% of adults aged 18 to 64 with at least 1 diagnosed chronic condition, a group that included diabetes, were uninsured for at least 1 month,<sup>10</sup> compared with 7.8% uninsured all year.<sup>11</sup> In 2002 to 2004, about 40% of working-age adults with part-year uninsurance gained coverage and kept it through the end of the year, and adults with chronic conditions who had short gaps filled fewer prescriptions than those insured all year.<sup>12</sup> MEPS monthly data have also been used to track part-year coverage and access<sup>13</sup> and multiyear coverage patterns.<sup>14</sup> In 2021 to 2022, 25.3% of nonelderly adults in MEPS had a coverage discontinuity, and those with discontinuities were less likely than adults with continuous private coverage to receive any prescriptions.<sup>15</sup> Medicaid churning among low-income adults has also been compared before and after the Affordable Care Act.<sup>16</sup> 

Two recent MEPS studies of diabetes costs and medication use classified coverage over the whole year. One treated only people uninsured all year as uninsured and assigned everyone else to the coverage type held longest,<sup>17</sup> and the other assigned the payer held for at least 7 months and excluded the uninsured,<sup>18</sup> so within-year gaps sit inside the insured groups.

No study identified in a literature search (Supplemental Digital Content 1, Text, Section S1.8, search methods) reports the share of adults with diabetes who were insured on December 31 but uninsured earlier in the same year, or shows how annual prescription summaries change when those people are separated out. This study gives that estimate for 2024, the most recent MEPS full-year file, with a 2023 replication. It also provides a reusable classification of monthly coverage that keeps out-of-scope and missing months separate from uninsured months. This descriptive study measures what a year-end indicator omits for this population. It does not estimate the effects of coverage gaps.

## Methods

### Data

MEPS Household Component data, released by the Agency for Healthcare Research and Quality (AHRQ), come from a nationally representative panel survey of the US civilian noninstitutionalized population. The 2024 Full Year Consolidated file (HC-256, released August 2026) contains 19,140 person records from Panel 28 rounds 3 to 5 and Panel 29 rounds 1 to 3, of whom 18,683 have a positive full-year weight.<sup>5</sup> Fill-level imputation flags came from the 2024 Prescribed Medicines file (HC-254A).<sup>19</sup> The replication used the 2023 file (HC-251).<sup>20</sup> An analysis plan with prespecified estimands, denominators, and robustness checks was written and dated before any data were tabulated; the 8 later amendments, none of which changed an estimand, are listed in Supplemental Digital Content 1, Text, Section S1.7 (amendments).

### Study Population

The population was adults aged 18 to 64 on December 31, 2024, who reported ever being told by a doctor or other health professional that they had diabetes, excluding gestational diabetes. Responses of refused or don't know were not treated as no. The primary domain required a positive person weight, scope on December 31, and scope in all 12 months. MEPS codes monthly coverage as inapplicable in months a person was outside the civilian noninstitutionalized population, so a month was in scope when it carried a coverage value. The person's 2024 reference period also had to end in December. Of the 1,002 adults with diabetes in scope on December 31, 1,001 met these conditions; the remaining person is described in Supplemental Digital Content 1, Text, Section S1.2 (scope rule).

### Coverage Measures

Year-end status was the MEPS indicator of coverage on December 31, 2024. Monthly coverage used the edited indicators of any hospital or physician coverage in each month from Medicare, Medicaid or the Children's Health Insurance Program, TRICARE or the Civilian Health and Medical Program of the Department of Veterans Affairs, Veterans Affairs care, other public programs, or private insurance including Medigap. Indian Health Service coverage alone is not counted as insurance. MEPS counts a month as covered if coverage applied on any day of it.<sup>5</sup>

Each person was assigned to 1 of 4 classes: (A) insured on December 31 and in every month; (B) insured on December 31 with at least 1 uninsured month; (C) uninsured on December 31; and (D) indeterminate, when the year-end value was unusable, or when a person insured on December 31 had no observed uninsured month but at least 1 month without usable information. 

Missing and out-of-scope months were never counted as uninsured. Coverage from 2 sources in the same month counted once, and a change of coverage source without an uninsured month was not a gap; changes between private insurers cannot be identified in the public-use file. Uninsured months were counted within calendar year 2024, so a gap that began in 2023 counts only from January. The prespecified alternative definition required at least 3 consecutive uninsured months, following the statutory short coverage gap of less than 3 months.<sup>21</sup>

Classification was implemented as a reusable function that accepts any set of monthly indicators and code lists and returns each person's class with an audit table of rule counts. Monthly data were reshaped into a person-month table with structured query language (SQL) queries and reconciled with the annual MEPS indicators on their documented definitions before use (Supplemental Digital Content 1, Text, Section S1.4, reconciliation checks).

### Prescription Measures

Outcomes were any prescription fill in 2024, the number of fills including refills, and self or family out-of-pocket payments for all prescribed medicines, in nominal 2024 dollars. These cover all prescriptions and the diabetic supplies recorded in the MEPS prescribed medicines component, not only glucose-lowering drugs. No recorded fill, fills with zero out-of-pocket payment, and missing expenditure were kept as separate states. Total payments from all sources gave context. MEPS imputes missing payments,<sup>5</sup> so the share of fills with fully or partially imputed payments was summarized from fill-level flags.<sup>19</sup> Out-of-pocket spending describes payments made; it does not measure affordability, unmet need, or access to every prescribed treatment.

### Statistical Analysis

Estimates used R version 4.5.1 (R Foundation for Statistical Computing, Vienna, Austria) with the survey package version 4.5,<sup>22</sup> with Taylor series linearization, the full-year weight, variance strata, and primary sampling units. The full file stayed in the design and domains were taken as subsets, so variance estimation used all 105 strata and 264 primary sampling units in 2024 (262 in 2023). No stratum had a single primary sampling unit in the full file. Proportions have logit-transformed 95% confidence intervals (CIs). Proportions were flagged with the National Center for Health Statistics presentation standards using Korn-Graubard intervals<sup>23</sup>; estimates that met the standard but called for review (fewer than 8 design degrees of freedom, or a complementary proportion that would not meet it) are marked. 

Means and quantiles were flagged when the relative standard error exceeded 30% or could not be estimated, or when the group had fewer than 30 people. Medians and 90th percentiles used survey quantiles with Woodruff intervals.<sup>24</sup> Differences between classes in any fill, number of fills, and mean spending are design-based contrasts. A post hoc diagnostic described how concentrated out-of-pocket spending was.

Summaries are shown 2 ways: on a common denominator, the primary domain split by class, and on classification-specific denominators, year-end status among everyone in scope on December 31. This keeps differences in scope or missing information from being read as coverage effects.

A prespecified adjustment set (age group, sex, race and ethnicity, and family income below or above 200% of the federal poverty level) was used to standardize out-of-pocket spending across classes A, B, and C with a two-part model: a survey-weighted logistic model for any out-of-pocket spending and a gamma model with log link for positive amounts. Standardized means set every domain member to each class in turn. Uncertainty came from jackknife replicate weights built from the design (264 in 2024 and 262 in 2023), refitting both parts in every replicate. The model was fit only if a prespecified rule on event counts, positive spending observations, and design degrees of freedom was met; it was met in both years. No stepwise selection was used, and the model is descriptive.

Three robustness checks were prespecified: a common complete-information domain, the 3-consecutive-month gap definition, and a replication in 2023 with definitions verified separately against that file's documentation. Years were not pooled and were not tested against each other, because Panel 28 contributes to both.

### Validation

Synthetic-record tests covered reshaping, overlapping coverage sources, missing and out-of-scope months, gaps before December coverage, source changes without gaps, expenditure states, and unchanged person counts. All 28 source reconciliation checks passed. In both years, the person-month table reproduced the annual MEPS uninsured and coverage indicators for every record, and weighted frequencies matched the AHRQ codebook. In 2024, fill counts and out-of-pocket sums from the prescribed medicines file matched every person's reported totals.

In 4 software cross-checks, a separately written SQL classification agreed on class and uninsured-month counts for every record in both years. A separate Taylor variance calculation reproduced the primary estimate and its standard error. Rerunning the pipeline from cached files reproduced every numeric output.

I confirmed the AHRQ file checksums and recomputed cohort counts, class counts, and the primary proportion and standard error in a separate script. I also checked the monthly coverage sequences of 25 randomly sampled domain members against their assigned classes and checked every reported number against the outputs. I reread each cited study, in full text where available and as an abstract otherwise, to confirm the statements attributed to it.

### Ethics

This study was a secondary analysis of publicly available, deidentified MEPS public-use files released by AHRQ. No participants were recruited, there was no contact with survey respondents, and no identifiable private information was accessed. No institutional review board approval or exemption determination was sought.

## Results

The 2024 file contained 19,140 records; 1,008 were adults aged 18 to 64 with a positive weight and diagnosed diabetes, and 1,001 formed the primary domain (Supplemental Digital Content 1, Figure S1, cohort flow). Monthly coverage had no missing values in the domain, so no one was classified as indeterminate. Table 1 shows characteristics by class.

### Year-End Status Versus Monthly Continuity

By the year-end indicator, 87.9% of adults with diabetes were insured (Figure 1). Monthly data split that group: 80.4% of the domain were insured in every month (class A), 7.5% were insured on December 31 after at least 1 uninsured month (class B), and 12.1% were uninsured on December 31 (class C). Among the 885 adults insured on December 31, 70 had a gap, a weighted 8.5% (95% CI, 6.3% to 11.4%; design effect 1.84), or about 1.24 million people. Under the 3-consecutive-month definition, the share was 4.7% (95% CI, 3.2% to 7.0%).

People in class B averaged 3.8 uninsured months within 2024 (95% CI, 3.0 to 4.7). About two thirds of class B (63.7%; 95% CI, 45.4% to 78.7%) were uninsured in January and insured from a later month through December; this subgroup estimate does not meet the presentation standard and describes timing only (Supplemental Digital Content 1, Figure S3, monthly uninsured shares in class B). Changes in the categories of coverage held, such as gaining or losing Medicaid or private coverage, without an uninsured month were also common: 10.4% of class A had one (95% CI, 8.2% to 13.0%). In month-to-month transitions, 6.6% of uninsured person-months were followed by a covered month.

### Prescription Use and Spending

Class B used fewer prescriptions than class A (Table 2, Figure 2). Any fill was less common in class B (78.8% vs 92.6%; difference −13.8 percentage points, 95% CI, −26.4 to −1.2; the class B proportion is marked for review in Table 2), and class B had fewer fills (20.1 vs 30.4; difference −10.3, 95% CI, −17.4 to −3.2). Unadjusted mean out-of-pocket spending including zeros was lower in class B ($240 vs $642; difference −$403, 95% CI, −$802 to −$4), while median spending among users was similar ($154 vs $152). The difference in means partly reflected a few very large amounts. In the post hoc diagnostic, the top 1% of the domain accounted for 42% of out-of-pocket dollars, and the largest annual amount, $91,626, was in class A; excluding that top 1%, mean spending was $383 in class A and $240 in class B. Class C had the lowest use (73.1% with any fill) and a mean of $845, an estimate flagged as imprecise.

Because class B is small, the year-end insured group looked much like class A. Its mean out-of-pocket spending was $608 versus $642 for class A, any fill 91.4% versus 92.6%, and mean fills 29.5 versus 30.4. The classification-specific year-end summaries were nearly identical to the common-denominator ones because only 1 person was in scope on December 31 for part of the year.

Imputed payments were common in every class. Among users, 90.1% in class A and 90.1% in class B had at least 1 fill with fully or partially imputed payments; the class B estimate rests on fewer than 8 design degrees of freedom (Supplemental Digital Content 1, Table S6, imputation information).

### Adjusted Comparison and Robustness

After standardization, mean out-of-pocket spending was $590 in class A and $352 in class B (difference −$238; 95% CI, −$536 to $59) (Table 3). In 2023 the difference was $105 (95% CI, −$215 to $425). The share of year-end insured adults with a gap was 8.4% in 2023 (95% CI, 6.3% to 11.3%), and 3.9% under the 3-month definition. In 2023, class B again less often filled any prescription than class A (difference −10.0 percentage points; 95% CI, −19.4 to −0.5), and the unadjusted mean spending difference was −$21 (95% CI, −$217 to $176).

## Discussion

About 1 in 12 working-age adults with diabetes who were insured on December 31, 2024, had spent at least 1 full month of that year without coverage, and about 1 in 20 had a gap of 3 months or more. The estimate was nearly the same in 2023. People with a gap filled fewer prescriptions and were less likely to fill any. Their median out-of-pocket spending was similar to that of the continuously insured, and their lower mean spending in 2024 partly reflected a few very large amounts in the continuously insured group. Because they are a small share of the insured, separating them out barely changed pooled summaries for the year-end insured.

These results fit earlier MEPS evidence. The 2016 AHRQ estimates for adults with chronic conditions imply that roughly 10 percentage points were uninsured for part of the year but not all of it,<sup>10,11</sup> and the 2024 estimate here isolates the part of such a group that a year-end indicator records as insured. Gulley and colleagues found that adults with chronic conditions who had short gaps filled fewer prescriptions,<sup>12</sup> and class B showed a similar pattern in 2024. Wang and colleagues reported that limiting their public and private insurance groups to adults covered all year lowered the high out-of-pocket cost rate only slightly (within 1%) and did not change trends<sup>17</sup>; the comparison of pooled year-end summaries here points the same way for person-level prescription spending. Multiyear MEPS typologies and studies of Medicaid churning describe instability over longer windows or in specific programs<sup>14-16,25</sup>; none of them crosses year-end status with monthly continuity among adults with diabetes, which is the contrast reported here.

For analysts, the choice of coverage measure depends on the question. When the aim is to describe annual spending for insured adults with diabetes, a year-end indicator loses little, at least at the level of means and medians in 2024 and 2023. For questions about prescription use, a year-end indicator combines people who had a gap with those continuously insured. About 1 in 12 of the year-end insured had a gap in these data. The lower use in class B could reflect forgone or deferred care. Coverage gaps have been associated with skipping medications because of cost,<sup>8</sup> adults who lost Medicaid deferred office-based care until they were insured again,<sup>25</sup> and longer gaps have been followed by later cost-related barriers to care,<sup>26</sup> but these data cannot separate that from differences in health or need. Lower spending in a group with less use should not be read as better financial protection.<sup>26</sup>

The classification function can be reused in other analyses. An AHRQ MEPS workshop program counts uninsured months but treats people whose months are all out of scope as fully insured and does not anchor the count to year-end status.<sup>27</sup> The function used here keeps out-of-scope and missing months apart from uninsured months, reports an explicit indeterminate class, and produces an audit table, so the same rules can be applied to other years, populations, or enrollment files.

### Limitations

Coverage is self-reported in interview rounds and edited by AHRQ. Estimates of coverage dynamics depend on the survey instrument,<sup>28</sup> and self-reported Medicaid enrollment may lag true enrollment.<sup>25</sup> Monthly indicators count a month as covered if any day was covered, so gaps shorter than a month, or inside a partly covered month, are invisible, and the estimate is a lower bound on people with any uninsured day. Uninsured months were counted within the calendar year, so gaps that began in the previous year are truncated at January; the mean number of uninsured months and the 3-consecutive-month estimate are therefore lower bounds. The year-end indicator and the December monthly indicator come from the same interviews, so the contrast is between reference periods rather than independent measurements. 

Diabetes is self-reported ever-diagnosed. The prescription outcome covers all medicines, not only diabetes treatment, and includes imputed payments. Class B is small (n = 70), many of its subgroup estimates are imprecise, and adjusted spending differences reversed direction between years. Out-of-pocket means were dominated by a few very large amounts. 

The cross-sectional design supports description only. Results apply to the US civilian noninstitutionalized population, not to institutionalized people.

### Conclusions

A year-end coverage indicator counts about 1 in 12 working-age adults with diabetes as insured even though they went without coverage for at least 1 month that year. Separating these groups revealed differences in prescription use while changing pooled spending summaries little in 2023 and 2024. Studies that stratify annual outcomes by coverage can retain monthly continuity with the classification provided here.

## References

1. Chu MC. *The Uninsured in America, 1996-2012: Estimates for the U.S. Civilian Noninstitutionalized Population under Age 65*. Statistical Brief #420. Agency for Healthcare Research and Quality; August 2013. Accessed October 7, 2026. https://meps.ahrq.gov/data_files/publications/st420/stat420.pdf
2. Rhoades JA. *Spells of Uninsurance: Estimates for the U.S. Civilian Noninstitutionalized Population under Age 65, 2013*. Statistical Brief #476. Agency for Healthcare Research and Quality; June 2015. Accessed October 7, 2026. https://meps.ahrq.gov/data_files/publications/st476/stat476.pdf
3. Short PF, Graefe DR, Swartz K, et al. New estimates of gaps and transitions in health insurance. *Med Care Res Rev*. 2012;69(6):721-736. doi:10.1177/1077558712454195
4. Pascale J, Boudreaux M, King R. Understanding the new Current Population Survey health insurance questions. *Health Serv Res*. 2016;51(1):240-261. doi:10.1111/1475-6773.12312
5. Agency for Healthcare Research and Quality. *MEPS HC-256: 2024 Full Year Consolidated Data File*. Agency for Healthcare Research and Quality; August 2026. Accessed October 7, 2026. https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-256
6. Lester L, Dinh D, Larson AE, et al. Insurance instability among community-based health center patients with diabetes post-Affordable Care Act Medicaid expansion. *J Am Board Fam Med*. 2025;38(1):154-164. doi:10.3122/jabfm.2024.240186R1
7. Huguet N, Dinh D, Larson A, et al. Insurance churn and diabetes outcomes among patients with low income. *JAMA Health Forum*. 2026;7(3):e260034. doi:10.1001/jamahealthforum.2026.0034
8. Sommers BD, Gourevitch R, Maylone B, et al. Insurance churning rates for low-income adults under health reform: lower than expected but still harmful for many. *Health Aff (Millwood)*. 2016;35(10):1816-1824. doi:10.1377/hlthaff.2016.0455
9. Fang M, Selvin E. Cost-related insulin rationing in US adults younger than 65 years with diabetes. *JAMA*. 2023;329(19):1700-1702. doi:10.1001/jama.2023.5747
10. Keenan PS, Vistnes J. *Non-Elderly Adults Ever Uninsured During the Calendar Year, 2013-2016*. Research Findings #42. Agency for Healthcare Research and Quality; June 2019. Accessed October 7, 2026. https://meps.ahrq.gov/data_files/publications/rf42/rf42.pdf
11. Vistnes J, Keenan P. *Uninsured All Year, 2013-2016: Estimates for Non-Elderly Adults by Selected Population Sub-groups and State Medicaid Expansion Status*. Research Findings #40. Agency for Healthcare Research and Quality; January 2019. Accessed October 7, 2026. https://meps.ahrq.gov/data_files/publications/rf40/rf40.pdf
12. Gulley SP, Rasch EK, Chan L. Ongoing coverage for ongoing care: access, utilization, and out-of-pocket spending among uninsured working-aged adults with chronic health care needs. *Am J Public Health*. 2011;101(2):368-375. doi:10.2105/AJPH.2010.191569
13. Abdus S. Part-year coverage and access to care for nonelderly adults. *Med Care*. 2014;52(8):709-714. doi:10.1097/MLR.0000000000000167
14. Gai Y, Jones K. Insurance patterns and instability from 2006 to 2016. *BMC Health Serv Res*. 2020;20(1):334. doi:10.1186/s12913-020-05226-1
15. Mac Arthur NS, Abraham JM, Drew JAR, et al. Insurance coverage disruptions and associated access and utilization, 2008 to 2022. *Med Care Res Rev*. Published online October 1, 2026. doi:10.1177/10775587261484437
16. Goldman AL, Sommers BD. Among low-income adults enrolled in Medicaid, churning decreased after the Affordable Care Act. *Health Aff (Millwood)*. 2020;39(1):85-93. doi:10.1377/hlthaff.2019.00378
17. Wang Y, Park J, Li R, et al. National trends in out-of-pocket costs among U.S. adults with diabetes aged 18–64 years: 2001–2017. *Diabetes Care*. 2021;44(11):2510-2517. doi:10.2337/dc20-2833
18. Bepo L, Nguyen OK, Makam AN. Disparities in use of novel diabetes medications by insurance: a nationally representative cohort study. *J Gen Intern Med*. 2024;39(15):2987-2994. doi:10.1007/s11606-024-08961-x
19. Agency for Healthcare Research and Quality. *MEPS HC-254A: 2024 Prescribed Medicines File*. Agency for Healthcare Research and Quality; July 2026. Accessed October 7, 2026. https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-254A
20. Agency for Healthcare Research and Quality. *MEPS HC-251: 2023 Full Year Consolidated Data File*. Agency for Healthcare Research and Quality; August 2025. Accessed October 7, 2026. https://meps.ahrq.gov/mepsweb/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-251
21. Requirement to maintain minimum essential coverage, 26 USC §5000A(e)(4) (2018). Accessed October 7, 2026. https://www.law.cornell.edu/uscode/text/26/5000A
22. Lumley T. Analysis of complex survey samples. *J Stat Softw*. 2004;9(8):1-19. doi:10.18637/jss.v009.i08
23. Parker JD, Talih M, Malec DJ, et al. National Center for Health Statistics data presentation standards for proportions. *Vital Health Stat 2*. 2017;(175):1-22. Accessed October 7, 2026. https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf
24. Woodruff RS. Confidence intervals for medians and other position measures. *J Am Stat Assoc*. 1952;47(260):635-646. doi:10.1080/01621459.1952.10483443
25. Roberts ET, Pollack CE. Does churning in Medicaid affect health care use? *Med Care*. 2016;54(5):483-489. doi:10.1097/MLR.0000000000000509
26. Cao Y, Liu Z, Jiang M, et al. Duration of health insurance coverage gaps and subsequent cost-related barriers to care among adults aged 18–64 years with multimorbidity. *Front Public Health*. 2026;14:1965839. doi:10.3389/fpubh.2026.1965839
27. Agency for Healthcare Research and Quality. HHS-AHRQ/MEPS workshop exercise 5b (SAS and Stata) [computer program]. GitHub repository, commit 02fbdd634959e97bd3584c3e9abdc62f84291d70; June 9, 2026. Accessed October 7, 2026. https://github.com/HHS-AHRQ/MEPS
28. Graves JA, Mishra P. Health insurance dynamics: methodological considerations and a comparison of estimates from two surveys. *Health Serv Res*. 2016;51(5):1981-2001. doi:10.1111/1475-6773.12449

## Tables

### Table 1. Characteristics of adults aged 18 to 64 with diagnosed diabetes, by coverage continuity class, MEPS 2024

Weighted percentages (95% CI, logit). CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey. Primary domain: in scope all 12 months. Class A, insured on December 31 and in all 12 months; class B, insured on December 31 with at least 1 uninsured month; class C, uninsured on December 31. † Does not meet the National Center for Health Statistics presentation standard for proportions.

| Characteristic | All | A. Insured all 12 months | B. Insured 12/31, gap | C. Uninsured 12/31 |
|---|---|---|---|---|
| Unweighted n | 1,001 | 815 | 70 | 116 |
| **Age, y** |  |  |  |  |
| &nbsp;&nbsp;18-44 | 26.0 (22.6 to 29.8) | 24.9 (21.3 to 29.0) | 28.8 (14.7 to 48.8) † | 31.7 (20.5 to 45.5) |
| &nbsp;&nbsp;45-64 | 74.0 (70.2 to 77.4) | 75.1 (71.0 to 78.7) | 71.2 (51.2 to 85.3) † | 68.3 (54.5 to 79.5) |
| **Sex** |  |  |  |  |
| &nbsp;&nbsp;Female | 49.3 (46.0 to 52.6) | 49.6 (46.0 to 53.3) | 56.6 (41.6 to 70.5) † | 42.6 (31.7 to 54.2) |
| &nbsp;&nbsp;Male | 50.7 (47.4 to 54.0) | 50.4 (46.7 to 54.0) | 43.4 (29.5 to 58.4) † | 57.4 (45.8 to 68.3) |
| **Race and ethnicity** |  |  |  |  |
| &nbsp;&nbsp;Hispanic | 22.6 (18.8 to 26.9) | 19.4 (15.7 to 23.7) | 26.2 (13.5 to 44.7) † | 41.8 (30.1 to 54.4) |
| &nbsp;&nbsp;Non-Hispanic Black | 15.9 (13.0 to 19.4) | 16.8 (13.6 to 20.5) | 10.5 (4.7 to 21.7) † | 13.8 (7.1 to 25.2) † |
| &nbsp;&nbsp;Non-Hispanic White | 49.6 (45.1 to 54.1) | 52.4 (47.7 to 57.1) | 51.5 (35.3 to 67.4) † | 29.6 (18.3 to 44.1) |
| &nbsp;&nbsp;Non-Hispanic Asian, other, or multiple | 11.9 (9.3 to 15.0) | 11.4 (8.8 to 14.6) | 11.8 (4.5 to 27.8) † | 14.8 (7.4 to 27.4) † |
| **Family income** |  |  |  |  |
| &nbsp;&nbsp;Below 200% of the federal poverty level | 33.5 (29.9 to 37.4) | 33.8 (29.7 to 38.1) | 36.7 (23.8 to 51.8) | 30.1 (20.3 to 42.1) |
| &nbsp;&nbsp;200% of the federal poverty level or more | 66.5 (62.6 to 70.1) | 66.2 (61.9 to 70.3) | 63.3 (48.2 to 76.2) | 69.9 (57.9 to 79.7) |
| **Census region** |  |  |  |  |
| &nbsp;&nbsp;Northeast | 14.9 (12.2 to 18.0) | 13.7 (10.9 to 17.0) | 19.4 (8.6 to 38.2) † | 20.0 (9.7 to 36.8) † |
| &nbsp;&nbsp;Midwest | 19.2 (16.2 to 22.5) | 21.4 (17.9 to 25.4) | 12.5 (4.5 to 30.4) † | 8.5 (3.7 to 18.4) † |
| &nbsp;&nbsp;South | 43.1 (38.9 to 47.4) | 42.7 (37.9 to 47.6) | 41.1 (26.2 to 57.8) † | 47.2 (32.9 to 61.9) † |
| &nbsp;&nbsp;West | 22.8 (19.2 to 26.9) | 22.2 (18.1 to 27.1) | 27.0 (15.0 to 43.7) † | 24.3 (13.5 to 39.8) |

### Table 2. Annual prescription use and out-of-pocket spending by coverage representation, MEPS 2024

Estimates (95% CI). CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey; OOP, out-of-pocket (self or family payments for all prescribed medicines, nominal 2024 dollars); Rx, prescription. The first 4 columns share the primary-domain denominator; the last column uses the classification-specific denominator (everyone in scope on December 31, including part-year in scope). Class definitions as in Table 1. Medians and 90th percentiles use Woodruff intervals. † Does not meet the National Center for Health Statistics (NCHS) presentation standard for proportions. ‡ Relative standard error above 30% or not estimable, or fewer than 30 people. § Meets the NCHS standard but calls for review (fewer than 8 design degrees of freedom, or the complementary proportion would not meet it).

| Measure | Insured on 12/31 (A+B) | A. All 12 months | B. 12/31 with gap | C. Uninsured 12/31 | Insured on 12/31, classification-specific |
|---|---|---|---|---|---|
| Unweighted n | 885 | 815 | 70 | 116 | 886 |
| Any fill, % | 91.4 (88.6 to 93.5) | 92.6 (89.6 to 94.8) | 78.8 (61.6 to 89.6) § | 73.1 (60.1 to 83.0) | 91.3 (88.5 to 93.4) |
| Fills per person, mean | 29.5 (27.3 to 31.8) | 30.4 (27.9 to 32.9) | 20.1 (12.9 to 27.3) | 13.7 (8.7 to 18.7) | 29.5 (27.2 to 31.7) |
| OOP spending, mean incl. zeros, $ | $608 ($260 to $956) | $642 ($263 to $1,022) | $240 ($99 to $380) | $845 ($139 to $1,551) ‡ | $607 ($260 to $955) |
| OOP spending among users, mean, $ | $665 ($282 to $1,048) | $694 ($281 to $1,107) ‡ | $304 ($115 to $494) | $1,157 ($152 to $2,161) ‡ | $665 ($282 to $1,048) |
| OOP spending among users, median, $ | $154 ($133 to $181) | $152 ($133 to $186) | $154 ($42 to $248) | $131 ($90 to $249) | $154 ($133 to $181) |
| OOP spending among users, 90th percentile, $ | $1,167 ($940 to $1,436) | $1,183 ($954 to $1,460) | $607 ($461 to $3,268) ‡ | $3,262 ($686 to not estimable) ‡ | $1,167 ($940 to $1,436) |
| Users with $0 OOP, % | 14.1 (11.4 to 17.3) | 14.2 (11.4 to 17.5) | 13.2 (5.0 to 30.7) † | 2.8 (0.8 to 9.0) † | 14.1 (11.4 to 17.3) |
| Total Rx expenditure, mean, $ | $8,261 ($6,987 to $9,535) | $8,657 ($7,286 to $10,029) | $4,018 ($2,102 to $5,933) | $1,931 ($869 to $2,993) | $8,251 ($6,978 to $9,524) |

### Table 3. Robustness of the primary estimate and standardized out-of-pocket spending, MEPS 2024 and 2023

CI indicates confidence interval; MEPS, Medical Expenditure Panel Survey; OOP, out-of-pocket. Proportions use logit 95% CIs with the unweighted numerator and denominator. Standardized means come from a survey-weighted two-part model adjusted for age group, sex, race and ethnicity, and family income, with jackknife replicate CIs. Class A, insured on December 31 and in all 12 months; class B, insured on December 31 with at least 1 uninsured month; class C, uninsured on December 31. Years are estimated separately and not pooled.

| Year | Quantity | Estimate (95% CI) | Unweighted n or variance basis |
|---|---|---|---|
| 2024 | Share of year-end insured with a gap (≥1 uninsured month), % | 8.5 (6.3 to 11.4) | 70/885 |
| 2024 | Share of year-end insured with a gap (≥3 consecutive uninsured months), % | 4.7 (3.2 to 7.0) | 39/885 |
| 2023 | Share of year-end insured with a gap (≥1 uninsured month), % | 8.4 (6.3 to 11.3) | 63/860 |
| 2023 | Share of year-end insured with a gap (≥3 consecutive uninsured months), % | 3.9 (2.6 to 5.9) | 33/860 |
| 2024 | Standardized mean OOP, class A, $ | $590 ($293 to $887) | 264 jackknife replicates |
| 2024 | Standardized mean OOP, class B, $ | $352 ($110 to $594) | 264 jackknife replicates |
| 2024 | Standardized mean OOP, class C, $ | $1,182 ($124 to $2,239) | 264 jackknife replicates |
| 2024 | Standardized difference, B minus A, $ | −$238 (−$536 to $59) | 264 jackknife replicates |
| 2024 | Standardized difference, C minus A, $ | $592 (−$414 to $1,598) | 264 jackknife replicates |
| 2023 | Standardized mean OOP, class A, $ | $338 ($285 to $391) | 262 jackknife replicates |
| 2023 | Standardized mean OOP, class B, $ | $443 ($129 to $758) | 262 jackknife replicates |
| 2023 | Standardized mean OOP, class C, $ | $784 ($131 to $1,437) | 262 jackknife replicates |
| 2023 | Standardized difference, B minus A, $ | $105 (−$215 to $425) | 262 jackknife replicates |
| 2023 | Standardized difference, C minus A, $ | $446 (−$205 to $1,097) | 262 jackknife replicates |

## Figure legends

**Figure 1.** The same adults classified by year-end coverage (left) and by monthly continuity (right), Medical Expenditure Panel Survey 2024. Bar heights are weighted shares of adults aged 18 to 64 with diagnosed diabetes in scope all year; labels on the right bar give unweighted counts.

**Figure 2.** Annual out-of-pocket prescription spending by continuity class, Medical Expenditure Panel Survey 2024. Points are design-based estimates and lines are 95% confidence intervals; medians use Woodruff intervals. Group sizes are unweighted; user subgroups are smaller. * Relative standard error above 30% or not estimable, or fewer than 30 people.

![Figure 1](../outputs/figures/fig1_yearend_vs_continuity_2024.png)

![Figure 2](../outputs/figures/fig2_oop_spending_2024.png)
