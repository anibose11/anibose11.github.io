# Journal fit

Checked 2026-10-07 from official pages where they could be opened. Nothing was submitted. No impact factors, acceptance rates, deadlines, or reviewer interest were used or inferred.

## Target: Medical Care (Wolters Kluwer; Medical Care Section, American Public Health Association)

**Source read:** the journal's Instructions for Authors on its Editorial Manager site (https://edmgr.ovid.com/mdc/accounts/ifauth.htm). The journals.lww.com instructions page was behind a Cloudflare human check, which was not attempted.

**Scope and article type.** The journal covers the planning, organization, financing, provision, and evaluation of health services, and explicitly invites manuscripts on health services research methods. The manuscript is formatted as an Original Research Article: up to 3,500 words excluding abstract, acknowledgments, tables, figures, and references; up to 5 tables and figures combined; 6 to 50 references; a structured abstract of 250 words or fewer (Background, Objectives, Research Design, Subjects, Measures, Results, Conclusions); 3 to 5 key words; AMA style; a blinded manuscript with a separate unblinded title page that gives funding, conflicts of interest for the past 3 years, and word, table, and reference counts; a cover letter confirming ICMJE authorship; and documented IRB status. Applied Methods (about 4,000 words, online only) is an alternative route if the reusable classification becomes the headline.

**Charges.** No mandatory charge. Open access is optional (hybrid); the optional APC is listed on a Wolters Kluwer page that could not be opened, so its amount is not verified.

**Closest published comparisons in the journal.**
- Abdus S. Part-year coverage and access to care for nonelderly adults. Med Care. 2014;52(8):709-714. doi:10.1097/MLR.0000000000000167. MEPS 2005-2010, months without coverage grouped 0, 1-5, 6-11, 12, related to access measures (abstract read).
- Roberts ET, Pollack CE. Does churning in Medicaid affect health care use? Med Care. 2016;54(5):483-489. doi:10.1097/MLR.0000000000000509. Longitudinal MEPS panels, monthly Medicaid enrollment, difference-in-differences on visits (full text read).

**Fit.** The manuscript's main text, 5 exhibits, and references sit inside the Original Research limits. Editors and reviewers have published the nearest MEPS part-year and churning work, so the distinction between a year-end indicator and monthly continuity will be familiar.

**Remaining scientific objections a reviewer could raise.**
1. Incremental value: part-year coverage in MEPS is established (Abdus 2014; AHRQ Research Findings #42). The contribution is the diabetes-specific, year-end-conditioned estimate for 2024, the spending comparison, and the reusable classification.
2. Class B has 70 unweighted respondents in 2024, so its subgroup estimates are imprecise and several fail the NCHS presentation standard.
3. Monthly coverage is self-reported in interview rounds; the year-end and December values come from the same interviews.
4. The prescription outcome covers all medicines and includes imputed payments; spending is not affordability.
5. The author is independent and has no institutional review board. The manuscript describes the study accurately as a secondary analysis of public, deidentified files with no participants recruited, and it claims no approval or exemption determination; an editor may still ask about review status.

## Alternate: Health Services Research (Wiley, for the Health Research & Educational Trust)

**Sources read:** Wiley publisher pages on research integrity, preprints, CRediT, and data sharing; the Wiley hybrid APC list (updated 2 September 2026); the official table-of-contents feed; and recent HSR articles in PubMed Central for format. The live HSR author guidelines and checklist returned HTTP 403 (Cloudflare) and could not be read, so HSR-specific limits below are unverified.

**Scope and article type.** The journal currently publishes Research Article, Research Brief, Methods Article, and Methods Brief sections (verified from the feed). As reported in search extracts, a Research Brief (about 2,500 words, 3 exhibits) suits descriptive single-year studies of well-known databases, which describes this study; a Research Article allows about 4,500 words and 5 exhibits. Recent Research Briefs use a structured abstract (Objective; Study Setting and Design; Data Sources and Analytic Sample; Principal Findings; Conclusions) and a callout box (What is known on this topic; What this study adds).

**Charges.** No charge for subscription publication. Optional OnlineOpen APC USD 4,140 (Wiley list updated 2 September 2026).

**Closest published comparisons.**
- Graves JA, Mishra P. Health insurance dynamics: methodological considerations and a comparison of estimates from two surveys. Health Serv Res. 2016;51(5):1981-2001. doi:10.1111/1475-6773.12449.
- Pascale J, Fertig AR, Call KT. Using enrollment records to evaluate self-reports of monthly coverage in the redesigned Current Population Survey health insurance module. Health Serv Res. 2024;59(2):e14285. doi:10.1111/1475-6773.14285 (abstract read).

**Fit and objections.** Strong audience fit for survey-measurement work. Reviewers there will press on seam effects, recall, round-based reporting, and the shared source of the year-end and December values, and will expect a STROBE checklist and response-rate reporting. Converting to a Research Brief would require cutting to about 2,500 words and 3 exhibits.

## Other venues checked

BMC Health Services Research (no word cap, Declarations structure, mandatory APC USD 3,450) and Health Affairs Scholar (Research Article 4,000 words and 4 exhibits, mandatory charge USD 3,457) were verified as scope fits but carry mandatory charges. Preventing Chronic Disease charges no fees but fits less well on scope and requires data no more than 2 years old at submission. INQUIRY has a mandatory APC of USD 3,200 and a 3-table cap.

## Software venue note

A Journal of Open Source Software submission is not proposed. JOSS requires evidence of public development history, and this project has no public repository yet.
