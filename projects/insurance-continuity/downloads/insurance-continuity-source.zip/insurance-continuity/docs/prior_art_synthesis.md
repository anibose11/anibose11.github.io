# Prior-art synthesis

Search date: 2026-10-07.

## Selection of the five closest items

The four searches (run 2026-10-07) returned 24 deduplicated items. Each identifier was resolved again on 2026-10-07: Crossref for all 15 DOIs, PubMed esummary for the key PMIDs, and HTTP 200 on the official AHRQ PDFs, the HC-256 documentation page and the AHRQ GitHub repository. Key figures were re-checked against the downloaded full texts: Gulley et al. Table 2 and the 40/40/20 transition sentence, RF #42 at 18.2% and RF #40 at 7.8%, Wang et al.'s uninsured definition and sensitivity sentence, Gai and Jones's framing and pattern rates, and the FULL_INSU logic in AHRQ Exercise 5b.

The five items were ranked by how directly they bear on three things: (a) the primary estimand, the share of year-end-insured adults with diabetes who had at least one fully uninsured month; (b) the secondary comparison of RXSLF24 and RXTOT24 under year-end versus monthly continuity representations; and (c) the reusable classification function.

1. Gulley et al. 2011 (peer-reviewed) is the closest on both (a) and (b). It uses the same survey and age band, builds duration-of-uninsurance categories from the monthly indicators, reports prescription fills and out-of-pocket burden by continuity among adults with chronic conditions, and gives the only published within-year transition split showing that about 40% of part-year uninsured adults gained coverage and kept it through year end.
2. Keenan and Vistnes 2019 (AHRQ RF #42, read with companion RF #40) is the closest official estimate for (a). It uses the same FYC files, the same 'insured if covered any part of the month' rule, adults 18-64 in scope all year, and a chronic-condition group that includes diabetes defined as 'ever told'. It is an agency report, kept because no peer-reviewed item gives a comparable single-year, same-definition estimate.
3. Wang et al. 2021 (peer-reviewed) is the closest diabetes-specific item for (b). It covers MEPS adults 18-64 with diabetes, reports prescription out-of-pocket trends, and uses the standard classification (full-year uninsured versus type held longest) that hides gaps inside 'insured' groups. Its full-year sensitivity analysis is the only published check of whether gaps move spending summaries.
4. Gai and Jones 2020 (peer-reviewed) is the closest methodological analogue for the classification. It builds a MEPS monthly continuity typology, frames it explicitly as point-in-time versus instability, and includes a prescription-count outcome.
5. HHS-AHRQ/MEPS Exercise 5b is the only existing tool that classifies MEPS monthly coverage. It is included because the reusable function is part of the stated contribution, and its specific gaps (no year-end anchor, out-of-scope months folded into 'fully insured', SAS and Stata only, hard-coded to 2015) define what the new function must do.

Near misses not selected:
- Cao et al. 2026 uses the same monthly indicators in a multimorbidity group that includes diabetes, but over a 2-year longitudinal window, with a prognostic design and outcomes in later years. It is close but less direct than Gai and Jones on classification and than Gulley et al. on single-year prescription outcomes.
- Lester et al. 2025 and Huguet et al. 2026 are diabetes-specific but rely on visit-based EHR churn in community health centers, not calendar months or national weights.
- Chu 2013, Rhoades 2015 and RF #40 are reference-period benchmarks with no chronic-disease or year-end conditioning; they are used in the reference list.
- Graves and Mishra 2016, Short et al. 2012 and Pascale et al. 2016 address measurement properties or point-in-time versus period framing in general populations.
- Goldman and Sommers 2020 and Short and Graefe 2003 were accessible only as abstracts.
- The HC-256 documentation and Moriya 2024 slides are the data source and variable definitions, not prior estimates.
- The MEPS R package and the AHRQ summary tables offer data access and benchmarks, not classification.

## How each closest item bears on the measurement question

Gulley, Rasch and Chan (2011). This is the closest peer-reviewed precedent, and it shows that the measurement problem is real, but it does not answer the question posed here. Using pooled MEPS-HC data for 2002-2004, the authors grouped adults aged 18-64 by months uninsured (none, 1-5, 6-11, all 12). Among all adults, 16% were uninsured all year and another 12% for part of the year. Among the part-year uninsured, about 40% lost coverage and had not regained it by year end, about 40% gained coverage and kept it through year end, and about 20% moved both into and out of coverage. The gained-and-kept group is exactly the group a December 31 indicator records as insured. On these figures, roughly 4.8% of all adults 18-64 (12% x 40%) were part-year uninsured yet insured at year end in 2002-2004. This is our arithmetic and a lower bound, because the year-end status of the multiple-transition group is not reported. Among adults with chronic conditions, 21% had at least one uninsured month. Annual prescription fills fell from 18.17 (SE 0.28) with full-year coverage to 12.63 (0.52) with 1-5 uninsured months, 11.88 (0.59) with 6-11 months and 10.17 (0.40) with all 12. The share spending at least 15% of family income on care rose from 4.52% to 6.78%, 12.62% and 16.60%. Even short gaps therefore went with materially fewer fills. The paper does not resolve the present question for four reasons:
- its groups are never cross-classified with year-end status;
- the transition split is reported for all adults, not for the chronic-condition group;
- the chronic-condition group is broad, with no diabetes estimate;
- the spending outcome is an income-burden threshold rather than prescription out-of-pocket dollars, from the pre-ACA period.
The present study conditions on INS24X=1 within DIABDX_M18=1 and asks how prescription summaries for the 'insured' group change once members with fully uninsured months are separated out.

Keenan and Vistnes (AHRQ Research Findings #42, 2019) with Vistnes and Keenan (RF #40, 2019). These reports give the closest official single-year benchmark built on definitions identical to those used here. Using MEPS-HC FYC files for 2013-2016, adults 18-64 in scope all 12 months, and a month counted as insured if covered for any part of it, they report that in 2016, 18.2% of adults with at least one of nine diagnosed chronic conditions (diabetes 'ever told' among them) were ever uninsured, against 26.2% of adults with none (22.0% overall). RF #40 reports that 7.8% of adults with a chronic condition were uninsured all year (10.8% overall). The implied part-year share among adults with chronic conditions is about 10.4 percentage points (our subtraction of two AHRQ estimates from the same sample definition). These reports do not resolve the question:
- diabetes is pooled with eight other conditions;
- the part-year share mixes people who ended the year uninsured with people who ended it insured;
- the data stop in 2016;
- no prescription outcomes are reported.
They are useful as a plausibility check, not as a comparator estimate. Applying Gulley et al.'s 2002-2004 transition split to the 2016 chronic-condition figures implies that roughly 5% to 7% of year-end-insured adults with chronic conditions had a part-year gap. Without that split, the logical ceiling is about 13% (10.4 divided by the minimum year-end-insured share of about 82%). These derived figures combine different years and populations and should not be reported as estimates. A 2024 diabetes estimate far outside this range would, however, call for re-checking the classification before interpretation.

Wang, Park, Li, Luman and Zhang (2021). This is the closest diabetes-specific analysis of out-of-pocket spending in MEPS. It shows how the standard classification handles within-year gaps but does not quantify them. Among adults 18-64 with diabetes in 2001-2017 (n=22,649), 'uninsured' meant no insurance in any month, and everyone else was assigned public or private coverage by the type held longest. People with part-year gaps are therefore counted as insured. Total family out-of-pocket costs fell from $4,328 to $4,139. Prescription out-of-pocket costs fell by $50.9 per year (P<0.0001). The share with family out-of-pocket costs above 10% of income fell from 28% to 19% (18% in the Results text). Limiting the public and private groups to full-year coverage changed that rate by less than 1 percentage point and left trends unchanged. That sensitivity result is directly relevant to the secondary aim, and it is a caution: it suggests that removing people with gaps may shift group-level summaries only modestly. The present analysis should therefore report the year-end versus continuity difference in RXSLF24 and RXTOT24 with confidence intervals and avoid presuming a large effect. Wang et al. do not resolve the question for four reasons:
- their spending is family-level and includes premiums, whereas RXSLF24 is a person-level prescription measure;
- they never estimate how many insured adults had a gap;
- the sensitivity analysis excludes those with gaps rather than reclassifying them, and reports only the high-burden rate;
- the data end in 2017.

Gai and Jones (2020). This paper is the closest methodological analogue for the classification, but it addresses a different reference period and makes no point-in-time comparison. Using 2-year MEPS panels from 2006-2016 and longitudinal weights, the authors classified 24 months of monthly status into seven patterns. Any interruption declined from 31.67% (2006-07) to 25.68% (2015-16), and uninterrupted coverage among people with priority conditions rose from 65.95% to 74.67%. The single-gap pattern averaged 4.10 uninsured months in 2015-16. Every disrupted pattern was associated with fewer prescribed medicines over 2 years than continuous coverage, ranging from -1.62 (transition out of coverage) to -3.74 (repeatedly uninsured). The paper frames point-in-time measurement as the dominant but incomplete approach. It does not resolve the present question:
- it uses a 24-month window;
- its patterns are not compared with a December 31 indicator;
- conditions are pooled;
- the prescription outcome is a count from a small and unexplained utilization sample (n=3,706);
- the population appears to include children.
The single-year classification used here collapses Gai and Jones's single-gap, transition-into and repeated-gap patterns that end in coverage into one class: insured at year end with at least one fully uninsured month.

HHS-AHRQ/MEPS example code (Exercise 5b). This is the only existing code that classifies MEPS monthly coverage, and it is a sound template for counting months and running design-based estimation. It cannot produce the estimand here. The SAS and Stata programs count insured, uninsured and in-scope months from INSJAyyX-INSDEyyX, flag FULL_INSU when no month is uninsured, cross-tabulate the flag against month counts before estimation, and estimate with VARSTR, VARPSU and the person weight. In the 2015 file, the weighted share with no uninsured month was 0.822 (SE 0.005). Three features rule it out:
- it has no year-end anchor;
- it assigns FULL_INSU=1 to people with fewer than 12 in-scope months, so out-of-scope months are absorbed into 'fully insured' (a choice that matters for people who entered or left the population during 2024);
- it is hard-coded to 2015 variable names in SAS and Stata.
The function released with this study keeps the audit-first logic. It adds year parameterization, a separate indeterminate class for people whose out-of-scope months prevent classification, classes defined relative to INS24X, and an audit table that includes INS24X by INSDE24X concordance.

Implications for interpreting the 2024 estimate. Four points from these sources and the HC-256 documentation should be stated in the Methods and Limitations:
1. Because a month counts as insured if any day was covered, a fully uninsured month is a conservative measure. Gaps shorter than a calendar month, or gaps that straddle a month boundary without covering a whole month, are not observable, so the estimate is a lower bound on within-year coverage interruption.
2. For people in scope on December 31, coverage on that date implies coverage on at least one day in December. Qualifying gaps should therefore fall in January-November, and any INS24X=1 records with INSDE24X=2 should be reported in the audit table rather than silently reclassified. For people who left the reporting unit before December 31, INS24X reflects coverage on the date they left, which is why an indeterminate class is needed.
3. MEPS monthly coverage reports are self-reported with dependent interviewing. Graves and Mishra (2016) found MEPS adult uninsured spells to be longer than SIPP spells (median 14 months versus 4-8 months), and Roberts and Pollack (2016) found that reported Medicaid reenrollment can lag observed Medicaid-covered use. Both point to possible under-capture of very short gaps.
4. Prescription out-of-pocket spending describes payments made, not affordability. Fang and Selvin (2023) show that cost-related insulin rationing occurs among insured adults with diabetes, so lower out-of-pocket spending in a gap group may reflect forgone fills rather than lower burden.

## Novelty assessment

The general phenomenon is already established, so the contribution should not be framed as showing that year-end or point-in-time status hides coverage gaps:
- Official MEPS publications have long shown that uninsured estimates depend on the reference period. For persons under 65, Chu (Statistical Brief #420) reports 25.2% uninsured at any time in 2011 versus 14.5% for the entire year, and Rhoades (Statistical Brief #476) reports 27.1% uninsured at least 1 month in 2013 versus 15.6% all year.
- AHRQ RF #42 and RF #40 give the same contrast for 2016 adults 18-64 with chronic conditions, including diabetes: 18.2% ever uninsured versus 7.8% uninsured all year.
- Gulley et al. (2011) report that about 40% of part-year uninsured working-age adults gained coverage and kept it through year end, which is precisely the group a December 31 indicator labels insured.
- Short et al. (2012), Short and Graefe (2003; abstract only) and Gai and Jones (2020) argue explicitly that point-in-time measures understate instability.
- For diabetes specifically, Lester et al. (2025) show that visit-based churn is more common among community health center patients with diabetes (17.0% versus 12.0%; adjusted OR 1.25), and Huguet et al. (2026) link churn to worse glycemic and prescribing outcomes.

What none of the verified items reports:
- a nationally representative weighted estimate, for any year, of the share of adults with diabetes insured at year end who had at least one fully uninsured calendar month;
- any such estimate from the 2024 file (HC-256, released August 2026, after the Medicaid unwinding);
- a side-by-side description of person-level prescription out-of-pocket spending and fills under a year-end versus a monthly continuity representation within the same population.
The closest spending evidence, Wang et al. (2021), handled gaps only through a sensitivity exclusion and found less than a 1 percentage point change in a family-level high-burden rate, so a small difference in the present comparison would be consistent with prior work and is itself informative. The only existing classification code (AHRQ Exercise 5b) has no year-end anchor and folds out-of-scope months into 'fully insured'.

Recommended framing: a descriptive measurement study, or brief report, that (1) gives a diabetes-specific 2024 update quantifying the part-year uninsurance concealed by the December 31 indicator; (2) uses a monthly continuity classification with an explicit indeterminate class for out-of-scope months and a documented audit table; (3) shows how much RXSLF24 and RXTOT24 summaries for the 'insured' group shift between the two representations, reported with design-based confidence intervals and without causal or affordability claims; and (4) releases the classification function as a reusable, year-parameterized tool. Wording such as 'first' or 'novel finding' is not supported and should be avoided. 'To our knowledge, no published estimate conditions on year-end coverage among adults with diabetes' is supportable for the sources searched.

Residual uncertainty: Goldman and Sommers (2020) and Short and Graefe (2003) could be read only at abstract level. Neither abstract mentions a year-end comparison or prescription outcomes, but their full texts cannot be ruled out. The search covered PubMed, publisher and PMC full texts, and AHRQ publications and tools; unindexed reports from other agencies or survey producers may exist.
