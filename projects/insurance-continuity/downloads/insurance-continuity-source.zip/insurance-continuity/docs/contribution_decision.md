# Contribution decision

- Written: 2026-10-07T09:47:14Z, after the prior-art search and before any analysis file was built or any estimate was produced.
- Inputs: the analysis plan (docs/analysis_plan.md, 2026-10-07T09:30:25Z) and the prior-art search (docs/literature_search_log.md, docs/prior_art.csv).

## Who could use the output

Health-services analysts and MEPS data users who stratify annual spending or use by coverage status; researchers studying medication costs in diabetes; and analysts who build annual coverage indicators from survey or enrollment data and need to decide how to treat part-year coverage.

## Decision it supports

Whether a year-end coverage indicator is an adequate stand-in for coverage over the year when summarizing annual prescription spending among working-age adults with diabetes, or whether analysts should carry a monthly continuity class (and how much it changes the summaries).

## What is already established

- Part-year uninsurance among working-age adults is well documented in MEPS. AHRQ Research Findings #42 (Keenan and Vistnes, 2019) reports that 22.0% of adults aged 18 to 64 in scope all of 2016 were uninsured for at least one month, and 18.2% of adults with at least one diagnosed chronic condition (a nine-condition group that includes diabetes). AHRQ Statistical Brief #476 (Rhoades, 2015) shows the any-month uninsured rate was about 1.7 times the full-year rate in 2013.
- MEPS monthly indicators have been used to build continuity typologies and relate them to prescription use: Gulley, Rasch, and Chan (2011) for adults with chronic conditions in 2002 to 2004, including fills and out-of-pocket burden; Gai and Jones (2020) for two-year patterns in 2006 to 2016.
- Medicaid churning has been measured with MEPS monthly data (Goldman and Sommers, 2020; abstract read, full text inaccessible), and coverage instability has been linked to diabetes outcomes in clinic populations (Lester et al., 2025; Huguet et al., 2026).
- MEPS studies of out-of-pocket costs in diabetes usually classify insurance by any-time or longest-held coverage and treat only the full-year uninsured as uninsured (Wang et al., 2021), so within-year gaps sit inside the insured groups.

## Narrow unresolved question

None of the items read reports, for adults with diabetes, the share of people who are insured on December 31 but had a fully uninsured month in the same year, and none compares annual prescription spending summaries under a year-end versus a monthly continuity representation. The most recent MEPS-based ever-uninsured estimates found were for 2016, before the 2023 to 2024 Medicaid unwinding.

## Comparator

The year-end indicator `INS24X` (covered on 12/31/2024), which is the point-in-time construct the study evaluates. AHRQ's annual any-time indicator `INSCOV24` is used only in reconciliation.

## Estimand

Weighted proportion with at least one fully uninsured calendar month among adults aged 18 to 64 with ever-diagnosed diabetes, in scope all 12 months of 2024, who were insured on 12/31/2024. Secondary: prescription use and out-of-pocket spending summaries by year-end status versus continuity class, on common and classification-specific denominators.

## How the work is framed

This is an update and extension of established MEPS part-year uninsurance estimates to a specific population and a specific measurement contrast, plus a reusable classification tool. It is not presented as the first measurement of part-year uninsurance or of coverage instability. The reusable audit function and the carefully quantified measurement difference are the contribution. A 2024 data year does not by itself establish novelty.

## What would count as a useful negative result

A small omitted-gap share (for example below 3%) with a narrow interval would support using the year-end indicator for this population in 2024. A spending comparison in which the gap group looks like the continuously insured would mean the year-end indicator loses little for spending summaries even if gaps exist. Either result will be reported as found.

## Amendments

None at the time of writing.
