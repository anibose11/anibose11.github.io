"""Compare the ACS values derived from the variance replicate tables with the Census
Bureau's separately published table-based summary files, for every county.

Streams the summary files (pipe-delimited, all geographies) and keeps county rows
only. Nothing large is stored. Writes outputs/validation/summary_file_check.json.

Usage: python scripts/check_summary_files.py
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parents[1]
BASE = "https://www2.census.gov/programs-surveys/acs/summary_file/{y}/table-based-SF/data/5YRData/acsdt5y{y}-{t}.dat"
NEEDED = {"b05003": ["B05003_E008", "B05003_E019"], "b17001": ["B17001_E001", "B17001_E002"]}


def county_rows(year: int, table: str) -> pd.DataFrame:
    url = BASE.format(y=year, t=table)
    with requests.get(url, stream=True, timeout=300) as r:
        r.raise_for_status()
        lines = (b.decode("utf-8") for b in r.iter_lines())
        header = next(lines).split("|")
        keep = [header.index("GEO_ID")] + [header.index(c) for c in NEEDED[table]]
        rows = []
        for line in lines:
            if line.startswith("0500000US"):
                parts = line.split("|")
                rows.append([parts[i] for i in keep])
    df = pd.DataFrame(rows, columns=["GEO_ID"] + NEEDED[table])
    df["fips"] = df["GEO_ID"].str.slice(9)
    for c in NEEDED[table]:
        df[c] = pd.to_numeric(df[c])
    return df.drop(columns="GEO_ID")


def main() -> dict:
    frame = set(pd.read_csv(ROOT / "data" / "processed" / "analysis_frame.csv", dtype={"fips": str})["fips"])
    out = {"run_id": json.loads((ROOT / "outputs" / "tables" / "run_record.json").read_text())["run_id"],
           "checked_on": dt.date.today().isoformat(),
           "source": "U.S. Census Bureau ACS table-based summary files (5-year)", "vintages": {}}
    for year in (2024, 2023):
        acs = pd.read_csv(ROOT / "data" / "interim" / f"acs{year}_county.csv", dtype={"fips": str})
        sf = county_rows(year, "b05003").merge(county_rows(year, "b17001"), on="fips")
        m = acs.merge(sf, on="fips", how="left")
        adult_sf = m["B05003_E008"] + m["B05003_E019"]
        pct_sf = 100 * m["B17001_E002"] / m["B17001_E001"]
        ok = ((adult_sf == m[f"acs{year}_adult"]) & (m["B17001_E002"] == m[f"acs{year}_pov_num"])
              & (m["B17001_E001"] == m[f"acs{year}_pov_den"]))
        out["vintages"][str(year)] = {
            "counties_in_replicate_file": int(len(acs)),
            "matched_in_summary_file": int(m["B05003_E008"].notna().sum()),
            "adults_equal": int((adult_sf == m[f"acs{year}_adult"]).sum()),
            "poverty_numerator_equal": int((m["B17001_E002"] == m[f"acs{year}_pov_num"]).sum()),
            "poverty_denominator_equal": int((m["B17001_E001"] == m[f"acs{year}_pov_den"]).sum()),
            "poverty_percent_max_abs_difference": float((pct_sf - m[f"acs{year}_pov_pct"]).abs().max()),
            "frame_counties": len(frame),
            "frame_counties_all_equal": int(ok[m["fips"].isin(frame)].sum()),
            "mismatched_fips": sorted(m.loc[~ok, "fips"].tolist()),
        }
    out["all_equal"] = all(not v["mismatched_fips"] and v["matched_in_summary_file"] == v["counties_in_replicate_file"]
                           for v in out["vintages"].values())
    dest = ROOT / "outputs" / "validation" / "summary_file_check.json"
    dest.write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    main()
