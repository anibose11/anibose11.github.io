#!/bin/sh
# Full pipeline from a fresh copy. Requires Python 3.12+ and R (base packages only).
set -eu
cd "$(dirname "$0")/.."
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.lock
pip install -e ".[test]"
pytest
dop acquire
dop build
dop analyze
dop validate
python scripts/check_summary_files.py
python scripts/check_places_live.py
python scripts/check_references.py
python scripts/recompute_tables.py
dop render
dop package
python scripts/recompute_tables.py
