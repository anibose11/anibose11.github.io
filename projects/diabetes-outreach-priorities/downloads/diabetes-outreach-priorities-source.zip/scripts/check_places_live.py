"""Compare the analysis tables with the live CDC PLACES 2025 county release on data.cdc.gov.

Queries the Socrata API for every diagnosed-diabetes crude-prevalence row, then checks
(1) every frame county's estimate, 95% limits and adult population, (2) the twelve
counties in the fixed-seed hand-check sample, with burden recalculated from the live
values, and (3) the counties ranked in the top 10 after sorting the live file.
Writes outputs/validation/places_live_check.json.

Usage: python scripts/check_places_live.py
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

import numpy as np
import pandas as pd
import requests

ROOT = Path(__file__).resolve().parents[1]
URL = "https://data.cdc.gov/resource/swc5-untb.json"


def live_rows() -> pd.DataFrame:
    params = {"measureid": "DIABETES", "datavaluetypeid": "CrdPrv", "$limit": 10000,
              "$select": "locationid,stateabbr,locationname,year,data_value,low_confidence_limit,high_confidence_limit,totalpop18plus"}
    r = requests.get(URL, params=params, timeout=120)
    r.raise_for_status()
    df = pd.DataFrame(r.json())
    for c in ("data_value", "low_confidence_limit", "high_confidence_limit", "totalpop18plus"):
        df[c] = pd.to_numeric(df[c])
    return df.rename(columns={"locationid": "fips"})


def main() -> dict:
    import tomllib
    a = tomllib.loads((ROOT / "config" / "study.toml").read_text())["analysis"]
    cfg_seed, cfg_n = a["validation_sample_seed"], a["validation_sample_size"]
    ctab = pd.read_csv(ROOT / "outputs" / "tables" / "county_priority_table.csv", dtype={"fips": str})
    live = live_rows()
    m = ctab.merge(live, on="fips", how="left")
    same = ((m.prev == m.data_value) & (m.prev_lcl == m.low_confidence_limit) & (m.prev_ucl == m.high_confidence_limit)
            & (m.pop18_places == m.totalpop18plus))

    s = ctab.sort_values("fips").reset_index(drop=True)
    idx = sorted(np.random.default_rng(cfg_seed).choice(len(s), size=cfg_n, replace=False))
    sample = s.iloc[idx].merge(live, on="fips", how="left")
    sample["burden_live"] = sample.data_value / 100 * sample.totalpop18plus
    sample_rows = [{"fips": r.fips, "county": f"{r.display_name}, {r.state_abbr}", "prev": r.data_value,
                    "lcl": r.low_confidence_limit, "ucl": r.high_confidence_limit, "adults": int(r.totalpop18plus),
                    "burden_recalculated": round(r.burden_live, 1), "burden_table": round(r.burden, 1),
                    "match": bool(r.prev == r.data_value and r.prev_lcl == r.low_confidence_limit
                                  and r.prev_ucl == r.high_confidence_limit and round(r.burden_live, 1) == round(r.burden, 1))}
                   for _, r in sample.iterrows()]

    frame_live = live[live.fips.isin(ctab.fips)].copy()
    frame_live["rank"] = frame_live.data_value.rank(method="min", ascending=False).astype(int)
    top_live = sorted(frame_live.loc[frame_live["rank"] <= 10, "fips"])
    top_table = sorted(ctab.loc[ctab.PREV_K25_rank <= 10, "fips"])

    out = {
        "run_id": json.loads((ROOT / "outputs" / "tables" / "run_record.json").read_text())["run_id"],
        "checked_on": dt.date.today().isoformat(),
        "source": "CDC PLACES County Data 2025 release, data.cdc.gov dataset swc5-untb (Socrata API)",
        "live_rows": int(len(live)),
        "live_years": sorted(live.year.unique().tolist()),
        "frame_counties": int(len(ctab)),
        "frame_counties_found": int(m.data_value.notna().sum()),
        "frame_counties_identical": int(same.sum()),
        "sample_seed": cfg_seed,
        "sample": sample_rows,
        "sample_all_match": all(r["match"] for r in sample_rows),
        "top10_live": top_live,
        "top10_table": top_table,
        "top10_identical": top_live == top_table,
    }
    out["all_match"] = bool(out["frame_counties_identical"] == len(ctab) and out["sample_all_match"] and out["top10_identical"])
    (ROOT / "outputs" / "validation" / "places_live_check.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps({k: v for k, v in out.items() if k != "sample"}, indent=2))
    return out


if __name__ == "__main__":
    main()
