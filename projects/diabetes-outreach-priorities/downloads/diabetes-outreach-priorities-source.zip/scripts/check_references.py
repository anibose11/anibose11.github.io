"""Check every reference against its registry record or web address.

Journal articles with a DOI are compared with Crossref (first author, year, volume,
first page and title). The article cited by PubMed ID is compared with the NCBI
E-utilities summary, and the Federal Register notice is compared with the Federal Register
API. Web pages and datasets must resolve. Writes outputs/validation/reference_check.json.

Usage: python scripts/check_references.py
"""

from __future__ import annotations

import datetime as dt
import difflib
import json
import re
import sys
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from dop.references import REFERENCES  # noqa: E402

UA = {"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"}


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", re.sub(r"<[^>]+>", "", s.lower())).strip()


def cited_parts(ref: str) -> dict:
    m = re.search(r"(\d{4});(\d+)(?:\(([^)]+)\))?:([A-Z]?\d+)", ref)
    return {"author": ref.split(" ")[0].rstrip(","), "year": m.group(1) if m else None,
            "volume": m.group(2) if m else None, "page": m.group(4) if m else None,
            "title": ref.split(". ")[1] if ". " in ref else ""}


def check_doi(ref: str, doi: str) -> dict:
    r = requests.get(f"https://api.crossref.org/works/{requests.utils.quote(doi, safe='/')}", headers=UA, timeout=60)
    if r.status_code != 200:
        return {"ok": False, "detail": f"Crossref HTTP {r.status_code}"}
    w = r.json()["message"]
    c = cited_parts(ref)
    year = str((w.get("published-print") or w.get("issued"))["date-parts"][0][0])
    year_any = {str(w[k]["date-parts"][0][0]) for k in ("published-print", "published-online", "issued") if k in w}
    page = (w.get("page") or w.get("article-number") or "").split("-")[0]
    c = cited_parts(ref)
    if page.lstrip("Ee") != (c["page"] or "").lstrip("E"):
        # Crossref has no page for some journals (Prev Chronic Dis gives an article number), so use PubMed.
        ids = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
                           params={"db": "pubmed", "term": f"{doi}[aid]", "retmode": "json"}, timeout=60).json()
        pm = ids["esearchresult"]["idlist"]
        if pm:
            s = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
                             params={"db": "pubmed", "id": pm[0], "retmode": "json"}, timeout=60).json()["result"][pm[0]]
            page = s["pages"].split("-")[0]
    first = (w.get("author") or [{}])[0].get("family", "")
    title = (w.get("title") or [""])[0]
    # Crossref sometimes appends a linked commentary to the title. Compare the cited title with its start.
    sim = difflib.SequenceMatcher(None, norm(c["title"]), norm(title)[:len(norm(c["title"]))]).ratio()
    checks = {
        "first_author": norm(first) == norm(c["author"]),
        "year": c["year"] in year_any,
        "volume": str(w.get("volume", "")) == c["volume"],
        "first_page": page.lstrip("Ee") == c["page"].lstrip("E") if c["page"] else False,
        "title_similarity": round(sim, 3),
    }
    ok = checks["first_author"] and checks["year"] and checks["volume"] and checks["first_page"] and sim >= 0.85
    return {"ok": ok, "crossref": {"first_author": first, "year": year, "volume": w.get("volume"), "page": w.get("page"),
                                   "journal": (w.get("container-title") or [""])[0], "title": title}, "checks": checks}


def check_pmid(ref: str, pmid: str) -> dict:
    r = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
                     params={"db": "pubmed", "id": pmid, "retmode": "json"}, timeout=60)
    r.raise_for_status()
    s = r.json()["result"][pmid]
    c = cited_parts(ref)
    checks = {"first_author": norm(s["authors"][0]["name"].split(" ")[0]) == norm(c["author"]),
              "year": s["pubdate"].startswith(c["year"]), "volume": s["volume"] == c["volume"],
              "page": s["pages"].lstrip("E") == c["page"].lstrip("E"),
              "title_similarity": round(difflib.SequenceMatcher(None, norm(c["title"]), norm(s["title"])).ratio(), 3)}
    ok = all(v for k, v in checks.items() if k != "title_similarity") and checks["title_similarity"] >= 0.85
    return {"ok": ok, "pubmed": {"title": s["title"], "source": s["source"], "pubdate": s["pubdate"],
                                 "volume": s["volume"], "pages": s["pages"]}, "checks": checks}


def check_fr(ref: str) -> dict:
    r = requests.get("https://www.federalregister.gov/api/v1/documents.json",
                     params={"conditions[term]": "Connecticut county-equivalents", "conditions[publication_date][is]": "2022-06-06"},
                     timeout=60)
    r.raise_for_status()
    hits = [d for d in r.json().get("results", []) if "Connecticut" in d["title"]]
    if not hits:
        return {"ok": False, "detail": "no Federal Register match"}
    d = requests.get(hits[0]["json_url"] if "json_url" in hits[0] else f"https://www.federalregister.gov/api/v1/documents/{hits[0]['document_number']}.json", timeout=60).json()
    ok = d.get("start_page") == 34235 and d.get("end_page") == 34240 and d.get("publication_date") == "2022-06-06"
    return {"ok": ok, "federal_register": {k: d.get(k) for k in ("title", "agencies", "publication_date", "start_page", "end_page", "volume")}}


def check_census_table(url: str, ref: str) -> dict | None:
    """data.census.gov table pages sit behind a bot check. Confirm the table and its title from the
    Census Bureau's public API metadata instead."""
    m = re.match(r"https://data.census.gov/table/ACSST5Y(\d{4})\.(S\d+)", url)
    if not m:
        return None
    year, table = m.groups()
    r = requests.get(f"https://api.census.gov/data/{year}/acs/acs5/subject/groups.json", timeout=60)
    r.raise_for_status()
    hit = next((g for g in r.json()["groups"] if g["name"] == table), None)
    ok = bool(hit) and norm(hit["description"]) in norm(ref)
    return {"ok": ok, "census_api_metadata": {"table": table, "year": year, "title": hit["description"] if hit else None}}


def check_url(url: str) -> dict:
    try:
        r = requests.get(url, headers=UA, timeout=60, allow_redirects=True, stream=True)
        code = r.status_code
        r.close()
    except requests.RequestException as e:
        return {"ok": False, "detail": str(e)[:200]}
    if code == 403 and "cdc.gov" in url:
        # cdc.gov refuses scripted clients. Use the recorded browser check if there is one.
        rec = ROOT / "outputs" / "validation" / "reference_browser_check.json"
        page = json.loads(rec.read_text())["pages"].get(url) if rec.exists() else None
        if page:
            return {"ok": page["ok"], "http_status": code, "browser_check": page}
        return {"ok": False, "http_status": code, "detail": "cdc.gov refuses scripted clients. Open in a browser"}
    return {"ok": code == 200, "http_status": code}


def main() -> dict:
    out = []
    for i, ref in enumerate(REFERENCES, 1):
        doi = re.search(r"doi:(\S+)$", ref)
        pmid = re.search(r"PMID: (\d+)", ref)
        url = re.search(r"(https?://\S+?)\.?(?: Accessed|$)", ref)
        if doi:
            res = {"kind": "doi", "id": doi.group(1), **check_doi(ref, doi.group(1))}
        elif pmid:
            res = {"kind": "pmid", "id": pmid.group(1), **check_pmid(ref, pmid.group(1))}
        elif "Fed Regist" in ref:
            res = {"kind": "federal_register", "id": "87 FR 34235", **check_fr(ref)}
        elif url and "data.census.gov/table/" in url.group(1):
            res = {"kind": "url", "id": url.group(1), **check_census_table(url.group(1), ref)}
        elif url:
            res = {"kind": "url", "id": url.group(1), **check_url(url.group(1))}
        else:
            res = {"kind": "none", "ok": False}
        out.append({"n": i, **res})
        print(f"[{i:2d}] {'ok ' if res['ok'] else 'CHECK'} {res['kind']:16s} {res['id']}")
    rep = {"n_references": len(REFERENCES), "n_ok": sum(r["ok"] for r in out), "references": out}
    rep = {"run_id": json.loads((ROOT / "outputs" / "tables" / "run_record.json").read_text())["run_id"],
           "checked_on": dt.date.today().isoformat(), **rep}
    (ROOT / "outputs" / "validation" / "reference_check.json").write_text(json.dumps(rep, indent=2) + "\n")
    print(f"{rep['n_ok']} of {rep['n_references']} references matched their records")
    return rep


if __name__ == "__main__":
    main()
