"""Recompute the numbers in manuscript Tables 2 and 3 and Figures 1 to 3 without the analysis package.

Starts from the analysis frame's published inputs (PLACES estimates and limits, adult
populations, ACS adult and poverty limits), rebuilds every rule's ranks and envelopes by
direct pairwise comparison (an O(n^2) method, unlike the sorted counts in the package),
and compares the results with the manuscript tables and the result files.
Writes outputs/validation/table_recompute_check.json.

Usage: python scripts/recompute_tables.py
"""

from __future__ import annotations

import json
import re
import tomllib
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def ranks_pairwise(v: np.ndarray, members: np.ndarray) -> np.ndarray:
    """Competition rank among members: 1 + number of members with a strictly larger value."""
    out = np.full(len(v), np.nan)
    vm = v[members]
    out[members] = 1 + (vm[None, :] > vm[:, None]).sum(axis=1)
    return out


def rule_values(f: pd.DataFrame, rule: str, thr: float):
    n = len(f)
    allc = np.ones(n, bool)
    if rule == "BURDEN":
        adults = f.pop18_places.to_numpy(float)
        lo_pop = np.minimum(adults, np.maximum(f.acs2024_adult_lo95.to_numpy(float), 0))
        hi_pop = np.maximum(adults, f.acs2024_adult_hi95.to_numpy(float))
        return (f.prev.to_numpy(float) * adults / 100, f.prev_lcl.to_numpy(float) * lo_pop / 100,
                f.prev_ucl.to_numpy(float) * hi_pop / 100, allc, allc, allc)
    v, lo, hi = f.prev.to_numpy(float), f.prev_lcl.to_numpy(float), f.prev_ucl.to_numpy(float)
    if rule == "PREV":
        return v, lo, hi, allc, allc, allc
    pov = f.acs2024_pov_pct.to_numpy(float)
    sdr = (f.acs2024_pov_status == "sdr").to_numpy()
    point = pov >= thr
    certain = np.where(sdr, f.acs2024_pov_lo95.to_numpy(float) >= thr, point)
    possible = np.where(sdr, f.acs2024_pov_hi95.to_numpy(float) >= thr, point)
    return v, lo, hi, point, certain, possible


def envelope_pairwise(lo, hi, certain, possible, k):
    gt_best = (lo[None, :] > hi[:, None]) & certain[None, :]          # j beats i even at i's best
    gt_worst = (hi[None, :] > lo[:, None]) & possible[None, :]        # j can beat i at i's worst
    np.fill_diagonal(gt_worst, False)
    best = 1 + gt_best.sum(axis=1)
    worst = 1 + gt_worst.sum(axis=1)
    core = possible & certain & (worst <= k)
    boundary = possible & (best <= k) & ~core
    return best, worst, core, boundary


def manuscript_tables(md: str):
    t2 = md.split("**Table 2.")[1].split("**Table 3.")[0]
    t3 = md.split("**Table 3.")[1].split("## Figure legends")[0]
    rows2 = [[c.strip() for c in line.strip("|").split("|")] for line in t2.splitlines()
             if line.startswith("| ") and not line.startswith("| Rule") and "---" not in line]
    rows3 = [[c.strip() for c in line.strip("|").split("|")] for line in t3.splitlines()
             if line.startswith("| ") and not line.startswith("| Capacity") and "---" not in line]
    return rows2, rows3


def main() -> dict:
    cfg = tomllib.loads((ROOT / "config" / "study.toml").read_text())["analysis"]
    thr, caps = cfg["high_poverty_threshold_pct"], cfg["national_capacities"]
    f = pd.read_csv(ROOT / "data" / "processed" / "analysis_frame.csv", dtype={"fips": str})
    names = {"PREV": "Prevalence", "BURDEN": "Estimated burden", "EQUITY": "High-poverty prevalence"}
    burden_point = f.prev.to_numpy(float) * f.pop18_places.to_numpy(float) / 100
    total = burden_point.sum()
    mine, sets = {}, {}
    for rule in ("PREV", "BURDEN", "EQUITY"):
        v, lo, hi, point, certain, possible = rule_values(f, rule, thr)
        rank = ranks_pairwise(v, point)
        for k in caps:
            selected = rank <= k
            best, worst, core, boundary = envelope_pairwise(lo, hi, certain, possible, k)
            sets[(rule, k)] = set(f.fips[selected])
            mine[(rule, k)] = {"ranked": int(point.sum()), "selected": int(selected.sum()), "core": int(core.sum()),
                               "boundary": int(boundary.sum()), "burden_sum": float(burden_point[selected].sum()),
                               "share": float(burden_point[selected].sum() / total),
                               "status": dict(zip(f.fips, np.where(core, "core", np.where(boundary, "boundary", "outside"))))}

    ms = ROOT / "manuscript" / "manuscript.md"
    if ms.exists():
        target, md = "manuscript/manuscript.md", ms.read_text()
    else:  # fresh copy before `dop render`: compare with the tables exactly as the report prints them
        from dop.report import table2, table3
        t = ROOT / "outputs" / "tables"
        md = (table2(pd.read_csv(t / "envelope_summary.csv"), pd.read_csv(t / "selection_profile.csv")) + "\n\n"
              + table3(pd.read_csv(t / "rule_overlap.csv")) + "\n\n## Figure legends\n")
        target = "Tables 2 and 3 as printed by dop.report from outputs/tables"
    rows2, rows3 = manuscript_tables(md)
    diffs = []
    rev = {v: k for k, v in names.items()}
    for r in rows2:
        rule, k = rev[r[0]], int(r[1])
        m = mine[(rule, k)]
        burden_txt, share_txt = re.match(r"([\d,]+) \(([\d.]+)%\)", r[6]).groups()
        want = {"ranked": f"{m['ranked']:,}", "selected": f"{m['selected']:,}", "core": str(m["core"]),
                "boundary": str(m["boundary"]), "burden": f"{round(m['burden_sum']):,}"}
        got = {"ranked": r[2], "selected": r[3], "core": r[4], "boundary": r[5], "burden": burden_txt}
        for key in want:
            if want[key] != got[key]:
                diffs.append(f"Table 2 {rule} K={k} {key}: manuscript {got[key]}, recomputed {want[key]}")
        dec = len(share_txt.split(".")[1])
        if f"{100 * m['share']:.{dec}f}" != share_txt:
            diffs.append(f"Table 2 {rule} K={k} share: manuscript {share_txt}, recomputed {100 * m['share']:.{dec}f}")
    for r in rows3:
        k = int(r[0])
        for cell, (a, b) in zip(r[1:], (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY"))):
            A, B = sets[(a, k)], sets[(b, k)]
            want = f"{len(A & B)} of {len(A | B)} ({len(A & B) / len(A | B):.2f})"
            if cell != want:
                diffs.append(f"Table 3 K={k} {a}/{b}: manuscript {cell}, recomputed {want}")

    # Result files used for the figures.
    env = pd.read_csv(ROOT / "outputs" / "tables" / "envelope_summary.csv")
    env = env[env.scope == "national"]
    for _, e in env.iterrows():
        m = mine[(e.rule, int(e.capacity))]
        if (int(e.n_core), int(e.n_boundary), int(e.n_selected_point)) != (m["core"], m["boundary"], m["selected"]):
            diffs.append(f"envelope_summary {e.rule} K={e.capacity} differs from recomputation")
    long = pd.read_csv(ROOT / "outputs" / "tables" / "priority_long.csv", dtype={"fips": str})
    long = long[long.capacity.isin(caps)]
    n_status = 0
    for (rule, k), d in long.groupby(["rule", "capacity"]):
        st = mine[(rule, int(k))]["status"]
        bad = int((d.envelope_status != d.fips.map(st)).sum())
        n_status += len(d)
        if bad:
            diffs.append(f"priority_long {rule} K={k}: {bad} county statuses differ")
    out = {"run_id": json.loads((ROOT / "outputs" / "tables" / "run_record.json").read_text())["run_id"],
           "compared_against": target,
           "frame_counties": int(len(f)), "table2_cells_checked": len(rows2) * 6, "table3_cells_checked": len(rows3) * 3,
           "county_statuses_checked": n_status, "figure1_counts": {r: mine[(r, 25)]["selected"] for r in names},
           "differences": diffs, "all_match": not diffs}
    (ROOT / "outputs" / "validation" / "table_recompute_check.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))
    return out


if __name__ == "__main__":
    main()
