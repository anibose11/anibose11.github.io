"""Generate the small SYNTHETIC fixture used by `dop demo` and documentation examples.

The values are random draws with a fixed seed. They are not study data and do
not describe any real place. FIPS-like codes start with 9, which no U.S. state
uses, and county names are labelled "Synthetic".
"""

from pathlib import Path

import numpy as np
import pandas as pd

rng = np.random.default_rng(20261007)
rows = []
for s, n in (("Z1", 24), ("Z2", 12), ("Z3", 4)):
    for i in range(n):
        prev = round(float(rng.uniform(7, 19)), 1)
        half = round(float(rng.uniform(0.4, 2.2)), 1)
        pop = int(rng.integers(800, 400000))
        acs = pop * float(rng.uniform(0.97, 1.03))
        acs_se = acs * float(rng.uniform(0.0, 0.02))
        pov = float(rng.uniform(6, 34))
        pov_se = float(rng.uniform(0.4, 4.0))
        rows.append({
            "fips": f"9{len(rows):04d}", "state_fips": f"9{s[-1]}", "state_abbr": s,
            "county_name": f"Synthetic {s}-{i + 1:02d}",
            "prev": prev, "prev_lcl": round(prev - half, 1), "prev_ucl": round(prev + half, 1),
            "pop18_places": pop, "acs2024_adult_lo95": acs - 1.96 * acs_se, "acs2024_adult_hi95": acs + 1.96 * acs_se,
            "acs2024_pov_pct": pov, "acs2024_pov_lo95": pov - 1.96 * pov_se, "acs2024_pov_hi95": pov + 1.96 * pov_se,
            "acs2024_pov_status": "sdr",
        })
out = Path(__file__).resolve().parents[1] / "tests" / "fixtures" / "demo_frame_SYNTHETIC.csv"
pd.DataFrame(rows).to_csv(out, index=False)
print(f"wrote {len(rows)} synthetic rows to {out}")
