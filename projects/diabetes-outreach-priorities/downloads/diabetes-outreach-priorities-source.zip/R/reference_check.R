# Second implementation in base R (no add-on packages).
#
# 1. Recomputes ACS 2020-2024 adults 18+ and poverty percent, with SDR standard
#    errors, directly from the raw Census variance replicate archives.
# 2. Recomputes estimated burden, scenario bounds, competition ranks, selected
#    sets and envelope ranks for every rule and national capacity from the
#    analysis frame.
#
# Agreement with the Python pipeline is a software cross-check. It is not
# independent scientific validation of the estimates.
#
# Usage: Rscript R/reference_check.R <project_root> <out_dir> <poverty_threshold> <capacities>
# (dop validate passes the threshold and capacities from config/study.toml)

args <- commandArgs(trailingOnly = TRUE)
root <- if (length(args) >= 1) args[1] else "."
out_dir <- if (length(args) >= 2) args[2] else file.path(root, "outputs", "validation")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

thr <- if (length(args) >= 3) as.numeric(args[3]) else 20.0
caps <- if (length(args) >= 4) as.integer(strsplit(args[4], ",")[[1]]) else c(10L, 25L, 50L)

# ---- 1. ACS from raw replicate archives ------------------------------------
read_vrt <- function(zip_path, member) {
  con <- unz(zip_path, member)
  d <- read.csv(con, colClasses = "character", check.names = FALSE, encoding = "latin1")
  d <- d[d$GEOID != "", ]
  d$fips <- substring(d$GEOID, 10)
  d
}
rep_cols <- paste0("Var_Rep", 1:80)
sdr_se <- function(est, reps) sqrt(4 / 80 * rowSums((reps - est)^2))
line <- function(d, order) {
  x <- d[d$ORDER == order, ]
  x[order(x$fips), ]
}
num <- function(x, cols) {
  m <- as.matrix(x[, cols, drop = FALSE])
  storage.mode(m) <- "double"
  m
}

raw <- file.path(root, "data", "raw")
b05 <- read_vrt(file.path(raw, "acs5_2024_b05003_vrt", "acs5_2024_B05003_vrt.csv.zip"), "050/B05003.csv")
b17 <- read_vrt(file.path(raw, "acs5_2024_b17001_vrt", "acs5_2024_B17001_vrt.csv.zip"), "050/B17001.csv")
m18 <- line(b05, "8"); f18 <- line(b05, "19")
stopifnot(all(m18$TITLE == "18 years and over:"), all(f18$TITLE == "18 years and over:"), identical(m18$fips, f18$fips))
adult <- num(m18, "ESTIMATE")[, 1] + num(f18, "ESTIMATE")[, 1]
adult_reps <- num(m18, rep_cols) + num(f18, rep_cols)
controlled <- m18$CME == "*****" & f18$CME == "*****"
adult_se <- ifelse(controlled, 0, sdr_se(adult, adult_reps))
pn <- line(b17, "2"); pd <- line(b17, "1")
stopifnot(identical(pn$fips, pd$fips), identical(pn$fips, m18$fips))
pct <- 100 * num(pn, "ESTIMATE")[, 1] / num(pd, "ESTIMATE")[, 1]
den_r <- num(pd, rep_cols)
rep_pct <- ifelse(den_r > 0, 100 * num(pn, rep_cols) / den_r, 0)
pov_se <- sdr_se(pct, rep_pct)
pov_special <- (num(pd, "ESTIMATE")[, 1] <= 0) | (pct <= 0) | (pct >= 100) | (pov_se <= 0)
pov_se[pov_special] <- NA
acs_r <- data.frame(fips = m18$fips, adult = adult, adult_se = adult_se, pov_pct = pct, pov_se = pov_se,
                    stringsAsFactors = FALSE)
write.csv(acs_r, file.path(out_dir, "r_acs2024.csv"), row.names = FALSE)

# ---- 2. Rules, ranks and envelopes from the analysis frame -------------------
f <- read.csv(file.path(root, "data", "processed", "analysis_frame.csv"),
              colClasses = c(fips = "character", state_fips = "character"))
f <- f[order(f$fips), ]
lo_pop <- pmin(f$pop18_places, pmax(f$acs2024_adult_lo95, 0))
hi_pop <- pmax(f$pop18_places, f$acs2024_adult_hi95)
burden <- f$prev / 100 * f$pop18_places
burden_lo <- f$prev_lcl / 100 * lo_pop
burden_hi <- f$prev_ucl / 100 * hi_pop
elig_point <- f$acs2024_pov_pct >= thr
# Poverty estimates flagged as special cases (0 or 100 percent, or zero replicate variance)
# have no usable standard error. Eligibility then follows the point estimate, as in Python.
special <- f$acs2024_pov_status != "sdr"
elig_certain <- ifelse(special, elig_point, f$acs2024_pov_lo95 >= thr)
elig_possible <- ifelse(special, elig_point, f$acs2024_pov_hi95 >= thr)

count_greater <- function(ref, x) {
  s <- sort(ref)
  length(s) - findInterval(x, s)
}
comp_rank <- function(v, mask) {
  r <- rep(NA_real_, length(v))
  r[mask] <- rank(-v[mask], ties.method = "min")
  r
}

rows <- list()
for (rule in c("PREV", "BURDEN", "EQUITY")) {
  if (rule == "PREV") { v <- f$prev; lo <- f$prev_lcl; hi <- f$prev_ucl
    pm <- cm <- qm <- rep(TRUE, nrow(f)) }
  if (rule == "BURDEN") { v <- burden; lo <- burden_lo; hi <- burden_hi
    pm <- cm <- qm <- rep(TRUE, nrow(f)) }
  if (rule == "EQUITY") { v <- f$prev; lo <- f$prev_lcl; hi <- f$prev_ucl
    pm <- elig_point; cm <- elig_certain; qm <- elig_possible }
  pr <- comp_rank(v, pm)
  best <- 1 + count_greater(lo[cm], hi)
  worst <- 1 + count_greater(hi[qm], lo) - as.integer(qm & hi > lo)
  for (k in caps) {
    status <- ifelse(qm & best <= k, ifelse(cm & worst <= k, "core", "boundary"), "outside")
    rows[[length(rows) + 1]] <- data.frame(
      fips = f$fips, rule = rule, capacity = k, value = v, lo = lo, hi = hi, point_rank = pr,
      selected_point = !is.na(pr) & pr <= k,
      best_rank = ifelse(qm, best, NA), worst_rank = ifelse(qm, worst, NA), envelope_status = status,
      stringsAsFactors = FALSE)
  }
}
res <- do.call(rbind, rows)
write.csv(res, file.path(out_dir, "r_reference.csv"), row.names = FALSE)
cat(sprintf("R reference: %d ACS counties, %d rule rows written to %s\n", nrow(acs_r), nrow(res), out_dir))
