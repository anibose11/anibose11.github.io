"""SQL build checks catch mixed releases, mixed value types and duplicate keys (synthetic rows)."""

import duckdb
import pytest

from dop.build import _checks
from dop.config import Paths, project_root

FMT = {
    "measure_id": "DIABETES", "measure_label": "Diagnosed diabetes among adults", "expected_year": "2023",
    "crude_id": "CrdPrv", "crude_label": "Crude prevalence",
    "ageadj_id": "AgeAdjPrv", "ageadj_label": "Age-adjusted prevalence",
}

COLUMNS = ("year VARCHAR, fips VARCHAR, measure_id VARCHAR, measure_label VARCHAR, value_type_id VARCHAR, "
           "value_type_label VARCHAR, unit VARCHAR, value DOUBLE, lcl DOUBLE, ucl DOUBLE, footnote_symbol VARCHAR, "
           "value_raw VARCHAR, lcl_raw VARCHAR, ucl_raw VARCHAR, pop18_raw VARCHAR, pop18_places BIGINT, total_pop_places BIGINT")

GOOD = [
    ("2023", "90001", "DIABETES", "Diagnosed diabetes among adults", "CrdPrv", "Crude prevalence", "%", 12.0, 11.0, 13.0, None, "12.0", "11.0", "13.0", "800", 800, 1000),
    ("2023", "90001", "DIABETES", "Diagnosed diabetes among adults", "AgeAdjPrv", "Age-adjusted prevalence", "%", 10.0, 9.0, 11.0, None, "10.0", "9.0", "11.0", "800", 800, 1000),
]


def _run(rows):
    con = duckdb.connect()
    con.execute(f"CREATE TABLE places_dia ({COLUMNS})")
    con.executemany("INSERT INTO places_dia VALUES (" + ",".join(["?"] * 17) + ")", rows)
    sql = (Paths(project_root()).sql / "02_checks.sql").read_text().format(**FMT)
    failed = {}
    for name, severity, query in _checks(sql):
        if "places_dia" not in query or "JOIN" in query or "places24" in query:
            continue
        n = len(con.execute(query).fetchall())
        if n:
            failed[name] = n
    return failed


def test_clean_rows_pass():
    assert _run(GOOD) == {}


def test_mixed_release_year_fails():
    rows = GOOD + [("2022",) + GOOD[0][1:4] + ("CrdPrv",) + GOOD[0][5:]]
    rows[-1] = rows[-1][:1] + ("90002",) + rows[-1][2:]
    assert "places_single_year_for_measure" in _run(rows)


def test_mislabelled_value_type_fails():
    bad = list(GOOD[1])
    bad[5] = "Crude prevalence"  # age-adjusted id carrying the crude label
    assert "places_value_types_known" in _run([GOOD[0], tuple(bad)])


def test_duplicate_key_fails():
    assert "places_unique_county_measure_type" in _run(GOOD + [GOOD[0]])


def test_interval_not_bracketing_fails():
    bad = list(GOOD[0])
    bad[8] = 12.5
    assert "places_interval_brackets_estimate" in _run([tuple(bad), GOOD[1]])


def test_adult_population_above_total_fails():
    bad = list(GOOD[0])
    bad[15] = 1200
    assert "places_adult_population_le_total" in _run([tuple(bad), GOOD[1]])


def test_unparseable_number_fails():
    bad = list(GOOD[0])
    bad[11] = "12.0x"
    bad[7] = None
    assert "places_numeric_parse" in _run([tuple(bad), GOOD[1]])
