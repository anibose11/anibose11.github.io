"""SDR variance and ACS derivation on synthetic replicate tables (not study data)."""

import zipfile

import numpy as np
import pytest

from dop.acs import ACSLayoutError, REP_COLS, derive, sdr_se


def test_sdr_se_known_value():
    est = np.array([10.0])
    reps = np.array([[11.0] * 40 + [9.0] * 40])
    # sum of squared differences = 80, variance = 4/80 * 80 = 4, SE = 2
    assert sdr_se(est, reps)[0] == pytest.approx(2.0)


def test_sdr_se_equal_replicates_is_zero():
    assert sdr_se(np.array([5.0]), np.full((1, 80), 5.0))[0] == 0.0


def _vrt_csv(table, title, lines):
    header = "TBLID,GEOID,NAME,ORDER,TITLE,ESTIMATE,MOE,CME,SE," + ",".join(REP_COLS)
    rows = [header, f"{table},,,,{title}" + "," * (4 + 80), f"{table},,,,Universe:  x" + "," * (4 + 80)]
    for geoid, name, order, ttl, est, reps, cme in lines:
        rows.append(",".join([table, geoid, f'"{name}"', str(order), ttl, str(est), "0", cme, "0"]
                             + [str(r) for r in reps]))
    return "\n".join(rows) + "\n"


def _write(tmp_path, table, content):
    p = tmp_path / f"{table}.csv.zip"
    with zipfile.ZipFile(p, "w") as zf:
        zf.writestr(f"050/{table}.csv", content)
    return p


def _b05003(geos, adult_reps):
    lines = []
    for (geoid, name), reps in zip(geos, adult_reps):
        cme = "*****" if reps is None else "+/-1"
        r = [100] * 80 if reps is None else reps
        lines += [(geoid, name, 1, "Total:", 250, [250] * 80, "*****"),
                  (geoid, name, 2, "Male:", 120, [120] * 80, "*****"),
                  (geoid, name, 8, "18 years and over:", 100, r, cme),
                  (geoid, name, 13, "Female:", 130, [130] * 80, "*****"),
                  (geoid, name, 19, "18 years and over:", 100, r, cme)]
    return _vrt_csv("B05003", "Sex by Age by Nativity and Citizenship Status", lines)


def _b17001(geos):
    lines = []
    for geoid, name in geos:
        lines += [(geoid, name, 1, "Total:", 200, [200] * 40 + [210] * 40, "+/-5"),
                  (geoid, name, 2, "Income in the past 12 months below poverty level:", 50, [50] * 80, "+/-5")]
    return _vrt_csv("B17001", "Poverty Status in the Past 12 Months by Sex by Age", lines)


GEOS = [("0500000US90001", "Synthetic A, Testland"), ("0500000US90002", "Synthetic B, Testland")]


def test_derive_controlled_and_replicate_based(tmp_path):
    b05 = _write(tmp_path, "B05003", _b05003(GEOS, [None, [101] * 40 + [99] * 40]))
    b17 = _write(tmp_path, "B17001", _b17001(GEOS))
    out, checks = derive(b05, b17, 2024, 1.645, 1.959964)
    a, b = out.iloc[0], out.iloc[1]
    assert a["acs2024_adult"] == 200 and a["acs2024_adult_status"] == "controlled" and a["acs2024_adult_se"] == 0
    # Both 18+ lines move together by +/-1, so the sum moves by +/-2: var = 4/80*80*4 = 16, SE = 4.
    assert b["acs2024_adult_status"] == "sdr" and b["acs2024_adult_se"] == pytest.approx(4.0)
    assert a["acs2024_pov_pct"] == pytest.approx(25.0)
    assert a["acs2024_pov_se"] > 0 and a["acs2024_pov_status"] == "sdr"
    assert out["fips"].tolist() == ["90001", "90002"]


def test_layout_change_fails_loudly(tmp_path):
    bad = _b05003(GEOS, [None, None]).replace("18 years and over:", "18 to 64 years:")
    b05 = _write(tmp_path, "B05003", bad)
    b17 = _write(tmp_path, "B17001", _b17001(GEOS))
    with pytest.raises(ACSLayoutError):
        derive(b05, b17, 2024, 1.645, 1.959964)


def test_zero_percent_poverty_is_flagged_special_case(tmp_path):
    lines = []
    for geoid, name in GEOS:
        lines += [(geoid, name, 1, "Total:", 200, [200] * 40 + [210] * 40, "+/-5"),
                  (geoid, name, 2, "Income in the past 12 months below poverty level:", 0, [0] * 80, "+/-5")]
    b17 = _write(tmp_path, "B17001", _vrt_csv("B17001", "Poverty Status", lines))
    b05 = _write(tmp_path, "B05003", _b05003(GEOS, [None, None]))
    out, _ = derive(b05, b17, 2024, 1.645, 1.959964)
    assert (out["acs2024_pov_status"] == "moe_special_case").all()
    assert out["acs2024_pov_se"].isna().all()
