"""Ranking and envelope logic on small synthetic inputs (not study data)."""

import math

import numpy as np
import pandas as pd
import pytest

from dop.analyze import evaluate
from dop.envelope import BOUNDARY, CORE, OUTSIDE, classify, competition_rank, envelope_ranks, jaccard


def test_competition_rank_shares_better_rank_on_ties():
    assert competition_rank([5, 3, 5, 1]).tolist() == [1, 3, 1, 4]


def test_competition_rank_rejects_missing():
    with pytest.raises(ValueError):
        competition_rank([1.0, float("nan")])


def test_ties_at_cutoff_are_all_selected():
    r = competition_rank([9.9, 9.9, 9.9, 8.0])
    assert (r <= 1).sum() == 3


def test_envelope_ranks_hand_example():
    lo = np.array([10.0, 8.0, 1.0])
    hi = np.array([12.0, 11.0, 2.0])
    best, worst = envelope_ranks(lo, hi)
    assert best.tolist() == [1, 1, 3]
    assert worst.tolist() == [2, 2, 3]
    assert classify(best, worst, 1).tolist() == [BOUNDARY, BOUNDARY, OUTSIDE]
    assert classify(best, worst, 2).tolist() == [CORE, CORE, OUTSIDE]


def test_degenerate_interval_does_not_count_itself():
    best, worst = envelope_ranks(np.array([5.0, 5.0]), np.array([5.0, 5.0]))
    assert best.tolist() == [1, 1]
    assert worst.tolist() == [1, 1]


def test_envelope_rejects_inverted_bounds():
    with pytest.raises(ValueError):
        envelope_ranks(np.array([2.0]), np.array([1.0]))


def test_competitor_masks():
    # County 2 is not a best-case competitor, so it cannot push county 0 down in the best case.
    lo = np.array([5.0, 1.0, 9.0])
    hi = np.array([6.0, 2.0, 10.0])
    best, worst = envelope_ranks(lo, hi, best_mask=np.array([True, True, False]))
    assert best[0] == 1
    assert worst[0] == 2


def test_jaccard_edges():
    assert jaccard({1, 2}, {2, 3}) == pytest.approx(1 / 3)
    assert math.isnan(jaccard(set(), set()))


def _synthetic_frame(n=200, seed=7):
    rng = np.random.default_rng(seed)
    prev = np.round(rng.uniform(6, 20, n), 1)
    half = np.round(rng.uniform(0.3, 2.5, n), 1)
    pop = rng.integers(500, 500000, n).astype(float)
    pov = rng.uniform(5, 35, n)
    pse = rng.uniform(0.3, 4, n)
    return pd.DataFrame({
        "fips": [f"9{i:04d}" for i in range(n)],
        "prev": prev, "prev_lcl": prev - half, "prev_ucl": prev + half,
        "burden": prev / 100 * pop,
        "burden_lo": (prev - half) / 100 * pop * 0.98,
        "burden_hi": (prev + half) / 100 * pop * 1.02,
        "elig_point": pov >= 20,
        "elig_certain": pov - 1.96 * pse >= 20,
        "elig_possible": pov + 1.96 * pse >= 20,
    })


@pytest.mark.parametrize("rule", ["PREV", "BURDEN", "EQUITY"])
@pytest.mark.parametrize("k", [1, 5, 25])
def test_invariants_core_subset_selected_subset_possible(rule, k):
    res = evaluate(_synthetic_frame(), rule, k)
    core = set(res.loc[res.envelope_status == CORE, "fips"])
    possible = set(res.loc[res.envelope_status.isin([CORE, BOUNDARY]), "fips"])
    selected = set(res.loc[res.selected_point, "fips"])
    assert core <= selected <= possible
    ranked = res[res.eligible_point]
    assert (ranked.best_rank <= ranked.point_rank).all()
    assert (ranked.point_rank <= ranked.worst_rank).all()


def test_equity_ineligible_county_is_outside():
    f = _synthetic_frame()
    res = evaluate(f, "EQUITY", 25)
    never = res[~res.eligible_possible]
    assert (never.envelope_status == OUTSIDE).all()
    assert not never.selected_point.any()
    # Certain eligibility is required for the core.
    assert res[(res.envelope_status == CORE)].eligible_certain.all()
