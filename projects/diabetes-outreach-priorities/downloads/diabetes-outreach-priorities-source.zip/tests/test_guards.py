"""Guards that protect reproducibility and the public archive (synthetic inputs only)."""

import hashlib
import http.server
import json
import threading
from pathlib import Path

import pytest

import dop.acquire as acquire_mod
import dop.build as build_mod
from dop.acquire import AcquisitionError
from dop.build import BuildCheckError
from dop.facts import Facts
from dop.package import scan, source_files
from dop.render import check_claim_guards

BODY = b"Year,LocationID\n2023,90001\n"


class _Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        self.send_response(200)
        self.send_header("Content-Type", "text/csv")
        self.send_header("Content-Length", str(len(BODY)))
        self.end_headers()
        self.wfile.write(BODY)

    def log_message(self, *args):
        pass


def _cfg(url):
    return {"sources": {"demo": {"title": "t", "publisher": "p", "url": url, "expect": "csv", "filename": "demo.csv",
                                 "min_bytes": 1, "required_columns": ["Year", "LocationID"]}},
            "_sha256": "x"}


def test_acquire_refuses_changed_source_without_refresh(tmp_path, monkeypatch):
    server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/demo.csv"
        manifest = {"schema": "dop-source-manifest/1", "sources": {"demo": {"sha256": "0" * 64}}}
        (tmp_path / "source_manifest.json").write_text(json.dumps(manifest))
        monkeypatch.setattr(acquire_mod, "project_root", lambda: tmp_path)
        monkeypatch.setattr(acquire_mod, "load_config", lambda: _cfg(url))
        with pytest.raises(AcquisitionError, match="differs from the manifest"):
            acquire_mod.acquire()
        assert not (tmp_path / "data" / "raw" / "demo" / "demo.csv").exists()
        assert json.loads((tmp_path / "source_manifest.json").read_text()) == manifest
        assert not list((tmp_path / "data" / "raw" / "demo").glob("*.part"))
        # Accepting the new snapshot deliberately records the previous hash.
        acquire_mod.acquire(refresh=True)
        entry = json.loads((tmp_path / "source_manifest.json").read_text())["sources"]["demo"]
        assert entry["sha256"] == hashlib.sha256(BODY).hexdigest() and entry["previous_sha256"] == "0" * 64
    finally:
        server.shutdown()


def test_build_refuses_raw_file_that_differs_from_manifest(tmp_path, monkeypatch):
    raw = tmp_path / "data" / "raw" / "demo"
    raw.mkdir(parents=True)
    (raw / "demo.csv").write_bytes(BODY)
    (tmp_path / "source_manifest.json").write_text(json.dumps({"sources": {"demo": {"sha256": "f" * 64}}}))
    cfg = _cfg("unused")
    cfg["analysis"] = {}
    cfg["geography"] = {}
    monkeypatch.setattr(build_mod, "project_root", lambda: tmp_path)
    monkeypatch.setattr(build_mod, "load_config", lambda: cfg)
    with pytest.raises(BuildCheckError, match="hash differs"):
        build_mod.build()


def test_source_archive_ships_only_allowlisted_files(tmp_path):
    kept = ("src/dop/x.py", "docs/analysis_plan.md", "templates/site_index.md", "data/interim/acs2024_county.csv",
            "manuscript/manuscript_template.md")
    left_out = ("docs/notes.md", "drafts/letter.md", "tools/local.py", "handoff/record.md", ".local/settings.json",
                "data/raw/demo/demo.csv", "manuscript/manuscript.md", "manuscript/manuscript.docx")
    for rel in kept + left_out:
        p = tmp_path / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("x\n")
    names = {str(p.relative_to(tmp_path)) for p in source_files(tmp_path)}
    assert set(kept) <= names
    assert not names & set(left_out)


def test_public_scan_flags_paths_emails_and_blocked_phrases(tmp_path):
    files = []
    # Path and address strings are assembled at run time so this test file passes the same scan.
    for name, text in (("a.md", "see /" + "Users/someone/project"), ("b.md", "contact x.y@" + "gmail.com"),
                       ("c.md", "draft note: internal only"), ("d.md", "plain text")):
        p = tmp_path / name
        p.write_text(text)
        files.append(p)
    problems = scan(files, tmp_path, ["internal only"])
    assert len(problems) == 3 and not any(p.startswith("d.md") for p in problems)


def test_claim_guards_stop_wording_that_no_longer_matches(tmp_path):
    F = Facts()
    values = {"k10_prev_burden_inter": 0, "k25_prev_burden_inter": 0, "k50_prev_burden_inter": 0, "k10_all_three": 0,
              "k25_all_three": 0, "k50_all_three": 0, "k10_core_all_three": 0, "k25_core_all_three": 0,
              "k50_core_all_three": 0, "k10_prev_core": 0, "k25_prev_core": 0, "k50_prev_core": 1,
              "k25_prev_selected": 26, "aligned_selected_ct": 0, "aligned_min_j": 1.0, "aligned_burden_core_changes": 0,
              "k25_burden_core_prev_outside": 17, "k25_burden_core": 17, "moe_povden_remaining": 10,
              "moe_povden_mismatch_reps_equal": 10, "k25_burden_burden_sum": 6.5e6, "k25_prev_burden_sum": 4.0e4}
    for k, v in values.items():
        F.add(k, v, str(v), "s", "s", "c")
    check_claim_guards(F)
    F.items["k25_prev_burden_inter"]["value"] = 1
    with pytest.raises(RuntimeError, match="wording no longer matches"):
        check_claim_guards(F)
