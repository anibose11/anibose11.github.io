"""Acquisition guards: error pages, bad headers and unsafe archives are rejected."""

import http.server
import threading
import zipfile

import pytest

from dop.acquire import AcquisitionError, check_csv_header, http_download, looks_like_html, validate_zip

MISSING_KEY_PAGE = b'<html style="font-size: 14px;">\n\n<head>\n    <title>Missing Key</title>\n</head><body>x</body></html>'


def test_html_error_page_detected():
    assert looks_like_html(MISSING_KEY_PAGE)
    assert not looks_like_html(b"Year,StateAbbr\n2023,MD\n")


def test_csv_header_missing_column_rejected():
    with pytest.raises(AcquisitionError):
        check_csv_header(b"Year,StateAbbr\n", ["Year", "LocationID"])
    check_csv_header(b"\xef\xbb\xbfYear,LocationID\n", ["Year", "LocationID"])


def _zip(tmp_path, members):
    p = tmp_path / "x.zip"
    with zipfile.ZipFile(p, "w") as zf:
        for name, data in members.items():
            zf.writestr(name, data)
    return p


def test_zip_path_traversal_rejected(tmp_path):
    p = _zip(tmp_path, {"../evil.csv": "a,b\n1,2\n"})
    with pytest.raises(AcquisitionError):
        validate_zip(p, ["../evil.csv"], None)


def test_zip_unexpected_members_rejected(tmp_path):
    p = _zip(tmp_path, {"050/B05003.csv": "TBLID,GEOID\n", "extra.txt": "x"})
    with pytest.raises(AcquisitionError):
        validate_zip(p, ["050/B05003.csv"], None)


def test_zip_html_member_rejected(tmp_path):
    p = _zip(tmp_path, {"050/B05003.csv": MISSING_KEY_PAGE.decode()})
    with pytest.raises(AcquisitionError):
        validate_zip(p, ["050/B05003.csv"], None)


def test_valid_zip_accepted(tmp_path):
    p = _zip(tmp_path, {"050/B05003.csv": "TBLID,GEOID,ORDER\nB05003,0500000US24033,1\n"})
    info = validate_zip(p, ["050/B05003.csv"], ["TBLID", "GEOID"])
    assert info[0]["member"] == "050/B05003.csv" and len(info[0]["sha256"]) == 64


class _Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        body = MISSING_KEY_PAGE
        self.send_response(200)
        # Deliberately mislabelled: an HTML error page served with a CSV-compatible type.
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def test_http_download_rejects_error_page_with_status_200(tmp_path):
    server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        dest = tmp_path / "out.csv"
        with pytest.raises(AcquisitionError):
            http_download(f"http://127.0.0.1:{server.server_port}/data.csv", dest, params=None,
                          expect="csv", min_bytes=1, retries=1)
        assert not dest.exists()
        assert not dest.with_suffix(".csv.part").exists()
    finally:
        server.shutdown()


class _CSVHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802
        body = b"Year,LocationID\n2023,24033\n"
        self.send_response(200)
        self.send_header("Content-Type", "text/csv")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def test_http_download_leaves_destination_untouched_until_commit(tmp_path):
    server = http.server.HTTPServer(("127.0.0.1", 0), _CSVHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        dest = tmp_path / "out.csv"
        dest.write_text("previous snapshot\n")
        prov = http_download(f"http://127.0.0.1:{server.server_port}/d.csv", dest, params=None, expect="csv",
                             min_bytes=1, required_columns=["Year", "LocationID"], retries=1)
        assert dest.read_text() == "previous snapshot\n"
        from pathlib import Path
        assert Path(prov["_tmp"]).read_bytes().startswith(b"Year,LocationID")
        assert len(prov["sha256"]) == 64
    finally:
        server.shutdown()
