"""Render the manuscript, supplementary file and planning brief from templates and outputs.

Numbers come only from dop.facts (named, traceable values) or from tables read
directly from outputs/. Output formats: Markdown, standalone HTML and DOCX.
"""

from __future__ import annotations

import html
import json
import re
from pathlib import Path

import markdown as md_lib
import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt

from .facts import fmt_dec, fmt_int, fmt_pct, resolve
from .references import REFERENCES

RULE_LABEL = {"PREV": "Prevalence", "BURDEN": "Estimated burden", "EQUITY": "High-poverty prevalence"}


def md_table(df: pd.DataFrame, align: list[str] | None = None) -> str:
    cols = list(df.columns)
    align = align or ["l"] + ["r"] * (len(cols) - 1)
    sep = ["---:" if a == "r" else "---" for a in align]
    lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(sep) + " |"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(v) for v in r.tolist()) + " |")
    return "\n".join(lines)


def table1(manifest: dict) -> str:
    s = manifest["sources"]
    rows = [
        ["CDC PLACES County Data, 2025 release", "Crude and age-adjusted prevalence of diagnosed diabetes among adults with 95% limits, and adult population (TotalPop18plus)",
         "BRFSS 2023 and Census 2023 county population estimates", f"data.cdc.gov swc5-untb [20], file hash {s['places_2025_county']['sha256'][:12]}"],
        ["CDC PLACES County Data, 2024 release (descriptive comparison only)", "Crude prevalence of diagnosed diabetes and adult population",
         "BRFSS 2022", f"data.cdc.gov fu4u-a9bh [31], file hash {s['places_2024_county_diabetes']['sha256'][:12]}"],
        ["Census Bureau Vintage 2023 county characteristics (CC-EST2023-AGESEX)", "Population aged 18 and older (AGE18PLUS_TOT), used to check the PLACES adult population",
         "July 1, 2023", f"www2.census.gov [22], file hash {s['pep_v2023_agesex']['sha256'][:12]}"],
        ["ACS 5-year variance replicate tables B05003 and B17001", "Adults 18 and older, people below the poverty level and the poverty universe, with 80 replicate estimates",
         "2020-2024 (primary) and 2019-2023 (aligned check)",
         f"www2.census.gov [23], file hashes {s['acs5_2024_b05003_vrt']['sha256'][:12]} (2020-2024 B05003), "
         f"{s['acs5_2024_b17001_vrt']['sha256'][:12]} (2020-2024 B17001), {s['acs5_2023_b05003_vrt']['sha256'][:12]} (2019-2023 B05003), "
         f"{s['acs5_2023_b17001_vrt']['sha256'][:12]} (2019-2023 B17001)"],
    ]
    df = pd.DataFrame(rows, columns=["Source", "Quantities used", "Reference period", "Identifier and file hash (first 12 characters)"])
    return ("**Table 1. Data sources.**\n\n" + md_table(df, ["l", "l", "l", "l"])
            + "\n\nAll files were accessed on 7 October 2026. File hashes are the first 12 characters of the SHA-256 hash recorded in the source manifest.")


def table2(env: pd.DataFrame, prof: pd.DataFrame) -> str:
    rows = []
    for r in ["PREV", "BURDEN", "EQUITY"]:
        for k in (10, 25, 50):
            e = env[(env.rule == r) & (env.capacity == k)].iloc[0]
            p = prof[(prof.rule == r) & (prof.capacity == k)].iloc[0]
            share = p.share_of_frame_estimated_burden
            rows.append([RULE_LABEL[r], k, fmt_int(e.n_ranked_point), fmt_int(e.n_selected_point), fmt_int(e.n_core), fmt_int(e.n_boundary),
                         f"{fmt_int(p.sum_estimated_burden)} ({fmt_pct(share, 2 if share < 0.01 else 1)})"])
    df = pd.DataFrame(rows, columns=["Rule", "Capacity", "Counties ranked", "Selected", "Core", "Boundary",
                                     "Estimated adults with diagnosed diabetes in selection (share of frame)"])
    hp = env[(env.rule == "EQUITY") & (env.scope == "national")].iloc[0]
    return ("**Table 2. Selected, core and boundary counties by rule and capacity.**\n\n"
            + md_table(df, ["l", "r", "r", "r", "r", "r", "r"])
            + "\n\nSelected counts exceed the capacity when counties tie at the cutoff. Core and boundary are defined in Methods. "
            f"For high-poverty prevalence, counties ranked are those with poverty of at least 20% at the point estimate ({fmt_int(hp.n_ranked_point)}). "
            f"Boundary counties can come from all counties whose ACS 95% upper poverty bound reaches 20% ({fmt_int(hp.n_eligible_possible)}), "
            f"and core counties need a lower bound of at least 20% ({fmt_int(hp.n_eligible_certain)}), so the boundary count can exceed the number ranked. "
            "The last column is descriptive and was added after the primary results.")


def table3(ovl: pd.DataFrame) -> str:
    rows = []
    for k in (10, 25, 50):
        row = [k]
        for x, y in (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")):
            o = ovl[(ovl.capacity == k) & (ovl.scenario == "point") & (ovl.set_a == x) & (ovl.set_b == y)].iloc[0]
            row.append(f"{int(o.n_intersection)} of {int(o.n_union)} ({fmt_dec(o.jaccard, 2)})")
        rows.append(row)
    df = pd.DataFrame(rows, columns=["Capacity", "Prevalence and burden", "Prevalence and high-poverty prevalence",
                                     "Burden and high-poverty prevalence"])
    return ("**Table 3. Overlap between the point-estimate selections of the three rules.**\n\n" + md_table(df, ["r", "r", "r", "r"])
            + "\n\nEach cell gives the counties in both sets, of the counties in either set, with the Jaccard index in parentheses.")


def references_md() -> str:
    return "\n".join(f"{i}. {ref}" for i, ref in enumerate(REFERENCES, 1))


def check_citations(text: str) -> dict:
    body = text.split("## References")[0]
    cited = set()
    for grp in re.findall(r"\[(\d+(?:\s*[-,]\s*\d+)*)\]", body):
        for part in grp.split(","):
            part = part.strip()
            if "-" in part:
                a, b = (int(x) for x in part.split("-"))
                cited.update(range(a, b + 1))
            else:
                cited.add(int(part))
    n = len(REFERENCES)
    out_of_range = sorted(c for c in cited if c < 1 or c > n)
    uncited = sorted(set(range(1, n + 1)) - cited)
    order, seen = [], set()
    for grp in re.findall(r"\[(\d+(?:\s*[-,]\s*\d+)*)\]", body):
        for part in grp.split(","):
            ends = [int(x) for x in part.strip().split("-")]
            for num in range(ends[0], ends[-1] + 1):
                if num not in seen:
                    seen.add(num)
                    order.append(num)
    in_order = order == list(range(1, len(order) + 1))
    if not in_order:
        raise ValueError(f"references are not numbered in order of first citation: {order}")
    if out_of_range or uncited:
        raise ValueError(f"citation problems: out_of_range={out_of_range} uncited={uncited}")
    return {"n_references": n, "n_cited": len(cited), "first_citation_order_sequential": in_order}


# ---------------------------------------------------------------- HTML

PAGE_CSS = """
:root{--bg:#fbfbf9;--ink:#1b1b1a;--ink2:#45443f;--muted:#64635d;--rule:#dcdad3;--accent:#1f5fa8;--plate:#f2f1ec;color-scheme:light}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
main{max-width:760px;margin:0 auto;padding:24px 16px 80px}
main.wide{max-width:1100px}
h1{font-size:clamp(26px,4vw,34px);line-height:1.2;margin:8px 0 12px;text-wrap:balance}
h2{font-size:22px;line-height:1.3;margin:40px 0 8px;padding-top:12px;border-top:1px solid var(--rule);text-wrap:balance}
h3{font-size:18px;margin:28px 0 6px}
p,li{text-wrap:pretty}
li,p,figcaption{overflow-wrap:anywhere}
.table-wrap table.wide{min-width:600px}
p.tcap{margin:20px 0 0;padding:8px;font-size:14px;color:var(--ink2);background:var(--plate);border:1px solid var(--rule);border-bottom:0}
a{color:var(--accent);text-underline-offset:2px}
a:hover{color:#123f73}
a:focus-visible,button:focus-visible,select:focus-visible,input:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.meta{color:var(--muted);font-size:14px}
.table-wrap{overflow-x:auto;margin:12px 0 20px;border:1px solid var(--rule);background:#fff}
table{border-collapse:collapse;width:100%;font-size:14px;font-variant-numeric:tabular-nums}
th,td{padding:6px 8px;border-bottom:1px solid var(--rule);vertical-align:top;text-align:left}
th{color:var(--ink2);font-weight:600;background:var(--plate)}
td[style*="right"],th[style*="right"]{text-align:right}
caption.tcap{caption-side:top;text-align:left;padding:8px;font-size:14px;color:var(--ink2);background:var(--plate)}
figure{margin:24px 0;max-width:100%}
figure img{width:100%;height:auto;background:#fcfcfb;border:1px solid var(--rule)}
figcaption{font-size:14px;color:var(--ink2);margin-top:6px}
code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.88em;background:var(--plate);padding:1px 4px;overflow-wrap:anywhere}
pre{background:var(--plate);padding:12px;overflow-x:auto;font-size:14px}
pre code{background:none;padding:0}
.skip{position:absolute;left:-999px}.skip:focus{left:16px;top:8px;background:var(--bg);padding:8px;z-index:2}
nav.crumbs{font-size:14px;color:var(--muted);margin-bottom:8px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:16px 0}
.stat{border:1px solid var(--rule);background:#fff;padding:12px}
.stat b{display:block;font-size:26px;line-height:1.2}
.stat span{font-size:14px;color:var(--ink2)}
ul.files{padding-left:20px}
"""


def html_page(title: str, body_html: str, description: str, extra_head: str = "", crumbs: str = "") -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(description)}">
<style>{PAGE_CSS}</style>
{extra_head}
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<main id="main">
{crumbs}
{body_html}
</main>
</body>
</html>
"""


def md_to_html(text: str) -> str:
    out = md_lib.markdown(text, extensions=["tables", "sane_lists", "attr_list"])
    out = out.replace("<table>", '<div class="table-wrap" tabindex="0" role="region" aria-label="Table"><table>')
    out = out.replace("</table>", "</table></div>")
    return out


# ---------------------------------------------------------------- DOCX

def _add_runs(par, text: str):
    for part in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            par.add_run(part[2:-2]).bold = True
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            par.add_run(part[1:-1]).italic = True
        elif part.startswith("`") and part.endswith("`"):
            r = par.add_run(part[1:-1])
            r.font.name = "Courier New"
        else:
            par.add_run(part)


def _line_and_page_numbers(doc):
    sect = doc.sections[0]
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    sect._sectPr.append(ln)
    p = sect.footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run()
    for tag, txt in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            fc = OxmlElement("w:fldChar")
            fc.set(qn("w:fldCharType"), tag)
            run._r.append(fc)
        else:
            it = OxmlElement("w:instrText")
            it.set(qn("xml:space"), "preserve")
            it.text = txt
            run._r.append(it)


def md_to_docx(text: str, out: Path, figures: dict[str, Path] | None = None, double_space: bool = True,
               letter: bool = False, title: str | None = None):
    """Markdown subset to DOCX. letter=True keeps line breaks inside paragraphs (addresses, signatures)
    and omits line numbering, which manuscripts need and letters do not."""
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.paragraph_format.line_spacing = 2.0 if double_space else 1.15
    if not letter:
        _line_and_page_numbers(doc)
    figures = figures or {}
    lines = text.splitlines()
    i = 0
    para_buf: list[str] = []

    def flush():
        if para_buf:
            p = doc.add_paragraph()
            if letter:
                for j, s in enumerate(para_buf):
                    _add_runs(p, s.strip())
                    if j < len(para_buf) - 1:
                        p.add_run().add_break()
            else:
                _add_runs(p, " ".join(s.strip() for s in para_buf))
            para_buf.clear()

    while i < len(lines):
        line = lines[i]
        if not line.strip():
            flush()
            i += 1
            continue
        m = re.match(r"^(#{1,3}) (.*)", line)
        if m:
            flush()
            level = len(m.group(1))
            doc.add_heading(m.group(2), level=0 if level == 1 else level - 1)
            i += 1
            continue
        if line.startswith("|"):
            flush()
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"
            for ri, r in enumerate(rows):
                for ci, c in enumerate(r):
                    cell = t.cell(ri, ci)
                    cell.text = ""
                    pp = cell.paragraphs[0]
                    pp.paragraph_format.line_spacing = 1.0
                    run_text = c
                    _add_runs(pp, run_text)
                    for run in pp.runs:
                        run.font.size = Pt(9)
                        if ri == 0:
                            run.bold = True
            doc.add_paragraph()
            continue
        mfig = re.match(r"^\*\*(Figure \d+)\.", line)
        if mfig and mfig.group(1) in figures:
            flush()
            doc.add_picture(str(figures[mfig.group(1)]), width=Inches(6.3))
        mb = re.match(r"^(\s*)[-*] (.*)", line)
        mn = re.match(r"^(\s*)(\d+)\. (.*)", line)
        if mb:
            flush()
            p = doc.add_paragraph(style="List Bullet")
            _add_runs(p, mb.group(2))
            i += 1
            continue
        if mn:
            flush()
            p = doc.add_paragraph()
            _add_runs(p, f"{mn.group(2)}. {mn.group(3)}")
            i += 1
            continue
        para_buf.append(line)
        i += 1
    flush()
    out.parent.mkdir(parents=True, exist_ok=True)
    import datetime as _dt
    fixed = _dt.datetime(2026, 10, 7, 0, 0, 0)  # fixed dates keep reruns byte-identical
    doc.core_properties.created = fixed
    doc.core_properties.modified = fixed
    doc.core_properties.last_modified_by = "Animesh Bose"
    doc.core_properties.revision = 1
    doc.core_properties.author = "Animesh Bose"
    doc.core_properties.title = title or text.splitlines()[0].lstrip("# ").strip()
    doc.core_properties.comments = ""
    doc.core_properties.subject = ""
    doc.core_properties.keywords = ""
    doc.save(out)
    from .editorial_format import finish
    out.write_bytes(finish(out.read_bytes(), supplement=out.name.startswith(("supplement", "ESM2")))[0])
    normalize_container(out)


def normalize_container(path: Path) -> None:
    """Rewrite a DOCX or XLSX container with fixed entry timestamps so identical content gives identical bytes."""
    import zipfile
    tmp = path.with_suffix(path.suffix + ".tmp")
    with zipfile.ZipFile(path) as src, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as dst:
        for item in src.infolist():
            info = zipfile.ZipInfo(item.filename, date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = item.external_attr
            data = src.read(item.filename)
            if item.filename == "docProps/core.xml":
                text = data.decode("utf-8")
                for tag in ("created", "modified"):
                    text = re.sub(rf"(<dcterms:{tag}[^>]*>)[^<]*(</dcterms:{tag}>)", r"\g<1>2026-10-07T00:00:00Z\g<2>", text)
                data = text.encode("utf-8")
            dst.writestr(info, data)
    tmp.replace(path)


def word_counts(text: str) -> dict:
    """Whitespace-delimited words as a word processor counts them, excluding headings and section labels."""
    def wc(s: str) -> int:
        body = "\n".join(line for line in s.splitlines() if not line.lstrip().startswith("#"))
        body = re.sub(r"\*\*(Background|Methods|Results|Conclusions):\*\*", "", body)
        return len(body.split())
    abstract = text.split("## Abstract")[1].split("**Keywords:**")[0]
    main = text.split("## Background")[1].split("## List of abbreviations")[0]
    return {"abstract_words": wc(abstract), "main_text_words": wc(main)}


# ---------------------------------------------------------------- supplement

def mismatch_note(b: dict) -> str:
    notes = []
    for v, d in b["acs_derivation"].items():
        for line, st in d["published_moe_reproduction"].items():
            n_mis = st["n_not_controlled"] - st["n_not_controlled_within_1"]
            if n_mis:
                table, ln = line.split("_line")
                k_eq = st["n_mismatch_with_all_replicates_equal_estimate"]
                which = f"In all {k_eq}" if k_eq == n_mis else f"In {k_eq} of them"
                notes.append(f"In ACS {int(v) - 4}-{v} {table} line {ln}, {n_mis} cells differed. {which}, all 80 replicate "
                             f"estimates equaled the published estimate (replicate margin 0), while the published margins were "
                             f"{fmt_int(st['mismatch_published_moe_min'])} to {fmt_int(st['mismatch_published_moe_max'])} persons")
    if not notes:
        return "All uncontrolled cells reproduced the published margin of error within 1."
    return ("Some cells did not reproduce. " + ". ".join(notes) + ". The Census Bureau's documentation notes that "
            "user-derived margins occasionally differ from published ones. These cells are poverty denominators, whose "
            "uncertainty has a negligible effect on the poverty-rate bounds.")


def supplement_md(root: Path, facts: dict[str, str]) -> str:
    t = root / "outputs" / "tables"
    p = root / "data" / "processed"
    parts = ["# Additional file 1: Supplementary methods and tables",
             "",
             "Stability of county diabetes outreach priorities under alternative need definitions and published uncertainty",
             "",
             f"Run identifier {facts['run_id']}. All tables are generated from the files named under each table.",
             ""]
    parts += ["## S1. Analysis plan, exposure log and amendments", "",
              "The plan below was written before any county value was ranked. It is reproduced from docs/analysis_plan.md.", ""]
    plan = (root / "docs" / "analysis_plan.md").read_text()
    plan = re.sub(r"^# Analysis plan\n", "", plan)
    plan = re.sub(r"(?m)^## ", "### ", plan)
    parts += [plan.strip(), "",
              "Rule codes used in the plan and in the result files: PREV = prevalence, BURDEN = estimated burden "
              "and EQUITY = high-poverty prevalence.", ""]

    allc = pd.read_csv(p / "county_all.csv", dtype={"fips": str})
    ex = allc[allc.frame_status != "in_frame"].groupby(["frame_status", "state_abbr"]).size().reset_index(name="Locations")
    ex.columns = ["Status", "State", "Locations"]
    parts += ["## S2. Exclusions from the analysis frame", "",
              "**Table S1. PLACES 2025 locations not in the analysis frame, by reason.** Source: data/processed/county_all.csv.", "",
              md_table(ex, ["l", "l", "r"]), ""]
    geo = pd.read_csv(p / "geography_reconciliation.csv", dtype={"fips": str})
    g = geo.groupby("source").agg(Locations=("fips", "size"), Example=("name", "first")).reset_index()
    g.columns = ["Census source", "Locations without a PLACES match", "Example"]
    parts += ["**Table S2. Census locations without a matching PLACES county.** All are Puerto Rico municipios, which PLACES does not cover. Source: data/processed/geography_reconciliation.csv.", "",
              md_table(g, ["l", "r", "l"]), ""]

    b = json.loads((p / "build_checks.json").read_text())
    rec = b["reconciliation"]
    rows = []
    for v, d in b["acs_derivation"].items():
        for line, s in d["published_moe_reproduction"].items():
            table, ln = line.split("_line")
            rows.append([f"{int(v) - 4}-{v}", f"{table} line {ln}", fmt_int(s["n_not_controlled"]), fmt_int(s["n_not_controlled_within_1"]),
                         fmt_int(s["max_abs_diff_not_controlled"]), fmt_int(s["n_controlled"])])
    df = pd.DataFrame(rows, columns=["ACS vintage", "Table and line", "Uncontrolled cells", "Replicate margin of error within 1 of published",
                                     "Largest difference", "Controlled cells"])
    a = rec["acs2024_adult_vs_places_adult"]
    parts += ["## S3. Source reconciliation", "",
              f"The PLACES adult population equaled the Census Vintage 2023 adult estimate (CC-EST2023-AGESEX, YEAR 5, AGE18PLUS_TOT) for {facts['pep_match']} frame counties. "
              f"The ACS 2020-2024 adult estimate differed from it by a median absolute {fmt_pct(a['median_abs_relative_difference'])} "
              f"(90th percentile {fmt_pct(a['p90_abs_relative_difference'])}, maximum {fmt_pct(a['max_abs_relative_difference'])}), and the Vintage 2023 value lay outside the ACS 95% range for "
              f"{fmt_int(a['n_places_adult_outside_acs_95pct_range'])} counties, which reflects the different reference periods of a July 2023 estimate and a 2020-2024 period estimate. "
              f"In the frame, {fmt_int(rec['acs_adult_status_in_frame'].get('controlled', 0))} ACS adult totals were population-controlled and carry no sampling error.",
              "",
              "**Table S3. Reproduction of published ACS margins of error from the variance replicates.** Source: data/processed/build_checks.json.", "",
              md_table(df, ["l", "l", "r", "r", "r", "r"]), "",
              mismatch_note(b), ""]

    scn = pd.read_csv(t / "scenario_overlap.csv")
    scn = scn[["rule", "capacity", "set_b", "n_a", "n_b", "n_intersection", "jaccard"]].copy()
    scn["rule"] = scn["rule"].map(RULE_LABEL)
    scn["set_b"] = scn["set_b"].str.replace("_", " ")
    scn["jaccard"] = scn["jaccard"].map(lambda x: fmt_dec(x, 2))
    scn.columns = ["Rule", "Capacity", "Scenario compared with point estimates", "Point set", "Scenario set", "Both", "Jaccard"]
    parts += ["## S4. Point estimates compared with bound scenarios", "",
              "**Table S4. Overlap between each rule's point-estimate selection and its scenario selections.** Source: outputs/tables/scenario_overlap.csv.", "",
              md_table(scn, ["l", "r", "l", "r", "r", "r", "r"]), ""]

    al = pd.read_csv(t / "robustness_aligned.csv")
    al2 = al[["rule", "capacity", "n_a", "n_b", "n_intersection", "jaccard", "core_primary", "core_aligned", "boundary_primary", "boundary_aligned"]].copy()
    al2["rule"] = al2["rule"].map(RULE_LABEL)
    al2["jaccard"] = al2["jaccard"].map(lambda x: fmt_dec(x, 2))
    al2.columns = ["Rule", "Capacity", "Primary set", "Aligned set", "Both", "Jaccard", "Core, primary", "Core, aligned", "Boundary, primary", "Boundary, aligned"]
    parts += ["## S5. Strictly aligned geography and reference period", "",
              f"The aligned subset contains {facts['aligned_counties']} counties (Connecticut's planning regions excluded) and uses ACS 2019-2023 for poverty and the adult range.", "",
              "**Table S5. Primary and aligned-subset selections.** Source: outputs/tables/robustness_aligned.csv.", "",
              md_table(al2, ["l"] + ["r"] * 9), ""]

    pr = pd.read_csv(t / "prior_release_comparison.csv")
    pr2 = pr[["rule", "capacity", "n_a", "n_b", "n_intersection", "jaccard", "n_KY_PA_in_2024_full_frame_selection"]].copy()
    pr2["rule"] = pr2["rule"].map(RULE_LABEL)
    pr2["jaccard"] = pr2["jaccard"].map(lambda x: fmt_dec(x, 2))
    pr2.columns = ["Rule", "Capacity", "2025 set", "2024 set (common counties)", "Both", "Jaccard", "Kentucky and Pennsylvania counties in the 2024 full-frame selection"]
    parts += ["## S6. Descriptive comparison with the PLACES 2024 release", "",
              "The 2024 release uses BRFSS 2022 and includes Kentucky and Pennsylvania. The comparison is descriptive and is not a validation. The high-poverty rule uses the same ACS 2020-2024 poverty criterion as the primary analysis. Applying it to the 2024 release was added after the primary results (plan amendment 2).", "",
              "**Table S6. Overlap of 2025 and 2024 selections among counties in both releases, and Kentucky and Pennsylvania counties selected in the full 2024 frame.** Source: outputs/tables/prior_release_comparison.csv.", "",
              md_table(pr2, ["l"] + ["r"] * 6), ""]

    ws = pd.read_csv(t / "within_state_summary.csv")
    cols = ["state_abbr", "n_frame_counties", "all_units_no_selection", "PREV_n_core", "PREV_n_boundary", "BURDEN_n_core",
            "BURDEN_n_boundary", "EQUITY_n_ranked", "EQUITY_n_core", "EQUITY_n_boundary", "jaccard_PREV_BURDEN", "jaccard_PREV_EQUITY"]
    w2 = ws[cols].copy()
    w2["all_units_no_selection"] = w2["all_units_no_selection"].map({True: "yes", False: "no"})
    for c in ("jaccard_PREV_BURDEN", "jaccard_PREV_EQUITY"):
        w2[c] = w2[c].map(lambda x: "" if pd.isna(x) else fmt_dec(x, 2))
    w2.columns = ["State", "Frame counties", "All units shown", "Prevalence core", "Prevalence boundary", "Burden core", "Burden boundary",
                  "High-poverty counties (point estimate)", "High-poverty core", "High-poverty boundary", "Jaccard prevalence and burden", "Jaccard prevalence and high-poverty"]
    parts += ["## S7. Within-state results at capacity 5", "",
              "**Table S7. Within-state selections.** States with five or fewer frame counties show all units and are excluded from summaries. "
              "High-poverty counties are those with poverty of at least 20% at the point estimate. High-poverty boundary counties can include any county whose ACS 95% upper poverty bound reaches 20%, so the boundary count can exceed the number of high-poverty counties. "
              "Source: outputs/tables/within_state_summary.csv.", "",
              md_table(w2, ["l"] + ["r"] * 11), ""]

    ctab = pd.read_csv(t / "county_priority_table.csv", dtype={"fips": str})
    parts += ["## S8. Selected counties at capacity 25", ""]
    for rule in ("PREV", "BURDEN", "EQUITY"):
        d = ctab[ctab[f"{rule}_K25_selected"] == True].sort_values([f"{rule}_K25_rank", "fips"])  # noqa: E712
        rows = []
        for _, r in d.iterrows():
            val = (f"{fmt_dec(r.prev)} ({fmt_dec(r.prev_lcl)} to {fmt_dec(r.prev_ucl)})" if rule != "BURDEN"
                   else f"{fmt_int(r.burden)} ({fmt_int(r.burden_lo)} to {fmt_int(r.burden_hi)})")
            rows.append([fmt_int(r[f'{rule}_K25_rank']), f"{r.display_name}, {r.state_abbr}", r.fips, val, fmt_int(r.pop18_places),
                         fmt_dec(r.pov), f"{fmt_int(r[f'{rule}_K25_best'])} to {fmt_int(r[f'{rule}_K25_worst'])}", r[f"{rule}_K25_status"]])
        unit = "Crude prevalence, % (95% interval)" if rule != "BURDEN" else "Estimated adults with diagnosed diabetes (scenario bounds)"
        df = pd.DataFrame(rows, columns=["Rank", "County", "FIPS", unit, "Adults", "Poverty, %", "Best to worst rank", "Status"])
        parts += [f"**Table S8{'abc'[['PREV','BURDEN','EQUITY'].index(rule)]}. Counties selected at capacity 25 under the {RULE_LABEL[rule].lower()} rule.** Source: outputs/tables/county_priority_table.csv.", "",
                  md_table(df, ["r", "l", "l", "r", "r", "r", "r", "l"]), ""]

    val = json.loads((root / "outputs" / "validation" / "validation_report.json").read_text())
    vr = [[c["kind"], c.get("label", c["check"].replace("_", " ")),
           ("passed" if c["passed"] else "failed") if c["kind"] != "report" else "recorded"] for c in val["checks"]]
    parts += ["## S9. Checks", "",
              "Software checks test the code. Source checks compare derived values with published source values. Report entries are recorded without a pass criterion. None of these is external scientific validation of the model-based estimates, which was not possible with public data.", "",
              "**Table S9. Automated checks for the reported run.** Source: outputs/validation/validation_report.json.", "",
              md_table(pd.DataFrame(vr, columns=["Kind", "Check", "Result"]), ["l", "l", "l"]), ""]
    vdir = root / "outputs" / "validation"
    sf = json.loads((vdir / "summary_file_check.json").read_text())
    pl = json.loads((vdir / "places_live_check.json").read_text())
    rf = json.loads((vdir / "reference_check.json").read_text())
    tr = json.loads((vdir / "table_recompute_check.json").read_text())
    n_sf = sf["vintages"]["2024"]["counties_in_replicate_file"]
    parts += ["Four further checks were run outside the pipeline with the scripts in the source archive (results in outputs/validation/):", "",
              f"- ACS adult counts and poverty numerators and denominators derived from the replicate tables equaled the Census Bureau's "
              f"table-based summary files for all {n_sf:,} counties in the 2020-2024 and 2019-2023 releases.",
              f"- The estimate, 95% limits and adult population of all {pl['frame_counties_identical']:,} frame counties equaled the live "
              f"PLACES 2025 release on data.cdc.gov ({pl['checked_on']}). Estimated burden recalculated from the live values equaled the "
              f"table for the 12 randomly sampled counties, and a sort of the live file returned the same top-ranked counties.",
              (f"- All {rf['n_references']} references passed a scripted check: " if rf["n_ok"] == rf["n_references"]
               else f"- {rf['n_ok']} of {rf['n_references']} references passed a scripted check: ") +
              f"{sum(r['kind'] in ('doi', 'pmid') for r in rf['references'])} journal articles against Crossref or PubMed (first author, year, "
              "volume, first page and title), the Federal Register notice against the Federal Register record, "
              f"{sum('browser_check' in r for r in rf['references'])} cdc.gov pages opened in a browser (title, and the displayed update date for the web pages), "
              f"{sum('census_api_metadata' in r for r in rf['references'])} Census table against the Census Bureau's API metadata (table "
              f"and title), and the remaining "
              f"{sum(r['kind'] == 'url' and 'browser_check' not in r and 'census_api_metadata' not in r for r in rf['references'])} "
              "web and dataset addresses by their response.",
              f"- A pairwise recomputation, written without the analysis package, reproduced every cell of Tables 2 and 3 and all "
              f"{tr['county_statuses_checked']:,} county classifications.", ""]
    brief = (root / "docs" / "planning_brief.md").read_text()
    brief = re.sub(r"^# .*\n", "", brief)
    brief = re.sub(r"(?m)^## ", "### ", brief)
    brief = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", brief)  # links in the brief are relative to its own page
    parts += ["## S10. Planning brief", "", brief.strip(), ""]
    return "\n".join(parts) + "\n"


def render_documents(root: Path, facts_display: dict[str, str]) -> dict:
    t = root / "outputs" / "tables"
    manifest = json.loads((root / "source_manifest.json").read_text())
    env = pd.read_csv(t / "envelope_summary.csv")
    prof = pd.read_csv(t / "selection_profile.csv")
    ovl = pd.read_csv(t / "rule_overlap.csv")

    brief = resolve((root / "docs" / "planning_brief_template.md").read_text(), facts_display)
    (root / "docs" / "planning_brief.md").write_text(brief)

    tables = "\n\n".join([table1(manifest), table2(env, prof), table3(ovl)])
    tmpl = (root / "manuscript" / "manuscript_template.md").read_text()
    tmpl = tmpl.replace("{{REFERENCES}}", references_md()).replace("{{TABLES}}", tables)
    text = resolve(tmpl, facts_display)
    em = [m.start() for m in re.finditer("—", text)]
    if em:
        raise ValueError("em dash found in manuscript text")
    cites = check_citations(text)
    (root / "manuscript" / "manuscript.md").write_text(text)
    # Figures are supplied as separate files, so the DOCX embeds none.
    md_to_docx(text, root / "manuscript" / "manuscript.docx")
    supp = supplement_md(root, facts_display)
    (root / "manuscript" / "additional_file_1_supplement.md").write_text(supp)
    md_to_docx(supp, root / "manuscript" / "additional_file_1_supplement.docx", double_space=False)
    return {"citations": cites, "word_counts": word_counts(text), "manuscript_md": text, "supplement_md": supp}
