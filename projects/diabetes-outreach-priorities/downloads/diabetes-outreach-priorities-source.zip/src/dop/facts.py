"""Named facts for reports, each traceable to an output file, selector and column.

Every number that appears in the manuscript, the portfolio page or the
handoff files is produced here from the analysis outputs. Templates refer to
facts by name ({{name}}), and an unknown name stops rendering. The same records are
written to evidence/claims.json with their provenance.
"""

from __future__ import annotations

import json
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

import pandas as pd

RULES = ["PREV", "BURDEN", "EQUITY"]
STATE_NAMES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado",
    "CT": "Connecticut", "DE": "Delaware", "DC": "District of Columbia", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan",
    "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina",
    "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island",
    "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont",
    "VA": "Virginia", "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming",
}


def r_half(x: float, nd: int = 0) -> Decimal:
    q = Decimal(1).scaleb(-nd)
    return Decimal(str(x)).quantize(q, rounding=ROUND_HALF_UP)


def fmt_int(x) -> str:
    return f"{int(r_half(float(x))):,}"


def fmt_dec(x, nd=1) -> str:
    return f"{r_half(float(x), nd):,.{nd}f}"


def fmt_pct(x, nd=1) -> str:
    return f"{r_half(100 * float(x), nd):.{nd}f}%"


def fmt_millions(x, nd=1) -> str:
    return f"{r_half(float(x) / 1e6, nd)} million"


class Facts:
    def __init__(self):
        self.items: dict[str, dict] = {}

    def add(self, name, value, display, source, selector, column, note=""):
        if name in self.items:
            raise KeyError(f"duplicate fact {name}")
        if isinstance(value, (pd.Series, pd.DataFrame)):
            raise TypeError(name)
        try:
            value = value.item()  # numpy scalar -> python
        except AttributeError:
            pass
        self.items[name] = {"value": value, "display": display, "source": source, "selector": selector,
                            "column": column, "note": note}

    def display(self) -> dict[str, str]:
        return {k: v["display"] for k, v in self.items.items()}


def build_facts(root: Path) -> Facts:
    from datetime import date as _date

    t = root / "outputs" / "tables"
    p = root / "data" / "processed"
    F = Facts()
    rel = lambda path: str(path.relative_to(root))  # noqa: E731

    allc = pd.read_csv(p / "county_all.csv", dtype={"fips": str})
    frame = pd.read_csv(p / "analysis_frame.csv", dtype={"fips": str, "state_fips": str})
    checks = json.loads((p / "build_checks.json").read_text())
    env = pd.read_csv(t / "envelope_summary.csv")
    ovl = pd.read_csv(t / "rule_overlap.csv")
    scn = pd.read_csv(t / "scenario_overlap.csv")
    prof = pd.read_csv(t / "selection_profile.csv")
    ws = pd.read_csv(t / "within_state_summary.csv")
    al = pd.read_csv(t / "robustness_aligned.csv")
    pr = pd.read_csv(t / "prior_release_comparison.csv")
    ctab = pd.read_csv(t / "county_priority_table.csv", dtype={"fips": str})
    dep = pd.read_csv(t / "rule_dependence.csv", dtype={"fips": str})
    run = json.loads((t / "run_record.json").read_text())
    val = json.loads((root / "outputs" / "validation" / "validation_report.json").read_text())
    manifest = json.loads((root / "source_manifest.json").read_text())

    # Frame and exclusions
    sc = allc["frame_status"].value_counts()
    F.add("places_rows", checks["row_counts"]["places_raw_rows"], fmt_int(checks["row_counts"]["places_raw_rows"]),
          rel(p / "build_checks.json"), "row_counts.places_raw_rows", "")
    n_county_equiv = int((allc["frame_status"] != "national_aggregate").sum())
    F.add("county_equivalents", n_county_equiv, fmt_int(n_county_equiv), rel(p / "county_all.csv"),
          "frame_status != national_aggregate", "fips")
    F.add("frame_counties", len(frame), fmt_int(len(frame)), rel(p / "analysis_frame.csv"), "all rows", "fips")
    n_st = frame["state_abbr"].nunique()
    F.add("frame_jurisdictions", n_st, str(n_st), rel(p / "analysis_frame.csv"), "distinct state_abbr", "state_abbr",
          "48 states plus the District of Columbia")
    F.add("frame_states", n_st - 1, str(n_st - 1), rel(p / "analysis_frame.csv"), "distinct state_abbr excluding DC",
          "state_abbr")
    excl = allc[allc.frame_status == "measure_not_released_for_state"]
    for st in ("KY", "PA"):
        n = int((excl.state_abbr == st).sum())
        F.add(f"excluded_{st.lower()}", n, str(n), rel(p / "county_all.csv"),
              f"frame_status == measure_not_released_for_state & state_abbr == {st}", "fips")
    F.add("excluded_measure", len(excl), str(len(excl)), rel(p / "county_all.csv"),
          "frame_status == measure_not_released_for_state", "fips")
    F.add("suppressed", int(sc.get("suppressed", 0)), str(int(sc.get("suppressed", 0))), rel(p / "county_all.csv"),
          "frame_status == suppressed", "fips")
    pr_geo = pd.read_csv(p / "geography_reconciliation.csv", dtype={"fips": str})
    n_pr = int((pr_geo["source"] == "acs_2020_2024").sum())
    F.add("acs_unmatched_pr", n_pr, str(n_pr), rel(p / "geography_reconciliation.csv"), "source == acs_2020_2024", "fips",
          "all are Puerto Rico municipios")
    F.add("aligned_counties", int(frame["in_aligned_subset"].sum()), fmt_int(frame["in_aligned_subset"].sum()),
          rel(p / "analysis_frame.csv"), "in_aligned_subset == True", "fips")
    F.add("ct_counties", int((frame.state_abbr == "CT").sum()), str(int((frame.state_abbr == "CT").sum())),
          rel(p / "analysis_frame.csv"), "state_abbr == CT", "fips")

    # Inputs
    q = frame["prev"].quantile([0.25, 0.5, 0.75])
    w = (frame["prev_ucl"] - frame["prev_lcl"])
    wq = w.quantile([0.25, 0.5, 0.75])
    for name, val_, col in (("prev_median", q[0.5], "prev"), ("prev_q1", q[0.25], "prev"), ("prev_q3", q[0.75], "prev"),
                            ("prev_min", frame.prev.min(), "prev"), ("prev_max", frame.prev.max(), "prev"),
                            ("width_median", wq[0.5], "prev_ucl - prev_lcl"), ("width_q1", wq[0.25], "prev_ucl - prev_lcl"),
                            ("width_q3", wq[0.75], "prev_ucl - prev_lcl"), ("width_min", w.min(), "prev_ucl - prev_lcl"),
                            ("width_max", w.max(), "prev_ucl - prev_lcl")):
        F.add(name, float(val_), fmt_dec(val_), rel(p / "analysis_frame.csv"), "all rows", col)
    F.add("adults_total", float(frame.pop18_places.sum()), fmt_millions(frame.pop18_places.sum()),
          rel(p / "analysis_frame.csv"), "sum", "pop18_places")
    F.add("burden_total", float(frame.burden.sum()), fmt_millions(frame.burden.sum()), rel(p / "analysis_frame.csv"),
          "sum", "burden")
    for nm, col in (("hp_point", "elig_point"), ("hp_certain", "elig_certain"), ("hp_possible", "elig_possible")):
        F.add(nm, int(frame[col].sum()), fmt_int(frame[col].sum()), rel(p / "analysis_frame.csv"), f"{col} == True", col)
    rec = checks["reconciliation"]
    a = rec["acs2024_adult_vs_places_adult"]
    F.add("acs_pep_median_abs", a["median_abs_relative_difference"], fmt_pct(a["median_abs_relative_difference"]),
          rel(p / "build_checks.json"), "reconciliation.acs2024_adult_vs_places_adult.median_abs_relative_difference", "")
    F.add("acs_pep_p90", a["p90_abs_relative_difference"], fmt_pct(a["p90_abs_relative_difference"]),
          rel(p / "build_checks.json"), "reconciliation.acs2024_adult_vs_places_adult.p90_abs_relative_difference", "")
    F.add("acs_pep_outside", a["n_places_adult_outside_acs_95pct_range"], fmt_int(a["n_places_adult_outside_acs_95pct_range"]),
          rel(p / "build_checks.json"), "reconciliation.acs2024_adult_vs_places_adult.n_places_adult_outside_acs_95pct_range", "")
    pep = rec["places_adult_vs_pep_v2023"]
    F.add("pep_match", pep["n_exact_match"], f"{fmt_int(pep['n_exact_match'])} of {fmt_int(pep['n_compared'])}",
          rel(p / "build_checks.json"), "reconciliation.places_adult_vs_pep_v2023", "n_exact_match / n_compared")
    acs_st = rec["acs_adult_status_in_frame"]
    F.add("acs_adult_controlled_frame", acs_st.get("controlled", 0), fmt_int(acs_st.get("controlled", 0)),
          rel(p / "build_checks.json"), "reconciliation.acs_adult_status_in_frame.controlled", "")
    repro = checks["acs_derivation"]["2024"]["published_moe_reproduction"]
    sden = repro["B17001_line1"]
    rem = sden["n_not_controlled"] - sden["n_not_controlled_within_1"]
    F.add("moe_povden_remaining", rem, str(rem), rel(p / "build_checks.json"),
          "acs_derivation.2024.published_moe_reproduction.B17001_line1", "n_not_controlled - n_not_controlled_within_1")
    F.add("moe_povden_mismatch_reps_equal", sden["n_mismatch_with_all_replicates_equal_estimate"],
          str(sden["n_mismatch_with_all_replicates_equal_estimate"]), rel(p / "build_checks.json"),
          "acs_derivation.2024.published_moe_reproduction.B17001_line1.n_mismatch_with_all_replicates_equal_estimate", "")
    F.add("moe_povden_mismatch_min", sden["mismatch_published_moe_min"], fmt_int(sden["mismatch_published_moe_min"]),
          rel(p / "build_checks.json"), "acs_derivation.2024.published_moe_reproduction.B17001_line1.mismatch_published_moe_min", "")
    F.add("moe_povden_mismatch_max", sden["mismatch_published_moe_max"], fmt_int(sden["mismatch_published_moe_max"]),
          rel(p / "build_checks.json"), "acs_derivation.2024.published_moe_reproduction.B17001_line1.mismatch_published_moe_max", "")
    lov = allc[allc.frame_status == "suppressed"].iloc[0]
    F.add("suppressed_adults", int(lov.pop18_places), fmt_int(lov.pop18_places), rel(p / "county_all.csv"),
          "frame_status == suppressed", "pop18_places")
    F.add("suppressed_total", int(lov.total_pop_places), fmt_int(lov.total_pop_places), rel(p / "county_all.csv"),
          "frame_status == suppressed", "total_pop_places")
    for nm, key in (("moe_m18", "B05003_line8"), ("moe_f18", "B05003_line19"), ("moe_povnum", "B17001_line2"),
                    ("moe_povden", "B17001_line1")):
        s = repro[key]
        F.add(nm, s["n_not_controlled_within_1"],
              f"{fmt_int(s['n_not_controlled_within_1'])} of {fmt_int(s['n_not_controlled'])}",
              rel(p / "build_checks.json"), f"acs_derivation.2024.published_moe_reproduction.{key}",
              "n_not_controlled_within_1 / n_not_controlled")

    # Per capacity results
    for k in (10, 25, 50):
        for r in RULES:
            e = env[(env.rule == r) & (env.capacity == k)].iloc[0]
            sel_ = f"rule == {r} & capacity == {k}"
            for col in ("n_selected_point", "n_core", "n_boundary", "n_core_or_boundary"):
                F.add(f"k{k}_{r.lower()}_{col.replace('n_', '').replace('_point', '')}", int(e[col]), fmt_int(e[col]),
                      rel(t / "envelope_summary.csv"), sel_, col)
            pf = prof[(prof.rule == r) & (prof.capacity == k)].iloc[0]
            F.add(f"k{k}_{r.lower()}_burden_share", float(pf.share_of_frame_estimated_burden),
                  fmt_pct(pf.share_of_frame_estimated_burden, 2 if pf.share_of_frame_estimated_burden < 0.01 else 1),
                  rel(t / "selection_profile.csv"), sel_, "share_of_frame_estimated_burden")
            F.add(f"k{k}_{r.lower()}_burden_sum", float(pf.sum_estimated_burden),
                  fmt_int(pf.sum_estimated_burden) if pf.sum_estimated_burden < 1e6 else fmt_millions(pf.sum_estimated_burden, 2),
                  rel(t / "selection_profile.csv"), sel_, "sum_estimated_burden")
        for x, y in (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")):
            o = ovl[(ovl.capacity == k) & (ovl.scenario == "point") & (ovl.set_a == x) & (ovl.set_b == y)].iloc[0]
            base = f"k{k}_{x.lower()}_{y.lower()}"
            sel_ = f"capacity == {k} & scenario == point & set_a == {x} & set_b == {y}"
            F.add(f"{base}_inter", int(o.n_intersection), fmt_int(o.n_intersection), rel(t / "rule_overlap.csv"), sel_, "n_intersection")
            F.add(f"{base}_union", int(o.n_union), fmt_int(o.n_union), rel(t / "rule_overlap.csv"), sel_, "n_union")
            F.add(f"{base}_j", float(o.jaccard), fmt_dec(o.jaccard, 2), rel(t / "rule_overlap.csv"), sel_, "jaccard")
        all3 = ovl[(ovl.capacity == k) & (ovl.scenario == "point") & (ovl.set_a == "ALL_THREE")].iloc[0]
        F.add(f"k{k}_all_three", int(all3.n_intersection), fmt_int(all3.n_intersection), rel(t / "rule_overlap.csv"),
              f"capacity == {k} & scenario == point & set_a == ALL_THREE", "n_intersection")
        dk = dep[dep.capacity == k]
        F.add(f"k{k}_strongly_dependent", int(dk.strongly_rule_dependent.sum()), fmt_int(dk.strongly_rule_dependent.sum()),
              rel(t / "rule_dependence.csv"), f"capacity == {k} & strongly_rule_dependent", "fips")
        F.add(f"k{k}_core_all_three", int(dk.core_all_three.sum()), fmt_int(dk.core_all_three.sum()),
              rel(t / "rule_dependence.csv"), f"capacity == {k} & core_all_three", "fips")
        for cls, nm in (("selected_by_one", "by_one"), ("selected_by_two", "by_two"), ("selected_by_all_three", "by_three")):
            n = int((dk.classification == cls).sum())
            F.add(f"k{k}_selected_{nm}", n, fmt_int(n), rel(t / "rule_dependence.csv"),
                  f"capacity == {k} & classification == {cls}", "fips")
        n_any = int((dk.n_rules_selected > 0).sum())
        F.add(f"k{k}_selected_any", n_any, fmt_int(n_any), rel(t / "rule_dependence.csv"),
              f"capacity == {k} & n_rules_selected > 0", "fips")

    # K = 25 descriptions
    s_prev = ctab[ctab.PREV_K25_selected == True]  # noqa: E712
    s_bur = ctab[ctab.BURDEN_K25_selected == True]  # noqa: E712
    vc = s_prev.state_abbr.value_counts()
    vc = vc.sort_values(ascending=False, kind="stable")
    parts = [f"{STATE_NAMES[s]} ({n})" for s, n in sorted(vc.items(), key=lambda kv: (-kv[1], STATE_NAMES[kv[0]]))]
    F.add("k25_prev_states_list", dict(vc), ", ".join(parts[:-1]) + " and " + parts[-1],
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True, count by state_abbr", "state_abbr")
    F.add("k25_prev_sel_median_adults", float(s_prev.pop18_places.median()), fmt_int(s_prev.pop18_places.median()),
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True, median", "pop18_places")
    F.add("k25_prev_sel_min_adults", float(s_prev.pop18_places.min()), fmt_int(s_prev.pop18_places.min()),
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True, min", "pop18_places")
    F.add("k25_prev_sel_max_adults", float(s_prev.pop18_places.max()), fmt_int(s_prev.pop18_places.max()),
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True, max", "pop18_places")
    F.add("k25_prev_sel_hp_point", int(s_prev.elig_point.sum()), fmt_int(s_prev.elig_point.sum()),
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True & elig_point", "elig_point")
    F.add("k25_prev_sel_hp_certain", int(s_prev.elig_certain.sum()), fmt_int(s_prev.elig_certain.sum()),
          rel(t / "county_priority_table.csv"), "PREV_K25_selected == True & elig_certain", "elig_certain")
    F.add("k25_prev_sel_minprev", float(s_prev.prev.min()), fmt_dec(s_prev.prev.min()), rel(t / "county_priority_table.csv"),
          "PREV_K25_selected == True, min", "prev")
    for stat in ("min", "median", "max"):
        v = getattr(s_prev.PREV_K25_worst, stat)()
        F.add(f"k25_prev_sel_worst_{stat}", float(v), fmt_int(v), rel(t / "county_priority_table.csv"),
              f"PREV_K25_selected == True, {stat}", "PREV_K25_worst")
    F.add("k25_burden_sel_states", int(s_bur.state_abbr.nunique()), str(s_bur.state_abbr.nunique()),
          rel(t / "county_priority_table.csv"), "BURDEN_K25_selected == True, distinct", "state_abbr")
    F.add("k25_burden_sel_median_adults", float(s_bur.pop18_places.median()), fmt_millions(s_bur.pop18_places.median(), 2),
          rel(t / "county_priority_table.csv"), "BURDEN_K25_selected == True, median", "pop18_places")
    F.add("k25_burden_sel_min_adults", float(s_bur.pop18_places.min()), fmt_millions(s_bur.pop18_places.min(), 2),
          rel(t / "county_priority_table.csv"), "BURDEN_K25_selected == True, min", "pop18_places")
    F.add("k25_burden_sel_minprev", float(s_bur.prev.min()), fmt_dec(s_bur.prev.min()), rel(t / "county_priority_table.csv"),
          "BURDEN_K25_selected == True, min", "prev")
    F.add("k25_burden_sel_maxprev", float(s_bur.prev.max()), fmt_dec(s_bur.prev.max()), rel(t / "county_priority_table.csv"),
          "BURDEN_K25_selected == True, max", "prev")
    F.add("k25_burden_sel_hp_point", int(s_bur.elig_point.sum()), fmt_int(s_bur.elig_point.sum()),
          rel(t / "county_priority_table.csv"), "BURDEN_K25_selected == True & elig_point", "elig_point")

    def county(fips, label):
        row = ctab[ctab.fips == fips].iloc[0]
        src = rel(t / "county_priority_table.csv")
        F.add(f"{label}_prev", float(row.prev), fmt_dec(row.prev), src, f"fips == {fips}", "prev")
        F.add(f"{label}_lcl", float(row.prev_lcl), fmt_dec(row.prev_lcl), src, f"fips == {fips}", "prev_lcl")
        F.add(f"{label}_ucl", float(row.prev_ucl), fmt_dec(row.prev_ucl), src, f"fips == {fips}", "prev_ucl")
        F.add(f"{label}_adults", float(row.pop18_places), fmt_int(row.pop18_places), src, f"fips == {fips}", "pop18_places")
        F.add(f"{label}_rank25", float(row.PREV_K25_rank), fmt_int(row.PREV_K25_rank), src, f"fips == {fips}", "PREV_K25_rank")
        F.add(f"{label}_worst25", float(row.PREV_K25_worst), fmt_int(row.PREV_K25_worst), src, f"fips == {fips}", "PREV_K25_worst")

    top = ctab.sort_values(["PREV_K25_rank", "fips"]).iloc[0]
    F.add("top_prev_county", top.fips, f"{top.display_name}, {STATE_NAMES[top.state_abbr]}",
          rel(t / "county_priority_table.csv"), "PREV_K25_rank == 1", "county_name")
    county(top.fips, "top")
    county("15005", "kalawao")
    core50 = ctab[ctab.PREV_K50_status == "core"]
    F.add("k50_prev_core_county", ";".join(core50.fips),
          ", ".join(f"{r.display_name}, {STATE_NAMES[r.state_abbr]}" for r in core50.itertuples()),
          rel(t / "county_priority_table.csv"), "PREV_K50_status == core", "county_name")
    b = ctab[ctab.PREV_K25_status == "boundary"]
    F.add("k25_prev_boundary_states", int(b.state_abbr.nunique()), str(b.state_abbr.nunique()),
          rel(t / "county_priority_table.csv"), "PREV_K25_status == boundary, distinct", "state_abbr")
    F.add("k25_prev_boundary_minprev", float(b.prev.min()), fmt_dec(b.prev.min()), rel(t / "county_priority_table.csv"),
          "PREV_K25_status == boundary, min", "prev")
    top_b = b.state_abbr.value_counts().head(5)
    tb = [f"{STATE_NAMES[s]} ({n})" for s, n in top_b.items()]
    F.add("k25_prev_boundary_topstates", dict(top_b), ", ".join(tb[:-1]) + " and " + tb[-1],
          rel(t / "county_priority_table.csv"), "PREV_K25_status == boundary, count by state_abbr, top 5", "state_abbr")
    o = ctab[ctab.PREV_K25_status == "outside"]
    F.add("k25_prev_outside_maxprev", float(o.prev.max()), fmt_dec(o.prev.max()), rel(t / "county_priority_table.csv"),
          "PREV_K25_status == outside, max", "prev")
    F.add("k25_prev_outside_max_ucl", float(o.prev_ucl.max()), fmt_dec(o.prev_ucl.max()), rel(t / "county_priority_table.csv"),
          "PREV_K25_status == outside, max", "prev_ucl")
    cut = float(ctab.prev_lcl.sort_values(ascending=False).iloc[24])
    F.add("k25_prev_cut", cut, fmt_dec(cut), rel(t / "county_priority_table.csv"), "25th largest value", "prev_lcl",
          "a county is boundary or core under PREV at K=25 exactly when prev_ucl >= this value")
    F.add("k25_prev_boundary_min_ucl", float(b.prev_ucl.min()), fmt_dec(b.prev_ucl.min()), rel(t / "county_priority_table.csv"),
          "PREV_K25_status == boundary, min", "prev_ucl")
    bc = ctab[(ctab.BURDEN_K25_status == "core") & (ctab.PREV_K25_status == "outside")]
    F.add("k25_burden_core_prev_outside", len(bc), str(len(bc)), rel(t / "county_priority_table.csv"),
          "BURDEN_K25_status == core & PREV_K25_status == outside", "fips")
    top35 = ctab.sort_values(["PREV_K25_rank", "fips"]).head(35)
    F.add("fig3_prev_worst_min", float(top35.PREV_K25_worst.min()), fmt_int(top35.PREV_K25_worst.min()),
          rel(t / "county_priority_table.csv"), "35 best PREV_K25_rank, min", "PREV_K25_worst")
    F.add("fig3_prev_worst_max", float(top35.PREV_K25_worst.max()), fmt_int(top35.PREV_K25_worst.max()),
          rel(t / "county_priority_table.csv"), "35 best PREV_K25_rank, max", "PREV_K25_worst")

    # Scenario overlap
    for r in RULES:
        for name, setb in (("lower", "lower_bounds"), ("upper", "upper_bounds")):
            o = scn[(scn.rule == r) & (scn.capacity == 25) & (scn.set_b == setb)].iloc[0]
            F.add(f"k25_{r.lower()}_scn_{name}_j", float(o.jaccard), fmt_dec(o.jaccard, 2), rel(t / "scenario_overlap.csv"),
                  f"rule == {r} & capacity == 25 & set_b == {setb}", "jaccard")
    for name, setb in (("certain", "certain_eligibility_frame"), ("possible", "possible_eligibility_frame")):
        o = scn[(scn.rule == "EQUITY") & (scn.capacity == 25) & (scn.set_b == setb)].iloc[0]
        F.add(f"k25_equity_scn_{name}_j", float(o.jaccard), fmt_dec(o.jaccard, 2), rel(t / "scenario_overlap.csv"),
              f"rule == EQUITY & capacity == 25 & set_b == {setb}", "jaccard")

    # Within state
    wss = ws[~ws.all_units_no_selection]
    src = rel(t / "within_state_summary.csv")
    F.add("ws_states", len(wss), str(len(wss)), src, "all_units_no_selection == False", "state_abbr")
    allu = ws[ws.all_units_no_selection].state_abbr.tolist()
    F.add("ws_all_units", allu, ", ".join(STATE_NAMES[s] for s in allu[:-1]) + " and " + STATE_NAMES[allu[-1]], src,
          "all_units_no_selection == True", "state_abbr")
    for r in RULES:
        F.add(f"ws_{r.lower()}_core_states", int((wss[f"{r}_n_core"] >= 1).sum()), str(int((wss[f"{r}_n_core"] >= 1).sum())),
              src, f"all_units_no_selection == False & {r}_n_core >= 1", "state_abbr")
    F.add("ws_burden_core_median", float(wss.BURDEN_n_core.median()), fmt_int(wss.BURDEN_n_core.median()), src,
          "all_units_no_selection == False, median", "BURDEN_n_core")
    F.add("ws_prev_burden_zero", int((wss.jaccard_PREV_BURDEN == 0).sum()), str(int((wss.jaccard_PREV_BURDEN == 0).sum())),
          src, "all_units_no_selection == False & jaccard_PREV_BURDEN == 0", "jaccard_PREV_BURDEN")
    F.add("ws_prev_equity_median_j", float(wss.jaccard_PREV_EQUITY.median()), fmt_dec(wss.jaccard_PREV_EQUITY.median(), 2),
          src, "all_units_no_selection == False, median", "jaccard_PREV_EQUITY")
    ge5 = wss[wss.EQUITY_n_ranked >= 5]
    F.add("ws_equity_ge5_states", len(ge5), str(len(ge5)), src, "all_units_no_selection == False & EQUITY_n_ranked >= 5", "state_abbr")
    F.add("ws_prev_equity_median_j_ge5", float(ge5.jaccard_PREV_EQUITY.median()), fmt_dec(ge5.jaccard_PREV_EQUITY.median(), 2),
          src, "all_units_no_selection == False & EQUITY_n_ranked >= 5, median", "jaccard_PREV_EQUITY")
    F.add("ws_equity_none", int((wss.EQUITY_n_ranked == 0).sum()), str(int((wss.EQUITY_n_ranked == 0).sum())), src,
          "all_units_no_selection == False & EQUITY_n_ranked == 0", "EQUITY_n_ranked")
    F.add("ws_equity_shortfall", int((wss.EQUITY_shortfall > 0).sum()), str(int((wss.EQUITY_shortfall > 0).sum())), src,
          "all_units_no_selection == False & EQUITY_shortfall > 0", "EQUITY_shortfall")

    # Robustness: aligned subset
    fa = frame[frame.in_aligned_subset]
    F.add("aligned_hp_point", int(fa.elig_point_aligned.sum()), fmt_int(fa.elig_point_aligned.sum()),
          rel(p / "analysis_frame.csv"), "in_aligned_subset & elig_point_aligned", "elig_point_aligned")
    F.add("aligned_hp_point_primary", int(fa.elig_point.sum()), fmt_int(fa.elig_point.sum()),
          rel(p / "analysis_frame.csv"), "in_aligned_subset & elig_point", "elig_point")
    ss = pd.read_csv(t / "selected_sets.csv", dtype={"fips": str})
    ct_sel = ss[(ss.scope == "national") & (ss.scenario == "point") & (ss.fips.str[:2] == "09")].fips.nunique()
    F.add("aligned_selected_ct", int(ct_sel), str(int(ct_sel)), rel(t / "selected_sets.csv"),
          "scope == national & scenario == point & Connecticut FIPS, distinct", "fips")
    src = rel(t / "robustness_aligned.csv")
    F.add("aligned_min_j", float(al.jaccard.min()), fmt_dec(al.jaccard.min(), 2), src, "all rows, min", "jaccard")
    ab = al[al.rule == "BURDEN"]
    nchg = int((ab.core_primary != ab.core_aligned).sum())
    F.add("aligned_burden_core_changes", nchg, str(nchg), src, "rule == BURDEN & core_primary != core_aligned", "capacity")
    b25 = al[(al.rule == "BURDEN") & (al.capacity == 25)].iloc[0]
    F.add("aligned_burden_boundary_k25", int(b25.boundary_aligned), fmt_int(b25.boundary_aligned), src,
          "rule == BURDEN & capacity == 25", "boundary_aligned")
    e25 = al[(al.rule == "EQUITY") & (al.capacity == 25)].iloc[0]
    F.add("aligned_equity_boundary_k25", int(e25.boundary_aligned), fmt_int(e25.boundary_aligned), src,
          "rule == EQUITY & capacity == 25", "boundary_aligned")

    # Prior release
    src = rel(t / "prior_release_comparison.csv")
    for k in (25, 50):
        for r in RULES:
            o = pr[(pr.rule == r) & (pr.capacity == k)].iloc[0]
            F.add(f"prior_k{k}_{r.lower()}_j", float(o.jaccard), fmt_dec(o.jaccard, 2), src, f"rule == {r} & capacity == {k}", "jaccard")
            F.add(f"prior_k{k}_{r.lower()}_inter", int(o.n_intersection), fmt_int(o.n_intersection), src,
                  f"rule == {r} & capacity == {k}", "n_intersection")
            F.add(f"prior_k{k}_{r.lower()}_union", int(o.n_union), fmt_int(o.n_union), src, f"rule == {r} & capacity == {k}", "n_union")
            F.add(f"prior_k{k}_{r.lower()}_kypa", int(o.n_KY_PA_in_2024_full_frame_selection),
                  fmt_int(o.n_KY_PA_in_2024_full_frame_selection), src, f"rule == {r} & capacity == {k}",
                  "n_KY_PA_in_2024_full_frame_selection")
    o = pr.iloc[0]
    F.add("prior_frame", int(o.n_counties_2024_frame), fmt_int(o.n_counties_2024_frame), src, "first row", "n_counties_2024_frame")

    # Validation and run
    vsrc = rel(root / "outputs" / "validation" / "validation_report.json")
    rows_r = next(c for c in val["checks"] if c["check"] == "r_second_implementation_rules")["detail"]["rows_matched"]
    F.add("r_rows", rows_r, fmt_int(rows_r), vsrc, "checks[r_second_implementation_rules].detail.rows_matched", "")
    n_checks = sum(1 for c in val["checks"] if c["kind"] in ("software", "source"))
    F.add("validation_checks", n_checks, str(n_checks), vsrc, "checks with kind software or source", "")
    F.add("validation_all_passed", val["all_passed"], "all passed" if val["all_passed"] else "not all passed", vsrc,
          "all_passed", "")
    F.add("run_id", run["run_id"], run["run_id"], rel(t / "run_record.json"), "run_id", "")

    # Independent rechecks run outside the pipeline (scripts/check_*.py, scripts/recompute_tables.py).
    vdir = root / "outputs" / "validation"
    rechecks = {}
    for name in ("summary_file_check", "places_live_check", "reference_check", "table_recompute_check"):
        f = vdir / f"{name}.json"
        if not f.exists():
            raise FileNotFoundError(f"{rel(f)} is missing. Run the scripts in scripts/ (see README)")
        rechecks[name] = json.loads(f.read_text())
        if rechecks[name]["run_id"] != run["run_id"]:
            raise RuntimeError(f"{rel(f)} is from run {rechecks[name]['run_id']}. Rerun its script for run {run['run_id']}")
    sf = rechecks["summary_file_check"]
    n_sf = {v["counties_in_replicate_file"] for v in sf["vintages"].values()}
    if not sf["all_equal"] or len(n_sf) != 1:
        raise RuntimeError("ACS summary-file check did not match")
    F.add("sf_counties", n_sf.pop(), fmt_int(sf["vintages"]["2024"]["counties_in_replicate_file"]), rel(vdir / "summary_file_check.json"),
          "vintages.*.counties_in_replicate_file (all_equal true)", "")
    pl = rechecks["places_live_check"]
    if not pl["all_match"]:
        raise RuntimeError("live PLACES check did not match")
    F.add("places_live_counties", pl["frame_counties_identical"], fmt_int(pl["frame_counties_identical"]),
          rel(vdir / "places_live_check.json"), "frame_counties_identical (all_match true)", "")
    d = _date.fromisoformat(pl["checked_on"])
    F.add("places_live_date", pl["checked_on"], f"{d.day} {d.strftime('%B')} {d.year}", rel(vdir / "places_live_check.json"),
          "checked_on", "")
    rc = rechecks["reference_check"]
    if rc["n_ok"] != rc["n_references"]:
        raise RuntimeError(f"reference check: {rc['n_ok']} of {rc['n_references']} matched")
    F.add("references_checked", rc["n_ok"], str(rc["n_ok"]), rel(vdir / "reference_check.json"), "n_ok", "")
    tr = rechecks["table_recompute_check"]
    if not tr["all_match"]:
        raise RuntimeError(f"table recomputation differs: {tr['differences'][:3]}")
    F.add("recompute_statuses", tr["county_statuses_checked"], fmt_int(tr["county_statuses_checked"]),
          rel(vdir / "table_recompute_check.json"), "county_statuses_checked (all_match true)", "")
    places = manifest["sources"]["places_2025_county"]
    F.add("places_sha", places["sha256"], places["sha256"][:12], "source_manifest.json", "sources.places_2025_county.sha256", "")
    F.add("places_rows_updated", places["socrata_metadata"]["rows_updated_at_utc"],
          places["socrata_metadata"]["rows_updated_at_utc"][:10], "source_manifest.json",
          "sources.places_2025_county.socrata_metadata.rows_updated_at_utc", "")
    import datetime as _dt
    d = _dt.date.fromisoformat(places["socrata_metadata"]["rows_updated_at_utc"][:10])
    F.add("places_rows_updated_display", d.isoformat(), f"{d.day} {d.strftime('%B')} {d.year}", "source_manifest.json",
          "sources.places_2025_county.socrata_metadata.rows_updated_at_utc", "")
    return F


def resolve(template: str, facts: dict[str, str]) -> str:
    import re

    missing = set()

    def sub(m):
        key = m.group(1)
        if key not in facts:
            missing.add(key)
            return m.group(0)
        return facts[key]

    out = re.sub(r"\{\{([a-z0-9_]+)\}\}", sub, template)
    if missing:
        raise KeyError(f"unresolved facts: {sorted(missing)}")
    return out
