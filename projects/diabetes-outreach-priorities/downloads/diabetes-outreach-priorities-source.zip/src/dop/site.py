"""Static project page for /projects/diabetes-outreach-priorities/.

All public files live under site/projects/<slug>/ so the page can be combined
with other independently built project pages later.
"""

from __future__ import annotations

import re
import shutil
import zipfile
from pathlib import Path

import markdown as md_lib
import pandas as pd

from .facts import resolve
from .report import html_page, md_to_html

SLUG = "diabetes-outreach-priorities"
FIG_FILES = {1: "fig1_selection_scatter", 2: "fig2_capacity_envelope", 3: "fig3_rank_envelopes"}

FIG_ALT = {
    1: ("Scatter plot of crude diabetes prevalence against adult population on a log scale for all frame counties. "
        "Prevalence-selected and high-poverty-selected counties sit at the top left with small populations and "
        "prevalence of {{k25_prev_sel_minprev}} percent or more. Burden-selected counties sit at the far right with at least "
        "{{k25_burden_sel_min_adults}} adults and prevalence between {{k25_burden_sel_minprev}} and {{k25_burden_sel_maxprev}} percent."),
    2: None,  # taken from the overview page's alt text for the same figure
    3: ("Two panels of horizontal lines, one per county, for the 35 highest-ranked counties under the prevalence rule "
        "(left) and the estimated burden rule (right). Prevalence lines run from rank 1 to worst-case ranks between "
        "{{fig3_prev_worst_min}} and {{fig3_prev_worst_max}} and all cross the capacity line at 25. Burden lines are short, "
        "and the {{k25_burden_core}} highest are entirely left of the capacity line."),
}
SOURCE_COLUMNS = {
    "places_release": "CDC PLACES County Data, 2025 release (BRFSS 2023), data.cdc.gov swc5-untb",
    "prevalence_measure": "Crude prevalence of diagnosed diabetes among adults aged 18+, percent, with 95% limits",
    "adult_population_source": "Census Bureau Vintage 2023 county estimate, ages 18+ (PLACES TotalPop18plus)",
    "poverty_source": "ACS 2020-2024 5-year, percent below poverty level (B17001), 95% bounds from replicates",
}


def crumbs(here: str, up: str = "./index.html") -> str:
    return f'<nav class="crumbs"><a href="{up}">Project overview</a> / {here}</nav>'


def captions_for_tables(body: str) -> str:
    """Give each table a visible title outside its scroll frame and name the table and frame by it."""
    counter = {"n": 0}

    def repl(m):
        counter["n"] += 1
        num = re.search(r"Table (S?\d+[a-z]?)\.", m.group(1))
        tid = f"table-{num.group(1).lower()}" if num else f"table-{counter['n']}"
        return (f'<p class="tcap" id="{tid}">{m.group(1)}</p>\n'
                f'<div class="table-wrap" tabindex="0" role="region" aria-labelledby="{tid}">'
                f'<table class="wide" aria-labelledby="{tid}">')

    pat = re.compile(r'<p>(<strong>Table [^<]+</strong>.*?)</p>\s*<div class="table-wrap" tabindex="0" role="region" '
                     r'aria-label="Table"><table>', re.S)
    return pat.sub(repl, body)


def link_figures(body: str) -> str:
    """Link in-text mentions of Figure N to the figure, outside figure captions and existing links."""
    parts = re.split(r"(<figure.*?</figure>|<a [^>]*>.*?</a>|<h[1-6][^>]*>.*?</h[1-6]>)", body, flags=re.S)
    for i in range(0, len(parts), 2):
        parts[i] = re.sub(r"(?<![\w>#-])Figure (\d)\b", r'<a href="#figure-\1">Figure \1</a>', parts[i])
    return "".join(parts)


def _img_size(path: Path) -> tuple[int, int]:
    from PIL import Image
    with Image.open(path) as im:
        return im.size


def _report_html(text: str, fig2_alt: str, facts_display: dict[str, str], figdir: Path) -> str:
    alts = {k: (resolve(v, facts_display) if v else v) for k, v in FIG_ALT.items()}
    alts[2] = fig2_alt
    out_lines = []
    for line in text.splitlines():
        m = re.match(r"^\*\*Figure (\d+)\. (.*?)\*\* ?(.*)$", line)
        if m:
            n = int(m.group(1))
            w, h = _img_size(figdir / f"{FIG_FILES[n]}.png")
            out_lines.append(
                f'<figure id="figure-{n}"><a href="assets/{FIG_FILES[n]}.png"><img src="assets/{FIG_FILES[n]}.svg" '
                f'alt="{alts[n]}" width="{w}" height="{h}" loading="lazy"></a>'
                f"<figcaption><b>Figure {n}. {m.group(2)}</b> {m.group(3)} Select the figure to open it at full size.</figcaption></figure>")
            out_lines.append("")
        else:
            out_lines.append(line)
    text = "\n".join(out_lines)
    body = md_lib.markdown(text, extensions=["tables", "sane_lists", "toc"])
    body = body.replace("<table>", '<div class="table-wrap" tabindex="0" role="region" aria-label="Table"><table>')
    body = body.replace("</table>", "</table></div>")
    return link_figures(captions_for_tables(body))


def build_site(root: Path, facts_display: dict[str, str], dashboard: Path, workbook: Path) -> Path:
    site = root / "site" / "projects" / SLUG
    if site.exists():
        shutil.rmtree(site)
    (site / "assets").mkdir(parents=True)
    (site / "downloads").mkdir(parents=True)

    figs = root / "outputs" / "figures"
    for stem in FIG_FILES.values():
        shutil.copy2(figs / f"{stem}.svg", site / "assets" / f"{stem}.svg")
        shutil.copy2(figs / f"{stem}.png", site / "assets" / f"{stem}.png")

    tmpl = (root / "templates" / "site_index.md").read_text()
    index_md = resolve(tmpl, facts_display)
    w2, h2 = _img_size(figs / f"{FIG_FILES[2]}.png")
    index_md = re.sub(r'(<img src="assets/fig2_capacity_envelope.svg"[^>]*?) width="\d+" height="\d+"',
                      rf'\1 width="{w2}" height="{h2}"', index_md)
    fig2_alt = re.search(r'alt="([^"]+)"', index_md).group(1)
    index_body = md_lib.markdown(index_md, extensions=["tables", "sane_lists"])
    (site / "index.html").write_text(html_page(
        "Diabetes outreach priorities",
        index_body,
        "How county shortlists for diabetes outreach change with the definition of need and the published uncertainty of CDC PLACES estimates.",
        crumbs=""))

    manuscript = (root / "manuscript" / "manuscript.md").read_text()
    report_body = _report_html(manuscript, fig2_alt, facts_display, figs)
    # Use first person in the portfolio; keep the journal declaration unchanged.
    report_body = report_body.replace('Animesh Bose is the owner of Norlowe Research. The author declares no other competing interests.', 'I own Norlowe Research and have no other competing interests.')
    for n, href, note in ((1, "supplement.html", ' <a href="downloads/additional_file_1_supplement.docx">Download supplementary material (Word)</a>.'),
                          (2, "downloads/diabetes-outreach-priorities-workbook.xlsx", ""),
                          (3, f"downloads/{SLUG}-source.zip", "")):
        tag = f"<strong>Additional file {n}.</strong>"
        if report_body.count(tag) != 1:
            raise RuntimeError(f"Additional file {n} entry not found once in the report")
        i = report_body.index(tag)
        end = report_body.index("</p>", i)
        report_body = (report_body[:i] + f'<strong><a href="{href}">Additional file {n}</a>.</strong>'
                       + report_body[i + len(tag):end] + note + report_body[end:])
    # On the portfolio page the paper is not (yet) a published article.
    pub = "are provided with this manuscript and its supplementary files (Additional files 1 and 2)"
    if report_body.count(pub) != 1:
        raise RuntimeError("availability sentence not found in the report")
    report_body = report_body.replace(pub, "are provided as Additional files 1 and 2 (the supplement and the analysis workbook in this project's downloads)")
    (site / "report.html").write_text(html_page(
        "Diabetes priorities report", report_body,
        "Full report: stability of county diabetes outreach priorities under alternative need definitions and published uncertainty.",
        crumbs=crumbs("Full report")))

    supp = (root / "manuscript" / "additional_file_1_supplement.md").read_text()
    (site / "supplement.html").write_text(html_page(
        "Diabetes priorities supplement", captions_for_tables(md_to_html(supp)),
        "Supplementary methods and tables for the county diabetes outreach priorities study.",
        crumbs=crumbs("Supplementary material")))

    brief = (root / "docs" / "planning_brief.md").read_text()
    (site / "downloads" / "planning-brief.html").write_text(html_page(
        "Diabetes planning brief", md_to_html(brief),
        "One-page brief on using the county diabetes priority tables and the local information needed before acting.",
        crumbs=crumbs("Planning brief", "../index.html")))

    shutil.copy2(dashboard, site / "dashboard.html")
    shutil.copy2(workbook, site / "downloads" / "diabetes-outreach-priorities-workbook.xlsx")
    shutil.copy2(root / "manuscript" / "additional_file_1_supplement.docx", site / "downloads" / "additional_file_1_supplement.docx")
    t = root / "outputs" / "tables"
    ctab = pd.read_csv(t / "county_priority_table.csv", dtype={"fips": str})
    for i, (col, val) in enumerate(SOURCE_COLUMNS.items()):
        ctab.insert(4 + i, col, val)
    ctab.to_csv(site / "downloads" / "county_priority_table.csv", index=False, float_format="%.15g")
    with zipfile.ZipFile(site / "downloads" / "summary_tables.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        members = [(name, (t / name).read_bytes()) for name in (
            "envelope_summary.csv", "rule_overlap.csv", "scenario_overlap.csv", "selection_profile.csv",
            "within_state_summary.csv", "robustness_aligned.csv", "prior_release_comparison.csv",
            "selected_sets.csv", "headline.json", "run_record.json")]
        members.append(("data_dictionary.csv", (root / "docs" / "data_dictionary.csv").read_bytes()))
        members.append(("README.txt", (
            "Summary tables for the county diabetes outreach priorities study.\n"
            "Sources: " + ". ".join(SOURCE_COLUMNS.values()) + ".\n"
            "Kentucky and Pennsylvania have no diagnosed-diabetes estimates in the PLACES 2025 release.\n"
            "Column definitions are in data_dictionary.csv. Rule codes: PREV = prevalence, BURDEN = estimated burden "
            "and EQUITY = high-poverty prevalence.\n").encode()))
        for name, data in members:
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, data)
    return site
