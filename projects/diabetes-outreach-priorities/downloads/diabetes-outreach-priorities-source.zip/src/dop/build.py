"""Build stage: stage sources in DuckDB, run fail-loud checks, join, derive.

Outputs (data/processed/):
  county_all.csv               every PLACES location with its frame status
  analysis_frame.csv           counties in the common frame with derived inputs
  places2024_crude.csv         prior-release crude prevalence (descriptive comparison only)
  geography_reconciliation.csv Census locations not present in PLACES
  build_checks.json            results of every build check and reconciliation
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from . import acs
from .acquire import sha256_file
from .config import Paths, load_config, project_root


class BuildCheckError(RuntimeError):
    pass


def _sql_path(p: Path) -> str:
    return str(p).replace("'", "''")


def _statements(sql: str) -> list[str]:
    body = "\n".join(line for line in sql.splitlines() if not line.strip().startswith("--"))
    return [s.strip() for s in body.split(";") if s.strip()]


def _checks(sql: str) -> list[tuple[str, str, str]]:
    out = []
    for block in re.split(r"(?m)^-- check: ", sql)[1:]:
        header, _, body = block.partition("\n")
        name, _, severity = (x.strip() for x in header.partition("|"))
        out.append((name, severity, body.strip().rstrip(";")))
    return out


def derive_acs(cfg: dict, paths: Paths, interim: Path) -> dict:
    z90, z95 = cfg["analysis"]["z90"], cfg["analysis"]["z95"]
    checks = {}
    for vintage in (cfg["analysis"]["primary_acs_vintage"], cfg["analysis"]["aligned_acs_vintage"]):
        b05 = paths.raw / f"acs5_{vintage}_b05003_vrt" / f"acs5_{vintage}_B05003_vrt.csv.zip"
        b17 = paths.raw / f"acs5_{vintage}_b17001_vrt" / f"acs5_{vintage}_B17001_vrt.csv.zip"
        df, chk = acs.derive(b05, b17, vintage, z90, z95)
        df.to_csv(interim / f"acs{vintage}_county.csv", index=False)
        checks[str(vintage)] = chk
    return checks


def add_derived(frame: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    a = cfg["analysis"]
    thr = a["high_poverty_threshold_pct"]
    f = frame.copy()
    f["burden"] = f["prev"] / 100.0 * f["pop18_places"]
    for v, tag in ((a["primary_acs_vintage"], ""), (a["aligned_acs_vintage"], "_aligned")):
        lo_pop = np.minimum(f["pop18_places"], f[f"acs{v}_adult_lo95"].clip(lower=0))
        hi_pop = np.maximum(f["pop18_places"], f[f"acs{v}_adult_hi95"])
        f[f"adult_lo_scn{tag}"] = lo_pop
        f[f"adult_hi_scn{tag}"] = hi_pop
        f[f"burden_lo{tag}"] = f["prev_lcl"] / 100.0 * lo_pop
        f[f"burden_hi{tag}"] = f["prev_ucl"] / 100.0 * hi_pop
        pov, lo, hi = f[f"acs{v}_pov_pct"], f[f"acs{v}_pov_lo95"], f[f"acs{v}_pov_hi95"]
        special = f[f"acs{v}_pov_status"] != "sdr"
        f[f"pov{tag}"] = pov
        f[f"elig_point{tag}"] = pov >= thr
        f[f"elig_certain{tag}"] = np.where(special, pov >= thr, lo >= thr)
        f[f"elig_possible{tag}"] = np.where(special, pov >= thr, hi >= thr)
    return f


def build(interim: Path | None = None, processed: Path | None = None) -> dict:
    cfg = load_config()
    paths = Paths(project_root())
    paths.ensure()
    interim = interim or paths.interim
    processed = processed or paths.processed
    interim.mkdir(parents=True, exist_ok=True)
    processed.mkdir(parents=True, exist_ok=True)
    a = cfg["analysis"]
    g = cfg["geography"]

    # Every raw input must be the exact file recorded in the source manifest.
    manifest = json.loads(paths.manifest.read_text())
    for sid, src in cfg["sources"].items():
        f = paths.raw / sid / src["filename"]
        if not f.exists():
            raise BuildCheckError(f"{sid}: raw file missing. Run `dop acquire`")
        if sha256_file(f) != manifest["sources"][sid]["sha256"]:
            raise BuildCheckError(f"{sid}: raw file hash differs from source_manifest.json")

    # ACS replicate tables: derive estimates and SDR errors from the validated archives.
    acs_checks = derive_acs(cfg, paths, interim)

    db_path = interim / "dop.duckdb"
    if db_path.exists():
        db_path.unlink()
    con = duckdb.connect(str(db_path))
    fmt = {
        "places_2025": _sql_path(paths.raw / "places_2025_county" / cfg["sources"]["places_2025_county"]["filename"]),
        "places_2024": _sql_path(paths.raw / "places_2024_county_diabetes" / cfg["sources"]["places_2024_county_diabetes"]["filename"]),
        "pep": _sql_path(paths.raw / "pep_v2023_agesex" / cfg["sources"]["pep_v2023_agesex"]["filename"]),
        "acs24": _sql_path(interim / f"acs{a['primary_acs_vintage']}_county.csv"),
        "acs23": _sql_path(interim / f"acs{a['aligned_acs_vintage']}_county.csv"),
        "measure_id": a["measure_id"],
        "measure_label": a["measure_label"],
        "expected_year": a["expected_places_year"],
        "crude_id": a["crude_type_id"],
        "crude_label": a["crude_type_label"],
        "ageadj_id": a["age_adjusted_type_id"],
        "ageadj_label": a["age_adjusted_type_label"],
        "territories": ", ".join(f"'{t}'" for t in g["territory_state_fips"]),
    }
    for stmt in _statements((paths.sql / "01_stage.sql").read_text().format(**fmt)):
        con.execute(stmt)

    results = []
    for name, severity, query in _checks((paths.sql / "02_checks.sql").read_text().format(**fmt)):
        rows = con.execute(query).fetchall()
        results.append({"check": name, "severity": severity, "n_violations": len(rows),
                        "examples": [list(map(str, r)) for r in rows[:5]], "passed": len(rows) == 0})
        if severity == "fatal" and rows:
            raise BuildCheckError(f"build check failed: {name}: {rows[:5]}")

    def n(q: str) -> int:
        return con.execute(q).fetchone()[0]

    n_raw_rows = n("SELECT count(*) FROM places_raw")
    n_locations = n("SELECT count(*) FROM places_locations")
    if n("SELECT count(DISTINCT fips) FROM places_locations") != n_locations:
        raise BuildCheckError("a PLACES LocationID maps to more than one name or state")
    for stmt in _statements((paths.sql / "03_frame.sql").read_text().format(**fmt)):
        con.execute(stmt)
    for table in ("crude", "ageadj"):
        if n(f"SELECT count(*) FROM {table}") != n(f"SELECT count(DISTINCT fips) FROM {table}"):
            raise BuildCheckError(f"{table} is not unique on fips")
    if n("SELECT count(*) FROM county_all") != n_locations:
        raise BuildCheckError("join changed the number of PLACES locations (fan-out)")
    if n("SELECT count(*) FROM crude") != n("SELECT count(*) FROM ageadj"):
        raise BuildCheckError("crude and age-adjusted row counts differ")

    county_all = con.execute("SELECT * FROM county_all ORDER BY fips").df()
    census_not_in_places = con.execute("SELECT * FROM census_not_in_places ORDER BY source, fips").df()
    places24 = con.execute("SELECT * FROM places24_crude ORDER BY fips").df()
    con.close()

    frame = county_all[county_all["frame_status"] == "in_frame"].copy()
    for v in (a["primary_acs_vintage"], a["aligned_acs_vintage"]):
        bad = frame[frame[f"acs{v}_adult_status"] == "moe_zero_not_controlled"]
        if len(bad):
            raise BuildCheckError(f"ACS {v}: adult estimate with zero replicate variance that is not controlled "
                                  f"for {list(bad.fips)[:5]}. Census guidance requires a modelled margin of error")
    frame = add_derived(frame, cfg)
    frame["in_aligned_subset"] = (
        frame["pop18_pep"].notna()
        & frame["acs2023_adult"].notna()
        & frame["acs2023_pov_pct"].notna()
        & ~frame["state_fips"].isin(g["post_2020_geography_change_state_fips"])
    )

    # Reconciliation between population sources (reported, not fatal).
    with_pep = frame[frame["pop18_pep"].notna()]
    pep_diff = (with_pep["pop18_places"] - with_pep["pop18_pep"]).abs()
    acs_rel = (frame["acs2024_adult"] - frame["pop18_places"]) / frame["pop18_places"]
    acs_outside = ~((frame["pop18_places"] >= frame["acs2024_adult_lo95"]) & (frame["pop18_places"] <= frame["acs2024_adult_hi95"]))
    reconciliation = {
        "places_adult_vs_pep_v2023": {
            "n_compared": int(len(with_pep)),
            "n_exact_match": int((pep_diff == 0).sum()),
            "max_abs_difference": float(pep_diff.max()) if len(pep_diff) else None,
        },
        "acs2024_adult_vs_places_adult": {
            "n_compared": int(acs_rel.notna().sum()),
            "median_relative_difference": float(acs_rel.median()),
            "median_abs_relative_difference": float(acs_rel.abs().median()),
            "p90_abs_relative_difference": float(acs_rel.abs().quantile(0.9)),
            "max_abs_relative_difference": float(acs_rel.abs().max()),
            "n_places_adult_outside_acs_95pct_range": int(acs_outside.sum()),
        },
        "acs_adult_status_in_frame": frame["acs2024_adult_status"].value_counts().to_dict(),
        "acs_poverty_status_in_frame": frame["acs2024_pov_status"].value_counts().to_dict(),
    }
    status_counts = county_all["frame_status"].value_counts().to_dict()
    checks_out = {
        "build_checks": results,
        "acs_derivation": acs_checks,
        "row_counts": {
            "places_raw_rows": int(n_raw_rows),
            "places_locations_incl_national_row": int(n_locations),
            "places_diabetes_crude_rows": int(county_all["prev"].notna().sum() + (county_all["frame_status"] == "suppressed").sum()),
            "frame_status_counts": status_counts,
            "analysis_frame_counties": int(len(frame)),
            "aligned_subset_counties": int(frame["in_aligned_subset"].sum()),
            "states_in_frame": int(frame["state_abbr"].nunique()),
            "places2024_crude_rows": int(len(places24)),
        },
        "reconciliation": reconciliation,
        "census_locations_not_in_places": census_not_in_places.groupby("source").size().to_dict(),
    }
    county_all.to_csv(processed / "county_all.csv", index=False)
    frame.to_csv(processed / "analysis_frame.csv", index=False)
    places24.to_csv(processed / "places2024_crude.csv", index=False)
    census_not_in_places.to_csv(processed / "geography_reconciliation.csv", index=False)
    exclusions = county_all[county_all["frame_status"] != "in_frame"][
        ["fips", "state_abbr", "county_name", "frame_status", "footnote"]]
    exclusions.to_csv(processed / "exclusions.csv", index=False)
    (processed / "build_checks.json").write_text(json.dumps(checks_out, indent=2, default=str) + "\n")
    print(f"[build] locations={n_locations} frame={len(frame)} status={status_counts}")
    print(f"[build] reconciliation={json.dumps(reconciliation['places_adult_vs_pep_v2023'])}")
    return checks_out
