"""Analysis stage: prespecified priority rules, envelopes and robustness checks.

Reads data/processed/analysis_frame.csv (and the prior-release extract) and
writes result tables to outputs/tables/ plus a run record in outputs/runs/.
See docs/analysis_plan.md for the definitions implemented here.
"""

from __future__ import annotations

import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from . import __version__
from .config import Paths, load_config, project_root
from .envelope import BOUNDARY, CORE, OUTSIDE, classify, competition_rank, envelope_ranks, overlap_row

RULES = ["PREV", "BURDEN", "EQUITY"]
RULE_LABELS = {
    "PREV": "Crude prevalence",
    "BURDEN": "Estimated adults with diagnosed diabetes",
    "EQUITY": "Crude prevalence among high-poverty counties",
}

FRAME_DTYPES = {"fips": str, "state_fips": str}


def read_frame(path: Path) -> pd.DataFrame:
    f = pd.read_csv(path, dtype=FRAME_DTYPES)
    for col in [c for c in f.columns if c.startswith("elig_")] + ["in_aligned_subset"]:
        if col in f.columns:
            f[col] = f[col].astype(bool)
    return f.sort_values("fips").reset_index(drop=True)


# Modules whose code can change a result table. Reporting and packaging modules are
# excluded so that editing a document template does not change the run identifier.
RESULT_MODULES = ["config.py", "acquire.py", "acs.py", "build.py", "envelope.py", "analyze.py"]


def code_hash(root: Path) -> str:
    h = hashlib.sha256()
    files = sorted([root / "src" / "dop" / m for m in RESULT_MODULES] + list((root / "sql").glob("*.sql")))
    for p in files:
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def run_id(cfg: dict, root: Path) -> str:
    manifest = json.loads((root / "source_manifest.json").read_text())
    parts = [cfg["_sha256"], code_hash(root)] + [
        f"{k}:{v['sha256']}" for k, v in sorted(manifest["sources"].items())]
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:12]


def rule_inputs(f: pd.DataFrame, rule: str, tag: str = "") -> dict:
    n = len(f)
    ones = np.ones(n, bool)
    if rule == "PREV":
        return dict(value=f["prev"].to_numpy(float), lo=f["prev_lcl"].to_numpy(float), hi=f["prev_ucl"].to_numpy(float),
                    point=ones, certain=ones, possible=ones)
    if rule == "BURDEN":
        return dict(value=f["burden"].to_numpy(float), lo=f[f"burden_lo{tag}"].to_numpy(float),
                    hi=f[f"burden_hi{tag}"].to_numpy(float), point=ones, certain=ones, possible=ones)
    if rule == "EQUITY":
        return dict(value=f["prev"].to_numpy(float), lo=f["prev_lcl"].to_numpy(float), hi=f["prev_ucl"].to_numpy(float),
                    point=f[f"elig_point{tag}"].to_numpy(bool), certain=f[f"elig_certain{tag}"].to_numpy(bool),
                    possible=f[f"elig_possible{tag}"].to_numpy(bool))
    raise ValueError(rule)


def _rank_within(values: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.full(len(values), np.nan)
    if mask.any():
        out[mask] = competition_rank(values[mask])
    return out


def evaluate(f: pd.DataFrame, rule: str, k: int, tag: str = "") -> pd.DataFrame:
    """Point, scenario and envelope results for one rule and capacity on frame f."""
    x = rule_inputs(f, rule, tag)
    point_rank = _rank_within(x["value"], x["point"])
    lower_rank = _rank_within(x["lo"], x["point"])
    upper_rank = _rank_within(x["hi"], x["point"])
    best, worst = envelope_ranks(x["lo"], x["hi"], best_mask=x["certain"], worst_mask=x["possible"])
    status = classify(best, worst, k, can_be_core=x["certain"], can_be_selected=x["possible"])
    best = np.where(x["possible"], best, np.nan)
    worst = np.where(x["possible"], worst, np.nan)
    out = pd.DataFrame({
        "fips": f["fips"].to_numpy(),
        "rule": rule,
        "capacity": k,
        "value": x["value"],
        "lo": x["lo"],
        "hi": x["hi"],
        "eligible_point": x["point"],
        "eligible_certain": x["certain"],
        "eligible_possible": x["possible"],
        "point_rank": point_rank,
        "selected_point": point_rank <= k,
        "lower_rank": lower_rank,
        "selected_lower": lower_rank <= k,
        "upper_rank": upper_rank,
        "selected_upper": upper_rank <= k,
        "best_rank": best,
        "worst_rank": worst,
        "envelope_status": status,
    })
    if rule == "EQUITY":
        out["selected_certain_frame"] = _rank_within(x["value"], x["certain"]) <= k
        out["selected_possible_frame"] = _rank_within(x["value"], x["possible"]) <= k
    return out


def sel(df: pd.DataFrame, rule: str, k: int, col: str = "selected_point") -> set:
    d = df[(df["rule"] == rule) & (df["capacity"] == k)]
    return set(d.loc[d[col], "fips"])


def status_set(df: pd.DataFrame, rule: str, k: int, status: str) -> set:
    d = df[(df["rule"] == rule) & (df["capacity"] == k)]
    return set(d.loc[d["envelope_status"] == status, "fips"])


def national(f: pd.DataFrame, caps: list[int], tag: str = "") -> pd.DataFrame:
    return pd.concat([evaluate(f, r, k, tag) for k in caps for r in RULES], ignore_index=True)


def envelope_summary(res: pd.DataFrame, caps: list[int], scope: str) -> pd.DataFrame:
    rows = []
    for k in caps:
        for r in RULES:
            d = res[(res["rule"] == r) & (res["capacity"] == k)]
            rows.append({
                "scope": scope, "rule": r, "capacity": k,
                "n_ranked_point": int(d["eligible_point"].sum()),
                "n_eligible_certain": int(d["eligible_certain"].sum()),
                "n_eligible_possible": int(d["eligible_possible"].sum()),
                "n_selected_point": int(d["selected_point"].sum()),
                "n_core": int((d["envelope_status"] == CORE).sum()),
                "n_boundary": int((d["envelope_status"] == BOUNDARY).sum()),
                "n_core_or_boundary": int(d["envelope_status"].isin([CORE, BOUNDARY]).sum()),
                "n_selected_lower": int(d["selected_lower"].sum()),
                "n_selected_upper": int(d["selected_upper"].sum()),
            })
    return pd.DataFrame(rows)


def rule_overlap(res: pd.DataFrame, caps: list[int], scope: str) -> pd.DataFrame:
    rows = []
    pairs = [("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")]
    for k in caps:
        for scenario, col in (("point", "selected_point"), ("lower_bounds", "selected_lower"), ("upper_bounds", "selected_upper")):
            for a, b in pairs:
                row = overlap_row(a, sel(res, a, k, col), b, sel(res, b, k, col))
                rows.append({"scope": scope, "capacity": k, "scenario": scenario, **row})
            all3 = sel(res, "PREV", k, col) & sel(res, "BURDEN", k, col) & sel(res, "EQUITY", k, col)
            rows.append({"scope": scope, "capacity": k, "scenario": scenario, "set_a": "ALL_THREE", "set_b": "",
                         "n_a": None, "n_b": None, "n_intersection": len(all3), "n_union": None, "jaccard": None})
    return pd.DataFrame(rows)


def scenario_overlap(res: pd.DataFrame, caps: list[int], scope: str) -> pd.DataFrame:
    rows = []
    for k in caps:
        for r in RULES:
            p = sel(res, r, k)
            comps = [("lower_bounds", sel(res, r, k, "selected_lower")), ("upper_bounds", sel(res, r, k, "selected_upper"))]
            if r == "EQUITY":
                comps += [("certain_eligibility_frame", sel(res, r, k, "selected_certain_frame")),
                          ("possible_eligibility_frame", sel(res, r, k, "selected_possible_frame"))]
            for name, s in comps:
                rows.append({"scope": scope, "rule": r, "capacity": k, **overlap_row("point", p, name, s)})
    return pd.DataFrame(rows)


def rule_dependence(res: pd.DataFrame, caps: list[int]) -> pd.DataFrame:
    rows = []
    for k in caps:
        d = res[res["capacity"] == k]
        wide_sel = d.pivot(index="fips", columns="rule", values="selected_point")
        wide_st = d.pivot(index="fips", columns="rule", values="envelope_status")
        keep = wide_sel.any(axis=1) | wide_st.isin([CORE, BOUNDARY]).any(axis=1)
        for fips in wide_sel.index[keep]:
            s = wide_sel.loc[fips]
            st = wide_st.loc[fips]
            n_sel = int(s.sum())
            strongly = bool((st == CORE).any() and (st == OUTSIDE).any())
            if n_sel == 3:
                cls = "selected_by_all_three"
            elif n_sel == 2:
                cls = "selected_by_two"
            elif n_sel == 1:
                cls = "selected_by_one"
            else:
                cls = "boundary_only"
            rows.append({"capacity": k, "fips": fips,
                         **{f"selected_{r}": bool(s[r]) for r in RULES},
                         **{f"status_{r}": st[r] for r in RULES},
                         "n_rules_selected": n_sel, "classification": cls,
                         "strongly_rule_dependent": strongly,
                         "core_all_three": bool((st == CORE).all())})
    return pd.DataFrame(rows)


def within_state(f: pd.DataFrame, k_state: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    results, summary = [], []
    for st, g in f.groupby("state_abbr", sort=True):
        g = g.reset_index(drop=True)
        all_units = len(g) <= k_state
        res = pd.concat([evaluate(g, r, k_state) for r in RULES], ignore_index=True)
        res["state_abbr"] = st
        res["all_units_no_selection"] = all_units
        results.append(res)
        row = {"state_abbr": st, "n_frame_counties": len(g), "capacity": k_state, "all_units_no_selection": all_units}
        for r in RULES:
            d = res[res["rule"] == r]
            row[f"{r}_n_ranked"] = int(d["eligible_point"].sum())
            row[f"{r}_n_selected"] = int(d["selected_point"].sum())
            row[f"{r}_n_core"] = int((d["envelope_status"] == CORE).sum())
            row[f"{r}_n_boundary"] = int((d["envelope_status"] == BOUNDARY).sum())
        row["EQUITY_shortfall"] = max(0, k_state - row["EQUITY_n_ranked"])
        for a, b in (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")):
            o = overlap_row(a, set(res[(res.rule == a) & res.selected_point].fips), b,
                            set(res[(res.rule == b) & res.selected_point].fips))
            row[f"jaccard_{a}_{b}"] = o["jaccard"]
        summary.append(row)
    return pd.concat(results, ignore_index=True), pd.DataFrame(summary)


def aligned_check(f: pd.DataFrame, primary: pd.DataFrame, caps: list[int]) -> tuple[pd.DataFrame, pd.DataFrame]:
    fa = f[f["in_aligned_subset"]].reset_index(drop=True)
    res = national(fa, caps, tag="_aligned")
    rows = []
    for k in caps:
        for r in RULES:
            p, q = sel(primary, r, k), sel(res, r, k)
            excluded = p - set(fa["fips"])
            rows.append({"rule": r, "capacity": k, **overlap_row("primary", p, "aligned", q),
                         "primary_selected_outside_aligned_subset": len(excluded),
                         "core_primary": len(status_set(primary, r, k, CORE)),
                         "core_aligned": len(status_set(res, r, k, CORE)),
                         "boundary_primary": len(status_set(primary, r, k, BOUNDARY)),
                         "boundary_aligned": len(status_set(res, r, k, BOUNDARY))})
    return pd.DataFrame(rows), res


def prior_release(f: pd.DataFrame, p24: pd.DataFrame, acs_primary: pd.DataFrame, primary: pd.DataFrame,
                  caps: list[int], thr: float) -> pd.DataFrame:
    p24 = p24[p24["fips"].str.fullmatch(r"\d{5}") & p24["prev"].notna() & p24["pop18_places"].notna()].copy()
    # Same poverty criterion as the primary analysis (ACS 2020-2024), so the comparison isolates the release change.
    p24 = p24.merge(acs_primary[["fips", "acs2024_pov_pct"]], on="fips", how="left")
    p24["burden"] = p24["prev"] / 100.0 * p24["pop18_places"]
    p24["elig"] = p24["acs2024_pov_pct"] >= thr
    rows = []

    def top(df, rule, k):
        if rule == "PREV":
            v, m = df["prev"].to_numpy(float), np.ones(len(df), bool)
        elif rule == "BURDEN":
            v, m = df["burden"].to_numpy(float), np.ones(len(df), bool)
        else:
            v, m = df["prev"].to_numpy(float), df["elig"].fillna(False).to_numpy(bool)
        r = _rank_within(v, m)
        return set(df.loc[r <= k, "fips"]), df.loc[r <= k, "state_abbr"]

    common = p24[p24["fips"].isin(set(f["fips"]))].reset_index(drop=True)
    for k in caps:
        for rule in RULES:
            s24c, _ = top(common, rule, k)
            s25 = sel(primary, rule, k)
            s24_full, states = top(p24.reset_index(drop=True), rule, k)
            rows.append({"rule": rule, "capacity": k,
                         **overlap_row("release_2025", s25, "release_2024_common_counties", s24c),
                         "n_counties_2024_frame": len(p24), "n_common_counties": len(common),
                         "n_selected_2024_full_frame": len(s24_full),
                         "n_KY_PA_in_2024_full_frame_selection": int(states.isin(["KY", "PA"]).sum())})
    return pd.DataFrame(rows)


def selection_profile(f: pd.DataFrame, res: pd.DataFrame, caps: list[int]) -> pd.DataFrame:
    """Descriptive profile of each point-estimate selected set (added after results, see plan amendments)."""
    total_burden = float(f["burden"].sum())
    rows = []
    for k in caps:
        for r in RULES:
            ids = sel(res, r, k)
            d = f[f["fips"].isin(ids)]
            rows.append({"rule": r, "capacity": k, "n_selected": len(d),
                         "sum_estimated_burden": float(d["burden"].sum()),
                         "share_of_frame_estimated_burden": float(d["burden"].sum()) / total_burden,
                         "frame_estimated_burden": total_burden,
                         "median_adults": float(d["pop18_places"].median()),
                         "min_adults": float(d["pop18_places"].min()), "max_adults": float(d["pop18_places"].max()),
                         "median_prevalence": float(d["prev"].median()),
                         "min_prevalence": float(d["prev"].min()), "max_prevalence": float(d["prev"].max()),
                         "n_high_poverty_point": int(d["elig_point"].sum()),
                         "n_states": int(d["state_abbr"].nunique())})
    return pd.DataFrame(rows)


def county_table(f: pd.DataFrame, res: pd.DataFrame, caps: list[int]) -> pd.DataFrame:
    keep = ["fips", "state_abbr", "county_name", "display_name", "prev", "prev_lcl", "prev_ucl", "prev_ageadj",
            "pop18_places", "acs2024_adult", "acs2024_adult_lo95", "acs2024_adult_hi95",
            "burden", "burden_lo", "burden_hi", "pov", "acs2024_pov_lo95", "acs2024_pov_hi95",
            "elig_point", "elig_certain", "elig_possible", "in_aligned_subset"]
    out = f[keep].copy()
    for k in caps:
        for r in RULES:
            d = res[(res["rule"] == r) & (res["capacity"] == k)].set_index("fips")
            out[f"{r}_K{k}_rank"] = out["fips"].map(d["point_rank"])
            out[f"{r}_K{k}_best"] = out["fips"].map(d["best_rank"])
            out[f"{r}_K{k}_worst"] = out["fips"].map(d["worst_rank"])
            out[f"{r}_K{k}_status"] = out["fips"].map(d["envelope_status"])
            out[f"{r}_K{k}_selected"] = out["fips"].map(d["selected_point"])
    return out


def analyze(frame_dir: Path | None = None, interim_dir: Path | None = None, out_dir: Path | None = None,
            write_run: bool = True) -> dict:
    cfg = load_config()
    paths = Paths(project_root())
    paths.ensure()
    a = cfg["analysis"]
    caps = list(a["national_capacities"])
    k0 = a["primary_capacity"]
    frame_dir = frame_dir or paths.processed
    interim_dir = interim_dir or paths.interim
    out = out_dir or paths.tables
    out.mkdir(parents=True, exist_ok=True)

    f = read_frame(frame_dir / "analysis_frame.csv")
    # PLACES LocationName does not distinguish independent cities from same-named counties
    # (for example Baltimore city and Baltimore County). The Census name does.
    f["display_name"] = f["pep_county_name"].fillna(f["county_name"])
    res = national(f, caps)
    state_res, state_summary = within_state(f, a["state_capacity"])
    aligned_cmp, aligned_res = aligned_check(f, res, caps)
    p24 = pd.read_csv(frame_dir / "places2024_crude.csv", dtype={"fips": str})
    acs_primary = pd.read_csv(interim_dir / f"acs{a['primary_acs_vintage']}_county.csv", dtype={"fips": str})
    prior = prior_release(f, p24, acs_primary, res, caps, a["high_poverty_threshold_pct"])

    env = envelope_summary(res, caps, "national")
    ovl = rule_overlap(res, caps, "national")
    scn = scenario_overlap(res, caps, "national")
    dep = rule_dependence(res, caps)
    ctab = county_table(f, res, caps)

    names = f.set_index("fips")[["state_abbr", "county_name", "display_name"]]
    sets = []
    for scope, df in (("national", res), ("aligned_subset", aligned_res)):
        for col, scen in (("selected_point", "point"), ("selected_lower", "lower_bounds"), ("selected_upper", "upper_bounds")):
            d = df[df[col]]
            sets.append(pd.DataFrame({"scope": scope, "state_abbr": "", "rule": d["rule"], "capacity": d["capacity"],
                                      "scenario": scen, "fips": d["fips"]}))
    d = state_res[state_res["selected_point"]]
    sets.append(pd.DataFrame({"scope": "within_state", "state_abbr": d["state_abbr"], "rule": d["rule"],
                              "capacity": d["capacity"], "scenario": "point", "fips": d["fips"]}))
    selected_sets = pd.concat(sets, ignore_index=True)
    selected_sets["county_name"] = selected_sets["fips"].map(names["county_name"])
    selected_sets["display_name"] = selected_sets["fips"].map(names["display_name"])
    selected_sets["state_abbr"] = selected_sets["fips"].map(names["state_abbr"])

    long = res.merge(names, left_on="fips", right_index=True)
    outputs = {
        "priority_long.csv": long,
        "within_state_long.csv": state_res,
        "within_state_summary.csv": state_summary,
        "envelope_summary.csv": env,
        "rule_overlap.csv": ovl,
        "scenario_overlap.csv": scn,
        "rule_dependence.csv": dep.merge(names, left_on="fips", right_index=True, how="left"),
        "robustness_aligned.csv": aligned_cmp,
        "envelope_summary_aligned.csv": envelope_summary(aligned_res, caps, "aligned_subset"),
        "prior_release_comparison.csv": prior,
        "selected_sets.csv": selected_sets,
        "county_priority_table.csv": ctab,
        "selection_profile.csv": selection_profile(f, res, caps),
    }
    for name, df in outputs.items():
        df.to_csv(out / name, index=False, float_format="%.15g")

    # Headline values used by reports. Every one is traceable to a table above.
    def env_row(r, k):
        return env[(env.rule == r) & (env.capacity == k)].iloc[0]

    def ov(k, x, y, scen="point"):
        return ovl[(ovl.capacity == k) & (ovl.scenario == scen) & (ovl.set_a == x) & (ovl.set_b == y)].iloc[0]

    headline = {
        "frame_counties": int(len(f)),
        "frame_states_incl_dc": int(f["state_abbr"].nunique()),
        "aligned_subset_counties": int(f["in_aligned_subset"].sum()),
        "high_poverty_counties_point": int(f["elig_point"].sum()),
        "high_poverty_counties_certain": int(f["elig_certain"].sum()),
        "high_poverty_counties_possible": int(f["elig_possible"].sum()),
        "primary_capacity": k0,
        "by_capacity": {},
    }
    for k in caps:
        hk = {"rules": {}, "overlap_point": {}}
        for r in RULES:
            e = env_row(r, k)
            hk["rules"][r] = {c: int(e[c]) for c in ("n_selected_point", "n_core", "n_boundary", "n_ranked_point")}
        for x, y in (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")):
            o = ov(k, x, y)
            hk["overlap_point"][f"{x}_{y}"] = {"n_intersection": int(o.n_intersection), "n_union": int(o.n_union),
                                               "jaccard": float(o.jaccard)}
        dk = dep[dep.capacity == k]
        hk["selected_by_all_three"] = int((dk.classification == "selected_by_all_three").sum())
        hk["selected_by_one"] = int((dk.classification == "selected_by_one").sum())
        hk["strongly_rule_dependent"] = int(dk.strongly_rule_dependent.sum())
        hk["core_all_three"] = int(dk.core_all_three.sum())
        hk["union_selected_any_rule"] = int((dk.n_rules_selected > 0).sum())
        prof = outputs["selection_profile.csv"]
        hk["share_of_frame_burden"] = {r: float(prof[(prof.rule == r) & (prof.capacity == k)].share_of_frame_estimated_burden.iloc[0])
                                       for r in RULES}
        headline["by_capacity"][str(k)] = hk
    (out / "headline.json").write_text(json.dumps(headline, indent=2) + "\n")

    record = {
        "run_id": run_id(cfg, paths.root),
        "package_version": __version__,
        "config_sha256": cfg["_sha256"],
        "code_sha256": code_hash(paths.root),
        "source_sha256": {k: v["sha256"] for k, v in json.loads(paths.manifest.read_text())["sources"].items()},
        "python": platform.python_version(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "platform": platform.platform(),
        "finished_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "outputs": {name: hashlib.sha256((out / name).read_bytes()).hexdigest()
                    for name in list(outputs) + ["headline.json"]},
    }
    if write_run:
        (out / "run_record.json").write_text(json.dumps(record, indent=2) + "\n")
        (paths.runs / f"{record['run_id']}.json").write_text(json.dumps(record, indent=2) + "\n")
    print(f"[analyze] run_id={record['run_id']} frame={len(f)} outputs={len(outputs)}")
    return {"headline": headline, "record": record}
