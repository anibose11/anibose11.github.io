"""Evidence and handoff files: claims with provenance, verified results, author worksheet."""

from __future__ import annotations

import json
import platform
import shutil
import subprocess
from importlib import metadata
from pathlib import Path

import pandas as pd

from .facts import Facts

HEADLINE_CLAIMS = [
    # (claim text, numerator fact, denominator fact or None, scope)
    ("Counties shared by the prevalence and estimated-burden top-25 selections", "k25_prev_burden_inter", "k25_prev_burden_union",
     "National frame, capacity 25, point estimates"),
    ("Counties shared by the high-poverty and prevalence top-25 selections", "k25_prev_equity_inter", "k25_prev_equity_union",
     "National frame, capacity 25, point estimates"),
    ("Core counties under the prevalence rule at capacity 25", "k25_prev_core", "frame_counties",
     "National frame, capacity 25, PLACES 95% bounds"),
    ("Counties that could enter the prevalence top 25 within the bounds (boundary)", "k25_prev_boundary", "frame_counties",
     "National frame, capacity 25, PLACES 95% bounds"),
    ("Core counties under the burden rule at capacity 25", "k25_burden_core", "k25_burden_selected",
     "National frame, capacity 25, burden scenario bounds"),
    ("Share of the frame's estimated adults with diagnosed diabetes inside the prevalence top 25", "k25_prev_burden_share", None,
     "National frame, capacity 25, descriptive summary added after primary results"),
    ("Share of the frame's estimated adults with diagnosed diabetes inside the burden top 25", "k25_burden_burden_share", None,
     "National frame, capacity 25, descriptive summary added after primary results"),
    ("States where prevalence and burden within-state selections share no county", "ws_prev_burden_zero", "ws_states",
     "Within-state capacity 5, states with more than 5 frame counties"),
    ("Minimum Jaccard between primary and strictly aligned selections", "aligned_min_j", None,
     "Strictly aligned subset, all rules and capacities"),
    ("Frame counties whose PLACES adult population equals the Census Vintage 2023 adult estimate", "pep_match", None, "All frame counties"),
    ("Rule results reproduced exactly by the base R implementation", "r_rows", None, "All rules, national capacities, frame counties"),
]


def runtime_manifest(root: Path) -> dict:
    def ver(cmd):
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip().splitlines()[0]
        except Exception as exc:  # noqa: BLE001
            return f"unavailable ({exc.__class__.__name__})"

    pkgs = {}
    for name in ("pandas", "numpy", "duckdb", "requests", "matplotlib", "openpyxl", "Markdown", "python-docx", "pytest"):
        try:
            pkgs[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            pkgs[name] = "not installed"
    return {
        "os": platform.platform(),
        "machine": platform.machine(),
        "python": platform.python_version(),
        "packages": pkgs,
        "R": ver(["R", "--version"]),
        "reporting_renderer": f"Python-Markdown {pkgs['Markdown']} (HTML) and python-docx {pkgs['python-docx']} (DOCX). "
                              "Quarto and pandoc were not installed on the build machine",
        "quarto": "not installed" if not shutil.which("quarto") else ver(["quarto", "--version"]),
        "database": f"DuckDB {pkgs['duckdb']} (embedded, no server)",
        "docker": "not used",
        "network": "required for `dop acquire` and for three of the four recheck scripts. The pipeline stages after acquire run offline from cached files",
    }


def write_claims(root: Path, F: Facts, run_id: str, cfg_sha: str) -> Path:
    manifest = json.loads((root / "source_manifest.json").read_text())
    items = F.items
    headline = []
    for text, num, den, scope in HEADLINE_CLAIMS:
        n = items[num]
        d = items[den] if den else None
        headline.append({
            "claim": text,
            "value": n["display"] if not d else f"{n['display']} of {d['display']}",
            "numerator": {"fact": num, **{k: n[k] for k in ("value", "source", "selector", "column")}},
            "denominator": None if not d else {"fact": den, **{k: d[k] for k in ("value", "source", "selector", "column")}},
            "scope": scope,
        })
    claims = {
        "run_id": run_id,
        "config_sha256": cfg_sha,
        "source_sha256": {k: v["sha256"] for k, v in manifest["sources"].items()},
        "counts_kept_separate": {
            "places_source_rows_all_measures": items["places_rows"]["value"],
            "places_county_equivalents": items["county_equivalents"]["value"],
            "analysis_frame_counties": items["frame_counties"]["value"],
            "aligned_subset_counties": items["aligned_counties"]["value"],
            "unit_tests": items["n_tests"]["value"],
            "automated_validation_checks": items["validation_checks"]["value"],
            "predictive_model_calls": 0,
            "build_check_violations_fatal": sum(c["n_violations"] for c in json.loads((root / "data" / "processed" / "build_checks.json").read_text())["build_checks"] if c["severity"] == "fatal"),
            "build_check_violations_report_only": sum(c["n_violations"] for c in json.loads((root / "data" / "processed" / "build_checks.json").read_text())["build_checks"] if c["severity"] == "report"),
        },
        "headline_claims": headline,
        "facts": items,
    }
    out = root / "evidence" / "claims.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(claims, indent=2, default=str) + "\n")
    return out


def verify_claims(root: Path) -> dict:
    """Re-read every fact's source and confirm the stored value (independent of facts.py logic where possible)."""
    claims = json.loads((root / "evidence" / "claims.json").read_text())
    t = root / "outputs" / "tables"
    checked, failed = 0, []
    env = pd.read_csv(t / "envelope_summary.csv")
    ovl = pd.read_csv(t / "rule_overlap.csv")
    for name, f in claims["facts"].items():
        if f["source"] == "outputs/tables/envelope_summary.csv":
            parts = dict(p.strip().split(" == ") for p in f["selector"].split("&"))
            row = env[(env.rule == parts["rule"]) & (env.capacity == int(parts["capacity"]))].iloc[0]
            ok = int(row[f["column"]]) == f["value"]
        elif f["source"] == "outputs/tables/rule_overlap.csv" and f["column"] in ("n_intersection", "n_union", "jaccard"):
            parts = dict(p.strip().split(" == ") for p in f["selector"].split("&"))
            q = ovl[(ovl.capacity == int(parts["capacity"])) & (ovl.scenario == parts["scenario"]) & (ovl.set_a == parts["set_a"])]
            if "set_b" in parts:
                q = q[q.set_b == parts["set_b"]]
            ok = abs(float(q.iloc[0][f["column"]]) - float(f["value"])) < 1e-12
        else:
            continue
        checked += 1
        if not ok:
            failed.append(name)
    return {"facts_rechecked_from_tables": checked, "failed": failed}
