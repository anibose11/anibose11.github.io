"""Validation stage.

Three kinds of checks are kept apart in the report:
  software    deterministic rerun comparison, invariants, base-R second implementation
  source      reconciliation against published source values (Census estimates, published ACS MOEs)
  report      values recorded without a pass criterion
  scientific  none is claimed here. Model-based estimates are not compared with observed outcomes
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd

from .analyze import RULES, analyze
from .build import build
from .config import Paths, load_config, project_root
from .envelope import BOUNDARY, CORE

COMPARE_TABLES = [
    "priority_long.csv", "within_state_long.csv", "within_state_summary.csv", "envelope_summary.csv",
    "rule_overlap.csv", "scenario_overlap.csv", "rule_dependence.csv", "robustness_aligned.csv",
    "envelope_summary_aligned.csv", "prior_release_comparison.csv", "selected_sets.csv",
    "county_priority_table.csv", "selection_profile.csv", "headline.json",
]
COMPARE_PROCESSED = ["analysis_frame.csv", "county_all.csv", "exclusions.csv", "places2024_crude.csv"]


def compare_csv(a: Path, b: Path, rtol: float, atol: float) -> dict:
    da = pd.read_csv(a, dtype=str, keep_default_na=False)
    db = pd.read_csv(b, dtype=str, keep_default_na=False)
    if list(da.columns) != list(db.columns) or da.shape != db.shape:
        return {"file": a.name, "equal": False, "reason": f"shape/columns differ {da.shape} vs {db.shape}"}
    mismatches = 0
    worst = 0.0
    for col in da.columns:
        x, y = da[col], db[col]
        if (x == y).all():
            continue
        xn = pd.to_numeric(x, errors="coerce")
        yn = pd.to_numeric(y, errors="coerce")
        both_num = xn.notna() & yn.notna()
        same_text = x == y
        close = np.isclose(xn[both_num], yn[both_num], rtol=rtol, atol=atol)
        bad = (~same_text & ~both_num).sum() + (~close).sum()
        if both_num.any():
            worst = max(worst, float(np.nanmax(np.abs(xn[both_num] - yn[both_num]))))
        mismatches += int(bad)
    return {"file": a.name, "equal": mismatches == 0, "n_mismatch_cells": mismatches, "max_abs_numeric_diff": worst}


def compare_json(a: Path, b: Path) -> dict:
    return {"file": a.name, "equal": json.loads(a.read_text()) == json.loads(b.read_text())}


def invariants(tables: Path, processed: Path) -> list[dict]:
    res = pd.read_csv(tables / "priority_long.csv", dtype={"fips": str})
    out = []
    for (rule, k), d in res.groupby(["rule", "capacity"]):
        core = set(d.loc[d.envelope_status == CORE, "fips"])
        poss = set(d.loc[d.envelope_status.isin([CORE, BOUNDARY]), "fips"])
        selp = set(d.loc[d.selected_point, "fips"])
        r = d[d.eligible_point]
        ok = core <= selp <= poss and (r.best_rank <= r.point_rank).all() and (r.point_rank <= r.worst_rank).all() \
            and len(selp) >= min(k, int(d.eligible_point.sum()))
        out.append({"check": f"envelope_invariants_{rule}_K{k}", "kind": "software", "passed": bool(ok),
                    "label": f"Ordering invariants hold ({rule}, capacity {k}): core within selected within core or boundary, and best <= point <= worst rank"})
    frame = pd.read_csv(processed / "analysis_frame.csv", dtype={"fips": str})
    allc = pd.read_csv(processed / "county_all.csv", dtype={"fips": str})
    out.append({"check": "frame_equals_in_frame_status", "kind": "software",
                "passed": bool(len(frame) == (allc.frame_status == "in_frame").sum()),
                "label": "Analysis frame equals the locations with status in_frame"})
    out.append({"check": "fips_five_digit_strings", "kind": "software",
                "passed": bool(frame.fips.str.fullmatch(r"\d{5}").all()),
                "label": "County FIPS codes are five-character strings with leading zeros"})
    out.append({"check": "no_territories_in_frame", "kind": "software",
                "passed": bool(not frame.fips.str[:2].isin(["60", "66", "69", "72", "78"]).any()),
                "label": "No territory is in the analysis frame"})
    out.append({"check": "burden_uses_crude_prevalence", "kind": "software",
                "passed": bool(np.allclose(frame.burden, frame.prev / 100 * frame.pop18_places, rtol=1e-12)),
                "label": "Estimated burden equals crude prevalence / 100 x adult population"})
    return out


def r_crosscheck(root: Path, tables: Path, interim: Path, out_dir: Path, cfg: dict) -> list[dict]:
    rscript = shutil.which("Rscript")
    if not rscript:
        return [{"check": "r_second_implementation", "kind": "software", "passed": False,
                 "label": "Base R second implementation", "detail": "Rscript not found. Stage blocked"}]
    a = cfg["analysis"]
    proc = subprocess.run([rscript, str(root / "R" / "reference_check.R"), str(root), str(out_dir),
                           str(a["high_poverty_threshold_pct"]), ",".join(str(k) for k in a["national_capacities"])],
                          capture_output=True, text=True)
    if proc.returncode != 0:
        return [{"check": "r_second_implementation", "kind": "software", "passed": False,
                 "label": "Base R second implementation", "detail": proc.stderr[-2000:]}]
    out = []
    r = pd.read_csv(out_dir / "r_reference.csv", dtype={"fips": str})
    p = pd.read_csv(tables / "priority_long.csv", dtype={"fips": str})
    m = p.merge(r, on=["fips", "rule", "capacity"], suffixes=("_py", "_r"), how="outer", indicator=True)
    both = m["_merge"] == "both"
    exact = {}
    for col in ("point_rank", "best_rank", "worst_rank"):
        exact[col] = bool(((m[f"{col}_py"].fillna(-1) == m[f"{col}_r"].fillna(-1)) | ~both).all())
    exact["selected_point"] = bool((m["selected_point_py"].astype(str).str.lower()
                                    == m["selected_point_r"].astype(str).str.lower()).all())
    exact["envelope_status"] = bool((m["envelope_status_py"] == m["envelope_status_r"]).all())
    num_close = {c: bool(np.allclose(m[f"{c}_py"], m[f"{c}_r"], rtol=1e-12, atol=1e-9, equal_nan=True))
                 for c in ("value", "lo", "hi")}
    out.append({"check": "r_second_implementation_rules", "kind": "software",
                "label": "Base R reimplementation reproduces burden, bounds, ranks, selections and envelope labels",
                "passed": bool(both.all() and all(exact.values()) and all(num_close.values())),
                "detail": {"rows_python": int(len(p)), "rows_r": int(len(r)), "rows_matched": int(both.sum()),
                           "exact": exact, "numeric_close": num_close}})
    ra = pd.read_csv(out_dir / "r_acs2024.csv", dtype={"fips": str})
    pa = pd.read_csv(interim / "acs2024_county.csv", dtype={"fips": str})
    ma = pa.merge(ra, on="fips", how="inner")
    acs_ok = {
        "adult": bool(np.allclose(ma.acs2024_adult, ma.adult, rtol=0, atol=1e-9, equal_nan=True)),
        "adult_se": bool(np.allclose(ma.acs2024_adult_se, ma.adult_se, rtol=1e-10, atol=1e-9, equal_nan=True)),
        "pov_pct": bool(np.allclose(ma.acs2024_pov_pct, ma.pov_pct, rtol=1e-12, atol=1e-12, equal_nan=True)),
        "pov_se": bool(np.allclose(ma.acs2024_pov_se, ma.pov_se, rtol=1e-10, atol=1e-12, equal_nan=True)),
    }
    out.append({"check": "r_second_implementation_acs_sdr", "kind": "software",
                "label": "Base R reimplementation reproduces ACS 2020-2024 adult and poverty estimates and replicate standard errors",
                "passed": bool(len(ma) == len(pa) == len(ra) and all(acs_ok.values())),
                "detail": {"n_python": int(len(pa)), "n_r": int(len(ra)), "n_matched": int(len(ma)), **acs_ok}})
    return out


def source_reconciliation(processed: Path) -> list[dict]:
    b = json.loads((processed / "build_checks.json").read_text())
    rec = b["reconciliation"]["places_adult_vs_pep_v2023"]
    out = [{"check": "places_adult_population_equals_census_v2023_age18plus", "kind": "source",
            "label": "PLACES adult population equals the Census Vintage 2023 adult estimate for every frame county",
            "passed": rec["n_exact_match"] == rec["n_compared"], "detail": rec}]
    for v, d in b["acs_derivation"].items():
        for line, s in d["published_moe_reproduction"].items():
            table, ln = line.split("_line")
            out.append({"check": f"sdr_reproduces_published_moe_{v}_{line}", "kind": "source",
                        "label": (f"Replicate standard errors reproduce published margins of error, ACS {int(v) - 4}-{v} {table} line {ln} "
                                  f"({s['n_not_controlled_within_1']:,} of {s['n_not_controlled']:,} uncontrolled cells within 1, "
                                  "criterion at least 99%)"),
                        "passed": s["n_not_controlled_within_1"] >= 0.99 * s["n_not_controlled"], "detail": s})
    out.append({"check": "acs_adult_vs_places_adult_reported", "kind": "report", "passed": True,
                "label": "ACS 2020-2024 adult estimate compared with the Vintage 2023 adult estimate (reported, no pass criterion)",
                "detail": b["reconciliation"]["acs2024_adult_vs_places_adult"]})
    return out


def validation_code_hash(root: Path) -> str:
    import hashlib
    h = hashlib.sha256()
    for p in [root / "src" / "dop" / "validate.py"] + sorted((root / "R").glob("*.R")):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def validate() -> bool:
    cfg = load_config()
    paths = Paths(project_root())
    a = cfg["analysis"]
    vdir = paths.root / "outputs" / "validation"
    vdir.mkdir(parents=True, exist_ok=True)
    rerun = vdir / "rerun"
    if rerun.exists():
        shutil.rmtree(rerun)
    (rerun / "interim").mkdir(parents=True)
    (rerun / "processed").mkdir()
    (rerun / "tables").mkdir()

    # 1. Deterministic rerun from cached raw inputs into a separate directory.
    build(interim=rerun / "interim", processed=rerun / "processed")
    analyze(frame_dir=rerun / "processed", interim_dir=rerun / "interim", out_dir=rerun / "tables", write_run=False)
    rerun_results = []
    for name in COMPARE_PROCESSED:
        rerun_results.append(compare_csv(paths.processed / name, rerun / "processed" / name,
                                         a["rerun_rel_tolerance"], a["rerun_abs_tolerance"]))
    for name in COMPARE_TABLES:
        fa, fb = paths.tables / name, rerun / "tables" / name
        rerun_results.append(compare_json(fa, fb) if name.endswith(".json")
                             else compare_csv(fa, fb, a["rerun_rel_tolerance"], a["rerun_abs_tolerance"]))
    checks = [{"check": "deterministic_rerun", "kind": "software", "passed": all(r["equal"] for r in rerun_results),
               "label": "Rerun of the build and analysis stages from cached inputs reproduces the processed and result tables",
               "detail": rerun_results,
               "tolerance": {"rel": a["rerun_rel_tolerance"], "abs": a["rerun_abs_tolerance"]}}]
    checks += invariants(paths.tables, paths.processed)
    checks += r_crosscheck(paths.root, paths.tables, paths.interim, vdir, cfg)
    checks += source_reconciliation(paths.processed)
    report = {
        "run_id": json.loads((paths.tables / "run_record.json").read_text())["run_id"],
        "all_passed": all(c["passed"] for c in checks if c["kind"] in ("software", "source")),
        "n_pass_fail_checks": sum(1 for c in checks if c["kind"] in ("software", "source")),
        "validation_code_sha256": validation_code_hash(paths.root),
        "checks": checks,
        "scientific_validation": "Not performed. PLACES estimates are model-based. No observed county outcome data were used.",
    }
    (vdir / "validation_report.json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    shutil.rmtree(rerun / "interim")
    for c in checks:
        print(f"[validate] {'PASS' if c['passed'] else 'FAIL'} {c['kind']:8s} {c['check']}")
    return report["all_passed"]
