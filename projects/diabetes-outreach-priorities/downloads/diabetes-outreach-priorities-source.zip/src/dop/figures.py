"""Static figures drawn from the analysis tables (PNG for documents, SVG for the web page).

Colors follow a validated categorical set (blue, orange, violet) on a light
surface. Identity never depends on color alone: every figure has a legend,
shapes differ between sets, and each figure has an equivalent table.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
BLUE = "#2a78d6"
ORANGE = "#eb6834"
ORANGE_EDGE = "#a8431b"
BLUE_EDGE = "#1a4f90"
VIOLET = "#4a3aa7"  # passes 3:1 contrast and colorblind separation from blue and orange
CONTEXT = "#c9c8c2"

RULE_NAMES = {"PREV": "Prevalence", "BURDEN": "Estimated burden", "EQUITY": "High-poverty prevalence"}


def _style():
    plt.rcParams.update({
        "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
        "font.size": 9,
        "axes.edgecolor": GRID,
        "axes.labelcolor": INK2,
        "axes.titlecolor": INK,
        "xtick.color": INK2,
        "ytick.color": INK2,
        "axes.facecolor": SURFACE,
        "figure.facecolor": SURFACE,
        "savefig.facecolor": SURFACE,
        "axes.grid": False,
        "svg.fonttype": "none",
        "svg.hashsalt": "dop",  # deterministic element ids so reruns produce identical SVG files
    })


def _save(fig, out: Path, stem: str) -> list[Path]:
    paths = []
    for ext, kw in (("png", {"dpi": 300}), ("svg", {})):
        p = out / f"{stem}.{ext}"
        fig.savefig(p, bbox_inches="tight", metadata={"Date": None} if ext == "svg" else {}, **kw)
        paths.append(p)
    plt.close(fig)
    return paths


def fig_capacity_envelope(env: pd.DataFrame, out: Path) -> list[Path]:
    """Core and boundary counts against each capacity, per rule."""
    rules = ["PREV", "BURDEN", "EQUITY"]
    caps = sorted(env["capacity"].unique())
    rows = [(r, k) for r in rules for k in caps]
    fig, ax = plt.subplots(figsize=(7.2, 3.9))
    y = np.arange(len(rows))[::-1].astype(float)
    # Small gap between rule groups.
    for i, (r, k) in enumerate(rows):
        y[i] -= rules.index(r) * 0.6
    xmax = env["n_core_or_boundary"].max()
    for yi, (r, k) in zip(y, rows):
        e = env[(env.rule == r) & (env.capacity == k)].iloc[0]
        core, bnd = int(e.n_core), int(e.n_boundary)
        h = 0.62
        if core:
            ax.barh(yi, core, height=h, color=BLUE, edgecolor=SURFACE, linewidth=1.5)
        if bnd:
            ax.barh(yi, bnd, left=core, height=h, color=ORANGE, edgecolor=SURFACE, linewidth=1.5)
        ax.plot([k, k], [yi - 0.42, yi + 0.42], color=INK, linewidth=1.6, solid_capstyle="butt")
        ax.text(core + bnd + xmax * 0.012, yi, f"{core} core, {bnd} boundary", va="center", ha="left",
                fontsize=8, color=INK2)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{RULE_NAMES[r]}, K = {k}" for r, k in rows], color=INK2)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(0, xmax * 1.32)
    ax.set_xlabel("Number of counties")
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.xaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color=BLUE, label="Core: selected at every point inside the bounds"),
                       Patch(color=ORANGE, label="Boundary: selected at some points inside the bounds"),
                       Line2D([0], [0], color=INK, linewidth=1.6, label="Capacity K")],
              loc="upper left", bbox_to_anchor=(0.0, -0.14), ncol=1, frameon=False, fontsize=8, labelcolor=INK2)
    return _save(fig, out, "fig2_capacity_envelope")


def fig_rank_envelopes(long: pd.DataFrame, names: pd.DataFrame, k: int, out: Path, n_show: int = 35) -> list[Path]:
    """Best-to-worst rank ranges for the top counties by point rank under PREV and BURDEN."""
    fig, axes = plt.subplots(1, 2, figsize=(7.4, 7.6), sharex=True)
    for ax, rule in zip(axes, ["PREV", "BURDEN"]):
        d = long[(long.rule == rule) & (long.capacity == k)].sort_values(["point_rank", "fips"]).head(n_show)
        if "display_name" not in d.columns:
            d = d.merge(names, left_on="fips", right_index=True)
        yy = np.arange(len(d))[::-1]
        for yi, (_, r) in zip(yy, d.iterrows()):
            col = BLUE if r.envelope_status == "core" else ORANGE if r.envelope_status == "boundary" else CONTEXT
            ax.plot([r.best_rank, r.worst_rank], [yi, yi], color=col, linewidth=2, solid_capstyle="round")
            ax.scatter([r.point_rank], [yi], s=22, color=col, edgecolor=SURFACE, linewidth=1.2, zorder=3)
        ax.axvline(k, color=INK, linewidth=1)
        ax.text(k * 1.06, len(d) - 0.2, f"K = {k}", fontsize=8, color=INK, va="bottom")
        ax.set_yticks(yy)
        ax.set_yticklabels([f"{r.display_name}, {r.state_abbr}" for _, r in d.iterrows()], fontsize=6.6, color=INK2)
        ax.tick_params(axis="y", length=0)
        ax.set_xscale("log")
        ax.set_xlim(0.8, 1000)
        ax.set_xticks([1, 10, 25, 100, 1000])
        ax.set_xticklabels(["1", "10", "25", "100", "1,000"])
        ax.set_title(RULE_NAMES[rule], fontsize=9.5, loc="left", color=INK)
        ax.xaxis.grid(True, color=GRID, linewidth=0.8)
        ax.set_axisbelow(True)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.set_xlabel("Rank (log scale)")
    from matplotlib.lines import Line2D
    fig.legend(handles=[Line2D([0], [0], color=BLUE, linewidth=2, marker="o", markersize=5, label="Core"),
                        Line2D([0], [0], color=ORANGE, linewidth=2, marker="o", markersize=5, label="Boundary")],
               loc="lower center", ncol=2, frameon=False, fontsize=8, labelcolor=INK2, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    return _save(fig, out, "fig3_rank_envelopes")


def fig_selection_scatter(ctab: pd.DataFrame, k: int, out: Path) -> list[Path]:
    """Where each rule's selections sit in prevalence and adult population."""
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.scatter(ctab.pop18_places, ctab.prev, s=5, color=CONTEXT, linewidth=0, label=f"All frame counties (n = {len(ctab):,})")
    b = ctab[ctab[f"BURDEN_K{k}_selected"] == True]  # noqa: E712
    p = ctab[ctab[f"PREV_K{k}_selected"] == True]  # noqa: E712
    e = ctab[ctab[f"EQUITY_K{k}_selected"] == True]  # noqa: E712
    ax.scatter(b.pop18_places, b.prev, s=30, marker="s", facecolor=ORANGE, edgecolor=ORANGE_EDGE, linewidth=0.7, alpha=0.75,
               label=f"Estimated burden, top {k} (n = {len(b)})", zorder=3)
    ax.scatter(p.pop18_places, p.prev, s=30, marker="o", facecolor=BLUE, edgecolor=BLUE_EDGE, linewidth=0.7, alpha=0.75,
               label=f"Prevalence, top {k} (n = {len(p)})", zorder=3)
    ax.scatter(e.pop18_places, e.prev, s=70, marker="o", facecolor="none", edgecolor=VIOLET, linewidth=1.4,
               label=f"High-poverty prevalence, top {k} (n = {len(e)})", zorder=4)
    ax.set_xscale("log")
    ax.set_xlabel("Adults aged 18 and older, Census Vintage 2023 estimate (log scale)")
    ax.set_ylabel("Crude prevalence of diagnosed diabetes (%)")
    ax.set_xticks([100, 1_000, 10_000, 100_000, 1_000_000, 10_000_000])
    ax.set_xticklabels(["100", "1,000", "10,000", "100,000", "1,000,000", "10,000,000"])
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.legend(loc="upper right", frameon=False, fontsize=7.5, labelcolor=INK2)
    return _save(fig, out, "fig1_selection_scatter")


def make_figures(tables: Path, out: Path, k: int) -> dict:
    _style()
    out.mkdir(parents=True, exist_ok=True)
    env = pd.read_csv(tables / "envelope_summary.csv")
    long = pd.read_csv(tables / "priority_long.csv", dtype={"fips": str})
    ctab = pd.read_csv(tables / "county_priority_table.csv", dtype={"fips": str})
    names = ctab.set_index("fips")[["state_abbr", "county_name", "display_name"]]
    made = {}
    for old in out.glob("fig*_*.*"):
        old.unlink()
    made["fig1"] = fig_selection_scatter(ctab, k, out)
    made["fig2"] = fig_capacity_envelope(env, out)
    made["fig3"] = fig_rank_envelopes(long, names, k, out)
    return {k_: [str(p) for p in v] for k_, v in made.items()}
