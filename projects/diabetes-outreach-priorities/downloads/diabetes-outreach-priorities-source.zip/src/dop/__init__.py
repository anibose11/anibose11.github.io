"""County diabetes outreach priorities under alternative need definitions and published uncertainty."""

__version__ = "1.0.0"
