"""Configuration and project paths."""

from __future__ import annotations

import hashlib
import tomllib
from dataclasses import dataclass
from pathlib import Path


def project_root() -> Path:
    # src/dop/config.py -> project root is two levels above src/
    return Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Paths:
    root: Path

    @property
    def config(self) -> Path:
        return self.root / "config" / "study.toml"

    @property
    def raw(self) -> Path:
        return self.root / "data" / "raw"

    @property
    def interim(self) -> Path:
        return self.root / "data" / "interim"

    @property
    def processed(self) -> Path:
        return self.root / "data" / "processed"

    @property
    def tables(self) -> Path:
        return self.root / "outputs" / "tables"

    @property
    def figures(self) -> Path:
        return self.root / "outputs" / "figures"

    @property
    def runs(self) -> Path:
        return self.root / "outputs" / "runs"

    @property
    def manifest(self) -> Path:
        return self.root / "source_manifest.json"

    @property
    def sql(self) -> Path:
        return self.root / "sql"

    def ensure(self) -> None:
        for p in (self.raw, self.interim, self.processed, self.tables, self.figures, self.runs):
            p.mkdir(parents=True, exist_ok=True)


def load_config(path: Path | None = None) -> dict:
    path = path or Paths(project_root()).config
    with open(path, "rb") as fh:
        cfg = tomllib.load(fh)
    cfg["_path"] = str(path)
    cfg["_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    return cfg
