"""Command-line entry point: dop <stage>.

Stages run in order acquire -> build -> analyze -> validate -> render -> package.
Each stage reads only the outputs of earlier stages, so any stage can be rerun
on its own from cached inputs.
"""

from __future__ import annotations

import argparse
import sys
import time


def _stage(name: str, fn, *args, **kwargs):
    t0 = time.time()
    print(f"== {name}")
    out = fn(*args, **kwargs)
    print(f"== {name} finished in {time.time() - t0:.1f}s")
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dop", description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)
    p_acq = sub.add_parser("acquire", help="download and validate raw sources (cached by SHA-256)")
    p_acq.add_argument("--refresh", action="store_true", help="re-download even when cached")
    p_acq.add_argument("--only", nargs="*", help="source ids to acquire")
    sub.add_parser("build", help="stage, check and join sources into the analysis frame")
    sub.add_parser("analyze", help="run the prespecified priority rules, envelopes and robustness checks")
    sub.add_parser("validate", help="rerun comparison, R cross-check, reconciliation and invariant checks")
    sub.add_parser("render", help="figures, workbook, dashboard and reports from the analysis outputs")
    sub.add_parser("package", help="build the source archive")
    p_demo = sub.add_parser("demo", help="run the rules on the bundled synthetic fixture (not study data)")
    p_demo.add_argument("--out", default=None, help="output directory (default outputs/demo)")
    sub.add_parser("all", help="acquire, build, analyze, validate, then render and package if validation passed")
    args = parser.parse_args(argv)

    if args.cmd == "acquire":
        from .acquire import acquire
        _stage("acquire", acquire, refresh=args.refresh, only=args.only)
    elif args.cmd == "build":
        from .build import build
        _stage("build", build)
    elif args.cmd == "analyze":
        from .analyze import analyze
        _stage("analyze", analyze)
    elif args.cmd == "validate":
        from .validate import validate
        ok = _stage("validate", validate)
        return 0 if ok else 1
    elif args.cmd == "render":
        from .render import render
        _stage("render", render)
    elif args.cmd == "package":
        from .package import package
        _stage("package", package)
    elif args.cmd == "demo":
        from .demo import demo
        _stage("demo", demo, out=args.out)
    elif args.cmd == "all":
        from .acquire import acquire
        from .analyze import analyze
        from .build import build
        from .render import render
        from .validate import validate
        from .package import package
        _stage("acquire", acquire)
        _stage("build", build)
        _stage("analyze", analyze)
        ok = _stage("validate", validate)
        if not ok:
            print("validation failed. Stopping before render and package")
            return 1
        _stage("render", render)
        _stage("package", package)
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
