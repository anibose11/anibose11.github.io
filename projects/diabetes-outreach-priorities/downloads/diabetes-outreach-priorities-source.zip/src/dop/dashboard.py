"""Static dashboard: filters operate only on bundled, precomputed rows.

No value is recomputed in the browser. Filters select which precomputed rows are
shown. Ranks, bounds and statuses come from outputs/tables.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from .report import PAGE_CSS

RULES = ["PREV", "BURDEN", "EQUITY"]
CAPS = [10, 25, 50]


def _n(x, nd=None):
    if pd.isna(x):
        return None
    x = float(x)
    return round(x, nd) if nd is not None else x


def build_data(root: Path) -> dict:
    t = root / "outputs" / "tables"
    ctab = pd.read_csv(t / "county_priority_table.csv", dtype={"fips": str})
    ws = pd.read_csv(t / "within_state_long.csv", dtype={"fips": str})
    st_all = pd.read_csv(t / "within_state_summary.csv").set_index("state_abbr")["all_units_no_selection"].to_dict()
    code = {"core": "c", "boundary": "b", "outside": "o"}
    rows = []
    wsi = ws.set_index(["fips", "rule"])
    for _, r in ctab.iterrows():
        rec = {"f": r.fips, "s": r.state_abbr, "n": r.display_name,
               "p": _n(r.prev, 1), "pl": _n(r.prev_lcl, 1), "pu": _n(r.prev_ucl, 1),
               "a": int(r.pop18_places), "b": _n(r.burden, 0), "bl": _n(r.burden_lo, 0), "bh": _n(r.burden_hi, 0),
               "v": _n(r.pov, 1), "vl": _n(r.acs2024_pov_lo95, 1), "vu": _n(r.acs2024_pov_hi95, 1),
               "r": {}, "w": {}}
        for rule in RULES:
            rec["r"][rule] = {}
            for k in CAPS:
                rk = r[f"{rule}_K{k}_rank"]
                rec["r"][rule][k] = [None if pd.isna(rk) else int(rk),
                                     None if pd.isna(r[f"{rule}_K{k}_best"]) else int(r[f"{rule}_K{k}_best"]),
                                     None if pd.isna(r[f"{rule}_K{k}_worst"]) else int(r[f"{rule}_K{k}_worst"]),
                                     code[r[f"{rule}_K{k}_status"]], bool(r[f"{rule}_K{k}_selected"])]
            x = wsi.loc[(r.fips, rule)]
            rec["w"][rule] = [None if pd.isna(x.point_rank) else int(x.point_rank),
                              None if pd.isna(x.best_rank) else int(x.best_rank),
                              None if pd.isna(x.worst_rank) else int(x.worst_rank), code[x.envelope_status],
                              bool(x.selected_point)]
        rows.append(rec)
    env = pd.read_csv(t / "envelope_summary.csv")
    ovl = pd.read_csv(t / "rule_overlap.csv")
    summary = {}
    for k in CAPS:
        e = {r: env[(env.rule == r) & (env.capacity == k)].iloc[0] for r in RULES}
        o = {}
        for x, y in (("PREV", "BURDEN"), ("PREV", "EQUITY"), ("BURDEN", "EQUITY")):
            q = ovl[(ovl.capacity == k) & (ovl.scenario == "point") & (ovl.set_a == x) & (ovl.set_b == y)].iloc[0]
            o[f"{x}|{y}"] = [int(q.n_intersection), int(q.n_union), round(float(q.jaccard), 2)]
        summary[k] = {"env": {r: [int(e[r].n_selected_point), int(e[r].n_core), int(e[r].n_boundary)] for r in RULES},
                      "ovl": o}
    return {"rows": rows, "summary": summary, "allUnits": {k: bool(v) for k, v in st_all.items()}}


JS = r"""
const D = JSON.parse(document.getElementById('data').textContent);
const RL = {PREV:'Prevalence', BURDEN:'Estimated burden', EQUITY:'High-poverty prevalence'};
const ST = {c:'Core', b:'Boundary', o:'Outside'};
const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = (x, d=0) => x === null || x === undefined ? 'n/a' : Number(x).toLocaleString('en-US', {minimumFractionDigits:d, maximumFractionDigits:d});
const states = [...new Set(D.rows.map(r => r.s))].sort();
for (const s of states) { const o = document.createElement('option'); o.value = s; o.textContent = s; $('state').appendChild(o); }

function summary() {
  const k = $('cap').value, S = D.summary[k];
  let h = '';
  for (const r of ['PREV','BURDEN','EQUITY']) { const e = S.env[r]; h += `<tr><th scope="row">${RL[r]}</th><td style="text-align:right">${e[0]}</td><td style="text-align:right">${e[1]}</td><td style="text-align:right">${e[2]}</td></tr>`; }
  $('envbody').innerHTML = h;
  let o = '';
  for (const [key, v] of Object.entries(S.ovl)) { const [a,b] = key.split('|'); o += `<tr><th scope="row">${RL[a]} and ${RL[b]}</th><td style="text-align:right">${v[0]}</td><td style="text-align:right">${v[1]}</td><td style="text-align:right">${v[2].toFixed(2)}</td></tr>`; }
  $('ovlbody').innerHTML = o;
  $('capnote').textContent = k;
}

function render() {
  summary();
  const rule = $('rule').value, k = $('cap').value, scope = $('scope').value, st = $('state').value, want = $('status').value;
  const q = $('q').value.trim().toLowerCase();
  if (scope === 'state' && st === '') { $('state').value = states[0]; return render(); }
  const rows = [];
  for (const r of D.rows) {
    if (st && r.s !== st) continue;
    if (q && !r.n.toLowerCase().includes(q)) continue;
    const x = scope === 'state' ? r.w[rule] : r.r[rule][k];
    // States with 5 or fewer counties list every unit. Nothing is selected there, so the status filter does not apply.
    const allUnitsRow = scope === 'state' && D.allUnits[r.s];
    if (!allUnitsRow) {
    if (want === 'cb' && !(x[3] === 'c' || x[3] === 'b')) continue;
    if (want === 'sel' && !x[4]) continue;
    if (want === 'c' && x[3] !== 'c') continue;
    if (want === 'b' && x[3] !== 'b') continue;
    }
    rows.push([r, x]);
  }
  rows.sort((A, B) => (A[1][0] ?? 1e9) - (B[1][0] ?? 1e9) || A[0].f.localeCompare(B[0].f));
  const isB = rule === 'BURDEN';
  $('valhead').textContent = isB ? 'Estimated adults with diagnosed diabetes (scenario bounds)' : 'Crude prevalence, % (95% interval)';
  const out = [];
  for (const [r, x] of rows) {
    const val = isB ? `${fmt(r.b)} <span class="iv">(${fmt(r.bl)} to ${fmt(r.bh)})</span>` : `${fmt(r.p,1)} <span class="iv">(${fmt(r.pl,1)} to ${fmt(r.pu,1)})</span>`;
    const allUnits = scope === 'state' && D.allUnits[r.s];
    const rng = x[1] === null ? 'not eligible' : `${x[1]} to ${x[2]}`;
    const rank = allUnits ? '' : (x[0] ?? (x[1] === null ? 'not eligible' : 'not eligible at estimate'));
    const stat = allUnits ? 'All units (no selection)' : `<span class="st st-${x[3]}">${ST[x[3]]}</span>${x[4] ? ' <span class="sel">selected</span>' : ''}`;
    out.push(`<tr><td style="text-align:right">${rank}</td><th scope="row">${esc(r.n)}</th><td>${r.s}</td><td style="text-align:right">${val}</td><td style="text-align:right">${rng}</td><td>${stat}</td><td style="text-align:right">${fmt(r.a)}</td><td style="text-align:right">${fmt(r.v,1)} <span class="iv">(${fmt(r.vl,1)} to ${fmt(r.vu,1)})</span></td><td>${r.f}</td></tr>`);
  }
  $('tbody').innerHTML = out.join('') || '<tr><td colspan="9">No counties match these filters.</td></tr>';
  const capText = scope === 'state' ? 'capacity 5 within the state' + (st && D.allUnits[st] ? ' (5 or fewer counties: all units shown, no selection)' : '') : `national capacity ${k}`;
  $('count').textContent = `${rows.length} ${rows.length === 1 ? 'county' : 'counties'} shown. ${RL[rule]} rule, ${capText}.`;
  $('cap').disabled = scope === 'state';
}
for (const id of ['rule','cap','scope','state','status']) $(id).addEventListener('change', render);
$('q').addEventListener('input', render);
render();
"""


def build_dashboard(root: Path, out: Path, run_id: str) -> Path:
    data = build_data(root)
    data_json = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
    css = PAGE_CSS + """
.controls{display:flex;flex-wrap:wrap;gap:12px;margin:12px 0}
.controls label{display:flex;flex-direction:column;font-size:14px;color:var(--ink2);gap:4px}
.controls select,.controls input{font:inherit;font-size:15px;padding:6px 8px;border:1px solid #767570;background:#fff;color:var(--ink);min-height:44px}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(300px,100%),1fr));gap:16px}
.iv{color:var(--muted);font-size:13px;white-space:nowrap}
.st{font-weight:600}.st-c{color:#1d5fa8}.st-b{color:#9a3d14}.st-o{color:var(--muted);font-weight:400}
.sel{font-size:12px;border:1px solid var(--rule);padding:0 4px;white-space:nowrap}
#count{font-weight:600;margin:8px 0}
tbody th{font-weight:400}
"""
    body = f"""
<nav class="crumbs"><a href="./index.html">Project overview</a> / Priority tables</nav>
<h1>County diabetes outreach priority tables</h1>
<p class="meta">CDC PLACES County Data, 2025 release (diagnosed diabetes among adults, BRFSS 2023), Census Bureau Vintage 2023 adult population estimates and ACS 2020-2024 poverty estimates. Kentucky and Pennsylvania have no diagnosed-diabetes estimates in this release and are not listed. Run {run_id}.</p>
<p>Each rule ranks the same counties differently. <b>Core</b> counties are selected wherever every county's value falls within the bounds used for that rule (the published PLACES 95% limits and, for estimated burden, scenario bounds that also span the adult population range). <b>Boundary</b> counties are selected for some values within the bounds. For high-poverty prevalence, eligibility also spans the ACS 95% poverty bounds. A county whose upper bound reaches 20% can be boundary, and only a county whose lower bound reaches 20% can be core. These labels describe the published estimates and are not probabilities. All values below were computed by the analysis pipeline. The filters only choose which rows to show.</p>
<h2>How much the rules agree at capacity <span id="capnote"></span></h2>
<div class="two">
<div class="table-wrap" tabindex="0" role="region" aria-labelledby="envcap"><table><caption id="envcap" class="meta" style="text-align:left;padding:6px 8px">Selected, core and boundary counties</caption><thead><tr><th scope="col">Rule</th><th scope="col" style="text-align:right">Selected</th><th scope="col" style="text-align:right">Core</th><th scope="col" style="text-align:right">Boundary</th></tr></thead><tbody id="envbody"></tbody></table></div>
<div class="table-wrap" tabindex="0" role="region" aria-labelledby="ovlcap"><table><caption id="ovlcap" class="meta" style="text-align:left;padding:6px 8px">Overlap of point-estimate selections</caption><thead><tr><th scope="col">Rules compared</th><th scope="col" style="text-align:right">Counties in both</th><th scope="col" style="text-align:right">Counties in either</th><th scope="col" style="text-align:right">Jaccard</th></tr></thead><tbody id="ovlbody"></tbody></table></div>
</div>
<h2>County table</h2>
<div class="controls" role="group" aria-label="Table filters">
<label for="rule">Rule<select id="rule"><option value="PREV">Prevalence</option><option value="BURDEN">Estimated burden</option><option value="EQUITY">High-poverty prevalence</option></select></label>
<label for="scope">Scope<select id="scope"><option value="national">National</option><option value="state">Within state (capacity 5)</option></select></label>
<label for="cap">National capacity<select id="cap"><option>10</option><option selected>25</option><option>50</option></select></label>
<label for="state">State<select id="state"><option value="">All states</option></select></label>
<label for="status">Show<select id="status"><option value="cb">Core or boundary</option><option value="sel">Selected by point estimate</option><option value="c">Core only</option><option value="b">Boundary only</option><option value="all">All counties</option></select></label>
<label for="q">County name<input id="q" type="search" autocomplete="off"></label>
</div>
<p id="count" aria-live="polite"></p>
<div class="table-wrap" tabindex="0" role="region" aria-label="County priority table">
<table>
<caption class="meta" style="text-align:left;padding:6px 8px">Ranks are competition ranks on the full national frame (or the full state) and ties share a rank. High-poverty prevalence ranks counties whose poverty estimate is at least 20%. Counties with an estimate below 20% but an upper 95% bound of 20% or more have no point rank (shown as not eligible at estimate) but can be boundary, and counties whose bounds straddle 20% cannot be core. Poverty is ACS 2020-2024 percent below the poverty level with 95% bounds.</caption>
<thead><tr><th scope="col" style="text-align:right">Rank</th><th scope="col">County</th><th scope="col">State</th><th scope="col" style="text-align:right" id="valhead"></th><th scope="col" style="text-align:right">Best to worst rank</th><th scope="col">Status</th><th scope="col" style="text-align:right">Adults (Vintage 2023)</th><th scope="col" style="text-align:right">Poverty, % (95% bounds)</th><th scope="col">FIPS</th></tr></thead>
<tbody id="tbody"></tbody>
</table>
</div>
<h2>Definitions</h2>
<ul>
<li><b>Prevalence</b>: crude percentage of adults aged 18 and older reporting diagnosed diabetes (PLACES model-based estimate).</li>
<li><b>Estimated burden</b>: prevalence times the adult population. Bounds combine the PLACES interval with the Vintage 2023 estimate and the ACS 2020-2024 95% range for adults. They are scenario bounds, not a confidence interval.</li>
<li><b>High-poverty prevalence</b>: prevalence ranked among counties where at least 20% of people are below the poverty level. Counties whose poverty bounds straddle 20% can be boundary but not core.</li>
<li><b>States with 5 or fewer counties</b> (District of Columbia, Delaware, Hawaii, Rhode Island): in the within-state view all units are listed and none is selected.</li>
<li><b>Best to worst rank</b>: the best and worst rank a county can take when every county's value stays within its bounds.</li>
</ul>
<script type="application/json" id="data">{data_json}</script>
<script>{JS}</script>
"""
    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Diabetes priority tables</title>
<meta name="description" content="Ranked county tables for three diabetes outreach need definitions with published-uncertainty labels.">
<style>{css}</style>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<main id="main" class="wide">
{body}
</main>
</body>
</html>
"""
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(page)
    return out
