"""Derive county ACS quantities from Census variance replicate tables.

Variance follows the successive differences replication formula in the Census
Bureau's "Documentation for the 2020-2024 Variance Replicate Estimates Tables":
Var = 4/80 * sum_r (rep_r - estimate)^2, MOE90 = 1.645 * sqrt(Var).

Derived quantities:
* adults 18+ = B05003 line 8 (male, 18 years and over) + line 19 (female, 18 years and over)
* poverty percent = 100 * B17001 line 2 / B17001 line 1

Estimates whose component cells all carry CME '*****' are population-controlled
and have no sampling error. A derived adult estimate with zero replicate variance
that is not controlled is flagged (status moe_zero_not_controlled), and the build
stage stops if such a county is in the analysis frame. Poverty percentages of 0
or 100, or with zero replicate variance, are flagged moe_special_case. Their
standard error is left missing and eligibility then uses the point estimate.
"""

from __future__ import annotations

import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

N_REP = 80
REP_COLS = [f"Var_Rep{i}" for i in range(1, N_REP + 1)]

# Expected line titles. A mismatch means the table layout changed and fails loudly.
B05003_LINES = {"1": "Total:", "2": "Male:", "8": "18 years and over:", "13": "Female:", "19": "18 years and over:"}
B17001_LINES = {"1": "Total:", "2": "Income in the past 12 months below poverty level:"}


class ACSLayoutError(RuntimeError):
    pass


def sdr_se(est: np.ndarray, reps: np.ndarray) -> np.ndarray:
    """Standard error from 80 SDR replicates. est shape (n,), reps shape (n, 80)."""
    diff = reps - est[:, None]
    return np.sqrt(4.0 / N_REP * np.sum(diff * diff, axis=1))


def read_vrt(zip_path: Path, member: str) -> pd.DataFrame:
    with zipfile.ZipFile(zip_path) as zf, zf.open(member) as fh:
        df = pd.read_csv(fh, dtype=str, keep_default_na=False, encoding="latin-1")
    df = df[df["GEOID"] != ""].copy()
    if not df["GEOID"].str.startswith("0500000US").all():
        raise ACSLayoutError(f"{zip_path.name}: non-county GEOID found")
    df["fips"] = df["GEOID"].str.slice(9)
    if not df["fips"].str.fullmatch(r"\d{5}").all():
        raise ACSLayoutError(f"{zip_path.name}: malformed county FIPS")
    if df.duplicated(["fips", "ORDER"]).any():
        raise ACSLayoutError(f"{zip_path.name}: duplicate county-line rows")
    return df


def _lines(df: pd.DataFrame, expected: dict[str, str], table: str) -> dict[str, pd.DataFrame]:
    out = {}
    for order, title in expected.items():
        sub = df[df["ORDER"] == order]
        titles = sub["TITLE"].unique().tolist()
        if titles != [title]:
            raise ACSLayoutError(f"{table} line {order}: titles {titles} != {title!r}")
        sub = sub.set_index("fips").sort_index()
        out[order] = sub
    idx = out[next(iter(out))].index
    for order, sub in out.items():
        if not sub.index.equals(idx):
            raise ACSLayoutError(f"{table} line {order}: county set differs across lines")
    return out


def _num(sub: pd.DataFrame, cols) -> np.ndarray:
    return sub[cols].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)


def published_moe_check(sub: pd.DataFrame) -> dict:
    """Reproduce the published integer MOE of a single published line from its replicates."""
    est = _num(sub, ["ESTIMATE"]).ravel()
    reps = _num(sub, REP_COLS)
    moe = 1.645 * sdr_se(est, reps)
    pub = _num(sub, ["MOE"]).ravel()
    controlled = (sub["CME"] == "*****").to_numpy()
    diff = np.abs(np.round(moe) - pub)
    nc = ~controlled
    mism = nc & (diff > 1)
    return {
        "n": int(len(sub)),
        "n_controlled": int(controlled.sum()),
        "n_not_controlled": int(nc.sum()),
        "n_not_controlled_within_1": int((diff[nc] <= 1).sum()),
        "max_abs_diff_not_controlled": float(diff[nc].max()) if nc.any() else 0.0,
        "median_abs_diff_not_controlled": float(np.median(diff[nc])) if nc.any() else 0.0,
        "n_mismatch_with_all_replicates_equal_estimate": int((mism & (moe == 0)).sum()),
        "mismatch_published_moe_min": float(pub[mism].min()) if mism.any() else None,
        "mismatch_published_moe_max": float(pub[mism].max()) if mism.any() else None,
    }


def derive(b05003_zip: Path, b17001_zip: Path, vintage: int, z90: float, z95: float) -> tuple[pd.DataFrame, dict]:
    b05 = _lines(read_vrt(b05003_zip, "050/B05003.csv"), B05003_LINES, "B05003")
    b17 = _lines(read_vrt(b17001_zip, "050/B17001.csv"), B17001_LINES, "B17001")
    if not b05["1"].index.equals(b17["1"].index):
        raise ACSLayoutError("B05003 and B17001 county sets differ")
    fips = b05["1"].index

    # Male 18+ must sit inside the male block and female 18+ inside the female block.
    m18, f18 = b05["8"], b05["19"]
    adult_est = _num(m18, ["ESTIMATE"]).ravel() + _num(f18, ["ESTIMATE"]).ravel()
    adult_reps = _num(m18, REP_COLS) + _num(f18, REP_COLS)
    adult_se = sdr_se(adult_est, adult_reps)
    adult_controlled = ((m18["CME"] == "*****") & (f18["CME"] == "*****")).to_numpy()
    adult_status = np.where(adult_controlled, "controlled",
                            np.where(adult_se > 0, "sdr", "moe_zero_not_controlled"))
    adult_se = np.where(adult_controlled, 0.0, adult_se)

    num, den = b17["2"], b17["1"]
    num_est = _num(num, ["ESTIMATE"]).ravel()
    den_est = _num(den, ["ESTIMATE"]).ravel()
    num_reps = _num(num, REP_COLS)
    den_reps = _num(den, REP_COLS)
    with np.errstate(divide="ignore", invalid="ignore"):
        pct = np.where(den_est > 0, 100.0 * num_est / den_est, np.nan)
        # Undefined replicate percents (zero denominator) are set to 0, per Census guidance.
        rep_pct = np.where(den_reps > 0, 100.0 * num_reps / den_reps, 0.0)
    pov_se = sdr_se(np.nan_to_num(pct), rep_pct)
    special = (den_est <= 0) | (pct <= 0) | (pct >= 100) | (pov_se <= 0)
    pov_status = np.where(den_est <= 0, "denominator_zero", np.where(special, "moe_special_case", "sdr"))
    pov_se = np.where(special, np.nan, pov_se)

    out = pd.DataFrame({
        "fips": fips.to_numpy(),
        "acs_name": b05["1"]["NAME"].to_numpy(),
        f"acs{vintage}_total_pop": _num(b05["1"], ["ESTIMATE"]).ravel(),
        f"acs{vintage}_adult": adult_est,
        f"acs{vintage}_adult_se": adult_se,
        f"acs{vintage}_adult_moe90": z90 * adult_se,
        f"acs{vintage}_adult_lo95": adult_est - z95 * adult_se,
        f"acs{vintage}_adult_hi95": adult_est + z95 * adult_se,
        f"acs{vintage}_adult_status": adult_status,
        f"acs{vintage}_pov_num": num_est,
        f"acs{vintage}_pov_den": den_est,
        f"acs{vintage}_pov_pct": pct,
        f"acs{vintage}_pov_se": pov_se,
        f"acs{vintage}_pov_moe90": z90 * pov_se,
        f"acs{vintage}_pov_lo95": pct - z95 * pov_se,
        f"acs{vintage}_pov_hi95": pct + z95 * pov_se,
        f"acs{vintage}_pov_status": pov_status,
    })
    checks = {
        "vintage": vintage,
        "n_counties_incl_pr": int(len(out)),
        "adult_status_counts": pd.Series(adult_status).value_counts().to_dict(),
        "poverty_status_counts": pd.Series(pov_status).value_counts().to_dict(),
        "published_moe_reproduction": {
            "B05003_line8": published_moe_check(m18),
            "B05003_line19": published_moe_check(f18),
            "B17001_line1": published_moe_check(den),
            "B17001_line2": published_moe_check(num),
        },
    }
    return out, checks
