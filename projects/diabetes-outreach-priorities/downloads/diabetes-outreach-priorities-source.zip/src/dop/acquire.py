"""Acquire raw sources with caching, bounded retries and content validation.

Every download is streamed to a temporary file, hashed while streaming, and
checked before it replaces anything in data/raw/:

* HTTP status must be 200 and the content type must match the expected kind.
* The first bytes must not be an HTML page (the Census Data API, for example,
  returns a "Missing Key" HTML page with status 200).
* CSV files must contain the configured header columns.
* ZIP archives must pass a CRC test, contain exactly the expected members, and
  contain no absolute or parent-relative member paths.

Cached files are reused when their SHA-256 matches the manifest entry, so the
remaining pipeline can be rerun offline from immutable local inputs. A fresh
download whose hash differs from an existing manifest entry stops with an error
unless --refresh is given, because the source has changed since the recorded
snapshot. Data files, metadata and manifest entries are written only after every
check has passed.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

import requests

from .config import Paths, load_config, project_root

USER_AGENT = "diabetes-outreach-priorities/1.0 (reproducible research pipeline)"
CHUNK = 1 << 20

CONTENT_TYPES = {
    "csv": ("text/csv", "application/csv", "text/plain", "application/octet-stream"),
    "zip": ("application/zip", "application/x-zip-compressed", "application/octet-stream"),
    "json": ("application/json",),
    "pdf": ("application/pdf",),
}


class AcquisitionError(RuntimeError):
    """Raised when a download fails validation. Nothing is written to data/raw."""


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(CHUNK), b""):
            h.update(block)
    return h.hexdigest()


def looks_like_html(head: bytes) -> bool:
    h = head.lstrip()[:512].lower()
    return h.startswith(b"<!doctype html") or h.startswith(b"<html") or b"<title>" in h[:300]


def check_content_type(expect: str, content_type: str | None) -> None:
    ct = (content_type or "").split(";")[0].strip().lower()
    if ct and ct not in CONTENT_TYPES[expect]:
        raise AcquisitionError(f"unexpected content type {ct!r} for expected {expect}")


def check_csv_header(head: bytes, required: list[str], encoding: str = "utf-8") -> None:
    text = head.decode(encoding, errors="replace")
    first = text.splitlines()[0] if text else ""
    first = first.lstrip("﻿")
    cols = next(csv.reader([first])) if first else []
    missing = [c for c in required if c not in cols]
    if missing:
        raise AcquisitionError(f"CSV header missing required columns: {missing}")


def validate_zip(path: Path, members: list[str], required_columns: list[str] | None) -> list[dict]:
    try:
        zf = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise AcquisitionError(f"not a valid zip archive: {exc}") from exc
    with zf:
        bad = zf.testzip()
        if bad is not None:
            raise AcquisitionError(f"zip CRC failure in member {bad}")
        names = zf.namelist()
        for name in names:
            p = PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts or name.startswith("\\"):
                raise AcquisitionError(f"unsafe zip member path {name!r}")
        if sorted(names) != sorted(members):
            raise AcquisitionError(f"zip members {names} differ from expected {members}")
        info = []
        for name in names:
            with zf.open(name) as fh:
                h = hashlib.sha256()
                head = fh.read(65536)
                h.update(head)
                for block in iter(lambda: fh.read(CHUNK), b""):
                    h.update(block)
            if looks_like_html(head):
                raise AcquisitionError(f"zip member {name} looks like HTML")
            if required_columns:
                check_csv_header(head, required_columns)
            zi = zf.getinfo(name)
            info.append({"member": name, "bytes": zi.file_size, "sha256": h.hexdigest()})
    return info


def http_download(url: str, dest: Path, *, params: dict | None, expect: str, min_bytes: int,
                  required_columns: list[str] | None = None, encoding: str = "utf-8",
                  retries: int = 3, timeout: int = 180, session: requests.Session | None = None) -> dict:
    """Stream url to a temporary file next to dest after validation.

    Returns response provenance with the temporary path under "_tmp". The caller
    moves it into place only after every remaining check has passed.
    """
    session = session or requests.Session()
    last_exc: Exception | None = None
    for attempt in range(1, retries + 1):
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            with session.get(url, params=params, stream=True, timeout=timeout,
                             headers={"User-Agent": USER_AGENT}) as resp:
                if resp.status_code != 200:
                    raise AcquisitionError(f"HTTP {resp.status_code} for {resp.url}")
                check_content_type(expect, resp.headers.get("Content-Type"))
                h = hashlib.sha256()
                n = 0
                head = b""
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(tmp, "wb") as out:
                    for block in resp.iter_content(CHUNK):
                        if not block:
                            continue
                        if len(head) < 65536:
                            head += block[: 65536 - len(head)]
                        h.update(block)
                        n += len(block)
                        out.write(block)
                if n < min_bytes:
                    raise AcquisitionError(f"download too small ({n} bytes < {min_bytes})")
                if expect in ("csv", "json") and looks_like_html(head):
                    raise AcquisitionError("response body is an HTML page, not data")
                if expect == "pdf" and not head.startswith(b"%PDF"):
                    raise AcquisitionError("response is not a PDF")
                if expect == "csv" and required_columns:
                    check_csv_header(head, required_columns, encoding)
                prov = {
                    "resolved_url": resp.url,
                    "http_status": resp.status_code,
                    "content_type": resp.headers.get("Content-Type"),
                    "etag": resp.headers.get("ETag"),
                    "last_modified": resp.headers.get("Last-Modified"),
                    "soda_truth_last_modified": resp.headers.get("X-SODA2-Truth-Last-Modified"),
                    "bytes": n,
                    "sha256": h.hexdigest(),
                    "attempts": attempt,
                }
            prov["_tmp"] = str(tmp)
            return prov
        except (requests.RequestException, AcquisitionError) as exc:
            last_exc = exc
            if tmp.exists():
                tmp.unlink()
            # Validation failures are deterministic. Only retry transport errors.
            if isinstance(exc, AcquisitionError) and "HTTP 5" not in str(exc):
                break
            time.sleep(min(30, 2 ** attempt))
    raise AcquisitionError(f"failed to acquire {url}: {last_exc}")


def load_manifest(paths: Paths) -> dict:
    if paths.manifest.exists():
        return json.loads(paths.manifest.read_text())
    return {"schema": "dop-source-manifest/1", "sources": {}}


def write_manifest(paths: Paths, manifest: dict) -> None:
    paths.manifest.write_text(json.dumps(manifest, indent=2, sort_keys=False) + "\n")


def fetch_metadata(url: str, session: requests.Session, retries: int = 3) -> tuple[bytes, dict]:
    """Fetch Socrata dataset metadata and return raw bytes and a summary. Nothing is written here."""
    last_exc: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            resp = session.get(url, timeout=120, headers={"User-Agent": USER_AGENT})
            if resp.status_code != 200 or looks_like_html(resp.content[:512]):
                raise AcquisitionError(f"metadata request failed for {url} (HTTP {resp.status_code})")
            meta = json.loads(resp.content)
            return resp.content, {
                "metadata_url": url,
                "metadata_sha256": hashlib.sha256(resp.content).hexdigest(),
                "name": meta.get("name"),
                "rows_updated_at_utc": datetime.fromtimestamp(meta["rowsUpdatedAt"], timezone.utc).isoformat()
                if meta.get("rowsUpdatedAt") else None,
                "license": (meta.get("license") or {}).get("name"),
                "attribution": meta.get("attribution"),
            }
        except (requests.RequestException, ValueError, AcquisitionError) as exc:
            last_exc = exc
            time.sleep(min(30, 2 ** attempt))
    raise AcquisitionError(f"failed to fetch metadata {url}: {last_exc}")


def acquire(refresh: bool = False, only: list[str] | None = None) -> dict:
    cfg = load_config()
    paths = Paths(project_root())
    paths.ensure()
    manifest = load_manifest(paths)
    session = requests.Session()
    for sid, src in cfg["sources"].items():
        if only and sid not in only:
            continue
        dest_dir = paths.raw / sid
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src["filename"]
        prior = manifest["sources"].get(sid)
        if dest.exists() and prior and not refresh:
            digest = sha256_file(dest)
            if digest == prior.get("sha256"):
                print(f"[acquire] {sid}: cached ({digest[:12]})")
                continue
            raise AcquisitionError(
                f"{sid}: cached file hash {digest[:12]} differs from manifest {prior.get('sha256', '')[:12]}. "
                "Rerun with --refresh to replace it deliberately")
        print(f"[acquire] {sid}: downloading {src['url']}")
        accessed = datetime.now(timezone.utc).isoformat(timespec="seconds")
        prov = http_download(src["url"], dest, params=src.get("params"), expect=src["expect"],
                             min_bytes=src.get("min_bytes", 1), required_columns=src.get("required_columns"),
                             encoding=src.get("encoding", "utf-8"), session=session)
        tmp = Path(prov.pop("_tmp"))
        entry = {
            "title": src["title"],
            "publisher": src["publisher"],
            "url": src["url"],
            "params": src.get("params"),
            "accessed_utc": accessed,
            "release": src.get("release"),
            "license_or_terms": src.get("license"),
            "local_path": str(dest.relative_to(paths.root)),
        }
        try:
            if src["expect"] == "zip":
                entry["archive_members"] = validate_zip(tmp, src["zip_members"], src.get("required_columns"))
            meta_bytes = None
            if src.get("metadata_url"):
                meta_bytes, entry["socrata_metadata"] = fetch_metadata(src["metadata_url"], session)
                entry["socrata_metadata"]["metadata_file"] = str((dest_dir / "metadata.json").relative_to(paths.root))
            if prior and prior.get("sha256") and prior["sha256"] != prov["sha256"] and not refresh:
                raise AcquisitionError(
                    f"{sid}: downloaded content (sha256 {prov['sha256'][:12]}) differs from the manifest "
                    f"({prior['sha256'][:12]}). The source has changed since the recorded snapshot. "
                    "Rerun with --refresh to accept the new snapshot deliberately.")
        except AcquisitionError:
            tmp.unlink(missing_ok=True)
            raise
        # Every check passed: commit the data file, its metadata and the manifest entry together.
        tmp.replace(dest)
        if meta_bytes is not None:
            (dest_dir / "metadata.json").write_bytes(meta_bytes)
        entry.update(prov)
        if prior and prior.get("sha256") and prior["sha256"] != entry["sha256"]:
            entry["previous_sha256"] = prior["sha256"]
            print(f"[acquire] {sid}: content changed since previous acquisition (accepted with --refresh)")
        manifest["sources"][sid] = entry
        write_manifest(paths, manifest)
        print(f"[acquire] {sid}: {entry['bytes']:,} bytes sha256={entry['sha256'][:12]}")
    manifest["note"] = (
        "Socrata exports are served from mutable endpoints. The SHA-256 values identify the exact snapshot "
        "used. Rebuilding an identical historical snapshot is only possible from these preserved files. "
        "Census replicate tables and population estimates are static release files.")
    write_manifest(paths, manifest)
    return manifest
