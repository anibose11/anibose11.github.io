"""Fast demo on the bundled SYNTHETIC fixture.

Runs the same rule, envelope and overlap code as the study on 40 made-up
counties in three made-up states. It shows that the software runs. It is not
evidence about any real county and its numbers must never be reported as results.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .analyze import RULES, envelope_summary, national, rule_overlap, within_state
from .config import project_root


def demo(out: str | None = None) -> Path:
    root = project_root()
    fixture = root / "tests" / "fixtures" / "demo_frame_SYNTHETIC.csv"
    out_dir = Path(out) if out else root / "outputs" / "demo"
    out_dir.mkdir(parents=True, exist_ok=True)
    f = pd.read_csv(fixture, dtype={"fips": str, "state_fips": str})
    thr = 20.0
    f["burden"] = f["prev"] / 100 * f["pop18_places"]
    lo_pop = np.minimum(f["pop18_places"], f["acs2024_adult_lo95"].clip(lower=0))
    hi_pop = np.maximum(f["pop18_places"], f["acs2024_adult_hi95"])
    f["burden_lo"] = f["prev_lcl"] / 100 * lo_pop
    f["burden_hi"] = f["prev_ucl"] / 100 * hi_pop
    f["elig_point"] = f["acs2024_pov_pct"] >= thr
    f["elig_certain"] = f["acs2024_pov_lo95"] >= thr
    f["elig_possible"] = f["acs2024_pov_hi95"] >= thr
    caps = [5, 10]
    res = national(f, caps)
    env = envelope_summary(res, caps, "SYNTHETIC")
    ovl = rule_overlap(res, caps, "SYNTHETIC")
    _, states = within_state(f, 3)
    for name, df in (("demo_priority_long_SYNTHETIC.csv", res), ("demo_envelope_summary_SYNTHETIC.csv", env),
                     ("demo_rule_overlap_SYNTHETIC.csv", ovl), ("demo_within_state_SYNTHETIC.csv", states)):
        df.to_csv(out_dir / name, index=False)
    print("SYNTHETIC DEMO (not study data)")
    print(env[["rule", "capacity", "n_selected_point", "n_core", "n_boundary"]].to_string(index=False))
    pt = ovl[(ovl.scenario == "point") & (ovl.set_a != "ALL_THREE")]
    print(pt[["capacity", "set_a", "set_b", "n_intersection", "jaccard"]].to_string(index=False))
    print(f"outputs in {out_dir}")
    return out_dir
