"""Ranking, deterministic sensitivity envelopes and set overlap.

All rankings are descending competition ranks: rank_i = 1 + #{j : v_j > v_i}.
Ties share the better rank, so every county tied at a capacity cutoff is
selected and a selected set can be larger than the capacity.

Envelope ranks use only each county's published lower and upper bounds:
  best_i  = 1 + #{j in C_best : L_j > U_i}
  worst_i = 1 + #{j in C_worst, j != i : U_j > L_i}
C_best and C_worst are the competitor sets (the whole ranking set for PREV and
BURDEN, and the certainly and possibly eligible counties for EQUITY). The worst case
puts every competitor at its upper bound and county i at its lower bound at
once, which is a sensitivity bound, not a jointly attainable confidence set.
"""

from __future__ import annotations

import numpy as np

CORE, BOUNDARY, OUTSIDE = "core", "boundary", "outside"


def competition_rank(values) -> np.ndarray:
    v = np.asarray(values, dtype=float)
    if np.isnan(v).any():
        raise ValueError("competition_rank received missing values")
    s = np.sort(v)
    return 1 + (len(v) - np.searchsorted(s, v, side="right"))


def count_greater(sorted_ref: np.ndarray, x: np.ndarray) -> np.ndarray:
    """For each x, the number of entries in sorted_ref strictly greater than x."""
    return len(sorted_ref) - np.searchsorted(sorted_ref, x, side="right")


def envelope_ranks(lo, hi, best_mask=None, worst_mask=None):
    """Best- and worst-case ranks for every county.

    lo, hi: bounds for all counties in the evaluation set.
    best_mask: competitors counted for best-case ranks (default all).
    worst_mask: competitors counted for worst-case ranks (default all).
    """
    lo = np.asarray(lo, dtype=float)
    hi = np.asarray(hi, dtype=float)
    if np.isnan(lo).any() or np.isnan(hi).any():
        raise ValueError("envelope bounds contain missing values")
    if (lo > hi).any():
        raise ValueError("lower bound exceeds upper bound")
    n = len(lo)
    best_mask = np.ones(n, bool) if best_mask is None else np.asarray(best_mask, bool)
    worst_mask = np.ones(n, bool) if worst_mask is None else np.asarray(worst_mask, bool)
    best = 1 + count_greater(np.sort(lo[best_mask]), hi)
    worst = 1 + count_greater(np.sort(hi[worst_mask]), lo)
    # Remove county i from its own worst-case count when it is a competitor and U_i > L_i.
    worst = worst - (worst_mask & (hi > lo)).astype(int)
    return best, worst


def classify(best, worst, k: int, can_be_core=None, can_be_selected=None) -> np.ndarray:
    best = np.asarray(best)
    worst = np.asarray(worst)
    n = len(best)
    can_be_core = np.ones(n, bool) if can_be_core is None else np.asarray(can_be_core, bool)
    can_be_selected = np.ones(n, bool) if can_be_selected is None else np.asarray(can_be_selected, bool)
    status = np.full(n, OUTSIDE, dtype=object)
    possible = can_be_selected & (best <= k)
    status[possible] = BOUNDARY
    status[possible & can_be_core & (worst <= k)] = CORE
    return status


def jaccard(a, b) -> float:
    a, b = set(a), set(b)
    union = a | b
    if not union:
        return float("nan")
    return len(a & b) / len(union)


def overlap_row(name_a: str, set_a, name_b: str, set_b) -> dict:
    a, b = set(set_a), set(set_b)
    return {
        "set_a": name_a, "set_b": name_b,
        "n_a": len(a), "n_b": len(b),
        "n_intersection": len(a & b), "n_union": len(a | b),
        "jaccard": jaccard(a, b),
    }
