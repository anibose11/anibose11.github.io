"""Analysis workbook (aggregate county data only) and the data dictionary."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import datetime

from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

FIXED_DOC_TIME = datetime.datetime(2026, 10, 7, 0, 0, 0)

SOURCE_NOTE = ("CDC PLACES County Data, 2025 release (data.cdc.gov swc5-untb, BRFSS 2023), Census Bureau Vintage 2023 "
               "county estimates (adults 18+) and ACS 2020-2024 5-year variance replicate tables B05003 and B17001. "
               "Kentucky and Pennsylvania have no diagnosed-diabetes estimates in the 2025 release.")

DICTIONARY = [
    ("fips", "County FIPS code, 5 characters with leading zeros", "text", "PLACES LocationID"),
    ("state_abbr", "State postal abbreviation", "text", "PLACES StateAbbr"),
    ("county_name", "County or county-equivalent name as published by PLACES (does not distinguish independent cities from same-named counties)", "text", "PLACES LocationName"),
    ("display_name", "Census Bureau name including the type of area, for example Baltimore city, Baltimore County or Tensas Parish", "text", "CC-EST2023-AGESEX CTYNAME"),
    ("prev", "Crude prevalence of diagnosed diabetes among adults aged 18 and older", "percent", "PLACES Data_Value, DataValueTypeID CrdPrv"),
    ("prev_lcl", "Lower 95% limit of crude prevalence", "percent", "PLACES Low_Confidence_Limit"),
    ("prev_ucl", "Upper 95% limit of crude prevalence", "percent", "PLACES High_Confidence_Limit"),
    ("prev_ageadj", "Age-adjusted prevalence, for display only and never multiplied by a population", "percent", "PLACES Data_Value, DataValueTypeID AgeAdjPrv"),
    ("pop18_places", "Adults aged 18 and older, Census 2023 county estimate as distributed by PLACES (equals CC-EST2023-AGESEX AGE18PLUS_TOT, YEAR 5)", "persons", "PLACES TotalPop18plus"),
    ("acs2024_adult", "Adults aged 18 and older, ACS 2020-2024 (B05003 line 8 + line 19)", "persons", "ACS variance replicate table B05003"),
    ("acs2024_adult_lo95", "ACS adult estimate minus 1.96 replicate standard errors", "persons", "derived"),
    ("acs2024_adult_hi95", "ACS adult estimate plus 1.96 replicate standard errors", "persons", "derived"),
    ("burden", "Estimated adults with diagnosed diabetes = prev / 100 x pop18_places (model-based estimate, not a patient count)", "persons", "derived"),
    ("burden_lo", "Scenario lower bound: prev_lcl / 100 x min(pop18_places, acs2024_adult_lo95), not a confidence limit", "persons", "derived"),
    ("burden_hi", "Scenario upper bound: prev_ucl / 100 x max(pop18_places, acs2024_adult_hi95), not a confidence limit", "persons", "derived"),
    ("pov", "Percent of people below the poverty level, ACS 2020-2024 (B17001 line 2 / line 1 x 100)", "percent", "ACS variance replicate table B17001"),
    ("acs2024_pov_lo95", "Poverty percent minus 1.96 replicate standard errors", "percent", "derived"),
    ("acs2024_pov_hi95", "Poverty percent plus 1.96 replicate standard errors", "percent", "derived"),
    ("elig_point", "Poverty estimate at or above 20.0%", "true/false", "derived"),
    ("elig_certain", "95% lower poverty bound at or above 20.0%", "true/false", "derived"),
    ("elig_possible", "95% upper poverty bound at or above 20.0%", "true/false", "derived"),
    ("in_aligned_subset", "In the strictly aligned subset (all sources present, Connecticut excluded)", "true/false", "derived"),
    ("<RULE>_K<k>_rank", "Point-estimate competition rank under the rule. For EQUITY, blank when the poverty point estimate is below 20% (elig_point false). Such a county can still be boundary if its 95% upper poverty bound is at least 20% (elig_possible).", "rank", "derived"),
    ("<RULE>_K<k>_best", "Best-case rank within the rule's bounds", "rank", "derived"),
    ("<RULE>_K<k>_worst", "Worst-case rank within the rule's bounds", "rank", "derived"),
    ("<RULE>_K<k>_status", "core means selected wherever every county's value is within its bounds, boundary means selected for some values within the bounds, and outside means never selected within the bounds", "category", "derived"),
    ("<RULE>_K<k>_selected", "Selected at capacity k using point estimates (ties at the cutoff included)", "true/false", "derived"),
    ("RULE PREV", "Rank by crude prevalence", "", "analysis plan"),
    ("RULE BURDEN", "Rank by estimated adults with diagnosed diabetes", "", "analysis plan"),
    ("RULE EQUITY", "Rank by crude prevalence among counties with poverty at or above 20.0% (labeled high-poverty prevalence)", "", "analysis plan"),
]


def data_dictionary(path: Path) -> pd.DataFrame:
    df = pd.DataFrame(DICTIONARY, columns=["column", "definition", "unit", "source"])
    df.to_csv(path, index=False)
    return df


def _sheet(writer, name, df, widths=None, note=None):
    start = 2 if note else 0
    df.to_excel(writer, sheet_name=name, index=False, startrow=start)
    ws = writer.sheets[name]
    if note:
        ws.cell(row=1, column=1, value=note).font = Font(italic=True)
    hdr = start + 1
    for c in range(1, df.shape[1] + 1):
        cell = ws.cell(row=hdr, column=c)
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="F2F1EC")
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        col = df.columns[c - 1]
        w = (widths or {}).get(col, min(max(12, len(str(col)) + 2), 40))
        ws.column_dimensions[get_column_letter(c)].width = w
    ws.freeze_panes = ws.cell(row=hdr + 1, column=1)


def build_workbook(root: Path, out: Path, run_id: str) -> Path:
    t = root / "outputs" / "tables"
    p = root / "data" / "processed"
    dd = data_dictionary(root / "docs" / "data_dictionary.csv")
    ctab = pd.read_csv(t / "county_priority_table.csv", dtype={"fips": str})
    manifest = json.loads((root / "source_manifest.json").read_text())
    readme = pd.DataFrame({"Item": [
        "Title", "What this is", "Unit", "Sources", "Run identifier", "How to use", "Caution", "Not included"],
        "Value": [
            "County diabetes outreach priorities under alternative need definitions and published uncertainty",
            "Aggregate county tables from the analysis. No person-level data are included.",
            "One row per county in the County table. Other sheets are summaries.",
            SOURCE_NOTE,
            run_id,
            "Filter the County table by state or status. Ranks and statuses were computed on the full national frame. Do not re-rank a filtered subset.",
            "Core and boundary labels describe the bounds used for each rule (PLACES 95% limits, and scenario bounds for estimated burden). For high-poverty prevalence, eligibility also spans the ACS 95% poverty bounds. A county whose upper bound reaches 20% can be boundary, and only a county whose lower bound reaches 20% can be core. These labels are not probabilities. Estimated burden is a model-based estimate, not a count of patients.",
            "Kentucky (120 counties) and Pennsylvania (67 counties): no 2025 PLACES diabetes estimates. Loving County, Texas: suppressed by PLACES.",
        ]})
    out.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(out, engine="openpyxl") as w:
        _sheet(w, "README", readme, {"Item": 18, "Value": 120})
        _sheet(w, "Definitions", dd, {"column": 22, "definition": 90, "unit": 12, "source": 40})
        _sheet(w, "County table", ctab, note=SOURCE_NOTE)
        _sheet(w, "Summary", pd.read_csv(t / "envelope_summary.csv").merge(
            pd.read_csv(t / "selection_profile.csv"), on=["rule", "capacity"]), note=SOURCE_NOTE)
        _sheet(w, "Rule overlap", pd.read_csv(t / "rule_overlap.csv"), note="Jaccard = intersection / union of selected sets.")
        _sheet(w, "Scenario overlap", pd.read_csv(t / "scenario_overlap.csv"))
        _sheet(w, "Within state", pd.read_csv(t / "within_state_summary.csv"), note="Capacity 5 within each state.")
        _sheet(w, "Aligned subset", pd.read_csv(t / "robustness_aligned.csv"))
        _sheet(w, "Prior release", pd.read_csv(t / "prior_release_comparison.csv"),
               note="Descriptive comparison with PLACES 2024 release (BRFSS 2022). Not a validation.")
        _sheet(w, "Exclusions", pd.read_csv(p / "exclusions.csv", dtype={"fips": str}))
        src = pd.DataFrame([{"source_id": k, "title": v["title"], "url": v["url"], "accessed_utc": v["accessed_utc"],
                             "release": v.get("release"), "sha256": v["sha256"], "bytes": v["bytes"]}
                            for k, v in manifest["sources"].items()])
        _sheet(w, "Sources", src, {"title": 60, "url": 60, "sha256": 66})
        # Fixed document dates keep the workbook byte-identical across reruns of the same results.
        w.book.properties.created = FIXED_DOC_TIME
        w.book.properties.modified = FIXED_DOC_TIME
        w.book.properties.creator = "Animesh Bose"
    from .report import normalize_container
    normalize_container(out)
    return out
