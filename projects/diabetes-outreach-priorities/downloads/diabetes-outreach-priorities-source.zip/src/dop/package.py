"""Package stage: allowlisted public source archive.

When the author's local record-keeping tools are present, this stage also writes
the portfolio handoff files and the project bundle. Run from a copy of the archive,
it packages the source archive only.
"""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path

from .config import load_config, project_root
from .site import SLUG

FIXED_TIME = (2026, 10, 7, 0, 0, 0)

SOURCE_ALLOW = [
    "README.md", "LICENSE", "CITATION.cff", "pyproject.toml", "requirements.lock", "source_manifest.json",
    "config/*.toml", "src/dop/*.py", "sql/*.sql", "R/*.R", "scripts/*.py", "scripts/*.sh", "templates/*.md",
    "tests/*.py", "tests/fixtures/*.csv",
    "docs/analysis_plan.md", "docs/contribution_decision.md", "docs/literature_search_log.md",
    "docs/planning_brief.md", "docs/planning_brief_template.md", "docs/tableau_spec.md", "docs/*.csv", "docs/*.json",
    "data/interim/acs*_county.csv",
    "data/raw/*/metadata.json",
    "data/processed/*.csv", "data/processed/*.json",
    "outputs/tables/*.csv", "outputs/tables/*.json", "outputs/figures/*.png", "outputs/figures/*.svg",
    "outputs/validation/*.json", "outputs/render_summary.json",
    "outputs/workbook/*.xlsx", "outputs/dashboard/*.html",
    "manuscript/manuscript_template.md",
    "evidence/*.json",
]
TEXT_SUFFIXES = {".md", ".py", ".R", ".sql", ".toml", ".json", ".csv", ".cff", ".txt", ".html", ".lock", ".sh", ""}
FORBIDDEN = [
    (re.compile(r"/Users/[A-Za-z0-9_.-]+"), "absolute macOS user path"),
    (re.compile("/" + "private/tmp|/" + "var/folders"), "temporary directory path"),
    (re.compile(r"(?i)api[_-]?key\s*[=:]\s*['\"][A-Za-z0-9]{16,}"), "API key"),
    (re.compile(r"(?i)-----BEGIN [A-Z ]*PRIVATE KEY-----"), "private key"),
    (re.compile(r"[A-Za-z0-9._%+-]+@gmail\.com"), "personal email address"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def source_files(root: Path) -> list[Path]:
    files = set()
    for pat in SOURCE_ALLOW:
        for p in root.glob(pat):
            if p.is_file() and "__pycache__" not in p.parts and p.name != ".DS_Store":
                files.add(p)
    return sorted(files)


def scan(files: list[Path], root: Path, extra_phrases: list[str] | None = None) -> list[str]:
    problems = []
    phrases = [re.compile(re.escape(x), re.I) for x in (extra_phrases or [])]
    for p in files:
        if p.suffix not in TEXT_SUFFIXES:
            continue
        text = p.read_text(errors="replace")
        for rx, what in FORBIDDEN:
            m = rx.search(text)
            if m:
                problems.append(f"{p.relative_to(root)}: {what} ({m.group(0)[:40]})")
        for rx in phrases:
            if rx.search(text):
                problems.append(f"{p.relative_to(root)}: blocked phrase ({rx.pattern[:30]})")
    return problems


def write_zip(out: Path, members: list[tuple[str, Path]]):
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".zip.part")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc, src in members:
            info = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, src.read_bytes())
    with zipfile.ZipFile(tmp) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f"zip integrity failure: {bad}")
    tmp.replace(out)


def public_files(site: Path, base: Path) -> list[dict]:
    return [{"path": str(p.relative_to(base)), "bytes": p.stat().st_size, "sha256": sha256(p)}
            for p in sorted(site.rglob("*")) if p.is_file() and p.name != ".DS_Store"]


def presentation_hash(root: Path) -> str:
    from .analyze import RESULT_MODULES
    h = hashlib.sha256()
    files = sorted(p for p in (root / "src" / "dop").glob("*.py") if p.name not in RESULT_MODULES)
    files += sorted((root / "templates").glob("*.md"))
    files += [root / "manuscript" / "manuscript_template.md", root / "docs" / "planning_brief_template.md"]
    for p in files:
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def load_private(root: Path):
    f = root / "private_tools" / "handoff_private.py"
    if not f.exists():
        return None
    import importlib.util
    spec = importlib.util.spec_from_file_location("handoff_private", f)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def package() -> dict:
    root = project_root()
    cfg = load_config()
    site = root / "site" / "projects" / SLUG
    if not (site / "index.html").exists():
        raise RuntimeError("site page missing. Run `dop render` first")
    summary = json.loads((root / "outputs" / "render_summary.json").read_text())
    if summary.get("presentation_sha256") != presentation_hash(root):
        raise RuntimeError("reporting code or templates changed after the last render. Rerun `dop render` first")
    files = source_files(root)
    site_files = [p for p in site.rglob("*") if p.is_file() and p.suffix in (".html", ".csv", ".md", ".txt")]
    private = load_private(root)
    phrases = private.blocked_phrases(root) if private is not None else []
    problems = scan(files, root, phrases) + scan(site_files, root, phrases)
    if problems:
        raise RuntimeError("public file scan failed:\n" + "\n".join(problems))
    run_now = json.loads((root / "outputs" / "tables" / "run_record.json").read_text())["run_id"]
    for f, needle in ((root / "manuscript" / "manuscript.md", run_now), (root / "evidence" / "claims.json", run_now),
                      (root / "outputs" / "validation" / "validation_report.json", run_now),
                      (site / "index.html", run_now)):
        if needle not in f.read_text():
            raise RuntimeError(f"{f.relative_to(root)} does not refer to run {run_now}. Rerun `dop render` first")
    src_zip = site / "downloads" / f"{SLUG}-source.zip"
    write_zip(src_zip, [(str(p.relative_to(root)), p) for p in files])
    with zipfile.ZipFile(src_zip) as zf:
        archived = json.loads(zf.read("outputs/tables/run_record.json"))["run_id"]
    if archived != run_now:
        raise RuntimeError(f"source archive holds run {archived}, expected {run_now}")
    src_sha = sha256(src_zip)
    print(f"[package] source archive {src_zip.stat().st_size:,} bytes, {len(files)} files, run {run_now}, sha256 {src_sha[:16]}")
    info = {"source_archive": str(src_zip.relative_to(root)), "source_archive_sha256": src_sha, "run_id": run_now}
    if private is None:
        print("[package] source archive only")
        return info
    info.update(private.finish_package(root, site, src_zip, cfg, write_zip=write_zip, scan=scan, sha256=sha256,
                                       public_files=public_files))
    return info
