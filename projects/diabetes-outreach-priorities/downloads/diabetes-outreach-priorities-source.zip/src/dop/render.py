"""Render stage: figures, documents, workbook, dashboard, site page and evidence files."""

from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

from .analyze import run_id
from .config import Paths, load_config, project_root
from .dashboard import build_dashboard
from .facts import build_facts
from .figures import make_figures
from .handoff import runtime_manifest, verify_claims, write_claims
from .package import load_private, presentation_hash
from .validate import validation_code_hash
from .report import render_documents
from .site import build_site
from .workbook import build_workbook


def count_tests(root: Path) -> int:
    proc = subprocess.run([sys.executable, "-m", "pytest", "--collect-only", "-q", str(root / "tests")],
                          capture_output=True, text=True, cwd=root)
    m = re.search(r"(\d+) tests? collected", proc.stdout)
    if not m:
        raise RuntimeError(f"could not count tests: {proc.stdout[-500:]} {proc.stderr[-500:]}")
    return int(m.group(1))


# Qualitative statements in the manuscript and pages that must hold for the facts they describe.
CLAIM_GUARDS = [
    ("k10_prev_burden_inter", lambda v: v == 0, "prevalence and burden share no county at any capacity"),
    ("k25_prev_burden_inter", lambda v: v == 0, "prevalence and burden share no county at any capacity"),
    ("k50_prev_burden_inter", lambda v: v == 0, "prevalence and burden share no county at any capacity"),
    ("k10_all_three", lambda v: v == 0, "no county selected by all three rules"),
    ("k25_all_three", lambda v: v == 0, "no county selected by all three rules"),
    ("k50_all_three", lambda v: v == 0, "no county selected by all three rules"),
    ("k10_core_all_three", lambda v: v == 0, "no county core under all three rules"),
    ("k25_core_all_three", lambda v: v == 0, "no county core under all three rules"),
    ("k50_core_all_three", lambda v: v == 0, "no county core under all three rules"),
    ("k10_prev_core", lambda v: v == 0, "no prevalence core at capacity 10"),
    ("k25_prev_core", lambda v: v == 0, "no prevalence core at capacity 25"),
    ("k50_prev_core", lambda v: v == 1, "one prevalence core county at capacity 50"),
    ("k25_prev_selected", lambda v: v == 26, "prevalence selection one more than the capacity"),
    ("aligned_selected_ct", lambda v: v == 0, "no Connecticut county in a national selection"),
    ("aligned_min_j", lambda v: v == 1.0, "aligned selections identical"),
    ("aligned_burden_core_changes", lambda v: v == 0, "aligned subset leaves the burden core unchanged"),
]
EQUAL_GUARDS = [
    ("k25_burden_core_prev_outside", "k25_burden_core", "all burden-core counties are outside the prevalence envelope"),
]


def check_claim_guards(F) -> None:
    bad = [f"{name}={F.items[name]['value']} ({why})" for name, ok, why in CLAIM_GUARDS if not ok(F.items[name]["value"])]
    for a_, b_, why in EQUAL_GUARDS:
        if F.items[a_]["value"] != F.items[b_]["value"]:
            bad.append(f"{a_} != {b_} ({why})")
    rem = F.items["moe_povden_remaining"]["value"]
    if F.items["moe_povden_mismatch_reps_equal"]["value"] != rem:
        bad.append("not all remaining poverty-universe cells have replicate estimates equal to the estimate")
    ratio = F.items["k25_burden_burden_sum"]["value"] / F.items["k25_prev_burden_sum"]["value"]
    if ratio <= 100:
        bad.append(f"burden/prevalence selection ratio {ratio:.1f} (text says more than a hundredfold)")
    if bad:
        raise RuntimeError("wording no longer matches the results. Revise the templates: " + ", ".join(bad))


def render() -> dict:
    cfg = load_config()
    paths = Paths(project_root())
    root = paths.root
    a = cfg["analysis"]
    run = json.loads((paths.tables / "run_record.json").read_text())
    current = run_id(cfg, root)
    if current != run["run_id"]:
        raise RuntimeError(f"outputs are from run {run['run_id']} but the current configuration, analysis code "
                           f"and sources give {current}. Rerun `dop analyze` and `dop validate` first")
    val = root / "outputs" / "validation" / "validation_report.json"
    if not val.exists() or json.loads(val.read_text())["run_id"] != run["run_id"]:
        raise RuntimeError("validation report missing or from another run. Run `dop validate` first")
    vrep = json.loads(val.read_text())
    if not vrep["all_passed"]:
        raise RuntimeError("validation did not pass. Documents are not rendered from a failed run")
    if vrep.get("validation_code_sha256") != validation_code_hash(root):
        raise RuntimeError("validation code changed after the last `dop validate`. Rerun it first")

    figs = make_figures(paths.tables, paths.figures, a["primary_capacity"])
    F = build_facts(root)
    n_tests = count_tests(root)
    F.add("n_tests", n_tests, str(n_tests), "tests/", "pytest --collect-only", "")
    from .references import REFERENCES
    F.add("n_references", len(REFERENCES), str(len(REFERENCES)), "src/dop/references.py", "len(REFERENCES)", "")
    check_claim_guards(F)
    disp = F.display()
    docs = render_documents(root, disp)
    wb = build_workbook(root, root / "outputs" / "workbook" / "diabetes-outreach-priorities-workbook.xlsx", run["run_id"])
    dash = build_dashboard(root, root / "outputs" / "dashboard" / "dashboard.html", run["run_id"])
    site = build_site(root, disp, dash, wb)
    claims = write_claims(root, F, run["run_id"], cfg["_sha256"])
    claim_check = verify_claims(root)
    if claim_check["failed"]:
        raise RuntimeError(f"claims failed re-check: {claim_check['failed']}")
    (root / "docs" / "runtime_manifest.json").write_text(json.dumps(runtime_manifest(root), indent=2) + "\n")
    private = load_private(root)  # optional local tooling for the author's own records, absent from the archive
    if private is not None:
        private.author_worksheet(root, a["validation_sample_seed"], a["validation_sample_size"])
        private.render_submission(root, disp, docs)
    figs = {k: [str(Path(x).resolve().relative_to(root)) for x in v] for k, v in figs.items()}
    summary = {"run_id": run["run_id"], "figures": figs, "citations": docs["citations"], "word_counts": docs["word_counts"],
               "claims": str(claims.relative_to(root)), "claim_recheck": claim_check, "n_facts": len(F.items),
               "site": str(site.relative_to(root)), "presentation_sha256": presentation_hash(root)}
    (root / "outputs" / "render_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"[render] run_id={run['run_id']} facts={len(F.items)} words={docs['word_counts']} citations={docs['citations']}")
    return summary
