-- Join sources into one row per PLACES location and assign frame status.
-- Joins are on 5-digit string FIPS. Cardinality is verified by dop.build before
-- and after these statements.

CREATE OR REPLACE TABLE crude AS
SELECT fips, value AS prev, lcl AS prev_lcl, ucl AS prev_ucl, footnote_symbol, footnote,
       total_pop_places, pop18_places, year AS brfss_year
FROM places_dia WHERE value_type_id = '{crude_id}';

CREATE OR REPLACE TABLE ageadj AS
SELECT fips, value AS prev_ageadj, lcl AS prev_ageadj_lcl, ucl AS prev_ageadj_ucl
FROM places_dia WHERE value_type_id = '{ageadj_id}';

-- States in which no location has a DIABETES row at all.
CREATE OR REPLACE TABLE states_without_measure AS
SELECT state_abbr FROM places_locations
GROUP BY state_abbr
HAVING sum(CASE WHEN fips IN (SELECT fips FROM crude) THEN 1 ELSE 0 END) = 0;

CREATE OR REPLACE TABLE county_all AS
SELECT
    l.fips,
    substr(l.fips, 1, 2) AS state_fips,
    l.state_abbr,
    l.state_name,
    l.county_name,
    c.brfss_year,
    c.prev, c.prev_lcl, c.prev_ucl,
    a.prev_ageadj, a.prev_ageadj_lcl, a.prev_ageadj_ucl,
    c.footnote_symbol, c.footnote,
    c.total_pop_places,
    c.pop18_places,
    p.pop18_pep,
    p.pep_total_pop,
    p.pep_county_name,
    a24.acs_name AS acs24_name,
    a24.acs2024_adult, a24.acs2024_adult_se, a24.acs2024_adult_lo95, a24.acs2024_adult_hi95, a24.acs2024_adult_status,
    a24.acs2024_pov_num, a24.acs2024_pov_den,
    a24.acs2024_pov_pct, a24.acs2024_pov_se, a24.acs2024_pov_lo95, a24.acs2024_pov_hi95, a24.acs2024_pov_status,
    a23.acs_name AS acs23_name,
    a23.acs2023_adult, a23.acs2023_adult_se, a23.acs2023_adult_lo95, a23.acs2023_adult_hi95, a23.acs2023_adult_status,
    a23.acs2023_pov_num, a23.acs2023_pov_den,
    a23.acs2023_pov_pct, a23.acs2023_pov_se, a23.acs2023_pov_lo95, a23.acs2023_pov_hi95, a23.acs2023_pov_status,
    CASE
        WHEN NOT regexp_full_match(l.fips, '[0-9]{{5}}') THEN 'national_aggregate'
        WHEN substr(l.fips, 1, 2) IN ({territories}) THEN 'territory'
        WHEN c.fips IS NULL AND l.state_abbr IN (SELECT state_abbr FROM states_without_measure) THEN 'measure_not_released_for_state'
        WHEN c.fips IS NULL THEN 'not_in_source'
        WHEN c.prev IS NULL AND c.footnote_symbol = '*' THEN 'suppressed'
        WHEN c.pop18_places IS NULL OR c.pop18_places <= 0 THEN 'missing_adult_population'
        WHEN a24.fips IS NULL THEN 'not_in_acs'
        WHEN a24.acs2024_pov_pct IS NULL THEN 'acs_poverty_unavailable'
        ELSE 'in_frame'
    END AS frame_status
FROM places_locations l
LEFT JOIN crude  c   USING (fips)
LEFT JOIN ageadj a   USING (fips)
LEFT JOIN pep23  p   USING (fips)
LEFT JOIN acs24  a24 USING (fips)
LEFT JOIN acs23  a23 USING (fips);

-- Locations present in a Census source but absent from PLACES (geography reconciliation).
CREATE OR REPLACE TABLE census_not_in_places AS
SELECT 'pep_v2023' AS source, fips, pep_county_name AS name FROM pep23 WHERE fips NOT IN (SELECT fips FROM places_locations)
UNION ALL
SELECT 'acs_2020_2024', fips, acs_name FROM acs24 WHERE fips NOT IN (SELECT fips FROM places_locations)
UNION ALL
SELECT 'acs_2019_2023', fips, acs_name FROM acs23 WHERE fips NOT IN (SELECT fips FROM places_locations);

CREATE OR REPLACE TABLE places24_crude AS
SELECT d.fips, d.state_abbr, d.county_name, d.value AS prev, d.lcl AS prev_lcl, d.ucl AS prev_ucl,
       d.footnote_symbol, d.pop18_places
FROM places24_dia d WHERE d.value_type_id = '{crude_id}';
