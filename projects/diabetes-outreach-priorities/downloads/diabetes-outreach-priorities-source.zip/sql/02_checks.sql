-- Build checks. Each statement is introduced by a line "-- check: <name> | <severity>"
-- and returns offending rows. dop.build runs them in order and stops on any
-- non-empty result for severity "fatal". "report" checks are recorded only.

-- check: places_single_year_for_measure | fatal
SELECT DISTINCT year FROM places_dia WHERE year <> '{expected_year}';

-- check: places_value_types_known | fatal
SELECT DISTINCT value_type_id, value_type_label FROM places_dia
WHERE NOT ((value_type_id = '{crude_id}' AND value_type_label = '{crude_label}')
        OR (value_type_id = '{ageadj_id}' AND value_type_label = '{ageadj_label}'));

-- check: places_measure_label | fatal
SELECT DISTINCT measure_label FROM places_dia WHERE measure_label <> '{measure_label}';

-- check: places_unit_percent | fatal
SELECT DISTINCT unit FROM places_dia WHERE unit <> '%';

-- check: places_unique_county_measure_type | fatal
SELECT fips, measure_id, value_type_id, count(*) AS n FROM places_dia
GROUP BY ALL HAVING count(*) > 1;

-- check: places_numeric_parse | fatal
SELECT fips, value_type_id, value_raw, lcl_raw, ucl_raw, pop18_raw FROM places_dia
WHERE (value_raw <> '' AND value IS NULL) OR (lcl_raw <> '' AND lcl IS NULL)
   OR (ucl_raw <> '' AND ucl IS NULL) OR (pop18_raw <> '' AND pop18_places IS NULL);

-- check: places_interval_brackets_estimate | fatal
SELECT fips, value_type_id, value, lcl, ucl FROM places_dia
WHERE value IS NOT NULL AND (lcl IS NULL OR ucl IS NULL OR lcl > value OR ucl < value OR lcl < 0 OR ucl > 100);

-- check: places_missing_value_has_suppression_footnote | fatal
SELECT fips, value_type_id, footnote_symbol FROM places_dia
WHERE value IS NULL AND coalesce(footnote_symbol, '') <> '*';

-- check: places_fips_format | report
SELECT DISTINCT fips, state_abbr FROM places_locations WHERE NOT regexp_full_match(fips, '[0-9]{{5}}');

-- check: places_adult_population_le_total | fatal
SELECT fips, total_pop_places, pop18_places FROM places_dia
WHERE pop18_places IS NULL OR total_pop_places IS NULL OR pop18_places > total_pop_places OR pop18_places <= 0;

-- check: places_crude_and_ageadj_pair | fatal
SELECT fips FROM places_dia GROUP BY fips
HAVING count(DISTINCT value_type_id) <> 2;

-- check: places_state_prefix_consistent | fatal
SELECT l.fips, l.state_abbr, p.pep_state_name FROM places_locations l
JOIN pep23 p USING (fips)
WHERE l.state_name <> p.pep_state_name;

-- check: pep_unique_fips | fatal
SELECT fips, count(*) FROM pep23 GROUP BY fips HAVING count(*) > 1;

-- check: acs24_unique_fips | fatal
SELECT fips, count(*) FROM acs24 GROUP BY fips HAVING count(*) > 1;

-- check: acs23_unique_fips | fatal
SELECT fips, count(*) FROM acs23 GROUP BY fips HAVING count(*) > 1;

-- check: places24_single_year | fatal
SELECT DISTINCT year FROM places24_dia WHERE year <> '2022';

-- check: places24_measure_only | fatal
SELECT DISTINCT measure_id FROM places24_dia WHERE measure_id <> '{measure_id}';

-- check: places24_unique_county_type | fatal
SELECT fips, value_type_id, count(*) FROM places24_dia GROUP BY ALL HAVING count(*) > 1;

-- check: places24_value_types_known | fatal
SELECT DISTINCT value_type_id, value_type_label FROM places24_dia
WHERE NOT ((value_type_id = '{crude_id}' AND value_type_label = '{crude_label}')
        OR (value_type_id = '{ageadj_id}' AND value_type_label = '{ageadj_label}'));

-- check: places24_numeric_parse | fatal
SELECT fips, value_raw FROM places24_dia WHERE value_raw <> '' AND value IS NULL;
