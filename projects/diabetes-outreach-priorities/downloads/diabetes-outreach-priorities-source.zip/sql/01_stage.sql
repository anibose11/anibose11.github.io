-- Stage raw sources as typed tables (DuckDB).
-- Brace placeholders are file paths and configured identifiers substituted by dop.build.
-- Every source column is read as VARCHAR first so identifiers keep leading zeros
-- and a failed numeric conversion can be detected instead of silently becoming NULL.

CREATE OR REPLACE TABLE places_raw AS
SELECT * FROM read_csv('{places_2025}', header = true, all_varchar = true);

-- Every location in the release, across all 40 measures.
CREATE OR REPLACE TABLE places_locations AS
SELECT DISTINCT LocationID AS fips, StateAbbr AS state_abbr, StateDesc AS state_name, LocationName AS county_name
FROM places_raw;

CREATE OR REPLACE TABLE places_dia AS
SELECT
    Year                                   AS year,
    StateAbbr                              AS state_abbr,
    StateDesc                              AS state_name,
    LocationName                           AS county_name,
    LocationID                             AS fips,
    MeasureId                              AS measure_id,
    Measure                                AS measure_label,
    DataValueTypeID                        AS value_type_id,
    Data_Value_Type                        AS value_type_label,
    Data_Value_Unit                        AS unit,
    DataSource                             AS data_source,
    Data_Value                             AS value_raw,
    Low_Confidence_Limit                   AS lcl_raw,
    High_Confidence_Limit                  AS ucl_raw,
    TRY_CAST(NULLIF(Data_Value, '') AS DOUBLE)            AS value,
    TRY_CAST(NULLIF(Low_Confidence_Limit, '') AS DOUBLE)  AS lcl,
    TRY_CAST(NULLIF(High_Confidence_Limit, '') AS DOUBLE) AS ucl,
    NULLIF(Data_Value_Footnote_Symbol, '') AS footnote_symbol,
    NULLIF(Data_Value_Footnote, '')        AS footnote,
    TotalPopulation                        AS total_pop_raw,
    TotalPop18plus                         AS pop18_raw,
    TRY_CAST(NULLIF(TotalPopulation, '') AS BIGINT) AS total_pop_places,
    TRY_CAST(NULLIF(TotalPop18plus, '') AS BIGINT)  AS pop18_places
FROM places_raw
WHERE MeasureId = '{measure_id}';

CREATE OR REPLACE TABLE pep_raw AS
SELECT * FROM read_csv('{pep}', header = true, all_varchar = true, encoding = 'latin-1');

CREATE OR REPLACE TABLE pep23 AS
SELECT
    lpad(STATE, 2, '0') || lpad(COUNTY, 3, '0') AS fips,
    STNAME  AS pep_state_name,
    CTYNAME AS pep_county_name,
    CAST(POPESTIMATE AS BIGINT)   AS pep_total_pop,
    CAST(AGE18PLUS_TOT AS BIGINT) AS pop18_pep
FROM pep_raw
WHERE SUMLEV = '050' AND YEAR = '5';

CREATE OR REPLACE TABLE acs24 AS
SELECT * FROM read_csv('{acs24}', header = true, types = {{'fips': 'VARCHAR'}});

CREATE OR REPLACE TABLE acs23 AS
SELECT * FROM read_csv('{acs23}', header = true, types = {{'fips': 'VARCHAR'}});

CREATE OR REPLACE TABLE places24_raw AS
SELECT * FROM read_csv('{places_2024}', header = true, all_varchar = true);

CREATE OR REPLACE TABLE places24_dia AS
SELECT
    year, stateabbr AS state_abbr, locationname AS county_name, locationid AS fips,
    measureid AS measure_id, measure AS measure_label,
    datavaluetypeid AS value_type_id, data_value_type AS value_type_label,
    data_value AS value_raw,
    TRY_CAST(NULLIF(data_value, '') AS DOUBLE)            AS value,
    TRY_CAST(NULLIF(low_confidence_limit, '') AS DOUBLE)  AS lcl,
    TRY_CAST(NULLIF(high_confidence_limit, '') AS DOUBLE) AS ucl,
    NULLIF(data_value_footnote_symbol, '') AS footnote_symbol,
    TRY_CAST(NULLIF(totalpop18plus, '') AS BIGINT) AS pop18_places
FROM places24_raw;
