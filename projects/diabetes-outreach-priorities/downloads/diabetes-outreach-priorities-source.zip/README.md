# County diabetes outreach priorities under alternative need definitions and published uncertainty

This project compares which U.S. counties would be shortlisted for diabetes outreach under three need definitions (crude prevalence, estimated number of adults with diagnosed diabetes, and prevalence among high-poverty counties). It also labels each selection as stable (core) or dependent on where values fall within the bounds used for each rule (boundary): the published PLACES 95% limits and, for estimated burden, scenario bounds built from them. It uses public CDC PLACES county estimates and Census Bureau population and poverty data. It does not contain any person-level data.

## Requirements

- Python 3.12 or later (the pinned versions in requirements.lock need 3.12)
- R 4.x (base packages only) for the second implementation used in `dop validate`
- About 150 MB of disk for downloaded sources
- Network access for `dop acquire` and for three of the four rechecks described below

No database server, API key or account is needed. ACS values come from the Census Bureau's public variance replicate files, which allow standard errors to be estimated for derived estimates.

## Setup

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.lock
pip install -e ".[test]"
```

`requirements.lock` pins the versions used for the reported run. `pip install -e .` alone installs compatible versions from `pyproject.toml`.

## Run

```bash
pytest                 # unit tests on small synthetic fixtures
dop demo               # the rules on a 40-county SYNTHETIC fixture (not study data)
dop acquire            # download sources, validate them and record SHA-256 hashes in source_manifest.json
dop build              # stage and check sources in DuckDB SQL, join, derive ACS replicate errors
dop analyze            # prespecified rules, envelopes, robustness checks -> outputs/tables/
dop validate           # deterministic rerun, invariants, base R cross-check, source reconciliation
dop render             # figures, manuscript, supplement, workbook, dashboard, site page, evidence/claims.json
dop package            # source archive in site/projects/.../downloads/
```

`scripts/run_all.sh` runs the tests, every pipeline stage and the four rechecks below in order from a fresh copy. It does not run `dop demo`.

Four independent rechecks run outside the pipeline. Three of them (summary files, live PLACES and references) need network access. `dop render` requires their results for the current run, because the manuscript reports them:

```bash
python scripts/check_summary_files.py   # ACS values vs the Census Bureau's table-based summary files, all counties
python scripts/check_places_live.py     # every frame county vs the live PLACES release on data.cdc.gov
python scripts/check_references.py      # every reference vs Crossref, PubMed, the Federal Register or its web page
python scripts/recompute_tables.py      # Tables 2 and 3 and every county classification by direct pairwise comparison
```

`cdc.gov` pages refuse scripted requests, so `outputs/validation/reference_browser_check.json` records the four cited `cdc.gov` pages as opened in a browser.

Each stage reads only earlier outputs, so any stage can be rerun alone once the earlier stages have run. From a fresh copy, run `dop acquire` and `dop build` before `dop analyze`. `dop acquire` reuses cached files whose hash matches the manifest and stops if a cached file changed. `dop acquire --refresh` replaces files deliberately and records the previous hash.

## Layout

| Path | Contents |
|---|---|
| `config/study.toml` | Prespecified parameters and source definitions |
| `src/dop/` | Pipeline code (`acquire`, `acs`, `build`, `envelope`, `analyze`, `validate`, `figures`, `report`, `workbook`, `dashboard`, `site`, `handoff`, `package`) |
| `sql/` | DuckDB staging, fail-loud checks and joins |
| `R/reference_check.R` | Base R second implementation |
| `tests/` | Unit tests. `tests/fixtures/` holds labeled synthetic data only |
| `docs/` | Analysis plan, contribution decision, prior art, literature search log, data dictionary, planning brief, Tableau specification, runtime manifest |
| `source_manifest.json` | Source URLs, access times, release labels, sizes and SHA-256 hashes |
| `outputs/tables/` | Result tables and the run record |
| `outputs/figures/` | Figures (PNG and SVG) |
| `outputs/validation/` | Results of every automated check (`validation_report.json`) and of the independent rechecks (`*_check.json`) |
| `scripts/` | Full-run script, the independent rechecks and the synthetic fixture generator |
| `manuscript/` | Manuscript template. `dop render` writes the manuscript and supplementary file (Markdown and DOCX) here |
| `evidence/claims.json` | Every reported number with its source file, selector and column |

## Data sources and terms

- CDC PLACES: Local Data for Better Health, County Data, 2025 release (data.cdc.gov dataset swc5-untb) and 2024 release (fu4u-a9bh). Public domain. CDC asks users to cite PLACES. A dataset can be updated in place, so the hash in `source_manifest.json` identifies the exact snapshot used.
- U.S. Census Bureau: ACS 2020-2024 and 2019-2023 five-year variance replicate tables B05003 and B17001, and Vintage 2023 county characteristics (CC-EST2023-AGESEX). U.S. Government works. This project uses Census Bureau data but is not endorsed or certified by the Census Bureau.

## What the results are and are not

PLACES estimates are model-based, not counts of diagnosed patients. Core and boundary labels describe the bounds used for each rule. The labels are not probabilities and not joint confidence sets. Estimated burden bounds are scenario bounds, not confidence intervals. Kentucky and Pennsylvania have no diagnosed-diabetes estimates in the 2025 release. The tables support deciding where to look more closely. They do not allocate services or evaluate programs.

## License and citation

Code is released under the MIT License (see `LICENSE`). Source data keep their own terms. Citation metadata is in `CITATION.cff`. No DOI has been assigned.
