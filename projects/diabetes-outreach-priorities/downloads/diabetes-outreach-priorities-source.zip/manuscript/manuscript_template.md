# Stability of county diabetes outreach priorities under alternative need definitions and published uncertainty: a cross-sectional analysis of U.S. small-area estimates

Animesh Bose

Norlowe Research

## Abstract

**Background:** Programs that plan diabetes outreach often shortlist counties from model-based small-area estimates. The shortlist depends on how need is defined and on the uncertainty of the estimates. This study measured how much each choice changes a county shortlist.

**Methods:** This cross-sectional analysis of {{frame_counties}} counties in {{frame_states}} states and the District of Columbia used Centers for Disease Control and Prevention PLACES 2025 estimates of crude diagnosed diabetes prevalence among adults, Census Bureau Vintage 2023 adult populations and American Community Survey (ACS) 2020-2024 poverty estimates with replicate-based errors. Three prespecified rules ranked counties by prevalence, by estimated number of adults with diagnosed diabetes (burden), and by prevalence among counties with at least 20% of residents in poverty. Selections at capacities of 10, 25 and 50 counties were compared by Jaccard overlap. Deterministic envelopes from the published 95% limits (scenario bounds for burden) classified counties as core (selected wherever every value falls within its bounds), boundary or outside. Kentucky and Pennsylvania had no diagnosed-diabetes estimates in the 2025 release.

**Results:** At a capacity of 25, the prevalence and burden rules shared none of the {{k25_prev_burden_union}} counties they selected, while the high-poverty rule shared {{k25_prev_equity_inter}} of {{k25_prev_equity_union}} counties with the prevalence rule. No county was core under the prevalence rule, and {{k25_prev_boundary}} counties could be in its top 25 under some combination of values within the published limits. Under the burden rule, {{k25_burden_core}} counties were core and {{k25_burden_boundary}} were boundary. Counties selected by prevalence held {{k25_prev_burden_share}} of the estimated {{burden_total}} adults with diagnosed diabetes in the frame, against {{k25_burden_burden_share}} for counties selected by burden. ACS 2019-2023 poverty estimates did not change the high-poverty selection. Within states, the prevalence and burden rules shared no county in {{ws_prev_burden_zero}} of {{ws_states}} states.

**Conclusions:** The definition of need decided which counties were selected. Under the prevalence definition, the published intervals could not separate a top 25 from several hundred plausible candidates, whereas the burden selection was largely stable. Small-area shortlists should state the need definition, report the boundary set with any ranked list, and serve as a starting point for local assessment.

**Keywords:** Diabetes mellitus; Small-area estimation; Health planning; Ranking; Uncertainty; Poverty; Counties; Decision support

## Background

County health departments, community organizations and diabetes prevention and self-management programs often have to decide where to look first. Diabetes self-management education and the National Diabetes Prevention Program are unevenly available across U.S. counties, and the gaps are largest in some places where diabetes is most common or most often newly diagnosed [1-3]. Choosing where to investigate unmet need is therefore a recurring planning task.

Most counties have no direct survey estimate of diabetes prevalence large enough to support that choice. The Centers for Disease Control and Prevention (CDC) PLACES (Population Level Analysis and Community Estimates) project fills the gap with model-based estimates for every county, produced by multilevel regression and poststratification of Behavioral Risk Factor Surveillance System (BRFSS) data [4-6]. In a validation against direct estimates from the 2011 Missouri County-Level Study, multilevel model estimates of diagnosed diabetes for 115 counties correlated with the direct estimates at r = 0.51 [6]. Analysts use these estimates to identify high-need counties, usually by ranking point estimates or applying a fixed cutoff. Recent PLACES examples include the top national quartile of diabetes prevalence [3] and quartiles of chronic obstructive pulmonary disease (COPD) prevalence crossed with the Social Vulnerability Index together with estimated counts of affected adults [7]. An earlier analysis of CDC county estimates defined a "diabetes belt" with a prevalence threshold of 11.0% [8].

Two choices sit inside any such list and are rarely examined together. The first is the definition of need. Ranking by prevalence finds places where a large share of adults is affected. Ranking by the estimated number of affected adults finds places where many affected people live. A socioeconomic criterion directs attention to places with fewer resources. Rose's observation that many cases arise among large numbers of people at modest risk rather than among the few at highest risk has a geographic counterpart in this choice [9]. In nonmetropolitan counties, those with a self-management program had more people with diagnosed diabetes but lower diabetes prevalence than counties without one [1].

The second choice is how to treat uncertainty. Rankings of estimates with sampling or model error are unstable [10-14], maps of estimates mislead in predictable ways [15], and CDC advises users of PLACES to consider confidence intervals rather than compare point estimates alone [16]. Formal methods give joint confidence regions for ranks [17] or confidence sets for the top-ranked units [18], and empirical Bayes procedures rank and select units under a model for the estimates [19]. These need simultaneous intervals, standard errors or a joint distribution of the estimates, whereas PLACES publishes only a marginal 95% percentile interval for each county.

I did not identify a study that measured, for diagnosed diabetes, how much a county shortlist changes across need definitions and within the published intervals of the estimates. This study asked which counties a planner would shortlist under three common definitions of need, at fixed capacities nationally and within states, and how much of each shortlist holds when the published uncertainty of the inputs is respected.

## Methods

### Design

This was a cross-sectional decision-sensitivity analysis of published county estimates. The analysis plan, including all rules, capacities, scenarios and robustness checks, was written and timestamped before any county value was ranked (Additional file 1). It is an internal plan and was not registered. Two additions made after the primary results, a descriptive summary of estimated burden and one comparison noted under Robustness checks, are identified as such below.

### Data sources

Table 1 lists the sources, reference periods and identifiers. All files were downloaded on 7 October 2026, and their file hashes are recorded in the source manifest.

Prevalence came from the PLACES county file, 2025 release (data.cdc.gov dataset swc5-untb, rows last updated {{places_rows_updated_display}}) [20]. The measure "Diagnosed diabetes among adults" is the share of adults aged 18 years or older who report having been told by a doctor or other health professional that they have diabetes, other than during pregnancy, from BRFSS 2023. PLACES fits a multilevel logistic model for each measure using some or all of individual age, sex, race and ethnicity, and education, the county percentage of adults below 150% of the federal poverty level from the five-year American Community Survey (ACS), and state and county random effects. It then poststratifies to Census Bureau county population estimates for 2023. The published value is the mean of the county estimates from 1,000 Monte Carlo simulations based on draws of the model parameters, and the 95% interval is the 2.5th and 97.5th percentiles of those estimates [21]. This study used crude prevalence because it applies to the actual adult population of each county. Age-adjusted prevalence was carried for display only and was never multiplied by a population.

The adult population was the TotalPop18plus field distributed with the PLACES estimates, documented as the Census Bureau's 2023 county estimate for ages 18 and older. It was checked against the Census Bureau's Vintage 2023 county characteristics file (CC-EST2023-AGESEX, July 1, 2023, AGE18PLUS_TOT) [22].

ACS values came from the Census Bureau's variance replicate tables for the 2020-2024 and 2019-2023 five-year estimates [23]. These tables contain the published estimates and margins of error together with 80 replicate estimates, which allow standard errors to be computed for derived sums and ratios [24]. Adults aged 18 and older were the sum of table B05003 lines 8 (male) and 19 (female). The poverty rate was table B17001 line 2 (income below the poverty level) divided by line 1 (population for whom poverty status is determined), times 100. Standard errors used the successive differences replication formula, variance = (4/80) times the sum over replicates of (replicate minus estimate) squared [24]. Published ACS margins of error are at 90% confidence [25], so 95% bounds were the estimate plus or minus 1.96 standard errors. Adult totals whose component cells were population-controlled were assigned no sampling error, following Census guidance [24]. The implementation reproduced the published integer margin of error for {{moe_m18}} uncontrolled male and {{moe_f18}} uncontrolled female adult cells, {{moe_povnum}} below-poverty cells, and {{moe_povden}} poverty-universe cells in the 2020-2024 files. In all {{moe_povden_mismatch_reps_equal}} remaining poverty-universe cells, the replicate estimates equaled the published estimate while the published margin was {{moe_povden_mismatch_min}} to {{moe_povden_mismatch_max}} persons, a negligible difference for the poverty-rate bounds.

### Analysis frame

The PLACES 2025 county file covers {{county_equivalents}} county equivalents in current Census Bureau geography, which includes Connecticut's nine planning regions. These replaced the state's eight counties as county equivalents in 2022 [26]. The file contains no diagnosed-diabetes estimates for Kentucky ({{excluded_ky}} counties) or Pennsylvania ({{excluded_pa}} counties), because BRFSS 2023 data from those states did not meet the requirements for the public data set [27, 28]. One county (Loving County, Texas, with {{suppressed_adults}} adults and {{suppressed_total}} residents) had its estimates suppressed by CDC, which does not publish estimates for areas with a population below 50 [16], and a national summary row was removed. The frame therefore had {{frame_counties}} counties in {{frame_states}} states and the District of Columbia. Every frame county matched exactly one Census Vintage 2023 record and one record in each ACS vintage on its five-digit Federal Information Processing Standards (FIPS) code, stored as text with leading zeros. The only ACS records without a PLACES match were {{acs_unmatched_pr}} Puerto Rico municipios, which PLACES does not cover.

### Planning rules

Three rules were fixed before results:

1. Prevalence: rank counties by crude prevalence.
2. Estimated burden: rank counties by the estimated number of adults with diagnosed diabetes, crude prevalence divided by 100 times the adult population. CDC describes the same calculation for converting PLACES prevalence into counts [16]. The product of a model-based prevalence and a population estimate is an estimate, not a count of identified patients.
3. High-poverty prevalence: restrict to counties where at least 20.0% of people are below the poverty level, the threshold the U.S. Department of Agriculture (USDA) Economic Research Service uses for high-poverty counties [29], and rank those counties by crude prevalence. Estimated burden is displayed alongside but does not enter the ranking. The threshold is a declared planning criterion, not an estimated optimal weight, and no composite need score was built.

No regression of prevalence on socioeconomic variables was fitted. CDC states that the PLACES approach incorporates poverty along with age, sex, race and ethnicity, and education [16], so such an association would partly reproduce the model's own inputs [30].

Rankings were descending with competition ties: a county's rank was 1 plus the number of counties with a strictly larger value. A county was selected at capacity K if its rank was K or better, so all counties tied at the cutoff were selected and set sizes are reported.

### Capacities

National capacities were 10, 25 (primary) and 50 counties. These are illustrative sizes for a shortlist, not program budgets. Within each state the capacity was 5 counties. The {{ws_all_units}} have 5 or fewer frame counties. All their units are shown, and they were excluded from within-state stability summaries.

### Uncertainty envelopes

PLACES intervals are marginal: they describe each county separately, and the estimates share a model and covariates, so their errors are not independent. This study therefore did not simulate independent draws or report probabilities of selection. Instead, for a rule with lower and upper bounds L and U, each county's best-case rank was 1 plus the number of other counties whose lower bound exceeds its upper bound, and its worst-case rank was 1 plus the number of other counties whose upper bound exceeds its lower bound. This is the interval-counting logic used by Klein, Wright and Wieczorek for rankings of ACS estimates [17], applied here to unadjusted marginal 95% intervals rather than simultaneous intervals. At capacity K, a county was core if its worst-case rank was K or better, boundary if only its best-case rank was K or better, and outside otherwise. A core county stays selected wherever every county's value falls within its bounds. A boundary county is selected under some combinations of values within the bounds and not others. The worst case places every competitor at its upper bound at once, which is not a jointly attainable confidence statement, so the result is described as a sensitivity envelope.

For the prevalence rule the bounds were the PLACES 95% limits. For the burden rule, the lower bound was the prevalence lower limit times the smaller of the Vintage 2023 adult estimate and the ACS 95% lower bound for adults, and the upper bound was the prevalence upper limit times the larger of the Vintage 2023 estimate and the ACS 95% upper bound. Population estimates carry no published sampling error, so this range combines the two published adult figures with the ACS sampling range. It is not a confidence interval, because the covariance between the prevalence and population inputs is unknown. For the high-poverty rule, a county was certainly eligible if its 95% lower poverty bound was at least 20%, eligible at the point estimate if its estimate was at least 20%, and possibly eligible if its upper bound was at least 20%. Best-case ranks counted only certainly eligible competitors, worst-case ranks counted all possibly eligible competitors, and only certainly eligible counties could be core.

Each rule was also ranked with every county at its lower bound and with every county at its upper bound, and for the high-poverty rule within the certainly and possibly eligible groups. These scenario sets were compared with the point-estimate set.

### Outcomes

The primary outcomes at capacity 25 were the pairwise Jaccard overlap (intersection divided by union) between the three point-estimate selected sets, and the numbers of core and boundary counties for each rule. Rule dependence was summarized for every county selected under any rule. County-level ranks, bounds and labels for every rule and capacity are tabulated in Additional file 2. After the primary results were produced, a descriptive summary of each selected set's total estimated burden and its share of the frame total was added (Table 2, last column). It did not change any rule or classification.

### Robustness checks

Three checks were prespecified: (1) capacities of 10 and 50, (2) point-estimate selections compared with lower-bound and upper-bound scenario selections, and (3) a strictly aligned subset of {{aligned_counties}} counties. The aligned subset excluded Connecticut's nine planning regions, whose geography changed after the 2020 Census, and used ACS 2019-2023, the vintage named in the PLACES 2025 documentation, for poverty and the adult range. An optional descriptive comparison applied the prevalence and burden rules to the PLACES 2024 county release (BRFSS 2022), which includes Kentucky and Pennsylvania [31]. The high-poverty rule was also applied to that release, with the same ACS 2020-2024 poverty criterion as the primary analysis. This extension was added after the primary results and was not in the plan. The comparison describes the consequence of the 2025 coverage gap. It is not a validation, because the releases differ in survey year and model inputs.

### Software, checks and reproducibility

The analysis was written in Python 3.13.5 (pandas 3.0.6, NumPy 2.5.3), with joins and integrity checks in DuckDB 1.5.6, an embedded database, and a second implementation in base R 4.5.1. It runs as six commands (acquire, build, analyze, validate, render, package). The build stage stops if a downloaded file differs from its recorded hash, or on any of these conditions: mixed release years, value types that are not exactly crude or age-adjusted prevalence, duplicate county-measure-type keys, intervals that do not bracket their estimates, adult populations above totals, unparseable numbers, or a join that changes the number of counties.

Software checks included {{n_tests}} unit tests on small synthetic fixtures, a rerun of the build and analysis stages from cached inputs, ordering invariants and the base R implementation. The rerun reproduced the analysis frame and every result table (relative tolerance 10^-12, absolute tolerance 10^-9). The invariants were that every core county is selected and that every selected county is core or boundary. The base R implementation recomputed the ACS 2020-2024 replicate standard errors from the raw Census archives and reproduced all {{r_rows}} rule, capacity and county results exactly. A third implementation, written without the analysis package, rebuilt every rank and envelope by direct pairwise comparison and reproduced every cell of Tables 2 and 3.

Source reconciliation showed that the PLACES adult population equaled the Census Vintage 2023 adult estimate for {{pep_match}} counties. It also showed that the ACS adult counts and poverty numerators and denominators derived from the replicate tables equaled the Census Bureau's separately published table-based summary files [32] for all {{sf_counties}} counties in both vintages, and that the estimate, 95% limits and adult population of all {{places_live_counties}} frame counties equaled the live PLACES 2025 release [20] on {{places_live_date}}.

I also checked the analysis by hand, separately from the code. I looked up a random sample of 12 frame counties, drawn with a fixed seed, in the PLACES 2025 county release [20] and in ACS table S1701 [33], recalculated their estimated burden by hand in a spreadsheet, sorted the public PLACES file to confirm the {{k10_prev_selected}} counties ranked in the top 10 by crude prevalence (including ties), compared every number in the tables and figures with the result files, and checked each reference against its publisher or PubMed record. No external validation of the prevalence estimates against observed outcomes was possible or attempted.

All code, configuration, the analysis plan, the source manifest with file hashes, and the result tables are provided in Additional file 3. The run reported here has identifier {{run_id}}, a hash of the configuration, the analysis code and the source files.

## Results

### Frame and inputs

Across the {{frame_counties}} counties, the median crude prevalence of diagnosed diabetes was {{prev_median}}% (interquartile range {{prev_q1}} to {{prev_q3}}, range {{prev_min}} to {{prev_max}}). The median width of a county's 95% interval was {{width_median}} percentage points (interquartile range {{width_q1}} to {{width_q3}}). The frame contained {{adults_total}} adults and an estimated {{burden_total}} adults with diagnosed diabetes. At the point estimate, {{hp_point}} counties met the poverty criterion, while {{hp_certain}} met it with certainty and {{hp_possible}} possibly met it. ACS 2020-2024 adult estimates differed from the Vintage 2023 estimates by a median of {{acs_pep_median_abs}} (90th percentile {{acs_pep_p90}}).

### The need definition determined the selection

Table 2 and Figure 1 show the selected sets. The prevalence and burden rules shared no county at any capacity (Table 3). At capacity 25, the prevalence rule selected {{k25_prev_selected}} counties, one more than the capacity because of a tie at the cutoff. They were in {{k25_prev_states_list}}, and they were small (median {{k25_prev_sel_median_adults}} adults, range {{k25_prev_sel_min_adults}} to {{k25_prev_sel_max_adults}}). The burden rule selected 25 large counties in {{k25_burden_sel_states}} states (median {{k25_burden_sel_median_adults}} adults, smallest {{k25_burden_sel_min_adults}}), with prevalence from {{k25_burden_sel_minprev}}% to {{k25_burden_sel_maxprev}}%. The high-poverty rule shared {{k25_prev_equity_inter}} of its counties with the prevalence rule (Jaccard {{k25_prev_equity_j}}), because {{k25_prev_sel_hp_point}} of the {{k25_prev_selected}} prevalence-selected counties met the poverty criterion at the point estimate ({{k25_prev_sel_hp_certain}} with certainty). Of the {{k25_selected_any}} counties selected under any rule at capacity 25, {{k25_selected_by_one}} were selected by one rule and {{k25_selected_by_two}} by two. No county was selected, or core, under all three rules at any capacity.

The selections differed sharply in how many affected adults they covered. At capacity 25, the prevalence selection contained an estimated {{k25_prev_burden_sum}} adults with diagnosed diabetes ({{k25_prev_burden_share}} of the frame total), the high-poverty selection {{k25_equity_burden_sum}} ({{k25_equity_burden_share}}), and the burden selection {{k25_burden_burden_sum}} ({{k25_burden_burden_share}}). At capacity 50 the shares were {{k50_prev_burden_share}}, {{k50_equity_burden_share}} and {{k50_burden_burden_share}}.

### Published uncertainty left the prevalence top 25 undetermined

No county was core under the prevalence rule at capacities 10 or 25, and one county ({{k50_prev_core_county}}) was core at capacity 50 (Figure 2). The number of boundary counties was {{k10_prev_boundary}}, {{k25_prev_boundary}} and {{k50_prev_boundary}} at capacities 10, 25 and 50. The highest-ranked county, {{top_prev_county}} ({{top_prev}}%, 95% interval {{top_lcl}} to {{top_ucl}}), had a worst-case rank of {{top_worst25}}, and the worst-case ranks of the {{k25_prev_selected}} selected counties ranged from {{k25_prev_sel_worst_min}} to {{k25_prev_sel_worst_max}} (median {{k25_prev_sel_worst_median}}, Figure 3). Kalawao County, Hawaii, with {{kalawao_adults}} adults ({{kalawao_prev}}%, interval {{kalawao_lcl}} to {{kalawao_ucl}}), ranked {{kalawao_rank25}} by point estimate with a worst-case rank of {{kalawao_worst25}}. The {{k25_prev_boundary}} boundary counties at capacity 25 were spread over {{k25_prev_boundary_states}} states, led by {{k25_prev_boundary_topstates}}, and had point estimates from {{k25_prev_boundary_minprev}}% to {{top_prev}}%. A county was in the boundary set exactly when its upper limit reached {{k25_prev_cut}}%, the 25th-highest lower limit, so some counties with point estimates above the lowest boundary estimate of {{k25_prev_boundary_minprev}}%, up to {{k25_prev_outside_maxprev}}%, were outside because their upper limits were {{k25_prev_outside_max_ucl}}% or less. The high-poverty rule behaved the same way, with {{k25_equity_core}} core and {{k25_equity_boundary}} boundary counties at capacity 25.

The burden selection was much more stable. At capacities 10, 25 and 50 it had {{k10_burden_core}}, {{k25_burden_core}} and {{k50_burden_core}} core counties and {{k10_burden_boundary}}, {{k25_burden_boundary}} and {{k50_burden_boundary}} boundary counties. All {{k25_burden_core}} burden-core counties at capacity 25 were outside the envelope of the prevalence rule, so their inclusion depended on the choice of rule rather than on uncertainty.

Ranking every county at its lower bound, or every county at its upper bound, changed the point-estimate sets only slightly. At capacity 25, the Jaccard overlap between the point-estimate set and the all-lower-bound set was {{k25_prev_scn_lower_j}} for prevalence, {{k25_burden_scn_lower_j}} for burden and {{k25_equity_scn_lower_j}} for high-poverty prevalence. Restricting the high-poverty rule to certainly eligible counties gave an overlap of {{k25_equity_scn_certain_j}}.

### Within-state views

In the {{ws_states}} states with more than 5 frame counties, at least one prevalence-selected county was core in {{ws_prev_core_states}} states, compared with {{ws_burden_core_states}} states for the burden rule (median {{ws_burden_core_median}} of 5 selected counties core). The prevalence and burden selections shared no county in {{ws_prev_burden_zero}} states. The overlap between the prevalence and high-poverty selections depended on how many counties met the poverty criterion. Fewer than 5 did so in {{ws_equity_shortfall}} states, {{ws_equity_none}} of which had none, and in the {{ws_equity_ge5_states}} states with at least 5 the median Jaccard index was {{ws_prev_equity_median_j_ge5}}.

### Robustness

In the strictly aligned subset of {{aligned_counties}} counties, the prevalence and burden point selections could change only through the removal of Connecticut, none of whose planning regions was in a national selection, and they were identical. With ACS 2019-2023 poverty estimates, {{aligned_hp_point}} of these counties met the poverty criterion at the point estimate, compared with {{aligned_hp_point_primary}} with ACS 2020-2024. The high-poverty selections were unchanged (minimum Jaccard {{aligned_min_j}}), and the high-poverty boundary set at capacity 25 grew from {{k25_equity_boundary}} to {{aligned_equity_boundary_k25}} counties. With the ACS 2019-2023 adult range, the burden core was unchanged, while the burden boundary set at capacity 25 changed from {{k25_burden_boundary}} to {{aligned_burden_boundary_k25}} counties (Additional file 1, Table S5). In the PLACES 2024 release (BRFSS 2022), among counties in both releases, overlap with the 2025 top 25 was {{prior_k25_prev_j}} for prevalence ({{prior_k25_prev_inter}} of {{prior_k25_prev_union}} counties), {{prior_k25_burden_j}} for burden and {{prior_k25_equity_j}} for high-poverty prevalence. In the full 2024 frame of {{prior_frame}} counties, Kentucky and Pennsylvania counties held {{prior_k25_prev_kypa}} of the top 25 places by prevalence, {{prior_k25_burden_kypa}} by burden and {{prior_k25_equity_kypa}} by high-poverty prevalence. At capacity 50 they held {{prior_k50_prev_kypa}}, {{prior_k50_burden_kypa}} and {{prior_k50_equity_kypa}}.

## Discussion

### Principal findings

The choice of need definition decided which counties were selected. A prevalence ranking and a burden ranking of the same estimates shared no county nationally and none in most states. Under prevalence, the selection consisted of small, mostly Southern counties where {{k25_prev_sel_minprev}}% to {{top_prev}}% of adults report diagnosed diabetes. Under burden, it consisted of large metropolitan counties (median {{k25_burden_sel_median_adults}} adults). The two selections differed more than a hundredfold in the estimated number of affected adults they contained.

The high-poverty rule nearly reproduced the prevalence ranking nationally, because the highest-prevalence counties were almost all high-poverty counties.

Uncertainty affected the two kinds of ranking very differently. The point estimates of the {{k25_prev_selected}} prevalence-selected counties spanned only {{k25_prev_sel_minprev}}% to {{top_prev}}%, while a typical county interval was about four percentage points wide, so each selected county's interval overlapped those of many counties ranked below it. A prevalence top 25 therefore could not be separated from several hundred plausible candidates. The burden ranking was largely stable, because adult populations differ by orders of magnitude and dominate the prevalence uncertainty.

### Comparison with previous work

The instability of the prevalence ranking is consistent with earlier work on league tables and county rankings [10-14]. Arndt and colleagues found that a county in a state's top 10% on a County Health Rankings measure stayed there in about two thirds of simulated redraws, with wide variation by measure [12]. Courtemanche and colleagues recommended attention to counties that stay among the least healthy across weightings and uncertainty [14]. The present analysis reaches a similar conclusion without simulating independent draws, which would be inappropriate for model-based estimates that share structure, and it adds the comparison across need definitions. The envelope is a marginal-interval version of the rank bounds of Klein and colleagues [17]. Their joint region, which needs intervals at a multiplicity-adjusted level, and the confidence sets of Mogstad and colleagues for the best-ranked units [18], which need a covariance matrix, would be the right tools if PLACES published standard errors or simulation draws.

Earlier PLACES planning studies classified counties with cutoffs on point estimates [3, 7], and one stated that measures of error were not included [7]. Their comparisons concern broad groups such as quartiles, which are less sensitive to interval width than a shortlist. The present results suggest that classifications near any cutoff, and any shortlist, should be reported with the number of counties within interval distance of the cutoff. Holt and colleagues aggregated counts derived from small-area prevalence without confidence intervals [34]. The burden envelope here is one practical way to bound such counts.

The rule comparison is a geographic form of the contrast Rose described [9]. Neither definition is correct in general. A program that wants to reach many people would start from burden, and one that wants to reach communities where diabetes is most common, which here were also poorer communities, would start from prevalence or the high-poverty rule. The finding that program presence followed the number of people with diabetes rather than prevalence [1] fits this pattern.

### Implications for planning

A county shortlist should state its definition of need and show the core and boundary sets alongside the ranking. For a prevalence objective, the boundary set is the realistic pool for further assessment. If several definitions matter, one transparent option is to consider the union of their core and boundary sets and retain the reason each county appears. This study did not evaluate whether that approach performs better than a composite score. In every case the list is a starting point. Acting on it requires local information that these data do not contain, such as existing programs, clinical and community capacity, and the views of the communities concerned (Additional file 1).

### Limitations

PLACES estimates are model-based and are not counts of diagnosed patients. Their intervals come from simulating the model's parameters [4, 21], so they do not reflect model misspecification or self-report error, and the moderate validation correlation for diabetes [6] suggests that point-estimate rankings carry error beyond the published intervals. Model smoothing may also compress the highest values.

The envelopes can err in both directions. Placing every competitor at its bound at the same time makes the core set small and the boundary set large compared with an analysis of the joint distribution of the estimates, which PLACES does not publish. In the other direction, the 95% intervals are marginal, carry no multiplicity adjustment and omit model error, so some true values lie outside them. A core county is therefore not guaranteed to stay selected, and an outside county could enter. Neither label is a probability.

The measure covers diagnosed diabetes only, and undiagnosed diabetes varies across counties [35]. Kentucky and Pennsylvania have no diagnosed-diabetes estimates in the 2025 release. The 2024 release suggests that this gap changes few national selections, but no within-state view is possible for those states.

The population estimate used for burden has no published sampling error, so the burden bounds use the ACS range as a proxy.

The 20% poverty threshold is a declared choice, and PLACES uses a related poverty measure in estimation, so the overlap between the prevalence and high-poverty rules is partly built into the estimates and is not independent evidence about poverty and diabetes [30]. The BRFSS 2023 data are the most recent in the newest PLACES county release available in October 2026. The capacities are illustrative, the within-state capacity does not scale with state size, and this ecological analysis cannot support conclusions about individuals.

## Conclusions

Which counties a planner shortlists for diabetes outreach depends mainly on how need is defined. In these estimates, a prevalence-based shortlist could not be separated from a much larger set of plausible candidates, while a burden-based shortlist was largely stable. Reporting the need definition and the boundary set with every shortlist would make small-area estimates more useful for planning and less likely to be read as more precise than they are.

## List of abbreviations

ACS: American Community Survey; BRFSS: Behavioral Risk Factor Surveillance System; CDC: Centers for Disease Control and Prevention; COPD: chronic obstructive pulmonary disease; FIPS: Federal Information Processing Standards; PLACES: Population Level Analysis and Community Estimates; USDA: U.S. Department of Agriculture.

## Declarations

### Ethics approval and consent to participate

Not applicable. This study is a secondary analysis of publicly available, aggregate county-level estimates published by the Centers for Disease Control and Prevention and the U.S. Census Bureau. No participants were recruited, no individual-level or identifiable data were accessed, and ethics approval was therefore not sought.

### Consent for publication

Not applicable.

### Availability of data and materials

The datasets analyzed during the current study are publicly available from the Centers for Disease Control and Prevention and the U.S. Census Bureau. They are the 2025 release of PLACES County Data (data.cdc.gov dataset swc5-untb) [20] and its 2024 release (dataset fu4u-a9bh) [31], the ACS 5-year variance replicate tables B05003 and B17001 [23], and the Census Vintage 2023 county characteristics file CC-EST2023-AGESEX [22]. These files are U.S. federal government works and may be reused without restriction. The datasets generated during the current study, namely the county priority table, summary tables and an analysis workbook with definitions, are provided with this manuscript and its supplementary files (Additional files 1 and 2). The analysis code (Python, SQL and R), configuration, analysis plan, source manifest with the SHA-256 hash of every downloaded file, and all derived tables are provided in Additional file 3 under the MIT License. The workflow downloads the public files, stops if any file differs from its recorded hash, and reproduces every reported result.

- Project name: Diabetes outreach priorities
- Project home page: not applicable (the code is provided as Additional file 3)
- Archived version: Additional file 3
- Operating system: platform independent (run on macOS)
- Programming languages: Python 3.13, SQL (DuckDB 1.5.6) and R 4.5.1
- Other requirements: Python packages listed in requirements.lock and base R only
- License: MIT
- Any restrictions to use by non-academics: none

### Competing interests

Animesh Bose is the owner of Norlowe Research. The author declares no other competing interests.

### Funding

This research received no specific grant from any funding agency in the public, commercial or not-for-profit sectors. I carried out the work using internal resources from Norlowe Research, which I own. No external funder was involved in the design of the study, the collection, analysis or interpretation of the data, or the writing of the manuscript.

### Authors' contributions

Animesh Bose (AB) is the sole author and was responsible for conceptualization, methodology, software, validation, formal analysis, investigation, data curation, visualization, writing of the original draft, and review and editing. The author reviewed and revised the manuscript.

### Acknowledgements

Not applicable.


## References

{{REFERENCES}}

## Tables

{{TABLES}}

## Figure legends

**Figure 1. Prevalence and adult population of counties selected under each rule.** Gray points are all {{frame_counties}} frame counties. Colored marks show counties selected at capacity 25 under the prevalence rule (filled circles), the high-poverty prevalence rule (open circles) and the estimated burden rule (squares). Adult population is the Census Vintage 2023 estimate on a logarithmic axis. Some burden-selected counties overlap at this scale. All are listed in Additional file 1, Table S8b. PLACES 2025 release.

**Figure 2. Core and boundary counties for each rule and capacity.** Bars show the number of counties classified as core (selected wherever every county's value falls within the bounds used for the rule) and boundary (selected under some combinations of values within the bounds). Bounds are the published PLACES 95% limits and, for estimated burden, scenario bounds that also span the adult population range. For high-poverty prevalence, eligibility also spans the ACS 95% poverty bounds: a county whose upper bound reaches 20% can be boundary, and only a county whose lower bound reaches 20% can be core. The vertical mark shows the capacity. National frame of {{frame_counties}} counties. PLACES 2025 release.

**Figure 3. Rank ranges for the highest-ranked counties at capacity 25.** Left panel: prevalence rule. Right panel: estimated burden rule. Each panel shows the 35 counties with the best point-estimate ranks under that rule. Lines run from the best-case to the worst-case rank within the rule's bounds, and dots mark point-estimate ranks. Blue marks core counties and orange marks boundary counties. The vertical line is the capacity of 25, the rank axis is logarithmic, and ties share a rank. PLACES 2025 release.

## Additional files

**Additional file 1.** File format: .docx. Title: Supplementary methods and tables. Description: analysis plan and amendments, exclusions, scenario overlaps, within-state results, robustness checks, source reconciliation and the planning brief (sections S1 to S10, Tables S1 to S9).

**Additional file 2.** File format: .xlsx. Title: Analysis workbook. Description: definitions sheet, the county priority table for all {{frame_counties}} frame counties, and the summary tables.

**Additional file 3.** File format: .zip. Title: Source archive. Description: analysis code (Python, SQL and R), configuration, tests, analysis plan, source manifest with file hashes, derived tables and the scripts for the independent rechecks. README.md gives the commands that reproduce every result.
