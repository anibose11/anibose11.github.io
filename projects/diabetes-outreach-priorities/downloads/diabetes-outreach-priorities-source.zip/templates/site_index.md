# How outreach priorities change which counties are selected

<p class="meta">Animesh Bose. County planning study using CDC PLACES 2025 estimates and Census Bureau data, October 2026.</p>

**Research question.** A program can prioritize places where diabetes is most common or places where the most affected adults live. I compared those choices, a poverty-based rule, and the uncertainty around each resulting county list.

<figure>
<a href="assets/fig2_capacity_envelope.png"><img src="assets/fig2_capacity_envelope.svg" alt="Horizontal bars for three rules at capacities 10, 25 and 50. Under prevalence, {{k10_prev_core}}, {{k25_prev_core}} and {{k50_prev_core}} counties are core and {{k10_prev_boundary}}, {{k25_prev_boundary}} and {{k50_prev_boundary}} are boundary. Under estimated burden, {{k10_burden_core}}, {{k25_burden_core}} and {{k50_burden_core}} are core and {{k10_burden_boundary}}, {{k25_burden_boundary}} and {{k50_burden_boundary}} boundary. Under high-poverty prevalence, {{k10_equity_core}}, {{k25_equity_core}} and {{k50_equity_core}} are core and {{k10_equity_boundary}}, {{k25_equity_boundary}} and {{k50_equity_boundary}} boundary." width="2288" height="1280"></a>
<figcaption>Counties that stay selected wherever every value falls within the bounds used for the rule (core) and counties whose selection depends on where values fall (boundary), by rule and capacity. Bounds are the published PLACES 95% limits and, for estimated burden, scenario bounds that also span the adult population range. For high-poverty prevalence, eligibility also spans the ACS 95% poverty bounds. A county whose upper bound reaches 20% can be boundary, and only a county whose lower bound reaches 20% can be core. The same numbers are in <a href="report.html#table-2">Table 2</a> and <a href="report.html#figure-2">Figure 2</a> of the report.</figcaption>
</figure>

<div class="stats">
<div class="stat"><b>{{k25_prev_burden_inter}} of {{k25_prev_burden_union}}</b><span>counties shared by the prevalence and burden selections at a capacity of 25; the prevalence cutoff tie adds one county</span></div>
<div class="stat"><b>{{k25_prev_boundary}}</b><span>counties that could be in a prevalence top 25 within the published limits, and none is core</span></div>
<div class="stat"><b>{{k25_burden_core}} of 25</b><span>burden-selected counties that are core</span></div>
<div class="stat"><b>{{k25_prev_burden_share}} vs {{k25_burden_burden_share}}</b><span>share of estimated adults with diagnosed diabetes inside the prevalence and burden top 25</span></div>
</div>

## Data sources and coverage

- **Prevalence:** CDC PLACES County Data, 2025 release, "Diagnosed diabetes among adults", crude prevalence with 95% intervals. PLACES estimates come from a multilevel model of Behavioral Risk Factor Surveillance System 2023 responses and are model-based estimates rather than counts of diagnosed patients.
- **Adults:** Census Bureau Vintage 2023 estimates of people aged 18 and older, as distributed with PLACES. They matched the Census file exactly for {{pep_match}} counties.
- **Poverty:** American Community Survey 2020-2024 five-year estimates, with standard errors computed from the Census Bureau's 80 published replicate estimates.
- **Coverage:** {{frame_counties}} counties in {{frame_states}} states and the District of Columbia. Kentucky ({{excluded_ky}} counties) and Pennsylvania ({{excluded_pa}}) have no diabetes estimates in the 2025 release because their BRFSS 2023 data did not meet the inclusion requirements.

## Three definitions of need, fixed before any county was ranked

1. **Prevalence:** the share of adults with diagnosed diabetes.
2. **Estimated burden:** prevalence times the adult population, an estimate of how many adults have diagnosed diabetes.
3. **High-poverty prevalence:** prevalence ranked only among counties where at least 20% of people are below the poverty level.

Each rule selects 10, 25 or 50 counties nationally and 5 within each state. The rules, capacities and uncertainty scenarios were written into a timestamped analysis plan before results.

## How the uncertainty bounds were used

**Using published bounds without simulation.** PLACES publishes one interval per county, and its estimates share a model, so their errors are not independent. Simulating independent draws would produce selection probabilities that look precise but are not calibrated. I used only interval bounds, the published PLACES limits and, for burden, scenario bounds built from them: a county is core if it stays in the top K when every county's value sits anywhere within its bounds, and boundary if it is in the top K for some of those values. The worst case is extreme by design, so these labels form a sensitivity envelope and carry no confidence level.

**A matched adult denominator.** Burden multiplies crude prevalence, not age-adjusted prevalence, by the adult population that PLACES itself used, and checks it against the Census file. Because population estimates have no published sampling error, the burden bounds widen the denominator to cover the ACS 2020-2024 range as well, and are labeled as scenario bounds.

## Which counties were selected and how stable were the lists

- At 25 counties, the prevalence and burden lists shared no county. Prevalence picked {{k25_prev_selected}} small counties (a tie at the cutoff added one) in {{k25_prev_states_list}}, with a median of {{k25_prev_sel_median_adults}} adults. Burden picked large metropolitan counties with a median of {{k25_burden_sel_median_adults}} adults.
- The high-poverty rule picked {{k25_prev_equity_inter}} of the same {{k25_prev_equity_union}} counties as prevalence, because almost every highest-prevalence county is also high-poverty. PLACES uses poverty in its model, so this overlap is partly built in.
- No prevalence-selected county was core at 25. The top-ranked county, {{top_prev_county}} ({{top_prev}}%, interval {{top_lcl}} to {{top_ucl}}), could fall to rank {{top_worst25}}.
- The burden list was more stable: {{k25_burden_core}} of 25 counties were core.
- Within states, prevalence and burden shared no county in {{ws_prev_burden_zero}} of {{ws_states}} states.
- National selections under all three rules at capacities 10, 25 and 50 were unchanged in a strictly aligned subset of {{aligned_counties}} counties.
- In the 2024 release, which includes Kentucky and Pennsylvania, those states held {{prior_k25_prev_kypa}} of the top 25 places by prevalence and {{prior_k25_burden_kypa}} by burden.

## Limitations

The estimates are model-based and validated only moderately for diabetes at the county level, which suggests that true rankings carry more error than the published intervals show. The envelopes are not joint confidence sets. Only diagnosed diabetes is measured. The 20% poverty threshold is a declared planning choice. Kentucky and Pennsylvania have no diagnosed-diabetes estimates in this release. The shortlists say where to look. Acting on them needs local information on programs, capacity and community priorities that these data do not contain.

## Reproduce

The reported run used Python 3.13.5 and R 4.5.1. The package needs Python 3.12 or later, and `dop validate` also needs R (base packages only). From the source archive:

<pre><code>python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.lock
pip install -e ".[test]"
pytest
dop acquire && dop build && dop analyze && dop validate && dop render</code></pre>

`dop demo` runs the same code on a small synthetic fixture in under a second, and `scripts/run_all.sh` runs every step in order. Every run is identified by a hash of the configuration, the analysis code and the source files. The run reported here is {{run_id}}.

## Files

<ul class="files">
<li><a href="report.html">Full report</a> and <a href="supplement.html">supplementary methods and tables</a></li>
<li><a href="dashboard.html">County priority tables</a>: filter by rule, capacity, state and status</li>
<li><a href="downloads/diabetes-outreach-priorities-workbook.xlsx">Analysis workbook</a> (XLSX, with a definitions sheet)</li>
<li><a href="downloads/county_priority_table.csv">County priority table</a> (CSV, one row per county, with source and measure columns)</li>
<li><a href="downloads/summary_tables.zip">Summary tables</a> (ZIP of CSV files with a data dictionary)</li>
<li><a href="downloads/planning-brief.html">One-page planning brief</a></li>
<li><a href="downloads/diabetes-outreach-priorities-source.zip">Source archive</a> (code, configuration, tests, source manifest and derived tables)</li>
</ul>
