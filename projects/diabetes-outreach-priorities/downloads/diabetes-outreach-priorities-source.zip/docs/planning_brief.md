# Planning brief: using the county diabetes priority tables

This brief is for an analyst deciding which counties to examine first for diabetes outreach. The tables rank counties from public estimates. They do not say where to place services, and they contain no information about local programs, staff or community priorities.

## What the tables contain

For 2,956 counties in 48 states and the District of Columbia, the tables show three ways of ranking need, all built from the CDC PLACES 2025 county release (diagnosed diabetes among adults, BRFSS 2023) and Census Bureau population and poverty estimates:

- **Prevalence**: the share of adults reporting diagnosed diabetes.
- **Estimated burden**: prevalence times the adult population, an estimate of how many adults have diagnosed diabetes.
- **High-poverty prevalence**: prevalence ranked only among counties where at least 20% of people are below the poverty level.

Each county is labeled at capacities of 10, 25 and 50 counties nationally and 5 within its state as **core** (selected wherever every county's value falls within the bounds used for the rule: the published PLACES 95% limits and, for estimated burden, scenario bounds that also span the adult population range), **boundary** (selected under some values within the bounds) or **outside**. For high-poverty prevalence, eligibility also spans the ACS 95% poverty bounds. A county whose upper bound reaches 20% can be boundary, and only a county whose lower bound reaches 20% can be core. These labels describe the published estimates. They are not probabilities.

## What the results mean for a shortlist

- The choice of rule decided which counties were listed, and the published uncertainty decided how firm each list is. At 25 counties, the prevalence and burden lists share none of their 51 counties. Choose the rule that matches the program's aim and say so.
- A prevalence top 25 cannot be identified from these estimates. No county is core, and 346 counties could be in the top 25. Treat the boundary set as the pool for further review.
- A burden list is more stable: 17 of 25 counties are core.
- Kentucky and Pennsylvania have no diagnosed-diabetes estimates in this release and are not ranked. Users in those states need another source.

## Local information needed before acting

None of the following is in these tables, and none was collected for this project. Each would need to come from local partners or other sources:

1. Existing diabetes self-management education and support programs, National Diabetes Prevention Program sites and lifestyle programs, with their current capacity and waiting lists.
2. Primary care, endocrinology, pharmacy and community health worker capacity, including federally qualified health centers and tribal health programs.
3. Health insurance coverage and payer support for diabetes education and prevention programs.
4. Transportation, broadband and language access that affect who can reach a program.
5. More recent local data, such as electronic health record or hospital discharge summaries, that could confirm or contradict the 2023 model-based estimates.
6. Community priorities, trusted organizations and existing coalitions, gathered with the communities concerned.
7. Current county and state program plans, so that outreach adds to existing work rather than duplicating it.

## How to read a county row

The [priority tables](../dashboard.html) and the [county CSV](county_priority_table.csv) name the release, the measure and the population and poverty sources. Each row gives the crude prevalence with its 95% interval, the adult population and estimated burden with scenario bounds, the ACS 2020-2024 poverty estimate with its 95% bounds, and for each rule the point rank, best-case and worst-case rank, and core, boundary or outside label. Very small counties have wide intervals. Kalawao County, Hawaii, with 75 adults, ranks 23 by prevalence but could rank as low as 395.
