# Tableau import and interaction specification

No Tableau workbook was built or tested for this project. This specification describes how to connect the verified CSV exports so that a Tableau view shows the same numbers as the analysis tables. It was written against the files listed below. Any view built from it should be checked against `outputs/tables/envelope_summary.csv` and `outputs/tables/rule_overlap.csv`.

## Files and grain

| File | Grain (one row per) | Use |
|---|---|---|
| `outputs/tables/priority_long.csv` | county x rule x national capacity | Main ranked table and filters |
| `outputs/tables/within_state_long.csv` | county x rule (capacity 5 within its state) | State view |
| `outputs/tables/county_priority_table.csv` | county | Tooltips and county detail |
| `outputs/tables/envelope_summary.csv` | rule x capacity | Summary bars (Figure 2) |
| `outputs/tables/rule_overlap.csv` | capacity x scenario x rule pair | Overlap view |
| `outputs/tables/selection_profile.csv` | rule x capacity | Estimated burden contained in each selection |

Join `priority_long.csv` to `county_priority_table.csv` on `fips` (text, five characters with leading zeros). Set the field type to String before joining. The join is many-to-one. Any other cardinality means the wrong files were used.

## Fields, units and labels

- `display_name`: Census name including the type of area (for example Baltimore city, Baltimore County, Tensas Parish). Use it for labels. The `county_name` field from PLACES does not distinguish independent cities from same-named counties.
- `value`: crude prevalence in percent for PREV and EQUITY, and estimated adults with diagnosed diabetes (persons) for BURDEN. Do not put both on one axis.
- `lo`, `hi`: PLACES 95% limits (percent) for PREV and EQUITY, and scenario bounds (persons) for BURDEN. The burden bounds are not confidence intervals.
- `point_rank`, `best_rank`, `worst_rank`: competition ranks within the national frame (or within the state in the state file). Ties share the better rank.
- `envelope_status`: core, boundary or outside at the row's capacity.
- `eligible_point`, `eligible_certain`, `eligible_possible`: ACS 2020-2024 poverty of at least 20% at the estimate, the 95% lower bound and the 95% upper bound.
- `pov`: percent of people below the poverty level, ACS 2020-2024.
- `acs2024_pov_lo95`, `acs2024_pov_hi95`: 95% bounds for `pov`.
- Every view must show the caption: "CDC PLACES County Data, 2025 release (BRFSS 2023), Census Vintage 2023 estimates and ACS 2020-2024. Kentucky and Pennsylvania are not included."

## Permitted filters and calculations

- Filter by `rule`, `capacity`, `state_abbr` and `envelope_status`. These select precomputed rows and do not change any value.
- Do not recompute ranks, core or boundary labels after filtering a subset of counties. Ranks are defined on the full national frame (or the full state in the state file). For a state view use `within_state_long.csv`, not a filtered national table.
- Do not average prevalence across counties. A group prevalence must be the sum of estimated burden divided by the sum of adult population, and it inherits no published interval.
- Do not sum `lo` or `hi` across counties. The bounds are marginal and do not add.
- Suppression: Loving County, Texas is absent (suppressed by PLACES because its population is under 50). Kentucky and Pennsylvania are absent (no diagnosed-diabetes estimates released). Show them as "not available", never as zero.

## Suggested views

1. Summary: bars of `n_core` and `n_boundary` by rule and capacity from `envelope_summary.csv`, with a reference line at the capacity.
2. Ranked table: `priority_long.csv` filtered to one rule and capacity, sorted by `point_rank`, showing value with interval, best to worst rank and status.
3. State view: `within_state_long.csv` filtered to one state.
