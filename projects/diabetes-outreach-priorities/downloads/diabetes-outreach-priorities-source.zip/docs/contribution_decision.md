# Contribution decision

Written 2026-10-07, after the literature and tool search (docs/literature_search_log.md, docs/prior_art.csv) and after the analysis plan (docs/analysis_plan.md), before any county ranking was computed.

## Who could use the output

Analysts in state and local health departments, community health organizations and diabetes prevention or self-management programs who must decide which counties to examine first when resources for outreach are limited.

## Decision it supports

Which counties to shortlist for a closer local assessment of unmet diabetes outreach need. The output does not allocate services. Acting on a shortlist would still require local information on existing programs, clinical capacity, partners and community priorities (docs/planning_brief.md).

## Narrow unresolved question

When counties are shortlisted from public small-area estimates at a fixed capacity, how much does the shortlist depend on (a) the definition of need, comparing crude prevalence, estimated number of adults with diagnosed diabetes, and prevalence restricted to high-poverty counties, and (b) the published uncertainty of the PLACES and ACS inputs?

## Comparator

The common practice of ranking or thresholding PLACES point estimates of prevalence, such as a top-quartile cutoff (Probst et al. 2024) or a fixed prevalence threshold (Barker et al. 2011). In this study the comparator is the point-estimate prevalence top-K list.

## Estimand

For each rule and capacity K: the point-estimate selected set; pairwise Jaccard overlap between rules; and the numbers of counties that stay selected anywhere inside the published bounds (core) or could enter or leave the selection within those bounds (boundary). These are deterministic descriptions of the published estimates. They are not probabilities that a county belongs in the top group.

## What is already established

- Uncertainty in rankings is a known problem with mature methods: league-table critiques (Goldstein and Spiegelhalter 1996; Marshall and Spiegelhalter 1998), joint confidence regions for rankings (Klein, Wright and Wieczorek 2020), confidence sets for ranks and for the best units (Mogstad et al. 2024), and ranking and selection under hierarchical models (Henderson and Newton 2016).
- County health rankings are unstable when uncertainty is considered (Arndt et al. 2013; Athens et al. 2013; Courtemanche, Soneji and Tchernis 2015).
- PLACES estimates are used to target counties and to combine prevalence with social vulnerability and counts of affected adults (Carlson et al. 2023; Probst et al. 2024), usually without interval-based sensitivity analysis.

## What this project adds

I did not identify a study that compares which U.S. counties are selected for diabetes outreach under prevalence, count and poverty-restricted definitions while carrying the published PLACES intervals and ACS sampling errors into the selection. The contribution is therefore an applied decision-sensitivity analysis of current public data together with a reusable priority-table generator. It is not a new statistical method: the envelope uses the interval-counting logic of Klein, Wright and Wieczorek with marginal intervals and is labeled a sensitivity envelope because it carries no joint coverage guarantee.

Specific incremental value:

1. A measured answer, for the 2025 PLACES release, to how much the three common need definitions disagree at capacities of 10, 25 and 50 counties and within states.
2. County-level labels separating selections that hold across the published bounds from those that depend on where estimates fall inside their intervals.
3. A documented consequence of the 2025 release's missing Kentucky and Pennsylvania estimates, using the 2024 release descriptively.
4. Open code, tables, a workbook and a static dashboard that an analyst can rerun when PLACES or ACS releases change.

The project does not claim to be first, does not produce new prevalence estimates, and does not evaluate programs.

## Useful negative result

If the core sets are empty or very small and the three rules share few counties, the useful conclusion is that a single top-K list from point estimates should not be presented as the answer. Planners would then be better served by the union of core and boundary counties under the definitions they care about, followed by local assessment. That conclusion would be reported as the main finding, not hidden.

## Framing choices

- The third perspective is described as a declared high-poverty criterion (ACS poverty of at least 20 percent), with prevalence ranking inside that group. The threshold is a planning choice, not an optimal weight.
- One paper reports one analysis. Within-state results, alternate capacities and the aligned subset are supplementary views of the same prespecified analysis, not separate studies.
