# Analysis plan

Written 2026-10-07 09:39 UTC (05:39 EDT), before any county prevalence, burden or poverty value was ranked, sorted or compared. This is an internal, timestamped plan kept with the project files. It is not a formal preregistration in a public registry. Any later change is recorded in the amendments section at the end with its own timestamp and reason.

## Prior exposure

Before writing this plan I had general background knowledge that diagnosed diabetes prevalence in the United States is highest in parts of the Southeast and Appalachia, and that counts of affected adults are dominated by populous counties. I inspected the structure of the acquired files only: column names, measure and value-type labels, row counts by measure and state, geography codes (Connecticut planning regions, Alaska Chugach and Copper River, the national row with LocationID 59), suppression footnotes, ACS replicate-table line titles, and which ACS cells are population-controlled. That inspection showed that the PLACES 2025 county release contains no diagnosed-diabetes estimates for Kentucky (120 counties) or Pennsylvania (67 counties) and that Loving County, Texas is suppressed. I did not look at any county's prevalence, burden or poverty value, any ranking, or any association between variables.

## Question

Which U.S. counties would a community-program analyst shortlist for further investigation of diabetes outreach need under three common definitions of need, and how much of each shortlist is stable when the published uncertainty of the inputs is made explicit?

The output supports a decision about where to look more closely. It does not allocate services, evaluate programs, or describe any individual's risk.

## Unit, frame and sources

- Unit: county or county equivalent in the 50 states and the District of Columbia, using the 2023 geography of the PLACES 2025 county release (Connecticut's nine planning regions, Alaska's Chugach and Copper River census areas).
- Prevalence: CDC PLACES County Data, 2025 release (Socrata dataset swc5-untb), measure DIABETES ("Diagnosed diabetes among adults"), value type CrdPrv ("Crude prevalence"), BRFSS 2023, with its published 95% confidence limits. Age-adjusted prevalence is carried for display only and is never multiplied by a population.
- Adult population (primary): TotalPop18plus in the PLACES 2025 file, documented as the Census 2023 county population estimate for ages 18 and over. It is checked against the Census Bureau Vintage 2023 county characteristics file (CC-EST2023-AGESEX, YEAR = 5, AGE18PLUS_TOT).
- Adult population (comparison and scenario range): ACS 2020-2024 five-year table B05003, male 18 years and over (line 8) plus female 18 years and over (line 19), with a margin of error computed from the 80 published variance replicates.
- Socioeconomic criterion: ACS 2020-2024 five-year table B17001, people below the poverty level (line 2) divided by the population for whom poverty status is determined (line 1), times 100, with a replicate-based margin of error.
- The Census Data API now requires a key, which this project does not use. ACS values therefore come from the Census Bureau's public variance replicate files, which contain the published estimates and margins of error for these lines.

Common analysis frame: counties with a non-suppressed crude prevalence and both confidence limits, a positive PLACES adult population, an ACS adult estimate, and an ACS poverty estimate. All three rules are evaluated on this same frame so that selected sets are comparable. Every location absent from the frame is listed with a reason code.

## Planning perspectives (rules)

All rankings are descending. Ties use competition ranking: a county's rank is 1 plus the number of frame counties with a strictly larger value. A county is selected at capacity K when its rank is at most K, so ties at the cutoff are all included and the selected set can exceed K. The set size is always reported.

1. Prevalence rule (PREV): rank by crude prevalence.
2. Estimated burden rule (BURDEN): rank by estimated adults with diagnosed diabetes, defined as crude prevalence / 100 times the PLACES adult population. This is a model-based estimate, not a count of identified patients.
3. Equity-sensitive rule (EQUITY): restrict to counties with ACS poverty of at least 20.0 percent (the high-poverty county threshold used by USDA Economic Research Service), then rank by crude prevalence. Estimated burden is displayed alongside but does not enter the ranking. The 20 percent threshold is a declared planning criterion, not an empirically optimal weight.

No composite need score is constructed. No regression of prevalence on socioeconomic variables is fitted, because the PLACES model may already use related covariates and any such association would not be an independent finding.

## Capacities

- National capacities: 10, 25 and 50 counties. The primary capacity is 25; 10 and 50 form the alternate-capacity robustness check. These are illustrative, not organizational budgets.
- Within-state capacity: 5 counties per state. Where a state or DC has 5 or fewer frame counties, all of its units are shown and labelled "all units, no selection" and the state is excluded from within-state stability summaries. Where fewer than 5 counties in a state meet the poverty criterion, all eligible counties are selected under EQUITY and the shortfall is reported.

## Uncertainty: deterministic envelopes, not probabilities

PLACES publishes marginal 95% intervals per county. There is no joint distribution, and county estimates share model structure and covariates. No independent draws are simulated, and no county is assigned a probability of belonging to a top group.

For a rule with value v and scenario bounds [L, U] for each county i in the ranking set:

- Best-case rank b_i = 1 + #{j : L_j > U_i}.
- Worst-case rank w_i = 1 + #{j != i : U_j > L_i}.
- At capacity K: core if w_i <= K (selected wherever every county falls inside its bounds); boundary if b_i <= K < w_i; outside if b_i > K.

The worst case places every other county at its upper bound and county i at its lower bound at the same time. Such combinations are not jointly attainable confidence statements, so the envelope is labelled a sensitivity envelope.

Bounds per rule:

- PREV: PLACES 95% lower and upper limits.
- BURDEN: lower = prevalence lower limit / 100 times the smaller of the PLACES adult population and the ACS 95% lower adult bound; upper = prevalence upper limit / 100 times the larger of the PLACES adult population and the ACS 95% upper adult bound. ACS 90% margins are rescaled to 95% (factor 1.959964 / 1.645). This product of bounds is a scenario range. It is not a confidence interval, because the covariance between the model-based prevalence and the population estimates is unknown.
- EQUITY: prevalence bounds as in PREV. Poverty eligibility is classified as certain (95% lower poverty bound at or above 20), point (estimate at or above 20) or possible (95% upper bound at or above 20). Best-case rank counts only certainly eligible competitors with L_j > U_i; worst-case rank counts all possibly eligible competitors with U_j > L_i. A county is core only if it is certainly eligible and w_i <= K, boundary if it is possibly eligible with b_i <= K and not core, and outside otherwise.

Scenario rankings, also reported as selected sets: point estimates; all counties at lower bounds; all counties at upper bounds; and for EQUITY, the certain-eligibility and possible-eligibility frames ranked by point prevalence.

## Primary outputs

1. Pairwise Jaccard overlap (|A and B| / |A or B|) of the point-estimate selected sets for PREV, BURDEN and EQUITY at K = 25, plus intersection counts.
2. For each rule at K = 25: numbers of core, boundary and point-selected counties.
3. Rule dependence for each county selected under any rule at K = 25: rule-robust if selected under all three rules, rule-dependent if selected under exactly one, and strongly rule-dependent if core under one rule and outside under another.

The stable core is reported per rule. A cross-rule core (core under all three rules) is reported even if it is empty.

## Robustness checks (fixed set of three)

1. Alternate capacity: repeat all primary outputs at K = 10 and K = 50.
2. Point estimates versus interval-bound scenarios: Jaccard overlap between the point-estimate set and the lower-bound and upper-bound scenario sets within each rule, alongside the envelope classification.
3. Strictly aligned geography and reference period: restrict to counties whose 5-digit FIPS codes appear in PLACES 2025, the Vintage 2023 estimates and both ACS vintages, excluding Connecticut, whose county equivalents changed after the 2020 Census tabulation geography. Use ACS 2019-2023 (the ACS vintage named in the PLACES 2025 documentation) for poverty and the ACS adult range. Report Jaccard overlap with the primary sets.

Optional descriptive comparison: the PLACES 2024 county release (BRFSS 2022), which includes Kentucky and Pennsylvania, ranked by the same PREV and BURDEN rules. Report (a) overlap with the 2025 selected sets among counties present in both releases, and (b) how many Kentucky and Pennsylvania counties the 2024 release would place in the national top K. This describes the consequence of the 2025 coverage gap. It is not validation against outcomes, and the two releases differ in survey year and model inputs.

## Validation and checks

- Software tests on small synthetic fixtures (ranking with ties, envelopes, eligibility logic, acquisition guards, build checks). Fixtures are labelled synthetic and never mixed with study data.
- Source reconciliation: PLACES adult population against the Census Vintage 2023 file (expected to match exactly); ACS adult estimate against the PLACES adult population (expected close but not identical because of reference period and sampling).
- Build checks that fail loudly: one row per county, measure and value type; DIABETES rows from a single year; crude and age-adjusted labels mapped one to one; confidence limits bracket the estimate; 5-digit string FIPS with leading zeros; one ACS row per county and line; no Puerto Rico or other territories in the frame.
- Invariants: core is a subset of the point-selected set, which is a subset of core plus boundary.
- A second implementation in base R recomputes burden, ranks, selections and envelope ranks from the analysis frame. Agreement is a software cross-check, not independent scientific validation.
- Deterministic stages are rerun from cached inputs and compared with relative tolerance 1e-12 and absolute tolerance 1e-9.

## Missing data and status vocabulary

No values are imputed. Status codes: observed; suppressed (PLACES footnote, population under 50); measure_not_released_for_state (Kentucky and Pennsylvania in the 2025 release); national_aggregate (LocationID 59); not_in_source; territory; controlled (ACS estimate with no sampling error); moe_zero_not_controlled (flagged and reported if it occurs). A zero value is never used to stand for a missing one.

## What would count as a useful negative result

If the stable core at K = 25 is empty or very small for every rule, or the three rules share almost no counties, that is a reportable finding: published uncertainty and the choice of need definition would then dominate any single ranked list, and a planner should treat the boundary set, not a top-25 list, as the unit of further investigation.

## Exposure log (not amendments)

- 2026-10-07, after the plan above was written and before any ranking was run: while the file formats were being documented, a few individual values were displayed (PLACES crude prevalence for Kusilvak Census Area, AK, and Kalawao County, HI; ACS B17001 counts for Montgomery and Prince George's counties, MD; Census Vintage 2023 adult totals for Montgomery and Prince George's counties and the Capitol Planning Region, CT). No rule, threshold, capacity or scenario was changed as a result.

## Amendments

1. 2026-10-07, after the primary results were produced: added a descriptive table (outputs/tables/selection_profile.csv) that summarizes each point-estimate selected set by its total estimated burden, share of the frame's total estimated burden, adult population range, prevalence range, number of high-poverty counties and number of states. It was added because the overlap results raised the question of how much estimated burden each rule's selection contains. It does not change any rule, capacity, scenario or classification, and it is reported as descriptive context rather than as a prespecified outcome.
2. 2026-10-07, after the primary results were produced: the optional comparison with the PLACES 2024 release was extended from the prevalence and burden rules to the high-poverty rule, using the same ACS 2020-2024 poverty criterion as the primary analysis so that the comparison reflects only the change of PLACES release. It is reported as descriptive and does not change any primary result.
3. 2026-10-07, after the primary results were produced (a correction of wording, not of the analysis): the structure inspection described under Prior exposure was carried out with a script that listed column names, labels, row counts, geography codes, footnotes and line titles, and this plan was fixed at the timestamp given at the top. No rule, threshold, capacity, scenario or classification changed.
