Summary tables for the county diabetes outreach priorities study.
Sources: CDC PLACES County Data, 2025 release (BRFSS 2023), data.cdc.gov swc5-untb. Crude prevalence of diagnosed diabetes among adults aged 18+, percent, with 95% limits. Census Bureau Vintage 2023 county estimate, ages 18+ (PLACES TotalPop18plus). ACS 2020-2024 5-year, percent below poverty level (B17001), 95% bounds from replicates.
Kentucky and Pennsylvania have no diagnosed-diabetes estimates in the PLACES 2025 release.
Column definitions are in data_dictionary.csv. Rule codes: PREV = prevalence, BURDEN = estimated burden and EQUITY = high-poverty prevalence.
