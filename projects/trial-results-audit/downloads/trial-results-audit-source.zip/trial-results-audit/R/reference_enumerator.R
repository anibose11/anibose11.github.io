# Independent raw-JSON reference for ETL fidelity (separate from the Python/SQL warehouse code).
#
# Reads the same raw API pages and, for each study in scope, writes:
#   leaves.copy        every scalar under resultsSection: nct_id, JSON pointer, JSON type, value text
#                      (values under excluded subtrees such as the point of contact are redacted, not copied)
#   objects.copy       count of objects per path pattern (indices replaced by *)
#   measurement_tiers.copy  tier, rule, participant and unit denominator per outcome measurement (docs/rules.md)
#   group_tiers.copy   tier and rules per outcome group
#   reference_summary.json
# Files use PostgreSQL COPY text format (tab separated, backslash escapes, \N for null).
#
# Usage: Rscript --vanilla reference_enumerator.R <raw_dir> <manifest.csv> <splits> <out_dir> <snapshot_id>

suppressPackageStartupMessages(library(jsonlite))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 5) stop("usage: reference_enumerator.R <raw_dir> <manifest.csv> <splits> <out_dir> <snapshot_id>")
raw_dir <- args[[1]]; manifest_path <- args[[2]]; splits <- strsplit(args[[3]], ",")[[1]]
out_dir <- args[[4]]; snapshot_id <- args[[5]]
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

EXCLUDED_PREFIXES <- c("/resultsSection/moreInfoModule/pointOfContact", "/resultsSection/moreInfoModule/certainAgreement")

manifest <- read.csv(manifest_path, colClasses = "character", na.strings = character(0))
in_scope <- manifest$nct_id[manifest$split %in% splits]

copy_escape <- function(x) {
  out <- ifelse(is.na(x), "\\N", x)
  idx <- !is.na(x)
  out[idx] <- gsub("\\", "\\\\", out[idx], fixed = TRUE)
  out[idx] <- gsub("\t", "\\t", out[idx], fixed = TRUE)
  out[idx] <- gsub("\n", "\\n", out[idx], fixed = TRUE)
  out[idx] <- gsub("\r", "\\r", out[idx], fixed = TRUE)
  out
}

ptr_escape <- function(k) gsub("/", "~1", gsub("~", "~0", k, fixed = TRUE), fixed = TRUE)

scalar_text <- function(v) {
  if (is.logical(v)) return(if (v) "true" else "false")
  if (is.numeric(v)) {
    # Integer-valued numbers (all JSON numbers in the results section are counts) as plain digits, any size below 2^53.
    if (is.finite(v) && v == round(v) && abs(v) < 2^53) return(sprintf("%.0f", v))
    for (d in 15:17) {
      txt <- format(v, digits = d, scientific = FALSE, trim = TRUE)
      if (as.numeric(txt) == v) return(txt)
    }
    return(txt)
  }
  as.character(v)
}

is_excluded <- function(pointer) any(pointer == EXCLUDED_PREFIXES | startsWith(pointer, paste0(EXCLUDED_PREFIXES, "/")))

scalar_type <- function(v) {
  if (is.logical(v)) "boolean" else if (is.numeric(v)) "number" else "string"
}

pattern_of <- function(pointer) gsub("/[0-9]+(?=/|$)", "/*", pointer, perl = TRUE)

# Enumerate scalars. Arrays and objects both come back as R lists; arrays have no names.
# Each call returns list(p, t, v) for its subtree, so no growing list is copied repeatedly.
enumerate_leaves <- function(node, pointer) {
  if (is.list(node)) {
    if (length(node) == 0) return(NULL)
    nm <- names(node)
    keys <- if (is.null(nm)) as.character(seq_along(node) - 1L) else ptr_escape(nm)
    parts <- lapply(seq_along(node), function(i) enumerate_leaves(node[[i]], paste0(pointer, "/", keys[[i]])))
    parts <- parts[!vapply(parts, is.null, logical(1))]
    if (length(parts) == 0) return(NULL)
    return(list(p = unlist(lapply(parts, `[[`, "p"), use.names = FALSE),
                t = unlist(lapply(parts, `[[`, "t"), use.names = FALSE),
                v = unlist(lapply(parts, `[[`, "v"), use.names = FALSE)))
  }
  if (is_excluded(pointer)) return(list(p = pointer, t = "excluded", v = NA_character_))
  if (is.null(node)) return(list(p = pointer, t = "null", v = NA_character_))
  list(p = pointer, t = scalar_type(node), v = scalar_text(node))
}

# Count array elements per path pattern (indices replaced by *).
count_arrays <- function(node, pointer, counter) {
  if (!is.list(node)) return(invisible(NULL))
  nm <- names(node)
  if (is.null(nm)) {
    pat <- paste0(pattern_of(pointer), "/*")
    counter[[pat]] <- (if (is.null(counter[[pat]])) 0L else counter[[pat]]) + length(node)
    for (i in seq_along(node)) count_arrays(node[[i]], paste0(pointer, "/", i - 1L), counter)
  } else {
    for (k in nm) count_arrays(node[[k]], paste0(pointer, "/", ptr_escape(k)), counter)
  }
  invisible(NULL)
}

# Trim spaces, tabs, CR and LF at both ends (trimws default set) and fold ASCII letters only, matching the SQL view.
ascii_lower <- function(x) chartr("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz", x)
norm_unit <- function(u) if (is.null(u)) "" else ascii_lower(trimws(u))
usable_int <- function(txt) !is.null(txt) && is.character(txt) && grepl("^[0-9]+$", txt) && as.numeric(txt) <= 2147483647

# Collect count texts covering group g in denominators with normalized unit u.
covering <- function(denoms, g, u) {
  vals <- character(0); ptrs <- character(0)
  for (d in denoms) {
    if (norm_unit(d$units) != u) next
    for (cn in d$counts) if (identical(cn$groupId, g)) vals <- c(vals, if (is.null(cn$value)) NA_character_ else cn$value)
  }
  vals
}

single_usable <- function(vals) if (length(vals) == 1 && !is.na(vals[[1]]) && usable_int(vals[[1]])) as.integer(vals[[1]]) else NA_integer_

tier_rank <- c(A = 1L, B = 2L, C = 3L, D = 0L)

reference_tiers <- function(nct, study, mrows, grows) {
  oms <- study$resultsSection$outcomeMeasuresModule$outcomeMeasures
  if (is.null(oms)) return(list(m = mrows, g = grows))
  for (oi in seq_along(oms)) {
    o <- oms[[oi]]
    posted <- identical(o$reportingStatus, "POSTED")
    dus <- if (is.null(o$denomUnitsSelected) || trimws(o$denomUnitsSelected) == "") "Participants" else trimws(o$denomUnitsSelected)
    # (posted is used for both measurement tiers and group tiers)
    u <- norm_unit(dus); unit_p <- u == "participants"
    classes <- if (is.null(o$classes)) list() else o$classes
    row_mode <- any(vapply(classes, function(cl) length(cl$denoms) > 0, logical(1)))
    group_tiers <- list()
    for (ci in seq_along(classes)) {
      cl <- classes[[ci]]
      cats <- if (is.null(cl$categories)) list() else cl$categories
      for (ti in seq_along(cats)) {
        ms <- if (is.null(cats[[ti]]$measurements)) list() else cats[[ti]]$measurements
        for (vi in seq_along(ms)) {
          g <- if (is.null(ms[[vi]]$groupId)) NA_character_ else ms[[vi]]$groupId
          pden <- NA_integer_; uden <- NA_integer_
          if (!posted) {
            tier <- "D"; rule <- "D_NOT_POSTED"
          } else if (row_mode) {
            cds <- if (is.null(cl$denoms)) list() else cl$denoms
            uden <- single_usable(covering(cds, g, u))
            if (length(cds) == 0) { tier <- "C"; rule <- "C4_PARTIAL_ROW_DENOMINATORS"
            } else if (!any(vapply(cds, function(d) norm_unit(d$units) == "participants", logical(1)))) {
              tier <- "C"; rule <- "C5_ROW_DENOMINATORS_NOT_IN_PARTICIPANTS"
            } else {
              vals <- covering(cds, g, "participants")
              if (length(vals) == 0) { tier <- "C"; rule <- "C1_NO_PARTICIPANT_COUNT"
              } else if (length(vals) > 1) { tier <- "C"; rule <- "C3_DUPLICATE_UNIT_ENTRIES"
              } else if (!usable_int(vals[[1]])) { tier <- "C"; rule <- "C2_NON_INTEGER_COUNT"
              } else if (!unit_p && is.na(uden)) { tier <- "C"; rule <- "C6_SELECTED_UNIT_NOT_REPORTED"
              } else { tier <- "B"; rule <- "B1_ROW_SPECIFIC_DENOMINATOR"; pden <- as.integer(vals[[1]]) }
            }
          } else {
            ods <- if (is.null(o$denoms)) list() else o$denoms
            uden <- single_usable(covering(ods, g, u))
            vals <- covering(ods, g, "participants")
            if (length(vals) == 0) { tier <- "C"; rule <- "C1_NO_PARTICIPANT_COUNT"
            } else if (length(vals) > 1) { tier <- "C"; rule <- "C3_DUPLICATE_UNIT_ENTRIES"
            } else if (!usable_int(vals[[1]])) { tier <- "C"; rule <- "C2_NON_INTEGER_COUNT"
            } else if (!unit_p && is.na(uden)) { tier <- "C"; rule <- "C6_SELECTED_UNIT_NOT_REPORTED"
            } else if (unit_p) { tier <- "A"; rule <- "A_OUTCOME_LEVEL"; pden <- as.integer(vals[[1]])
            } else { tier <- "B"; rule <- "B2_NON_PARTICIPANT_UNITS"; pden <- as.integer(vals[[1]]) }
          }
          mrows$n <- mrows$n + 1L
          mrows$rows[[mrows$n]] <- c(nct, oi - 1L, ci - 1L, ti - 1L, vi - 1L, g, tier, rule,
                                     if (is.na(pden)) NA_character_ else as.character(pden),
                                     if (is.na(uden)) NA_character_ else as.character(uden))
          key <- if (is.na(g)) "<missing>" else g
          prev <- group_tiers[[key]]
          if (is.null(prev)) group_tiers[[key]] <- list(tier = tier, rules = rule)
          else group_tiers[[key]] <- list(tier = if (tier_rank[[tier]] > tier_rank[[prev$tier]]) tier else prev$tier,
                                          rules = sort(unique(c(prev$rules, rule))))
        }
      }
    }
    for (gr in (if (is.null(o$groups)) list() else o$groups)) {
      gid <- gr$id
      gt <- group_tiers[[gid]]
      if (!posted) { tier <- "D"; rules <- "D_NOT_POSTED"
      } else if (is.null(gt)) { tier <- "D"; rules <- "D_NO_MEASUREMENTS"
      } else { tier <- gt$tier; rules <- paste(sort(gt$rules), collapse = "|") }
      grows$n <- grows$n + 1L
      grows$rows[[grows$n]] <- c(nct, oi - 1L, gid, tier, rules)
    }
  }
  list(m = mrows, g = grows)
}

state <- fromJSON(file.path(raw_dir, "retrieval_state.json"), simplifyVector = FALSE)
batch_keys <- sort(names(state$batches))

# Outputs are written as UTF-8 bytes through binary connections, independent of the session locale.
leaf_con <- file(file.path(out_dir, "leaves.copy"), open = "wb")
obj_rows <- list(); mrows <- new.env(); mrows$n <- 0L; mrows$rows <- list()
grows <- new.env(); grows$n <- 0L; grows$rows <- list()
n_studies <- 0L; n_leaves <- 0L
leaves_by_module <- list()

for (key in batch_keys) {
  page <- fromJSON(file.path(raw_dir, state$batches[[key]]$file), simplifyVector = FALSE)
  for (study in page$studies) {
    nct <- study$protocolSection$identificationModule$nctId
    if (!(nct %in% in_scope)) next
    n_studies <- n_studies + 1L
    leaves <- if (is.null(study$resultsSection)) NULL else enumerate_leaves(study$resultsSection, "/resultsSection")
    if (!is.null(leaves)) {
      writeLines(enc2utf8(paste(snapshot_id, nct, copy_escape(leaves$p), leaves$t, copy_escape(leaves$v), sep = "\t")), leaf_con,
                 useBytes = TRUE)
      n_leaves <- n_leaves + length(leaves$p)
      mods <- sub("^/resultsSection/([^/]+).*$", "\\1", leaves$p)
      for (m in unique(mods)) leaves_by_module[[m]] <- (if (is.null(leaves_by_module[[m]])) 0 else leaves_by_module[[m]]) + sum(mods == m)
    }
    counter <- new.env()
    if (!is.null(study$resultsSection)) count_arrays(study$resultsSection, "/resultsSection", counter)
    for (pat in ls(counter)) obj_rows[[length(obj_rows) + 1L]] <- c(snapshot_id, nct, pat, counter[[pat]])
    res <- reference_tiers(nct, study, mrows, grows)
  }
}
close(leaf_con)

write_copy <- function(rows, path, prefix = snapshot_id) {
  con <- file(path, open = "wb")
  if (length(rows) > 0) {
    lines <- vapply(rows, function(r) paste(copy_escape(c(prefix, as.character(r))), collapse = "\t"), character(1))
    writeLines(enc2utf8(lines), con, useBytes = TRUE)
  }
  close(con)
}
con <- file(file.path(out_dir, "objects.copy"), open = "wb")
if (length(obj_rows) > 0) writeLines(enc2utf8(vapply(obj_rows, function(r) paste(copy_escape(r), collapse = "\t"), character(1))), con,
                                     useBytes = TRUE)
close(con)
write_copy(if (mrows$n > 0) mrows$rows[seq_len(mrows$n)] else list(), file.path(out_dir, "measurement_tiers.copy"))
write_copy(if (grows$n > 0) grows$rows[seq_len(grows$n)] else list(), file.path(out_dir, "group_tiers.copy"))

mt <- if (mrows$n > 0) vapply(mrows$rows[seq_len(mrows$n)], function(r) r[[7]], character(1)) else character(0)
gt <- if (grows$n > 0) vapply(grows$rows[seq_len(grows$n)], function(r) r[[4]], character(1)) else character(0)
summary <- list(
  snapshot_id = snapshot_id, splits = splits, n_studies = n_studies, n_leaves = n_leaves,
  leaves_by_module = leaves_by_module,
  measurement_tiers = as.list(table(mt)), group_tiers = as.list(table(gt)),
  r_version = R.version.string, jsonlite_version = as.character(packageVersion("jsonlite"))
)
writeLines(toJSON(summary, auto_unbox = TRUE, pretty = TRUE), file.path(out_dir, "reference_summary.json"))
cat(sprintf("reference: %d studies, %d leaves\n", n_studies, n_leaves))
