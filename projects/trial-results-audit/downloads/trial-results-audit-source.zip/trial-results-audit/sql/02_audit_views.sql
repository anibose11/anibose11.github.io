-- Audit layer: denominator association tiers, checks, evidence table, provenance explorer, issue ledger.
-- Implements docs/rules.md. Every view keeps snapshot_id, nct_id and source JSON pointers.

create schema if not exists audit;

-- Trims spaces, tabs, carriage returns and line feeds at both ends (the same set as R's trimws).
create or replace function audit.trim_ws(t text) returns text
language sql immutable as $$ select regexp_replace(coalesce(t, ''), E'^[ \t\r\n]+|[ \t\r\n]+$', '', 'g') $$;

-- Unit names are compared after trim_ws and ASCII case folding (lower() folds only ASCII letters in the C locale).
create or replace function audit.norm_unit(u text) returns text
language sql immutable as $$ select lower(audit.trim_ws(u)) $$;

-- Used only for display (listing same-label groups); S7 itself uses exact title equality.
create or replace function audit.norm_title(t text) returns text
language sql immutable as $$ select lower(regexp_replace(audit.trim_ws(t), '\s+', ' ', 'g')) $$;

-- Both dispersion vocabularies (outcome display text and baseline enumeration codes) mapped to interval kinds.
create or replace function audit.interval_kind(d text) returns text
language sql immutable as $$
  select case
    when d ~* '^\s*\d+(\.\d+)?\s*%\s*confidence interval\s*$' or d ~ '^CONFIDENCE_' then 'confidence'
    when d ~* '^\s*inter[- ]?quartile range\s*$' or d = 'INTER_QUARTILE_RANGE' then 'iqr'
    when d ~* '^\s*full range\s*$' or d = 'FULL_RANGE' then 'full_range'
    else null end
$$;

-- Filled by the analyze stage from leaf-level reconciliation against the R reference.
create table if not exists audit.transformation_defect (
    snapshot_id text not null, nct_id text not null, pointer text not null, defect_kind text not null,
    reference_value text, warehouse_value text,
    primary key (snapshot_id, nct_id, pointer, defect_kind)
);

-- ---------------------------------------------------------------- outcome context
create or replace view audit.v_outcome_context as
select o.snapshot_id, o.nct_id, o.outcome_ordinal, o.reporting_status, o.type as outcome_type, o.title as outcome_title,
       o.time_frame, o.param_type, o.dispersion_type, o.unit_of_measure,
       coalesce(nullif(audit.trim_ws(o.denom_units_selected), ''), 'Participants') as analysis_unit,
       audit.norm_unit(coalesce(nullif(audit.trim_ws(o.denom_units_selected), ''), 'Participants')) = 'participants' as unit_is_participants,
       exists (select 1 from ctr.outcome_class_denom cd
               where cd.snapshot_id = o.snapshot_id and cd.nct_id = o.nct_id and cd.outcome_ordinal = o.outcome_ordinal) as row_specific_mode,
       nullif(audit.trim_ws(o.population_description), '') is not null as population_description_present,
       o.population_description, o.source_pointer as outcome_pointer
from ctr.outcome_measure o;

create or replace view audit.v_outcome_counts as
select c.snapshot_id, c.nct_id, c.outcome_ordinal, c.group_id, audit.norm_unit(d.units) as unit_norm,
       count(*) as n_entries, min(c.value_text) as value_text, min(c.value_int) as value_int,
       bool_and(c.value_int is not null) as all_usable,
       string_agg(c.source_pointer, ' ' order by c.source_pointer) as pointers
from ctr.outcome_denom d
join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
group by 1, 2, 3, 4, 5;

create or replace view audit.v_class_counts as
select c.snapshot_id, c.nct_id, c.outcome_ordinal, c.class_ordinal, c.group_id, audit.norm_unit(d.units) as unit_norm,
       count(*) as n_entries, min(c.value_text) as value_text, min(c.value_int) as value_int,
       bool_and(c.value_int is not null) as all_usable,
       string_agg(c.source_pointer, ' ' order by c.source_pointer) as pointers
from ctr.outcome_class_denom d
join ctr.outcome_class_denom_count c using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal)
group by 1, 2, 3, 4, 5, 6;

create or replace view audit.v_class_denom_units as
select snapshot_id, nct_id, outcome_ordinal, class_ordinal,
       count(*) as n_denoms, bool_or(audit.norm_unit(units) = 'participants') as has_participant_unit
from ctr.outcome_class_denom
group by 1, 2, 3, 4;

-- ---------------------------------------------------------------- measurement-level tiers (docs/rules.md)
create or replace view audit.v_measurement_denominator as
select m.snapshot_id, m.nct_id, m.outcome_ordinal, m.class_ordinal, m.category_ordinal, m.measurement_ordinal, m.group_id,
       oc.analysis_unit, oc.unit_is_participants, oc.row_specific_mode,
       r.tier, r.rule_id,
       case when r.tier in ('A', 'B') then r.participant_denominator end as participant_denominator,
       case when r.tier in ('A', 'B') then r.denominator_scope end as denominator_scope,
       r.denominator_pointer,
       case when oc.row_specific_mode
            then case when cuu.n_entries = 1 and cuu.all_usable then cuu.value_int end
            else case when ouu.n_entries = 1 and ouu.all_usable then ouu.value_int end end as unit_denominator,
       m.source_pointer as measurement_pointer
from ctr.outcome_measurement m
join audit.v_outcome_context oc using (snapshot_id, nct_id, outcome_ordinal)
left join audit.v_class_denom_units cu using (snapshot_id, nct_id, outcome_ordinal, class_ordinal)
left join audit.v_class_counts cp
       on cp.snapshot_id = m.snapshot_id and cp.nct_id = m.nct_id and cp.outcome_ordinal = m.outcome_ordinal
      and cp.class_ordinal = m.class_ordinal and cp.group_id = m.group_id and cp.unit_norm = 'participants'
left join audit.v_outcome_counts op
       on op.snapshot_id = m.snapshot_id and op.nct_id = m.nct_id and op.outcome_ordinal = m.outcome_ordinal
      and op.group_id = m.group_id and op.unit_norm = 'participants'
left join audit.v_class_counts cuu
       on cuu.snapshot_id = m.snapshot_id and cuu.nct_id = m.nct_id and cuu.outcome_ordinal = m.outcome_ordinal
      and cuu.class_ordinal = m.class_ordinal and cuu.group_id = m.group_id and cuu.unit_norm = audit.norm_unit(oc.analysis_unit)
left join audit.v_outcome_counts ouu
       on ouu.snapshot_id = m.snapshot_id and ouu.nct_id = m.nct_id and ouu.outcome_ordinal = m.outcome_ordinal
      and ouu.group_id = m.group_id and ouu.unit_norm = audit.norm_unit(oc.analysis_unit)
cross join lateral (
    select * from (values
        (case when oc.reporting_status is distinct from 'POSTED' then 'D'
              when oc.row_specific_mode then
              case when cu.n_denoms is null then 'C'
                   when not cu.has_participant_unit then 'C'
                   when cp.n_entries is null then 'C'
                   when cp.n_entries > 1 then 'C'
                   when not cp.all_usable then 'C'
                   when not oc.unit_is_participants and not coalesce(cuu.n_entries = 1 and cuu.all_usable, false) then 'C'
                   else 'B' end
         else
              case when op.n_entries is null then 'C'
                   when op.n_entries > 1 then 'C'
                   when not op.all_usable then 'C'
                   when not oc.unit_is_participants and not coalesce(ouu.n_entries = 1 and ouu.all_usable, false) then 'C'
                   when oc.unit_is_participants then 'A'
                   else 'B' end
         end,
         case when oc.reporting_status is distinct from 'POSTED' then 'D_NOT_POSTED'
              when oc.row_specific_mode then
              case when cu.n_denoms is null then 'C4_PARTIAL_ROW_DENOMINATORS'
                   when not cu.has_participant_unit then 'C5_ROW_DENOMINATORS_NOT_IN_PARTICIPANTS'
                   when cp.n_entries is null then 'C1_NO_PARTICIPANT_COUNT'
                   when cp.n_entries > 1 then 'C3_DUPLICATE_UNIT_ENTRIES'
                   when not cp.all_usable then 'C2_NON_INTEGER_COUNT'
                   when not oc.unit_is_participants and not coalesce(cuu.n_entries = 1 and cuu.all_usable, false)
                        then 'C6_SELECTED_UNIT_NOT_REPORTED'
                   else 'B1_ROW_SPECIFIC_DENOMINATOR' end
         else
              case when op.n_entries is null then 'C1_NO_PARTICIPANT_COUNT'
                   when op.n_entries > 1 then 'C3_DUPLICATE_UNIT_ENTRIES'
                   when not op.all_usable then 'C2_NON_INTEGER_COUNT'
                   when not oc.unit_is_participants and not coalesce(ouu.n_entries = 1 and ouu.all_usable, false)
                        then 'C6_SELECTED_UNIT_NOT_REPORTED'
                   when oc.unit_is_participants then 'A_OUTCOME_LEVEL'
                   else 'B2_NON_PARTICIPANT_UNITS' end
         end,
         case when oc.row_specific_mode then cp.value_int else op.value_int end,
         case when oc.row_specific_mode then 'class' else 'outcome' end,
         case when oc.row_specific_mode then cp.pointers else op.pointers end)
    ) as v(tier, rule_id, participant_denominator, denominator_scope, denominator_pointer)
) r;

-- Materialized copy of the measurement tiers, refreshed at the end of every warehouse load (tra.etl.load_snapshot).
-- Dependent views read this copy so the tier logic is evaluated once per load.
create materialized view if not exists audit.mv_measurement_denominator as
select * from audit.v_measurement_denominator with no data;
create unique index if not exists mv_measurement_denominator_key
    on audit.mv_measurement_denominator (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal);
create index if not exists mv_measurement_denominator_pointer
    on audit.mv_measurement_denominator (snapshot_id, nct_id, measurement_pointer);

-- ---------------------------------------------------------------- outcome-level structure summary
create or replace view audit.v_outcome_summary as
select oc.snapshot_id, oc.nct_id, oc.outcome_ordinal, oc.reporting_status, oc.outcome_type, oc.param_type,
       oc.analysis_unit, oc.unit_is_participants, oc.row_specific_mode, oc.population_description_present,
       coalesce(k.n_classes, 0) as n_classes, coalesce(k.max_categories, 0) as max_categories,
       coalesce(g.n_groups, 0) as n_groups, coalesce(mm.n_measurements, 0) as n_measurements,
       case when oc.reporting_status is distinct from 'POSTED' then 'not posted'
            when coalesce(mm.n_measurements, 0) = 0 then 'no measurements'
            when k.n_classes > 1 then 'multiple rows (classes)'
            when k.max_categories > 1 then 'categorical (one row, several categories)'
            else 'single row' end as structure
from audit.v_outcome_context oc
left join (select c.snapshot_id, c.nct_id, c.outcome_ordinal, count(*) as n_classes,
                  max(coalesce(x.n_cat, 0)) as max_categories
           from ctr.outcome_class c
           left join (select snapshot_id, nct_id, outcome_ordinal, class_ordinal, count(*) as n_cat
                      from ctr.outcome_category group by 1, 2, 3, 4) x
             using (snapshot_id, nct_id, outcome_ordinal, class_ordinal)
           group by 1, 2, 3) k using (snapshot_id, nct_id, outcome_ordinal)
left join (select snapshot_id, nct_id, outcome_ordinal, count(*) as n_groups from ctr.outcome_group group by 1, 2, 3) g
       using (snapshot_id, nct_id, outcome_ordinal)
left join (select snapshot_id, nct_id, outcome_ordinal, count(*) as n_measurements from ctr.outcome_measurement group by 1, 2, 3) mm
       using (snapshot_id, nct_id, outcome_ordinal);

-- ---------------------------------------------------------------- outcome-group tiers (primary unit)
create or replace view audit.v_outcome_group_tier as
select g.snapshot_id, g.nct_id, g.outcome_ordinal, g.group_id, g.title as group_title,
       os.reporting_status, os.outcome_type, os.param_type, os.analysis_unit, os.unit_is_participants,
       os.row_specific_mode, os.population_description_present, os.structure,
       count(md.measurement_ordinal) as n_measurements,
       case when os.reporting_status is distinct from 'POSTED' then 'D'
            when count(md.measurement_ordinal) = 0 then 'D'
            when bool_or(md.tier = 'C') then 'C'
            when bool_or(md.tier = 'B') then 'B'
            else 'A' end as tier,
       case when os.reporting_status is distinct from 'POSTED' then 'D_NOT_POSTED'
            when count(md.measurement_ordinal) = 0 then 'D_NO_MEASUREMENTS'
            else string_agg(distinct md.rule_id, '|' order by md.rule_id) end as rules,
       min(md.participant_denominator) as min_participant_denominator,
       max(md.participant_denominator) as max_participant_denominator,
       count(distinct md.participant_denominator) as n_distinct_participant_denominators,
       g.source_pointer as group_pointer
from ctr.outcome_group g
join audit.v_outcome_summary os using (snapshot_id, nct_id, outcome_ordinal)
left join audit.mv_measurement_denominator md
       on md.snapshot_id = g.snapshot_id and md.nct_id = g.nct_id and md.outcome_ordinal = g.outcome_ordinal
      and md.group_id = g.group_id
group by g.snapshot_id, g.nct_id, g.outcome_ordinal, g.group_id, g.title, os.reporting_status, os.outcome_type,
         os.param_type, os.analysis_unit, os.unit_is_participants, os.row_specific_mode,
         os.population_description_present, os.structure, g.source_pointer;

-- ---------------------------------------------------------------- baseline denominators (for K9)
create or replace view audit.v_baseline_measurement_denominator as
select m.snapshot_id, m.nct_id, m.measure_ordinal, m.class_ordinal, m.category_ordinal, m.measurement_ordinal, m.group_id,
       lvl.level, cnt.n_entries, cnt.value_int, cnt.all_usable, cnt.pointers, m.source_pointer as measurement_pointer
from ctr.baseline_measurement m
cross join lateral (
    select case
        when exists (select 1 from ctr.baseline_class_denom d where (d.snapshot_id, d.nct_id, d.measure_ordinal, d.class_ordinal)
                     = (m.snapshot_id, m.nct_id, m.measure_ordinal, m.class_ordinal)) then 'class'
        when exists (select 1 from ctr.baseline_measure_denom d where (d.snapshot_id, d.nct_id, d.measure_ordinal)
                     = (m.snapshot_id, m.nct_id, m.measure_ordinal)) then 'measure'
        else 'module' end as level
) lvl
cross join lateral (
    select count(*) as n_entries, min(x.value_int) as value_int, bool_and(x.value_int is not null) as all_usable,
           string_agg(x.source_pointer, ' ' order by x.source_pointer) as pointers
    from (
        select c.value_int, c.source_pointer from ctr.baseline_class_denom d
        join ctr.baseline_class_denom_count c using (snapshot_id, nct_id, measure_ordinal, class_ordinal, denom_ordinal)
        where lvl.level = 'class' and (d.snapshot_id, d.nct_id, d.measure_ordinal, d.class_ordinal) = (m.snapshot_id, m.nct_id, m.measure_ordinal, m.class_ordinal)
          and audit.norm_unit(d.units) = 'participants' and c.group_id = m.group_id
        union all
        select c.value_int, c.source_pointer from ctr.baseline_measure_denom d
        join ctr.baseline_measure_denom_count c using (snapshot_id, nct_id, measure_ordinal, denom_ordinal)
        where lvl.level = 'measure' and (d.snapshot_id, d.nct_id, d.measure_ordinal) = (m.snapshot_id, m.nct_id, m.measure_ordinal)
          and audit.norm_unit(d.units) = 'participants' and c.group_id = m.group_id
        union all
        select c.value_int, c.source_pointer from ctr.baseline_denom d
        join ctr.baseline_denom_count c using (snapshot_id, nct_id, denom_ordinal)
        where lvl.level = 'module' and (d.snapshot_id, d.nct_id) = (m.snapshot_id, m.nct_id)
          and audit.norm_unit(d.units) = 'participants' and c.group_id = m.group_id
    ) x
) cnt;

-- ---------------------------------------------------------------- checks (docs/rules.md)
create or replace view audit.v_check as
-- K1
select 'K1'::text as check_id, md.snapshot_id, md.nct_id, md.measurement_pointer as pointer,
       case when m.value_num is null then 'not_evaluable' when m.value_num > md.participant_denominator then 'fail' else 'pass' end as status,
       jsonb_build_object('value', m.value_text, 'participant_denominator', md.participant_denominator,
                          'denominator_pointer', md.denominator_pointer, 'tier_rule', md.rule_id,
                          'param_type', oc.param_type, 'analysis_unit', oc.analysis_unit) as evidence
from audit.mv_measurement_denominator md
join ctr.outcome_measurement m on m.snapshot_id = md.snapshot_id and m.nct_id = md.nct_id and m.source_pointer = md.measurement_pointer
join audit.v_outcome_context oc on oc.snapshot_id = md.snapshot_id and oc.nct_id = md.nct_id and oc.outcome_ordinal = md.outcome_ordinal
where oc.param_type = 'COUNT_OF_PARTICIPANTS' and oc.unit_is_participants and md.tier in ('A', 'B') and m.value_text is not null
union all
-- K2
select 'K2', md.snapshot_id, md.nct_id, md.measurement_pointer,
       case when m.value_num is null then 'not_evaluable' when m.value_num > md.unit_denominator then 'fail' else 'pass' end,
       jsonb_build_object('value', m.value_text, 'unit_denominator', md.unit_denominator, 'analysis_unit', oc.analysis_unit,
                          'param_type', oc.param_type)
from audit.mv_measurement_denominator md
join ctr.outcome_measurement m on m.snapshot_id = md.snapshot_id and m.nct_id = md.nct_id and m.source_pointer = md.measurement_pointer
join audit.v_outcome_context oc on oc.snapshot_id = md.snapshot_id and oc.nct_id = md.nct_id and oc.outcome_ordinal = md.outcome_ordinal
where oc.param_type = 'COUNT_OF_UNITS' and md.unit_denominator is not null and m.value_text is not null
union all
-- K3 outcome and baseline
select 'K3', m.snapshot_id, m.nct_id, m.source_pointer,
       case when m.lower_limit_num is null or m.upper_limit_num is null then 'not_evaluable'
            when m.lower_limit_num > m.upper_limit_num then 'fail' else 'pass' end,
       jsonb_build_object('module', 'outcome', 'dispersion_type', o.dispersion_type, 'lower', m.lower_limit_text, 'upper', m.upper_limit_text)
from ctr.outcome_measurement m join ctr.outcome_measure o using (snapshot_id, nct_id, outcome_ordinal)
where audit.interval_kind(o.dispersion_type) is not null and m.lower_limit_text is not null and m.upper_limit_text is not null
union all
select 'K3', m.snapshot_id, m.nct_id, m.source_pointer,
       case when m.lower_limit_num is null or m.upper_limit_num is null then 'not_evaluable'
            when m.lower_limit_num > m.upper_limit_num then 'fail' else 'pass' end,
       jsonb_build_object('module', 'baseline', 'dispersion_type', b.dispersion_type, 'lower', m.lower_limit_text, 'upper', m.upper_limit_text)
from ctr.baseline_measurement m join ctr.baseline_measure b using (snapshot_id, nct_id, measure_ordinal)
where audit.interval_kind(b.dispersion_type) is not null and m.lower_limit_text is not null and m.upper_limit_text is not null
union all
-- K4 outcome and baseline
select 'K4', m.snapshot_id, m.nct_id, m.source_pointer,
       case when m.value_num is null or m.lower_limit_num is null or m.upper_limit_num is null then 'not_evaluable'
            when m.lower_limit_num > m.upper_limit_num then 'not_evaluable'
            when m.value_num < m.lower_limit_num or m.value_num > m.upper_limit_num then 'fail' else 'pass' end,
       jsonb_build_object('module', 'outcome', 'param_type', o.param_type, 'dispersion_type', o.dispersion_type,
                          'value', m.value_text, 'lower', m.lower_limit_text, 'upper', m.upper_limit_text)
from ctr.outcome_measurement m join ctr.outcome_measure o using (snapshot_id, nct_id, outcome_ordinal)
where (audit.interval_kind(o.dispersion_type) in ('confidence', 'full_range')
       or (audit.interval_kind(o.dispersion_type) = 'iqr' and o.param_type = 'MEDIAN'))
  and m.value_text is not null and m.lower_limit_text is not null and m.upper_limit_text is not null
union all
select 'K4', m.snapshot_id, m.nct_id, m.source_pointer,
       case when m.value_num is null or m.lower_limit_num is null or m.upper_limit_num is null then 'not_evaluable'
            when m.lower_limit_num > m.upper_limit_num then 'not_evaluable'
            when m.value_num < m.lower_limit_num or m.value_num > m.upper_limit_num then 'fail' else 'pass' end,
       jsonb_build_object('module', 'baseline', 'param_type', b.param_type, 'dispersion_type', b.dispersion_type,
                          'value', m.value_text, 'lower', m.lower_limit_text, 'upper', m.upper_limit_text)
from ctr.baseline_measurement m join ctr.baseline_measure b using (snapshot_id, nct_id, measure_ordinal)
where (audit.interval_kind(b.dispersion_type) in ('confidence', 'full_range')
       or (audit.interval_kind(b.dispersion_type) = 'iqr' and b.param_type = 'MEDIAN'))
  and m.value_text is not null and m.lower_limit_text is not null and m.upper_limit_text is not null
union all
-- K5
select 'K5', m.snapshot_id, m.nct_id, m.source_pointer,
       case when m.value_num is null then 'not_evaluable' when m.value_num < 0 or m.value_num > 100 then 'fail' else 'pass' end,
       jsonb_build_object('value', m.value_text, 'unit_of_measure', o.unit_of_measure, 'param_type', o.param_type)
from ctr.outcome_measurement m join ctr.outcome_measure o using (snapshot_id, nct_id, outcome_ordinal)
where o.unit_of_measure ~* '^\s*(percentage|percent|%)\s+(of\s+)?participants' and o.param_type = 'NUMBER' and m.value_text is not null
union all
-- K6
select 'K6', s.snapshot_id, s.nct_id, s.source_pointer,
       case when s.num_affected > s.num_at_risk then 'fail' else 'pass' end,
       jsonb_build_object('num_affected', s.num_affected, 'num_at_risk', s.num_at_risk, 'seriousness', s.seriousness)
from ctr.ae_event_stat s where s.num_affected is not null and s.num_at_risk is not null
union all
-- K7
select 'K7', s.snapshot_id, s.nct_id, s.source_pointer,
       case when s.num_affected > s.num_events then 'fail' else 'pass' end,
       jsonb_build_object('num_affected', s.num_affected, 'num_events', s.num_events, 'seriousness', s.seriousness)
from ctr.ae_event_stat s where s.num_affected is not null and s.num_events is not null
union all
-- K8
select 'K8', g.snapshot_id, g.nct_id, g.source_pointer || '/' || x.kind || 'NumAffected',
       case when x.affected > x.at_risk then 'fail' else 'pass' end,
       jsonb_build_object('kind', x.kind, 'affected', x.affected, 'at_risk', x.at_risk,
                          'at_risk_pointer', g.source_pointer || '/' || x.kind || 'NumAtRisk')
from ctr.ae_group g
cross join lateral (values ('deaths', g.deaths_num_affected, g.deaths_num_at_risk),
                           ('serious', g.serious_num_affected, g.serious_num_at_risk),
                           ('other', g.other_num_affected, g.other_num_at_risk)) as x(kind, affected, at_risk)
where x.affected is not null and x.at_risk is not null
union all
-- K9
select 'K9', bd.snapshot_id, bd.nct_id, bd.measurement_pointer,
       case when m.value_num is null then 'not_evaluable' when m.value_num > bd.value_int then 'fail' else 'pass' end,
       jsonb_build_object('value', m.value_text, 'baseline_denominator', bd.value_int, 'level', bd.level,
                          'denominator_pointer', bd.pointers)
from audit.v_baseline_measurement_denominator bd
join ctr.baseline_measurement m on m.snapshot_id = bd.snapshot_id and m.nct_id = bd.nct_id and m.source_pointer = bd.measurement_pointer
join ctr.baseline_measure b on b.snapshot_id = m.snapshot_id and b.nct_id = m.nct_id and b.measure_ordinal = m.measure_ordinal
where b.param_type = 'COUNT_OF_PARTICIPANTS' and audit.norm_unit(coalesce(nullif(audit.trim_ws(b.denom_units_selected), ''), 'Participants')) = 'participants'
  and bd.n_entries = 1 and bd.all_usable and m.value_text is not null
union all
-- K10
select 'K10', a.snapshot_id, a.nct_id, a.source_pointer,
       case when a.param_value_num is null or a.ci_lower_limit_num is null or a.ci_upper_limit_num is null then 'not_evaluable'
            when a.ci_lower_limit_num > a.ci_upper_limit_num then 'fail'
            when a.param_value_num < a.ci_lower_limit_num or a.param_value_num > a.ci_upper_limit_num then 'fail'
            else 'pass' end,
       jsonb_build_object('param_type', a.param_type, 'estimate', a.param_value_text, 'ci_lower', a.ci_lower_limit_text,
                          'ci_upper', a.ci_upper_limit_text, 'ci_pct', a.ci_pct_value_text)
from ctr.outcome_analysis a
where a.ci_num_sides = 'TWO_SIDED' and a.param_value_text is not null and a.ci_lower_limit_text is not null and a.ci_upper_limit_text is not null
union all
-- K11
select 'K11', md.snapshot_id, md.nct_id, md.measurement_pointer,
       case when m.value_num is null then 'not_evaluable' when m.value_num <> 0 then 'fail' else 'pass' end,
       jsonb_build_object('value', m.value_text, 'participant_denominator', md.participant_denominator,
                          'denominator_pointer', md.denominator_pointer)
from audit.mv_measurement_denominator md
join ctr.outcome_measurement m on m.snapshot_id = md.snapshot_id and m.nct_id = md.nct_id and m.source_pointer = md.measurement_pointer
where md.unit_is_participants and md.tier in ('A', 'B') and md.participant_denominator = 0 and m.value_text is not null
union all
-- K12: categories of a count-of-participants row are defined as mutually exclusive and exhaustive, so their counts
-- should add up to the participants analyzed for that row and group.
select 'K12', x.snapshot_id, x.nct_id, x.first_pointer,
       case when not x.all_plain_int then 'not_evaluable' when x.total <> x.den then 'fail' else 'pass' end,
       jsonb_build_object('group_id', x.group_id, 'category_sum', x.total, 'participant_denominator', x.den,
                          'n_categories', x.n_cat, 'category_pointers', x.pointers, 'denominator_pointer', x.den_pointer)
from (
    select md.snapshot_id, md.nct_id, md.outcome_ordinal, md.class_ordinal, md.group_id,
           count(*) as n_cat, bool_and(nullif(audit.trim_ws(k.title), '') is not null) as all_titled,
           bool_and(m.value_num is not null and m.value_num = trunc(m.value_num) and m.value_num >= 0) as all_plain_int,
           sum(m.value_num) as total, min(md.participant_denominator) as den, min(md.denominator_pointer) as den_pointer,
           (array_agg(m.source_pointer order by m.category_ordinal, m.measurement_ordinal))[1] as first_pointer,
           string_agg(m.source_pointer, ' ' order by m.category_ordinal, m.measurement_ordinal) as pointers
    from audit.mv_measurement_denominator md
    join ctr.outcome_measurement m on m.snapshot_id = md.snapshot_id and m.nct_id = md.nct_id and m.source_pointer = md.measurement_pointer
    join ctr.outcome_category k on k.snapshot_id = m.snapshot_id and k.nct_id = m.nct_id and k.outcome_ordinal = m.outcome_ordinal
         and k.class_ordinal = m.class_ordinal and k.category_ordinal = m.category_ordinal
    join audit.v_outcome_context oc on oc.snapshot_id = md.snapshot_id and oc.nct_id = md.nct_id and oc.outcome_ordinal = md.outcome_ordinal
    where oc.param_type = 'COUNT_OF_PARTICIPANTS' and oc.unit_is_participants and md.tier in ('A', 'B')
    group by md.snapshot_id, md.nct_id, md.outcome_ordinal, md.class_ordinal, md.group_id
) x
where x.n_cat >= 2 and x.all_titled;

-- ---------------------------------------------------------------- cautious evidence table (one row per outcome measurement)
create or replace view audit.v_evidence_table as
select s.snapshot_id, s.nct_id, s.registry_url, s.split, s.cohort_status, array_to_string(s.confirmed_groups, '|') as condition_groups,
       s.results_first_post_date,
       oc.outcome_ordinal, oc.outcome_type, oc.outcome_title, oc.time_frame, oc.param_type, oc.dispersion_type, oc.unit_of_measure,
       oc.analysis_unit, oc.population_description_present, oc.population_description,
       c.title as class_title, k.title as category_title, g.group_id, g.title as group_title,
       m.value_text, m.spread_text, m.lower_limit_text, m.upper_limit_text, m.comment as value_comment,
       md.tier, md.rule_id, md.participant_denominator, md.denominator_scope, md.unit_denominator,
       concat_ws('; ',
           case when md.rule_id = 'B1_ROW_SPECIFIC_DENOMINATOR' then 'row-specific number analyzed used for this row' end,
           case when not oc.unit_is_participants then 'values are per ' || oc.analysis_unit || ', not per participant' end,
           case when md.tier = 'C' then 'participant denominator not resolvable (' || md.rule_id || ')' end,
           case when m.value_text is not null and m.value_text <> 'NA' and m.value_num is null then 'value is not a plain number; kept as text' end,
           case when m.value_text = 'NA' then 'value reported as NA' end,
           case when not oc.population_description_present then 'no analysis population description' end
       ) as caution,
       m.source_pointer as measurement_pointer, md.denominator_pointer
from ctr.outcome_measurement m
join ctr.study s using (snapshot_id, nct_id)
join audit.v_outcome_context oc using (snapshot_id, nct_id, outcome_ordinal)
join ctr.outcome_class c using (snapshot_id, nct_id, outcome_ordinal, class_ordinal)
join ctr.outcome_category k using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal)
join ctr.outcome_group g using (snapshot_id, nct_id, outcome_ordinal, group_id)
join audit.mv_measurement_denominator md
  on md.snapshot_id = m.snapshot_id and md.nct_id = m.nct_id and md.measurement_pointer = m.source_pointer;

-- ---------------------------------------------------------------- denominator provenance explorer (one row per outcome group)
create or replace view audit.v_denominator_provenance as
select t.snapshot_id, t.nct_id, s.registry_url, t.outcome_ordinal, oc.outcome_type, oc.outcome_title, oc.time_frame,
       t.group_id, t.group_title, t.tier, t.rules, t.n_measurements,
       t.min_participant_denominator, t.max_participant_denominator, t.n_distinct_participant_denominators,
       oc.analysis_unit, oc.row_specific_mode, oc.population_description_present, oc.population_description,
       (select jsonb_agg(jsonb_build_object('level', 'outcome', 'units', d.units, 'value', c.value_text, 'pointer', c.source_pointer)
                         order by c.source_pointer)
          from ctr.outcome_denom d join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
         where (c.snapshot_id, c.nct_id, c.outcome_ordinal, c.group_id) = (t.snapshot_id, t.nct_id, t.outcome_ordinal, t.group_id)
       ) as outcome_level_denominators,
       (select jsonb_agg(jsonb_build_object('level', 'class', 'class_title', cl.title, 'units', d.units, 'value', c.value_text,
                                            'pointer', c.source_pointer) order by c.source_pointer)
          from ctr.outcome_class_denom d
          join ctr.outcome_class_denom_count c using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal)
          join ctr.outcome_class cl using (snapshot_id, nct_id, outcome_ordinal, class_ordinal)
         where (c.snapshot_id, c.nct_id, c.outcome_ordinal, c.group_id) = (t.snapshot_id, t.nct_id, t.outcome_ordinal, t.group_id)
       ) as row_specific_denominators,
       (select jsonb_agg(jsonb_build_object('module', 'baseline', 'group_id', bg.group_id, 'title', bg.title) order by bg.group_id)
          from ctr.baseline_group bg
         where bg.snapshot_id = t.snapshot_id and bg.nct_id = t.nct_id and audit.norm_title(bg.title) = audit.norm_title(t.group_title)
       ) as same_label_in_baseline_not_linked,
       t.group_pointer
from audit.v_outcome_group_tier t
join ctr.study s using (snapshot_id, nct_id)
join audit.v_outcome_context oc using (snapshot_id, nct_id, outcome_ordinal);

-- ---------------------------------------------------------------- cross-module label identity (S7, descriptive)
create or replace view audit.v_cross_module_label as
select t.snapshot_id, t.nct_id, t.outcome_ordinal, t.group_id, t.group_title, t.tier,
       op.value_int as outcome_participants,
       bm.n_matches as baseline_title_matches, bm.baseline_group_id, bm.baseline_participants
from audit.v_outcome_group_tier t
left join audit.v_outcome_counts op
       on op.snapshot_id = t.snapshot_id and op.nct_id = t.nct_id and op.outcome_ordinal = t.outcome_ordinal
      and op.group_id = t.group_id and op.unit_norm = 'participants' and op.n_entries = 1 and op.all_usable
left join lateral (
    -- exact title equality, as prespecified (S7); one row per baseline group
    select count(*) as n_matches, min(bg.group_id) as baseline_group_id,
           min(bc.value_int) filter (where bc.n_entries = 1 and bc.all_usable) as baseline_participants
    from ctr.baseline_group bg
    left join (select c.snapshot_id, c.nct_id, c.group_id, count(*) as n_entries, min(c.value_int) as value_int,
                      bool_and(c.value_int is not null) as all_usable
               from ctr.baseline_denom d join ctr.baseline_denom_count c using (snapshot_id, nct_id, denom_ordinal)
               where audit.norm_unit(d.units) = 'participants' group by 1, 2, 3) bc
           on bc.snapshot_id = bg.snapshot_id and bc.nct_id = bg.nct_id and bc.group_id = bg.group_id
    where bg.snapshot_id = t.snapshot_id and bg.nct_id = t.nct_id and bg.title = t.group_title
) bm on true
where t.reporting_status = 'POSTED';

-- ---------------------------------------------------------------- issue ledger
create or replace view audit.v_issue_ledger as
select 'transformation defect'::text as issue_class, d.defect_kind as rule_id, d.snapshot_id, d.nct_id, d.pointer,
       jsonb_build_object('reference_value', d.reference_value, 'warehouse_value', d.warehouse_value) as evidence,
       'warehouse value differs from the independent raw-JSON reference at this pointer'::text as why_flagged
from audit.transformation_defect d
union all
select 'possible source inconsistency', c.check_id, c.snapshot_id, c.nct_id, c.pointer, c.evidence,
       'applicability conditions of ' || c.check_id || ' held and the check failed (docs/rules.md)'
from audit.v_check c where c.status = 'fail'
union all
select 'unresolved interpretation',
       (select string_agg(r, '|' order by r) from unnest(string_to_array(t.rules, '|')) r where r like 'C%'),
       t.snapshot_id, t.nct_id, t.group_pointer,
       jsonb_build_object('group_title', t.group_title, 'n_measurements', t.n_measurements, 'analysis_unit', t.analysis_unit,
                          'row_specific_mode', t.row_specific_mode, 'all_rules', t.rules,
                          'outcome_level_denominators',
                          (select jsonb_agg(jsonb_build_object('units', d.units, 'value', c.value_text, 'pointer', c.source_pointer)
                                            order by c.source_pointer)
                             from ctr.outcome_denom d join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
                            where c.snapshot_id = t.snapshot_id and c.nct_id = t.nct_id and c.outcome_ordinal = t.outcome_ordinal
                              and c.group_id = t.group_id),
                          'row_level_denominators',
                          (select jsonb_agg(jsonb_build_object('class_ordinal', c.class_ordinal, 'units', d.units, 'value', c.value_text,
                                                               'pointer', c.source_pointer) order by c.source_pointer)
                             from ctr.outcome_class_denom d
                             join ctr.outcome_class_denom_count c using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal)
                            where c.snapshot_id = t.snapshot_id and c.nct_id = t.nct_id and c.outcome_ordinal = t.outcome_ordinal
                              and c.group_id = t.group_id)),
       'participant denominator cannot be associated with every measurement of this outcome group by the written rules'
from audit.v_outcome_group_tier t where t.tier = 'C'
union all
select 'unresolved interpretation', 'NUMERIC_TEXT_NOT_PLAIN', m.snapshot_id, m.nct_id, m.source_pointer,
       jsonb_build_object('value', m.value_text),
       'value text is not a plain decimal number (for example a thousands separator or decimal comma); kept verbatim, not parsed'
from ctr.outcome_measurement m where m.value_text is not null and m.value_text <> 'NA' and m.value_num is null;
