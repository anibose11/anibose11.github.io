-- Warehouse schema for public aggregate ClinicalTrials.gov results (API v2).
-- Every table is keyed by (snapshot_id, nct_id, ...source ordinals...). Ordinals are zero-based list
-- positions in the source record, so the key of a row is also its location in the source JSON.
-- *_text columns hold the exact source string; *_num / *_int hold a parsed value only when the text is a
-- plain decimal number (or non-negative integer). Group identifiers are scoped to their module, and outcome
-- group identifiers are additionally scoped to their outcome measure.

create schema if not exists ctr;

create table if not exists ctr.snapshot (
    snapshot_id            text primary key,
    retrieval_started_at   timestamptz not null,
    retrieval_finished_at  timestamptz not null,
    api_version            text not null,
    data_timestamp_before  text not null,
    data_timestamp_after   text not null,
    query_spec             jsonb not null,
    n_studies              integer not null check (n_studies >= 0),
    raw_pages_sha256       text not null,
    loader_version         text not null,
    loaded_at              timestamptz not null default now()
);

-- Staging: one record per study (jsonb keeps every value; key order is not semantic). The point-of-contact and
-- certain-agreement blocks are removed before storage; record_sha256 is the hash of the record as retrieved.
create table if not exists ctr.raw_study (
    snapshot_id    text not null references ctr.snapshot on delete cascade,
    nct_id         text not null check (nct_id ~ '^NCT[0-9]{8}$'),
    batch_file     text not null,
    record_sha256  text not null check (record_sha256 ~ '^[0-9a-f]{64}$'),
    record         jsonb not null,
    primary key (snapshot_id, nct_id)
);

create table if not exists ctr.study (
    snapshot_id               text not null,
    nct_id                    text not null,
    split                     text not null check (split in ('development', 'heldout')),
    cohort_status             text not null check (cohort_status in ('confirmed', 'ambiguous_condition_match', 'excluded_frame')),
    query_groups              text[] not null,
    confirmed_groups          text[] not null,
    cluster_id                text not null,
    brief_title               text,
    official_title            text,
    acronym                   text,
    organization              text,
    organization_class        text,
    org_study_id              text,
    study_type                text,
    phases                    text[],
    allocation                text,
    intervention_model        text,
    primary_purpose           text,
    masking                   text,
    enrollment_count          integer,
    enrollment_type           text,
    overall_status            text,
    start_date                text,          -- partial dates (YYYY-MM) are kept as text
    primary_completion_date   text,
    completion_date           text,
    completion_date_type      text,
    results_first_submit_date date,
    results_first_post_date   date,
    last_update_post_date     date,
    has_results               boolean not null,
    registry_url              text generated always as ('https://clinicaltrials.gov/study/' || nct_id) stored,
    primary key (snapshot_id, nct_id),
    foreign key (snapshot_id, nct_id) references ctr.raw_study on delete cascade
);

create table if not exists ctr.study_condition (
    snapshot_id text not null, nct_id text not null, condition_ordinal integer not null check (condition_ordinal >= 0),
    condition text not null,
    primary key (snapshot_id, nct_id, condition_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);

create table if not exists ctr.study_condition_mesh (
    snapshot_id text not null, nct_id text not null,
    kind text not null check (kind in ('mesh', 'ancestor')),
    mesh_ordinal integer not null check (mesh_ordinal >= 0),
    mesh_id text, term text,
    primary key (snapshot_id, nct_id, kind, mesh_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);

-- Studies whose results could not be loaded under the constraints are recorded here instead of failing the load.
create table if not exists ctr.load_exception (
    snapshot_id text not null, nct_id text not null, stage text not null, detail text not null,
    primary key (snapshot_id, nct_id, stage)
);

create table if not exists ctr.result_module (
    snapshot_id text not null, nct_id text not null,
    module text not null check (module in ('participant_flow', 'baseline', 'outcome_measures', 'adverse_events', 'more_info')),
    present boolean not null,
    source_pointer text not null,
    primary key (snapshot_id, nct_id, module),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);

-- ---------------------------------------------------------------- participant flow
create table if not exists ctr.flow_module (
    snapshot_id text not null, nct_id text not null,
    recruitment_details text, pre_assignment_details text, type_units_analyzed text,
    source_pointer text not null,
    primary key (snapshot_id, nct_id),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);
create table if not exists ctr.flow_group (
    snapshot_id text not null, nct_id text not null, group_id text not null, group_ordinal integer not null,
    title text, description text, source_pointer text not null,
    primary key (snapshot_id, nct_id, group_id),
    unique (snapshot_id, nct_id, group_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.flow_module on delete cascade
);
create table if not exists ctr.flow_period (
    snapshot_id text not null, nct_id text not null, period_ordinal integer not null,
    title text, source_pointer text not null,
    primary key (snapshot_id, nct_id, period_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.flow_module on delete cascade
);
create table if not exists ctr.flow_milestone (
    snapshot_id text not null, nct_id text not null, period_ordinal integer not null, milestone_ordinal integer not null,
    type text, comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, period_ordinal, milestone_ordinal),
    foreign key (snapshot_id, nct_id, period_ordinal) references ctr.flow_period on delete cascade
);
create table if not exists ctr.flow_achievement (
    snapshot_id text not null, nct_id text not null, period_ordinal integer not null, milestone_ordinal integer not null,
    achievement_ordinal integer not null, group_id text not null,
    num_subjects_text text, num_subjects_int integer check (num_subjects_int >= 0),
    num_units_text text, num_units_int integer check (num_units_int >= 0),
    comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, period_ordinal, milestone_ordinal, achievement_ordinal),
    foreign key (snapshot_id, nct_id, period_ordinal, milestone_ordinal) references ctr.flow_milestone on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.flow_group on delete cascade
);
create table if not exists ctr.flow_drop_withdraw (
    snapshot_id text not null, nct_id text not null, period_ordinal integer not null, drop_ordinal integer not null,
    type text, comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, period_ordinal, drop_ordinal),
    foreign key (snapshot_id, nct_id, period_ordinal) references ctr.flow_period on delete cascade
);
create table if not exists ctr.flow_drop_reason (
    snapshot_id text not null, nct_id text not null, period_ordinal integer not null, drop_ordinal integer not null,
    reason_ordinal integer not null, group_id text not null,
    num_subjects_text text, num_subjects_int integer check (num_subjects_int >= 0),
    comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, period_ordinal, drop_ordinal, reason_ordinal),
    foreign key (snapshot_id, nct_id, period_ordinal, drop_ordinal) references ctr.flow_drop_withdraw on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.flow_group on delete cascade
);

-- ---------------------------------------------------------------- baseline characteristics
create table if not exists ctr.baseline_module (
    snapshot_id text not null, nct_id text not null,
    population_description text, type_units_analyzed text, source_pointer text not null,
    primary key (snapshot_id, nct_id),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);
create table if not exists ctr.baseline_group (
    snapshot_id text not null, nct_id text not null, group_id text not null, group_ordinal integer not null,
    title text, description text, source_pointer text not null,
    primary key (snapshot_id, nct_id, group_id),
    unique (snapshot_id, nct_id, group_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.baseline_module on delete cascade
);
create table if not exists ctr.baseline_denom (
    snapshot_id text not null, nct_id text not null, denom_ordinal integer not null, units text,
    source_pointer text not null,
    primary key (snapshot_id, nct_id, denom_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.baseline_module on delete cascade
);
create table if not exists ctr.baseline_denom_count (
    snapshot_id text not null, nct_id text not null, denom_ordinal integer not null, count_ordinal integer not null,
    group_id text not null, value_text text, value_int integer check (value_int >= 0), source_pointer text not null,
    primary key (snapshot_id, nct_id, denom_ordinal, count_ordinal),
    foreign key (snapshot_id, nct_id, denom_ordinal) references ctr.baseline_denom on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.baseline_group on delete cascade
);
create table if not exists ctr.baseline_measure (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null,
    title text, description text, population_description text, param_type text, dispersion_type text,
    unit_of_measure text, calculate_pct boolean, denom_units_selected text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.baseline_module on delete cascade
);
create table if not exists ctr.baseline_measure_denom (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, denom_ordinal integer not null,
    units text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, denom_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal) references ctr.baseline_measure on delete cascade
);
create table if not exists ctr.baseline_measure_denom_count (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, denom_ordinal integer not null,
    count_ordinal integer not null, group_id text not null, value_text text, value_int integer check (value_int >= 0),
    source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, denom_ordinal, count_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal, denom_ordinal) references ctr.baseline_measure_denom on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.baseline_group on delete cascade
);
create table if not exists ctr.baseline_class (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, class_ordinal integer not null,
    title text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, class_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal) references ctr.baseline_measure on delete cascade
);
create table if not exists ctr.baseline_class_denom (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, class_ordinal integer not null,
    denom_ordinal integer not null, units text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, class_ordinal, denom_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal, class_ordinal) references ctr.baseline_class on delete cascade
);
create table if not exists ctr.baseline_class_denom_count (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, class_ordinal integer not null,
    denom_ordinal integer not null, count_ordinal integer not null, group_id text not null,
    value_text text, value_int integer check (value_int >= 0), source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, class_ordinal, denom_ordinal, count_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal, class_ordinal, denom_ordinal) references ctr.baseline_class_denom on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.baseline_group on delete cascade
);
create table if not exists ctr.baseline_category (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, class_ordinal integer not null,
    category_ordinal integer not null, title text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, class_ordinal, category_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal, class_ordinal) references ctr.baseline_class on delete cascade
);
create table if not exists ctr.baseline_measurement (
    snapshot_id text not null, nct_id text not null, measure_ordinal integer not null, class_ordinal integer not null,
    category_ordinal integer not null, measurement_ordinal integer not null, group_id text not null,
    value_text text, value_num numeric, spread_text text, spread_num numeric,
    lower_limit_text text, lower_limit_num numeric, upper_limit_text text, upper_limit_num numeric,
    comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, measure_ordinal, class_ordinal, category_ordinal, measurement_ordinal),
    foreign key (snapshot_id, nct_id, measure_ordinal, class_ordinal, category_ordinal) references ctr.baseline_category on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.baseline_group on delete cascade
);

-- ---------------------------------------------------------------- outcome measures
create table if not exists ctr.outcome_measure (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null,
    type text, title text, description text, population_description text,
    reporting_status text, anticipated_posting_date text,
    param_type text, dispersion_type text, unit_of_measure text, calculate_pct boolean,
    time_frame text, type_units_analyzed text, denom_units_selected text,
    source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);
-- OG identifiers are scoped to one outcome measure: OG000 in two outcomes need not be the same population.
create table if not exists ctr.outcome_group (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, group_id text not null,
    group_ordinal integer not null, title text, description text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, group_id),
    unique (snapshot_id, nct_id, outcome_ordinal, group_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal) references ctr.outcome_measure on delete cascade
);
create table if not exists ctr.outcome_denom (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, denom_ordinal integer not null,
    units text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, denom_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal) references ctr.outcome_measure on delete cascade
);
create table if not exists ctr.outcome_denom_count (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, denom_ordinal integer not null,
    count_ordinal integer not null, group_id text not null, value_text text, value_int integer check (value_int >= 0),
    source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, denom_ordinal, count_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, denom_ordinal) references ctr.outcome_denom on delete cascade,
    foreign key (snapshot_id, nct_id, outcome_ordinal, group_id) references ctr.outcome_group on delete cascade
);
create table if not exists ctr.outcome_class (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    title text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal) references ctr.outcome_measure on delete cascade
);
create table if not exists ctr.outcome_class_denom (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    denom_ordinal integer not null, units text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, class_ordinal) references ctr.outcome_class on delete cascade
);
create table if not exists ctr.outcome_class_denom_count (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    denom_ordinal integer not null, count_ordinal integer not null, group_id text not null,
    value_text text, value_int integer check (value_int >= 0), source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal, count_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, denom_ordinal) references ctr.outcome_class_denom on delete cascade,
    foreign key (snapshot_id, nct_id, outcome_ordinal, group_id) references ctr.outcome_group on delete cascade
);
create table if not exists ctr.outcome_category (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    category_ordinal integer not null, title text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, class_ordinal) references ctr.outcome_class on delete cascade
);
create table if not exists ctr.outcome_measurement (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    category_ordinal integer not null, measurement_ordinal integer not null, group_id text not null,
    value_text text, value_num numeric, spread_text text, spread_num numeric,
    lower_limit_text text, lower_limit_num numeric, upper_limit_text text, upper_limit_num numeric,
    comment text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal) references ctr.outcome_category on delete cascade,
    foreign key (snapshot_id, nct_id, outcome_ordinal, group_id) references ctr.outcome_group on delete cascade
);
create table if not exists ctr.outcome_analysis (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, analysis_ordinal integer not null,
    param_type text, param_value_text text, param_value_num numeric,
    dispersion_type text, dispersion_value_text text, dispersion_value_num numeric,
    statistical_method text, statistical_comment text, p_value_text text, p_value_comment text,
    ci_num_sides text, ci_pct_value_text text,
    ci_lower_limit_text text, ci_lower_limit_num numeric, ci_upper_limit_text text, ci_upper_limit_num numeric,
    ci_lower_limit_comment text, ci_upper_limit_comment text, estimate_comment text,
    tested_non_inferiority boolean, non_inferiority_type text, non_inferiority_comment text,
    other_analysis_description text, group_description text, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, analysis_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal) references ctr.outcome_measure on delete cascade
);
create table if not exists ctr.outcome_analysis_group (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, analysis_ordinal integer not null,
    member_ordinal integer not null, group_id text not null, source_pointer text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, analysis_ordinal, member_ordinal),
    foreign key (snapshot_id, nct_id, outcome_ordinal, analysis_ordinal) references ctr.outcome_analysis on delete cascade,
    foreign key (snapshot_id, nct_id, outcome_ordinal, group_id) references ctr.outcome_group on delete cascade
);

-- ---------------------------------------------------------------- adverse events
create table if not exists ctr.ae_module (
    snapshot_id text not null, nct_id text not null,
    frequency_threshold text, time_frame text, description text, all_cause_mortality_comment text,
    source_pointer text not null,
    primary key (snapshot_id, nct_id),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);
create table if not exists ctr.ae_group (
    snapshot_id text not null, nct_id text not null, group_id text not null, group_ordinal integer not null,
    title text, description text,
    deaths_num_affected integer, deaths_num_at_risk integer,
    serious_num_affected integer, serious_num_at_risk integer,
    other_num_affected integer, other_num_at_risk integer,
    source_pointer text not null,
    primary key (snapshot_id, nct_id, group_id),
    unique (snapshot_id, nct_id, group_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.ae_module on delete cascade
);
-- Events (numEvents) and participants (numAffected / numAtRisk) are different units and are kept apart.
create table if not exists ctr.ae_event (
    snapshot_id text not null, nct_id text not null,
    seriousness text not null check (seriousness in ('serious', 'other')),
    event_ordinal integer not null, term text, organ_system text, source_vocabulary text,
    assessment_type text, notes text, source_pointer text not null,
    primary key (snapshot_id, nct_id, seriousness, event_ordinal),
    foreign key (snapshot_id, nct_id) references ctr.ae_module on delete cascade
);
create table if not exists ctr.ae_event_stat (
    snapshot_id text not null, nct_id text not null, seriousness text not null, event_ordinal integer not null,
    stat_ordinal integer not null, group_id text not null,
    num_events integer, num_affected integer, num_at_risk integer, source_pointer text not null,
    primary key (snapshot_id, nct_id, seriousness, event_ordinal, stat_ordinal),
    foreign key (snapshot_id, nct_id, seriousness, event_ordinal) references ctr.ae_event on delete cascade,
    foreign key (snapshot_id, nct_id, group_id) references ctr.ae_group on delete cascade
);

-- ---------------------------------------------------------------- more information (limitations only)
-- The point-of-contact block (names, e-mail addresses, telephone numbers) is deliberately not loaded.
create table if not exists ctr.more_info (
    snapshot_id text not null, nct_id text not null,
    limitations_and_caveats text, source_pointer text not null,
    primary key (snapshot_id, nct_id),
    foreign key (snapshot_id, nct_id) references ctr.study on delete cascade
);

-- Load bookkeeping for idempotency checks.
create table if not exists ctr.load_run (
    load_run_id     bigint generated always as identity primary key,
    snapshot_id     text not null,
    scope           text not null,
    started_at      timestamptz not null,
    finished_at     timestamptz,
    action          text not null check (action in ('loaded', 'reloaded_identical', 'reloaded_changed')),
    n_studies       integer,
    table_fingerprint jsonb
);

-- Indexes for the audit views, which join measurements by their source pointer.
create index if not exists outcome_measurement_pointer_idx on ctr.outcome_measurement (snapshot_id, nct_id, source_pointer);
create index if not exists baseline_measurement_pointer_idx on ctr.baseline_measurement (snapshot_id, nct_id, source_pointer);
create index if not exists outcome_measurement_group_idx on ctr.outcome_measurement (snapshot_id, nct_id, outcome_ordinal, group_id);
