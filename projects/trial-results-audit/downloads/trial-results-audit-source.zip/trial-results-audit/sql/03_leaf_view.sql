-- Generated from src/tra/spec.py by tra.reference.leaf_view_sql(); do not edit by hand.
create or replace view ctr.v_leaf as
select snapshot_id, nct_id, source_pointer || '/recruitmentDetails' as pointer, 'string'::text as json_type, recruitment_details as value_text, 'flow_module'::text as object_name, 'recruitment_details'::text as column_name from ctr.flow_module where recruitment_details is not null
union all
select snapshot_id, nct_id, source_pointer || '/preAssignmentDetails' as pointer, 'string'::text as json_type, pre_assignment_details as value_text, 'flow_module'::text as object_name, 'pre_assignment_details'::text as column_name from ctr.flow_module where pre_assignment_details is not null
union all
select snapshot_id, nct_id, source_pointer || '/typeUnitsAnalyzed' as pointer, 'string'::text as json_type, type_units_analyzed as value_text, 'flow_module'::text as object_name, 'type_units_analyzed'::text as column_name from ctr.flow_module where type_units_analyzed is not null
union all
select snapshot_id, nct_id, source_pointer || '/id' as pointer, 'string'::text as json_type, group_id as value_text, 'flow_group'::text as object_name, 'group_id'::text as column_name from ctr.flow_group where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'flow_group'::text as object_name, 'title'::text as column_name from ctr.flow_group where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'flow_group'::text as object_name, 'description'::text as column_name from ctr.flow_group where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'flow_period'::text as object_name, 'title'::text as column_name from ctr.flow_period where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/type' as pointer, 'string'::text as json_type, type as value_text, 'flow_milestone'::text as object_name, 'type'::text as column_name from ctr.flow_milestone where type is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'flow_milestone'::text as object_name, 'comment'::text as column_name from ctr.flow_milestone where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'flow_achievement'::text as object_name, 'group_id'::text as column_name from ctr.flow_achievement where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'flow_achievement'::text as object_name, 'comment'::text as column_name from ctr.flow_achievement where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/numSubjects' as pointer, 'string'::text as json_type, num_subjects_text as value_text, 'flow_achievement'::text as object_name, 'num_subjects_text'::text as column_name from ctr.flow_achievement where num_subjects_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/numUnits' as pointer, 'string'::text as json_type, num_units_text as value_text, 'flow_achievement'::text as object_name, 'num_units_text'::text as column_name from ctr.flow_achievement where num_units_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/type' as pointer, 'string'::text as json_type, type as value_text, 'flow_drop_withdraw'::text as object_name, 'type'::text as column_name from ctr.flow_drop_withdraw where type is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'flow_drop_withdraw'::text as object_name, 'comment'::text as column_name from ctr.flow_drop_withdraw where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'flow_drop_reason'::text as object_name, 'group_id'::text as column_name from ctr.flow_drop_reason where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'flow_drop_reason'::text as object_name, 'comment'::text as column_name from ctr.flow_drop_reason where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/numSubjects' as pointer, 'string'::text as json_type, num_subjects_text as value_text, 'flow_drop_reason'::text as object_name, 'num_subjects_text'::text as column_name from ctr.flow_drop_reason where num_subjects_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/populationDescription' as pointer, 'string'::text as json_type, population_description as value_text, 'baseline_module'::text as object_name, 'population_description'::text as column_name from ctr.baseline_module where population_description is not null
union all
select snapshot_id, nct_id, source_pointer || '/typeUnitsAnalyzed' as pointer, 'string'::text as json_type, type_units_analyzed as value_text, 'baseline_module'::text as object_name, 'type_units_analyzed'::text as column_name from ctr.baseline_module where type_units_analyzed is not null
union all
select snapshot_id, nct_id, source_pointer || '/id' as pointer, 'string'::text as json_type, group_id as value_text, 'baseline_group'::text as object_name, 'group_id'::text as column_name from ctr.baseline_group where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'baseline_group'::text as object_name, 'title'::text as column_name from ctr.baseline_group where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'baseline_group'::text as object_name, 'description'::text as column_name from ctr.baseline_group where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/units' as pointer, 'string'::text as json_type, units as value_text, 'baseline_denom'::text as object_name, 'units'::text as column_name from ctr.baseline_denom where units is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'baseline_denom_count'::text as object_name, 'group_id'::text as column_name from ctr.baseline_denom_count where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'baseline_denom_count'::text as object_name, 'value_text'::text as column_name from ctr.baseline_denom_count where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'baseline_measure'::text as object_name, 'title'::text as column_name from ctr.baseline_measure where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'baseline_measure'::text as object_name, 'description'::text as column_name from ctr.baseline_measure where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/populationDescription' as pointer, 'string'::text as json_type, population_description as value_text, 'baseline_measure'::text as object_name, 'population_description'::text as column_name from ctr.baseline_measure where population_description is not null
union all
select snapshot_id, nct_id, source_pointer || '/paramType' as pointer, 'string'::text as json_type, param_type as value_text, 'baseline_measure'::text as object_name, 'param_type'::text as column_name from ctr.baseline_measure where param_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/dispersionType' as pointer, 'string'::text as json_type, dispersion_type as value_text, 'baseline_measure'::text as object_name, 'dispersion_type'::text as column_name from ctr.baseline_measure where dispersion_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/unitOfMeasure' as pointer, 'string'::text as json_type, unit_of_measure as value_text, 'baseline_measure'::text as object_name, 'unit_of_measure'::text as column_name from ctr.baseline_measure where unit_of_measure is not null
union all
select snapshot_id, nct_id, source_pointer || '/calculatePct' as pointer, 'boolean'::text as json_type, case when calculate_pct then 'true' else 'false' end as value_text, 'baseline_measure'::text as object_name, 'calculate_pct'::text as column_name from ctr.baseline_measure where calculate_pct is not null
union all
select snapshot_id, nct_id, source_pointer || '/denomUnitsSelected' as pointer, 'string'::text as json_type, denom_units_selected as value_text, 'baseline_measure'::text as object_name, 'denom_units_selected'::text as column_name from ctr.baseline_measure where denom_units_selected is not null
union all
select snapshot_id, nct_id, source_pointer || '/units' as pointer, 'string'::text as json_type, units as value_text, 'baseline_measure_denom'::text as object_name, 'units'::text as column_name from ctr.baseline_measure_denom where units is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'baseline_measure_denom_count'::text as object_name, 'group_id'::text as column_name from ctr.baseline_measure_denom_count where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'baseline_measure_denom_count'::text as object_name, 'value_text'::text as column_name from ctr.baseline_measure_denom_count where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'baseline_class'::text as object_name, 'title'::text as column_name from ctr.baseline_class where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/units' as pointer, 'string'::text as json_type, units as value_text, 'baseline_class_denom'::text as object_name, 'units'::text as column_name from ctr.baseline_class_denom where units is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'baseline_class_denom_count'::text as object_name, 'group_id'::text as column_name from ctr.baseline_class_denom_count where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'baseline_class_denom_count'::text as object_name, 'value_text'::text as column_name from ctr.baseline_class_denom_count where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'baseline_category'::text as object_name, 'title'::text as column_name from ctr.baseline_category where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'baseline_measurement'::text as object_name, 'group_id'::text as column_name from ctr.baseline_measurement where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'baseline_measurement'::text as object_name, 'value_text'::text as column_name from ctr.baseline_measurement where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/spread' as pointer, 'string'::text as json_type, spread_text as value_text, 'baseline_measurement'::text as object_name, 'spread_text'::text as column_name from ctr.baseline_measurement where spread_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/lowerLimit' as pointer, 'string'::text as json_type, lower_limit_text as value_text, 'baseline_measurement'::text as object_name, 'lower_limit_text'::text as column_name from ctr.baseline_measurement where lower_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/upperLimit' as pointer, 'string'::text as json_type, upper_limit_text as value_text, 'baseline_measurement'::text as object_name, 'upper_limit_text'::text as column_name from ctr.baseline_measurement where upper_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'baseline_measurement'::text as object_name, 'comment'::text as column_name from ctr.baseline_measurement where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/type' as pointer, 'string'::text as json_type, type as value_text, 'outcome_measure'::text as object_name, 'type'::text as column_name from ctr.outcome_measure where type is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'outcome_measure'::text as object_name, 'title'::text as column_name from ctr.outcome_measure where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'outcome_measure'::text as object_name, 'description'::text as column_name from ctr.outcome_measure where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/populationDescription' as pointer, 'string'::text as json_type, population_description as value_text, 'outcome_measure'::text as object_name, 'population_description'::text as column_name from ctr.outcome_measure where population_description is not null
union all
select snapshot_id, nct_id, source_pointer || '/reportingStatus' as pointer, 'string'::text as json_type, reporting_status as value_text, 'outcome_measure'::text as object_name, 'reporting_status'::text as column_name from ctr.outcome_measure where reporting_status is not null
union all
select snapshot_id, nct_id, source_pointer || '/anticipatedPostingDate' as pointer, 'string'::text as json_type, anticipated_posting_date as value_text, 'outcome_measure'::text as object_name, 'anticipated_posting_date'::text as column_name from ctr.outcome_measure where anticipated_posting_date is not null
union all
select snapshot_id, nct_id, source_pointer || '/paramType' as pointer, 'string'::text as json_type, param_type as value_text, 'outcome_measure'::text as object_name, 'param_type'::text as column_name from ctr.outcome_measure where param_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/dispersionType' as pointer, 'string'::text as json_type, dispersion_type as value_text, 'outcome_measure'::text as object_name, 'dispersion_type'::text as column_name from ctr.outcome_measure where dispersion_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/unitOfMeasure' as pointer, 'string'::text as json_type, unit_of_measure as value_text, 'outcome_measure'::text as object_name, 'unit_of_measure'::text as column_name from ctr.outcome_measure where unit_of_measure is not null
union all
select snapshot_id, nct_id, source_pointer || '/calculatePct' as pointer, 'boolean'::text as json_type, case when calculate_pct then 'true' else 'false' end as value_text, 'outcome_measure'::text as object_name, 'calculate_pct'::text as column_name from ctr.outcome_measure where calculate_pct is not null
union all
select snapshot_id, nct_id, source_pointer || '/timeFrame' as pointer, 'string'::text as json_type, time_frame as value_text, 'outcome_measure'::text as object_name, 'time_frame'::text as column_name from ctr.outcome_measure where time_frame is not null
union all
select snapshot_id, nct_id, source_pointer || '/typeUnitsAnalyzed' as pointer, 'string'::text as json_type, type_units_analyzed as value_text, 'outcome_measure'::text as object_name, 'type_units_analyzed'::text as column_name from ctr.outcome_measure where type_units_analyzed is not null
union all
select snapshot_id, nct_id, source_pointer || '/denomUnitsSelected' as pointer, 'string'::text as json_type, denom_units_selected as value_text, 'outcome_measure'::text as object_name, 'denom_units_selected'::text as column_name from ctr.outcome_measure where denom_units_selected is not null
union all
select snapshot_id, nct_id, source_pointer || '/id' as pointer, 'string'::text as json_type, group_id as value_text, 'outcome_group'::text as object_name, 'group_id'::text as column_name from ctr.outcome_group where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'outcome_group'::text as object_name, 'title'::text as column_name from ctr.outcome_group where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'outcome_group'::text as object_name, 'description'::text as column_name from ctr.outcome_group where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/units' as pointer, 'string'::text as json_type, units as value_text, 'outcome_denom'::text as object_name, 'units'::text as column_name from ctr.outcome_denom where units is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'outcome_denom_count'::text as object_name, 'group_id'::text as column_name from ctr.outcome_denom_count where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'outcome_denom_count'::text as object_name, 'value_text'::text as column_name from ctr.outcome_denom_count where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'outcome_class'::text as object_name, 'title'::text as column_name from ctr.outcome_class where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/units' as pointer, 'string'::text as json_type, units as value_text, 'outcome_class_denom'::text as object_name, 'units'::text as column_name from ctr.outcome_class_denom where units is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'outcome_class_denom_count'::text as object_name, 'group_id'::text as column_name from ctr.outcome_class_denom_count where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'outcome_class_denom_count'::text as object_name, 'value_text'::text as column_name from ctr.outcome_class_denom_count where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'outcome_category'::text as object_name, 'title'::text as column_name from ctr.outcome_category where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'outcome_measurement'::text as object_name, 'group_id'::text as column_name from ctr.outcome_measurement where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/value' as pointer, 'string'::text as json_type, value_text as value_text, 'outcome_measurement'::text as object_name, 'value_text'::text as column_name from ctr.outcome_measurement where value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/spread' as pointer, 'string'::text as json_type, spread_text as value_text, 'outcome_measurement'::text as object_name, 'spread_text'::text as column_name from ctr.outcome_measurement where spread_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/lowerLimit' as pointer, 'string'::text as json_type, lower_limit_text as value_text, 'outcome_measurement'::text as object_name, 'lower_limit_text'::text as column_name from ctr.outcome_measurement where lower_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/upperLimit' as pointer, 'string'::text as json_type, upper_limit_text as value_text, 'outcome_measurement'::text as object_name, 'upper_limit_text'::text as column_name from ctr.outcome_measurement where upper_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/comment' as pointer, 'string'::text as json_type, comment as value_text, 'outcome_measurement'::text as object_name, 'comment'::text as column_name from ctr.outcome_measurement where comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/paramType' as pointer, 'string'::text as json_type, param_type as value_text, 'outcome_analysis'::text as object_name, 'param_type'::text as column_name from ctr.outcome_analysis where param_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/paramValue' as pointer, 'string'::text as json_type, param_value_text as value_text, 'outcome_analysis'::text as object_name, 'param_value_text'::text as column_name from ctr.outcome_analysis where param_value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/dispersionType' as pointer, 'string'::text as json_type, dispersion_type as value_text, 'outcome_analysis'::text as object_name, 'dispersion_type'::text as column_name from ctr.outcome_analysis where dispersion_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/dispersionValue' as pointer, 'string'::text as json_type, dispersion_value_text as value_text, 'outcome_analysis'::text as object_name, 'dispersion_value_text'::text as column_name from ctr.outcome_analysis where dispersion_value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/statisticalMethod' as pointer, 'string'::text as json_type, statistical_method as value_text, 'outcome_analysis'::text as object_name, 'statistical_method'::text as column_name from ctr.outcome_analysis where statistical_method is not null
union all
select snapshot_id, nct_id, source_pointer || '/statisticalComment' as pointer, 'string'::text as json_type, statistical_comment as value_text, 'outcome_analysis'::text as object_name, 'statistical_comment'::text as column_name from ctr.outcome_analysis where statistical_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/pValue' as pointer, 'string'::text as json_type, p_value_text as value_text, 'outcome_analysis'::text as object_name, 'p_value_text'::text as column_name from ctr.outcome_analysis where p_value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/pValueComment' as pointer, 'string'::text as json_type, p_value_comment as value_text, 'outcome_analysis'::text as object_name, 'p_value_comment'::text as column_name from ctr.outcome_analysis where p_value_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciNumSides' as pointer, 'string'::text as json_type, ci_num_sides as value_text, 'outcome_analysis'::text as object_name, 'ci_num_sides'::text as column_name from ctr.outcome_analysis where ci_num_sides is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciPctValue' as pointer, 'string'::text as json_type, ci_pct_value_text as value_text, 'outcome_analysis'::text as object_name, 'ci_pct_value_text'::text as column_name from ctr.outcome_analysis where ci_pct_value_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciLowerLimit' as pointer, 'string'::text as json_type, ci_lower_limit_text as value_text, 'outcome_analysis'::text as object_name, 'ci_lower_limit_text'::text as column_name from ctr.outcome_analysis where ci_lower_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciUpperLimit' as pointer, 'string'::text as json_type, ci_upper_limit_text as value_text, 'outcome_analysis'::text as object_name, 'ci_upper_limit_text'::text as column_name from ctr.outcome_analysis where ci_upper_limit_text is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciLowerLimitComment' as pointer, 'string'::text as json_type, ci_lower_limit_comment as value_text, 'outcome_analysis'::text as object_name, 'ci_lower_limit_comment'::text as column_name from ctr.outcome_analysis where ci_lower_limit_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/ciUpperLimitComment' as pointer, 'string'::text as json_type, ci_upper_limit_comment as value_text, 'outcome_analysis'::text as object_name, 'ci_upper_limit_comment'::text as column_name from ctr.outcome_analysis where ci_upper_limit_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/estimateComment' as pointer, 'string'::text as json_type, estimate_comment as value_text, 'outcome_analysis'::text as object_name, 'estimate_comment'::text as column_name from ctr.outcome_analysis where estimate_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/testedNonInferiority' as pointer, 'boolean'::text as json_type, case when tested_non_inferiority then 'true' else 'false' end as value_text, 'outcome_analysis'::text as object_name, 'tested_non_inferiority'::text as column_name from ctr.outcome_analysis where tested_non_inferiority is not null
union all
select snapshot_id, nct_id, source_pointer || '/nonInferiorityType' as pointer, 'string'::text as json_type, non_inferiority_type as value_text, 'outcome_analysis'::text as object_name, 'non_inferiority_type'::text as column_name from ctr.outcome_analysis where non_inferiority_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/nonInferiorityComment' as pointer, 'string'::text as json_type, non_inferiority_comment as value_text, 'outcome_analysis'::text as object_name, 'non_inferiority_comment'::text as column_name from ctr.outcome_analysis where non_inferiority_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/otherAnalysisDescription' as pointer, 'string'::text as json_type, other_analysis_description as value_text, 'outcome_analysis'::text as object_name, 'other_analysis_description'::text as column_name from ctr.outcome_analysis where other_analysis_description is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupDescription' as pointer, 'string'::text as json_type, group_description as value_text, 'outcome_analysis'::text as object_name, 'group_description'::text as column_name from ctr.outcome_analysis where group_description is not null
union all
select snapshot_id, nct_id, source_pointer as pointer, 'string'::text as json_type, group_id as value_text, 'outcome_analysis_group'::text as object_name, 'group_id'::text as column_name from ctr.outcome_analysis_group
union all
select snapshot_id, nct_id, source_pointer || '/frequencyThreshold' as pointer, 'string'::text as json_type, frequency_threshold as value_text, 'ae_module'::text as object_name, 'frequency_threshold'::text as column_name from ctr.ae_module where frequency_threshold is not null
union all
select snapshot_id, nct_id, source_pointer || '/timeFrame' as pointer, 'string'::text as json_type, time_frame as value_text, 'ae_module'::text as object_name, 'time_frame'::text as column_name from ctr.ae_module where time_frame is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'ae_module'::text as object_name, 'description'::text as column_name from ctr.ae_module where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/allCauseMortalityComment' as pointer, 'string'::text as json_type, all_cause_mortality_comment as value_text, 'ae_module'::text as object_name, 'all_cause_mortality_comment'::text as column_name from ctr.ae_module where all_cause_mortality_comment is not null
union all
select snapshot_id, nct_id, source_pointer || '/id' as pointer, 'string'::text as json_type, group_id as value_text, 'ae_group'::text as object_name, 'group_id'::text as column_name from ctr.ae_group where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/title' as pointer, 'string'::text as json_type, title as value_text, 'ae_group'::text as object_name, 'title'::text as column_name from ctr.ae_group where title is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, description as value_text, 'ae_group'::text as object_name, 'description'::text as column_name from ctr.ae_group where description is not null
union all
select snapshot_id, nct_id, source_pointer || '/deathsNumAffected' as pointer, 'number'::text as json_type, deaths_num_affected::text as value_text, 'ae_group'::text as object_name, 'deaths_num_affected'::text as column_name from ctr.ae_group where deaths_num_affected is not null
union all
select snapshot_id, nct_id, source_pointer || '/deathsNumAtRisk' as pointer, 'number'::text as json_type, deaths_num_at_risk::text as value_text, 'ae_group'::text as object_name, 'deaths_num_at_risk'::text as column_name from ctr.ae_group where deaths_num_at_risk is not null
union all
select snapshot_id, nct_id, source_pointer || '/seriousNumAffected' as pointer, 'number'::text as json_type, serious_num_affected::text as value_text, 'ae_group'::text as object_name, 'serious_num_affected'::text as column_name from ctr.ae_group where serious_num_affected is not null
union all
select snapshot_id, nct_id, source_pointer || '/seriousNumAtRisk' as pointer, 'number'::text as json_type, serious_num_at_risk::text as value_text, 'ae_group'::text as object_name, 'serious_num_at_risk'::text as column_name from ctr.ae_group where serious_num_at_risk is not null
union all
select snapshot_id, nct_id, source_pointer || '/otherNumAffected' as pointer, 'number'::text as json_type, other_num_affected::text as value_text, 'ae_group'::text as object_name, 'other_num_affected'::text as column_name from ctr.ae_group where other_num_affected is not null
union all
select snapshot_id, nct_id, source_pointer || '/otherNumAtRisk' as pointer, 'number'::text as json_type, other_num_at_risk::text as value_text, 'ae_group'::text as object_name, 'other_num_at_risk'::text as column_name from ctr.ae_group where other_num_at_risk is not null
union all
select snapshot_id, nct_id, source_pointer || '/term' as pointer, 'string'::text as json_type, term as value_text, 'ae_event'::text as object_name, 'term'::text as column_name from ctr.ae_event where term is not null
union all
select snapshot_id, nct_id, source_pointer || '/organSystem' as pointer, 'string'::text as json_type, organ_system as value_text, 'ae_event'::text as object_name, 'organ_system'::text as column_name from ctr.ae_event where organ_system is not null
union all
select snapshot_id, nct_id, source_pointer || '/sourceVocabulary' as pointer, 'string'::text as json_type, source_vocabulary as value_text, 'ae_event'::text as object_name, 'source_vocabulary'::text as column_name from ctr.ae_event where source_vocabulary is not null
union all
select snapshot_id, nct_id, source_pointer || '/assessmentType' as pointer, 'string'::text as json_type, assessment_type as value_text, 'ae_event'::text as object_name, 'assessment_type'::text as column_name from ctr.ae_event where assessment_type is not null
union all
select snapshot_id, nct_id, source_pointer || '/notes' as pointer, 'string'::text as json_type, notes as value_text, 'ae_event'::text as object_name, 'notes'::text as column_name from ctr.ae_event where notes is not null
union all
select snapshot_id, nct_id, source_pointer || '/groupId' as pointer, 'string'::text as json_type, group_id as value_text, 'ae_event_stat'::text as object_name, 'group_id'::text as column_name from ctr.ae_event_stat where group_id is not null
union all
select snapshot_id, nct_id, source_pointer || '/numEvents' as pointer, 'number'::text as json_type, num_events::text as value_text, 'ae_event_stat'::text as object_name, 'num_events'::text as column_name from ctr.ae_event_stat where num_events is not null
union all
select snapshot_id, nct_id, source_pointer || '/numAffected' as pointer, 'number'::text as json_type, num_affected::text as value_text, 'ae_event_stat'::text as object_name, 'num_affected'::text as column_name from ctr.ae_event_stat where num_affected is not null
union all
select snapshot_id, nct_id, source_pointer || '/numAtRisk' as pointer, 'number'::text as json_type, num_at_risk::text as value_text, 'ae_event_stat'::text as object_name, 'num_at_risk'::text as column_name from ctr.ae_event_stat where num_at_risk is not null
union all
select snapshot_id, nct_id, source_pointer || '/description' as pointer, 'string'::text as json_type, limitations_and_caveats as value_text, 'more_info'::text as object_name, 'limitations_and_caveats'::text as column_name from ctr.more_info where limitations_and_caveats is not null;
