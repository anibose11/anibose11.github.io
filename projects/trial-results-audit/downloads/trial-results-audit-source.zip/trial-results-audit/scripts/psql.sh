#!/bin/sh
# Open psql on the project-local cluster (start it first with: python -m tra db start).
# Uses the same TRA_PG_PORT and TRA_PG_BIN settings as the pipeline.
HERE="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${TRA_PG_PORT:-55432}"
PSQL=""
if [ -n "$TRA_PG_BIN" ]; then
  PSQL="$TRA_PG_BIN/psql"
else
  for d in /opt/homebrew/opt/postgresql@17/bin /usr/local/opt/postgresql@17/bin /usr/lib/postgresql/17/bin; do
    if [ -x "$d/psql" ]; then PSQL="$d/psql"; break; fi
  done
  PSQL="${PSQL:-psql}"
fi
exec "$PSQL" -h "$HERE/.pgsock" -p "$PORT" -U tra -d trial_results -X "$@"
