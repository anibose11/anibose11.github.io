# Contribution decision

Written 2026-10-07 (UTC) after the literature and tool review and after work on the development portion, before the parser freeze and before any held-out result was computed. The development-portion tier distribution was known when this was written; the held-out results were not.

## Who would use the output and what decision it supports

The users are a research analyst who builds an evidence table or extracts data for a systematic review from ClinicalTrials.gov posted results, and the data engineer who maintains the pipeline that feeds that table. The decision is practical: for each result row, which participant count belongs with it, and whether an ordinary flat export of the registry results is safe to use for that purpose or silently attaches the wrong count. The output is not meant for patients or for judging whether a treatment works.

## What is already established

- Zarin, Tse and colleagues (N Engl J Med 2011) described the results database, called the analysis population the "denominator" of each posted result, and found an average of 2.5 distinct analysis populations per study group across 700 records. That paper established the concept this project measures.
- Schwartz and colleagues (Ann Intern Med 2016) found the number analyzed for the primary outcome discordant with FDA reviews for 42 of 137 primary outcomes, in a diabetes-heavy sample of approval trials. Riveros and colleagues (PLoS Med 2013) found the number analyzed per group reported in 96% of sampled posted results, with reasons for exclusion reported in 8%. Hartung and colleagues (Ann Intern Med 2014) recorded denominator inconsistencies and arm transpositions between registry and publication.
- Tse, Fain and Zarin (BMJ 2018) explained that most results elements were available only as XML because results tables vary in shape, which is why flat downloads handle them poorly.
- AACT (Tasneem and colleagues, PLoS One 2012, maintained by CTTI) already loads results into relational tables. Shi and Du (Sci Data 2024) built a finer-grained arm-level representation and knowledge graph, matching groups across sections semantically. EXACT (Pradhan and colleagues, J Clin Epidemiol 2019) extracts results into spreadsheets for meta-analysis and left some conversions to the user.

So "a database of trial results" is not new, and neither is the observation that analysis populations vary across outcomes.

## The narrow unresolved question

In current API v2 results for a recent, defined cohort, how often can a participant denominator be attached to each reported value by written rules alone, how often does that need an explicit rule (row-level counts, other analysis units), and how often is it not safely resolvable? And what does an ordinary one-row-per-value flat export lose or misattach for the same values, measured scalar by scalar against the source rather than asserted? None of the papers above reports this at the level of every measurement, with an independent reference for the transformation and a declared flat comparator.

## Comparator and estimand

- Comparator: a declared flat export that follows the `json_normalize` convention, keeps all values as text, and attaches the outcome-level participant count to each value row (`docs/analysis_plan.md`). It is deliberately generous; ClinicalTrials.gov's own CSV download carries no posted results data (correction 2026-10-07: it has a has-results flag and the results first posted date, but no results tables).
- Primary estimand: the distribution of held-out outcome groups across tiers A, B and C (D reported separately), as a finite-corpus description.
- Key secondary estimands: the share of measurements whose flat-export count is not the applicable one; scalar-level retention by field family; warehouse fidelity against the R reference.

## Framing

This is an update and extension of the Zarin 2011 denominator framing to API v2 data from 2020 to 2026, delivered as a reusable preservation and audit method (warehouse, rules, checks, ledger and reference) with measured limitations. It is not presented as the first database of results, the first study of analysis populations, or a validation of clinical truth. Any comparison with AACT is qualitative, from its documentation, because AACT was not run here.

## What would count as a useful negative result

If nearly all held-out outcome groups were tier A and the flat export attached the applicable count to nearly every value, the useful conclusion would be that a simple flat export with an outcome-level count is adequate for this cohort and that the extra machinery is not needed for denominator purposes. That result would be reported as such. A finding that the warehouse loses or alters source values would be reported as a transformation defect, not hidden.

## What would not count as a contribution

A different title, newer data alone, more tests, or a dashboard. One analysis produces one paper; the warehouse code and the paper are not split into overlapping papers.
