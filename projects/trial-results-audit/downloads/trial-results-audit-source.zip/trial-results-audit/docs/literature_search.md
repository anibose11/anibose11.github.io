# Literature and tool search

All searches were run on 2026-10-07, before any held-out result was computed. Databases: PubMed (NCBI E-utilities `esearch`, `esummary`, `efetch`), Europe PMC REST search, Crossref REST (`/works/<doi>`) for bibliographic checks, and general web search for tools and grey literature. Every included item was checked a second time against PubMed or Crossref, and key numbers were re-read in the source text. Items that could not be verified were dropped.

## Search strings (reproducible)

PubMed:

1. `"ClinicalTrials.gov"[tiab] AND ("participants analyzed"[tiab] OR "number analyzed"[tiab] OR "numbers analyzed"[tiab] OR "analysis population"[tiab] OR "analysis populations"[tiab] OR denominator*[tiab])` (238 hits)
2. `"ClinicalTrials.gov"[ti] AND (results[ti] OR reporting[ti]) AND (publication*[ti] OR publications[ti] OR journal*[ti] OR articles[ti])` (23 hits)
3. `"ClinicalTrials.gov"[tiab] AND ("results database"[tiab]) AND (quality[tiab] OR structure[tiab] OR "outcome measure"[tiab])` (15 hits)
4. `"ClinicalTrials.gov"[tiab] AND ("data quality"[tiab] OR "machine readable"[tiab] OR "machine-readable"[tiab] OR metadata[tiab] OR "data structure"[tiab] OR interoperab*[tiab] OR "unit of measure"[tiab] OR "units of measure"[tiab])` (228 hits)
5. `"clinicaltrials.gov"[tiab] AND (automat*[tiab] OR "automatic extraction"[tiab]) AND (meta-analys*[tiab] OR "evidence synthesis"[tiab] OR "systematic review"[tiab])` (98 hits)
6. `"clinicaltrials.gov"[tiab] AND ("relational database"[tiab] OR "AACT"[tiab] OR "Aggregate Analysis of ClinicalTrials.gov"[tiab] OR "knowledge graph"[tiab] OR XML[tiab] OR JSON[tiab] OR "application programming interface"[tiab])` (54 hits)
7. `("extract, transform, load"[tiab] OR "extract-transform-load"[tiab] OR ETL[tiab]) AND ("data quality"[tiab] OR fidelity[tiab] OR "information loss"[tiab] OR "semantic loss"[tiab] OR validation[tiab] OR provenance[tiab])` (104 hits, mostly EHR pipelines)
8. `(FHIR[tiab] OR "nested"[tiab] OR JSON[tiab] OR hierarchical[tiab]) AND (flatten*[tiab] OR "tabular"[tiab] OR relational[tiab]) AND (clinical[tiab] OR health[tiab]) AND ("information loss"[tiab] OR "data loss"[tiab] OR fidelity[tiab] OR provenance[tiab] OR "semantic"[tiab])` (23 hits; none measured loss from flattening registry results)
9. `("clinicaltrials.gov"[ti] OR "trial registry"[ti] OR "trial registries"[ti] OR "registered trials"[ti] OR "registered clinical trials"[ti]) AND (diabet*[ti] OR "heart failure"[ti] OR obes*[ti] OR cardiovascular[ti] OR cardiometabolic[ti] OR "weight"[ti] OR cardiology[ti] OR GLP-1[ti] OR SGLT2[ti])` (29 hits)
10. Author-anchored checks: `Zarin DA[au] AND "results database" AND N Engl J Med[ta] AND 2011[dp]`; `Tse T[au] AND ClinicalTrials.gov AND BMJ[ta] AND 2018[dp]`; `Riveros C[au] AND ClinicalTrials.gov AND 2013[dp]`; `Becker JE[au] AND ClinicalTrials.gov AND JAMA[ta] AND 2014[dp]`; `DeVito NJ[au] AND Goldacre B[au] AND Lancet[ta] AND 2020[dp]`; `Hartung DM[au] AND ClinicalTrials.gov`.
11. `(intention-to-treat[ti] OR "intention to treat"[ti]) AND (modified[tiab]) AND (systematic review[tiab] OR survey[tiab]) AND (reporting[tiab])` (4 hits)

Europe PMC:

12. `TITLE_ABS:"ClinicalTrials.gov" AND TITLE_ABS:("results database" OR "posted results" OR "summary results") AND TITLE_ABS:("data quality" OR "machine-readable" OR "machine readable" OR "structured data" OR "unit of measure" OR "units of measure" OR "data structure" OR schema)` (4 hits)
13. `TITLE_ABS:"clinicaltrials.gov" AND TITLE_ABS:"results" AND (TITLE_ABS:"structured" OR TITLE_ABS:"machine-readable" OR TITLE_ABS:"reuse") AND (TITLE_ABS:"meta-analysis" OR TITLE_ABS:"evidence synthesis")` (109 hits)
14. `PMCID:PMC4617780` (the starting article, Hartung and colleagues 2014)


## Inclusion

Included items (full text read unless stated):

| Item | Why included |
|---|---|
| Zarin and colleagues, N Engl J Med 2011 (doi:10.1056/NEJMsa1012065) | Defines the analysis population as the denominator of each posted result |
| Hartung and colleagues, Ann Intern Med 2014 (doi:10.7326/M13-0480) | Registry-publication discrepancies, including denominator inconsistencies and arm transpositions |
| Schwartz and colleagues, Ann Intern Med 2016 (doi:10.7326/M15-2658) | Number-analyzed and analysis-population discordance against FDA reviews |
| Riveros and colleagues, PLoS Med 2013 (doi:10.1371/journal.pmed.1001566) | Completeness of number analyzed and reasons for exclusion in posted results |
| Becker and colleagues, JAMA 2014 (doi:10.1001/jama.2013.285634) | Registry-publication comparisons that could not be made because of format and population differences |
| Talebi, Redberg and Ross, Trials 2020 (doi:10.1186/s13063-020-04603-9) | Persisting inconsistency after FDAAA |
| Zarin and colleagues, N Engl J Med 2019 (doi:10.1056/NEJMsr1907644) | Quality-control issues in results submissions, including units and internal inconsistencies |
| Tse, Fain and Zarin, BMJ 2018 (doi:10.1136/bmj.k1452) | Why results tables resist flat download; provenance and change over time |
| Miron, Gonçalves and Musen, Sci Data 2020 (doi:10.1038/s41597-020-00780-z) | Type and schema conformance of registry metadata |
| Shi and Du, Sci Data 2024 (doi:10.1038/s41597-023-02869-7) | Finer-grained restructuring of posted results |
| Pradhan and colleagues, J Clin Epidemiol 2019 (doi:10.1016/j.jclinepi.2018.08.023) | Automatic extraction of results for meta-analysis |
| Tasneem and colleagues, PLoS One 2012 (doi:10.1371/journal.pone.0033677) | AACT relational database |
| Abraha and Montedori, BMJ 2010 (doi:10.1136/bmj.c2697) | Instability of modified intention-to-treat labels |
| DeVito, Bacon and Goldacre, Lancet 2020 (doi:10.1016/S0140-6736(19)33220-9) | Reproducible full-registry processing; who posts results |
| Tse, Williams and Zarin, Chest 2009 (doi:10.1378/chest.08-3022; bibliographic record and front matter) | Start of basic results reporting in 2008, cited with Zarin 2011 |
| Zarin and colleagues, N Engl J Med 2016 (doi:10.1056/NEJMsr1611785) | The Final Rule and its 2017 effective date |
| Baudard and colleagues, BMJ 2017 (doi:10.1136/bmj.j448) | Systematic reviews that use registry results |
| Dechartres and colleagues, BMC Med 2016 (doi:10.1186/s12916-016-0740-1) | Recomputing effects from posted per-arm values |
| Earley, Lau and Uhlig, BMJ Open 2013 (doi:10.1136/bmjopen-2012-001963) | Deaths reported in more than one module |
| Yu and colleagues, BMC Med Res Methodol 2024 (doi:10.1186/s12874-024-02225-2; abstract) | Rapid safety meta-analyses emulated from posted results |
| Steinberg and colleagues, BMC Med Res Methodol 2023 (doi:10.1186/s12874-023-02025-0; abstract) | Benchmark of drug-versus-drug adverse event comparisons built from trial reports (TrialProbe) |
| van Essen and colleagues, J Med Internet Res 2025 (doi:10.2196/64628) | Two pipelines on the same source give different datasets |
| Herold, ctrdata (Res Synth Methods; doi:10.1017/rsm.2025.10061; partly read) | R package that retrieves and stores registry records, including ClinicalTrials.gov results, as documents |

Domain background read as abstracts only: Šaler and colleagues on SGLT2 inhibitor trial safety reporting (J Clin Epidemiol 2026) and Psotka and colleagues on heart failure trial publication (J Am Coll Cardiol 2020).

Excluded after screening (reason): correspondence and authors' replies; conference posters that could not be accessed; registration-data quality studies not about results (Chaturvedi 2019, Iken 2024, Keuchel and Spicher); EHR provenance papers without registry relevance; preprints without a peer-reviewed version (Thiele and colleagues); clinical systematic reviews that merely used ClinicalTrials.gov data.

`docs/prior_art.csv` lists the five closest items with their task, methods, relevant limitation, overlap and what this project adds.
