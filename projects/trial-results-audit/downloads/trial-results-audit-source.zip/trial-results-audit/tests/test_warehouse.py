"""Warehouse loading, idempotency, transactions, constraints, round trip and reconciliation on synthetic fixtures."""
from __future__ import annotations

import json

import psycopg
import pytest

from tra import pg
from tra.etl import load_snapshot, table_fingerprint
from tra.reference import leaf_view_sql, load_reference
from tra.roundtrip import roundtrip

from conftest import SNAPSHOT


def test_load_has_no_exceptions_or_unmapped_keys(loaded):
    assert loaded["n_studies_in_scope"] == 7
    assert loaded["n_result_load_exceptions"] == 0
    assert loaded["unknown_source_keys"] == {}


def test_repeat_load_is_idempotent(loaded, test_db, fixture_snapshot):
    raw_dir, frozen_dir = fixture_snapshot
    with pg.connect(test_db) as conn:
        before = table_fingerprint(conn, SNAPSHOT)
        report = load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)
        conn.commit()
        after = table_fingerprint(conn, SNAPSHOT)
        actions = [r[0] for r in conn.execute("select action from ctr.load_run where snapshot_id=%s order by load_run_id",
                                               (SNAPSHOT,)).fetchall()]
    assert before == after
    assert report["n_studies_replaced"] == 7
    assert actions[-1] == "reloaded_identical"


def test_changed_reload_is_not_recorded_as_identical(loaded, test_db, fixture_snapshot, tmp_path):
    import json as _json
    import shutil
    raw_dir, frozen_dir = fixture_snapshot
    alt_raw = tmp_path / "raw"
    shutil.copytree(raw_dir, alt_raw)
    page_path = alt_raw / "study_pages" / "batch_0000.json"
    page = _json.loads(page_path.read_text())
    page["studies"][0]["resultsSection"]["outcomeMeasuresModule"]["outcomeMeasures"][0]["classes"][0]["categories"][0][
        "measurements"][0]["value"] = "999.9"
    page_path.write_text(_json.dumps(page))
    with pg.connect(test_db) as conn:
        load_snapshot(conn, {"development"}, SNAPSHOT, alt_raw, frozen_dir)
        conn.commit()
        changed = conn.execute("select action from ctr.load_run order by load_run_id desc limit 1").fetchone()[0]
        load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)  # restore the original fixture state
        conn.commit()
    assert changed == "reloaded_changed"


def test_failed_load_rolls_back(loaded, test_db, fixture_snapshot, monkeypatch):
    raw_dir, frozen_dir = fixture_snapshot
    import tra.etl as etl
    with pg.connect(test_db) as conn:
        before = table_fingerprint(conn, SNAPSHOT)

    def boom(*a, **k):
        raise RuntimeError("simulated failure during load")

    monkeypatch.setattr(etl, "table_fingerprint", boom)
    with pg.connect(test_db) as conn:
        with pytest.raises(RuntimeError):
            etl.load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)
    monkeypatch.undo()
    with pg.connect(test_db) as conn:
        assert table_fingerprint(conn, SNAPSHOT) == before


def test_k8_pointer_resolves_to_a_source_field(loaded, test_db, fixture_snapshot):
    import json as _json
    raw_dir, _ = fixture_snapshot
    page = _json.loads((raw_dir / "study_pages" / "batch_0000.json").read_text())
    with pg.connect(test_db) as conn:
        ptrs = [r[0] for r in conn.execute("select pointer from audit.v_check where check_id='K8' and status='fail'").fetchall()]
    assert ptrs
    study = [s for s in page["studies"] if s["protocolSection"]["identificationModule"]["nctId"] == "NCT99000002"][0]
    for p in ptrs:
        node = study
        for part in p.strip("/").split("/"):
            node = node[int(part)] if isinstance(node, list) else node[part]
        assert isinstance(node, int)


def test_group_ids_are_scoped_to_their_outcome(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = conn.execute("select outcome_ordinal, title from ctr.outcome_group where nct_id='NCT99000003' and group_id='OG000' "
                            "order by outcome_ordinal").fetchall()
    assert rows == [(0, "Placebo"), (1, "Drug B")]


def test_measurement_with_undeclared_group_is_rejected_by_constraint(loaded, test_db):
    with pg.connect(test_db) as conn:
        with pytest.raises(psycopg.errors.ForeignKeyViolation):
            conn.execute("insert into ctr.outcome_measurement (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, "
                         "measurement_ordinal, group_id, value_text, source_pointer) values (%s,'NCT99000001',0,0,0,9,'OG999','1','x')",
                         (SNAPSHOT,))
        conn.rollback()


def test_events_and_participants_stay_separate(loaded, test_db):
    with pg.connect(test_db) as conn:
        row = conn.execute("select num_events, num_affected, num_at_risk from ctr.ae_event_stat where nct_id='NCT99000002' "
                           "and seriousness='serious' and group_id='EG000'").fetchone()
    assert row == (7, 3, 20)


def test_crossover_periods_are_not_summed(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = conn.execute("select p.title, a.group_id, a.num_subjects_int from ctr.flow_achievement a join ctr.flow_period p "
                            "using (snapshot_id, nct_id, period_ordinal) join ctr.flow_milestone m "
                            "using (snapshot_id, nct_id, period_ordinal, milestone_ordinal) where a.nct_id='NCT99000004' "
                            "and m.type='STARTED' order by p.period_ordinal, a.group_id").fetchall()
    assert rows == [("Period 1", "FG000", 15), ("Period 1", "FG001", 15), ("Period 2", "FG000", 14), ("Period 2", "FG001", 15)]


def test_exact_text_and_numeric_parsing(loaded, test_db):
    with pg.connect(test_db) as conn:
        val = conn.execute("select value_text, value_num from ctr.outcome_measurement where nct_id='NCT99000006' "
                           "and outcome_ordinal=0 and group_id='OG000'").fetchone()
        lsm = conn.execute("select value_text, value_num::text from ctr.outcome_measurement where nct_id='NCT99000001' "
                           "and outcome_ordinal=0 and group_id='OG000'").fetchone()
        pval = conn.execute("select p_value_text from ctr.outcome_analysis where nct_id='NCT99000001'").fetchone()[0]
    assert val == ("1,169.62", None)
    assert lsm == ("-1.10", "-1.10")
    assert pval == "<0.001"


def test_point_of_contact_is_not_loaded(loaded, test_db):
    with pg.connect(test_db) as conn:
        in_raw = conn.execute("select count(*) from ctr.raw_study where record::text like '%%example.invalid%%' "
                              "or record #> '{resultsSection,moreInfoModule,pointOfContact}' is not null").fetchone()[0]
        cols = {r[0] for r in conn.execute("select column_name from information_schema.columns where table_schema='ctr'").fetchall()}
        kept = conn.execute("select limitations_and_caveats from ctr.more_info where nct_id='NCT99000005'").fetchone()[0]
    assert in_raw == 0
    assert kept == "Terminated early; small sample."
    assert not any("email" in c or "phone" in c for c in cols)


def test_round_trip_rebuilds_every_module(loaded, test_db, fixture_snapshot):
    raw_dir, _ = fixture_snapshot
    ids = {"NCT99000001", "NCT99000002", "NCT99000003", "NCT99000004", "NCT99000005", "NCT99000006"}
    with pg.connect(test_db) as conn:
        r = roundtrip(conn, SNAPSHOT, raw_dir, ids)
    assert r["n_differing"] == 0, r["differing"]
    assert r["identical"] == r["n"] > 0


def test_leaf_reconciliation_against_r_reference(loaded, test_db, reference_out):
    with pg.connect(test_db) as conn:
        conn.execute(leaf_view_sql())
        load_reference(conn, reference_out, SNAPSHOT)
        conn.commit()
        rows = conn.execute("""
            select case when w.pointer is null and r.json_type = 'excluded' then 'excluded'
                        when w.pointer is null then 'missing' when r.pointer is null then 'extra'
                        when w.value_text is distinct from r.value_text then 'differs' else 'match' end, count(*)
            from ctr.v_leaf w full outer join ref.leaf r using (snapshot_id, nct_id, pointer)
            where coalesce(w.snapshot_id, r.snapshot_id) = %s group by 1""", (SNAPSHOT,)).fetchall()
    status = dict(rows)
    assert set(status) <= {"match", "excluded"}
    assert status["excluded"] == 4  # the four point-of-contact fields in fixture 5


def test_r_reference_redacts_excluded_values(reference_out):
    text = (reference_out / "leaves.copy").read_text()
    assert "example.invalid" not in text and "000-000-0000" not in text
