"""Generate the synthetic regression fixtures (software tests only; never mixed with registry observations).

Each fixture is a small study in ClinicalTrials.gov API v2 JSON shape with NCT numbers in the 99000000 range,
which the registry does not use. Run: python tests/fixtures/make_fixtures.py
"""
import json
from pathlib import Path

HERE = Path(__file__).parent


def proto(nct, title, conditions, mesh):
    return {
        "identificationModule": {"nctId": nct, "orgStudyIdInfo": {"id": f"FIXTURE-{nct[-4:]}"},
                                 "organization": {"fullName": "Fixture Organization", "class": "OTHER"},
                                 "briefTitle": title, "officialTitle": title + " (synthetic fixture)"},
        "statusModule": {"overallStatus": "COMPLETED", "resultsFirstSubmitDate": "2021-01-05",
                         "resultsFirstPostDateStruct": {"date": "2021-02-01", "type": "ACTUAL"},
                         "lastUpdatePostDateStruct": {"date": "2021-02-01", "type": "ACTUAL"},
                         "completionDateStruct": {"date": "2020-06", "type": "ACTUAL"}},
        "conditionsModule": {"conditions": conditions},
        "designModule": {"studyType": "INTERVENTIONAL", "phases": ["PHASE3"],
                         "designInfo": {"allocation": "RANDOMIZED", "interventionModel": "PARALLEL",
                                        "primaryPurpose": "TREATMENT", "maskingInfo": {"masking": "DOUBLE"}},
                         "enrollmentInfo": {"count": 100, "type": "ACTUAL"}},
    }, {"conditionBrowseModule": {"meshes": mesh, "ancestors": []}}


def denom(units, counts):
    return {"units": units, "counts": [{"groupId": g, "value": v} for g, v in counts]}


def meas(g, value, **kw):
    d = {"groupId": g, "value": value}
    d.update(kw)
    return d


def study(nct, title, rs, conditions=("Type 2 Diabetes",), mesh=({"id": "D003924", "term": "Diabetes Mellitus, Type 2"},)):
    p, d = proto(nct, title, list(conditions), list(mesh))
    return {"protocolSection": p, "derivedSection": d, "resultsSection": rs, "hasResults": True}


OG2 = [{"id": "OG000", "title": "Drug A", "description": "Drug A daily"},
       {"id": "OG001", "title": "Placebo", "description": "Matching placebo"}]

# 1. Unequal denominators that are legitimate, multiple time points with row-specific numbers analyzed.
s1 = study("NCT99000001", "Unequal denominators and time points", {
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "Change in HbA1c", "populationDescription": "All randomized participants with a baseline and post-baseline value.",
         "reportingStatus": "POSTED", "paramType": "LEAST_SQUARES_MEAN", "dispersionType": "Standard Error",
         "unitOfMeasure": "percentage of HbA1c", "timeFrame": "Baseline, Week 26", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "48"), ("OG001", "45")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "-1.10", spread="0.08"), meas("OG001", "-0.20", spread="0.09")]}]}],
         "analyses": [{"paramType": "Mean Difference (Net)", "paramValue": "-0.90", "ciPctValue": "95", "ciNumSides": "TWO_SIDED",
                       "ciLowerLimit": "-1.12", "ciUpperLimit": "-0.68", "pValue": "<0.001", "statisticalMethod": "ANCOVA",
                       "groupIds": ["OG000", "OG001"]}]},
        {"type": "SECONDARY", "title": "Fasting plasma glucose over time", "reportingStatus": "POSTED", "paramType": "MEAN",
         "dispersionType": "Standard Deviation", "unitOfMeasure": "mg/dL", "timeFrame": "Week 12, Week 26, Week 52",
         "groups": OG2, "denoms": [denom("Participants", [("OG000", "50"), ("OG001", "50")])],
         "classes": [
             {"title": "Week 12", "denoms": [denom("Participants", [("OG000", "49"), ("OG001", "50")])],
              "categories": [{"measurements": [meas("OG000", "140.2", spread="20.1"), meas("OG001", "151.0", spread="22.4")]}]},
             {"title": "Week 26", "denoms": [denom("Participants", [("OG000", "47"), ("OG001", "44")])],
              "categories": [{"measurements": [meas("OG000", "135.9", spread="19.8"), meas("OG001", "150.3", spread="23.0")]}]},
             {"title": "Week 52", "denoms": [denom("Participants", [("OG000", "40"), ("OG001", "39")])],
              "categories": [{"measurements": [meas("OG000", "133.4", spread="21.0"), meas("OG001", "149.8", spread="24.6")]}]}]},
        {"type": "SECONDARY", "title": "Participants reaching HbA1c below 7%", "reportingStatus": "POSTED",
         "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants", "timeFrame": "Week 26", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "48"), ("OG001", "45")])],
         "classes": [{"categories": [{"title": "Yes", "measurements": [meas("OG000", "30"), meas("OG001", "12")]},
                                     {"title": "No", "measurements": [meas("OG000", "18"), meas("OG001", "33")]}]}]},
    ]}})

# 2. Events versus participants; check K1 failure; check K7 failure.
s2 = study("NCT99000002", "Events and participants", {
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "Number of participants with hypoglycaemia", "reportingStatus": "POSTED",
         "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants", "timeFrame": "52 weeks", "groups": OG2,
         "denomUnitsSelected": "\tParticipants\n",
         "denoms": [denom("Participants\n", [("OG000", "20"), ("OG001", "20")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "25"), meas("OG001", "4")]}]}]},
        {"type": "SECONDARY", "title": "Percentage of participants with nausea", "reportingStatus": "POSTED",
         "paramType": "NUMBER", "unitOfMeasure": "percentage of participants", "timeFrame": "52 weeks", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "20"), ("OG001", "20")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "135"), meas("OG001", "10")]}]}]},
    ]},
    "adverseEventsModule": {"frequencyThreshold": "5", "timeFrame": "52 weeks",
        "eventGroups": [{"id": "EG000", "title": "Drug A", "seriousNumAffected": 3, "seriousNumAtRisk": 20,
                         "otherNumAffected": 15, "otherNumAtRisk": 20},
                        {"id": "EG001", "title": "Placebo", "seriousNumAffected": 1, "seriousNumAtRisk": 20,
                         "otherNumAffected": 21, "otherNumAtRisk": 20}],
        "seriousEvents": [{"term": "Hypoglycaemia", "organSystem": "Metabolism and nutrition disorders",
                           "sourceVocabulary": "MedDRA 23.0", "assessmentType": "SYSTEMATIC_ASSESSMENT",
                           "stats": [{"groupId": "EG000", "numEvents": 7, "numAffected": 3, "numAtRisk": 20},
                                     {"groupId": "EG001", "numEvents": 1, "numAffected": 1, "numAtRisk": 20}]}],
        "otherEvents": [{"term": "Nausea", "organSystem": "Gastrointestinal disorders", "assessmentType": "SYSTEMATIC_ASSESSMENT",
                         "stats": [{"groupId": "EG000", "numEvents": 4, "numAffected": 6, "numAtRisk": 20},
                                   {"groupId": "EG001", "numEvents": 2, "numAffected": 2, "numAtRisk": 20}]}]}})

# 3. Similarly named groups across modules with different populations; OG000 means different arms in two outcomes.
s3 = study("NCT99000003", "Same labels, different populations", {
    "participantFlowModule": {"groups": [{"id": "FG000", "title": "Placebo"}, {"id": "FG001", "title": "Drug B"}],
        "periods": [{"title": "Overall Study", "milestones": [
            {"type": "STARTED", "achievements": [{"groupId": "FG000", "numSubjects": "52"}, {"groupId": "FG001", "numSubjects": "51"}]},
            {"type": "COMPLETED", "achievements": [{"groupId": "FG000", "numSubjects": "46"}, {"groupId": "FG001", "numSubjects": "47"}]}],
            "dropWithdraws": [{"type": "Withdrawal by Subject", "reasons": [{"groupId": "FG000", "numSubjects": "6"}, {"groupId": "FG001", "numSubjects": "4"}]}]}]},
    "baselineCharacteristicsModule": {"populationDescription": "All randomized participants.",
        "groups": [{"id": "BG000", "title": "Placebo"}, {"id": "BG001", "title": "Drug B"}, {"id": "BG002", "title": "Total"}],
        "denoms": [denom("Participants", [("BG000", "52"), ("BG001", "51"), ("BG002", "103")])],
        "measures": [{"title": "Age, Continuous", "paramType": "MEAN", "dispersionType": "STANDARD_DEVIATION", "unitOfMeasure": "years",
                      "classes": [{"categories": [{"measurements": [meas("BG000", "58.1", spread="9.2"), meas("BG001", "57.4", spread="8.8"),
                                                                   meas("BG002", "57.8", spread="9.0")]}]}]},
                     {"title": "Sex: Female, Male", "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants",
                      "classes": [{"categories": [{"title": "Female", "measurements": [meas("BG000", "60"), meas("BG001", "25"), meas("BG002", "85")]},
                                                  {"title": "Male", "measurements": [meas("BG000", "27"), meas("BG001", "26"), meas("BG002", "53")]}]}]}]},
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "Body weight change", "populationDescription": "Modified ITT: participants with at least one post-baseline weight.",
         "reportingStatus": "POSTED", "paramType": "MEAN", "dispersionType": "95% Confidence Interval", "unitOfMeasure": "kg",
         "timeFrame": "Week 24", "groups": [{"id": "OG000", "title": "Placebo"}, {"id": "OG001", "title": "Drug B"}],
         "denoms": [denom("Participants", [("OG000", "45"), ("OG001", "49")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "-0.5", lowerLimit="-1.1", upperLimit="0.1"),
                                                      meas("OG001", "-4.2", lowerLimit="-3.5", upperLimit="-4.9")]}]}]},
        {"type": "SECONDARY", "title": "Waist circumference change", "reportingStatus": "POSTED", "paramType": "MEDIAN",
         "dispersionType": "Inter-Quartile Range", "unitOfMeasure": "cm", "timeFrame": "Week 24",
         "groups": [{"id": "OG000", "title": "Drug B"}, {"id": "OG001", "title": "Placebo"}],
         "denoms": [denom("Participants", [("OG000", "48"), ("OG001", "44")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "-6.0", lowerLimit="-5.0", upperLimit="-1.0"),
                                                      meas("OG001", "-0.5", lowerLimit="NA", upperLimit="1.0")]}]}]},
    ]}})

# 4. Crossover (two flow periods) and cluster design (units analyzed = Clinics).
s4 = study("NCT99000004", "Crossover and cluster", {
    "participantFlowModule": {"groups": [{"id": "FG000", "title": "A then B"}, {"id": "FG001", "title": "B then A"}],
        "periods": [{"title": "Period 1", "milestones": [
                        {"type": "STARTED", "achievements": [{"groupId": "FG000", "numSubjects": "15"}, {"groupId": "FG001", "numSubjects": "15"}]},
                        {"type": "COMPLETED", "achievements": [{"groupId": "FG000", "numSubjects": "14"}, {"groupId": "FG001", "numSubjects": "15"}]}]},
                    {"title": "Period 2", "milestones": [
                        {"type": "STARTED", "achievements": [{"groupId": "FG000", "numSubjects": "14"}, {"groupId": "FG001", "numSubjects": "15"}]},
                        {"type": "COMPLETED", "achievements": [{"groupId": "FG000", "numSubjects": "14"}, {"groupId": "FG001", "numSubjects": "14"}]}]}]},
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "Clinic-level HbA1c testing rate", "reportingStatus": "POSTED", "paramType": "MEAN",
         "dispersionType": "Standard Deviation", "unitOfMeasure": "tests per 100 patients", "timeFrame": "12 months",
         "typeUnitsAnalyzed": "Clinics", "denomUnitsSelected": "Clinics",
         "groups": [{"id": "OG000", "title": "Intervention clinics"}, {"id": "OG001", "title": "Control clinics"}],
         "denoms": [denom("Participants", [("OG000", "1200"), ("OG001", "1100")]), denom("Clinics", [("OG000", "12"), ("OG001", "11")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "78.2", spread="10.1"), meas("OG001", "61.0", spread="12.3")]}]}]},
        {"type": "SECONDARY", "title": "Clinics meeting the testing target", "reportingStatus": "POSTED", "paramType": "COUNT_OF_UNITS",
         "unitOfMeasure": "Clinics", "timeFrame": "12 months", "typeUnitsAnalyzed": "Clinics", "denomUnitsSelected": "Clinics",
         "groups": [{"id": "OG000", "title": "Intervention clinics"}, {"id": "OG001", "title": "Control clinics"}],
         "denoms": [denom("Participants", [("OG000", "1200"), ("OG001", "1100")]), denom("Clinics", [("OG000", "12"), ("OG001", "11")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "9"), meas("OG001", "13")]}]}]},
    ]}})

# 5. Empty and not-posted modules.
s5 = study("NCT99000005", "Empty and not posted", {
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "SECONDARY", "title": "Long-term cardiovascular events", "reportingStatus": "NOT_POSTED",
         "anticipatedPostingDate": "2027-06", "denomUnitsSelected": "Participants", "timeFrame": "5 years"},
        {"type": "SECONDARY", "title": "Outcome with zero analyzed", "reportingStatus": "POSTED", "unitOfMeasure": "mg/dL",
         "timeFrame": "Week 4", "groups": OG2, "denoms": [denom("Participants", [("OG000", "0"), ("OG001", "0")])]},
    ]},
    "adverseEventsModule": {"frequencyThreshold": "0", "timeFrame": "4 weeks",
        "eventGroups": [{"id": "EG000", "title": "Drug A", "seriousNumAffected": 0, "seriousNumAtRisk": 10},
                        {"id": "EG001", "title": "Placebo", "seriousNumAffected": 0, "seriousNumAtRisk": 10}]},
    "moreInfoModule": {"limitationsAndCaveats": {"description": "Terminated early; small sample."},
                       "pointOfContact": {"title": "Fixture Contact", "organization": "Fixture Organization",
                                          "email": "contact@example.invalid", "phone": "000-000-0000"}}})

# 6. Ambiguity rules C1 to C5 and a value with a thousands separator; K11 failure.
s6 = study("NCT99000006", "Ambiguous denominators", {
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "C2 non-integer count", "reportingStatus": "POSTED", "paramType": "MEAN",
         "dispersionType": "Standard Deviation", "unitOfMeasure": "units", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "NA"), ("OG001", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "1,169.62", spread="10"), meas("OG001", "12.5", spread="2.0")]}]}]},
        {"type": "SECONDARY", "title": "C3 duplicate participant entries", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "units", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")]), denom("participants", [("OG000", "29"), ("OG001", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "5.0"), meas("OG001", "6.0")]}]}]},
        {"type": "SECONDARY", "title": "C4 partial row denominators", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "units", "timeFrame": "Week 4, Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"title": "Week 4", "denoms": [denom("Participants", [("OG000", "29"), ("OG001", "28")])],
                      "categories": [{"measurements": [meas("OG000", "1.0"), meas("OG001", "2.0")]}]},
                     {"title": "Week 8", "categories": [{"measurements": [meas("OG000", "1.5"), meas("OG001", "2.5")]}]}]},
        {"type": "SECONDARY", "title": "C5 row denominators not in participants", "reportingStatus": "POSTED", "paramType": "NUMBER",
         "unitOfMeasure": "comparisons", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"title": "Pairs", "denoms": [denom("Pairwise comparison", [("OG000", "100"), ("OG001", "90")])],
                      "categories": [{"measurements": [meas("OG000", "88"), meas("OG001", "70")]}]}]},
        {"type": "SECONDARY", "title": "C1 missing group count", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "units", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "3.0"), meas("OG001", "4.0")]}]}]},
        {"type": "SECONDARY", "title": "K11 value with zero analyzed", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "units", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "0"), ("OG001", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "7.0"), meas("OG001", "4.0")]}]}]},
        {"type": "SECONDARY", "title": "C6 selected unit not reported", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "mm", "timeFrame": "Week 8", "typeUnitsAnalyzed": "Eyes", "denomUnitsSelected": "Eyes",
         "groups": [{"id": "OG001", "title": "Placebo"}, {"id": "OG000", "title": "Drug A"}],
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "1.2"), meas("OG001", "1.4")]}]}]},
        {"type": "SECONDARY", "title": "K12 categories that do not add up", "reportingStatus": "POSTED",
         "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants", "timeFrame": "Week 8", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"categories": [{"title": "Improved", "measurements": [meas("OG000", "20"), meas("OG001", "18")]},
                                     {"title": "Not improved", "measurements": [meas("OG000", "5"), meas("OG001", "12")]}]}]},
    ]}})

# 7. Row-level branches of the rules: C1, C3 and C2 in row-specific mode, B1 and C6 with a selected unit other than
#    participants, a blank selected unit, a not-posted outcome that declares groups, and K6 and K10 failures.
s7 = study("NCT99000007", "Row-level edge cases", {
    "outcomeMeasuresModule": {"outcomeMeasures": [
        {"type": "PRIMARY", "title": "Row counts missing, duplicated and NA", "reportingStatus": "POSTED", "paramType": "MEAN",
         "dispersionType": "Standard Deviation", "unitOfMeasure": "mg/dL", "timeFrame": "Week 4, Week 8, Week 12", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "41"), ("OG001", "40")])],
         "classes": [
             {"title": "Week 4", "denoms": [denom("Participants", [("OG000", "40")])],
              "categories": [{"measurements": [meas("OG000", "120.1", spread="15.0"), meas("OG001", "125.4", spread="16.2")]}]},
             {"title": "Week 8", "denoms": [denom("Participants", [("OG000", "39"), ("OG001", "38")]),
                                            denom("participants", [("OG000", "39")])],
              "categories": [{"measurements": [meas("OG000", "118.0", spread="14.1"), meas("OG001", "124.9", spread="15.8")]}]},
             {"title": "Week 12", "denoms": [denom("Participants", [("OG000", "NA"), ("OG001", "37")])],
              "categories": [{"measurements": [meas("OG000", "116.3", spread="13.9"), meas("OG001", "124.0", spread="15.1")]}]}]},
        {"type": "SECONDARY", "title": "Retinal thickness by eye", "reportingStatus": "POSTED", "paramType": "MEAN",
         "dispersionType": "Standard Deviation", "unitOfMeasure": "micrometers", "timeFrame": "Week 12",
         "typeUnitsAnalyzed": "Eyes", "denomUnitsSelected": "Eyes", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "20"), ("OG001", "20")]), denom("Eyes", [("OG000", "40"), ("OG001", "39")])],
         "classes": [
             {"title": "Left eye", "denoms": [denom("Participants", [("OG000", "20"), ("OG001", "20")]),
                                              denom("Eyes", [("OG000", "20"), ("OG001", "20")])],
              "categories": [{"measurements": [meas("OG000", "250.0", spread="20.0"), meas("OG001", "255.0", spread="21.0")]}]},
             {"title": "Right eye", "denoms": [denom("Participants", [("OG000", "20"), ("OG001", "19")])],
              "categories": [{"measurements": [meas("OG000", "251.0", spread="19.0"), meas("OG001", "254.0", spread="22.0")]}]}]},
        {"type": "SECONDARY", "title": "Blank selected unit", "reportingStatus": "POSTED", "paramType": "MEAN",
         "unitOfMeasure": "kg", "timeFrame": "Week 12", "denomUnitsSelected": "  ", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"categories": [{"measurements": [meas("OG000", "-2.0"), meas("OG001", "-0.5")]}]}],
         "analyses": [{"paramType": "Mean Difference (Net)", "paramValue": "2.5", "ciPctValue": "95", "ciNumSides": "TWO_SIDED",
                       "ciLowerLimit": "-1.0", "ciUpperLimit": "1.0", "statisticalMethod": "ANCOVA",
                       "groupIds": ["OG000", "OG001"]}]},
        {"type": "SECONDARY", "title": "Not yet posted, groups declared", "reportingStatus": "NOT_POSTED",
         "anticipatedPostingDate": "2027-06", "timeFrame": "2 years", "groups": OG2},
        {"type": "SECONDARY", "title": "Categories with an NA count", "reportingStatus": "POSTED",
         "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants", "timeFrame": "Week 12", "groups": OG2,
         "denoms": [denom("Participants", [("OG000", "30"), ("OG001", "30")])],
         "classes": [{"categories": [{"title": "Yes", "measurements": [meas("OG000", "NA"), meas("OG001", "10")]},
                                     {"title": "No", "measurements": [meas("OG000", "20"), meas("OG001", "20")]}]}]},
    ]},
    "baselineCharacteristicsModule": {
        "groups": [{"id": "BG000", "title": "Drug A"}, {"id": "BG001", "title": "Placebo"}],
        "denoms": [denom("Participants", [("BG000", "30"), ("BG001", "30")])],
        "measures": [{"title": "Subgroup with class-level counts", "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants",
                      "classes": [{"title": "Subgroup", "denoms": [denom("Participants", [("BG000", "10"), ("BG001", "10")])],
                                   "categories": [{"title": "Yes", "measurements": [meas("BG000", "12"), meas("BG001", "4")]},
                                                  {"title": "No", "measurements": [meas("BG000", "0"), meas("BG001", "6")]}]}]},
                     {"title": "Age, median", "paramType": "MEDIAN", "dispersionType": "INTER_QUARTILE_RANGE", "unitOfMeasure": "years",
                      "classes": [{"categories": [{"measurements": [meas("BG000", "55", lowerLimit="60", upperLimit="50"),
                                                                   meas("BG001", "56", lowerLimit="50", upperLimit="62")]}]}]},
                     {"title": "Subgroup with measure-level counts", "paramType": "COUNT_OF_PARTICIPANTS", "unitOfMeasure": "Participants",
                      "denoms": [denom("Participants", [("BG000", "8"), ("BG001", "8")])],
                      "classes": [{"categories": [{"title": "Yes", "measurements": [meas("BG000", "9"), meas("BG001", "3")]}]}]}]},
    "adverseEventsModule": {"frequencyThreshold": "5", "timeFrame": "12 weeks",
        "eventGroups": [{"id": "EG000", "title": "Drug A", "seriousNumAffected": 3, "seriousNumAtRisk": 10},
                        {"id": "EG001", "title": "Placebo", "seriousNumAffected": 1, "seriousNumAtRisk": 10}],
        "seriousEvents": [{"term": "Dizziness", "organSystem": "Nervous system disorders", "assessmentType": "SYSTEMATIC_ASSESSMENT",
                           "stats": [{"groupId": "EG000", "numEvents": 6, "numAffected": 5, "numAtRisk": 4},
                                     {"groupId": "EG001", "numEvents": 1, "numAffected": 1, "numAtRisk": 10}]}]}})

STUDIES = [s1, s2, s3, s4, s5, s6, s7]

EXPECTED_MEASUREMENT_RULES = {
    # (nct, outcome, class, category, measurement) -> rule
    ("NCT99000001", 0, 0, 0, 0): "A_OUTCOME_LEVEL",
    ("NCT99000001", 1, 0, 0, 0): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000001", 1, 2, 0, 1): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000001", 2, 0, 1, 1): "A_OUTCOME_LEVEL",
    ("NCT99000004", 0, 0, 0, 0): "B2_NON_PARTICIPANT_UNITS",
    ("NCT99000006", 0, 0, 0, 0): "C2_NON_INTEGER_COUNT",
    ("NCT99000006", 0, 0, 0, 1): "A_OUTCOME_LEVEL",
    ("NCT99000006", 1, 0, 0, 0): "C3_DUPLICATE_UNIT_ENTRIES",
    ("NCT99000006", 2, 0, 0, 0): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000006", 2, 1, 0, 0): "C4_PARTIAL_ROW_DENOMINATORS",
    ("NCT99000006", 3, 0, 0, 0): "C5_ROW_DENOMINATORS_NOT_IN_PARTICIPANTS",
    ("NCT99000006", 4, 0, 0, 0): "A_OUTCOME_LEVEL",
    ("NCT99000006", 4, 0, 0, 1): "C1_NO_PARTICIPANT_COUNT",
    ("NCT99000006", 6, 0, 0, 0): "C6_SELECTED_UNIT_NOT_REPORTED",
    ("NCT99000002", 0, 0, 0, 0): "A_OUTCOME_LEVEL",
    ("NCT99000007", 0, 0, 0, 0): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000007", 0, 0, 0, 1): "C1_NO_PARTICIPANT_COUNT",
    ("NCT99000007", 0, 1, 0, 0): "C3_DUPLICATE_UNIT_ENTRIES",
    ("NCT99000007", 0, 1, 0, 1): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000007", 0, 2, 0, 0): "C2_NON_INTEGER_COUNT",
    ("NCT99000007", 0, 2, 0, 1): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000007", 1, 0, 0, 0): "B1_ROW_SPECIFIC_DENOMINATOR",
    ("NCT99000007", 1, 1, 0, 0): "C6_SELECTED_UNIT_NOT_REPORTED",
    ("NCT99000007", 2, 0, 0, 0): "A_OUTCOME_LEVEL",
}
EXPECTED_DENOMINATORS = {("NCT99000001", 1, 0, 0, 0): 49, ("NCT99000001", 1, 1, 0, 1): 44, ("NCT99000001", 1, 2, 0, 1): 39,
                         ("NCT99000004", 0, 0, 0, 0): 1200, ("NCT99000007", 0, 0, 0, 0): 40, ("NCT99000007", 0, 1, 0, 1): 38,
                         ("NCT99000007", 0, 2, 0, 1): 37, ("NCT99000007", 1, 0, 0, 0): 20, ("NCT99000007", 2, 0, 0, 0): 30}
EXPECTED_GROUP_TIERS = {("NCT99000005", 1, "OG000"): ("D", "D_NO_MEASUREMENTS"),
                        ("NCT99000006", 2, "OG000"): ("C", "B1_ROW_SPECIFIC_DENOMINATOR|C4_PARTIAL_ROW_DENOMINATORS"),
                        ("NCT99000001", 1, "OG001"): ("B", "B1_ROW_SPECIFIC_DENOMINATOR"),
                        ("NCT99000007", 3, "OG000"): ("D", "D_NOT_POSTED")}
EXPECTED_CHECK_FAILS = {("K1", "NCT99000002"), ("K5", "NCT99000002"), ("K7", "NCT99000002"), ("K8", "NCT99000002"),
                        ("K3", "NCT99000003"), ("K4", "NCT99000003"), ("K9", "NCT99000003"), ("K2", "NCT99000004"),
                        ("K11", "NCT99000006"), ("K12", "NCT99000006"), ("K6", "NCT99000007"), ("K10", "NCT99000007"),
                        ("K9", "NCT99000007"), ("K3", "NCT99000007")}


def write():
    page = {"studies": STUDIES}
    (HERE / "api_page_fixture.json").write_text(json.dumps(page, indent=1, ensure_ascii=False) + "\n")
    expected = {
        "measurement_rules": {"|".join(map(str, k)): v for k, v in EXPECTED_MEASUREMENT_RULES.items()},
        "denominators": {"|".join(map(str, k)): v for k, v in EXPECTED_DENOMINATORS.items()},
        "group_tiers": {"|".join(map(str, k)): list(v) for k, v in EXPECTED_GROUP_TIERS.items()},
        "check_fails": sorted("|".join(k) for k in EXPECTED_CHECK_FAILS),
    }
    (HERE / "expected.json").write_text(json.dumps(expected, indent=1) + "\n")


if __name__ == "__main__":
    write()
