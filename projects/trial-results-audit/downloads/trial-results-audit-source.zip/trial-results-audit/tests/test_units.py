"""Unit tests that need no database: parsing, cohort rules, retrieval validation and the flat baseline."""
from __future__ import annotations

import json
from decimal import Decimal

import httpx
import pytest

from tra.acquire import Fetcher, RetrievalError
from tra.etl import parse_int, parse_num
from tra.flat import flatten_study
from tra.manifest import confirm_condition, usable_identifier

FIX = json.load(open(__import__("pathlib").Path(__file__).parent / "fixtures" / "api_page_fixture.json"))


def test_numeric_parsing_is_conservative():
    assert parse_num("-1.10") == Decimal("-1.10")
    assert parse_num("1e-3") == Decimal("0.001")
    for text in ("1,169.62", "-0,028", "<0.001", "NA", "", "12 (5%)", "1.5\n", "\uff11\uff12", " 1.5"):
        assert parse_num(text) is None
    assert parse_int("48") == 48
    for text in ("4.0", "NA", "-1", "12\n", "\uff11\uff12", "\u0661\u0662", " 12", "2147483648"):
        assert parse_int(text) is None


def test_identifier_rule_ignores_bare_years():
    assert not usable_identifier("2017")
    assert not usable_identifier("N/A")
    assert usable_identifier("R01DK049587")


def test_condition_confirmation_rule():
    q = {"mesh_descriptor_id": "D003920", "condition_regex": r"\bdiabet(es|ic)\b", "condition_exclude_regex": r"\binsipidus\b"}
    s = {"protocolSection": {"conditionsModule": {"conditions": ["Diabetes Insipidus"]}},
         "derivedSection": {"conditionBrowseModule": {"meshes": [], "ancestors": []}}}
    assert confirm_condition(s, q) == (False, "matched_only_outside_condition_fields")
    s["derivedSection"]["conditionBrowseModule"]["ancestors"] = [{"id": "D003920", "term": "Diabetes Mellitus"}]
    assert confirm_condition(s, q) == (True, "condition_ancestor_mesh_term")


def _fetcher(handler, tmp_path):
    cfg = {"api": {"base_url": "https://example.invalid/api/v2", "timeout_seconds": 5, "max_retries": 2,
                   "backoff_seconds": 0, "min_interval_seconds": 0}}
    f = Fetcher(cfg, tmp_path / "log.jsonl")
    f.client = httpx.Client(transport=httpx.MockTransport(handler))
    return f


def test_error_page_masquerading_as_data_is_rejected(tmp_path):
    f = _fetcher(lambda req: httpx.Response(200, headers={"content-type": "text/html"}, text="<html>error</html>"), tmp_path)
    with pytest.raises(RetrievalError):
        f.get("/studies")


def test_retry_then_success(tmp_path):
    calls = {"n": 0}

    def handler(req):
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(503, text="busy")
        return httpx.Response(200, headers={"content-type": "application/json"}, json={"studies": []})

    f = _fetcher(handler, tmp_path)
    body, obj, _ = f.get("/studies", expect_keys=("studies",))
    assert obj == {"studies": []} and calls["n"] == 2


def test_flat_baseline_attaches_outcome_level_count_to_row_specific_rows():
    from tra.flat import OUTCOME_COLS
    rows = [dict(zip(OUTCOME_COLS, r)) for r in flatten_study(FIX["studies"][0])["outcomes"]]
    week52 = [r for r in rows if r["class_title"] == "Week 52" and r["group_id"] == "OG000"][0]
    assert week52["n_analyzed"] == "50"  # outcome-level N, although the row-specific N is 40


def test_flat_baseline_copies_ancestor_scalars_down():
    from tra.flat import BASELINE_COLS
    rows = [dict(zip(BASELINE_COLS, r)) for r in flatten_study(FIX["studies"][2])["baseline"]]
    assert rows and all(r["module_population_description"] == "All randomized participants." for r in rows)


def test_flat_baseline_drops_outcomes_without_values():
    from tra.flat import OUTCOME_COLS
    titles = {dict(zip(OUTCOME_COLS, r))["outcome_title"] for r in flatten_study(FIX["studies"][4])["outcomes"]}
    assert "Long-term cardiovascular events" not in titles and "Outcome with zero analyzed" not in titles


def test_fixture_ids_are_outside_the_registry_range():
    for s in FIX["studies"]:
        assert s["protocolSection"]["identificationModule"]["nctId"].startswith("NCT990")


def test_analyze_gate_refuses_unsafe_runs(tmp_path, monkeypatch):
    import tra.analyze as an
    import tra.freeze as fz
    monkeypatch.setattr(fz, "assert_heldout_allowed", lambda: {"combined_sha256": "x"})
    monkeypatch.setattr(an, "EVIDENCE_DIR", tmp_path)
    monkeypatch.setattr(an, "current_snapshot_id", lambda: "fixture-snapshot")
    with pytest.raises(SystemExit, match="rerun-check applies only"):
        an.analyze(split="development", rerun_check=True)
    with pytest.raises(SystemExit, match="No completed held-out run"):
        an.analyze(split="heldout", rerun_check=True)
    with pytest.raises(SystemExit, match="touches held-out data"):
        an.analyze(split="all")
    (tmp_path / "heldout_run.json").write_text("{}")
    with pytest.raises(SystemExit, match="already been executed once"):
        an.analyze(split="heldout")


def test_compare_runs_flags_differences_and_extra_files(tmp_path):
    from tra.analyze import compare_runs
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir(); b.mkdir()
    (a / "t.csv").write_text("x,y\n1,0.5\n")
    (b / "t.csv").write_text("x,y\n1,0.5000000000001\n")
    assert compare_runs(a, b)["all_identical"]
    (b / "extra.csv").write_text("x\n")
    r = compare_runs(a, b)
    assert not r["all_identical"] and r["files"]["extra.csv"] == "extra in rerun"
