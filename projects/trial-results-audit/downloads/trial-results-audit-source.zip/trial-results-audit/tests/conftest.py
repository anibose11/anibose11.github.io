"""Shared test setup: a fixture snapshot on disk and a separate test database in the project cluster.

The fixtures are synthetic software tests. They are loaded into the database `tra_test`, never into the study database.
"""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

import pytest

from tra import pg
from tra.etl import apply_schema

FIXTURES = Path(__file__).parent / "fixtures"
SNAPSHOT = "fixture-snapshot"
TEST_DB = "tra_test"


def make_fixture_snapshot(base: Path) -> tuple[Path, Path]:
    raw_dir = base / "raw" / SNAPSHOT
    frozen_dir = base / "frozen" / SNAPSHOT
    (raw_dir / "study_pages").mkdir(parents=True, exist_ok=True)
    frozen_dir.mkdir(parents=True, exist_ok=True)
    page_bytes = (FIXTURES / "api_page_fixture.json").read_bytes()
    (raw_dir / "study_pages" / "batch_0000.json").write_bytes(page_bytes)
    page = json.loads(page_bytes)
    ids = [s["protocolSection"]["identificationModule"]["nctId"] for s in page["studies"]]
    state = {"snapshot_id": SNAPSHOT, "complete": True, "union_n": len(ids),
             "retrieval_started_at": "2026-01-01T00:00:00Z", "retrieval_finished_at": "2026-01-01T00:00:01Z",
             "version_before": {"apiVersion": "fixture", "dataTimestamp": "fixture"},
             "version_after": {"apiVersion": "fixture", "dataTimestamp": "fixture"},
             "queries": {"fixture": {"query_cond": "fixture", "filter_advanced": "fixture", "total_count": len(ids), "ids": ids}},
             "batches": {"batch_0000": {"file": "study_pages/batch_0000.json", "ids": sorted(ids),
                                        "sha256": hashlib.sha256(page_bytes).hexdigest()}},
             "sampling": {"applied": False}}
    (raw_dir / "retrieval_state.json").write_text(json.dumps(state))
    from tra.manifest import canonical_sha256
    with open(frozen_dir / "manifest.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["nct_id", "split", "cohort_status", "query_groups", "confirmed_groups",
                                           "cluster_id", "record_sha256"])
        w.writeheader()
        for s in page["studies"]:
            n = s["protocolSection"]["identificationModule"]["nctId"]
            w.writerow({"nct_id": n, "split": "development", "cohort_status": "confirmed", "query_groups": "diabetes",
                        "confirmed_groups": "diabetes", "cluster_id": n, "record_sha256": canonical_sha256(s)})
    return raw_dir, frozen_dir


@pytest.fixture(scope="session")
def fixture_snapshot(tmp_path_factory):
    base = tmp_path_factory.mktemp("fixture_data")
    return make_fixture_snapshot(base)


@pytest.fixture(scope="session")
def test_db(fixture_snapshot):
    params = pg.ensure_cluster(database=TEST_DB)
    with pg.connect(params) as conn:
        for schema in ("ctr", "audit", "ref", "flat"):
            conn.execute(f"drop schema if exists {schema} cascade")
        conn.commit()
        apply_schema(conn)
    yield params
    with pg.connect({**params, "dbname": "postgres"}, autocommit=True) as conn:
        conn.execute(f"drop database if exists {TEST_DB} with (force)")


@pytest.fixture(scope="session")
def loaded(test_db, fixture_snapshot):
    from tra.etl import load_snapshot
    raw_dir, frozen_dir = fixture_snapshot
    with pg.connect(test_db) as conn:
        report = load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)
        conn.commit()
    return report


@pytest.fixture(scope="session")
def expected():
    return json.loads((FIXTURES / "expected.json").read_text())


@pytest.fixture(scope="session")
def reference_out(fixture_snapshot, tmp_path_factory):
    import subprocess
    from tra.config import R_DIR
    if shutil.which("Rscript") is None:
        pytest.skip("Rscript not available")
    raw_dir, frozen_dir = fixture_snapshot
    out = tmp_path_factory.mktemp("reference")
    subprocess.run(["Rscript", "--vanilla", str(R_DIR / "reference_enumerator.R"), str(raw_dir),
                    str(frozen_dir / "manifest.csv"), "development", str(out), SNAPSHOT], check=True, capture_output=True)
    return out
