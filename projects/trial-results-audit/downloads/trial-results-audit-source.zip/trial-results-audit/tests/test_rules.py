"""Denominator association rules, check catalogue and SQL/R agreement on synthetic fixtures."""
from __future__ import annotations

from tra import pg
from tra.reference import load_reference

from conftest import SNAPSHOT


def _md(conn):
    return {(r[0], r[1], r[2], r[3], r[4]): r[5:] for r in conn.execute(
        "select nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal, tier, rule_id, "
        "participant_denominator, unit_denominator from audit.v_measurement_denominator where snapshot_id=%s", (SNAPSHOT,)).fetchall()}


def test_measurement_rules_match_expectations(loaded, test_db, expected):
    with pg.connect(test_db) as conn:
        md = _md(conn)
    for key, rule in expected["measurement_rules"].items():
        n, o, c, k, m = key.split("|")
        assert md[(n, int(o), int(c), int(k), int(m))][1] == rule, key


def test_row_specific_and_unit_denominators(loaded, test_db, expected):
    with pg.connect(test_db) as conn:
        md = _md(conn)
    for key, den in expected["denominators"].items():
        n, o, c, k, m = key.split("|")
        assert md[(n, int(o), int(c), int(k), int(m))][2] == den, key
    # cluster outcome: participant denominator 1200, unit (clinic) denominator 12, values per clinic
    assert md[("NCT99000004", 0, 0, 0, 0)][2:] == (1200, 12)


def test_ambiguous_cases_get_no_denominator(loaded, test_db):
    with pg.connect(test_db) as conn:
        md = _md(conn)
    assert md[("NCT99000006", 0, 0, 0, 0)][0] == "C" and md[("NCT99000006", 0, 0, 0, 0)][2] is None
    assert md[("NCT99000006", 1, 0, 0, 0)][2] is None


def test_group_tiers(loaded, test_db, expected):
    with pg.connect(test_db) as conn:
        gt = {(r[0], r[1], r[2]): (r[3], r[4]) for r in conn.execute(
            "select nct_id, outcome_ordinal, group_id, tier, rules from audit.v_outcome_group_tier where snapshot_id=%s",
            (SNAPSHOT,)).fetchall()}
        not_posted = conn.execute("select reporting_status, n_groups from audit.v_outcome_summary where nct_id='NCT99000005' "
                                  "and outcome_ordinal=0").fetchone()
    for key, val in expected["group_tiers"].items():
        n, o, g = key.split("|")
        assert gt[(n, int(o), g)] == tuple(val), key
    assert not_posted == ("NOT_POSTED", 0)


def test_checks_fail_exactly_where_expected(loaded, test_db, expected):
    with pg.connect(test_db) as conn:
        fails = {f"{r[0]}|{r[1]}" for r in conn.execute(
            "select distinct check_id, nct_id from audit.v_check where snapshot_id=%s and status='fail'", (SNAPSHOT,)).fetchall()}
    assert fails == set(expected["check_fails"])


def test_padded_unit_labels_still_read_as_participants(loaded, test_db):
    with pg.connect(test_db) as conn:
        row = conn.execute("select analysis_unit, unit_is_participants from audit.v_outcome_context "
                           "where nct_id='NCT99000002' and outcome_ordinal=0").fetchone()
    assert row == ("Participants", True)


def test_swapped_interval_is_reported_once(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = dict(conn.execute("select check_id, status from audit.v_check where nct_id='NCT99000003' and pointer like "
                                 "'%%outcomeMeasures/0/%%measurements/1'").fetchall())
    assert rows == {"K3": "fail", "K4": "not_evaluable"}


def test_not_evaluable_is_separate_from_failure(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = conn.execute("select check_id, status from audit.v_check where nct_id='NCT99000003' and pointer like "
                            "'%%outcomeMeasures/1/%%measurements/1'").fetchall()
    assert ("K4", "not_evaluable") in rows


def test_mean_outcomes_are_not_given_count_checks(loaded, test_db):
    with pg.connect(test_db) as conn:
        n = conn.execute("select count(*) from audit.v_check c join ctr.outcome_measurement m on m.source_pointer = c.pointer "
                         "and m.nct_id = c.nct_id and m.snapshot_id = c.snapshot_id join ctr.outcome_measure o "
                         "on o.snapshot_id = m.snapshot_id and o.nct_id = m.nct_id and o.outcome_ordinal = m.outcome_ordinal "
                         "where c.check_id in ('K1','K2') and o.param_type not in ('COUNT_OF_PARTICIPANTS','COUNT_OF_UNITS')").fetchone()[0]
    assert n == 0


def test_same_label_is_shown_but_not_linked(loaded, test_db):
    with pg.connect(test_db) as conn:
        row = conn.execute("select outcome_participants, baseline_title_matches, baseline_participants from audit.v_cross_module_label "
                           "where nct_id='NCT99000003' and outcome_ordinal=0 and group_id='OG000'").fetchone()
        prov = conn.execute("select same_label_in_baseline_not_linked, min_participant_denominator from audit.v_denominator_provenance "
                            "where nct_id='NCT99000003' and outcome_ordinal=0 and group_id='OG000'").fetchone()
    assert row == (45, 1, 52)
    assert prov[1] == 45 and prov[0][0]["group_id"] == "BG000"


def test_evidence_table_has_one_row_per_measurement(loaded, test_db):
    with pg.connect(test_db) as conn:
        a = conn.execute("select count(*) from audit.v_evidence_table where nct_id like 'NCT990%%'").fetchone()[0]
        b = conn.execute("select count(*) from ctr.outcome_measurement where snapshot_id=%s", (SNAPSHOT,)).fetchone()[0]
    assert a == b


def test_sql_and_r_tiers_agree(loaded, test_db, reference_out):
    with pg.connect(test_db) as conn:
        load_reference(conn, reference_out, SNAPSHOT)
        conn.commit()
        bad = conn.execute("""
            select count(*) from audit.v_measurement_denominator md full outer join ref.measurement_tier r
              using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal)
            where coalesce(md.snapshot_id, r.snapshot_id) = %s and (md.tier is distinct from r.tier or md.rule_id is distinct from r.rule_id
               or md.participant_denominator is distinct from r.participant_denominator
               or md.unit_denominator is distinct from r.unit_denominator)""", (SNAPSHOT,)).fetchone()[0]
        bad_g = conn.execute("""
            select count(*) from audit.v_outcome_group_tier t full outer join ref.group_tier r
              using (snapshot_id, nct_id, outcome_ordinal, group_id)
            where coalesce(t.snapshot_id, r.snapshot_id) = %s and (t.tier is distinct from r.tier or t.rules is distinct from r.rules)""",
                             (SNAPSHOT,)).fetchone()[0]
    assert bad == 0 and bad_g == 0


def test_row_level_rule_in_another_unit(loaded, test_db):
    with pg.connect(test_db) as conn:
        md = _md(conn)
    # left eye: participant count and eye count both given per row -> B1 with both denominators
    assert md[("NCT99000007", 1, 0, 0, 0)] == ("B", "B1_ROW_SPECIFIC_DENOMINATOR", 20, 20)
    # right eye: no eye count in the row -> C6, no denominator attached
    assert md[("NCT99000007", 1, 1, 0, 0)][:3] == ("C", "C6_SELECTED_UNIT_NOT_REPORTED", None)


def test_blank_selected_unit_reads_as_participants(loaded, test_db):
    with pg.connect(test_db) as conn:
        row = conn.execute("select analysis_unit, unit_is_participants from audit.v_outcome_context "
                           "where nct_id='NCT99000007' and outcome_ordinal=2").fetchone()
    assert row[1] is True


def test_category_check_not_evaluable_with_na(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = conn.execute("select status, count(*) from audit.v_check where check_id='K12' and nct_id='NCT99000007' "
                            "group by 1 order by 1").fetchall()
    assert dict(rows) == {"not_evaluable": 1, "pass": 1}


def test_baseline_check_uses_class_level_denominator_first(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = dict(conn.execute("select pointer, status from audit.v_check where check_id='K9' and nct_id='NCT99000007'"
                                 ).fetchall())
    # 12 against the class-level count of 10, and 9 against the measure-level count of 8, both fail, although the module
    # count of 30 would pass either
    assert sum(1 for v in rows.values() if v == "fail") == 2


def test_baseline_interquartile_range_in_enumeration_vocabulary(loaded, test_db):
    with pg.connect(test_db) as conn:
        rows = conn.execute("select check_id, status from audit.v_check where nct_id='NCT99000007' "
                            "and check_id in ('K3', 'K4') and pointer like '%%baselineCharacteristicsModule/measures/1/%%' "
                            "order by 1, 2").fetchall()
    assert ("K3", "fail") in rows and ("K4", "not_evaluable") in rows


def test_interval_kind_vocabulary(loaded, test_db):
    labels = ("95% Confidence Interval", "CONFIDENCE_95", "Inter-Quartile Range", "INTER_QUARTILE_RANGE", "Full Range",
              "FULL_RANGE", "Standard Deviation")
    with pg.connect(test_db) as conn:
        got = {d: conn.execute("select audit.interval_kind(%s)", (d,)).fetchone()[0] for d in labels}
    assert got == {"95% Confidence Interval": "confidence", "CONFIDENCE_95": "confidence", "Inter-Quartile Range": "iqr",
                   "INTER_QUARTILE_RANGE": "iqr", "Full Range": "full_range", "FULL_RANGE": "full_range",
                   "Standard Deviation": None}
