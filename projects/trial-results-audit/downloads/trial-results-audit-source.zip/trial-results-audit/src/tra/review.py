"""Worksheets for checking warehouse values against the public record pages (not part of the computation).

Draws a fixed-seed stratified random sample of held-out outcome groups (seed 20261007: 10 tier A, 10 row-level counts,
5 unit rule, all tier C) and lists every flagged ledger item, each with its public registry link and the values the
warehouse associated, plus blank columns for the result of each check.
"""
from __future__ import annotations

import csv
import random
from pathlib import Path

from . import pg
from .config import ROOT, TABLES_DIR, current_snapshot_id

SEED = 20261007
STRATA = {"A_OUTCOME_LEVEL": 10, "B1_ROW_SPECIFIC_DENOMINATOR": 10, "B2_NON_PARTICIPANT_UNITS": 5, "C": 5}


def write_review_packet(out_dir: Path | None = None) -> Path:
    out_dir = out_dir or ROOT / "review"
    out_dir.mkdir(parents=True, exist_ok=True)
    snap = current_snapshot_id()
    with pg.connect() as conn:
        rows = conn.execute("""
            select t.nct_id, s.registry_url, t.outcome_ordinal, o.type, o.title, o.time_frame, t.group_id, t.group_title, t.tier,
                   t.rules, t.n_measurements, t.min_participant_denominator, t.max_participant_denominator, t.analysis_unit,
                   (select string_agg(d.units || '=' || c.value_text, '; ' order by c.source_pointer)
                      from ctr.outcome_denom d join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
                     where c.snapshot_id = t.snapshot_id and c.nct_id = t.nct_id and c.outcome_ordinal = t.outcome_ordinal
                       and c.group_id = t.group_id) as outcome_level_counts,
                   t.group_pointer
            from audit.v_outcome_group_tier t
            join ctr.study s using (snapshot_id, nct_id)
            join ctr.outcome_measure o using (snapshot_id, nct_id, outcome_ordinal)
            where t.snapshot_id = %s and s.split = 'heldout' and s.cohort_status = 'confirmed' and t.tier in ('A', 'B', 'C')
            order by t.nct_id, t.outcome_ordinal, t.group_id""", (snap,)).fetchall()
    cols = ["nct_id", "registry_url", "outcome_ordinal", "outcome_type", "outcome_title", "time_frame", "group_id", "group_title",
            "tier", "rules", "n_measurements", "min_participant_denominator", "max_participant_denominator", "analysis_unit",
            "outcome_level_counts", "group_pointer"]
    recs = [dict(zip(cols, r)) for r in rows]
    rng = random.Random(SEED)
    sample = []
    for key, k in STRATA.items():
        pool = [r for r in recs if (r["tier"] == "C" if key == "C" else r["rules"] == key)]
        picked = pool if len(pool) <= k else rng.sample(pool, k)
        for r in sorted(picked, key=lambda r: (r["nct_id"], r["outcome_ordinal"], r["group_id"])):
            sample.append({"stratum": key, **r})
    review_cols = ["registry_count_matches (yes/no)", "tier_and_rule_agree (yes/no)", "reviewer_notes"]
    with open(out_dir / "sample_outcome_groups.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["sample_id", "stratum"] + cols + review_cols)
        for i, r in enumerate(sample, 1):
            w.writerow([f"S{i:02d}", r["stratum"]] + [r[c] for c in cols] + ["", "", ""])
    ledger = list(csv.DictReader(open(TABLES_DIR / "heldout" / "issue_ledger.csv", encoding="utf-8")))
    with open(out_dir / "flagged_items.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["issue_id", "issue_class", "rule_id", "nct_id", "registry_url", "pointer", "evidence",
                    "confirmed_on_registry_page (yes/no/unclear)", "reviewer_notes"])
        for r in ledger:
            if r["issue_class"] != "unresolved interpretation" or r["rule_id"].startswith("C"):
                w.writerow([r["issue_id"], r["issue_class"], r["rule_id"], r["nct_id"], r["registry_url"], r["pointer"],
                            r["evidence"], "", ""])
    print(f"Verification sample: {len(sample)} sampled outcome groups (seed {SEED}), flagged items written to {out_dir}")
    return out_dir
