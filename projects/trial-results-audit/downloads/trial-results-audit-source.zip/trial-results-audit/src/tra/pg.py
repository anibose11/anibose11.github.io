"""Project-local native PostgreSQL cluster: initdb, start, stop and connections.

The cluster listens on a Unix socket inside the project directory only. No sudo, no system service,
and no other database is touched. Set TRA_PG_BIN to override the binary directory.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path

import psycopg

from .config import LOG_DIR, ROOT, load_db_config


def pg_bin() -> Path:
    env = os.environ.get("TRA_PG_BIN")
    cands = [env] if env else []
    cands += load_db_config()["pg_bin_candidates"]
    for c in cands:
        if c and (Path(c) / "pg_ctl").exists():
            return Path(c)
    found = shutil.which("pg_ctl")
    if found:
        return Path(found).parent
    raise SystemExit("PostgreSQL binaries (pg_ctl, initdb) were not found. Install PostgreSQL 17 or set TRA_PG_BIN.")


def _paths(cfg: dict | None = None, data_dir: Path | None = None, socket_dir: Path | None = None):
    cfg = dict(cfg or load_db_config())
    # A second copy of the project (for example a clean extraction of the source archive) can run its own
    # cluster beside this one by setting TRA_PG_PORT.
    if os.environ.get("TRA_PG_PORT"):
        cfg["port"] = int(os.environ["TRA_PG_PORT"])
    d = data_dir or (ROOT / cfg["data_dir"])
    s = socket_dir or (ROOT / cfg["socket_dir"])
    return cfg, d, s


def _env() -> dict:
    # On macOS the postmaster refuses to start ("became multithreaded during startup") unless LC_ALL is set.
    return {**os.environ, "LC_ALL": "C", "LANG": "C"}


def run(cmd: list[str], **kw) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=True, capture_output=True, text=True, env=_env(), **kw)


def ensure_cluster(data_dir: Path | None = None, socket_dir: Path | None = None, port: int | None = None,
                   database: str | None = None) -> dict:
    """Create (if needed) and start the cluster; create the database. Returns connection parameters."""
    cfg, d, s = _paths(None, data_dir, socket_dir)
    port = port or cfg["port"]
    database = database or cfg["database"]
    b = pg_bin()
    s.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    if not (d / "PG_VERSION").exists():
        d.parent.mkdir(parents=True, exist_ok=True)
        run([str(b / "initdb"), "-D", str(d), "-U", cfg["user"], "--auth=trust", f"--encoding={cfg['encoding']}",
             f"--locale={cfg['locale']}", "--no-instructions"])
    status = subprocess.run([str(b / "pg_ctl"), "-D", str(d), "status"], capture_output=True, text=True, env=_env())
    if status.returncode != 0:
        opts = f"-k {s} -p {port} -c listen_addresses='' -c fsync=on -c timezone=UTC"
        run([str(b / "pg_ctl"), "-D", str(d), "-l", str(LOG_DIR / f"postgres-{d.name.lstrip('.')}.log"), "-o", opts, "-w", "start"])
    params = {"host": str(s), "port": port, "user": cfg["user"], "dbname": "postgres"}
    for _ in range(50):
        try:
            with psycopg.connect(**params, autocommit=True) as conn:
                exists = conn.execute("select 1 from pg_database where datname=%s", (database,)).fetchone()
                if not exists:
                    conn.execute(f'create database "{database}" template template0 encoding \'UTF8\' locale \'C\'')
            break
        except psycopg.OperationalError:
            time.sleep(0.2)
    else:
        raise SystemExit("PostgreSQL did not accept connections; see logs/postgres-*.log")
    return {**params, "dbname": database}


def stop_cluster(data_dir: Path | None = None):
    _, d, _ = _paths(None, data_dir, None)
    if (d / "PG_VERSION").exists():
        subprocess.run([str(pg_bin() / "pg_ctl"), "-D", str(d), "-m", "fast", "stop"], capture_output=True, text=True,
                       env=_env())


def connect(params: dict | None = None, autocommit: bool = False) -> psycopg.Connection:
    if params is None:
        cfg, d, s = _paths()
        params = {"host": str(s), "port": cfg["port"], "user": cfg["user"], "dbname": cfg["database"]}
    return psycopg.connect(**params, autocommit=autocommit)


def server_version(conn) -> str:
    return conn.execute("show server_version").fetchone()[0]


def cli(action: str) -> int:
    cfg, d, s = _paths()
    if action == "start":
        p = ensure_cluster()
        print(f"PostgreSQL running: socket {p['host']} port {p['port']} database {p['dbname']}")
    elif action == "stop":
        stop_cluster()
        print("PostgreSQL stopped")
    elif action == "status":
        r = subprocess.run([str(pg_bin() / "pg_ctl"), "-D", str(d), "status"], capture_output=True, text=True)
        print(r.stdout or r.stderr)
        return r.returncode
    elif action == "psql-uri":
        print(f"postgresql://{cfg['user']}@/{cfg['database']}?host={s}&port={cfg['port']}")
    return 0
