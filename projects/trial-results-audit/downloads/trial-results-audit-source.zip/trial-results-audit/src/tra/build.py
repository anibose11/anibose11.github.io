"""Build stage: project PostgreSQL cluster, schema, warehouse load, views, flat baseline and R reference."""
from __future__ import annotations

import json
import subprocess
import time

from . import pg
from .config import RUNS_DIR, current_snapshot_id, write_json, R_DIR, snapshot_dirs, ROOT
from .etl import apply_schema, load_snapshot

SPLITS = {"development": {"development"}, "heldout": {"heldout"}, "all": {"development", "heldout"}}


def build(split: str = "development", skip_reference: bool = False, fresh: bool = False) -> dict:
    from .freeze import assert_heldout_allowed
    if split in ("heldout", "all"):
        assert_heldout_allowed()
    params = pg.ensure_cluster()
    if fresh:
        with pg.connect(params) as conn:
            for schema in ("audit", "flat", "ref", "ctr"):
                conn.execute(f"drop schema if exists {schema} cascade")
            conn.commit()
    snap = current_snapshot_id()
    out_dir = RUNS_DIR / f"build-{split}"
    out_dir.mkdir(parents=True, exist_ok=True)
    with pg.connect(params) as conn:
        apply_schema(conn)
        report = load_snapshot(conn, SPLITS[split], snap)
        report["postgres_version"] = pg.server_version(conn)
        from .views import create_views
        create_views(conn)
        conn.commit()
    print(f"Loaded {report['n_studies_in_scope']} studies ({split}) in {report['seconds']} s; "
          f"{report['n_result_load_exceptions']} result load exceptions")
    if report["unknown_source_keys"]:
        print("Unmapped source keys:", report["unknown_source_keys"])
    if report["value_anomalies"]:
        print("Value anomalies:", report["value_anomalies"])

    from .flat import build_flat
    report["flat"] = build_flat(SPLITS[split], snap, out_dir / "flat")
    with pg.connect(params) as conn:
        from .flat import load_flat
        load_flat(conn, out_dir / "flat", snap)
        conn.commit()

    if not skip_reference:
        report["reference"] = run_reference(snap, SPLITS[split], out_dir / "reference")
        with pg.connect(params) as conn:
            from .reference import load_reference
            load_reference(conn, out_dir / "reference", snap)
            conn.commit()
    write_json(out_dir / "load_report.json", {k: v for k, v in report.items()})
    return report


def run_reference(snapshot_id: str, splits: set[str], out_dir) -> dict:
    """Run the independent R enumerator over the same raw pages."""
    raw_dir, frozen_dir = snapshot_dirs(snapshot_id)
    out_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.monotonic()
    cmd = ["Rscript", "--vanilla", str(R_DIR / "reference_enumerator.R"), str(raw_dir), str(frozen_dir / "manifest.csv"),
           ",".join(sorted(splits)), str(out_dir), snapshot_id]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        raise SystemExit(f"R reference enumerator failed:\n{res.stderr[-4000:]}")
    secs = round(time.monotonic() - t0, 2)
    summary = json.loads((out_dir / "reference_summary.json").read_text())
    summary["seconds"] = secs
    summary["r_stdout_tail"] = res.stdout[-500:]
    print(f"R reference: {summary.get('n_leaves')} leaves from {summary.get('n_studies')} studies in {secs} s")
    return summary
