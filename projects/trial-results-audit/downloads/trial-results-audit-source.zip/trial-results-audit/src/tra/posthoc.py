"""Post hoc descriptive tables, added after the single held-out run (analysis plan, post hoc additions).

They describe the held-out results further and change no prespecified result:
- flat_row_count_differs_spread.csv: how the flat-export values with a different row-level count spread across studies,
  outcomes and primary outcomes, and the outcome groups with row-level counts in which at least one row differs;
- flat_row_count_differs_by_study.csv: those values by study;
- flat_analysis_order_matching.csv: statistical-analysis values in outcomes with two or more analyses, where the flat
  comparison's match depends on their order within the outcome.
Reads the warehouse, the audit views and the R reference; writes results/tables/heldout_posthoc/.
"""
from __future__ import annotations

import csv
from pathlib import Path

from . import pg
from .config import TABLES_DIR, current_snapshot_id

OUT = TABLES_DIR / "heldout_posthoc"
SCOPE = "heldout portion, confirmed cohort (post hoc)"

SPREAD_SQL = """
with ol as (
  select c.nct_id, c.outcome_ordinal, c.group_id, min(c.value_int) as ol_n
  from ctr.outcome_denom d join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
  where d.snapshot_id = %(s)s and lower(trim(d.units)) = 'participants'
  group by 1, 2, 3),
held as (select nct_id from ctr.study where snapshot_id = %(s)s and split = 'heldout' and cohort_status = 'confirmed'),
m as (
  select md.nct_id, md.outcome_ordinal, md.group_id, md.rule_id, o.type as outcome_type,
         md.rule_id = 'B1_ROW_SPECIFIC_DENOMINATOR' and md.participant_denominator is distinct from ol.ol_n as differs
  from audit.mv_measurement_denominator md
  join held using (nct_id)
  join ctr.outcome_measure o on o.snapshot_id = md.snapshot_id and o.nct_id = md.nct_id and o.outcome_ordinal = md.outcome_ordinal
  left join ol on ol.nct_id = md.nct_id and ol.outcome_ordinal = md.outcome_ordinal and ol.group_id = md.group_id
  where md.snapshot_id = %(s)s)
select count(*) filter (where differs) as measurements_differs,
       count(*) as measurements_total,
       count(distinct nct_id) filter (where differs) as studies_differs,
       count(distinct nct_id) as studies_with_values,
       count(distinct (nct_id, outcome_ordinal)) filter (where differs) as outcomes_differs,
       count(distinct (nct_id, outcome_ordinal)) as outcomes_with_values,
       count(*) filter (where differs and outcome_type = 'PRIMARY') as primary_differs,
       count(*) filter (where outcome_type = 'PRIMARY') as primary_total,
       count(distinct (nct_id, outcome_ordinal, group_id)) filter (where differs) as b1_groups_differ,
       count(distinct (nct_id, outcome_ordinal, group_id)) filter (where rule_id = 'B1_ROW_SPECIFIC_DENOMINATOR') as b1_groups_any
from m
"""

TOP_SQL = SPREAD_SQL.split("select count(*) filter")[0] + """
select nct_id, count(*) as n from m where differs group by 1 order by 2 desc, 1
"""

ANALYSIS_SQL = """
with a as (
  select l.nct_id, regexp_match(l.pointer, '^/resultsSection/outcomeMeasuresModule/outcomeMeasures/(\\d+)/analyses/(\\d+)/') as m
  from ref.leaf l join ctr.study s on s.snapshot_id = l.snapshot_id and s.nct_id = l.nct_id
  where l.snapshot_id = %(s)s and s.split = 'heldout' and s.cohort_status = 'confirmed'
    and l.pointer like '/resultsSection/outcomeMeasuresModule/outcomeMeasures/%%/analyses/%%'),
b as (select nct_id, m[1]::int as oi, m[2]::int as ai from a where m is not null),
o as (select nct_id, oi, max(ai) + 1 as n_analyses, count(*) as n_values from b group by 1, 2)
select sum(n_values) as values_total,
       sum(n_values) filter (where n_analyses >= 2) as values_in_outcomes_with_2plus,
       count(*) as outcomes_with_analyses,
       count(*) filter (where n_analyses >= 2) as outcomes_with_2plus
from o
"""


def _write(path: Path, header: list[str], rows: list[list]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)


def posthoc() -> None:
    snap = current_snapshot_id()
    with pg.connect() as conn:
        s = conn.execute(SPREAD_SQL, {"s": snap}).fetchone()
        top = conn.execute(TOP_SQL, {"s": snap}).fetchall()
        a = conn.execute(ANALYSIS_SQL, {"s": snap}).fetchone()
    top10 = sum(n for _, n in top[:10])
    _write(OUT / "flat_row_count_differs_spread.csv",
           ["measure", "unit", "scope", "numerator", "denominator"],
           [["values where the flat export attaches the outcome-level count and the row reports a different number analyzed",
             "measurement", SCOPE, s[0], s[1]],
            ["studies with at least one such value", "study", SCOPE, s[2], s[3]],
            ["outcomes with at least one such value", "outcome", SCOPE, s[4], s[5]],
            ["such values in the ten studies with the most of them", "measurement", SCOPE, top10, s[0]],
            ["such values among measurements of primary outcomes", "measurement", SCOPE, s[6], s[7]],
            ["outcome groups with row-level counts (B1 measurements) in which at least one row's count differs from the outcome-level count",
             "outcome group", SCOPE, s[8], s[9]]])
    _write(OUT / "flat_row_count_differs_by_study.csv", ["nct_id", "unit", "scope", "n"],
           [[n, "measurement", SCOPE, k] for n, k in top])
    _write(OUT / "flat_analysis_order_matching.csv",
           ["measure", "unit", "scope", "numerator", "denominator"],
           [["statistical-analysis values in outcomes with two or more analyses (matched by order in the flat comparison)",
             "source scalar", SCOPE, int(a[1]), int(a[0])],
            ["outcomes with two or more analyses", "outcome", SCOPE, a[3], a[2]]])
    print(f"Post hoc tables written to {OUT}")
