"""Named facts read from result tables. Every number shown in the report, manuscript and page comes from here,
and evidence/claims.json is written from the same records (path, row selector, column, numerator, denominator, unit).
"""
from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .config import EVIDENCE_DIR, FROZEN_DIR, ROOT, TABLES_DIR, current_snapshot_id, snapshot_dirs


@dataclass
class Fact:
    name: str
    value: object
    unit: str
    path: str
    selector: str
    column: str
    numerator: object = None
    denominator: object = None
    scope: str = ""
    note: str = ""

    def pct(self, digits=1):
        if self.numerator is None or not self.denominator:
            return None
        return round(100.0 * float(self.numerator) / float(self.denominator), digits)


def _read(path: Path) -> list[dict]:
    with open(path, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _rel(p: Path) -> str:
    rel = str(p.relative_to(ROOT))
    # raw retrieval records are shipped in the source archive under data/snapshot_provenance/<snapshot>/
    return "data/snapshot_provenance/" + rel[len("data/raw/"):] if rel.startswith("data/raw/") else rel


class Facts:
    def __init__(self, tables: Path | None = None):
        self.tables = (tables or TABLES_DIR / "heldout").resolve()
        self.items: dict[str, Fact] = {}
        self.snapshot = current_snapshot_id()
        self._load()

    def add(self, **kw):
        f = Fact(**kw)
        self.items[f.name] = f
        return f

    def __getitem__(self, k) -> Fact:
        return self.items[k]

    def row(self, fname, **match) -> tuple[dict, Path]:
        p = self.tables / fname
        for r in _read(p):
            if all(r.get(k) == v for k, v in match.items()):
                return r, p
        raise KeyError(f"{fname}: no row matching {match}")

    def _load(self):
        snap = self.snapshot
        raw_dir, frozen_dir = snapshot_dirs(snap)
        state = json.loads((raw_dir / "retrieval_state.json").read_text())
        split = json.loads((frozen_dir / "split_summary.json").read_text())
        sp = frozen_dir / "split_summary.json"
        self.add(name="api_version", value=state["version_before"]["apiVersion"], unit="", path=_rel(raw_dir / "version_before.json"),
                 selector="", column="apiVersion")
        self.add(name="data_timestamp", value=state["version_before"]["dataTimestamp"], unit="", path=_rel(raw_dir / "version_before.json"),
                 selector="", column="dataTimestamp")
        self.add(name="retrieved_at", value=state["retrieval_started_at"], unit="", path=_rel(raw_dir / "retrieval_state.json"),
                 selector="", column="retrieval_started_at")
        for g, n in split["per_query_total_count"].items():
            self.add(name=f"query_{g}", value=n, unit="study", path=_rel(sp), selector="per_query_total_count", column=g)
        for k in ("retrieved_union", "excluded_frame", "ambiguous_condition_match", "confirmed", "confirmed_in_multiple_groups",
                  "clusters", "multi_study_clusters", "near_duplicate_title_pairs"):
            self.add(name=k, value=split[k], unit="study" if k not in ("clusters", "multi_study_clusters", "near_duplicate_title_pairs")
                     else ("identifier cluster" if "cluster" in k else "study pair"), path=_rel(sp), selector="", column=k)
        for g, n in split["confirmed_by_group"].items():
            self.add(name=f"confirmed_{g}", value=n, unit="study", path=_rel(sp), selector="confirmed_by_group", column=g)
        for s, n in split["split_confirmed"].items():
            self.add(name=f"split_{s}", value=n, unit="study", path=_rel(sp), selector="split_confirmed", column=s)

        scope = "held-out portion, confirmed cohort"
        # primary
        r, p = self.row("primary_outcome_group_tiers.csv")
        appl = int(r["n_applicable"])
        self.add(name="og_applicable", value=appl, unit="outcome group", path=_rel(p), selector="(single row)", column="n_applicable", scope=scope)
        self.add(name="og_studies", value=int(r["n_studies"]), unit="study", path=_rel(p), selector="(single row)", column="n_studies", scope=scope)
        for t in "ABC":
            self.add(name=f"og_{t}", value=int(r[f"n_{t}"]), unit="outcome group", path=_rel(p), selector="(single row)",
                     column=f"n_{t}", numerator=int(r[f"n_{t}"]), denominator=appl, scope=scope)
        self.add(name="og_D", value=int(r["n_D_not_applicable"]), unit="outcome group", path=_rel(p), selector="(single row)",
                 column="n_D_not_applicable", scope=scope)
        self.add(name="og_resolvable", value=int(r["n_A"]) + int(r["n_B"]), unit="outcome group", path=_rel(p),
                 selector="(single row)", column="n_A + n_B", numerator=int(r["n_A"]) + int(r["n_B"]), denominator=appl, scope=scope)
        # measurement level
        r, p = self.row("measurement_tiers.csv")
        mappl = int(r["n_applicable"])
        self.add(name="m_total", value=mappl, unit="measurement", path=_rel(p), selector="(single row)", column="n_applicable", scope=scope)
        for t in "ABC":
            self.add(name=f"m_{t}", value=int(r[f"n_{t}"]), unit="measurement", path=_rel(p), selector="(single row)",
                     column=f"n_{t}", numerator=int(r[f"n_{t}"]), denominator=mappl, scope=scope)
        p = self.tables / "measurement_rules.csv"
        for rr in _read(p):
            self.add(name=f"m_rule_{rr['rule_id']}", value=int(rr["n"]), unit="measurement", path=_rel(p),
                     selector=f"rule_id={rr['rule_id']}", column="n", numerator=int(rr["n"]), denominator=mappl, scope=scope)
        p = self.tables / "outcome_group_rules.csv"
        self.og_rules = _read(p)
        # outcomes
        p = self.tables / "outcome_status_and_population_description.csv"
        orows = _read(p)
        n_out = sum(int(x["n"]) for x in orows if x["category"] in ("posted with measurements", "not posted", "no measurements"))
        for x in orows:
            key = {"posted with measurements": "out_posted_meas", "not posted": "out_not_posted", "no measurements": "out_no_meas",
                   "posted outcomes with an analysis population description": "out_popdesc",
                   "posted outcomes with measurements and an analysis population description": "out_popdesc_meas"}.get(x["category"])
            if key:
                den = int(x["denominator"]) if x.get("denominator") else n_out
                self.add(name=key, value=int(x["n"]), unit="outcome", path=_rel(p), selector=f"category={x['category']}",
                         column="n", numerator=int(x["n"]), denominator=den, scope=scope)
        self.add(name="out_total", value=n_out, unit="outcome", path=_rel(p), selector="sum of status categories", column="n", scope=scope)
        # structure
        p = self.tables / "tiers_by_structure.csv"
        for x in _read(p):
            k = {"single row": "single", "categorical (one row, several categories)": "categorical",
                 "multiple rows (classes)": "multirow"}.get(x["structure"])
            if k:
                n = int(x["n_applicable"])
                self.add(name=f"struct_{k}_n", value=n, unit="outcome group", path=_rel(p), selector=f"structure={x['structure']}",
                         column="n_applicable", scope=scope)
                for t in "ABC":
                    self.add(name=f"struct_{k}_{t}", value=int(x[f"n_{t}"]), unit="outcome group", path=_rel(p),
                             selector=f"structure={x['structure']}", column=f"n_{t}", numerator=int(x[f"n_{t}"]), denominator=n, scope=scope)
        p = self.tables / "tiers_by_row_specific_denominators.csv"
        for x in _read(p):
            n = int(x["n_applicable"])
            k = "rowspec" if x["row_specific_denominators"] == "yes" else "norowspec"
            self.add(name=f"{k}_n", value=n, unit="outcome group", path=_rel(p),
                     selector=f"row_specific_denominators={x['row_specific_denominators']}", column="n_applicable", scope=scope)
        p = self.tables / "tiers_by_analysis_unit.csv"
        for x in _read(p):
            k = "unit_part" if x["analysis_unit_type"] == "participants" else "unit_other"
            self.add(name=f"{k}_n", value=int(x["n_applicable"]), unit="outcome group", path=_rel(p),
                     selector=f"analysis_unit_type={x['analysis_unit_type']}", column="n_applicable", scope=scope)
            for t in "ABC":
                self.add(name=f"{k}_{t}", value=int(x[f"n_{t}"]), unit="outcome group", path=_rel(p),
                         selector=f"analysis_unit_type={x['analysis_unit_type']}", column=f"n_{t}", scope=scope)
        p = self.tables / "outcome_group_rules.csv"
        og_rules = {x["rules"]: int(x["n"]) for x in _read(p)}
        self.add(name="og_rule_B2", value=og_rules.get("B2_NON_PARTICIPANT_UNITS", 0), unit="outcome group", path=_rel(p),
                 selector="rules=B2_NON_PARTICIPANT_UNITS", column="n", scope=scope)
        self.add(name="og_rule_B1", value=og_rules.get("B1_ROW_SPECIFIC_DENOMINATOR", 0), unit="outcome group", path=_rel(p),
                 selector="rules=B1_ROW_SPECIFIC_DENOMINATOR", column="n", scope=scope)
        self.by_year = _read(self.tables / "tiers_by_results_first_posted_year.csv")
        self.by_condition = _read(self.tables / "tiers_by_condition_group.csv")
        self.by_param = _read(self.tables / "tiers_by_param_type.csv")
        self.by_type = _read(self.tables / "tiers_by_outcome_type.csv")
        self.studies_by_year = _read(self.tables / "studies_by_results_first_posted_year.csv")
        # flat comparison
        p = self.tables / "flat_denominator_comparison.csv"
        fd = _read(p)
        ntot = sum(int(x["n"]) for x in fd)
        self.add(name="flat_meas_total", value=ntot, unit="measurement", path=_rel(p), selector="sum of categories", column="n", scope=scope)
        names = {"A: flat count equals the reference denominator": "flat_same",
                 "B1: flat attaches the outcome-level count, row-specific count differs": "flat_b1_diff",
                 "B1: flat attaches the outcome-level count, row-specific count is the same value": "flat_b1_same",
                 "B2: flat attaches a participant count to values in another unit": "flat_b2",
                 "C: reference not resolvable; flat attaches a value": "flat_c_value",
                 "C: reference not resolvable; flat attaches nothing": "flat_c_none",
                 "A: flat count differs from the reference denominator": "flat_a_diff",
                 "A: flat attaches nothing": "flat_a_none", "B1: flat attaches nothing": "flat_b1_none",
                 "B2: flat attaches nothing": "flat_b2_none", "D: outcome not posted": "flat_d",
                 "flat row not identifiable": "flat_not_identifiable"}
        for x in fd:
            k = names.get(x["category"])
            if k:
                self.add(name=k, value=int(x["n"]), unit="measurement", path=_rel(p), selector=f"category={x['category']}",
                         column="n", numerator=int(x["n"]), denominator=ntot, scope=scope)
        for k in names.values():
            if k not in self.items:
                self.add(name=k, value=0, unit="measurement", path=_rel(p), selector="category absent", column="n",
                         numerator=0, denominator=ntot, scope=scope)
        wrong = sum(self[k].value for k in ("flat_a_diff", "flat_b1_diff", "flat_c_value"))
        self.add(name="flat_wrong_participant_count", value=wrong, unit="measurement", path=_rel(p),
                 selector="A differs + B1 differs + C with a value", column="n", numerator=wrong, denominator=ntot, scope=scope,
                 note="attached count is not the most specific participant count, or no safe count exists")
        not_appl = wrong + self["flat_b2"].value
        self.add(name="flat_not_applicable_count", value=not_appl, unit="measurement", path=_rel(p),
                 selector="A differs + B1 differs + C with a value + B2", column="n", numerator=not_appl, denominator=ntot,
                 scope=scope, note="adds B2: a participant count attached to values reported in another unit")
        p = self.tables / "flat_outcomes_lost.csv"
        lost = {x["category"]: int(x["n"]) for x in _read(p)}
        self.add(name="flat_outcomes_lost", value=lost.get("outcomes with no value rows (absent from the flat export)", 0),
                 unit="outcome", path=_rel(p), selector="category=outcomes with no value rows (absent from the flat export)",
                 column="n", numerator=lost.get("outcomes with no value rows (absent from the flat export)", 0),
                 denominator=lost.get("outcomes", 0), scope=scope)
        p = self.tables / "retention_flat_vs_warehouse.csv"
        self.retention = _read(p)
        for x in self.retention:
            if x["family"].startswith("TOTAL: all families"):
                key = "ret_attempted"
            elif x["family"].startswith("TOTAL: all in-scope"):
                key = "ret_all"
            else:
                key = "ret_" + x["family"].replace(":", "").replace(",", "").replace(" ", "_")
            n = int(x["n_scalars_in_scope"])
            self.add(name=key + "_flat", value=int(x["flat_recoverable"]), unit="source scalar", path=_rel(p),
                     selector=f"family={x['family']}", column="flat_recoverable", numerator=int(x["flat_recoverable"]),
                     denominator=n, scope=scope)
            self.add(name=key + "_wh", value=int(x["warehouse_exact"]), unit="source scalar", path=_rel(p),
                     selector=f"family={x['family']}", column="warehouse_exact", numerator=int(x["warehouse_exact"]),
                     denominator=n, scope=scope)
        # fidelity
        p = self.tables / "warehouse_fidelity.csv"
        fk = {"in-scope source scalars present in the warehouse with identical text at the same JSON pointer": "fid_scalars",
              "SQL and independent R tier, rule and denominators agree": "fid_tier_m",
              "SQL and independent R outcome-group tier and rules agree": "fid_tier_g",
              "results module rebuilt from the warehouse is identical to the source": "fid_roundtrip",
              "cautious evidence view rows per measurement (duplicate join check)": "fid_evidence_rows"}
        for x in _read(p):
            k = fk.get(x["check"])
            if k:
                self.add(name=k, value=int(x["n"]), unit=x["unit"], path=_rel(p), selector=f"check={x['check']}", column="n",
                         numerator=int(x["n"]), denominator=int(x["denominator"]), scope=scope)
        p = self.tables / "warehouse_leaf_reconciliation.csv"
        excl = sum(int(x["n"]) for x in _read(p) if x["status"] == "excluded by design")
        self.add(name="excluded_scalars", value=excl, unit="source scalar", path=_rel(p), selector="status=excluded by design",
                 column="n (summed over modules)", scope=scope)
        bad = sum(int(x["n"]) for x in _read(p) if x["status"] in ("missing in warehouse", "extra in warehouse", "value differs"))
        self.add(name="transformation_defects", value=bad, unit="source scalar", path=_rel(p),
                 selector="status in (missing, extra, value differs)", column="n (summed)", scope=scope)
        p = self.tables / "object_count_reconciliation.csv"
        oc = _read(p)
        self.add(name="object_patterns", value=sum(1 for x in oc if x["study_mismatches"] != ""), unit="object type", path=_rel(p),
                 selector="mapped patterns", column="count of rows", scope=scope)
        self.add(name="object_mismatches", value=sum(int(x["study_mismatches"] or 0) for x in oc), unit="study x object type",
                 path=_rel(p), selector="mapped patterns", column="study_mismatches (summed)", scope=scope)
        self.add(name="objects_total", value=sum(int(x["reference"]) for x in oc if x["study_mismatches"] != ""), unit="object",
                 path=_rel(p), selector="mapped patterns", column="reference (summed)", scope=scope)
        # checks
        p = self.tables / "checks_summary.csv"
        self.checks = _read(p)
        tot_app = sum(int(x["n_applicable"]) for x in self.checks)
        tot_fail = sum(int(x["n_fail"]) for x in self.checks)
        tot_ne = sum(int(x["n_not_evaluable"]) for x in self.checks)
        self.add(name="checks_applicable", value=tot_app, unit="applicable check", path=_rel(p), selector="all checks",
                 column="n_applicable (summed)", scope=scope)
        self.add(name="checks_fail", value=tot_fail, unit="applicable check", path=_rel(p), selector="all checks",
                 column="n_fail (summed)", numerator=tot_fail, denominator=tot_app - tot_ne, scope=scope)
        self.add(name="checks_not_evaluable", value=tot_ne, unit="applicable check", path=_rel(p), selector="all checks",
                 column="n_not_evaluable (summed)", scope=scope)
        for x in self.checks:
            self.add(name=f"check_{x['check_id']}_fail", value=int(x["n_fail"]), unit="applicable check", path=_rel(p),
                     selector=f"check_id={x['check_id']}", column="n_fail", numerator=int(x["n_fail"]),
                     denominator=int(x["n_pass"]) + int(x["n_fail"]), scope=scope)
            self.add(name=f"check_{x['check_id']}_studies", value=int(x["n_studies_with_a_failure"]), unit="study", path=_rel(p),
                     selector=f"check_id={x['check_id']}", column="n_studies_with_a_failure", scope=scope)
        # ledger
        p = self.tables / "issue_ledger_summary.csv"
        self.ledger_summary = _read(p)
        for x in self.ledger_summary:
            self.add(name=f"ledger_rule_{x['rule_id']}", value=int(x["n"]), unit="ledger row", path=_rel(p),
                     selector=f"issue_class={x['issue_class']}, rule_id={x['rule_id']}", column="n", scope=scope)
            self.add(name=f"ledger_rule_{x['rule_id']}_studies", value=int(x["n_studies"]), unit="study", path=_rel(p),
                     selector=f"issue_class={x['issue_class']}, rule_id={x['rule_id']}", column="n_studies", scope=scope)
        for cls in ("transformation defect", "possible source inconsistency", "unresolved interpretation"):
            rows = [x for x in self.ledger_summary if x["issue_class"] == cls]
            self.add(name="ledger_" + cls.split()[0], value=sum(int(x["n"]) for x in rows), unit="ledger row", path=_rel(p),
                     selector=f"issue_class={cls}", column="n (summed)", scope=scope)
        # cross-module
        p = self.tables / "cross_module_label_identity.csv"
        cm = {x["category"]: int(x["n"]) for x in _read(p)}
        base = cm["same title, both counts usable"]
        self.add(name="cm_base", value=cm["posted outcome groups with measurements"], unit="outcome group", path=_rel(p),
                 selector="category=posted outcome groups with measurements", column="n", scope=scope)
        self.add(name="cm_match", value=cm["exactly one baseline group with the same title"], unit="outcome group", path=_rel(p),
                 selector="category=exactly one baseline group with the same title", column="n",
                 numerator=cm["exactly one baseline group with the same title"], denominator=cm["posted outcome groups with measurements"], scope=scope)
        self.add(name="cm_usable", value=base, unit="outcome group", path=_rel(p), selector="category=same title, both counts usable",
                 column="n", scope=scope)
        self.add(name="cm_diff", value=cm["same title, different participant count"], unit="outcome group", path=_rel(p),
                 selector="category=same title, different participant count", column="n",
                 numerator=cm["same title, different participant count"], denominator=base, scope=scope)
        r, p = self.row("group_id_scope.csv")
        self.add(name="og000_varies", value=int(r["n"]), unit="study", path=_rel(p), selector="(single row)", column="n",
                 numerator=int(r["n"]), denominator=int(r["denominator"]), scope=scope + "; studies with OG000 in two or more outcomes")
        # sensitivity and bootstrap
        self.sensitivity = _read(self.tables / "sensitivity_analyses.csv")
        self.bootstrap = _read(self.tables / "exploratory_trial_bootstrap.csv")
        rt = TABLES_DIR / "runtime" / f"{self.tables.name}_runtime_storage.csv"
        self.runtime = _read(rt) if rt.exists() else []
        self.cohort_flow = _read(self.tables / "cohort_flow.csv")
        self.popdesc_by_type = _read(self.tables / "population_description_by_outcome_type.csv")
        self.example = json.loads((self.tables / "example_multi_population.json").read_text())
        ledger = _read(self.tables / "issue_ledger.csv")
        nt = [json.loads(x["evidence"])["value"] for x in ledger if x["rule_id"] == "NUMERIC_TEXT_NOT_PLAIN"]
        self.numeric_text_examples = nt[:3]
        self.c_rules_present = sorted({x["rule_id"] for x in _read(self.tables / "measurement_rules.csv")
                                       if x["rule_id"].startswith("C")})
        hr = EVIDENCE_DIR / "heldout_run.json"
        self.heldout_run = json.loads(hr.read_text()) if hr.exists() else {}
        fz = EVIDENCE_DIR / "parser_freeze.json"
        self.freeze = json.loads(fz.read_text()) if fz.exists() else {}
        self._load_posthoc()

    def _load_posthoc(self):
        """Post hoc descriptive tables (python -m tra posthoc), labeled as such wherever they are reported."""
        ph = self.tables.parent / "heldout_posthoc"
        self.ph_top_study = ("", 0)
        if (ph / "flat_row_count_differs_by_study.csv").exists():
            top = _read(ph / "flat_row_count_differs_by_study.csv")[0]
            self.ph_top_study = (top["nct_id"], int(top["n"]))
        keys = {"studies with at least one such value": "ph_flat_diff_studies",
                "outcomes with at least one such value": "ph_flat_diff_outcomes",
                "such values in the ten studies with the most of them": "ph_flat_diff_top10",
                "such values among measurements of primary outcomes": "ph_flat_diff_primary",
                "outcome groups with row-level counts (B1 measurements) in which at least one row's count differs from the outcome-level count":
                    "ph_b1_groups_differ",
                "statistical-analysis values in outcomes with two or more analyses (matched by order in the flat comparison)":
                    "ph_analysis_order_values",
                "outcomes with two or more analyses": "ph_analysis_order_outcomes"}
        for fname in ("flat_row_count_differs_spread.csv", "flat_analysis_order_matching.csv"):
            p = ph / fname
            if not p.exists():
                continue
            for x in _read(p):
                if x["measure"] in keys:
                    self.add(name=keys[x["measure"]], value=int(x["numerator"]), unit=x["unit"], path=_rel(p),
                             selector=f"measure={x['measure']}", column="numerator", numerator=int(x["numerator"]),
                             denominator=int(x["denominator"]), scope=x["scope"])

    # formatting helpers for templates
    def n(self, k) -> str:
        v = self[k].value
        return f"{v:,}" if isinstance(v, int) else str(v)

    def p(self, k, digits=1) -> str:
        f = self[k]
        if f.numerator is None or not f.denominator:
            return "n/a"
        raw = 100.0 * float(f.numerator) / float(f.denominator)
        if 0 < raw < 10 ** -digits:
            return f"<{10 ** -digits:g}%"
        if raw < 100 and round(raw, digits) == 100:
            return f">{100 - 10 ** -digits:g}%"
        return f"{raw:.{digits}f}%"

    def np(self, k, digits=1) -> str:
        f = self[k]
        return f"{f.value:,} of {f.denominator:,} ({self.p(k, digits)})"

    def claims(self, run_id: str | None = None) -> dict:
        from .manifest import canonical_sha256  # noqa: F401
        state = json.loads((snapshot_dirs(self.snapshot)[0] / "retrieval_state.json").read_text())
        pages = sorted(f"{v['file']}:{v['sha256']}" for v in state["batches"].values())
        import hashlib
        return {
            "snapshot_id": self.snapshot,
            "source_pages_combined_sha256": hashlib.sha256("\n".join(pages).encode()).hexdigest(),
            "run_id": run_id or self.heldout_run.get("run_id"),
            "parser_freeze_sha256": self.freeze.get("combined_sha256"),
            "configuration": ["config/cohort.yaml", "config/database.yaml", "docs/rules.md"],
            "note": ("Counts are kept separate by unit: source records, eligible cohort, held-out portion, outcome groups, "
                     "measurements, source scalars and applicable checks are different quantities. No model calls were made."),
            "claims": [asdict(f) for f in self.items.values()],
        }
