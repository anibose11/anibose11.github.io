"""Figures as accessible inline SVG, drawn from the result tables (presentation only; computes nothing new).

Palette checked for contrast and color-vision-deficiency separation on the light surface #fcfcfb: blue #2a78d6, orange #eb6834,
aqua #1baf7a (aqua is below 3:1 contrast, so every chart that uses it carries direct labels and a table view).
Each mark has a <title> so hovering shows its exact count and denominator.
"""
from __future__ import annotations

import csv
import html
from pathlib import Path

SURFACE = "#fcfcfb"
INK = "#1d1d1b"
INK2 = "#52514e"
GRID = "#e4e3df"
AXIS = "#b9b8b2"
BLUE, ORANGE, AQUA, GREY = "#2a78d6", "#eb6834", "#1baf7a", "#a9a8a2"
FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif"
TIER_COLOR = {"A": BLUE, "B": ORANGE, "C": AQUA}
TIER_NAME = {"A": "Directly structured", "B": "Explicit rule needed", "C": "Not safely resolvable"}


def _e(s) -> str:
    return html.escape(str(s), quote=True)


def _read(path: Path) -> list[dict]:
    with open(path, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def _svg(w, h, title, desc, body, fig_id) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="100%" role="img" '
            f'aria-labelledby="{fig_id}-t {fig_id}-d" style="max-width:{w}px;height:auto;font-family:{FONT}">'
            f'<title id="{fig_id}-t">{_e(title)}</title><desc id="{fig_id}-d">{_e(desc)}</desc>'
            f'<rect width="{w}" height="{h}" fill="{SURFACE}"/>{body}</svg>')


def _subtitle(text, y=38, width_chars=118) -> tuple[str, int]:
    """Subtitle wrapped to the chart width; returns (svg, extra height used)."""
    words, line, lines = text.split(), "", []
    for wd in words:
        if len(line) + len(wd) + 1 > width_chars:
            lines.append(line)
            line = wd
        else:
            line = (line + " " + wd).strip()
    lines.append(line)
    svg = "".join(f'<text x="0" y="{y + 16 * i}" font-size="12.5" fill="{INK2}">{_e(t)}</text>' for i, t in enumerate(lines))
    return svg, 16 * (len(lines) - 1)


def _pct_label(n, total) -> str:
    p = 100 * n / total if total else 0
    if 0 < p < 0.05:
        return "<0.1%"
    if 99.95 <= p < 100:
        return ">99.9%"
    return f"{p:.1f}%"


def _bar(x, y, w, h, color, tip, round_end=True) -> str:
    if w <= 0:
        return ""
    r = min(4, w / 2, h / 2) if round_end else 0
    if r:
        path = (f"M{x:.1f},{y:.1f} h{w - r:.1f} a{r},{r} 0 0 1 {r},{r} v{h - 2 * r:.1f} a{r},{r} 0 0 1 -{r},{r} "
                f"h-{w - r:.1f} z")
        shape = f'<path d="{path}" fill="{color}"/>'
    else:
        shape = f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{color}"/>'
    return f'<g><title>{_e(tip)}</title>{shape}</g>'


def _key(items, y=4, stacked=False) -> str:
    """Color key inside the graphic (journal figures carry their key but not their title)."""
    out, x = [], 0
    for color, label in items:
        out.append(f'<rect x="{x}" y="{y}" width="12" height="12" rx="2" fill="{color}"/>'
                   f'<text x="{x + 17}" y="{y + 10}" font-size="12" fill="{INK}">{_e(label)}</text>')
        if stacked:
            y += 18
        else:
            x += 17 + int(len(label) * 6.6) + 24
    return "".join(out)


def fig_flat_denominator(tables: Path, journal: bool = False) -> str:
    """Single series, emphasis on the categories where the flat export's count is not the applicable one."""
    rows = _read(tables / "flat_denominator_comparison.csv")
    total = sum(int(r["n"]) for r in rows)
    order = [
        ("A: flat count equals the reference denominator", "Outcome-level count applies, and the flat export attaches it", False),
        ("A: flat count differs from the reference denominator", "Outcome-level count applies, but a different count is attached", True),
        ("B1: flat attaches the outcome-level count, row-specific count is the same value",
         "Row-level count applies; same value as the attached outcome-level count", False),
        ("B1: flat attaches the outcome-level count, row-specific count differs",
         "Row-level count applies and differs from the attached outcome-level count", True),
        ("B2: flat attaches a participant count to values in another unit",
         "Values are per another unit (clinics, eyes, samples); a participant count is attached", True),
        ("C: reference not resolvable; flat attaches a value", "No safe participant count; the flat export cell holds \"NA\"", True),
        ("flat row not identifiable", "Value cannot be located uniquely in the flat file", True),
    ]
    known = {k for k, *_ in order}
    for r in rows:
        if r["category"] not in known and int(r["n"]) > 0:
            order.append((r["category"], r["category"], True))
    by = {r["category"]: int(r["n"]) for r in rows}
    sub, extra = _subtitle(f"Held-out confirmed cohort; n = {total:,} outcome measurements. Orange marks bars where the attached "
                           "count is not, or cannot be shown to be, the denominator of the value: the row has its own, different number "
                           "analyzed, the values are per another unit, no count can be attached safely, or the value cannot be "
                           "located uniquely.")
    w, left, right, top, bh, gap = 760, 300, 120, 62 + extra, 22, 26
    if journal:
        top = 56
    h = top + len(order) * (bh + gap) + 30
    plot_w = w - left - right
    mx = max(by.get(k, 0) for k, *_ in order) or 1
    body = [f'<text x="0" y="18" font-size="15" font-weight="600" fill="{INK}">Denominator attached by the flat export, per measurement</text>',
            sub]
    if journal:
        body = [_key([(GREY, "Attached count is the applicable participant count"),
                      (ORANGE, "Attached count is not, or cannot be shown to be, the applicable denominator")], stacked=True)]
    for i, (key, label, emph) in enumerate(order):
        n = by.get(key, 0)
        y = top + i * (bh + gap)
        bw = plot_w * n / mx
        color = ORANGE if emph else GREY
        words, line, lines = label.split(), "", []
        for wd in words:
            if len(line) + len(wd) + 1 > 44:
                lines.append(line)
                line = wd
            else:
                line = (line + " " + wd).strip()
        lines.append(line)
        for j, ln in enumerate(lines[:2]):
            body.append(f'<text x="{left - 10}" y="{y + 9 + j * 14 - (len(lines[:2]) - 1) * 7 + 6}" font-size="12" '
                        f'text-anchor="end" fill="{INK}">{_e(ln)}</text>')
        body.append(_bar(left, y, bw, bh, color, f"{label}: {n:,} of {total:,} measurements ({_pct_label(n, total)})"))
        body.append(f'<text x="{left + bw + 6:.1f}" y="{y + bh / 2 + 4}" font-size="12" fill="{INK}">'
                    f'{n:,} ({_e(_pct_label(n, total))})</text>')
    body.append(f'<line x1="{left}" y1="{top - 6}" x2="{left}" y2="{h - 22}" stroke="{AXIS}" stroke-width="1"/>')
    return _svg(w, h, "Denominator attached by the flat export",
                f"Bar chart of {total:,} held-out outcome measurements by how the denominator attached by the flat export compares "
                "with the applicable participant denominator under the written rules.", "".join(body), "fig-flatden")


def fig_retention(tables: Path, journal: bool = False) -> str:
    """Two series dot plot: warehouse exact versus flat recoverable, by scalar family."""
    rows = [r for r in _read(tables / "retention_flat_vs_warehouse.csv")
            if not r["family"].startswith("TOTAL") and r["family"] not in ("adverse events", "more information")]
    rows.sort(key=lambda r: int(r["flat_recoverable"]) / max(int(r["n_scalars_in_scope"]), 1))
    sub, extra = _subtitle("Percent of source scalars in the held-out confirmed cohort. Adverse events and the more-information "
                           "module are left out because the flat export does not attempt them.")
    w, left, right, top, row_h = 760, 330, 40, 80 + extra, 26
    if journal:
        sub, extra, top = "", -50, 40
    h = top + len(rows) * row_h + 40
    plot_w = w - left - right
    x = lambda p: left + plot_w * p / 100.0  # noqa: E731
    body = [] if journal else [f'<text x="0" y="18" font-size="15" font-weight="600" fill="{INK}">Source values each representation returns exactly, by field family</text>']
    body += [sub,
            f'<circle cx="{left}" cy="{62 + extra}" r="5" fill="{BLUE}" stroke="{SURFACE}" stroke-width="2"/>'
            f'<text x="{left + 10}" y="{66 + extra}" font-size="12" fill="{INK}">Relational warehouse</text>'
            f'<circle cx="{left + 160}" cy="{62 + extra}" r="5" fill="{ORANGE}" stroke="{SURFACE}" stroke-width="2"/>'
            f'<text x="{left + 170}" y="{66 + extra}" font-size="12" fill="{INK}">Flat export</text>']
    for p in (0, 25, 50, 75, 100):
        body.append(f'<line x1="{x(p):.1f}" y1="{top - 8}" x2="{x(p):.1f}" y2="{top + len(rows) * row_h}" stroke="{GRID}" stroke-width="1"/>'
                    f'<text x="{x(p):.1f}" y="{top + len(rows) * row_h + 16}" font-size="11" text-anchor="middle" fill="{INK2}">{p}%</text>')
    for i, r in enumerate(rows):
        y = top + i * row_h + row_h / 2
        n = int(r["n_scalars_in_scope"])
        # percentages from the counts, not from the rounded CSV column, so labels are rounded once
        wp = 100.0 * int(r["warehouse_exact"]) / n if n else 0.0
        fp = 100.0 * int(r["flat_recoverable"]) / n if n else 0.0
        fam = r["family"].replace("row-specific denominators", "row-level denominators").replace(
            "measurement values", "measurement fields")
        body.append(f'<text x="{left - 12}" y="{y + 4}" font-size="12" text-anchor="end" fill="{INK}">{_e(fam)}</text>')
        body.append(f'<line x1="{x(fp):.1f}" y1="{y}" x2="{x(wp):.1f}" y2="{y}" stroke="{AXIS}" stroke-width="2"/>')
        body.append(f'<g><title>{_e(fam)}, flat export: {int(r["flat_recoverable"]):,} of {n:,} ({_e(_pct_label(int(r["flat_recoverable"]), n))})</title>'
                    f'<circle cx="{x(fp):.1f}" cy="{y}" r="5" fill="{ORANGE}" stroke="{SURFACE}" stroke-width="2"/></g>')
        body.append(f'<g><title>{_e(fam)}, warehouse: {int(r["warehouse_exact"]):,} of {n:,} ({_e(_pct_label(int(r["warehouse_exact"]), n))})</title>'
                    f'<circle cx="{x(wp):.1f}" cy="{y}" r="5" fill="{BLUE}" stroke="{SURFACE}" stroke-width="2"/></g>')
        if fp < 95:
            body.append(f'<text x="{x(fp) + (9 if fp < 50 else -9):.1f}" y="{y - 7}" font-size="10.5" '
                        f'text-anchor="{"start" if fp < 50 else "end"}" fill="{INK2}">{_e(_pct_label(int(r["flat_recoverable"]), n))}</text>')
    return _svg(w, h, "Source values returned exactly, by field family",
                "Dot plot comparing, for each family of source fields, the percent of source values returned exactly by the "
                "relational warehouse and by the flat export.", "".join(body), "fig-retention")


def fig_tiers_by_structure(tables: Path, journal: bool = False) -> str:
    """Stacked horizontal bars (A, B, C) per outcome structure, among applicable outcome groups."""
    prim = _read(tables / "primary_outcome_group_tiers.csv")[0]
    order = {"single row": 0, "categorical (one row, several categories)": 1, "multiple rows (classes)": 2}
    labels = {"single row": "Single row", "categorical (one row, several categories)": "One row, several categories",
              "multiple rows (classes)": "Several rows"}
    rows = [dict(r, label=labels.get(r["structure"], r["structure"].capitalize())) for r in _read(tables / "tiers_by_structure.csv")
            if int(r["n_applicable"]) > 0]
    rows.sort(key=lambda r: order.get(r["structure"], 9))
    rows = [dict(prim, label="All applicable outcome groups")] + rows
    w, left, right, top, bh, gap = 760, 250, 30, 84, 20, 30
    ky = 52
    if journal:
        top, ky = 40, 6
    h = top + len(rows) * (bh + gap) + 20
    plot_w = w - left - right
    body = [] if journal else [
        f'<text x="0" y="18" font-size="15" font-weight="600" fill="{INK}">How each outcome group gets its participant denominator</text>',
        f'<text x="0" y="38" font-size="12.5" fill="{INK2}">Held-out confirmed cohort, applicable outcome groups, by the structure of the outcome table.</text>']
    lx = left
    for t in "ABC":
        body.append(f'<rect x="{lx}" y="{ky}" width="12" height="12" rx="2" fill="{TIER_COLOR[t]}"/>'
                    f'<text x="{lx + 17}" y="{ky + 10}" font-size="12" fill="{INK}">{t}: {TIER_NAME[t]}</text>')
        lx += 170
    for i, r in enumerate(rows):
        y = top + i * (bh + gap)
        n = int(r["n_applicable"])
        body.append(f'<text x="{left - 10}" y="{y + 9}" font-size="12" text-anchor="end" fill="{INK}">{_e(r["label"])}</text>'
                    f'<text x="{left - 10}" y="{y + 23}" font-size="11" text-anchor="end" fill="{INK2}">n = {n:,}</text>')
        xx = left
        segs = [(t, int(r[f"n_{t}"])) for t in "ABC"]
        for k, (t, c) in enumerate(segs):
            sw = plot_w * c / n if n else 0
            last = all(c2 == 0 for _, c2 in segs[k + 1:])
            tip = f'{r["label"]}, tier {t} ({TIER_NAME[t]}): {c:,} of {n:,} ({100 * c / n:.2f}%)' if n else ""
            if sw > 0:
                body.append(_bar(xx, y, max(sw - (0 if last else 2), 0.8), bh, TIER_COLOR[t], tip, round_end=last))
            if sw > 46:
                body.append(f'<text x="{xx + 6:.1f}" y="{y + 14}" font-size="11" fill="#ffffff">{100 * c / n:.1f}%</text>')
            xx += sw
        c_n = int(r["n_C"])
        if c_n:
            body.append(f'<text x="{w - right:.1f}" y="{y + bh + 12}" font-size="10.5" text-anchor="end" fill="{INK2}">C: {c_n:,}</text>')
    return _svg(w, h, "How each outcome group gets its participant denominator",
                "Stacked bars showing the share of applicable held-out outcome groups in tiers A, B and C, overall and by outcome "
                "table structure.", "".join(body), "fig-tiers")


def write_figures(tables: Path, out_dir: Path, journal: bool = False) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    # numbered as in the manuscript: Figure 1 tiers, Figure 2 flat-export denominators, Figure 3 retention
    figs = {"fig1_tiers_by_structure.svg": fig_tiers_by_structure(tables, journal),
            "fig2_flat_denominator.svg": fig_flat_denominator(tables, journal),
            "fig3_retention_by_family.svg": fig_retention(tables, journal)}
    paths = {}
    for name, svg in figs.items():
        p = out_dir / name
        p.write_text(svg, encoding="utf-8")
        paths[name] = p
    return paths
