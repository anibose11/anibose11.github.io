"""Round trip: rebuild each results module from the warehouse and compare it with the original record.

The comparison is on canonical JSON (sorted keys). The point-of-contact and certain-agreement subtrees are removed
from the source side because they are deliberately not loaded. Unit of the result: study module.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

from .manifest import iter_snapshot_studies
from .spec import OBJ_BY_NAME, table_columns


def _fetch(conn, objname: str, snapshot_id: str, scope: list[str]) -> dict:
    obj = OBJ_BY_NAME[objname]
    cols = table_columns(obj)
    is_group = objname in ("flow_group", "baseline_group", "outcome_group", "ae_group")
    # groups are rebuilt in source order (group_ordinal), not in group_id order
    keys = ["nct_id"] + [k for k in obj.keys if not (is_group and k == "group_id")] + (["group_ordinal"] if is_group else [])
    order = ", ".join(keys)
    rows = conn.execute(f"select {', '.join(cols)} from ctr.{obj.table} where snapshot_id=%s and nct_id = any(%s) order by {order}",
                        (snapshot_id, scope)).fetchall()
    out = defaultdict(list)
    for r in rows:
        d = dict(zip(cols, r))
        out[d["nct_id"]].append(d)
    return out


def _fields(objname: str, row: dict) -> dict:
    out = {}
    for f in OBJ_BY_NAME[objname].fields:
        v = row[f.text_column()]
        if v is not None:
            out[f.key] = v
    return out


def rebuild(conn, snapshot_id: str, scope: list[str]) -> dict[str, dict]:
    names = ["flow_module", "flow_group", "flow_period", "flow_milestone", "flow_achievement", "flow_drop_withdraw",
             "flow_drop_reason", "baseline_module", "baseline_group", "baseline_denom", "baseline_denom_count",
             "baseline_measure", "baseline_measure_denom", "baseline_measure_denom_count", "baseline_class",
             "baseline_class_denom", "baseline_class_denom_count", "baseline_category", "baseline_measurement",
             "outcome_measure", "outcome_group", "outcome_denom", "outcome_denom_count", "outcome_class",
             "outcome_class_denom", "outcome_class_denom_count", "outcome_category", "outcome_measurement",
             "outcome_analysis", "outcome_analysis_group", "ae_module", "ae_group", "ae_event", "ae_event_stat", "more_info"]
    data = {n: _fetch(conn, n, snapshot_id, scope) for n in names}
    present = defaultdict(set)
    for nct, module, p in conn.execute("select nct_id, module, present from ctr.result_module where snapshot_id=%s and nct_id = any(%s)",
                                       (snapshot_id, scope)).fetchall():
        if p:
            present[nct].add(module)

    def children(name, nct, **match):
        return [r for r in data[name].get(nct, []) if all(r[k] == v for k, v in match.items())]

    def denoms(prefix, nct, **match):
        out = []
        for d in children(f"{prefix}_denom", nct, **match):
            dd = _fields(f"{prefix}_denom", d)
            cnts = [_fields(f"{prefix}_denom_count", c) for c in children(f"{prefix}_denom_count", nct, denom_ordinal=d["denom_ordinal"], **match)]
            if cnts:
                dd["counts"] = cnts
            out.append(dd)
        return out

    def put(d, key, lst):
        if lst:
            d[key] = lst

    result = {}
    for nct in scope:
        rs = {}
        if "participant_flow" in present[nct] and data["flow_module"].get(nct):
            fm = data["flow_module"][nct][0]
            pf = _fields("flow_module", fm)
            put(pf, "groups", [_fields("flow_group", g) for g in data["flow_group"].get(nct, [])])
            periods = []
            for p in data["flow_period"].get(nct, []):
                pd = _fields("flow_period", p)
                ms = []
                for m in children("flow_milestone", nct, period_ordinal=p["period_ordinal"]):
                    md = _fields("flow_milestone", m)
                    put(md, "achievements", [_fields("flow_achievement", a) for a in children(
                        "flow_achievement", nct, period_ordinal=p["period_ordinal"], milestone_ordinal=m["milestone_ordinal"])])
                    ms.append(md)
                put(pd, "milestones", ms)
                dws = []
                for d in children("flow_drop_withdraw", nct, period_ordinal=p["period_ordinal"]):
                    dd = _fields("flow_drop_withdraw", d)
                    put(dd, "reasons", [_fields("flow_drop_reason", r) for r in children(
                        "flow_drop_reason", nct, period_ordinal=p["period_ordinal"], drop_ordinal=d["drop_ordinal"])])
                    dws.append(dd)
                put(pd, "dropWithdraws", dws)
                periods.append(pd)
            put(pf, "periods", periods)
            rs["participantFlowModule"] = pf
        if "baseline" in present[nct] and data["baseline_module"].get(nct):
            bl = _fields("baseline_module", data["baseline_module"][nct][0])
            put(bl, "groups", [_fields("baseline_group", g) for g in data["baseline_group"].get(nct, [])])
            put(bl, "denoms", denoms("baseline", nct))
            measures = []
            for m in data["baseline_measure"].get(nct, []):
                k = m["measure_ordinal"]
                md = _fields("baseline_measure", m)
                put(md, "denoms", denoms("baseline_measure", nct, measure_ordinal=k))
                classes = []
                for c in children("baseline_class", nct, measure_ordinal=k):
                    cd = _fields("baseline_class", c)
                    put(cd, "denoms", denoms("baseline_class", nct, measure_ordinal=k, class_ordinal=c["class_ordinal"]))
                    cats = []
                    for t in children("baseline_category", nct, measure_ordinal=k, class_ordinal=c["class_ordinal"]):
                        td = _fields("baseline_category", t)
                        put(td, "measurements", [_fields("baseline_measurement", v) for v in children(
                            "baseline_measurement", nct, measure_ordinal=k, class_ordinal=c["class_ordinal"],
                            category_ordinal=t["category_ordinal"])])
                        cats.append(td)
                    put(cd, "categories", cats)
                    classes.append(cd)
                put(md, "classes", classes)
                measures.append(md)
            put(bl, "measures", measures)
            rs["baselineCharacteristicsModule"] = bl
        if "outcome_measures" in present[nct]:
            oms = []
            for o in data["outcome_measure"].get(nct, []):
                oi = o["outcome_ordinal"]
                od = _fields("outcome_measure", o)
                put(od, "groups", [_fields("outcome_group", g) for g in children("outcome_group", nct, outcome_ordinal=oi)])
                put(od, "denoms", denoms("outcome", nct, outcome_ordinal=oi))
                classes = []
                for c in children("outcome_class", nct, outcome_ordinal=oi):
                    cd = _fields("outcome_class", c)
                    put(cd, "denoms", denoms("outcome_class", nct, outcome_ordinal=oi, class_ordinal=c["class_ordinal"]))
                    cats = []
                    for t in children("outcome_category", nct, outcome_ordinal=oi, class_ordinal=c["class_ordinal"]):
                        td = _fields("outcome_category", t)
                        put(td, "measurements", [_fields("outcome_measurement", v) for v in children(
                            "outcome_measurement", nct, outcome_ordinal=oi, class_ordinal=c["class_ordinal"],
                            category_ordinal=t["category_ordinal"])])
                        cats.append(td)
                    put(cd, "categories", cats)
                    classes.append(cd)
                put(od, "classes", classes)
                analyses = []
                for a in children("outcome_analysis", nct, outcome_ordinal=oi):
                    ad = _fields("outcome_analysis", a)
                    put(ad, "groupIds", [g["group_id"] for g in children("outcome_analysis_group", nct, outcome_ordinal=oi,
                                                                          analysis_ordinal=a["analysis_ordinal"])])
                    analyses.append(ad)
                put(od, "analyses", analyses)
                oms.append(od)
            om = {}
            put(om, "outcomeMeasures", oms)
            rs["outcomeMeasuresModule"] = om
        if "adverse_events" in present[nct] and data["ae_module"].get(nct):
            ae = _fields("ae_module", data["ae_module"][nct][0])
            put(ae, "eventGroups", [_fields("ae_group", g) for g in data["ae_group"].get(nct, [])])
            for key, seriousness in (("seriousEvents", "serious"), ("otherEvents", "other")):
                evs = []
                for e in children("ae_event", nct, seriousness=seriousness):
                    ed = _fields("ae_event", e)
                    put(ed, "stats", [_fields("ae_event_stat", s) for s in children(
                        "ae_event_stat", nct, seriousness=seriousness, event_ordinal=e["event_ordinal"])])
                    evs.append(ed)
                put(ae, key, evs)
            rs["adverseEventsModule"] = ae
        if "more_info" in present[nct]:
            mi = {}
            rows = data["more_info"].get(nct, [])
            if rows and rows[0]["limitations_and_caveats"] is not None:
                mi["limitationsAndCaveats"] = {"description": rows[0]["limitations_and_caveats"]}
            rs["moreInfoModule"] = mi
        result[nct] = rs
    return result


def _strip_excluded(rs: dict) -> dict:
    rs = json.loads(json.dumps(rs))
    mi = rs.get("moreInfoModule")
    if isinstance(mi, dict):
        mi.pop("pointOfContact", None)
        mi.pop("certainAgreement", None)
        lc = mi.get("limitationsAndCaveats")
        if isinstance(lc, dict) and "description" not in lc:
            mi.pop("limitationsAndCaveats")
    return rs


def canonical(obj) -> str:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def roundtrip(conn, snapshot_id: str, raw_dir: Path, scope: set[str], batch: int = 300) -> dict:
    """Studies quarantined at load (ctr.load_exception) are reported separately, not rebuilt."""
    results = []
    quarantined = {r[0] for r in conn.execute("select nct_id from ctr.load_exception where snapshot_id=%s", (snapshot_id,)).fetchall()}
    q_in_scope = sorted(quarantined & set(scope))
    scope = set(scope) - quarantined
    ids = sorted(scope)
    sources = {}
    for _, study in iter_snapshot_studies(raw_dir):
        nct = study["protocolSection"]["identificationModule"]["nctId"]
        if nct in scope:
            sources[nct] = _strip_excluded(study.get("resultsSection") or {})
    for i in range(0, len(ids), batch):
        chunk = ids[i:i + batch]
        rebuilt = rebuild(conn, snapshot_id, chunk)
        for nct in chunk:
            src, wh = sources[nct], rebuilt[nct]
            for module in sorted(set(src) | set(wh)):
                results.append({"nct_id": nct, "module": module,
                                "identical": canonical(src.get(module)) == canonical(wh.get(module))})
    n = len(results)
    same = sum(r["identical"] for r in results)
    return {"unit": "study module", "n": n, "identical": same,
            "differing": [r for r in results if not r["identical"]][:50], "n_differing": n - same,
            "quarantined_studies_not_rebuilt": q_in_scope}
