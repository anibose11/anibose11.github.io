"""Information retention of the flat baseline, measured scalar by scalar against the raw source.

For every scalar under resultsSection (the same set the R reference enumerates), decide whether the flat export
can return that exact text under an unambiguous context:
  recoverable                  exactly one flat row matches the scalar's full context and a cell holds the identical text
  ambiguous context            more than one flat row matches the context (the source nesting cannot be rebuilt)
  absent from rows             the export has a column for the field but no row for this object
                               (for example outcomes, rows or groups without values)
  value differs                a matching row exists but its cell text differs from the source
  no column                    the export has no cell holding this text (for example row-level denominators, or the
                               units label "Participants", which is implied by the n_analyzed column name but not stored)
  module not exported          adverse events and more-information blocks are outside this flat export
  excluded by design           point-of-contact and agreement fields (excluded from every representation)
The context key for a value row is every ancestor column the export carries (module, measure or outcome columns,
group ID, title and description, class title and category title), the most specific key the export allows.
"""
from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

from .flat import ANALYSIS_KEYS, FILES, OUTCOME_KEYS, _t
from .manifest import iter_snapshot_studies
from .spec import EXCLUDED_POINTER_PREFIXES

OUT_HEAD_COLS = ["outcome_type", "outcome_title", "outcome_description", "population_description", "reporting_status",
                 "anticipated_posting_date", "time_frame", "param_type", "dispersion_type", "unit_of_measure", "calculate_pct",
                 "type_units_analyzed", "denom_units_selected"]
OKEY = OUT_HEAD_COLS + ["group_id", "group_title", "group_description", "class_title", "category_title"]
BASE_HEAD_KEYS = ["title", "description", "populationDescription", "paramType", "dispersionType", "unitOfMeasure",
                  "calculatePct", "denomUnitsSelected"]
BKEY = ["module_population_description", "module_type_units_analyzed", "measure_title", "measure_description",
        "population_description", "param_type", "dispersion_type", "unit_of_measure", "calculate_pct", "denom_units_selected",
        "group_id", "group_title", "group_description", "class_title", "category_title"]
FKEY = ["recruitment_details", "pre_assignment_details", "type_units_analyzed", "period_title", "milestone_type",
        "milestone_comment", "group_id", "group_title", "group_description"]
MEAS_COLS = {"groupId": "group_id", "value": "value", "spread": "spread", "lowerLimit": "lower_limit",
             "upperLimit": "upper_limit", "comment": "comment"}
ANALYSIS_COL = dict(zip(ANALYSIS_KEYS, ["group_description", "param_type", "param_value", "dispersion_type",
                                        "dispersion_value", "statistical_method", "statistical_comment", "p_value",
                                        "p_value_comment", "ci_num_sides", "ci_pct_value", "ci_lower_limit", "ci_upper_limit",
                                        "ci_lower_limit_comment", "ci_upper_limit_comment", "estimate_comment",
                                        "tested_non_inferiority", "non_inferiority_type", "non_inferiority_comment",
                                        "other_analysis_description"]))


def is_excluded(ptr: str) -> bool:
    return any(ptr == p or ptr.startswith(p + "/") for p in EXCLUDED_POINTER_PREFIXES)


def iter_leaves(node, ptr):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from iter_leaves(v, f"{ptr}/{k.replace('~', '~0').replace('/', '~1')}")
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from iter_leaves(v, f"{ptr}/{i}")
    else:
        yield ptr, node


def pattern(ptr: str) -> str:
    return re.sub(r"/\d+(?=/|$)", "/*", ptr)


def family(pat: str) -> str:
    """Readable leaf family for reporting."""
    p = pat.replace("/resultsSection/", "")
    if p.startswith("outcomeMeasuresModule"):
        if "/classes/*/denoms/" in p:
            return "outcome: row-specific denominators"
        if "/measurements/" in p:
            return "outcome: measurement values"
        if "/analyses/" in p:
            return "outcome: statistical analyses"
        if "/denoms/" in p:
            return "outcome: outcome-level denominators"
        if "/groups/" in p:
            return "outcome: groups"
        if "/classes/" in p:
            return "outcome: class and category titles"
        return "outcome: measure-level fields"
    if p.startswith("baselineCharacteristicsModule"):
        if "/classes/*/denoms/" in p or "/measures/*/denoms/" in p:
            return "baseline: measure and row denominators"
        if "/measurements/" in p:
            return "baseline: measurement values"
        if p.startswith("baselineCharacteristicsModule/denoms"):
            return "baseline: overall denominators"
        if "/groups/" in p:
            return "baseline: groups"
        if "/classes/" in p:
            return "baseline: class and category titles"
        return "baseline: measure and module fields"
    if p.startswith("participantFlowModule"):
        if "/dropWithdraws/" in p:
            return "participant flow: reasons not completed"
        if "/achievements/" in p:
            return "participant flow: milestone counts"
        if "/groups/" in p:
            return "participant flow: groups"
        return "participant flow: periods, milestones and module fields"
    if p.startswith("adverseEventsModule"):
        return "adverse events"
    return "more information"


def _read_flat(flat_dir: Path) -> dict[str, dict[str, list[dict]]]:
    out = {}
    for k, (fname, _) in FILES.items():
        by = defaultdict(list)
        with open(flat_dir / fname, encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                by[row["nct_id"]].append(row)
        out[k] = by
    return out


def _read_ref_tiers(ref_dir: Path) -> dict:
    tiers = {}
    with open(ref_dir / "measurement_tiers.copy", encoding="utf-8") as fh:
        for line in fh:
            f = line.rstrip("\n").split("\t")
            key = (f[1], int(f[2]), int(f[3]), int(f[4]), int(f[5]))
            tiers[key] = {"tier": f[7], "rule": f[8], "pden": None if f[9] == "\\N" else int(f[9])}
    return tiers


def _as_int(txt: str):
    return int(txt) if re.fullmatch(r"[0-9]+", txt or "") else None


def _status(found: bool, hit: bool) -> str:
    return "recoverable" if found else ("ambiguous context" if hit else "absent from rows")


def compare_study(study: dict, flat: dict, ref_tiers: dict, status: dict, denom_cmp: Counter, outcome_cmp: Counter):
    nct = study["protocolSection"]["identificationModule"]["nctId"]
    rs = study.get("resultsSection") or {}

    def mark(ptr, st):
        status[ptr] = st

    # ------------------------------------------------------------------ outcomes
    rows = flat["outcomes"].get(nct, [])
    index = defaultdict(list)
    for i, r in enumerate(rows):
        index[tuple(r[c] for c in OKEY)].append(i)
    arows = flat["analyses"].get(nct, [])
    aindex = defaultdict(list)
    for r in arows:
        aindex[tuple(r["outcome_" + c.removeprefix("outcome_")] for c in OUT_HEAD_COLS)].append(r)
    oms = (rs.get("outcomeMeasuresModule") or {}).get("outcomeMeasures", []) or []
    heads = [tuple(_t(o.get(k)) for k in OUTCOME_KEYS) for o in oms]
    actx = Counter(heads)
    for oi, o in enumerate(oms):
        base = f"/resultsSection/outcomeMeasuresModule/outcomeMeasures/{oi}"
        head = list(heads[oi])
        groups = {g.get("id"): g for g in o.get("groups", []) or []}
        group_rows, group_hit = defaultdict(list), set()
        any_unique, any_hit = False, False
        class_ok, cat_ok, class_hit, cat_hit = set(), set(), set(), set()
        for ci, c in enumerate(o.get("classes", []) or []):
            for ti, k in enumerate(c.get("categories", []) or []):
                for vi, m in enumerate(k.get("measurements", []) or []):
                    mptr = f"{base}/classes/{ci}/categories/{ti}/measurements/{vi}"
                    g = groups.get(m.get("groupId"), {})
                    key = tuple(head + [_t(m.get("groupId")), _t(g.get("title")), _t(g.get("description")),
                                        _t(c.get("title")), _t(k.get("title"))])
                    hits = index.get(key, [])
                    if hits:
                        any_hit = True
                        group_hit.add(m.get("groupId"))
                        class_hit.add(ci)
                        cat_hit.add((ci, ti))
                    if len(hits) == 1:
                        r = rows[hits[0]]
                        any_unique = True
                        class_ok.add(ci)
                        cat_ok.add((ci, ti))
                        group_rows[m.get("groupId")].append(r)
                        for kk, col in MEAS_COLS.items():
                            if kk in m:
                                mark(f"{mptr}/{kk}", "recoverable" if r[col] == _t(m[kk]) else "value differs")
                    else:
                        for kk in MEAS_COLS:
                            if kk in m:
                                mark(f"{mptr}/{kk}", "ambiguous context" if hits else "absent from rows")
                    # denominator attached by the flat export vs the reference resolution
                    ref = ref_tiers.get((nct, oi, ci, ti, vi))
                    if len(hits) != 1:
                        denom_cmp["flat row not identifiable"] += 1
                    elif ref is None:
                        denom_cmp["no reference row"] += 1
                    else:
                        fn = rows[hits[0]]["n_analyzed"]
                        same = _as_int(fn) is not None and ref["pden"] is not None and _as_int(fn) == ref["pden"]
                        if ref["tier"] == "D":
                            denom_cmp["D: outcome not posted"] += 1
                        elif fn == "" and ref["tier"] in ("A", "B"):
                            short = {"A_OUTCOME_LEVEL": "A", "B1_ROW_SPECIFIC_DENOMINATOR": "B1",
                                     "B2_NON_PARTICIPANT_UNITS": "B2"}[ref["rule"]]
                            denom_cmp[f"{short}: flat attaches nothing"] += 1
                        elif ref["tier"] == "A":
                            denom_cmp["A: flat count equals the reference denominator" if same
                                      else "A: flat count differs from the reference denominator"] += 1
                        elif ref["rule"] == "B1_ROW_SPECIFIC_DENOMINATOR":
                            denom_cmp["B1: flat attaches the outcome-level count, row-specific count is the same value"
                                      if same else "B1: flat attaches the outcome-level count, row-specific count differs"] += 1
                        elif ref["rule"] == "B2_NON_PARTICIPANT_UNITS":
                            denom_cmp["B2: flat attaches a participant count to values in another unit"] += 1
                        else:
                            denom_cmp["C: reference not resolvable; flat attaches " + ("a value" if fn else "nothing")] += 1
        for kk, val in zip(OUTCOME_KEYS, head):
            if kk in o:
                mark(f"{base}/{kk}", _status(any_unique, any_hit))
        outcome_cmp["outcomes"] += 1
        if not any_hit:
            outcome_cmp["outcomes with no value rows (absent from the flat export)"] += 1
        elif not any_unique:
            outcome_cmp["outcomes whose rows cannot be told apart"] += 1
        for gi, g in enumerate(o.get("groups", []) or []):
            gr = group_rows.get(g.get("id"))
            for kk, col in (("id", "group_id"), ("title", "group_title"), ("description", "group_description")):
                if kk in g:
                    if gr:
                        mark(f"{base}/groups/{gi}/{kk}", "recoverable" if gr[0][col] == _t(g[kk]) else "value differs")
                    else:
                        mark(f"{base}/groups/{gi}/{kk}", "ambiguous context" if g.get("id") in group_hit else "absent from rows")
        first_p = next((di for di, d in enumerate(o.get("denoms", []) or [])
                        if str(d.get("units", "")).strip().lower() == "participants"), None)
        if first_p is not None:
            d = o["denoms"][first_p]
            for ci_, cnt in enumerate(d.get("counts", []) or []):
                gr = group_rows.get(cnt.get("groupId"))
                if gr:
                    st = "recoverable" if gr[0]["n_analyzed"] == _t(cnt.get("value")) else "value differs"
                else:
                    st = "ambiguous context" if cnt.get("groupId") in group_hit else "absent from rows"
                for kk in ("groupId", "value"):
                    if kk in cnt:
                        mark(f"{base}/denoms/{first_p}/counts/{ci_}/{kk}", st)
            # the units label itself is not stored in any cell: left as "no column"
        for ci, c in enumerate(o.get("classes", []) or []):
            if "title" in c:
                mark(f"{base}/classes/{ci}/title", _status(ci in class_ok, ci in class_hit))
            for ti, k in enumerate(c.get("categories", []) or []):
                if "title" in k:
                    mark(f"{base}/classes/{ci}/categories/{ti}/title", _status((ci, ti) in cat_ok, (ci, ti) in cat_hit))
        flat_as = aindex.get(tuple(head), [])
        for ai, a in enumerate(o.get("analyses", []) or []):
            aptr = f"{base}/analyses/{ai}"
            unique = actx[tuple(head)] == 1 and ai < len(flat_as)
            r = flat_as[ai] if unique else None
            for kk, col in ANALYSIS_COL.items():
                if kk in a:
                    mark(f"{aptr}/{kk}", ("recoverable" if r[col] == _t(a[kk]) else "value differs") if unique
                         else "ambiguous context")
            ids = r["group_ids"].split("|") if unique and r["group_ids"] else []
            for mi, gid in enumerate(a.get("groupIds", []) or []):
                mark(f"{aptr}/groupIds/{mi}", "recoverable" if unique and mi < len(ids) and ids[mi] == gid else "ambiguous context")

    # ------------------------------------------------------------------ baseline
    bl = rs.get("baselineCharacteristicsModule") or {}
    if bl:
        rows = flat["baseline"].get(nct, [])
        index = defaultdict(list)
        for i, r in enumerate(rows):
            index[tuple(r[c] for c in BKEY)].append(i)
        base = "/resultsSection/baselineCharacteristicsModule"
        groups = {g.get("id"): g for g in bl.get("groups", []) or []}
        mod_head = [_t(bl.get("populationDescription")), _t(bl.get("typeUnitsAnalyzed"))]
        group_rows, group_hit = defaultdict(list), set()
        mod_unique, mod_hit = False, False
        for ki, ms in enumerate(bl.get("measures", []) or []):
            mbase = f"{base}/measures/{ki}"
            head = mod_head + [_t(ms.get(k)) for k in BASE_HEAD_KEYS]
            any_unique, any_hit = False, False
            class_ok, cat_ok, class_hit, cat_hit = set(), set(), set(), set()
            for ci, c in enumerate(ms.get("classes", []) or []):
                for ti, k in enumerate(c.get("categories", []) or []):
                    for vi, m in enumerate(k.get("measurements", []) or []):
                        mptr = f"{mbase}/classes/{ci}/categories/{ti}/measurements/{vi}"
                        g = groups.get(m.get("groupId"), {})
                        hits = index.get(tuple(head + [_t(m.get("groupId")), _t(g.get("title")), _t(g.get("description")),
                                                       _t(c.get("title")), _t(k.get("title"))]), [])
                        if hits:
                            any_hit = mod_hit = True
                            group_hit.add(m.get("groupId"))
                            class_hit.add(ci)
                            cat_hit.add((ci, ti))
                        if len(hits) == 1:
                            r = rows[hits[0]]
                            any_unique = mod_unique = True
                            class_ok.add(ci)
                            cat_ok.add((ci, ti))
                            group_rows[m.get("groupId")].append(r)
                            for kk, col in MEAS_COLS.items():
                                if kk in m:
                                    mark(f"{mptr}/{kk}", "recoverable" if r[col] == _t(m[kk]) else "value differs")
                        else:
                            for kk in MEAS_COLS:
                                if kk in m:
                                    mark(f"{mptr}/{kk}", "ambiguous context" if hits else "absent from rows")
            for kk in BASE_HEAD_KEYS:
                if kk in ms:
                    mark(f"{mbase}/{kk}", _status(any_unique, any_hit))
            for ci, c in enumerate(ms.get("classes", []) or []):
                if "title" in c:
                    mark(f"{mbase}/classes/{ci}/title", _status(ci in class_ok, ci in class_hit))
                for ti, k in enumerate(c.get("categories", []) or []):
                    if "title" in k:
                        mark(f"{mbase}/classes/{ci}/categories/{ti}/title", _status((ci, ti) in cat_ok, (ci, ti) in cat_hit))
        for kk in ("populationDescription", "typeUnitsAnalyzed"):
            if kk in bl:
                mark(f"{base}/{kk}", _status(mod_unique, mod_hit))
        for gi, g in enumerate(bl.get("groups", []) or []):
            gr = group_rows.get(g.get("id"))
            for kk, col in (("id", "group_id"), ("title", "group_title"), ("description", "group_description")):
                if kk in g:
                    if gr:
                        mark(f"{base}/groups/{gi}/{kk}", "recoverable" if gr[0][col] == _t(g[kk]) else "value differs")
                    else:
                        mark(f"{base}/groups/{gi}/{kk}", "ambiguous context" if g.get("id") in group_hit else "absent from rows")
        first_p = next((di for di, d in enumerate(bl.get("denoms", []) or [])
                        if str(d.get("units", "")).strip().lower() == "participants"), None)
        if first_p is not None:
            d = bl["denoms"][first_p]
            for ci_, cnt in enumerate(d.get("counts", []) or []):
                gr = group_rows.get(cnt.get("groupId"))
                if gr:
                    st = "recoverable" if gr[0]["n_baseline"] == _t(cnt.get("value")) else "value differs"
                else:
                    st = "ambiguous context" if cnt.get("groupId") in group_hit else "absent from rows"
                for kk in ("groupId", "value"):
                    if kk in cnt:
                        mark(f"{base}/denoms/{first_p}/counts/{ci_}/{kk}", st)

    # ------------------------------------------------------------------ participant flow
    pf = rs.get("participantFlowModule") or {}
    if pf:
        rows = flat["flow"].get(nct, [])
        index = defaultdict(list)
        for i, r in enumerate(rows):
            index[tuple(r[c] for c in FKEY)].append(i)
        base = "/resultsSection/participantFlowModule"
        groups = {g.get("id"): g for g in pf.get("groups", []) or []}
        mod_head = [_t(pf.get("recruitmentDetails")), _t(pf.get("preAssignmentDetails")), _t(pf.get("typeUnitsAnalyzed"))]
        group_rows, group_hit = defaultdict(list), set()
        mod_unique, mod_hit = False, False
        for pi, p in enumerate(pf.get("periods", []) or []):
            p_ok = p_hit = False
            for mi, ms in enumerate(p.get("milestones", []) or []):
                m_ok = m_hit = False
                for ai, a in enumerate(ms.get("achievements", []) or []):
                    aptr = f"{base}/periods/{pi}/milestones/{mi}/achievements/{ai}"
                    g = groups.get(a.get("groupId"), {})
                    hits = index.get(tuple(mod_head + [_t(p.get("title")), _t(ms.get("type")), _t(ms.get("comment")),
                                                       _t(a.get("groupId")), _t(g.get("title")), _t(g.get("description"))]), [])
                    if hits:
                        p_hit = m_hit = mod_hit = True
                        group_hit.add(a.get("groupId"))
                    if len(hits) == 1:
                        r = rows[hits[0]]
                        p_ok = m_ok = mod_unique = True
                        group_rows[a.get("groupId")].append(r)
                        for kk, col in (("groupId", "group_id"), ("numSubjects", "num_subjects"), ("numUnits", "num_units"),
                                        ("comment", "comment")):
                            if kk in a:
                                mark(f"{aptr}/{kk}", "recoverable" if r[col] == _t(a[kk]) else "value differs")
                    else:
                        for kk in ("groupId", "numSubjects", "numUnits", "comment"):
                            if kk in a:
                                mark(f"{aptr}/{kk}", "ambiguous context" if hits else "absent from rows")
                for kk in ("type", "comment"):
                    if kk in ms:
                        mark(f"{base}/periods/{pi}/milestones/{mi}/{kk}", _status(m_ok, m_hit))
            if "title" in p:
                mark(f"{base}/periods/{pi}/title", _status(p_ok, p_hit))
        for kk in ("recruitmentDetails", "preAssignmentDetails", "typeUnitsAnalyzed"):
            if kk in pf:
                mark(f"{base}/{kk}", _status(mod_unique, mod_hit))
        for gi, g in enumerate(pf.get("groups", []) or []):
            gr = group_rows.get(g.get("id"))
            for kk, col in (("id", "group_id"), ("title", "group_title"), ("description", "group_description")):
                if kk in g:
                    if gr:
                        mark(f"{base}/groups/{gi}/{kk}", "recoverable" if gr[0][col] == _t(g[kk]) else "value differs")
                    else:
                        mark(f"{base}/groups/{gi}/{kk}", "ambiguous context" if g.get("id") in group_hit else "absent from rows")


def compare(raw_dir: Path, scope: set[str], flat_dir: Path, ref_dir: Path, out_dir: Path) -> dict:
    flat = _read_flat(flat_dir)
    ref_tiers = _read_ref_tiers(ref_dir)
    by_pattern = Counter()
    by_family = Counter()
    by_study_module = Counter()
    denom_cmp, outcome_cmp = Counter(), Counter()
    n_leaves = 0
    for _, study in iter_snapshot_studies(raw_dir):
        nct = study["protocolSection"]["identificationModule"]["nctId"]
        if nct not in scope:
            continue
        status: dict[str, str] = {}
        compare_study(study, flat, ref_tiers, status, denom_cmp, outcome_cmp)
        for ptr, _v in iter_leaves(study.get("resultsSection") or {}, "/resultsSection"):
            n_leaves += 1
            if is_excluded(ptr):
                st = "excluded by design"
            elif ptr.startswith(("/resultsSection/adverseEventsModule", "/resultsSection/moreInfoModule")):
                st = status.get(ptr, "module not exported")
            else:
                st = status.get(ptr, "no column")
            pat = pattern(ptr)
            by_pattern[(pat, st)] += 1
            by_family[(family(pat), st)] += 1
            by_study_module[(nct, ptr.split("/")[2], st)] += 1
    out_dir.mkdir(parents=True, exist_ok=True)
    with open(out_dir / "flat_leaf_status_by_pattern.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["pattern", "status", "n_scalars"])
        for (p, s), n in sorted(by_pattern.items()):
            w.writerow([p, s, n])
    with open(out_dir / "flat_leaf_status_by_family.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["family", "status", "n_scalars"])
        for (f, s), n in sorted(by_family.items()):
            w.writerow([f, s, n])
    with open(out_dir / "flat_leaf_status_by_study_module.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["nct_id", "module", "status", "n_scalars"])
        for (n_, m, s), n in sorted(by_study_module.items()):
            w.writerow([n_, m, s, n])
    summary = {"n_scalars": n_leaves, "denominator_comparison_unit": "outcome measurement",
               "denominator_comparison": dict(sorted(denom_cmp.items())), "outcomes": dict(outcome_cmp)}
    (out_dir / "flat_compare_summary.json").write_text(json.dumps(summary, indent=2))
    return summary
