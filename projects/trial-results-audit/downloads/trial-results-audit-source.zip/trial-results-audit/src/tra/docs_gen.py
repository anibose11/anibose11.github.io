"""Generated documentation: source-to-warehouse data dictionary and the source manifest."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

from .config import DOCS_DIR, ROOT, current_snapshot_id, snapshot_dirs, write_json
from .spec import EXCLUDED_POINTER_PREFIXES, OBJECTS

KIND_NOTE = {
    "text": "exact source string",
    "textnum": "<base>_text holds the exact source string; <base>_num holds the decimal only when the text is a plain number",
    "textint": "<base>_text holds the exact source string; <base>_int holds the integer only when the text is digits only",
    "bool": "JSON boolean",
    "int": "JSON integer",
}

DERIVED = [
    ("audit.v_measurement_denominator", "tier", "derived", "Tier A/B/C for one outcome measurement (docs/rules.md)", "measurement"),
    ("audit.v_measurement_denominator", "rule_id", "derived", "Rule that decided the tier", "measurement"),
    ("audit.v_measurement_denominator", "participant_denominator", "derived",
     "Participants analyzed associated with the measurement (A or B only); integer participants", "measurement"),
    ("audit.v_measurement_denominator", "denominator_scope", "derived", "outcome (outcome-level count) or class (row-specific count)", "measurement"),
    ("audit.v_measurement_denominator", "unit_denominator", "derived", "Count in the outcome's analysis unit, when exactly one usable count exists", "measurement"),
    ("audit.v_outcome_group_tier", "tier", "derived", "Least favorable measurement tier of the group; D when not posted or no measurements", "outcome group"),
    ("audit.v_outcome_group_tier", "rules", "derived", "All rules used by the group's measurements, joined with |", "outcome group"),
    ("audit.v_check", "status", "derived", "pass, fail or not_evaluable for one applicable check", "applicable check"),
    ("audit.v_evidence_table", "caution", "derived", "Plain-language cautions attached to a measurement row", "measurement"),
    ("audit.v_issue_ledger", "issue_class", "derived",
     "transformation defect, possible source inconsistency, or unresolved interpretation", "ledger row"),
]


def write_data_dictionary(path: Path | None = None) -> Path:
    path = path or DOCS_DIR / "data_dictionary.csv"
    rows = []
    for o in OBJECTS:
        for k in o.keys:
            if k.endswith("_ordinal"):
                rows.append({"table": f"ctr.{o.table}", "column": k, "source_path": o.path, "json_key": "(list position)",
                             "kind": "integer", "registry_label": "", "storage_note": "zero-based position in the source list",
                             "row_unit": o.unit})
        for f in o.fields:
            for c in f.columns():
                rows.append({"table": f"ctr.{o.table}", "column": c, "source_path": o.path, "json_key": f.key,
                             "kind": f.kind, "registry_label": f.label, "storage_note": KIND_NOTE[f.kind], "row_unit": o.unit})
        rows.append({"table": f"ctr.{o.table}", "column": "source_pointer", "source_path": o.path, "json_key": "",
                     "kind": "text", "registry_label": "", "storage_note": "RFC 6901 JSON pointer of this object in the study record",
                     "row_unit": o.unit})
    for p in EXCLUDED_POINTER_PREFIXES:
        rows.append({"table": "(not loaded)", "column": "", "source_path": p, "json_key": "", "kind": "",
                     "registry_label": "", "storage_note": "deliberately excluded (contact details or out of scope)", "row_unit": ""})
    for t, c, kind, note, unit in DERIVED:
        rows.append({"table": t, "column": c, "source_path": "", "json_key": "", "kind": kind, "registry_label": "",
                     "storage_note": note, "row_unit": unit})
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return path


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_source_manifest(terms: dict | None = None) -> Path:
    snap = current_snapshot_id()
    raw_dir, frozen_dir = snapshot_dirs(snap)
    state = json.loads((raw_dir / "retrieval_state.json").read_text())
    files = []
    for v in state["batches"].values():
        p = raw_dir / v["file"]
        files.append({"path": f"data/raw/{snap}/{v['file']}", "role": "full study records (API page)", "url": v["url"],
                      "bytes": p.stat().st_size, "sha256": v["sha256"], "content_type": "application/json",
                      "retrieved_at": v["retrieved_at"], "n_records": len(v["ids"])})
    for g, q in state["queries"].items():
        for pg_ in q["pages"]:
            files.append({"path": f"data/raw/{snap}/{pg_['file']}", "role": f"identifier manifest page ({g})", "url": pg_["url"],
                          "bytes": pg_["bytes"], "sha256": pg_["sha256"], "content_type": "application/json"})
    for name in ("version_before.json", "version_after.json"):
        p = raw_dir / name
        files.append({"path": f"data/raw/{snap}/{name}", "role": "API version and data timestamp", "bytes": p.stat().st_size,
                      "sha256": _sha(p), "content_type": "application/json"})
    meta_dir = ROOT / "data" / "api_meta"
    for p in sorted(meta_dir.glob("*.json")):
        files.append({"path": f"data/api_meta/{p.name}", "role": "API field catalogue / enumerations / search areas",
                      "bytes": p.stat().st_size, "sha256": _sha(p), "content_type": "application/json",
                      "url": f"https://clinicaltrials.gov/api/v2/studies/{p.stem}" if p.stem != "version" else
                      "https://clinicaltrials.gov/api/v2/version"})
    manifest = {
        "snapshot_id": snap,
        "source": "ClinicalTrials.gov (U.S. National Library of Medicine), Data API v2",
        "api_version": state["version_before"]["apiVersion"],
        "data_timestamp_before_retrieval": state["version_before"]["dataTimestamp"],
        "data_timestamp_after_retrieval": state["version_after"]["dataTimestamp"],
        "retrieval_started_at": state["retrieval_started_at"], "retrieval_finished_at": state["retrieval_finished_at"],
        "reference_period": "results first posted 2020-01-01 to 2026-09-30 (registry posting date, not study completion)",
        "queries": {g: {k: q[k] for k in ("query_cond", "filter_advanced", "total_count")} for g, q in state["queries"].items()},
        "n_studies_retrieved": state["union_n"],
        "mutable_source_note": ("Registry records change over time. The raw pages saved here, with their SHA-256 hashes, are the "
                                "snapshot. Re-running the queries later returns the registry as it is then, not this snapshot."),
        "terms_of_use": terms or {},
        "files": files,
    }
    path = ROOT / "source_manifest.json"
    write_json(path, manifest)
    return path
