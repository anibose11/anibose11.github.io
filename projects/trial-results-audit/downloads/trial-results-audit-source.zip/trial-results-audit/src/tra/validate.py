"""Validate stage: software tests, freeze integrity, idempotent reload, independent rebuild, rerun determinism,
REDCap file checks. Writes evidence/validation_report.json.

Three kinds of evidence are kept apart: software tests (synthetic fixtures), source reconciliation (warehouse
against the raw record and an independent R reference), and reproducibility (reload, rebuild, rerun).
None of them is external scientific validation.
"""
from __future__ import annotations

import datetime as dt
import json
import subprocess
import sys
import time

from . import pg
from .config import EVIDENCE_DIR, ROOT, TABLES_DIR, current_snapshot_id, write_json
from .etl import apply_schema, load_snapshot, table_fingerprint

REBUILD_DB = "trial_results_rebuild"


def validate(quick: bool = False) -> int:
    report = {"started_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    ok = True

    t0 = time.monotonic()
    res = subprocess.run([sys.executable, "-m", "pytest", "-q", "--junitxml", str(ROOT / "logs" / "pytest.xml")],
                         cwd=ROOT, capture_output=True, text=True)
    tail = res.stdout.strip().splitlines()[-1] if res.stdout.strip() else res.stderr[-300:]
    report["software_tests"] = {"kind": "software test on synthetic fixtures", "exit_code": res.returncode, "summary": tail,
                                "seconds": round(time.monotonic() - t0, 2)}
    ok &= res.returncode == 0
    print("tests:", tail)
    if quick:
        write_json(EVIDENCE_DIR / "validation_report_quick.json", report)
        return 0 if ok else 1

    from .freeze import assert_heldout_allowed
    rec = assert_heldout_allowed()
    report["freeze_integrity"] = {"combined_sha256": rec["combined_sha256"], "frozen_at": rec["frozen_at"],
                                  "files_unchanged_since_freeze": True}

    snap = current_snapshot_id()
    params = pg.ensure_cluster()
    with pg.connect(params) as conn:
        before = table_fingerprint(conn, snap)
        t0 = time.monotonic()
        rep = load_snapshot(conn, {"development", "heldout"}, snap)
        conn.commit()
        after = table_fingerprint(conn, snap)
    same = before == after
    report["idempotent_reload"] = {"kind": "reproducibility", "unit": "warehouse table",
                                   "tables_compared": len(before), "identical": same,
                                   "studies_reloaded": rep["n_studies_in_scope"], "seconds": round(time.monotonic() - t0, 2)}
    ok &= same
    print("idempotent reload identical:", same)

    rb = pg.ensure_cluster(database=REBUILD_DB)
    with pg.connect(rb) as conn:
        for schema in ("audit", "flat", "ref", "ctr"):
            conn.execute(f"drop schema if exists {schema} cascade")
        conn.commit()
        apply_schema(conn)
        load_snapshot(conn, {"development", "heldout"}, snap)
        conn.commit()
        rebuilt = table_fingerprint(conn, snap)
    diff = sorted(t for t in after if after[t] != rebuilt.get(t))
    report["independent_rebuild"] = {"kind": "reproducibility", "unit": "warehouse table",
                                     "description": "fresh schema in a second database from the cached raw pages",
                                     "tables_compared": len(after), "tables_differing": diff, "identical": not diff}
    ok &= not diff
    print("independent rebuild identical:", not diff)
    with pg.connect({**rb, "dbname": "postgres"}, autocommit=True) as conn:
        conn.execute(f"drop database if exists {REBUILD_DB} with (force)")

    if (EVIDENCE_DIR / "heldout_run.json").exists():
        from .analyze import analyze
        out = analyze(split="heldout", rerun_check=True)
        cmp = json.loads((out / "rerun_comparison.json").read_text())
        report["heldout_rerun"] = {"kind": "reproducibility", "tolerance": cmp["tolerance"], "files": cmp["n_files"],
                                   "all_identical": cmp["all_identical"], "rerun_dir": str(out.relative_to(ROOT))}
        ok &= cmp["all_identical"]

    from .redcap import local_checks
    rc = local_checks(ROOT / "redcap" / "trial_results_ledger_review_dictionary.csv",
                      ROOT / "redcap" / "ledger_review_example_import.csv")
    report["redcap_local_checks"] = rc
    write_json(ROOT / "redcap" / "redcap_local_checks.json", rc)
    ok &= rc["passed"]

    fid = TABLES_DIR / "heldout" / "warehouse_fidelity.csv"
    if fid.exists():
        import csv
        report["heldout_source_reconciliation"] = list(csv.DictReader(open(fid, encoding="utf-8")))
    report["finished_at"] = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    report["all_passed"] = ok
    write_json(EVIDENCE_DIR / "validation_report.json", report)
    print("validation", "passed" if ok else "FAILED")
    return 0 if ok else 1
