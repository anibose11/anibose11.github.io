"""Warehouse loader: raw API pages -> typed PostgreSQL tables, one transaction per load.

Loading is idempotent: rows for the studies in scope are deleted (cascading) and re-inserted inside the same
transaction, so loading the same frozen snapshot twice yields identical table contents, and a failure leaves the
previous state untouched.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import re
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .config import ROOT, SQL_DIR, current_snapshot_id, snapshot_dirs
from .manifest import iter_snapshot_studies
from .spec import OBJ_BY_NAME, OBJECTS, table_columns

LOADER_VERSION = "1.0.0"

# ASCII digits only and a full-string match: Python's \d accepts any Unicode digit and $ accepts a trailing newline.
NUM_RE = re.compile(r"[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?")
INT_RE = re.compile(r"[0-9]+")
INT_MAX = 2 ** 31 - 1


class StudyLoadError(Exception):
    pass


def parse_num(v):
    if isinstance(v, str) and NUM_RE.fullmatch(v):
        try:
            return Decimal(v)
        except InvalidOperation:
            return None
    return None


def parse_int(v):
    if isinstance(v, str) and INT_RE.fullmatch(v):
        i = int(v)
        return i if i <= INT_MAX else None
    return None


def as_int(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v if -INT_MAX <= v <= INT_MAX else None
    return parse_int(v)


def field_values(f, src: dict, anomalies: Counter, objname: str):
    v = src.get(f.key)
    if v is not None and f.kind in ("text", "textnum", "textint") and not isinstance(v, str):
        anomalies[f"{objname}.{f.key}: non-string value"] += 1
        v = json.dumps(v)
    if f.kind == "text":
        return [v]
    if f.kind == "textnum":
        return [v, parse_num(v)]
    if f.kind == "textint":
        return [v, parse_int(v)]
    if f.kind == "bool":
        if v is not None and not isinstance(v, bool):
            anomalies[f"{objname}.{f.key}: non-boolean value"] += 1
            return [None]
        return [v]
    if f.kind == "int":
        if v is not None and as_int(v) is None:
            anomalies[f"{objname}.{f.key}: non-integer value"] += 1
        return [as_int(v)]
    raise ValueError(f.kind)


class Extractor:
    def __init__(self, snapshot_id: str):
        self.snapshot_id = snapshot_id
        self.anomalies: Counter = Counter()
        self.unknown_keys: Counter = Counter()
        self.cols = {o.name: table_columns(o) for o in OBJECTS}

    def _check_keys(self, objname: str, src: dict, allowed: set):
        for k in src:
            if k not in allowed:
                self.unknown_keys[f"{objname}.{k}"] += 1

    def emit(self, rows, objname: str, nct: str, keyvals: dict, src: dict, pointer: str):
        obj = OBJ_BY_NAME[objname]
        if not isinstance(src, dict):
            raise StudyLoadError(f"{pointer} is not an object")
        allowed = {f.key for f in obj.fields} | set(obj.children) | set(obj.excluded)
        self._check_keys(objname, src, allowed)
        vals = {"snapshot_id": self.snapshot_id, "nct_id": nct, "source_pointer": pointer}
        vals.update(keyvals)
        for f in obj.fields:
            for c, v in zip(f.columns(), field_values(f, src, self.anomalies, objname)):
                vals[c] = v
        rows[obj.table].append(tuple(vals.get(c) for c in self.cols[objname]))
        return vals

    def _groups(self, rows, objname, nct, groups, base_ptr, extra_keys=None):
        ids = []
        for gi, g in enumerate(groups or []):
            gid = g.get("id") if isinstance(g, dict) else None
            if not gid:
                raise StudyLoadError(f"{base_ptr}/groups/{gi} has no id")
            ids.append(gid)
            self.emit(rows, objname, nct, {**(extra_keys or {}), "group_id": gid, "group_ordinal": gi}, g, f"{base_ptr}/{gi}")
        if len(set(ids)) != len(ids):
            raise StudyLoadError(f"{base_ptr}: duplicate group ids {ids}")
        return set(ids)

    def _require_group(self, gid, valid: set, ptr: str):
        if gid not in valid:
            raise StudyLoadError(f"{ptr}: group id {gid!r} is not declared in its module/outcome")

    def _denoms(self, rows, prefix: str, nct, denoms, base_ptr, keyvals, valid_groups):
        for di, d in enumerate(denoms or []):
            dptr = f"{base_ptr}/denoms/{di}"
            self.emit(rows, f"{prefix}_denom", nct, {**keyvals, "denom_ordinal": di}, d, dptr)
            for ci, c in enumerate(d.get("counts", []) or []):
                cptr = f"{dptr}/counts/{ci}"
                self._require_group(c.get("groupId"), valid_groups, cptr)
                self.emit(rows, f"{prefix}_denom_count", nct, {**keyvals, "denom_ordinal": di, "count_ordinal": ci}, c, cptr)

    def results_rows(self, nct: str, rs: dict) -> dict:
        rows = defaultdict(list)
        self._check_keys("resultsSection", rs, {"participantFlowModule", "baselineCharacteristicsModule",
                                                 "outcomeMeasuresModule", "adverseEventsModule", "moreInfoModule"})
        pf = rs.get("participantFlowModule")
        if pf is not None:
            base = "/resultsSection/participantFlowModule"
            self.emit(rows, "flow_module", nct, {}, pf, base)
            fg = self._groups(rows, "flow_group", nct, pf.get("groups"), f"{base}/groups")
            for pi, p in enumerate(pf.get("periods", []) or []):
                pptr = f"{base}/periods/{pi}"
                self.emit(rows, "flow_period", nct, {"period_ordinal": pi}, p, pptr)
                for mi, m in enumerate(p.get("milestones", []) or []):
                    mptr = f"{pptr}/milestones/{mi}"
                    self.emit(rows, "flow_milestone", nct, {"period_ordinal": pi, "milestone_ordinal": mi}, m, mptr)
                    for ai, a in enumerate(m.get("achievements", []) or []):
                        aptr = f"{mptr}/achievements/{ai}"
                        self._require_group(a.get("groupId"), fg, aptr)
                        self.emit(rows, "flow_achievement", nct,
                                  {"period_ordinal": pi, "milestone_ordinal": mi, "achievement_ordinal": ai}, a, aptr)
                for di, d in enumerate(p.get("dropWithdraws", []) or []):
                    dptr = f"{pptr}/dropWithdraws/{di}"
                    self.emit(rows, "flow_drop_withdraw", nct, {"period_ordinal": pi, "drop_ordinal": di}, d, dptr)
                    for ri, r in enumerate(d.get("reasons", []) or []):
                        rptr = f"{dptr}/reasons/{ri}"
                        self._require_group(r.get("groupId"), fg, rptr)
                        self.emit(rows, "flow_drop_reason", nct,
                                  {"period_ordinal": pi, "drop_ordinal": di, "reason_ordinal": ri}, r, rptr)

        bl = rs.get("baselineCharacteristicsModule")
        if bl is not None:
            base = "/resultsSection/baselineCharacteristicsModule"
            self.emit(rows, "baseline_module", nct, {}, bl, base)
            bg = self._groups(rows, "baseline_group", nct, bl.get("groups"), f"{base}/groups")
            self._denoms(rows, "baseline", nct, bl.get("denoms"), base, {}, bg)
            for ki, m in enumerate(bl.get("measures", []) or []):
                mptr = f"{base}/measures/{ki}"
                self.emit(rows, "baseline_measure", nct, {"measure_ordinal": ki}, m, mptr)
                self._denoms(rows, "baseline_measure", nct, m.get("denoms"), mptr, {"measure_ordinal": ki}, bg)
                for ci, c in enumerate(m.get("classes", []) or []):
                    cptr = f"{mptr}/classes/{ci}"
                    kv = {"measure_ordinal": ki, "class_ordinal": ci}
                    self.emit(rows, "baseline_class", nct, kv, c, cptr)
                    self._denoms(rows, "baseline_class", nct, c.get("denoms"), cptr, kv, bg)
                    for ti, t in enumerate(c.get("categories", []) or []):
                        tptr = f"{cptr}/categories/{ti}"
                        self.emit(rows, "baseline_category", nct, {**kv, "category_ordinal": ti}, t, tptr)
                        for vi, v in enumerate(t.get("measurements", []) or []):
                            vptr = f"{tptr}/measurements/{vi}"
                            self._require_group(v.get("groupId"), bg, vptr)
                            self.emit(rows, "baseline_measurement", nct,
                                      {**kv, "category_ordinal": ti, "measurement_ordinal": vi}, v, vptr)

        om = rs.get("outcomeMeasuresModule")
        if om is not None:
            self._check_keys("outcomeMeasuresModule", om, {"outcomeMeasures"})
            for oi, o in enumerate(om.get("outcomeMeasures", []) or []):
                optr = f"/resultsSection/outcomeMeasuresModule/outcomeMeasures/{oi}"
                kv = {"outcome_ordinal": oi}
                self.emit(rows, "outcome_measure", nct, kv, o, optr)
                og = self._groups(rows, "outcome_group", nct, o.get("groups"), f"{optr}/groups", kv)
                self._denoms(rows, "outcome", nct, o.get("denoms"), optr, kv, og)
                for ci, c in enumerate(o.get("classes", []) or []):
                    cptr = f"{optr}/classes/{ci}"
                    ckv = {**kv, "class_ordinal": ci}
                    self.emit(rows, "outcome_class", nct, ckv, c, cptr)
                    self._denoms(rows, "outcome_class", nct, c.get("denoms"), cptr, ckv, og)
                    for ti, t in enumerate(c.get("categories", []) or []):
                        tptr = f"{cptr}/categories/{ti}"
                        self.emit(rows, "outcome_category", nct, {**ckv, "category_ordinal": ti}, t, tptr)
                        for vi, v in enumerate(t.get("measurements", []) or []):
                            vptr = f"{tptr}/measurements/{vi}"
                            self._require_group(v.get("groupId"), og, vptr)
                            self.emit(rows, "outcome_measurement", nct,
                                      {**ckv, "category_ordinal": ti, "measurement_ordinal": vi}, v, vptr)
                for ai, a in enumerate(o.get("analyses", []) or []):
                    aptr = f"{optr}/analyses/{ai}"
                    akv = {**kv, "analysis_ordinal": ai}
                    self.emit(rows, "outcome_analysis", nct, akv, a, aptr)
                    for mi, gid in enumerate(a.get("groupIds", []) or []):
                        gptr = f"{aptr}/groupIds/{mi}"
                        self._require_group(gid, og, gptr)
                        rows["outcome_analysis_group"].append(
                            (self.snapshot_id, nct, oi, ai, mi, gid, gptr))

        ae = rs.get("adverseEventsModule")
        if ae is not None:
            base = "/resultsSection/adverseEventsModule"
            self.emit(rows, "ae_module", nct, {}, ae, base)
            eg = self._groups(rows, "ae_group", nct, ae.get("eventGroups"), f"{base}/eventGroups")
            for key, seriousness in (("seriousEvents", "serious"), ("otherEvents", "other")):
                for ei, e in enumerate(ae.get(key, []) or []):
                    eptr = f"{base}/{key}/{ei}"
                    ekv = {"seriousness": seriousness, "event_ordinal": ei}
                    self.emit(rows, "ae_event", nct, ekv, e, eptr)
                    for si, s in enumerate(e.get("stats", []) or []):
                        sptr = f"{eptr}/stats/{si}"
                        self._require_group(s.get("groupId"), eg, sptr)
                        self.emit(rows, "ae_event_stat", nct, {**ekv, "stat_ordinal": si}, s, sptr)

        mi = rs.get("moreInfoModule")
        if mi is not None:
            self._check_keys("moreInfoModule", mi, {"limitationsAndCaveats", "certainAgreement", "pointOfContact"})
            lc = mi.get("limitationsAndCaveats") or {}
            self.emit(rows, "more_info", nct, {}, lc, "/resultsSection/moreInfoModule/limitationsAndCaveats")
        return rows


def strip_excluded(study: dict) -> dict:
    """Copy of the record without the deliberately excluded subtrees (point of contact, certain agreement)."""
    rec = json.loads(json.dumps(study))
    mi = (rec.get("resultsSection") or {}).get("moreInfoModule")
    if isinstance(mi, dict):
        mi.pop("pointOfContact", None)
        mi.pop("certainAgreement", None)
    return rec


def _date_or_none(s):
    if isinstance(s, str) and re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return dt.date.fromisoformat(s)
    return None


def study_row(snapshot_id: str, study: dict, m: dict) -> tuple:
    p = study["protocolSection"]
    ident = p["identificationModule"]
    status = p.get("statusModule", {})
    design = p.get("designModule", {})
    info = design.get("designInfo", {}) or {}
    org = ident.get("organization", {}) or {}
    return (
        snapshot_id, ident["nctId"], m["split"], m["cohort_status"],
        [g for g in m["query_groups"].split("|") if g], [g for g in m["confirmed_groups"].split("|") if g],
        m["cluster_id"], ident.get("briefTitle"), ident.get("officialTitle"), ident.get("acronym"),
        org.get("fullName"), org.get("class"), (ident.get("orgStudyIdInfo") or {}).get("id"),
        design.get("studyType"), design.get("phases"), info.get("allocation"), info.get("interventionModel"),
        info.get("primaryPurpose"), (info.get("maskingInfo") or {}).get("masking"),
        (design.get("enrollmentInfo") or {}).get("count"), (design.get("enrollmentInfo") or {}).get("type"),
        status.get("overallStatus"), (status.get("startDateStruct") or {}).get("date"),
        (status.get("primaryCompletionDateStruct") or {}).get("date"),
        (status.get("completionDateStruct") or {}).get("date"), (status.get("completionDateStruct") or {}).get("type"),
        _date_or_none(status.get("resultsFirstSubmitDate")),
        _date_or_none((status.get("resultsFirstPostDateStruct") or {}).get("date")),
        _date_or_none((status.get("lastUpdatePostDateStruct") or {}).get("date")),
        bool(study.get("hasResults")),
    )


STUDY_COLS = ["snapshot_id", "nct_id", "split", "cohort_status", "query_groups", "confirmed_groups", "cluster_id",
              "brief_title", "official_title", "acronym", "organization", "organization_class", "org_study_id",
              "study_type", "phases", "allocation", "intervention_model", "primary_purpose", "masking",
              "enrollment_count", "enrollment_type", "overall_status", "start_date", "primary_completion_date",
              "completion_date", "completion_date_type", "results_first_submit_date", "results_first_post_date",
              "last_update_post_date", "has_results"]

CTR_TABLES_IN_ORDER = (["raw_study", "study", "study_condition", "study_condition_mesh", "result_module", "load_exception"]
                       + [o.table for o in OBJECTS])


def apply_schema(conn):
    for f in sorted(SQL_DIR.glob("0*.sql")):
        conn.execute(f.read_text())
    conn.commit()


def load_manifest(frozen_dir: Path) -> dict:
    with open(frozen_dir / "manifest.csv", encoding="utf-8") as fh:
        return {r["nct_id"]: r for r in csv.DictReader(fh)}


def snapshot_row(snapshot_id: str, raw_dir: Path) -> tuple:
    state = json.loads((raw_dir / "retrieval_state.json").read_text())
    lines = sorted(f"{v['file']}:{v['sha256']}" for v in state["batches"].values())
    pages_sha = hashlib.sha256("\n".join(lines).encode()).hexdigest()
    spec = {g: {k: q[k] for k in ("query_cond", "filter_advanced", "total_count")} for g, q in state["queries"].items()}
    return (snapshot_id, state["retrieval_started_at"], state["retrieval_finished_at"],
            state["version_before"]["apiVersion"], state["version_before"]["dataTimestamp"],
            state["version_after"]["dataTimestamp"], json.dumps(spec, sort_keys=True), state["union_n"], pages_sha,
            LOADER_VERSION)


def load_snapshot(conn, splits: set[str], snapshot_id: str | None = None, raw_dir: Path | None = None,
                  frozen_dir: Path | None = None) -> dict:
    """Load studies whose split is in `splits` (all cohort statuses). Returns a load report."""
    snapshot_id = snapshot_id or current_snapshot_id()
    if raw_dir is None or frozen_dir is None:
        raw_dir, frozen_dir = snapshot_dirs(snapshot_id)
    manifest = load_manifest(frozen_dir)
    scope = sorted(n for n, m in manifest.items() if m["split"] in splits)
    scope_set = set(scope)
    started = dt.datetime.now(dt.timezone.utc)

    ex = Extractor(snapshot_id)
    tables = defaultdict(list)
    exceptions = []
    raw_rows, study_rows, cond_rows, mesh_rows, mod_rows = [], [], [], [], []
    for batch_file, study in iter_snapshot_studies(raw_dir):
        nct = study["protocolSection"]["identificationModule"]["nctId"]
        if nct not in scope_set:
            continue
        m = manifest[nct]
        # record_sha256 is the hash of the original record; the stored copy omits the excluded contact block.
        raw_rows.append((snapshot_id, nct, batch_file, m["record_sha256"], json.dumps(strip_excluded(study), ensure_ascii=False)))
        study_rows.append(study_row(snapshot_id, study, m))
        for i, c in enumerate(study["protocolSection"].get("conditionsModule", {}).get("conditions", []) or []):
            cond_rows.append((snapshot_id, nct, i, c))
        cbm = (study.get("derivedSection", {}) or {}).get("conditionBrowseModule", {}) or {}
        for kind, key in (("mesh", "meshes"), ("ancestor", "ancestors")):
            for i, x in enumerate(cbm.get(key, []) or []):
                mesh_rows.append((snapshot_id, nct, kind, i, x.get("id"), x.get("term")))
        rs = study.get("resultsSection") or {}
        for module, key in (("participant_flow", "participantFlowModule"), ("baseline", "baselineCharacteristicsModule"),
                            ("outcome_measures", "outcomeMeasuresModule"), ("adverse_events", "adverseEventsModule"),
                            ("more_info", "moreInfoModule")):
            mod_rows.append((snapshot_id, nct, module, key in rs, f"/resultsSection/{key}"))
        try:
            rows = ex.results_rows(nct, rs)
        except StudyLoadError as exc:
            exceptions.append((snapshot_id, nct, "results", str(exc)))
            continue
        for t, rr in rows.items():
            tables[t].extend(rr)

    with conn.transaction():
        fp_before = table_fingerprint(conn, snapshot_id)
        conn.execute("insert into ctr.snapshot (snapshot_id, retrieval_started_at, retrieval_finished_at, api_version, "
                     "data_timestamp_before, data_timestamp_after, query_spec, n_studies, raw_pages_sha256, loader_version) "
                     "values (%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s) on conflict (snapshot_id) do update set "
                     "retrieval_started_at=excluded.retrieval_started_at, retrieval_finished_at=excluded.retrieval_finished_at, "
                     "api_version=excluded.api_version, data_timestamp_before=excluded.data_timestamp_before, "
                     "data_timestamp_after=excluded.data_timestamp_after, query_spec=excluded.query_spec, "
                     "n_studies=excluded.n_studies, raw_pages_sha256=excluded.raw_pages_sha256, "
                     "loader_version=excluded.loader_version", snapshot_row(snapshot_id, raw_dir))
        existing = conn.execute("select count(*) from ctr.raw_study where snapshot_id=%s and nct_id = any(%s)",
                                (snapshot_id, scope)).fetchone()[0]
        conn.execute("delete from ctr.load_exception where snapshot_id=%s and nct_id = any(%s)", (snapshot_id, scope))
        conn.execute("delete from ctr.raw_study where snapshot_id=%s and nct_id = any(%s)", (snapshot_id, scope))
        with conn.cursor() as cur:
            with cur.copy("copy ctr.raw_study (snapshot_id, nct_id, batch_file, record_sha256, record) from stdin") as cp:
                for r in raw_rows:
                    cp.write_row(r)
            cur.executemany(f"insert into ctr.study ({', '.join(STUDY_COLS)}) values ({', '.join(['%s'] * len(STUDY_COLS))})",
                            study_rows)
            for table, cols, rows in (("study_condition", "snapshot_id, nct_id, condition_ordinal, condition", cond_rows),
                                      ("study_condition_mesh", "snapshot_id, nct_id, kind, mesh_ordinal, mesh_id, term", mesh_rows),
                                      ("result_module", "snapshot_id, nct_id, module, present, source_pointer", mod_rows),
                                      ("load_exception", "snapshot_id, nct_id, stage, detail", exceptions)):
                with cur.copy(f"copy ctr.{table} ({cols}) from stdin") as cp:
                    for r in rows:
                        cp.write_row(r)
            for o in OBJECTS:
                rows = tables.get(o.table, [])
                if not rows:
                    continue
                cols = table_columns(o)
                with cur.copy(f"copy ctr.{o.table} ({', '.join(cols)}) from stdin") as cp:
                    for r in rows:
                        cp.write_row(r)
        # fresh planner statistics; without them the audit views fall back to nested loops on the pointer joins
        for t in CTR_TABLES_IN_ORDER:
            conn.execute(f"analyze ctr.{t}")
        if conn.execute("select to_regclass('audit.mv_measurement_denominator')").fetchone()[0]:
            conn.execute("refresh materialized view audit.mv_measurement_denominator")
            conn.execute("analyze audit.mv_measurement_denominator")
        finished = dt.datetime.now(dt.timezone.utc)
        fp = table_fingerprint(conn, snapshot_id)
        conn.execute("insert into ctr.load_run (snapshot_id, scope, started_at, finished_at, action, n_studies, table_fingerprint) "
                     "values (%s,%s,%s,%s,%s,%s,%s::jsonb)",
                     (snapshot_id, ",".join(sorted(splits)), started, finished,
                      "loaded" if not existing else ("reloaded_identical" if fp == fp_before else "reloaded_changed"),
                      len(scope), json.dumps(fp)))
    return {
        "snapshot_id": snapshot_id, "splits": sorted(splits), "n_studies_in_scope": len(scope),
        "n_studies_replaced": existing, "identical_to_previous_state": fp == fp_before,
        "n_result_load_exceptions": len(exceptions),
        "exceptions": [{"nct_id": e[1], "detail": e[3]} for e in exceptions],
        "rows_by_table": {t: len(r) for t, r in sorted(tables.items())},
        "unknown_source_keys": dict(ex.unknown_keys), "value_anomalies": dict(ex.anomalies),
        "seconds": round((finished - started).total_seconds(), 2), "loader_version": LOADER_VERSION,
        "table_fingerprint": fp,
    }


def table_fingerprint(conn, snapshot_id: str) -> dict:
    """Row count and MD5 of the ordered row texts for every warehouse table (load timestamps excluded)."""
    out = {}
    snap = conn.execute(
        "select md5(string_agg(t::text, E'\\n' order by t::text)) from (select snapshot_id, retrieval_started_at, "
        "retrieval_finished_at, api_version, data_timestamp_before, data_timestamp_after, query_spec, n_studies, "
        "raw_pages_sha256, loader_version from ctr.snapshot where snapshot_id=%s) t", (snapshot_id,)).fetchone()[0]
    out["snapshot"] = {"rows": 1, "md5": snap}
    for t in CTR_TABLES_IN_ORDER:
        n, h = conn.execute(f"select count(*), md5(coalesce(string_agg(t::text, E'\\n' order by t::text), '')) "
                            f"from ctr.{t} t where snapshot_id=%s", (snapshot_id,)).fetchone()
        out[t] = {"rows": n, "md5": h}
    return out
