"""Handoff files: project summary JSON, validation notes and verified results."""
from __future__ import annotations

import json
from pathlib import Path

from .config import EVIDENCE_DIR, ROOT, SLUG, write_json
from .facts import Facts

HANDOFF = ROOT / "handoff"

EXECUTED = [
    "python -m tra acquire", "python -m tra freeze",
    "python -m tra build --split development --fresh", "python -m tra analyze --split development",
    "python -m pytest -q", "python -m tra freeze-parser",
    "python -m tra build --split all --fresh", "python -m tra analyze --split heldout",
    "python -m tra validate", "python -m tra posthoc", "python -m tra render", "python -m tra package",
    "clean extraction of the source archive: setup, pytest, python -m tra demo (evidence/clean_extract_check.json)",
    "local HTTP serving of site/ with link, anchor and download checks (evidence/site_check.json)",
    "journal submission files, built separately from the rendered report (nothing uploaded or submitted)",
]


def _deposit_doi():
    import yaml
    p = ROOT / "config" / "deposit.yaml"
    return (yaml.safe_load(p.read_text()) or {}).get("doi") if p.exists() else None


def _attempts() -> str:
    p = EVIDENCE_DIR / "heldout_attempts.jsonl"
    if not p.exists():
        return "none"
    kinds = [json.loads(line).get("kind") for line in p.read_text().splitlines() if line.strip()]
    runs, reruns = kinds.count("run"), kinds.count("rerun")
    return f"{runs} primary run and {reruns} reproducibility rerun{'s' if reruns != 1 else ''}, each compared with the run"


def _load(name):
    p = EVIDENCE_DIR / name
    return json.loads(p.read_text()) if p.exists() else None


def write_handoff(public_files: list[dict]) -> None:
    f = Facts()
    HANDOFF.mkdir(exist_ok=True)
    val = _load("validation_report.json") or {}
    clean = _load("clean_extract_check.json")
    site = _load("site_check.json")
    review = ROOT / "review" / "author_review.json"
    author_review_done = review.exists()

    def finding(key, text):
        x = f[key]
        return {"finding": text, "value": x.value, "numerator": x.numerator, "denominator": x.denominator,
                "percent": f.p(key, 2) if x.denominator else None, "unit": x.unit, "evidence_path": x.path,
                "selector": x.selector, "column": x.column}

    data = {
        "slug": SLUG,
        "title": "Trial results denominator audit",
        "featured": True,
        "summary": (f"A native PostgreSQL warehouse for ClinicalTrials.gov results and an audit of which participant count "
                    f"belongs with each posted value, in {f.n('split_heldout')} held-out cardiometabolic trials, compared with "
                    f"a declared one-row-per-value flat export and checked against a separately written R program."),
        "status": {
            "computational_completion": "complete: held-out audit executed once with the frozen parser; validation passed"
                                        if val.get("all_passed") else "incomplete: see validation report",
            "manuscript_completeness": ("complete (BMC Medical Research Methodology, Research article format); "
                                        + ("the author's review and validation checks are incorporated and the journal files "
                                           "are prepared; not submitted" if author_review_done
                                           else "awaiting the author's single comprehensive review; not submitted")),
            "unresolved_prerequisites": ([] if author_review_done else ["author's comprehensive review and validation"]) + (
                [] if _deposit_doi() else [
                    "DOI for the source archive: the author deposits it (Zenodo) and the DOI is then added to the "
                    "availability statement; the manuscript files are prepared; add the identifier before submission as described in the submission guide"]) + [
                "submission through the journal's own system, by the author",
            ],
        },
        "data_versions": {"source": "ClinicalTrials.gov Data API", "api_version": f["api_version"].value,
                          "data_timestamp_utc": f["data_timestamp"].value, "retrieved_at_utc": f["retrieved_at"].value,
                          "snapshot_id": f.snapshot, "parser_freeze_sha256": f.freeze.get("combined_sha256"),
                          "heldout_run_id": f.heldout_run.get("run_id")},
        "key_limitations": [
            "The R reference follows the same written rules as the warehouse, so a shared misreading of the rules would not be detected.",
            "Rules decide which count applies from record structure; they do not establish clinical correctness, and no external gold standard exists.",
            "Three condition groups and one snapshot of a mutable registry; the API offers no programmatic access to earlier record versions.",
            "Percentages are finite-corpus descriptions of the held-out portion, not estimates for all registered trials.",
            "The REDCap instrument is a template; no ledger item was adjudicated.",
            "The flat export is one declared design; a flat file with row-level and unit count columns would not misattach these counts.",
            "The recall of the registry's condition search was not assessed; measurement-level shares are concentrated in a minority of studies.",
        ],
        "paths": {"project_page": f"site/projects/{SLUG}/index.html", "report": f"site/projects/{SLUG}/report.html",
                  "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip",
                  "claims_map": f"site/projects/{SLUG}/downloads/claims.json"},
        "executed_commands": EXECUTED,
        "measured_findings": [
            finding("og_A", "Held-out outcome groups with a directly structured participant denominator (tier A)"),
            finding("og_B", "Held-out outcome groups needing an explicit rule (tier B)"),
            finding("og_C", "Held-out outcome groups not safely resolvable (tier C)"),
            finding("flat_b1_diff", "Measurements where the flat export attaches the outcome-level count but the row reports a different number analyzed"),
            finding("flat_not_applicable_count", "Measurements where the flat export's count is not the most specific participant count or not in the value's unit"),
            finding("flat_outcomes_lost", "Outcomes with no row in the flat export"),
            finding("ret_attempted_flat", "Source values in attempted modules returned exactly by the flat export"),
            finding("fid_scalars", "In-scope source values held by the warehouse with identical text at the same JSON pointer"),
            finding("fid_tier_m", "Measurements where SQL and the independent R reference agree on tier and denominators"),
            finding("fid_roundtrip", "Results modules rebuilt from the warehouse identical to the source"),
            finding("cm_diff", "Same-title outcome and baseline groups with different participant counts"),
            finding("checks_fail", f"Evaluable checks that failed (possible source inconsistencies; {f.n('checks_applicable')} applicable, "
                                  f"{f.n('checks_not_evaluable')} not evaluable)"),
        ],
        "validation": {"report": "evidence/validation_report.json", "all_passed": val.get("all_passed"),
                       "clean_extract": clean, "site_check": site},
        "public_files": public_files,
    }
    write_json(HANDOFF / f"{SLUG}.json", data)

    lines = [f"# Validation: {SLUG}", "",
             "Editorial revision, October 12, 2026: the computational checks below describe the original research run. Prose and packages were revised without rerunning acquisition, the database or the held-out analysis. Prior archive checks apply to their recorded hashes; they are not new checks of this archive.", "",
             "Three kinds of evidence are kept apart: software tests on synthetic fixtures, source reconciliation against the raw "
             "registry records and an independent R reader, and reproducibility checks. None of them is external scientific validation.", "",
             "## Software tests", f"- {val.get('software_tests', {}).get('summary', 'not run')} (synthetic fixtures only).", "",
             "## Source reconciliation (held-out portion)"]
    for k, label in (("fid_scalars", "source scalars with identical text at the same JSON pointer"),
                     ("fid_tier_m", "measurements where SQL and R agree on tier, rule and denominators"),
                     ("fid_tier_g", "outcome groups where SQL and R agree on tier and rules"),
                     ("fid_roundtrip", "results modules rebuilt identically from the warehouse"),
                     ("fid_evidence_rows", "evidence-view rows per measurement")):
        lines.append(f"- {f.np(k)} {label}.")
    lines += [f"- Transformation defects found: {f.n('transformation_defects')}.", "",
              "## Reproducibility",
              f"- Idempotent reload of all studies: identical = {val.get('idempotent_reload', {}).get('identical')} "
              f"({val.get('idempotent_reload', {}).get('tables_compared')} tables).",
              f"- Independent rebuild into a second database: identical = {val.get('independent_rebuild', {}).get('identical')}.",
              f"- Held-out rerun compared cell by cell (tolerance {val.get('heldout_rerun', {}).get('tolerance')}): "
              f"all identical = {val.get('heldout_rerun', {}).get('all_identical')} over {val.get('heldout_rerun', {}).get('files')} files.",
              f"- Held-out attempts logged in evidence/heldout_attempts.jsonl: {_attempts()}.", "",
              "## REDCap files",
              f"- Local format checks passed = {val.get('redcap_local_checks', {}).get('passed')}. No REDCap server import was performed.", ""]
    if clean:
        lines += ["## Clean extraction of the source archive", f"- {clean.get('summary')}", ""]
    if site:
        lines += ["## Site checks", f"- {site.get('summary')}"] + [f"- {x}" for x in site.get("notes", [])] + [""]
    lines += ["## Not checked", "- No Tableau workbook was built; a specification is provided instead.",
              "- No REDCap server import.", "- No external gold standard for denominators exists; agreement with the R reference is "
              "transformation fidelity, not clinical validation."]
    (HANDOFF / f"{SLUG}-validation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    vr = [f"# Verified results: {SLUG}", "",
          "Methods and measured results only, each with its evidence path. Held-out portion of a frozen ClinicalTrials.gov snapshot "
          f"({f['data_timestamp'].value} UTC data timestamp).", "",
          "## Methods (verified as implemented)",
          "- Retrieved 2,615 interventional diabetes, heart failure and obesity studies with results first posted 2020-01 to 2026-09 "
          "from the ClinicalTrials.gov API v2, saving raw pages with SHA-256 hashes (source_manifest.json).",
          "- Built a native PostgreSQL 17 warehouse with module-scoped keys, exact source text, parsed numerics and a JSON pointer "
          "per row; idempotent, transactional loads (sql/01_schema.sql, src/tra/etl.py).",
          "- Wrote denominator tier rules and twelve applicability-restricted checks; froze code by hash and ran the held-out audit "
          "once (docs/rules.md, evidence/parser_freeze.json, evidence/heldout_run.json).",
          "- Wrote an independent R reference reader and compared the warehouse value by value; built a declared flat-export "
          "comparator (R/reference_enumerator.R, src/tra/flat.py).", "",
          "## Measured results (held-out portion)"]
    for item in data["measured_findings"]:
        pct = f" ({item['percent']})" if item["percent"] else ""
        den = f" of {item['denominator']:,}" if item["denominator"] else ""
        vr.append(f"- {item['finding']}: {item['value']:,}{den}{pct}; unit {item['unit']}; {item['evidence_path']} [{item['selector']}].")
    (HANDOFF / "verified_results.md").write_text("\n".join(vr) + "\n", encoding="utf-8")
    print(f"Handoff written to {HANDOFF}")
