"""Package stage: allowlisted source archive, handoff files and the project bundle ZIP.

The source archive holds code, SQL, R, configuration, tests and fixtures, documentation, small result tables and
exports. It excludes environments, the database cluster, raw registry pages, caches, logs, local notes, run
directories, review worksheets and earlier bundles. Entries get a fixed timestamp so the archive is reproducible
from the same files.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import zipfile
from pathlib import Path

from .config import EVIDENCE_DIR, ROOT, SLUG, current_snapshot_id

OUTER = ROOT / "deliverables" / "02-trial-results-audit-PROJECT-BUNDLE.zip"
SITE_ROOT = ROOT / "site"
SITE = SITE_ROOT / "projects" / SLUG
FIXED_TIME = (2026, 10, 7, 0, 0, 0)
MAX_OUTER_BYTES = 28 * 1024 * 1024

ALLOW = [
    "README.md", "LICENSE", "CITATION.cff", "THIRD_PARTY_NOTICES.md", "Makefile", "pyproject.toml", "requirements.in",
    "requirements.lock", ".gitignore", "source_manifest.json",
    "config/*.yaml", "src/tra/*.py", "sql/*.sql", "R/*.R", "scripts/psql.sh",
    "tests/*.py", "tests/fixtures/*.py", "tests/fixtures/*.json",
    "docs/analysis_plan.md", "docs/contribution_decision.md", "docs/literature_search.md", "docs/rules.md",
    "docs/tableau_spec.md", "docs/*.csv", "docs/*.json",
    "evidence/*.json", "evidence/*.jsonl",
    "results/tables/heldout/*", "results/tables/heldout_posthoc/*", "results/tables/development/*", "results/tables/runtime/*.csv",
    "results/exports/*.csv.gz", "results/trial_results_audit_tables.xlsx",
    "redcap/*.csv", "redcap/*.json",
    "report/manuscript.md.j2", "site_src/*",
    "data/api_meta/*.json",
]
# Records of checks run on the finished archive and pages; kept in evidence/ and the handoff but not inside the archive,
# so the archive that was checked is the archive that ships, byte for byte.
CHECK_RECORDS = {"clean_extract_check.json", "site_check.json", "site_check_links.json"}
# Built from parts so the scanner does not match its own source text.
PRIVATE_PATTERNS = [re.compile("/" + "Users/[A-Za-z0-9_.-]+"), re.compile("/" + "private/" + "tmp/"),
                    re.compile("/" + "home/[A-Za-z0-9_.-]+/")]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _source_files() -> list[tuple[Path, str]]:
    snap = current_snapshot_id()
    files = []
    for pat in ALLOW:
        for p in sorted(ROOT.glob(pat)):
            if p.is_file() and "__pycache__" not in p.parts and p.name not in CHECK_RECORDS:
                files.append((p, str(p.relative_to(ROOT))))
    for name in ("manifest.csv", "split_summary.json", "near_duplicate_titles.csv"):
        p = ROOT / "data" / "frozen" / snap / name
        files.append((p, f"data/frozen/{snap}/{name}"))
    for name in ("retrieval_state.json", "version_before.json", "version_after.json"):
        p = ROOT / "data" / "raw" / snap / name
        files.append((p, f"data/snapshot_provenance/{snap}/{name}"))
    return files


def scan_private(files: list[tuple[Path, str]]) -> list[str]:
    hits = []
    for p, arc in files:
        if p.suffix in (".gz", ".xlsx", ".zip"):
            continue
        try:
            text = p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for rx in PRIVATE_PATTERNS:
            m = rx.search(text)
            if m:
                hits.append(f"{arc}: {m.group(0)}")
    return hits


def _zip(out: Path, entries: list[tuple[Path, str]]):
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p, arc in sorted(entries, key=lambda e: e[1]):
            info = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if arc.endswith(".sh") else 0o644) << 16
            z.writestr(info, p.read_bytes())
    tmp.replace(out)
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        if bad:
            raise SystemExit(f"ZIP integrity check failed at {bad}")


def build_source_zip() -> Path:
    files = _source_files()
    hits = scan_private(files)
    if hits:
        raise SystemExit("Machine-specific paths found in files bound for the source archive:\n  " + "\n  ".join(hits))
    out = SITE / "downloads" / f"{SLUG}-source.zip"
    _zip(out, files)
    print(f"Source archive: {len(files)} files, {out.stat().st_size:,} bytes")
    return out


def public_files() -> list[dict]:
    rows = []
    for p in sorted(SITE.rglob("*")):
        if p.is_file():
            rows.append({"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": sha256(p)})
    return rows


def build_outer_zip() -> Path:
    entries = [(p, str(p.relative_to(ROOT))) for p in sorted(SITE.rglob("*")) if p.is_file()]
    entries += [(p, str(p.relative_to(ROOT))) for p in sorted((ROOT / "handoff").glob("*")) if p.is_file()
                and p.name in (f"{SLUG}.json", f"{SLUG}-validation.md", "verified_results.md")]
    _zip(OUTER, entries)
    size = OUTER.stat().st_size
    digest = sha256(OUTER)
    (OUTER.parent / (OUTER.name + ".sha256")).write_text(f"{digest}  {OUTER.name}\n")
    print(f"Outer bundle: {OUTER} ({size:,} bytes, sha256 {digest})")
    if size > MAX_OUTER_BYTES:
        print(f"WARNING: bundle exceeds the 28 MiB target ({size / 2**20:.1f} MiB)")
    return OUTER


def package() -> None:
    from .handoff import write_handoff
    build_source_zip()
    write_handoff(public_files())
    build_outer_zip()
