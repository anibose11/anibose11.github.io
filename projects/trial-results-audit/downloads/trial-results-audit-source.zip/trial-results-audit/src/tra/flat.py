"""Flat baseline: an ordinary analyst export of the results section, as declared in docs/analysis_plan.md
(item 2 of "Representations compared", widened by amendment 3).

This follows the shape produced by pandas.json_normalize along each module's deepest list: one CSV row per leaf
record, with every scalar attribute of its ancestors (module, measure, class, category, group) copied down, and the
first outcome-level (or baseline overall) "Participants" count for the group attached as n_analyzed (n_baseline).
All values stay source text; nothing is coerced to numbers. Lists that are not on a record path (denominators other
than that participant count, row-level denominators, reasons not completed, outcomes or measures with no value rows)
are not represented, which is what this kind of export ordinarily does. Adverse events and the more-information
block are not exported. It is written independently of the warehouse loader and does not import it.
"""
from __future__ import annotations

import csv
import json
import time
from pathlib import Path

from .config import snapshot_dirs
from .manifest import iter_snapshot_studies

OUTCOME_COLS = ["nct_id", "outcome_type", "outcome_title", "outcome_description", "population_description", "reporting_status",
                "anticipated_posting_date", "time_frame", "param_type", "dispersion_type", "unit_of_measure", "calculate_pct",
                "type_units_analyzed", "denom_units_selected", "group_id", "group_title", "group_description",
                "class_title", "category_title", "value", "spread", "lower_limit", "upper_limit", "comment", "n_analyzed"]
OUTCOME_KEYS = ["type", "title", "description", "populationDescription", "reportingStatus", "anticipatedPostingDate",
                "timeFrame", "paramType", "dispersionType", "unitOfMeasure", "calculatePct", "typeUnitsAnalyzed",
                "denomUnitsSelected"]
ANALYSIS_KEYS = ["groupDescription", "paramType", "paramValue", "dispersionType", "dispersionValue", "statisticalMethod",
                 "statisticalComment", "pValue", "pValueComment", "ciNumSides", "ciPctValue", "ciLowerLimit", "ciUpperLimit",
                 "ciLowerLimitComment", "ciUpperLimitComment", "estimateComment", "testedNonInferiority",
                 "nonInferiorityType", "nonInferiorityComment", "otherAnalysisDescription"]
ANALYSIS_COLS = (["nct_id"] + ["outcome_" + c for c in ("type", "title", "description", "population_description", "reporting_status",
                                                        "anticipated_posting_date", "time_frame", "param_type", "dispersion_type",
                                                        "unit_of_measure", "calculate_pct", "type_units_analyzed",
                                                        "denom_units_selected")]
                 + ["group_ids", "group_description", "param_type", "param_value", "dispersion_type", "dispersion_value",
                    "statistical_method", "statistical_comment", "p_value", "p_value_comment", "ci_num_sides", "ci_pct_value",
                    "ci_lower_limit", "ci_upper_limit", "ci_lower_limit_comment", "ci_upper_limit_comment", "estimate_comment",
                    "tested_non_inferiority", "non_inferiority_type", "non_inferiority_comment", "other_analysis_description"])
BASELINE_COLS = ["nct_id", "module_population_description", "module_type_units_analyzed", "measure_title", "measure_description",
                 "population_description", "param_type", "dispersion_type", "unit_of_measure", "calculate_pct",
                 "denom_units_selected", "group_id", "group_title", "group_description", "class_title", "category_title",
                 "value", "spread", "lower_limit", "upper_limit", "comment", "n_baseline"]
FLOW_COLS = ["nct_id", "recruitment_details", "pre_assignment_details", "type_units_analyzed", "period_title", "milestone_type",
             "milestone_comment", "group_id", "group_title", "group_description", "num_subjects", "num_units", "comment"]


def _t(v):
    """Text form used in the CSV: absent -> empty, booleans as true/false, everything else as given."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def _first_participant_counts(denoms) -> dict:
    """Ordinary convention: the first denominator whose units read 'Participants' gives N analyzed per group."""
    for d in denoms or []:
        if str(d.get("units", "")).strip().lower() == "participants":
            return {c.get("groupId"): c.get("value") for c in d.get("counts", []) or []}
    return {}


def flatten_study(study: dict) -> dict[str, list[list[str]]]:
    nct = study["protocolSection"]["identificationModule"]["nctId"]
    rs = study.get("resultsSection") or {}
    out = {"outcomes": [], "analyses": [], "baseline": [], "flow": []}

    for o in (rs.get("outcomeMeasuresModule") or {}).get("outcomeMeasures", []) or []:
        head = [o.get(k) for k in OUTCOME_KEYS]
        groups = {g.get("id"): g for g in o.get("groups", []) or []}
        n_by_group = _first_participant_counts(o.get("denoms"))
        for c in o.get("classes", []) or []:
            for k in c.get("categories", []) or []:
                for m in k.get("measurements", []) or []:
                    g = groups.get(m.get("groupId"), {})
                    out["outcomes"].append([nct] + head + [m.get("groupId"), g.get("title"), g.get("description"),
                                                           c.get("title"), k.get("title"), m.get("value"), m.get("spread"),
                                                           m.get("lowerLimit"), m.get("upperLimit"), m.get("comment"),
                                                           n_by_group.get(m.get("groupId"))])
        for a in o.get("analyses", []) or []:
            out["analyses"].append([nct] + head + ["|".join(a.get("groupIds", []) or [])] + [a.get(k) for k in ANALYSIS_KEYS])

    bl = rs.get("baselineCharacteristicsModule") or {}
    if bl:
        groups = {g.get("id"): g for g in bl.get("groups", []) or []}
        n_by_group = _first_participant_counts(bl.get("denoms"))
        for ms in bl.get("measures", []) or []:
            for c in ms.get("classes", []) or []:
                for k in c.get("categories", []) or []:
                    for m in k.get("measurements", []) or []:
                        g = groups.get(m.get("groupId"), {})
                        out["baseline"].append([nct, bl.get("populationDescription"), bl.get("typeUnitsAnalyzed"), ms.get("title"),
                                                ms.get("description"), ms.get("populationDescription"), ms.get("paramType"),
                                                ms.get("dispersionType"), ms.get("unitOfMeasure"), ms.get("calculatePct"),
                                                ms.get("denomUnitsSelected"), m.get("groupId"), g.get("title"),
                                                g.get("description"), c.get("title"), k.get("title"), m.get("value"),
                                                m.get("spread"), m.get("lowerLimit"), m.get("upperLimit"), m.get("comment"),
                                                n_by_group.get(m.get("groupId"))])

    pf = rs.get("participantFlowModule") or {}
    if pf:
        groups = {g.get("id"): g for g in pf.get("groups", []) or []}
        for p in pf.get("periods", []) or []:
            for ms in p.get("milestones", []) or []:
                for a in ms.get("achievements", []) or []:
                    g = groups.get(a.get("groupId"), {})
                    out["flow"].append([nct, pf.get("recruitmentDetails"), pf.get("preAssignmentDetails"),
                                        pf.get("typeUnitsAnalyzed"), p.get("title"), ms.get("type"), ms.get("comment"),
                                        a.get("groupId"), g.get("title"), g.get("description"), a.get("numSubjects"),
                                        a.get("numUnits"), a.get("comment")])
    return {k: [[_t(v) for v in row] for row in rows] for k, rows in out.items()}


FILES = {"outcomes": ("flat_outcome_rows.csv", OUTCOME_COLS), "analyses": ("flat_analysis_rows.csv", ANALYSIS_COLS),
         "baseline": ("flat_baseline_rows.csv", BASELINE_COLS), "flow": ("flat_flow_rows.csv", FLOW_COLS)}


def build_flat(splits: set[str], snapshot_id: str, out_dir: Path) -> dict:
    raw_dir, frozen_dir = snapshot_dirs(snapshot_id)
    with open(frozen_dir / "manifest.csv", encoding="utf-8") as fh:
        scope = {r["nct_id"] for r in csv.DictReader(fh) if r["split"] in splits}
    out_dir.mkdir(parents=True, exist_ok=True)
    t0 = time.monotonic()
    handles = {k: open(out_dir / fname, "w", newline="", encoding="utf-8") for k, (fname, _) in FILES.items()}
    writers = {k: csv.writer(h) for k, h in handles.items()}
    for k, (_, cols) in FILES.items():
        writers[k].writerow(cols)
    counts = {k: 0 for k in FILES}
    n = 0
    try:
        for _, study in iter_snapshot_studies(raw_dir):
            if study["protocolSection"]["identificationModule"]["nctId"] not in scope:
                continue
            n += 1
            for k, rows in flatten_study(study).items():
                writers[k].writerows(rows)
                counts[k] += len(rows)
    finally:
        for h in handles.values():
            h.close()
    secs = round(time.monotonic() - t0, 2)
    sizes = {FILES[k][0]: (out_dir / FILES[k][0]).stat().st_size for k in FILES}
    report = {"n_studies": n, "rows": counts, "bytes": sizes, "seconds": secs}
    (out_dir / "flat_report.json").write_text(json.dumps(report, indent=2))
    return report


def load_flat(conn, flat_dir: Path, snapshot_id: str):
    """Load the flat CSVs as text tables in schema `flat` for querying (row order kept in row_number)."""
    conn.execute("create schema if not exists flat")
    for k, (fname, cols) in FILES.items():
        table = fname.removesuffix(".csv")
        conn.execute(f"drop table if exists flat.{table}")
        conn.execute(f"create table flat.{table} (row_number bigint generated always as identity primary key, "
                     + ", ".join(f"{c} text" for c in cols) + ")")
        with conn.cursor() as cur:
            with cur.copy(f"copy flat.{table} ({', '.join(cols)}) from stdin with (format csv, header true)") as cp:
                with open(flat_dir / fname, "rb") as fh:
                    while chunk := fh.read(1 << 20):
                        cp.write(chunk)
