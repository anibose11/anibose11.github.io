"""REDCap-compatible review instrument for a future adjudication of issue-ledger rows.

Produces a data dictionary, a small example import file whose review fields are deliberately blank, and local format
checks. These are an instrument and locally checked files. No REDCap server import was performed and no human review
has been recorded in them.
"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path

DICT_HEADER = ["Variable / Field Name", "Form Name", "Section Header", "Field Type", "Field Label",
               "Choices, Calculations, OR Slider Labels", "Field Note", "Text Validation Type OR Show Slider Number",
               "Text Validation Min", "Text Validation Max", "Identifier?", "Branching Logic (Show field only if...)",
               "Required Field?", "Custom Alignment", "Question Number (surveys only)", "Matrix Group Name",
               "Matrix Ranking?", "Field Annotation"]
FORM = "ledger_item_review"
FIELDS = [
    # name, type, label, choices, note, validation, required, section, branching, annotation
    ("record_id", "text", "Record ID", "", "Ledger issue_id", "", "y", "Ledger item (filled from the issue ledger)", "", "@READONLY"),
    ("nct_id", "text", "ClinicalTrials.gov identifier", "", "", "", "y", "", "", "@READONLY"),
    ("registry_url", "text", "Registry record link", "", "Open the public record to review the source", "", "", "", "", "@READONLY"),
    ("issue_class", "dropdown", "Issue class assigned by the audit",
     "1, transformation defect | 2, possible source inconsistency | 3, unresolved interpretation", "", "", "y", "", "", "@READONLY"),
    ("rule_id", "text", "Rule or check identifier", "", "See docs/rules.md", "", "y", "", "", "@READONLY"),
    ("json_pointer", "text", "JSON pointer of the flagged object", "", "", "", "y", "", "", "@READONLY"),
    ("evidence_json", "notes", "Source values and denominators recorded by the audit", "", "", "", "", "", "", "@READONLY"),
    ("snapshot_id", "text", "Registry snapshot", "", "", "", "y", "", "", "@READONLY"),
    ("rv_decision", "radio", "Reviewer decision",
     "1, Confirmed as described | 2, Acceptable reporting variation | 3, Audit rule misapplied | 4, Cannot determine from the public record",
     "", "", "y", "Review", "", ""),
    ("rv_source_checked", "yesno", "Did you open the public registry record for this item?", "", "", "", "y", "", "", ""),
    ("rv_corrected_denominator", "text", "Denominator you would use, if any", "", "Leave blank when not applicable",
     "integer", "", "", "[issue_class] = '3'", ""),
    ("rv_notes", "notes", "Notes", "", "", "", "", "", "", ""),
    ("rv_reviewer", "text", "Reviewer initials", "", "", "", "y", "", "", ""),
    ("rv_date", "text", "Review date", "", "", "date_ymd", "y", "", "", ""),
]
CLASS_CODE = {"transformation defect": "1", "possible source inconsistency": "2", "unresolved interpretation": "3"}
VALID_TYPES = {"text", "notes", "dropdown", "radio", "checkbox", "yesno", "truefalse", "calc", "file", "slider", "descriptive", "sql"}
VALID_VALIDATION = {"", "integer", "number", "date_ymd", "date_mdy", "date_dmy", "email", "phone", "time", "zipcode"}


def write_dictionary(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(DICT_HEADER)
        for name, ftype, label, choices, note, val, req, section, branch, ann in FIELDS:
            w.writerow([name, FORM, section, ftype, label, choices, note, val, "", "", "", branch, req, "", "", "", "", ann])


def write_example_import(ledger_csv: Path, path: Path, snapshot_id: str, per_class: int = 3) -> int:
    rows = list(csv.DictReader(open(ledger_csv, encoding="utf-8")))
    picked = []
    for cls in CLASS_CODE:
        picked += [r for r in rows if r["issue_class"] == cls][:per_class]
    cols = [f[0] for f in FIELDS]
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in picked:
            rec = {"record_id": r["issue_id"], "nct_id": r["nct_id"], "registry_url": r["registry_url"],
                   "issue_class": CLASS_CODE[r["issue_class"]], "rule_id": r["rule_id"], "json_pointer": r["pointer"],
                   "evidence_json": r["evidence"], "snapshot_id": snapshot_id}
            w.writerow([rec.get(c, "") for c in cols])  # review fields intentionally blank
    return len(picked)


def local_checks(dict_path: Path, import_path: Path) -> dict:
    issues = []
    with open(dict_path, encoding="utf-8") as fh:
        rd = list(csv.reader(fh))
    header, body = rd[0], rd[1:]
    if header != DICT_HEADER:
        issues.append("dictionary header does not match the 18 standard REDCap columns")
    names = [r[0] for r in body]
    if names[0] != "record_id":
        issues.append("first field is not the record identifier")
    if len(set(names)) != len(names):
        issues.append("duplicate variable names")
    choices = {}
    for r in body:
        name, form, ftype, choice, val = r[0], r[1], r[3], r[5], r[7]
        if not re.fullmatch(r"[a-z][a-z0-9_]*", name) or len(name) > 26:
            issues.append(f"{name}: variable name must be lowercase letters, digits and underscores, start with a letter, <= 26 characters")
        if not re.fullmatch(r"[a-z][a-z0-9_]*", form):
            issues.append(f"{name}: invalid form name")
        if ftype not in VALID_TYPES:
            issues.append(f"{name}: unknown field type {ftype}")
        if val not in VALID_VALIDATION:
            issues.append(f"{name}: unknown validation {val}")
        if ftype in ("radio", "dropdown", "checkbox"):
            parts = [p.strip() for p in choice.split("|")]
            codes = []
            for p in parts:
                m = re.fullmatch(r"([A-Za-z0-9_]+),\s*(.+)", p)
                if not m:
                    issues.append(f"{name}: malformed choice '{p}'")
                else:
                    codes.append(m.group(1))
            choices[name] = set(codes)
        if ftype == "yesno":
            choices[name] = {"0", "1"}
        branch = r[11]
        for ref in re.findall(r"\[([a-z0-9_]+)\]", branch):
            if ref not in names:
                issues.append(f"{name}: branching logic refers to unknown field {ref}")
    with open(import_path, encoding="utf-8") as fh:
        ri = list(csv.reader(fh))
    ih, ib = ri[0], ri[1:]
    if ih[0] != "record_id":
        issues.append("import file does not start with record_id")
    unknown = [c for c in ih if c not in names]
    if unknown:
        issues.append(f"import columns not in dictionary: {unknown}")
    for row in ib:
        rec = dict(zip(ih, row))
        for f, allowed in choices.items():
            if rec.get(f) and rec[f] not in allowed:
                issues.append(f"record {rec['record_id']}: {f}={rec[f]} not an allowed code")
        if any(rec.get(f) for f in ("rv_decision", "rv_reviewer", "rv_date", "rv_source_checked")):
            issues.append(f"record {rec['record_id']}: example file must not contain review answers")
    ids = [r[0] for r in ib]
    if len(set(ids)) != len(ids):
        issues.append("duplicate record_id in import file")
    return {"checked": "local file format checks only; no REDCap server import was performed",
            "dictionary_fields": len(body), "example_records": len(ib), "issues": issues, "passed": not issues}
