"""Project paths and configuration loading."""
from __future__ import annotations

import json
import os
from pathlib import Path

import yaml

ROOT = Path(os.environ.get("TRA_ROOT", Path(__file__).resolve().parents[2]))
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
FROZEN_DIR = DATA_DIR / "frozen"
RESULTS_DIR = ROOT / "results"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR = RESULTS_DIR / "figures"
RUNS_DIR = RESULTS_DIR / "runs"
LOCAL_DIR = ROOT / ".local"
SQL_DIR = ROOT / "sql"
R_DIR = ROOT / "R"
DOCS_DIR = ROOT / "docs"
EVIDENCE_DIR = ROOT / "evidence"
LOG_DIR = ROOT / "logs"

SLUG = "trial-results-audit"


def load_cohort_config() -> dict:
    with open(CONFIG_DIR / "cohort.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def load_db_config() -> dict:
    with open(CONFIG_DIR / "database.yaml", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def current_snapshot_id() -> str:
    """The snapshot used by build/analyze stages, recorded by the acquire stage."""
    pointer = FROZEN_DIR / "CURRENT_SNAPSHOT"
    if not pointer.exists():
        raise SystemExit("No frozen snapshot found. Run: python -m tra acquire")
    return pointer.read_text(encoding="utf-8").strip()


def snapshot_dirs(snapshot_id: str) -> tuple[Path, Path]:
    return RAW_DIR / snapshot_id, FROZEN_DIR / snapshot_id


def write_json(path: Path, obj, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=indent, ensure_ascii=False, sort_keys=False)
        fh.write("\n")
    tmp.replace(path)


def read_json(path: Path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)
