"""Reference list in the BMC (Vancouver) style, numbered by order of first citation.

Every entry was checked against PubMed or Crossref, or read on the official page, on 2026-10-07
(docs/literature_search.md). Templates call cite("key", ...) and list the references with citer.ordered().
"""
from __future__ import annotations

REFS = {
    "zarin2011": "Zarin DA, Tse T, Williams RJ, Califf RM, Ide NC. The ClinicalTrials.gov results database: update and key issues. N Engl J Med. 2011;364:852-60. https://doi.org/10.1056/NEJMsa1012065.",
    "zarin2016": "Zarin DA, Tse T, Williams RJ, Carr S. Trial reporting in ClinicalTrials.gov: the final rule. N Engl J Med. 2016;375:1998-2004. https://doi.org/10.1056/NEJMsr1611785.",
    "tse2009": "Tse T, Williams RJ, Zarin DA. Reporting \"basic results\" in ClinicalTrials.gov. Chest. 2009;136:295-303. https://doi.org/10.1378/chest.08-3022.",
    "riveros2013": "Riveros C, Dechartres A, Perrodeau E, Haneef R, Boutron I, Ravaud P. Timing and completeness of trial results posted at ClinicalTrials.gov and published in journals. PLoS Med. 2013;10:e1001566. https://doi.org/10.1371/journal.pmed.1001566.",
    "hartung2014": "Hartung DM, Zarin DA, Guise JM, McDonagh M, Paynter R, Helfand M. Reporting discrepancies between the ClinicalTrials.gov results database and peer-reviewed publications. Ann Intern Med. 2014;160:477-83. https://doi.org/10.7326/M13-0480.",
    "becker2014": "Becker JE, Krumholz HM, Ben-Josef G, Ross JS. Reporting of results in ClinicalTrials.gov and high-impact journals. JAMA. 2014;311:1063-5. https://doi.org/10.1001/jama.2013.285634.",
    "schwartz2016": "Schwartz LM, Woloshin S, Zheng E, Tse T, Zarin DA. ClinicalTrials.gov and Drugs@FDA: a comparison of results reporting for new drug approval trials. Ann Intern Med. 2016;165:421-30. https://doi.org/10.7326/M15-2658.",
    "talebi2020": "Talebi R, Redberg RF, Ross JS. Consistency of trial reporting between ClinicalTrials.gov and corresponding publications: one decade after FDAAA. Trials. 2020;21:675. https://doi.org/10.1186/s13063-020-04603-9.",
    "dechartres2016": "Dechartres A, Bond EG, Scheer J, Riveros C, Atal I, Ravaud P. Reporting of statistically significant results at ClinicalTrials.gov for completed superiority randomized controlled trials. BMC Med. 2016;14:192. https://doi.org/10.1186/s12916-016-0740-1.",
    "tse2018": "Tse T, Fain KM, Zarin DA. How to avoid common problems when using ClinicalTrials.gov in research: 10 issues to consider. BMJ. 2018;361:k1452. https://doi.org/10.1136/bmj.k1452.",
    "zarin2019": "Zarin DA, Fain KM, Dobbins HD, Tse T, Williams RJ. 10-year update on study results submitted to ClinicalTrials.gov. N Engl J Med. 2019;381:1966-74. https://doi.org/10.1056/NEJMsr1907644.",
    "tasneem2012": "Tasneem A, Aberle L, Ananth H, Chakraborty S, Chiswell K, McCourt BJ, et al. The database for aggregate analysis of ClinicalTrials.gov (AACT) and subsequent regrouping by clinical specialty. PLoS One. 2012;7:e33677. https://doi.org/10.1371/journal.pone.0033677.",
    "aact": "Clinical Trials Transformation Initiative. AACT: Aggregate Analysis of ClinicalTrials.gov. https://aact.ctti-clinicaltrials.org/. Accessed 7 Oct 2026.",
    "aact_code": "Clinical Trials Transformation Initiative. ctti-clinicaltrials/aact: source code, master branch revision 16ec282c (20 Oct 2025), archived by Software Heritage on 6 Jun 2026 as snapshot swh:1:snp:5a34a7efb3947a6d31627a3d1381ae19625df3ce. https://archive.softwareheritage.org/swh:1:snp:5a34a7efb3947a6d31627a3d1381ae19625df3ce. Accessed 7 Oct 2026.",
    "pradhan2019": "Pradhan R, Hoaglin DC, Cornell M, Liu W, Wang V, Yu H. Automatic extraction of quantitative data from ClinicalTrials.gov to conduct meta-analyses. J Clin Epidemiol. 2019;105:92-100. https://doi.org/10.1016/j.jclinepi.2018.08.023.",
    "shi2024": "Shi X, Du J. Constructing a finer-grained representation of clinical trial results from ClinicalTrials.gov. Sci Data. 2024;11:41. https://doi.org/10.1038/s41597-023-02869-7.",
    "herold2026": "Herold R. Aggregating and analysing clinical trials data from multiple public registers using R package ctrdata. Res Synth Methods. 2026;17:624-56. https://doi.org/10.1017/rsm.2025.10061.",
    "miron2020": "Miron L, Gonçalves RS, Musen MA. Obstacles to the reuse of study metadata in ClinicalTrials.gov. Sci Data. 2020;7:443. https://doi.org/10.1038/s41597-020-00780-z.",
    "abraha2010": "Abraha I, Montedori A. Modified intention to treat reporting in randomised controlled trials: systematic review. BMJ. 2010;340:c2697. https://doi.org/10.1136/bmj.c2697.",
    "earley2013": "Earley A, Lau J, Uhlig K. Haphazard reporting of deaths in clinical trials: a review of cases of ClinicalTrials.gov records and matched publications. A cross-sectional study. BMJ Open. 2013;3:e001963. https://doi.org/10.1136/bmjopen-2012-001963.",
    "devito2020": "DeVito NJ, Bacon S, Goldacre B. Compliance with legal requirement to report clinical trial results on ClinicalTrials.gov: a cohort study. Lancet. 2020;395:361-9. https://doi.org/10.1016/S0140-6736(19)33220-9.",
    "baudard2017": "Baudard M, Yavchitz A, Ravaud P, Perrodeau E, Boutron I. Impact of searching clinical trial registries in systematic reviews of pharmaceutical treatments: methodological systematic review and reanalysis of meta-analyses. BMJ. 2017;356:j448. https://doi.org/10.1136/bmj.j448.",
    "ctgov_api": "National Library of Medicine. ClinicalTrials.gov API. Last updated 26 Aug 2025. https://clinicaltrials.gov/data-api/api. Accessed 7 Oct 2026.",
    "results_defs": "National Library of Medicine. ClinicalTrials.gov results data element definitions for interventional and observational studies. Last updated 31 Dec 2024. https://clinicaltrials.gov/policy/results-definitions. Accessed 7 Oct 2026.",
    "techbull2024": "ClinicalTrials.gov API version 2.0 now available. NLM Tech Bull. 2024 Mar-Apr;(457):e2. https://www.nlm.nih.gov/pubs/techbull/ma24/ma24_clinicaltrials_api.html. Accessed 7 Oct 2026.",
    "ctgov_csv": "National Library of Medicine. ClinicalTrials.gov API: CSV download. Last updated 14 Aug 2026. https://clinicaltrials.gov/data-api/about-api/csv-download. Accessed 7 Oct 2026.",
    "yu2024": "Yu T, Yang X, Clark J, Lin L, Furuya-Kanamori L, Xu C. Accelerating evidence synthesis for safety assessment through ClinicalTrials.gov platform: a feasibility study. BMC Med Res Methodol. 2024;24:165. https://doi.org/10.1186/s12874-024-02225-2.",
    "steinberg2023": "Steinberg E, Ignatiadis N, Yadlowsky S, Xu Y, Shah N. Using public clinical trial reports to probe non-experimental causal inference methods. BMC Med Res Methodol. 2023;23:204. https://doi.org/10.1186/s12874-023-02025-0.",
    "terms": "National Library of Medicine. ClinicalTrials.gov terms and conditions. Last updated 31 Jan 2023. https://clinicaltrials.gov/about-site/terms-conditions. Accessed 7 Oct 2026.",
}


class Citer:
    def __init__(self):
        self.order: list[str] = []

    def __call__(self, *keys: str) -> str:
        nums = []
        for k in keys:
            if k not in REFS:
                raise KeyError(f"unknown reference {k}")
            if k not in self.order:
                self.order.append(k)
            nums.append(self.order.index(k) + 1)
        nums = sorted(set(nums))
        parts, start = [], None
        for i, n in enumerate(nums):
            if start is None:
                start = n
            if i + 1 < len(nums) and nums[i + 1] == n + 1:
                continue
            parts.append(f"{start}" if start == n else (f"{start},{n}" if n == start + 1 else f"{start}-{n}"))
            start = None
        return "[" + ",".join(parts) + "]"

    def ordered(self) -> list[tuple[int, str]]:
        return [(i + 1, REFS[k]) for i, k in enumerate(self.order)]

    def unused(self) -> list[str]:
        return [k for k in REFS if k not in self.order]
