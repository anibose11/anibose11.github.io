"""Load the independent R reference output into schema `ref`, and generate the warehouse leaf view.

The warehouse leaf view (sql/03_leaf_view.sql, generated from spec.py) turns every non-null mapped column back
into (JSON pointer, value text) so it can be compared with the reference leaf by leaf.
"""
from __future__ import annotations

from pathlib import Path

from .config import SQL_DIR
from .spec import OBJECTS

REF_DDL = """
create schema if not exists ref;
create table if not exists ref.leaf (
    snapshot_id text not null, nct_id text not null, pointer text not null, json_type text not null, value_text text,
    primary key (snapshot_id, nct_id, pointer)
);
create table if not exists ref.object_count (
    snapshot_id text not null, nct_id text not null, pattern text not null, n integer not null,
    primary key (snapshot_id, nct_id, pattern)
);
create table if not exists ref.measurement_tier (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, class_ordinal integer not null,
    category_ordinal integer not null, measurement_ordinal integer not null, group_id text,
    tier text not null, rule_id text not null, participant_denominator integer, unit_denominator integer,
    primary key (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal)
);
create table if not exists ref.group_tier (
    snapshot_id text not null, nct_id text not null, outcome_ordinal integer not null, group_id text not null,
    tier text not null, rules text not null,
    primary key (snapshot_id, nct_id, outcome_ordinal, group_id)
);
"""


def load_reference(conn, ref_dir: Path, snapshot_id: str):
    conn.execute(REF_DDL)
    nct_ids = sorted({line.split("\t", 2)[1] for line in open(ref_dir / "group_tiers.copy", encoding="utf-8")} |
                     {line.split("\t", 2)[1] for line in open(ref_dir / "objects.copy", encoding="utf-8")})
    with conn.transaction():
        for t in ("leaf", "object_count", "measurement_tier", "group_tier"):
            conn.execute(f"delete from ref.{t} where snapshot_id=%s and nct_id = any(%s)", (snapshot_id, nct_ids))
        with conn.cursor() as cur:
            for table, fname in (("leaf", "leaves.copy"), ("object_count", "objects.copy"),
                                 ("measurement_tier", "measurement_tiers.copy"), ("group_tier", "group_tiers.copy")):
                with cur.copy(f"copy ref.{table} from stdin") as cp:
                    with open(ref_dir / fname, "rb") as fh:
                        while chunk := fh.read(1 << 20):
                            cp.write(chunk)


def leaf_view_sql() -> str:
    """One SELECT per mapped field: pointer = row pointer + '/' + JSON key, value = exact text form."""
    parts = []
    for o in OBJECTS:
        if o.name == "outcome_analysis_group":
            parts.append("select snapshot_id, nct_id, source_pointer as pointer, 'string'::text as json_type, group_id as value_text, "
                         "'outcome_analysis_group'::text as object_name, 'group_id'::text as column_name "
                         "from ctr.outcome_analysis_group")
            continue
        for f in o.fields:
            col = f.text_column()
            if f.kind == "bool":
                val, jt = f"case when {col} then 'true' else 'false' end", "boolean"
            elif f.kind == "int":
                val, jt = f"{col}::text", "number"
            else:
                val, jt = col, "string"
            parts.append(
                f"select snapshot_id, nct_id, source_pointer || '/{f.key}' as pointer, '{jt}'::text as json_type, "
                f"{val} as value_text, '{o.name}'::text as object_name, '{col}'::text as column_name "
                f"from ctr.{o.table} where {col} is not null")
    return ("-- Generated from src/tra/spec.py by tra.reference.leaf_view_sql(); do not edit by hand.\n"
            "create or replace view ctr.v_leaf as\n" + "\nunion all\n".join(parts) + ";\n")


def write_leaf_view_file() -> Path:
    path = SQL_DIR / "03_leaf_view.sql"
    path.write_text(leaf_view_sql(), encoding="utf-8")
    return path
