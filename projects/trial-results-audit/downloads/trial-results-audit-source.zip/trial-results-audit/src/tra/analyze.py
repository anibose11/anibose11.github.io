"""Analyze stage: primary and secondary estimates, reconciliation, flat comparison, checks, sensitivity analyses.

Every output table carries a `unit` column (study, outcome, outcome group, measurement, source scalar, object,
applicable check, study module). Percentages are finite-corpus descriptions of the stated scope.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import shutil
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from . import pg
from .config import EVIDENCE_DIR, RESULTS_DIR, RUNS_DIR, TABLES_DIR, current_snapshot_id, snapshot_dirs, write_json
from .flat_compare import compare as flat_compare_run, family

SPLITS = {"development": ["development"], "heldout": ["heldout"], "all": ["development", "heldout"]}
TIER_LABEL = {"A": "directly structured and applicable", "B": "requires an explicitly reproducible transformation",
              "C": "ambiguous and not safely resolvable", "D": "not applicable"}
BOOTSTRAP_SEED = 20261007
BOOTSTRAP_REPS = 2000

PATTERN_TABLE = {
    "/resultsSection/participantFlowModule/groups/*": ("flow_group", None),
    "/resultsSection/participantFlowModule/periods/*": ("flow_period", None),
    "/resultsSection/participantFlowModule/periods/*/milestones/*": ("flow_milestone", None),
    "/resultsSection/participantFlowModule/periods/*/milestones/*/achievements/*": ("flow_achievement", None),
    "/resultsSection/participantFlowModule/periods/*/dropWithdraws/*": ("flow_drop_withdraw", None),
    "/resultsSection/participantFlowModule/periods/*/dropWithdraws/*/reasons/*": ("flow_drop_reason", None),
    "/resultsSection/baselineCharacteristicsModule/groups/*": ("baseline_group", None),
    "/resultsSection/baselineCharacteristicsModule/denoms/*": ("baseline_denom", None),
    "/resultsSection/baselineCharacteristicsModule/denoms/*/counts/*": ("baseline_denom_count", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*": ("baseline_measure", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/denoms/*": ("baseline_measure_denom", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/denoms/*/counts/*": ("baseline_measure_denom_count", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/classes/*": ("baseline_class", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/classes/*/denoms/*": ("baseline_class_denom", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/classes/*/denoms/*/counts/*": ("baseline_class_denom_count", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/classes/*/categories/*": ("baseline_category", None),
    "/resultsSection/baselineCharacteristicsModule/measures/*/classes/*/categories/*/measurements/*": ("baseline_measurement", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*": ("outcome_measure", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/groups/*": ("outcome_group", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/denoms/*": ("outcome_denom", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/denoms/*/counts/*": ("outcome_denom_count", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/classes/*": ("outcome_class", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/classes/*/denoms/*": ("outcome_class_denom", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/classes/*/denoms/*/counts/*": ("outcome_class_denom_count", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/classes/*/categories/*": ("outcome_category", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/classes/*/categories/*/measurements/*": ("outcome_measurement", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/analyses/*": ("outcome_analysis", None),
    "/resultsSection/outcomeMeasuresModule/outcomeMeasures/*/analyses/*/groupIds/*": ("outcome_analysis_group", None),
    "/resultsSection/adverseEventsModule/eventGroups/*": ("ae_group", None),
    "/resultsSection/adverseEventsModule/seriousEvents/*": ("ae_event", "serious"),
    "/resultsSection/adverseEventsModule/seriousEvents/*/stats/*": ("ae_event_stat", "serious"),
    "/resultsSection/adverseEventsModule/otherEvents/*": ("ae_event", "other"),
    "/resultsSection/adverseEventsModule/otherEvents/*/stats/*": ("ae_event_stat", "other"),
}


def _rows(conn, sql, params=None):
    cur = conn.execute(sql, params or ())
    cols = [d.name for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _write_csv(path: Path, rows: list[dict], cols: list[str] | None = None):
    path.parent.mkdir(parents=True, exist_ok=True)
    cols = cols or (list(rows[0].keys()) if rows else [])
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(r.get(k)) for k in cols})


def _fmt(v):
    if isinstance(v, float):
        return f"{v:.6f}".rstrip("0").rstrip(".") if v == v else ""
    if isinstance(v, (dict, list)):
        return json.dumps(v, ensure_ascii=False, sort_keys=True)
    return "" if v is None else v


def pct(n, d):
    return round(100.0 * n / d, 2) if d else None


def tier_table(rows, unit, scope_label, key_cols=()):
    """rows: dicts with key columns and 'tier'. Returns one row per key with counts and percentages of applicable."""
    agg = defaultdict(Counter)
    for r in rows:
        agg[tuple(r[k] for k in key_cols)][r["tier"]] += 1
    out = []
    for key, c in sorted(agg.items(), key=lambda kv: tuple(str(x) for x in kv[0])):
        appl = c["A"] + c["B"] + c["C"]
        row = {k: v for k, v in zip(key_cols, key)}
        row.update({"unit": unit, "scope": scope_label, "n_applicable": appl, "n_A": c["A"], "n_B": c["B"], "n_C": c["C"],
                    "n_D_not_applicable": c["D"], "pct_A": pct(c["A"], appl), "pct_B": pct(c["B"], appl),
                    "pct_C": pct(c["C"], appl), "pct_resolvable_A_or_B": pct(c["A"] + c["B"], appl)})
        out.append(row)
    return out


def setup_scope(conn, snapshot_id: str, splits: list[str]):
    conn.execute("drop table if exists scope_study, r_md, r_gt, r_os, r_check")
    conn.execute("""create temp table scope_study as
        select snapshot_id, nct_id, split, cohort_status, confirmed_groups, query_groups,
               extract(year from results_first_post_date)::int as rfp_year
        from ctr.study where snapshot_id = %s and split = any(%s)""", (snapshot_id, splits))
    conn.execute("create index on scope_study (snapshot_id, nct_id)")
    conn.execute("analyze scope_study")
    conn.execute("""create temp table r_md as select md.*, s.cohort_status, s.rfp_year, s.confirmed_groups
        from audit.mv_measurement_denominator md join scope_study s using (snapshot_id, nct_id)""")
    conn.execute("""create temp table r_gt as select t.*, s.cohort_status, s.rfp_year, s.confirmed_groups
        from audit.v_outcome_group_tier t join scope_study s using (snapshot_id, nct_id)""")
    conn.execute("""create temp table r_os as select o.*, s.cohort_status, s.rfp_year, s.confirmed_groups
        from audit.v_outcome_summary o join scope_study s using (snapshot_id, nct_id)""")
    conn.execute("""create temp table r_check as select c.*, s.cohort_status
        from audit.v_check c join scope_study s using (snapshot_id, nct_id)""")


def analyze(split: str = "development", rerun_check: bool = False) -> Path:
    from .freeze import assert_heldout_allowed
    freeze = assert_heldout_allowed() if split in ("heldout", "all") else None
    snap = current_snapshot_id()
    splits = SPLITS[split]
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    marker = EVIDENCE_DIR / "heldout_run.json"
    attempts = EVIDENCE_DIR / "heldout_attempts.jsonl"
    if rerun_check and split != "heldout":
        raise SystemExit("--rerun-check applies only to --split heldout")
    if split == "heldout":
        if rerun_check and not marker.exists():
            raise SystemExit("No completed held-out run to compare against (evidence/heldout_run.json is missing).")
        if not rerun_check and marker.exists():
            raise SystemExit("The held-out audit has already been executed once (evidence/heldout_run.json). "
                             "Use --rerun-check for a deterministic reproducibility rerun.")
    if split == "all" and not marker.exists():
        raise SystemExit("--split all touches held-out data; run the held-out audit (--split heldout) first.")
    kind = "rerun" if rerun_check else "run"
    run_id = f"{split}-{kind}-{stamp}"
    if split in ("heldout", "all"):
        # Every attempt that touches held-out data is logged before any table is computed, so a failed or repeated
        # attempt cannot pass unrecorded.
        EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
        with open(attempts, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"run_id": run_id, "split": split, "kind": kind, "started_at": stamp,
                                 "parser_freeze_sha256": freeze["combined_sha256"]}) + "\n")
    out = RUNS_DIR / run_id
    tdir = out / "tables"
    tdir.mkdir(parents=True, exist_ok=True)
    build_dir = RUNS_DIR / ("build-all" if split in ("heldout", "all") else "build-development")
    raw_dir, frozen_dir = snapshot_dirs(snap)
    t_start = time.monotonic()
    timings = {}

    with pg.connect() as conn:
        t0 = time.monotonic()
        setup_scope(conn, snap, splits)
        timings["scope_and_tiers_seconds"] = round(time.monotonic() - t0, 2)
        scope_label = f"{split} portion, confirmed cohort"

        # ------------------------------------------------------------ cohort flow (unit: study)
        manifest = list(csv.DictReader(open(frozen_dir / "manifest.csv", encoding="utf-8")))
        split_summary = json.loads((frozen_dir / "split_summary.json").read_text())
        flow = [{"unit": "study", "step": "identifiers returned by condition query", "group": g, "n": n}
                for g, n in split_summary["per_query_total_count"].items()]
        flow += [{"unit": "study", "step": "unique identifiers retrieved (union of queries)", "group": "all", "n": split_summary["retrieved_union"]},
                 {"unit": "study", "step": "excluded by frame checks", "group": "all", "n": split_summary["excluded_frame"]},
                 {"unit": "study", "step": "ambiguous condition match (excluded from primary cohort)", "group": "all",
                  "n": split_summary["ambiguous_condition_match"]},
                 {"unit": "study", "step": "confirmed cohort", "group": "all", "n": split_summary["confirmed"]}]
        flow += [{"unit": "study", "step": "confirmed cohort by condition group (groups overlap)", "group": g, "n": n}
                 for g, n in split_summary["confirmed_by_group"].items()]
        flow += [{"unit": "study", "step": f"confirmed cohort, {s} portion", "group": "all", "n": n}
                 for s, n in split_summary["split_confirmed"].items()]
        n_exc = conn.execute("""select count(*) from ctr.load_exception e join scope_study s using (snapshot_id, nct_id)
                                 where s.cohort_status = 'confirmed'""").fetchone()[0]
        flow.append({"unit": "study", "step": f"confirmed {split} studies whose results could not be loaded (load exception)",
                     "group": "all", "n": n_exc})
        _write_csv(tdir / "cohort_flow.csv", flow)

        # ------------------------------------------------------------ primary: outcome-group tiers
        gt = _rows(conn, "select nct_id, outcome_ordinal, group_id, tier, rules, structure, row_specific_mode, unit_is_participants, "
                         "param_type, outcome_type, population_description_present, rfp_year, confirmed_groups, cohort_status "
                         "from r_gt")
        gt_conf = [r for r in gt if r["cohort_status"] == "confirmed"]
        primary = tier_table(gt_conf, "outcome group", scope_label)
        for r in primary:
            r["n_studies"] = len({g["nct_id"] for g in gt_conf})
        _write_csv(tdir / "primary_outcome_group_tiers.csv", primary)
        long_primary = []
        appl = sum(1 for r in gt_conf if r["tier"] != "D")
        for t in "ABCD":
            n = sum(1 for r in gt_conf if r["tier"] == t)
            long_primary.append({"unit": "outcome group", "scope": scope_label, "tier": t, "tier_label": TIER_LABEL[t], "n": n,
                                 "denominator": appl if t != "D" else len(gt_conf),
                                 "pct": pct(n, appl) if t != "D" else pct(n, len(gt_conf))})
        _write_csv(tdir / "primary_outcome_group_tiers_long.csv", long_primary)
        rules = Counter(r["rules"] for r in gt_conf)
        _write_csv(tdir / "outcome_group_rules.csv",
                   [{"unit": "outcome group", "scope": scope_label, "rules": k, "n": v} for k, v in rules.most_common()])

        # ------------------------------------------------------------ measurement level
        md = _rows(conn, "select tier, rule_id, cohort_status from r_md")
        md_conf = [r for r in md if r["cohort_status"] == "confirmed"]
        _write_csv(tdir / "measurement_tiers.csv", tier_table(md_conf, "measurement", scope_label))
        mr = Counter(r["rule_id"] for r in md_conf)
        _write_csv(tdir / "measurement_rules.csv",
                   [{"unit": "measurement", "scope": scope_label, "rule_id": k, "tier": k[0], "n": v,
                     "pct_of_measurements": pct(v, len(md_conf))} for k, v in sorted(mr.items())])

        # ------------------------------------------------------------ outcomes (unit: outcome)
        os_rows = _rows(conn, "select reporting_status, structure, population_description_present, outcome_type, cohort_status, "
                              "n_measurements from r_os where cohort_status='confirmed'")
        status = Counter(r["structure"] if r["structure"] in ("not posted", "no measurements") else "posted with measurements"
                         for r in os_rows)
        out_rows = [{"unit": "outcome", "scope": scope_label, "category": k, "n": v, "pct_of_outcomes": pct(v, len(os_rows))}
                    for k, v in sorted(status.items())]
        posted = [r for r in os_rows if r["reporting_status"] == "POSTED"]
        posted_m = [r for r in posted if r["n_measurements"] > 0]
        out_rows += [
            {"unit": "outcome", "scope": scope_label, "category": "posted outcomes with an analysis population description",
             "n": sum(r["population_description_present"] for r in posted), "denominator": len(posted),
             "pct_of_outcomes": pct(sum(r["population_description_present"] for r in posted), len(posted))},
            {"unit": "outcome", "scope": scope_label,
             "category": "posted outcomes with measurements and an analysis population description",
             "n": sum(r["population_description_present"] for r in posted_m), "denominator": len(posted_m),
             "pct_of_outcomes": pct(sum(r["population_description_present"] for r in posted_m), len(posted_m))}]
        _write_csv(tdir / "outcome_status_and_population_description.csv", out_rows,
                   ["unit", "scope", "category", "n", "denominator", "pct_of_outcomes"])
        popdesc_by_type = defaultdict(lambda: [0, 0])
        for r in posted:
            popdesc_by_type[r["outcome_type"]][0] += r["population_description_present"]
            popdesc_by_type[r["outcome_type"]][1] += 1
        _write_csv(tdir / "population_description_by_outcome_type.csv",
                   [{"unit": "outcome", "scope": scope_label, "outcome_type": k, "n_with_description": a, "n_posted": b,
                     "pct": pct(a, b)} for k, (a, b) in sorted(popdesc_by_type.items(), key=lambda kv: str(kv[0]))])

        # ------------------------------------------------------------ S3 breakdowns (unit: outcome group)
        for r in gt_conf:
            r["row_specific_denominators"] = "yes" if r["row_specific_mode"] else "no"
            r["analysis_unit_type"] = "participants" if r["unit_is_participants"] else "other unit"
        _write_csv(tdir / "tiers_by_structure.csv", tier_table(gt_conf, "outcome group", scope_label, ("structure",)))
        _write_csv(tdir / "tiers_by_row_specific_denominators.csv",
                   tier_table(gt_conf, "outcome group", scope_label, ("row_specific_denominators",)))
        _write_csv(tdir / "tiers_by_analysis_unit.csv", tier_table(gt_conf, "outcome group", scope_label, ("analysis_unit_type",)))
        _write_csv(tdir / "tiers_by_param_type.csv", tier_table(gt_conf, "outcome group", scope_label, ("param_type",)))
        _write_csv(tdir / "tiers_by_outcome_type.csv", tier_table(gt_conf, "outcome group", scope_label, ("outcome_type",)))
        by_cond = []
        for r in gt_conf:
            for g in r["confirmed_groups"]:
                by_cond.append({**r, "condition_group": g})
        _write_csv(tdir / "tiers_by_condition_group.csv",
                   tier_table(by_cond, "outcome group", scope_label + "; a study counts in every condition group it belongs to",
                              ("condition_group",)))
        _write_csv(tdir / "tiers_by_results_first_posted_year.csv",
                   tier_table(gt_conf, "outcome group", scope_label + "; 2026 covers January to September", ("rfp_year",)))
        studies_by_year = Counter(r["rfp_year"] for r in _rows(conn, "select rfp_year from scope_study where cohort_status='confirmed'"))
        _write_csv(tdir / "studies_by_results_first_posted_year.csv",
                   [{"unit": "study", "scope": scope_label, "rfp_year": k, "n": v} for k, v in sorted(studies_by_year.items())])

        # ------------------------------------------------------------ S6 checks (unit: applicable check)
        ch = _rows(conn, "select check_id, status, count(*) n, count(distinct nct_id) n_studies from r_check "
                         "where cohort_status='confirmed' group by 1, 2")
        agg = defaultdict(dict)
        for r in ch:
            agg[r["check_id"]][r["status"]] = (r["n"], r["n_studies"])
        fail_studies = {r["check_id"]: r["n"] for r in _rows(conn, "select check_id, count(distinct nct_id) n from r_check "
                                                                 "where cohort_status='confirmed' and status='fail' group by 1")}
        check_rows = []
        for cid in sorted(agg, key=lambda c: int(c[1:])):
            a = agg[cid]
            n_app = sum(v[0] for v in a.values())
            n_eval = a.get("pass", (0, 0))[0] + a.get("fail", (0, 0))[0]
            check_rows.append({"unit": "applicable check", "scope": scope_label, "check_id": cid, "n_applicable": n_app,
                               "n_pass": a.get("pass", (0, 0))[0], "n_fail": a.get("fail", (0, 0))[0],
                               "n_not_evaluable": a.get("not_evaluable", (0, 0))[0],
                               "pct_fail_of_evaluable": pct(a.get("fail", (0, 0))[0], n_eval),
                               "n_studies_with_a_failure": fail_studies.get(cid, 0)})
        _write_csv(tdir / "checks_summary.csv", check_rows)

        # ------------------------------------------------------------ S7 cross-module labels (unit: outcome group)
        cm = _rows(conn, """select x.baseline_title_matches, x.outcome_participants, x.baseline_participants
                            from audit.v_cross_module_label x join scope_study s using (snapshot_id, nct_id)
                            where s.cohort_status='confirmed' and x.tier <> 'D'""")
        c7 = Counter()
        for r in cm:
            c7["posted outcome groups with measurements"] += 1
            if r["baseline_title_matches"] == 0:
                c7["no baseline group with the same title"] += 1
            elif r["baseline_title_matches"] > 1:
                c7["more than one baseline group with the same title"] += 1
            else:
                c7["exactly one baseline group with the same title"] += 1
                if r["outcome_participants"] is not None and r["baseline_participants"] is not None:
                    c7["same title, both counts usable"] += 1
                    c7["same title, same participant count" if r["outcome_participants"] == r["baseline_participants"]
                       else "same title, different participant count"] += 1
        base_n = c7["posted outcome groups with measurements"]
        _write_csv(tdir / "cross_module_label_identity.csv",
                   [{"unit": "outcome group", "scope": scope_label, "category": k, "n": c7[k],
                     "pct_of_outcome_groups": pct(c7[k], base_n)} for k in (
                       "posted outcome groups with measurements", "exactly one baseline group with the same title",
                       "no baseline group with the same title", "more than one baseline group with the same title",
                       "same title, both counts usable", "same title, same participant count",
                       "same title, different participant count")])
        coll = _rows(conn, """select count(*) filter (where n_titles > 1) as studies_with_varying_og000, count(*) as studies
            from (select g.nct_id, count(distinct audit.norm_title(g.title)) n_titles from ctr.outcome_group g
                  join scope_study s using (snapshot_id, nct_id) where s.cohort_status='confirmed' and g.group_id='OG000'
                  group by 1 having count(*) > 1) x""")[0]
        _write_csv(tdir / "group_id_scope.csv", [{"unit": "study", "scope": scope_label + "; studies with OG000 in two or more outcomes",
                                                  "category": "OG000 title differs between outcomes of the same study",
                                                  "n": coll["studies_with_varying_og000"], "denominator": coll["studies"],
                                                  "pct": pct(coll["studies_with_varying_og000"], coll["studies"])}])

        # ------------------------------------------------------------ S5 fidelity: leaf reconciliation (unit: source scalar)
        t0 = time.monotonic()
        recon = _rows(conn, """
            select regexp_replace(coalesce(r.pointer, w.pointer), '/[0-9]+(?=/|$)', '/*', 'g') as pattern,
                   case when w.pointer is null and r.json_type = 'excluded' then 'excluded by design'
                        when w.pointer is null then 'missing in warehouse'
                        when r.pointer is null then 'extra in warehouse'
                        when w.value_text is distinct from r.value_text then 'value differs'
                        else 'exact match' end as status, count(*) as n
            from (select l.* from ref.leaf l join scope_study s using (snapshot_id, nct_id) where s.cohort_status='confirmed') r
            full outer join (select l.* from ctr.v_leaf l join scope_study s using (snapshot_id, nct_id) where s.cohort_status='confirmed') w
              on w.snapshot_id = r.snapshot_id and w.nct_id = r.nct_id and w.pointer = r.pointer
            group by 1, 2""")
        timings["leaf_reconciliation_seconds"] = round(time.monotonic() - t0, 2)
        conn.execute("""delete from audit.transformation_defect d using scope_study s
                        where d.snapshot_id = s.snapshot_id and d.nct_id = s.nct_id""")
        conn.execute("""
            insert into audit.transformation_defect (snapshot_id, nct_id, pointer, defect_kind, reference_value, warehouse_value)
            select coalesce(r.snapshot_id, w.snapshot_id), coalesce(r.nct_id, w.nct_id), coalesce(r.pointer, w.pointer),
                   case when w.pointer is null then 'MISSING_IN_WAREHOUSE' when r.pointer is null then 'EXTRA_IN_WAREHOUSE'
                        else 'VALUE_DIFFERS' end, r.value_text, w.value_text
            from (select l.* from ref.leaf l join scope_study s using (snapshot_id, nct_id)) r
            full outer join (select l.* from ctr.v_leaf l join scope_study s using (snapshot_id, nct_id)) w
              on w.snapshot_id = r.snapshot_id and w.nct_id = r.nct_id and w.pointer = r.pointer
            where (w.pointer is null and r.json_type <> 'excluded') or r.pointer is null or w.value_text is distinct from r.value_text""")
        conn.commit()
        by_mod = Counter()
        wh_family = Counter()
        for r in recon:
            module = r["pattern"].split("/")[2]
            by_mod[(module, r["status"])] += r["n"]
            wh_family[(family(r["pattern"]), r["status"])] += r["n"]
        _write_csv(tdir / "warehouse_leaf_reconciliation.csv",
                   [{"unit": "source scalar", "scope": scope_label, "module": m, "status": s, "n": n}
                    for (m, s), n in sorted(by_mod.items())])

        # object counts (unit: object)
        ref_obj = _rows(conn, """select o.nct_id, o.pattern, o.n from ref.object_count o join scope_study s using (snapshot_id, nct_id)
                                 where s.cohort_status='confirmed'""")
        wh_counts = {}
        for pat, (table, ser) in PATTERN_TABLE.items():
            if (table, ser) in wh_counts:
                continue
            q = (f"select t.nct_id, count(*) n from ctr.{table} t join scope_study s using (snapshot_id, nct_id) "
                 f"where s.cohort_status='confirmed' " + (f"and t.seriousness = '{ser}' " if ser else "") + "group by 1")
            wh_counts[(table, ser)] = {r["nct_id"]: r["n"] for r in _rows(conn, q)}
        obj_tot = defaultdict(lambda: {"reference": 0, "warehouse": 0, "study_mismatches": 0})
        ref_by = defaultdict(dict)
        for r in ref_obj:
            ref_by[r["pattern"]][r["nct_id"]] = r["n"]
        for pat, (table, ser) in PATTERN_TABLE.items():
            w = wh_counts[(table, ser)]
            rf = ref_by.get(pat, {})
            for nct in set(w) | set(rf):
                obj_tot[pat]["reference"] += rf.get(nct, 0)
                obj_tot[pat]["warehouse"] += w.get(nct, 0)
                obj_tot[pat]["study_mismatches"] += int(rf.get(nct, 0) != w.get(nct, 0))
        from .spec import EXCLUDED_POINTER_PREFIXES
        unmapped = sorted(set(ref_by) - set(PATTERN_TABLE))
        _write_csv(tdir / "object_count_reconciliation.csv",
                   [{"unit": "object", "scope": scope_label, "source_pattern": p, "warehouse_table": PATTERN_TABLE[p][0]
                     + (f" ({PATTERN_TABLE[p][1]})" if PATTERN_TABLE[p][1] else ""), **v} for p, v in obj_tot.items()]
                   + [{"unit": "object", "scope": scope_label, "source_pattern": p,
                       "warehouse_table": ("not loaded (excluded by design)"
                                           if any(p == x or p.startswith(x + "/") for x in EXCLUDED_POINTER_PREFIXES)
                                           else "not loaded (unmapped source array)"),
                       "reference": sum(ref_by[p].values()), "warehouse": 0,
                       "study_mismatches": len(ref_by[p])} for p in unmapped])

        # SQL vs R tier agreement
        agree = _rows(conn, """
            select count(*) as n,
                   count(*) filter (where md.tier = r.tier and md.rule_id = r.rule_id
                                    and md.participant_denominator is not distinct from r.participant_denominator
                                    and md.unit_denominator is not distinct from r.unit_denominator) as agree
            from (select * from r_md where cohort_status = 'confirmed') md
            full outer join (select r.* from ref.measurement_tier r join scope_study s using (snapshot_id, nct_id)
                             where s.cohort_status = 'confirmed') r
              using (snapshot_id, nct_id, outcome_ordinal, class_ordinal, category_ordinal, measurement_ordinal)""")[0]
        agree_g = _rows(conn, """
            select count(*) as n, count(*) filter (where t.tier = r.tier and t.rules = r.rules) as agree
            from (select * from r_gt where cohort_status = 'confirmed') t
            full outer join (select r.* from ref.group_tier r join scope_study s using (snapshot_id, nct_id)
                             where s.cohort_status = 'confirmed') r
              using (snapshot_id, nct_id, outcome_ordinal, group_id)""")[0]
        ev = _rows(conn, """select (select count(*) from audit.v_evidence_table e join scope_study s using (snapshot_id, nct_id)
                                    where s.cohort_status = 'confirmed') as evidence_rows,
                                   (select count(*) from ctr.outcome_measurement m join scope_study s using (snapshot_id, nct_id)
                                    where s.cohort_status = 'confirmed') as measurements""")[0]

    # ---------------------------------------------------------------- round trip (unit: study module)
    from .roundtrip import roundtrip
    conf_ids = {r["nct_id"] for r in manifest if r["split"] in splits and r["cohort_status"] == "confirmed"}
    t0 = time.monotonic()
    with pg.connect() as conn:
        rt = roundtrip(conn, snap, raw_dir, conf_ids)
    timings["round_trip_seconds"] = round(time.monotonic() - t0, 2)

    fidelity = [
        {"unit": "measurement", "scope": scope_label, "check": "SQL and independent R tier, rule and denominators agree",
         "n": agree["agree"], "denominator": agree["n"], "pct": pct(agree["agree"], agree["n"])},
        {"unit": "outcome group", "scope": scope_label, "check": "SQL and independent R outcome-group tier and rules agree",
         "n": agree_g["agree"], "denominator": agree_g["n"], "pct": pct(agree_g["agree"], agree_g["n"])},
        {"unit": "study module", "scope": scope_label, "check": "results module rebuilt from the warehouse is identical to the source",
         "n": rt["identical"], "denominator": rt["n"], "pct": pct(rt["identical"], rt["n"])},
        {"unit": "measurement", "scope": scope_label, "check": "cautious evidence view rows per measurement (duplicate join check)",
         "n": ev["evidence_rows"], "denominator": ev["measurements"], "pct": pct(ev["evidence_rows"], ev["measurements"])},
    ]
    in_scope = sum(n for (m, s), n in by_mod.items() if s not in ("excluded by design", "extra in warehouse"))
    exact = sum(n for (m, s), n in by_mod.items() if s == "exact match")
    extra = sum(n for (m, s), n in by_mod.items() if s == "extra in warehouse")
    fidelity.insert(0, {"unit": "source scalar", "scope": scope_label,
                        "check": "in-scope source scalars present in the warehouse with identical text at the same JSON pointer",
                        "n": exact, "denominator": in_scope, "pct": pct(exact, in_scope)})
    fidelity.insert(1, {"unit": "warehouse scalar", "scope": scope_label,
                        "check": "warehouse scalars with no counterpart in the source (extra pointers)", "n": extra,
                        "denominator": None, "pct": None})
    fidelity.append({"unit": "study", "scope": scope_label,
                     "check": "confirmed studies quarantined at load (results not loaded, not rebuilt)",
                     "n": len(rt.get("quarantined_studies_not_rebuilt", [])), "denominator": len(conf_ids),
                     "pct": pct(len(rt.get("quarantined_studies_not_rebuilt", [])), len(conf_ids))})
    _write_csv(tdir / "warehouse_fidelity.csv", fidelity)
    if rt["n_differing"]:
        _write_csv(tdir / "round_trip_differences.csv", rt["differing"])

    # ---------------------------------------------------------------- S4 flat comparison (unit: source scalar, measurement)
    t0 = time.monotonic()
    fc_dir = out / "flat_compare"
    fc = flat_compare_run(raw_dir, conf_ids, build_dir / "flat", build_dir / "reference", fc_dir)
    timings["flat_comparison_seconds"] = round(time.monotonic() - t0, 2)
    fam = defaultdict(Counter)
    with open(fc_dir / "flat_leaf_status_by_family.csv", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            fam[r["family"]][r["status"]] += int(r["n_scalars"])
    ret_rows = []
    attempted_prefixes = ("outcome:", "baseline:", "participant flow:")
    tot = {"all": Counter(), "attempted": Counter(), "wh_all": Counter(), "wh_attempted": Counter()}
    for f in sorted(fam):
        c = fam[f]
        n = sum(c.values())
        whc = Counter({s: v for (ff, s), v in wh_family.items() if ff == f})
        wh_exact = whc["exact match"]
        excl = c["excluded by design"]
        n_scope = n - excl
        row = {"unit": "source scalar", "scope": scope_label, "family": f, "n_scalars_in_scope": n_scope,
               "warehouse_exact": wh_exact, "warehouse_pct": pct(wh_exact, n_scope),
               "flat_recoverable": c["recoverable"], "flat_pct": pct(c["recoverable"], n_scope),
               "flat_ambiguous_context": c["ambiguous context"], "flat_absent_from_rows": c["absent from rows"],
               "flat_no_column": c["no column"], "flat_module_not_exported": c["module not exported"],
               "flat_value_differs": c["value differs"], "excluded_by_design": excl}
        ret_rows.append(row)
        tot["all"].update({k: v for k, v in c.items() if k != "excluded by design"})
        tot["wh_all"]["exact"] += wh_exact
        if f.startswith(attempted_prefixes):
            tot["attempted"].update({k: v for k, v in c.items() if k != "excluded by design"})
            tot["wh_attempted"]["exact"] += wh_exact
    for label, key, wkey in (("all families the flat export attempts (participant flow, baseline, outcomes)", "attempted", "wh_attempted"),
                             ("all in-scope results scalars, including adverse events", "all", "wh_all")):
        c = tot[key]
        n = sum(c.values())
        ret_rows.append({"unit": "source scalar", "scope": scope_label, "family": "TOTAL: " + label, "n_scalars_in_scope": n,
                         "warehouse_exact": tot[wkey]["exact"], "warehouse_pct": pct(tot[wkey]["exact"], n),
                         "flat_recoverable": c["recoverable"], "flat_pct": pct(c["recoverable"], n),
                         "flat_ambiguous_context": c["ambiguous context"], "flat_absent_from_rows": c["absent from rows"],
                         "flat_no_column": c["no column"], "flat_module_not_exported": c["module not exported"],
                         "flat_value_differs": c["value differs"], "excluded_by_design": 0})
    _write_csv(tdir / "retention_flat_vs_warehouse.csv", ret_rows)
    dc = fc["denominator_comparison"]
    n_meas = sum(dc.values())
    _write_csv(tdir / "flat_denominator_comparison.csv",
               [{"unit": "measurement", "scope": scope_label, "category": k, "n": v, "pct_of_measurements": pct(v, n_meas)}
                for k, v in sorted(dc.items())])
    oc = fc["outcomes"]
    _write_csv(tdir / "flat_outcomes_lost.csv",
               [{"unit": "outcome", "scope": scope_label, "category": k, "n": v, "pct_of_outcomes": pct(v, oc.get("outcomes", 0))}
                for k, v in oc.items()])

    # ---------------------------------------------------------------- sensitivity analyses (unit: outcome group)
    with pg.connect() as conn:
        setup_scope(conn, snap, splits)
        sa = []
        base = _rows(conn, "select tier, outcome_type, population_description_present, cohort_status from r_gt")
        sa.append(("Primary: confirmed cohort, all outcome types", [r for r in base if r["cohort_status"] == "confirmed"]))
        sa.append(("SA1: including ambiguous condition matches", [r for r in base if r["cohort_status"] in ("confirmed", "ambiguous_condition_match")]))
        sa.append(("SA2: primary outcomes only", [r for r in base if r["cohort_status"] == "confirmed" and r["outcome_type"] == "PRIMARY"]))
        sa3 = []
        for r in base:
            if r["cohort_status"] != "confirmed":
                continue
            t = r["tier"]
            if t in ("A", "B") and not r["population_description_present"]:
                t = "C"
            sa3.append({**r, "tier": t})
        sa.append(("SA3: resolvable only with a population description (composite)", sa3))
        if split == "heldout":
            setup_scope(conn, snap, ["development", "heldout"])
            both = _rows(conn, "select tier, cohort_status from r_gt where cohort_status='confirmed'")
            sa.append(("SA4: development and held-out portions combined", both))
        sens = []
        for label, rows in sa:
            t = tier_table(rows, "outcome group", label)[0] if rows else {}
            t["analysis"] = label
            sens.append(t)
        _write_csv(tdir / "sensitivity_analyses.csv", sens,
                   ["unit", "analysis", "n_applicable", "n_A", "n_B", "n_C", "n_D_not_applicable", "pct_A", "pct_B", "pct_C",
                    "pct_resolvable_A_or_B"])

        # ------------------------------------------------------------ exploratory trial-clustered bootstrap
        setup_scope(conn, snap, splits)
        per = defaultdict(Counter)
        for r in _rows(conn, "select nct_id, tier from r_gt where cohort_status='confirmed' and tier <> 'D'"):
            per[r["nct_id"]][r["tier"]] += 1
        ids = sorted(per)
        arr = np.array([[per[i]["A"], per[i]["B"], per[i]["C"]] for i in ids], dtype=float)
        rng = np.random.default_rng(BOOTSTRAP_SEED)
        draws = rng.integers(0, len(ids), size=(BOOTSTRAP_REPS, len(ids)))
        sums = arr[draws].sum(axis=1)
        totals = sums.sum(axis=1)
        resolvable = (sums[:, 0] + sums[:, 1]) / totals * 100
        cshare = sums[:, 2] / totals * 100
        bshare = sums[:, 1] / totals * 100
        boot = []
        for name, vals, point in (("pct resolvable (A or B)", resolvable, (arr[:, 0].sum() + arr[:, 1].sum()) / arr.sum() * 100),
                                  ("pct B", bshare, arr[:, 1].sum() / arr.sum() * 100),
                                  ("pct C", cshare, arr[:, 2].sum() / arr.sum() * 100)):
            boot.append({"unit": "outcome group (resampled by trial)", "scope": scope_label, "statistic": name,
                         "corpus_value": round(float(point), 3), "p2_5": round(float(np.percentile(vals, 2.5)), 3),
                         "p97_5": round(float(np.percentile(vals, 97.5)), 3), "reps": BOOTSTRAP_REPS, "seed": BOOTSTRAP_SEED,
                         "n_trials": len(ids),
                         "note": "exploratory: describes dependence on trial composition, not sampling uncertainty for all trials"})
        _write_csv(tdir / "exploratory_trial_bootstrap.csv", boot)

        # ------------------------------------------------------------ issue ledger (confirmed cohort in scope)
        ledger = _rows(conn, """select l.issue_class, l.rule_id, l.nct_id, 'https://clinicaltrials.gov/study/' || l.nct_id as registry_url,
                                       l.pointer, l.evidence, l.why_flagged
                                from audit.v_issue_ledger l join scope_study s using (snapshot_id, nct_id)
                                where s.cohort_status = 'confirmed'
                                order by l.issue_class, l.nct_id, l.pointer, l.rule_id""")
        for r in ledger:
            r["issue_id"] = hashlib.sha256(f"{snap}|{r['issue_class']}|{r['rule_id']}|{r['nct_id']}|{r['pointer']}".encode()).hexdigest()[:16]
        _write_csv(tdir / "issue_ledger.csv", ledger,
                   ["issue_id", "issue_class", "rule_id", "nct_id", "registry_url", "pointer", "evidence", "why_flagged"])
        ledger_sum = Counter((r["issue_class"], r["rule_id"]) for r in ledger)
        _write_csv(tdir / "issue_ledger_summary.csv",
                   [{"unit": "ledger row (one flagged object)", "scope": scope_label, "issue_class": k[0], "rule_id": k[1], "n": v,
                     "n_studies": len({r["nct_id"] for r in ledger if (r["issue_class"], r["rule_id"]) == k})}
                    for k, v in sorted(ledger_sum.items())])

        # ------------------------------------------------------------ worked multi-population example
        example = choose_example(conn, snap, scope_label)
        write_json(tdir / "example_multi_population.json", example)

        # evidence table and provenance exports
        export_evidence(conn, out / "exports")

    timings["total_seconds"] = round(time.monotonic() - t_start, 2)
    # Measured timings and sizes vary run to run, so they are kept outside the compared tables directory.
    write_runtime_storage(out / "runtime_storage.csv", build_dir, raw_dir, timings, scope_label)
    run = {"run_id": run_id, "split": split, "kind": kind, "snapshot_id": snap, "created_at": stamp,
           "parser_freeze_sha256": freeze["combined_sha256"] if freeze else None, "timings": timings,
           "scope": scope_label, "tables": sorted(p.name for p in tdir.iterdir())}
    write_json(out / "run.json", run)

    from .redcap import write_dictionary, write_example_import
    rc_dir = out / "redcap"
    write_dictionary(rc_dir / "trial_results_ledger_review_dictionary.csv")
    write_example_import(tdir / "issue_ledger.csv", rc_dir / "ledger_review_example_import.csv", snap)

    if split == "heldout" and not rerun_check:
        shutil.copytree(rc_dir, RESULTS_DIR.parent / "redcap", dirs_exist_ok=True)
        canonical = TABLES_DIR / "heldout"
        if canonical.exists():
            shutil.rmtree(canonical)
        shutil.copytree(tdir, canonical)
        (TABLES_DIR / "runtime").mkdir(parents=True, exist_ok=True)
        shutil.copy(out / "runtime_storage.csv", TABLES_DIR / "runtime" / "heldout_runtime_storage.csv")
        shutil.copytree(out / "exports", RESULTS_DIR / "exports", dirs_exist_ok=True)
        n_attempts = sum(1 for line in open(attempts, encoding="utf-8") if '"split": "heldout"' in line and '"kind": "run"' in line)
        write_json(marker, {"run_id": run_id, "executed_at": stamp, "parser_freeze_sha256": freeze["combined_sha256"],
                            "snapshot_id": snap, "tables_dir": "results/tables/heldout",
                            "held_out_run_attempts_logged": n_attempts,
                            "note": "Held-out audit completed with the frozen parser. Every attempt is listed in "
                                    "evidence/heldout_attempts.jsonl."})
    elif split == "heldout" and rerun_check:
        cmp = compare_runs(TABLES_DIR / "heldout", tdir)
        write_json(out / "rerun_comparison.json", cmp)
        write_json(EVIDENCE_DIR / "rerun_comparison.json", {**cmp, "rerun_id": run_id})
        print(json.dumps({k: v for k, v in cmp.items() if k != "files"}, indent=2))
    elif split == "development":
        canonical = TABLES_DIR / "development"
        if canonical.exists():
            shutil.rmtree(canonical)
        shutil.copytree(tdir, canonical)
        (TABLES_DIR / "runtime").mkdir(parents=True, exist_ok=True)
        shutil.copy(out / "runtime_storage.csv", TABLES_DIR / "runtime" / "development_runtime_storage.csv")
    print(f"Analysis {run_id} written to {out}")
    return out


def write_runtime_storage(path: Path, build_dir: Path, raw_dir: Path, timings: dict, scope_label: str):
    """Measured on this machine only. Build timings cover every study loaded by the build (both portions for build-all)."""
    import platform
    import subprocess
    rep = json.loads((build_dir / "load_report.json").read_text())
    with pg.connect() as conn:
        sizes = {r["schema"]: r["bytes"] for r in _rows(conn, """
            select n.nspname as schema, sum(pg_total_relation_size(c.oid))::bigint as bytes
            from pg_class c join pg_namespace n on n.oid = c.relnamespace
            where n.nspname in ('ctr', 'ref', 'flat', 'audit') and c.relkind in ('r', 'm') group by 1""")}
        version = pg.server_version(conn)
    try:
        cpu = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip()
        mem = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True).stdout.strip() or 0)
    except (OSError, ValueError):
        cpu, mem = platform.processor(), 0
    env = f"{platform.system()} {platform.release()} {platform.machine()}; {cpu}; {mem / 2**30:.0f} GiB RAM; PostgreSQL {version}"
    raw_bytes = sum(p.stat().st_size for p in (raw_dir / "study_pages").glob("*.json"))
    flat_bytes = sum(rep["flat"]["bytes"].values()) if "flat" in rep else None
    rows = [
        ("build: warehouse load (all studies in the build, one transaction)", "seconds", rep.get("seconds"), f"{rep.get('n_studies_in_scope')} studies"),
        ("build: flat baseline export", "seconds", rep.get("flat", {}).get("seconds"), f"{rep.get('flat', {}).get('n_studies')} studies"),
        ("build: independent R reference enumeration", "seconds", rep.get("reference", {}).get("seconds"),
         f"{rep.get('reference', {}).get('n_studies')} studies"),
        ("analyze: scope tables and tier views", "seconds", timings.get("scope_and_tiers_seconds"), scope_label),
        ("analyze: leaf reconciliation query", "seconds", timings.get("leaf_reconciliation_seconds"), scope_label),
        ("analyze: round-trip rebuild", "seconds", timings.get("round_trip_seconds"), scope_label),
        ("analyze: flat retention comparison", "seconds", timings.get("flat_comparison_seconds"), scope_label),
        ("storage: raw API study pages (entire snapshot)", "bytes", raw_bytes, "original JSON as retrieved"),
        ("storage: warehouse tables and indexes, schema ctr (studies loaded by the build)", "bytes", sizes.get("ctr"), "PostgreSQL relation sizes"),
        ("storage: reference tables and indexes, schema ref (studies loaded by the build)", "bytes", sizes.get("ref"), "PostgreSQL relation sizes"),
        ("storage: flat baseline CSV files (studies in the build)", "bytes", flat_bytes, "four CSV files"),
    ]
    _write_csv(path, [{"unit": "measured quantity", "measure": m, "unit_of_value": u, "value": v, "context": c, "environment": env}
                      for m, u, v, c in rows])


def choose_example(conn, snap: str, scope_label: str) -> dict:
    """Deterministic choice among confirmed-cohort outcomes in the analysis scope that have measurements under
    B1_ROW_SPECIFIC_DENOMINATOR, with 3 to 8 distinct rows (classes) and 2 or 3 groups: the outcome with the largest
    (maximum minus minimum row-level participant count) divided by its largest outcome-level participant count;
    ties broken by NCT ID, then outcome position."""
    cand = _rows(conn, """
        with b1 as (select md.nct_id, md.outcome_ordinal, min(md.participant_denominator) mn, max(md.participant_denominator) mx,
                           count(distinct md.class_ordinal) n_rows, count(distinct md.group_id) n_groups
                    from r_md md where md.cohort_status='confirmed' and md.rule_id = 'B1_ROW_SPECIFIC_DENOMINATOR'
                    group by 1, 2 having count(distinct md.class_ordinal) between 3 and 8 and count(distinct md.group_id) between 2 and 3),
             o as (select c.nct_id, c.outcome_ordinal, max(c.value_int) on_max from audit.v_outcome_counts c
                   where c.unit_norm='participants' group by 1, 2)
        select b1.*, o.on_max from b1 join o using (nct_id, outcome_ordinal)
        where o.on_max > 0
        order by (b1.mx - b1.mn)::numeric / o.on_max desc, b1.nct_id, b1.outcome_ordinal limit 1""")
    if not cand:
        return {}
    c = cand[0]
    nct, oi = c["nct_id"], c["outcome_ordinal"]
    head = _rows(conn, """select s.nct_id, s.brief_title, s.registry_url, s.results_first_post_date::text, o.type, o.title, o.time_frame,
                                 o.param_type, o.dispersion_type, o.unit_of_measure, o.population_description, o.source_pointer
                          from ctr.study s join ctr.outcome_measure o using (snapshot_id, nct_id)
                          where s.snapshot_id=%s and s.nct_id=%s and o.outcome_ordinal=%s""", (snap, nct, oi))[0]
    rows = _rows(conn, """select e.class_title, e.category_title, e.group_id, e.group_title, e.value_text, e.spread_text,
                                 e.lower_limit_text, e.upper_limit_text, e.participant_denominator, e.denominator_scope, e.rule_id,
                                 e.measurement_pointer, e.denominator_pointer
                          from audit.v_evidence_table e where e.snapshot_id=%s and e.nct_id=%s and e.outcome_ordinal=%s
                          order by e.measurement_pointer""", (snap, nct, oi))
    outcome_level = _rows(conn, """select d.units, c.group_id, c.value_text, c.source_pointer from ctr.outcome_denom d
                                   join ctr.outcome_denom_count c using (snapshot_id, nct_id, outcome_ordinal, denom_ordinal)
                                   where d.snapshot_id=%s and d.nct_id=%s and d.outcome_ordinal=%s order by c.source_pointer""",
                         (snap, nct, oi))
    baseline = _rows(conn, """select g.group_id, g.title, c.value_text as overall_baseline_count from ctr.baseline_group g
                              left join (select c.* from ctr.baseline_denom d join ctr.baseline_denom_count c
                                         using (snapshot_id, nct_id, denom_ordinal) where audit.norm_unit(d.units)='participants') c
                                on c.nct_id = g.nct_id and c.group_id = g.group_id and c.snapshot_id = g.snapshot_id
                              where g.snapshot_id=%s and g.nct_id=%s order by g.group_ordinal""", (snap, nct))
    flow = _rows(conn, """select p.title as period, m.type as milestone, a.group_id, g.title as group_title, a.num_subjects_text
                          from ctr.flow_achievement a join ctr.flow_milestone m using (snapshot_id, nct_id, period_ordinal, milestone_ordinal)
                          join ctr.flow_period p using (snapshot_id, nct_id, period_ordinal)
                          join ctr.flow_group g on g.snapshot_id = a.snapshot_id and g.nct_id = a.nct_id and g.group_id = a.group_id
                          where a.snapshot_id=%s and a.nct_id=%s and m.type in ('STARTED', 'COMPLETED')
                          order by a.period_ordinal, a.milestone_ordinal, a.group_id""", (snap, nct))
    return {"selection_rule": " ".join(choose_example.__doc__.split()), "scope": scope_label, "study": head, "measurements": rows,
            "outcome_level_denominators": outcome_level,
            "baseline_groups_not_linked": baseline, "participant_flow_not_linked": flow,
            "note": "Baseline and participant-flow groups are listed for context only. Matching titles are not treated as the same population."}


def export_evidence(conn, out_dir: Path):
    """Analyst exports for the confirmed cohort in scope: evidence table and denominator provenance (gzipped CSV)."""
    import gzip
    out_dir.mkdir(parents=True, exist_ok=True)
    for name, sql in (
        ("evidence_table", """select e.* from audit.v_evidence_table e join scope_study s using (snapshot_id, nct_id)
                               where s.cohort_status='confirmed' order by e.nct_id, e.measurement_pointer"""),
        ("denominator_provenance", """select p.nct_id, p.registry_url, p.outcome_ordinal, p.outcome_type, p.outcome_title, p.time_frame,
                                             p.group_id, p.group_title, p.tier, p.rules, p.n_measurements, p.min_participant_denominator,
                                             p.max_participant_denominator, p.n_distinct_participant_denominators, p.analysis_unit,
                                             p.row_specific_mode, p.population_description_present, p.outcome_level_denominators,
                                             p.row_specific_denominators, p.same_label_in_baseline_not_linked, p.group_pointer
                                      from audit.v_denominator_provenance p join scope_study s using (snapshot_id, nct_id)
                                      where s.cohort_status='confirmed' order by p.nct_id, p.outcome_ordinal, p.group_id"""),
    ):
        cur = conn.execute(sql)
        cols = [d.name for d in cur.description]
        with gzip.open(out_dir / f"{name}.csv.gz", "wt", newline="", encoding="utf-8", compresslevel=9) as fh:
            w = csv.writer(fh)
            w.writerow(cols)
            for row in cur:
                w.writerow([_fmt(v) for v in row])


def compare_runs(a: Path, b: Path, tol: float = 1e-9) -> dict:
    """Compare two table directories cell by cell: exact for text and integers, |x - y| <= tol for decimals."""
    files = {}
    ok = True
    for p in sorted(a.iterdir()):
        q = b / p.name
        if not q.exists():
            files[p.name] = "missing in rerun"
            ok = False
            continue
        if p.suffix == ".json":
            same = json.loads(p.read_text()) == json.loads(q.read_text())
        else:
            ra = list(csv.reader(open(p, encoding="utf-8")))
            rb = list(csv.reader(open(q, encoding="utf-8")))
            same = len(ra) == len(rb)
            if same:
                for x, y in zip(ra, rb):
                    if len(x) != len(y):
                        same = False
                        break
                    for u, v in zip(x, y):
                        if u == v:
                            continue
                        try:
                            if abs(float(u) - float(v)) <= tol:
                                continue
                        except ValueError:
                            pass
                        same = False
                        break
                    if not same:
                        break
        files[p.name] = "identical within tolerance" if same else "differs"
        ok &= same
    for q in sorted(b.iterdir()):
        if not (a / q.name).exists():
            files[q.name] = "extra in rerun"
            ok = False
    return {"tolerance": tol, "all_identical": ok, "n_files": len(files), "files": files}
