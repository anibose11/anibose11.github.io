"""Source-to-warehouse field map for the results section.

One declaration drives four things: the loader (etl.py), the data dictionary (docs/data_dictionary.csv),
the warehouse leaf view used for reconciliation against the independent R reference, and the round-trip
rebuild of each results module. Field kinds:

  text     exact source string in column <base>
  textnum  exact source string in <base>_text, parsed decimal in <base>_num when the text is a plain number
  textint  exact source string in <base>_text, parsed integer in <base>_int when the text is a non-negative integer
  bool     JSON boolean in column <base>
  int      JSON integer in column <base>
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class F:
    key: str          # JSON key in the source object
    base: str         # column (or column stem) in the table
    kind: str = "text"
    label: str = ""   # registry data element label from the API metadata

    def columns(self) -> list[str]:
        if self.kind == "textnum":
            return [f"{self.base}_text", f"{self.base}_num"]
        if self.kind == "textint":
            return [f"{self.base}_text", f"{self.base}_int"]
        return [self.base]

    def text_column(self) -> str:
        return self.columns()[0]


@dataclass(frozen=True)
class Obj:
    name: str             # object type name used in reconciliation tables
    table: str            # ctr table
    path: str             # source path pattern (documentation)
    keys: tuple           # key columns after (snapshot_id, nct_id)
    fields: tuple         # F declarations
    children: tuple = ()  # JSON keys holding child lists handled elsewhere
    excluded: tuple = ()  # JSON keys deliberately not loaded
    unit: str = ""        # what one row represents


GROUP_FIELDS = (F("id", "group_id", label="Arm/Group ID"), F("title", "title", label="Arm/Group Title"),
                F("description", "description", label="Arm/Group Description"))
DENOM_FIELDS = (F("units", "units", label="Units of the denominator (Participants or another analysis unit)"),)
DENOM_COUNT_FIELDS = (F("groupId", "group_id", label="Arm/Group ID"),
                      F("value", "value", "textint", label="Number analyzed for the group"))
MEASUREMENT_FIELDS = (F("groupId", "group_id", label="Arm/Group ID"), F("value", "value", "textnum", label="Value"),
                      F("spread", "spread", "textnum", label="Dispersion value"),
                      F("lowerLimit", "lower_limit", "textnum", label="Lower limit"),
                      F("upperLimit", "upper_limit", "textnum", label="Upper limit"),
                      F("comment", "comment", label="Comments for N/A values"))

OBJECTS: tuple[Obj, ...] = (
    Obj("flow_module", "flow_module", "/resultsSection/participantFlowModule", (),
        (F("recruitmentDetails", "recruitment_details", label="Recruitment Details"),
         F("preAssignmentDetails", "pre_assignment_details", label="Pre-assignment Details"),
         F("typeUnitsAnalyzed", "type_units_analyzed", label="Type of Unit Analyzed")),
        children=("groups", "periods"), unit="study"),
    Obj("flow_group", "flow_group", "/resultsSection/participantFlowModule/groups/{g}", ("group_id",), GROUP_FIELDS,
        unit="participant flow group"),
    Obj("flow_period", "flow_period", "/resultsSection/participantFlowModule/periods/{p}", ("period_ordinal",),
        (F("title", "title", label="Period Title"),), children=("milestones", "dropWithdraws"), unit="period"),
    Obj("flow_milestone", "flow_milestone", ".../periods/{p}/milestones/{m}", ("period_ordinal", "milestone_ordinal"),
        (F("type", "type", label="Milestone Title"), F("comment", "comment", label="Milestone Comment")),
        children=("achievements",), unit="milestone"),
    Obj("flow_achievement", "flow_achievement", ".../milestones/{m}/achievements/{a}",
        ("period_ordinal", "milestone_ordinal", "achievement_ordinal"),
        (F("groupId", "group_id", label="Milestone Arm/Group ID"), F("comment", "comment", label="Milestone Arm/Group Comment"),
         F("numSubjects", "num_subjects", "textint", label="Number of Milestone Arm/Group Participants"),
         F("numUnits", "num_units", "textint", label="Number of Units")), unit="milestone count"),
    Obj("flow_drop_withdraw", "flow_drop_withdraw", ".../periods/{p}/dropWithdraws/{d}", ("period_ordinal", "drop_ordinal"),
        (F("type", "type", label="Reason Not Completed Type"), F("comment", "comment", label="Description of Reason Not Completed")),
        children=("reasons",), unit="reason not completed"),
    Obj("flow_drop_reason", "flow_drop_reason", ".../dropWithdraws/{d}/reasons/{r}",
        ("period_ordinal", "drop_ordinal", "reason_ordinal"),
        (F("groupId", "group_id", label="Reason Group ID"), F("comment", "comment"),
         F("numSubjects", "num_subjects", "textint", label="Reason Group Number of Subjects")), unit="reason count"),

    Obj("baseline_module", "baseline_module", "/resultsSection/baselineCharacteristicsModule", (),
        (F("populationDescription", "population_description", label="Baseline Analysis Population Description"),
         F("typeUnitsAnalyzed", "type_units_analyzed", label="Type of Units Analyzed")),
        children=("groups", "denoms", "measures"), unit="study"),
    Obj("baseline_group", "baseline_group", ".../baselineCharacteristicsModule/groups/{g}", ("group_id",), GROUP_FIELDS,
        unit="baseline group"),
    Obj("baseline_denom", "baseline_denom", ".../baselineCharacteristicsModule/denoms/{d}", ("denom_ordinal",),
        DENOM_FIELDS, children=("counts",), unit="baseline overall denominator"),
    Obj("baseline_denom_count", "baseline_denom_count", ".../denoms/{d}/counts/{c}", ("denom_ordinal", "count_ordinal"),
        DENOM_COUNT_FIELDS, unit="baseline overall denominator count"),
    Obj("baseline_measure", "baseline_measure", ".../baselineCharacteristicsModule/measures/{k}", ("measure_ordinal",),
        (F("title", "title", label="Baseline Measure Title"), F("description", "description"),
         F("populationDescription", "population_description", label="Baseline Measure Description"),
         F("paramType", "param_type", label="Baseline Measure Type"),
         F("dispersionType", "dispersion_type", label="Baseline Measure Dispersion/Precision"),
         F("unitOfMeasure", "unit_of_measure", label="Unit of Measure"),
         F("calculatePct", "calculate_pct", "bool", label="Calculated Percentage"),
         F("denomUnitsSelected", "denom_units_selected", label="Type of Units Selected")),
        children=("denoms", "classes"), unit="baseline measure"),
    Obj("baseline_measure_denom", "baseline_measure_denom", ".../measures/{k}/denoms/{d}", ("measure_ordinal", "denom_ordinal"),
        DENOM_FIELDS, children=("counts",), unit="baseline measure denominator"),
    Obj("baseline_measure_denom_count", "baseline_measure_denom_count", ".../measures/{k}/denoms/{d}/counts/{c}",
        ("measure_ordinal", "denom_ordinal", "count_ordinal"), DENOM_COUNT_FIELDS, unit="baseline measure denominator count"),
    Obj("baseline_class", "baseline_class", ".../measures/{k}/classes/{c}", ("measure_ordinal", "class_ordinal"),
        (F("title", "title", label="Baseline Row Title"),), children=("denoms", "categories"), unit="baseline class"),
    Obj("baseline_class_denom", "baseline_class_denom", ".../classes/{c}/denoms/{d}",
        ("measure_ordinal", "class_ordinal", "denom_ordinal"), DENOM_FIELDS, children=("counts",), unit="baseline row denominator"),
    Obj("baseline_class_denom_count", "baseline_class_denom_count", ".../classes/{c}/denoms/{d}/counts/{n}",
        ("measure_ordinal", "class_ordinal", "denom_ordinal", "count_ordinal"), DENOM_COUNT_FIELDS,
        unit="baseline row denominator count"),
    Obj("baseline_category", "baseline_category", ".../classes/{c}/categories/{t}",
        ("measure_ordinal", "class_ordinal", "category_ordinal"), (F("title", "title", label="Category Title"),),
        children=("measurements",), unit="baseline category"),
    Obj("baseline_measurement", "baseline_measurement", ".../categories/{t}/measurements/{v}",
        ("measure_ordinal", "class_ordinal", "category_ordinal", "measurement_ordinal"), MEASUREMENT_FIELDS,
        unit="baseline measurement"),

    Obj("outcome_measure", "outcome_measure", "/resultsSection/outcomeMeasuresModule/outcomeMeasures/{o}", ("outcome_ordinal",),
        (F("type", "type", label="Outcome Measure Type"), F("title", "title", label="Outcome Measure Title"),
         F("description", "description", label="Outcome Measure Description"),
         F("populationDescription", "population_description", label="Analysis Population Description"),
         F("reportingStatus", "reporting_status", label="Reporting Status"),
         F("anticipatedPostingDate", "anticipated_posting_date", label="Anticipated Reporting Date"),
         F("paramType", "param_type", label="Outcome Measure Data Type"),
         F("dispersionType", "dispersion_type", label="Outcome Measure Dispersion/Precision"),
         F("unitOfMeasure", "unit_of_measure", label="Unit of Measure"),
         F("calculatePct", "calculate_pct", "bool", label="Calculated Percentage"),
         F("timeFrame", "time_frame", label="Outcome Measure Time Frame"),
         F("typeUnitsAnalyzed", "type_units_analyzed", label="Units Analyzed"),
         F("denomUnitsSelected", "denom_units_selected", label="Units selected for the measure")),
        children=("groups", "denoms", "classes", "analyses"), unit="outcome measure"),
    Obj("outcome_group", "outcome_group", ".../outcomeMeasures/{o}/groups/{g}", ("outcome_ordinal", "group_id"), GROUP_FIELDS,
        unit="outcome group"),
    Obj("outcome_denom", "outcome_denom", ".../outcomeMeasures/{o}/denoms/{d}", ("outcome_ordinal", "denom_ordinal"),
        DENOM_FIELDS, children=("counts",), unit="outcome denominator"),
    Obj("outcome_denom_count", "outcome_denom_count", ".../outcomeMeasures/{o}/denoms/{d}/counts/{c}",
        ("outcome_ordinal", "denom_ordinal", "count_ordinal"), DENOM_COUNT_FIELDS, unit="outcome denominator count"),
    Obj("outcome_class", "outcome_class", ".../outcomeMeasures/{o}/classes/{c}", ("outcome_ordinal", "class_ordinal"),
        (F("title", "title", label="Class (row) title"),), children=("denoms", "categories"), unit="outcome class"),
    Obj("outcome_class_denom", "outcome_class_denom", ".../classes/{c}/denoms/{d}",
        ("outcome_ordinal", "class_ordinal", "denom_ordinal"), DENOM_FIELDS, children=("counts",), unit="outcome row denominator"),
    Obj("outcome_class_denom_count", "outcome_class_denom_count", ".../classes/{c}/denoms/{d}/counts/{n}",
        ("outcome_ordinal", "class_ordinal", "denom_ordinal", "count_ordinal"), DENOM_COUNT_FIELDS,
        unit="outcome row denominator count"),
    Obj("outcome_category", "outcome_category", ".../classes/{c}/categories/{t}",
        ("outcome_ordinal", "class_ordinal", "category_ordinal"), (F("title", "title", label="Category Title"),),
        children=("measurements",), unit="outcome category"),
    Obj("outcome_measurement", "outcome_measurement", ".../categories/{t}/measurements/{v}",
        ("outcome_ordinal", "class_ordinal", "category_ordinal", "measurement_ordinal"), MEASUREMENT_FIELDS,
        unit="outcome measurement"),
    Obj("outcome_analysis", "outcome_analysis", ".../outcomeMeasures/{o}/analyses/{a}", ("outcome_ordinal", "analysis_ordinal"),
        (F("paramType", "param_type", label="Estimation Parameter"), F("paramValue", "param_value", "textnum", label="Estimated Value"),
         F("dispersionType", "dispersion_type", label="Estimation Dispersion Type"),
         F("dispersionValue", "dispersion_value", "textnum", label="Parameter Dispersion Value"),
         F("statisticalMethod", "statistical_method", label="Statistical Method"),
         F("statisticalComment", "statistical_comment", label="Statistical Comment"),
         F("pValue", "p_value_text", label="P-Value"), F("pValueComment", "p_value_comment", label="P-Value Comment"),
         F("ciNumSides", "ci_num_sides", label="Number of Sides for Confidence Interval"),
         F("ciPctValue", "ci_pct_value_text", label="Percentage for Confidence Interval"),
         F("ciLowerLimit", "ci_lower_limit", "textnum", label="Lower Limit for Confidence Interval"),
         F("ciUpperLimit", "ci_upper_limit", "textnum", label="Upper Limit for Confidence Interval"),
         F("ciLowerLimitComment", "ci_lower_limit_comment"), F("ciUpperLimitComment", "ci_upper_limit_comment"),
         F("estimateComment", "estimate_comment", label="Estimation Comment"),
         F("testedNonInferiority", "tested_non_inferiority", "bool", label="Non-inferiority or Equivalence Test"),
         F("nonInferiorityType", "non_inferiority_type", label="Type of Statistical Test"),
         F("nonInferiorityComment", "non_inferiority_comment"),
         F("otherAnalysisDescription", "other_analysis_description", label="Other Statistical Analysis"),
         F("groupDescription", "group_description", label="Selected Comparison Group Description")),
        children=("groupIds",), unit="statistical analysis"),
    Obj("outcome_analysis_group", "outcome_analysis_group", ".../analyses/{a}/groupIds/{i}",
        ("outcome_ordinal", "analysis_ordinal", "member_ordinal"), (), unit="analysis comparison group"),

    Obj("ae_module", "ae_module", "/resultsSection/adverseEventsModule", (),
        (F("frequencyThreshold", "frequency_threshold", label="Frequency Threshold"),
         F("timeFrame", "time_frame", label="Adverse Event Time Frame"),
         F("description", "description", label="Adverse Event Reporting Description"),
         F("allCauseMortalityComment", "all_cause_mortality_comment", label="All Cause Mortality Comment")),
        children=("eventGroups", "seriousEvents", "otherEvents"), unit="study"),
    Obj("ae_group", "ae_group", ".../adverseEventsModule/eventGroups/{g}", ("group_id",),
        GROUP_FIELDS + (F("deathsNumAffected", "deaths_num_affected", "int"), F("deathsNumAtRisk", "deaths_num_at_risk", "int"),
                        F("seriousNumAffected", "serious_num_affected", "int"), F("seriousNumAtRisk", "serious_num_at_risk", "int"),
                        F("otherNumAffected", "other_num_affected", "int"), F("otherNumAtRisk", "other_num_at_risk", "int")),
        unit="adverse event group"),
    Obj("ae_event", "ae_event", ".../adverseEventsModule/{seriousEvents|otherEvents}/{e}", ("seriousness", "event_ordinal"),
        (F("term", "term", label="Adverse Event Term"), F("organSystem", "organ_system", label="Organ System"),
         F("sourceVocabulary", "source_vocabulary", label="Source Vocabulary Name"),
         F("assessmentType", "assessment_type", label="Collection Approach"), F("notes", "notes", label="Additional Description")),
        children=("stats",), unit="adverse event term"),
    Obj("ae_event_stat", "ae_event_stat", ".../{e}/stats/{s}", ("seriousness", "event_ordinal", "stat_ordinal"),
        (F("groupId", "group_id"), F("numEvents", "num_events", "int", label="Number of events (events, not people)"),
         F("numAffected", "num_affected", "int", label="Number of Participants Affected"),
         F("numAtRisk", "num_at_risk", "int", label="Number of Participants at Risk")), unit="adverse event count"),

    Obj("more_info", "more_info", "/resultsSection/moreInfoModule/limitationsAndCaveats", (),
        (F("description", "limitations_and_caveats", label="Limitations and Caveats Description"),),
        excluded=("certainAgreement", "pointOfContact"), unit="study"),
)

OBJ_BY_NAME = {o.name: o for o in OBJECTS}

# Source subtrees deliberately not loaded. The point of contact holds names, e-mail addresses and
# telephone numbers, which this project does not need; certain-agreement flags are out of scope.
EXCLUDED_POINTER_PREFIXES = (
    "/resultsSection/moreInfoModule/pointOfContact",
    "/resultsSection/moreInfoModule/certainAgreement",
)


def table_columns(obj: Obj) -> list[str]:
    cols = ["snapshot_id", "nct_id"]
    for k in obj.keys:
        if k not in cols:
            cols.append(k)
    extra_ordinals = {
        "flow_group": ["group_ordinal"], "baseline_group": ["group_ordinal"], "outcome_group": ["group_ordinal"],
        "ae_group": ["group_ordinal"],
    }.get(obj.name, [])
    cols += extra_ordinals
    for f in obj.fields:
        for c in f.columns():
            if c not in cols:
                cols.append(c)
    if obj.name == "outcome_analysis_group":
        cols.append("group_id")
    cols.append("source_pointer")
    return cols
