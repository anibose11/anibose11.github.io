"""Parser freeze: hash the files that define mappings, rules and analysis before the held-out run.

The held-out build and analysis refuse to run if any frozen file has changed since the freeze. Presentation code
(figures, rendering, packaging) is not frozen because it does not change any computed result.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json

from .config import EVIDENCE_DIR, LOCAL_DIR, ROOT, write_json

FROZEN_GLOBS = [
    "src/tra/acquire.py", "src/tra/manifest.py", "src/tra/spec.py", "src/tra/etl.py", "src/tra/flat.py",
    "src/tra/flat_compare.py", "src/tra/reference.py", "src/tra/roundtrip.py", "src/tra/analyze.py", "src/tra/pg.py",
    "src/tra/config.py", "sql/*.sql", "R/*.R", "docs/rules.md", "config/cohort.yaml", "config/database.yaml",
]
FREEZE_FILE = EVIDENCE_DIR / "parser_freeze.json"


def _hashes() -> dict[str, str]:
    out = {}
    for pattern in FROZEN_GLOBS:
        for p in sorted(ROOT.glob(pattern)):
            out[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def freeze_parser() -> dict:
    if FREEZE_FILE.exists():
        raise SystemExit(f"Parser already frozen at {json.loads(FREEZE_FILE.read_text())['frozen_at']}; "
                         "a new freeze would invalidate the held-out procedure.")
    h = _hashes()
    combined = hashlib.sha256("\n".join(f"{k}:{v}" for k, v in sorted(h.items())).encode()).hexdigest()
    rec = {"frozen_at": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "combined_sha256": combined,
           "files": h, "note": "Mappings, tier rules, checks and analysis code frozen after development-portion work only."}
    write_json(FREEZE_FILE, rec)
    LOCAL_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Frozen {len(h)} files, combined SHA-256 {combined}")
    return rec


def assert_heldout_allowed() -> dict:
    if not FREEZE_FILE.exists():
        raise SystemExit("The held-out portion is locked until the parser is frozen: python -m tra freeze-parser")
    rec = json.loads(FREEZE_FILE.read_text())
    now = _hashes()
    changed = sorted(k for k in set(now) | set(rec["files"]) if now.get(k) != rec["files"].get(k))
    if changed:
        raise SystemExit("Frozen files changed after the freeze; the held-out run would no longer be the frozen parser:\n  "
                         + "\n  ".join(changed))
    return rec
