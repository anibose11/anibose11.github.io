"""(Re)create the generated leaf view and the audit views after a load."""
from __future__ import annotations

from .config import SQL_DIR
from .reference import write_leaf_view_file


def create_views(conn):
    write_leaf_view_file()
    for name in ("02_audit_views.sql", "03_leaf_view.sql"):
        conn.execute((SQL_DIR / name).read_text())
