"""Acquire stage: frozen manifest queries and full-record retrieval from ClinicalTrials.gov API v2.

Raw API responses are saved byte for byte with SHA-256 hashes. Nothing in this module reads the
results section of a record; the manifest step uses identifiers, conditions and status fields only.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import time
from pathlib import Path
from urllib.parse import urlencode

import httpx

from .config import FROZEN_DIR, LOCAL_DIR, RAW_DIR, load_cohort_config, write_json

USER_AGENT = "trial-results-audit/1.0 (research retrieval script; python-httpx)"


class RetrievalError(RuntimeError):
    pass


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0)


def iso(ts: dt.datetime) -> str:
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Fetcher:
    """HTTP GET with pacing, bounded retries and validation that the body is JSON, not an error page."""

    def __init__(self, cfg: dict, log_path: Path):
        api = cfg["api"]
        self.base = api["base_url"]
        self.timeout = api["timeout_seconds"]
        self.max_retries = api["max_retries"]
        self.backoff = api["backoff_seconds"]
        self.min_interval = api["min_interval_seconds"]
        self.client = httpx.Client(timeout=self.timeout, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
        self.log_path = log_path
        self._last = 0.0

    def close(self):
        self.client.close()

    def _log(self, entry: dict):
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.log_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def get(self, path: str, params: dict | None = None, expect_keys: tuple[str, ...] = ()) -> tuple[bytes, dict, str]:
        url = self.base + path
        full_url = url + ("?" + urlencode(params, safe=",[]:") if params else "")
        last_err = None
        for attempt in range(self.max_retries):
            wait = self.min_interval - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()
            started = utcnow()
            try:
                resp = self.client.get(url, params=params)
            except httpx.HTTPError as exc:  # network failure: retry with backoff
                last_err = f"{type(exc).__name__}: {exc}"
                self._log({"ts": iso(started), "url": full_url, "attempt": attempt + 1, "error": last_err})
                time.sleep(self.backoff * (2 ** attempt))
                continue
            body = resp.content
            ctype = resp.headers.get("content-type", "")
            entry = {"ts": iso(started), "url": str(resp.request.url), "attempt": attempt + 1, "status": resp.status_code,
                     "content_type": ctype, "bytes": len(body), "sha256": sha256_bytes(body)}
            if resp.status_code in (429, 500, 502, 503, 504):
                entry["error"] = "retryable status"
                self._log(entry)
                last_err = f"HTTP {resp.status_code}"
                time.sleep(self.backoff * (2 ** attempt))
                continue
            if resp.status_code != 200:
                entry["error"] = body[:300].decode("utf-8", "replace")
                self._log(entry)
                raise RetrievalError(f"HTTP {resp.status_code} for {full_url}: {entry['error']}")
            if not ctype.startswith("application/json"):
                entry["error"] = "unexpected content type"
                self._log(entry)
                raise RetrievalError(f"Unexpected content type {ctype!r} for {full_url}")
            try:
                obj = json.loads(body)
            except json.JSONDecodeError as exc:
                entry["error"] = f"invalid JSON: {exc}"
                self._log(entry)
                last_err = entry["error"]
                time.sleep(self.backoff * (2 ** attempt))
                continue
            if not isinstance(obj, dict) or any(k not in obj for k in expect_keys):
                entry["error"] = f"JSON missing expected keys {expect_keys}"
                self._log(entry)
                raise RetrievalError(entry["error"] + f" for {full_url}")
            self._log(entry)
            return body, obj, str(resp.request.url)
        raise RetrievalError(f"Gave up after {self.max_retries} attempts for {full_url}: {last_err}")


def _advanced_filter(cfg: dict) -> str:
    fr = cfg["frame"]
    return (f"AREA[StudyType]{fr['study_type']} AND "
            f"AREA[{fr['results_first_post_date_field']}]RANGE[{fr['window_start']},{fr['window_end']}]")


def _write_bytes(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)


def _valid_saved(path: Path, expect_sha: str | None = None) -> bool:
    if not path.exists():
        return False
    data = path.read_bytes()
    try:
        json.loads(data)
    except json.JSONDecodeError:
        return False
    return expect_sha is None or sha256_bytes(data) == expect_sha


def acquire(force: bool = False) -> str:
    cfg = load_cohort_config()
    pointer = FROZEN_DIR / "CURRENT_SNAPSHOT"
    progress = LOCAL_DIR / "acquire_in_progress"
    if pointer.exists() and not force and not progress.exists():
        snap = pointer.read_text().strip()
        print(f"Snapshot {snap} is already frozen; cached raw files are immutable. Use --force for a new snapshot.")
        return snap

    if progress.exists() and not force:
        snapshot_id = progress.read_text().strip()
        print(f"Resuming interrupted retrieval {snapshot_id}")
    else:
        snapshot_id = "ctgov-" + utcnow().strftime("%Y%m%dT%H%M%SZ")
        LOCAL_DIR.mkdir(parents=True, exist_ok=True)
        progress.write_text(snapshot_id)

    raw_dir = RAW_DIR / snapshot_id
    raw_dir.mkdir(parents=True, exist_ok=True)
    state_path = raw_dir / "retrieval_state.json"
    state = json.loads(state_path.read_text()) if state_path.exists() else {"snapshot_id": snapshot_id, "queries": {}, "batches": {}}
    fetch = Fetcher(cfg, raw_dir / "retrieval_log.jsonl")

    try:
        if "version_before" not in state:
            body, obj, url = fetch.get("/version", expect_keys=("apiVersion", "dataTimestamp"))
            _write_bytes(raw_dir / "version_before.json", body)
            state["version_before"] = {**obj, "retrieved_at": iso(utcnow()), "url": url, "sha256": sha256_bytes(body)}
            state["retrieval_started_at"] = state["version_before"]["retrieved_at"]
            write_json(state_path, state)

        adv = _advanced_filter(cfg)
        page_size = cfg["api"]["manifest_page_size"]
        for q in cfg["condition_queries"]:
            group = q["group"]
            if state["queries"].get(group, {}).get("complete"):
                continue
            ids: list[str] = []
            pages = []
            token = None
            k = 0
            total = None
            while True:
                params = {"query.cond": q["query_cond"], "filter.advanced": adv, "countTotal": "true",
                          "pageSize": str(page_size), "fields": "NCTId", "format": "json"}
                if token:
                    params["pageToken"] = token
                body, obj, url = fetch.get("/studies", params, expect_keys=("studies",))
                fname = f"manifest_pages/{group}_p{k:03d}.json"
                _write_bytes(raw_dir / fname, body)
                if k == 0:
                    total = obj.get("totalCount")
                page_ids = [s["protocolSection"]["identificationModule"]["nctId"] for s in obj["studies"]]
                ids.extend(page_ids)
                pages.append({"file": fname, "url": url, "sha256": sha256_bytes(body), "bytes": len(body), "n": len(page_ids)})
                token = obj.get("nextPageToken")
                k += 1
                if not token:
                    break
            if total is None or len(ids) != total or len(set(ids)) != len(ids):
                raise RetrievalError(f"Query {group}: collected {len(ids)} ids ({len(set(ids))} unique) but totalCount={total}")
            state["queries"][group] = {"query_cond": q["query_cond"], "filter_advanced": adv, "total_count": total,
                                      "n_ids": len(ids), "ids": sorted(ids), "pages": pages, "complete": True,
                                      "completed_at": iso(utcnow())}
            write_json(state_path, state)
            print(f"  {group}: {total} identifiers in {len(pages)} page(s)")

        union = sorted(set().union(*[set(v["ids"]) for v in state["queries"].values()]))
        ceiling = cfg["frame"]["resource_ceiling_studies"]
        state["union_n"] = len(union)
        state["sampling"] = {"applied": len(union) > ceiling, "ceiling": ceiling}
        if len(union) > ceiling:
            raise RetrievalError(f"Union of {len(union)} exceeds the {ceiling} ceiling; stratified sampling must be "
                                 "run from the manifest before parsing (not needed for this snapshot).")

        bsz = cfg["api"]["batch_size"]
        batches = [union[i:i + bsz] for i in range(0, len(union), bsz)]
        for b, chunk in enumerate(batches):
            key = f"batch_{b:04d}"
            done = state["batches"].get(key)
            fpath = raw_dir / "study_pages" / f"{key}.json"
            if done and done.get("ids") == chunk and _valid_saved(fpath, done.get("sha256")):
                continue
            # pageSize is one larger than the request so a complete answer carries no next-page token
            # (the API returns a token whenever a page is exactly full).
            params = {"filter.ids": ",".join(chunk), "pageSize": str(len(chunk) + 1), "format": "json"}
            body, obj, url = fetch.get("/studies", params, expect_keys=("studies",))
            got = [s["protocolSection"]["identificationModule"]["nctId"] for s in obj["studies"]]
            if sorted(got) != chunk or obj.get("nextPageToken"):
                raise RetrievalError(f"{key}: requested {len(chunk)} ids, received {len(got)}; mismatch or unexpected next page")
            _write_bytes(fpath, body)
            state["batches"][key] = {"file": f"study_pages/{key}.json", "url": url, "ids": chunk,
                                     "sha256": sha256_bytes(body), "bytes": len(body), "retrieved_at": iso(utcnow())}
            write_json(state_path, state)
            print(f"  {key}: {len(chunk)} records, {len(body):,} bytes")

        body, obj, url = fetch.get("/version", expect_keys=("apiVersion", "dataTimestamp"))
        _write_bytes(raw_dir / "version_after.json", body)
        state["version_after"] = {**obj, "retrieved_at": iso(utcnow()), "url": url, "sha256": sha256_bytes(body)}
        state["retrieval_finished_at"] = state["version_after"]["retrieved_at"]
        state["data_timestamp_changed_during_retrieval"] = (
            state["version_before"]["dataTimestamp"] != state["version_after"]["dataTimestamp"])
        state["complete"] = True
        write_json(state_path, state)
    finally:
        fetch.close()

    FROZEN_DIR.mkdir(parents=True, exist_ok=True)
    pointer.write_text(snapshot_id + "\n")
    progress.unlink(missing_ok=True)
    print(f"Snapshot {snapshot_id}: {len(union)} studies in {len(state['batches'])} batch files")
    return snapshot_id
