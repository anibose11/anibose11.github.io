"""Fast demo on the synthetic fixtures (a software test of the pipeline, not evidence about registry data).

Creates the database `tra_demo` in the project cluster, loads the seven fixture studies, builds the views, prints the
tier summary, a few evidence-table rows and the checks that fail, and writes them to demo_output/.
"""
from __future__ import annotations

import csv
import json
import shutil
import tempfile
from pathlib import Path

from . import pg
from .config import ROOT
from .etl import apply_schema, load_snapshot
from .views import create_views

DEMO_DB = "tra_demo"


def demo(keep: bool = False) -> int:
    import sys
    sys.path.insert(0, str(ROOT / "tests"))
    from conftest import SNAPSHOT, make_fixture_snapshot  # noqa: E402

    tmp = Path(tempfile.mkdtemp(prefix="tra-demo-"))
    raw_dir, frozen_dir = make_fixture_snapshot(tmp)
    params = pg.ensure_cluster(database=DEMO_DB)
    out = ROOT / "demo_output"
    out.mkdir(exist_ok=True)
    try:
        with pg.connect(params) as conn:
            for schema in ("audit", "flat", "ref", "ctr"):
                conn.execute(f"drop schema if exists {schema} cascade")
            conn.commit()
            apply_schema(conn)
            rep = load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)
            create_views(conn)
            conn.commit()
            rep2 = load_snapshot(conn, {"development"}, SNAPSHOT, raw_dir, frozen_dir)
            conn.commit()
            tiers = conn.execute("select tier, count(*) from audit.v_outcome_group_tier group by 1 order by 1").fetchall()
            ev = conn.execute("""select nct_id, outcome_title, class_title, group_title, value_text, participant_denominator,
                                        denominator_scope, tier, rule_id, caution
                                 from audit.v_evidence_table where nct_id in ('NCT99000001', 'NCT99000004')
                                 order by nct_id, measurement_pointer""").fetchall()
            fails = conn.execute("select check_id, nct_id, pointer, evidence::text from audit.v_check where status='fail' "
                                 "order by check_id, nct_id, pointer").fetchall()
        fp_same = rep["table_fingerprint"] == rep2["table_fingerprint"]
        print("Synthetic fixture demo (software test only; these are not registry records)")
        print(f"  loaded {rep['n_studies_in_scope']} fixture studies; second load identical: {fp_same}")
        print("  outcome-group tiers (unit: outcome group): " + ", ".join(f"{t}={n}" for t, n in tiers))
        print("  evidence table rows (first 8):")
        for r in ev[:8]:
            print("   ", " | ".join("" if v is None else str(v) for v in r[:9]))
        print(f"  failed checks: {len(fails)} " + ", ".join(sorted({f'{c}:{n}' for c, n, *_ in fails})))
        with open(out / "demo_evidence_rows.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["nct_id", "outcome_title", "class_title", "group_title", "value_text", "participant_denominator",
                        "denominator_scope", "tier", "rule_id", "caution"])
            w.writerows(ev)
        (out / "demo_summary.json").write_text(json.dumps({
            "note": "Synthetic fixtures; software test only.", "fixture_studies": rep["n_studies_in_scope"],
            "second_load_identical": fp_same, "outcome_group_tiers": dict(tiers),
            "failed_checks": [{"check_id": c, "nct_id": n, "pointer": p} for c, n, p, _ in fails]}, indent=2))
        return 0 if fp_same else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        if not keep:
            with pg.connect({**params, "dbname": "postgres"}, autocommit=True) as conn:
                conn.execute(f"drop database if exists {DEMO_DB} with (force)")
