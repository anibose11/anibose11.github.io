"""Freeze stage: frame checks, deterministic condition confirmation, identifier clusters and the split.

Only identification, status, design, condition and condition-browse fields are read here. The results
section is not parsed, so the development/held-out assignment is made before any result is seen.
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

from .acquire import iso, utcnow
from .config import FROZEN_DIR, ROOT, current_snapshot_id, load_cohort_config, snapshot_dirs, write_json

GENERIC_IDS = {"na", "n/a", "none", "not applicable", "nil", "unknown", "tbd", "pending"}


def canonical_sha256(obj) -> str:
    data = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def iter_snapshot_studies(raw_dir: Path):
    """Yield (batch_file, study_dict) in batch order. Shared by every Python stage that reads raw pages."""
    state = json.loads((raw_dir / "retrieval_state.json").read_text())
    for key in sorted(state["batches"]):
        rel = state["batches"][key]["file"]
        with open(raw_dir / rel, encoding="utf-8") as fh:
            page = json.load(fh)
        for study in page["studies"]:
            yield rel, study


def _norm_text(s: str | None) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def _norm_id(s: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


def usable_identifier(s: str | None) -> bool:
    """Identifiers used for clustering need at least 5 alphanumeric characters and cannot be bare short numbers.

    Amendment 1 (2026-10-07, before results parsing): bare values such as "2017" entered as NIH secondary IDs
    linked 123 unrelated studies, so purely numeric identifiers of 4 or fewer digits and identifiers with
    fewer than 5 alphanumeric characters are ignored.
    """
    n = _norm_id(s)
    return bool(n) and _norm_text(s) not in GENERIC_IDS and len(n) >= 5 and not (n.isdigit() and len(n) <= 4)


def _tokens(s: str | None) -> frozenset:
    return frozenset(t for t in re.findall(r"[a-z0-9]+", (s or "").lower()) if len(t) >= 2)


class UnionFind:
    def __init__(self):
        self.parent: dict[str, str] = {}

    def find(self, x: str) -> str:
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def union(self, a: str, b: str):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            if ra < rb:
                self.parent[rb] = ra
            else:
                self.parent[ra] = rb


def confirm_condition(study: dict, qcfg: dict) -> tuple[bool, str]:
    proto = study.get("protocolSection", {})
    derived = study.get("derivedSection", {})
    cbm = derived.get("conditionBrowseModule", {}) or {}
    mesh_ids = {m.get("id") for m in cbm.get("meshes", []) or []}
    anc_ids = {m.get("id") for m in cbm.get("ancestors", []) or []}
    target = qcfg["mesh_descriptor_id"]
    if target in mesh_ids:
        return True, "condition_mesh_term"
    if target in anc_ids:
        return True, "condition_ancestor_mesh_term"
    pat = re.compile(qcfg["condition_regex"], re.I)
    excl = re.compile(qcfg["condition_exclude_regex"], re.I) if qcfg.get("condition_exclude_regex") else None
    for c in proto.get("conditionsModule", {}).get("conditions", []) or []:
        if pat.search(c) and not (excl and excl.search(c)):
            return True, "condition_free_text"
    return False, "matched_only_outside_condition_fields"


def freeze_manifest() -> Path:
    cfg = load_cohort_config()
    snap = current_snapshot_id()
    raw_dir, frozen_dir = snapshot_dirs(snap)
    frozen_dir.mkdir(parents=True, exist_ok=True)
    state = json.loads((raw_dir / "retrieval_state.json").read_text())
    if not state.get("complete"):
        raise SystemExit("Retrieval is not complete; rerun: python -m tra acquire")

    query_hits = defaultdict(list)
    for group, q in state["queries"].items():
        for nct in q["ids"]:
            query_hits[nct].append(group)
    qcfg_by_group = {q["group"]: q for q in cfg["condition_queries"]}
    fr = cfg["frame"]

    rows = []
    uf = UnionFind()
    titles = {}
    for batch_file, study in iter_snapshot_studies(raw_dir):
        proto = study["protocolSection"]
        ident = proto["identificationModule"]
        status = proto.get("statusModule", {})
        design = proto.get("designModule", {})
        nct = ident["nctId"]
        rfp = (status.get("resultsFirstPostDateStruct") or {}).get("date")
        frame_fail = []
        if design.get("studyType") != fr["study_type"]:
            frame_fail.append("study_type")
        if fr["require_has_results"] and not study.get("hasResults"):
            frame_fail.append("has_results_false")
        if "resultsSection" not in study:
            frame_fail.append("no_results_section")
        if not rfp or not (fr["window_start"] <= rfp <= fr["window_end"]):
            frame_fail.append("results_first_post_date_outside_window")

        confirmed, reasons = [], {}
        for group in sorted(query_hits.get(nct, [])):
            ok, why = confirm_condition(study, qcfg_by_group[group])
            reasons[group] = why
            if ok:
                confirmed.append(group)

        org = ident.get("organization", {}) or {}
        uf.find(nct)
        for alias in ident.get("nctIdAliases", []) or []:
            uf.union(nct, alias)
        org_sid = (ident.get("orgStudyIdInfo") or {}).get("id")
        if usable_identifier(org_sid):
            uf.union(nct, "org:" + _norm_text(org.get("fullName")) + "|" + _norm_id(org_sid))
        for sec in ident.get("secondaryIdInfos", []) or []:
            sid = sec.get("id")
            if usable_identifier(sid):
                uf.union(nct, "sec:" + _norm_id(sid))
        otitle = _norm_text(ident.get("officialTitle"))
        if otitle:
            uf.union(nct, "title:" + otitle)
        titles[nct] = _tokens(ident.get("briefTitle"))

        rows.append({
            "nct_id": nct,
            "batch_file": batch_file,
            "record_sha256": canonical_sha256(study),
            "query_groups": "|".join(sorted(query_hits.get(nct, []))),
            "confirmed_groups": "|".join(confirmed),
            "confirmation_reasons": json.dumps(reasons, sort_keys=True),
            "frame_failures": "|".join(frame_fail),
            "results_first_post_date": rfp or "",
            "results_first_post_year": (rfp or "")[:4],
            "last_update_post_date": (status.get("lastUpdatePostDateStruct") or {}).get("date", ""),
            "organization": org.get("fullName", ""),
            "org_study_id": org_sid or "",
            "nct_id_aliases": "|".join(ident.get("nctIdAliases", []) or []),
        })

    # Near-duplicate brief titles (token Jaccard >= 0.9) are linked into the same cluster and reported.
    near = []
    ids = sorted(titles)
    for i, a in enumerate(ids):
        ta = titles[a]
        if not ta:
            continue
        for b in ids[i + 1:]:
            tb = titles[b]
            if not tb:
                continue
            small, large = sorted((len(ta), len(tb)))
            if small / large < 0.9:
                continue
            j = len(ta & tb) / len(ta | tb)
            if j >= 0.9:
                near.append({"nct_a": a, "nct_b": b, "jaccard": round(j, 4)})
                uf.union(a, b)

    salt = cfg["split"]["salt"]
    frac = cfg["split"]["development_fraction"]
    members = defaultdict(list)
    for r in rows:
        members[uf.find(r["nct_id"])].append(r["nct_id"])
    cluster_of = {}
    for root, ms in members.items():
        key = min(ms)
        h = hashlib.sha256(f"{salt}:{key}".encode()).hexdigest()
        u = int(h[:8], 16) / 2 ** 32
        split = "development" if u < frac else "heldout"
        for m in ms:
            cluster_of[m] = (key, len(ms), split, round(u, 6))

    for r in rows:
        key, size, split, u = cluster_of[r["nct_id"]]
        r["cluster_id"] = key
        r["cluster_size"] = size
        r["split"] = split
        r["split_hash_fraction"] = u
        if r["frame_failures"]:
            r["cohort_status"] = "excluded_frame"
        elif r["confirmed_groups"]:
            r["cohort_status"] = "confirmed"
        else:
            r["cohort_status"] = "ambiguous_condition_match"

    rows.sort(key=lambda r: r["nct_id"])
    out = frozen_dir / "manifest.csv"
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    with open(frozen_dir / "near_duplicate_titles.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["nct_a", "nct_b", "jaccard"])
        w.writeheader()
        w.writerows(near)

    def count(pred):
        return sum(1 for r in rows if pred(r))

    summary = {
        "snapshot_id": snap,
        "frozen_at": iso(utcnow()),
        "unit": "study",
        "retrieved_union": len(rows),
        "per_query_total_count": {g: q["total_count"] for g, q in state["queries"].items()},
        "excluded_frame": count(lambda r: r["cohort_status"] == "excluded_frame"),
        "ambiguous_condition_match": count(lambda r: r["cohort_status"] == "ambiguous_condition_match"),
        "confirmed": count(lambda r: r["cohort_status"] == "confirmed"),
        "confirmed_by_group": {g: count(lambda r, g=g: r["cohort_status"] == "confirmed" and g in r["confirmed_groups"].split("|"))
                               for g in qcfg_by_group},
        "confirmed_in_multiple_groups": count(lambda r: r["cohort_status"] == "confirmed" and "|" in r["confirmed_groups"]),
        "clusters": len(members),
        "multi_study_clusters": sum(1 for ms in members.values() if len(ms) > 1),
        "near_duplicate_title_pairs": len(near),
        "split_confirmed": {s: count(lambda r, s=s: r["cohort_status"] == "confirmed" and r["split"] == s)
                            for s in ("development", "heldout")},
        "split_all_retrieved": {s: count(lambda r, s=s: r["split"] == s) for s in ("development", "heldout")},
        "sampling_applied": state["sampling"]["applied"],
    }
    write_json(frozen_dir / "split_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return out
