# Third-party notices

## ClinicalTrials.gov data

The study records analyzed here come from ClinicalTrials.gov, a service of the U.S. National Library of Medicine (NLM), retrieved through the ClinicalTrials.gov Data API v2 (API version 2.0.5; data timestamp 2026-10-06T09:00:05 UTC; retrieved 2026-10-07). Use is subject to the ClinicalTrials.gov Terms and Conditions (https://clinicaltrials.gov/about-site/terms-conditions, last updated 2023-01-31). In line with those terms:

- Source: ClinicalTrials.gov.
- Processing date: the data reflect ClinicalTrials.gov as processed at the data timestamp above. They are a frozen snapshot and are not kept current.
- Modifications: records were restructured into relational tables, numeric text was parsed into additional columns (the original text is kept), tiers, checks and cautions were derived, and the point-of-contact and certain-agreement blocks were removed. All modifications are described in `docs/rules.md`, `docs/data_dictionary.csv` and the report's methods.
- NLM, NIH and HHS make no warranty about the data and are not responsible for this project's use of them. Some record content may be subject to third-party rights outside the United States.

The raw API pages are not included in the public archive. `source_manifest.json` lists the exact request URLs, retrieval times and SHA-256 hashes.

## Software

The code in this repository is MIT licensed (`LICENSE`). It depends on third-party packages under their own licenses, including PostgreSQL (PostgreSQL License), psycopg (LGPL-3.0), httpx (BSD-3-Clause), PyYAML (MIT), NumPy (BSD-3-Clause), Jinja2 and MarkupSafe (BSD-3-Clause), Python-Markdown (BSD-3-Clause), openpyxl (MIT), pytest (MIT) and R with jsonlite (MIT). Exact versions are in `requirements.lock` and the runtime manifest.
