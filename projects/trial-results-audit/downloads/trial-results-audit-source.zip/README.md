# Clinical trial results warehouse and denominator audit

A native PostgreSQL warehouse for public aggregate results from ClinicalTrials.gov (API v2), and an audit of how often a documented participant denominator can be carried with each outcome result without guessing. The cohort is interventional diabetes mellitus, heart failure and obesity trials whose results were first posted from January 2020 to September 2026. The audit compares the warehouse with a declared one-row-per-value flat export and with a separately written R reading of the raw records.

This is a study of machine-readable reporting and of what a transformation keeps. It does not judge treatment effects, detect misconduct, or adjudicate conditions clinically.

The full report (results, methods and limitations) is rendered from `report/manuscript.md.j2` to `site/projects/trial-results-audit/report.html` by `python -m tra render`. Every headline number maps to an output file in `evidence/claims.json`.

## Requirements

- Python 3.12 or newer (the locked NumPy release needs it), R 4.x with the `jsonlite` package. Tested on macOS; written to run on Linux, which was not tested.
- PostgreSQL 17 binaries (`initdb`, `pg_ctl`, `postgres`, `psql`). The project starts its own cluster inside the project folder on a Unix socket (port 55432 by default; set `TRA_PG_PORT` to change it, `TRA_PG_BIN` to point at the binaries). No system database is touched and no superuser setup is needed. The cluster keeps running between commands, so use the same `TRA_PG_PORT` for every command, or run `python -m tra db stop` before changing it.
- Network access only for the `acquire` stage. Docker is not used.

Tested on macOS 27.0 (Apple M5 Pro, 48 GB) with Python 3.13.5, R 4.5.1 (jsonlite 2.0.0) and PostgreSQL 17.11.

PostgreSQL limits Unix socket paths to 103 bytes. Put the project in a folder whose full path is under about 75 characters (for example `~/projects/trial-results-audit`); a deeply nested folder makes the cluster fail to start: the command stops with a `CalledProcessError` from `pg_ctl`, and `logs/postgres-pgdata.log` shows "Unix-domain socket path ... is too long".

## Setup

```bash
python3.13 -m venv .venv    # any Python 3.12 or newer; the system python3 on macOS is too old for the locked NumPy
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install -e . --no-deps
Rscript -e 'if (!requireNamespace("jsonlite", quietly = TRUE)) install.packages("jsonlite", repos = "https://cloud.r-project.org")'
```

## Fast check on synthetic fixtures

Both commands start the project PostgreSQL cluster (the first run initializes it), so they need the PostgreSQL 17 binaries; two tests also call `Rscript`. The tests themselves take a few seconds.

```bash
.venv/bin/python -m pytest -q
.venv/bin/python -m tra demo
```

The fixtures are seven synthetic studies with identifiers in the unused `NCT990…` range. They test software behavior only: unequal denominators, time points with row-specific numbers analyzed, events versus participants, similar group labels across modules, crossover and cluster designs, empty and not-posted modules, every ambiguity rule in both outcome-level and row-level mode, and repeat loading.

## Full pipeline

| Stage | Command | What it does |
|---|---|---|
| acquire | `python -m tra acquire` | Paged condition queries, then full records in batches of 100 by identifier. Saves raw API pages byte for byte with SHA-256 hashes. Skipped when a snapshot is frozen. |
| freeze | `python -m tra freeze` | Frame checks, condition confirmation rule, identifier clusters and the development/held-out split, from identifiers only. |
| build | `python -m tra build --split development --fresh` | Starts the project cluster, creates the schema, loads the warehouse in one transaction, builds views, the flat export and the R reference. |
| analyze | `python -m tra analyze --split development` | Tiers, checks, reconciliation, flat comparison and sensitivity tables for the development portion. |
| freeze-parser | `python -m tra freeze-parser` | One time. Hashes the loader, SQL, R, rules and analysis code. The held-out portion stays locked until this exists, and refuses to run if any frozen file changes. |
| build (all) | `python -m tra build --split all --fresh` | Both portions with the frozen code. |
| analyze (held-out) | `python -m tra analyze --split heldout` | The held-out audit. Runs once; a second call is refused. |
| validate | `python -m tra validate` | Tests, idempotent reload of the real snapshot, an independent rebuild into a second database, a deterministic rerun of the held-out analysis compared cell by cell, REDCap file checks. |
| posthoc | `python -m tra posthoc` | Post hoc descriptive tables added after the held-out run (`results/tables/heldout_posthoc/`), labeled as post hoc wherever reported. |
| render | `python -m tra render` | Report, project page, figures, workbook and exports. Needs the raw snapshot (`data/raw/<snapshot>/`) and the built warehouse, so it cannot run from the source archive alone; the rendered report is `report.html` and the downloads on the project page. |
| package | `python -m tra package` | Source archive, handoff files and the project bundle ZIP. |

`make` targets wrap the same commands.

The source archive includes the records of the original run (`evidence/parser_freeze.json`, `evidence/heldout_run.json`, `evidence/heldout_attempts.jsonl`). While they are present, `freeze-parser` and `analyze --split heldout` refuse to run. To repeat the procedure on a newly acquired snapshot, move these three files out of `evidence/` first and keep them as the record of the published run.

The raw snapshot (about 164 MB) is not in the source archive; `data/snapshot_provenance/<snapshot>/` holds its retrieval state and the API version records, and `data/frozen/<snapshot>/` the frozen identifier manifest and split. Re-running `acquire` retrieves the registry as it is on that day, which will differ from the frozen snapshot; `source_manifest.json` lists the exact URLs, retrieval times, API version, data timestamp and hashes of the original pages so a rebuilt snapshot can be compared file by file.

## Layout

```
config/            cohort and database configuration (frozen)
src/tra/           pipeline (Python): acquire, manifest, spec, etl, flat, flat_compare, analyze, validate, render, package
sql/               warehouse schema, audit views (tiers, checks, evidence table, provenance, ledger), generated leaf view
R/                 independent raw-JSON reference enumerator and rule implementation
docs/              analysis plan and amendments, rules, contribution decision, prior art, literature search, data dictionary
tests/             unit and fixture tests; tests/fixtures holds the synthetic studies and expectations
results/tables/    result tables (development and held-out); results/exports holds gzipped analyst exports
evidence/          claims map, parser freeze record, held-out run record, validation and rerun reports
redcap/            review instrument data dictionary, example import (review fields blank), local check report
report/            report template (manuscript.md.j2)
```

## Using the warehouse

```bash
.venv/bin/python -m tra db start
scripts/psql.sh -c "select tier, count(*) from audit.v_outcome_group_tier group by 1 order by 1"
```

Useful views: `audit.v_evidence_table` (one row per outcome measurement with the associated denominator, its scope, the rule used and cautions), `audit.v_denominator_provenance` (every denominator available to an outcome group, with same-label baseline groups listed but not linked), `audit.v_check` and `audit.v_issue_ledger`.

## License and data

Code: MIT License (`LICENSE`). ClinicalTrials.gov content is provided by the U.S. National Library of Medicine; see `THIRD_PARTY_NOTICES.md` for its terms and attribution. Derived tables contain only public aggregate results and no individual participant data. The point-of-contact block of each results section (names, e-mail addresses, telephone numbers) is not loaded. The local staging copy of each record (`ctr.raw_study`) keeps the protocol section, which includes the study contacts and investigator names the registry publishes; raw records are not part of the archive.
