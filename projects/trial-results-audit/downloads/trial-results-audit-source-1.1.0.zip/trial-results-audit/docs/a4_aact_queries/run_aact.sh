#!/bin/sh
# Run by Animesh Bose in Terminal:  sh run_aact.sh
# It asks for your AACT user name; psql then asks for your AACT password. Nothing is saved, and no AI agent
# sees the password. Results go to a new dated folder next to this script.
# Host, port and database: use what your AACT account page shows. The defaults below are AACT's long-standing
# public settings; change them if your account page says otherwise.
set -e
HOST="${AACT_HOST:-aact-db.ctti-clinicaltrials.org}"
PORT="${AACT_PORT:-5432}"
DB="${AACT_DB:-aact}"
cd "$(dirname "$0")"
OUTDIR="aact_export_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$OUTDIR"
cp heldout_nct_ids.csv "$OUTDIR/"
printf "AACT user name: "
read AACT_USER
cd "$OUTDIR"
psql "host=$HOST port=$PORT dbname=$DB user=$AACT_USER sslmode=require" -f ../1_schema_check.sql
printf "Run the full export for the 1,961 held-out studies now? (y/n) "
read GO
if [ "$GO" = "y" ]; then
  psql "host=$HOST port=$PORT dbname=$DB user=$AACT_USER sslmode=require" -f ../2_export_heldout.sql
fi
shasum -a 256 * > SHA256SUMS.txt
echo "Done. Tell Claude the folder name: $OUTDIR"
