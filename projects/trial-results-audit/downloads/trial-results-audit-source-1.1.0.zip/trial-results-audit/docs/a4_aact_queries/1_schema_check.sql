-- Amendment 4, section 3.1: AACT schema check. Run with: psql <connection> -f 1_schema_check.sql
-- Read-only queries. Output goes to schema_check_output.txt in the current folder.
\set ON_ERROR_STOP off
\pset footer off
\o schema_check_output.txt
select now() at time zone 'utc' as queried_at_utc, version() as server_version, current_database() as database;
-- 2. columns of the outcome tables
select table_schema, table_name, ordinal_position, column_name, data_type
  from information_schema.columns
 where table_schema in ('ctgov', 'ctgov_v2')
   and table_name in ('outcomes', 'outcome_counts', 'outcome_measurements', 'result_groups')
 order by 1, 2, 3;
-- 3. any column that could hold a count or number analyzed
select table_schema, table_name, column_name, data_type
  from information_schema.columns
 where table_schema in ('ctgov', 'ctgov_v2')
   and (column_name ilike '%denom%' or column_name ilike '%count%' or column_name ilike '%analyzed%' or column_name ilike '%number%')
 order by 1, 2, 3;
-- 4. scopes and units of outcome counts (decision rule: any scope other than 'Measure')
select scope, count(*) as n from ctgov.outcome_counts group by 1 order by 2 desc;
select scope, units, count(*) as n from ctgov.outcome_counts group by 1, 2 order by 3 desc limit 40;
-- 5. the worked example (rows should show 9 and 14 at week 0 cross-reactivity if row-level counts are kept)
select o.id, o.nct_id, o.outcome_type, o.title, o.time_frame, o.units_analyzed, o.param_type
  from ctgov.outcomes o where o.nct_id = 'NCT02443155' and o.title = 'Occurrence of Anti-NNC0114-0006 Antibodies';
select c.* from ctgov.outcome_counts c join ctgov.outcomes o on o.id = c.outcome_id
 where o.nct_id = 'NCT02443155' and o.title = 'Occurrence of Anti-NNC0114-0006 Antibodies' order by c.ctgov_group_code, c.units;
select m.* from ctgov.outcome_measurements m join ctgov.outcomes o on o.id = m.outcome_id
 where o.nct_id = 'NCT02443155' and o.title = 'Occurrence of Anti-NNC0114-0006 Antibodies' order by m.classification, m.category, m.ctgov_group_code;
\o
\echo 'Schema check written to schema_check_output.txt'
