import csv, gzip, json, sys, statistics as st, collections, math
base = sys.argv[1]
csv.field_size_limit(10**9)
# outcome-level participant counts per (nct, outcome_ordinal, group)
olc = {}
with gzip.open(base + '/denominator_provenance.csv.gz', 'rt', newline='') as f:
    for r in csv.DictReader(f):
        try:
            lst = json.loads(r['outcome_level_denominators']) if r['outcome_level_denominators'] else []
        except Exception:
            lst = []
        part = [d for d in lst if d.get('units','').strip().lower() == 'participants']
        if len(part) == 1 and part[0]['value'].isdigit():
            olc[(r['nct_id'], r['outcome_ordinal'], r['group_id'])] = int(part[0]['value'])
rows = []
with gzip.open(base + '/evidence_table.csv.gz', 'rt', newline='') as f:
    for r in csv.DictReader(f):
        if r['split'] != 'heldout' or r['cohort_status'] != 'confirmed':
            continue
        rows.append(r)
print('rows', len(rows))
b1 = [r for r in rows if r['rule_id'] == 'B1_ROW_SPECIFIC_DENOMINATOR']
print('B1', len(b1))
diff = []
for r in b1:
    k = (r['nct_id'], r['outcome_ordinal'], r['group_id'])
    if k not in olc or not r['participant_denominator'].isdigit():
        continue
    o = olc[k]; n = int(r['participant_denominator'])
    if n != o:
        diff.append((r, o, n))
print('B1 with differing row count', len(diff))
ratios = [n / o for r, o, n in diff if o > 0]
print('row>outcome', sum(1 for r,o,n in diff if n > o), 'row==0', sum(1 for r,o,n in diff if n == 0), 'outcome==0', sum(1 for r,o,n in diff if o == 0))
qs = sorted(ratios)
def q(p): return qs[int(p*(len(qs)-1))]
print('ratio row/outcome quantiles 5,25,50,75,95:', [round(q(p),3) for p in (0.05,0.25,0.5,0.75,0.95)])
bins = collections.Counter()
for x in ratios:
    if x < 0.5: bins['<0.5'] += 1
    elif x < 0.8: bins['0.5-0.8'] += 1
    elif x < 0.9: bins['0.8-0.9'] += 1
    elif x < 0.95: bins['0.9-0.95'] += 1
    elif x < 1: bins['0.95-1'] += 1
    else: bins['>1'] += 1
print('ratio bins', dict(bins))
# relative error in a derived proportion if count/n: outcome-level n understates proportion by factor ratio
# count of participants outcomes
cop = [(r,o,n) for r,o,n in diff if r['param_type']=='COUNT_OF_PARTICIPANTS' and r['value_text'].isdigit() and n>0 and o>0]
pp = [abs(int(r['value_text'])/n - int(r['value_text'])/o)*100 for r,o,n in cop]
print('COUNT_OF_PARTICIPANTS differing', len(cop), 'studies', len({r['nct_id'] for r,o,n in cop}))
if pp:
    s = sorted(pp)
    print('abs pct-point diff quantiles 50,75,90,95:', [round(s[int(p*(len(s)-1))],2) for p in (0.5,0.75,0.9,0.95)], 'share >=5pp', round(sum(1 for x in pp if x>=5)/len(pp),3), 'share>=10pp', round(sum(1 for x in pp if x>=10)/len(pp),3))
# param types among diff
print('param types', collections.Counter(r['param_type'] for r,o,n in diff).most_common())
print('outcome types', collections.Counter(r['outcome_type'] for r,o,n in diff).most_common())
# for mean outcomes, SE implications: ratio of sqrt(o/n)
mean = [(r,o,n) for r,o,n in diff if r['param_type'] in ('MEAN','LEAST_SQUARES_MEAN','GEOMETRIC_MEAN','MEDIAN') and n>0]
se = sorted(math.sqrt(o/n) for r,o,n in mean)
if se:
    print('mean-type differing', len(mean), 'SE understatement factor sqrt(o/n) median, p90:', round(se[len(se)//2],3), round(se[int(0.9*(len(se)-1))],3), 'share >=1.1', round(sum(1 for x in se if x>=1.1)/len(se),3))
# per-study: share of studies where a primary outcome is affected
prim = {r['nct_id'] for r,o,n in diff if r['outcome_type']=='PRIMARY'}
print('studies with affected primary outcome', len(prim))
# excluding top study
top = collections.Counter(r['nct_id'] for r,o,n in diff).most_common(1)
print('top', top)
# per-study median share of measurements affected among studies with any B1
