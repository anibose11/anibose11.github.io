import json, glob, csv, sys, collections
man = {}
with open(sys.argv[1]) as f:
    for r in csv.DictReader(f): man[r.get('nct_id')] = r
c = collections.Counter(); studies_diff=set(); studies_eval=set()
for fn in sorted(glob.glob(sys.argv[2] + '/study_pages/batch_*.json')):
    for s in json.load(open(fn)).get('studies', []):
        nct = s['protocolSection']['identificationModule']['nctId']
        m = man.get(nct, {})
        if m.get('split') != 'heldout' or m.get('cohort_status', m.get('status','confirmed')) not in ('confirmed',):
            continue
        rs = s.get('resultsSection', {})
        fl = rs.get('participantFlowModule', {}); ae = rs.get('adverseEventsModule', {})
        if not fl or not ae: continue
        periods = fl.get('periods', [])
        if not periods: continue
        started = {}
        for ms in periods[0].get('milestones', []):
            if (ms.get('type') or '').upper() == 'STARTED':
                for a in ms.get('achievements', []):
                    started[a.get('groupId')] = a.get('numSubjects')
        ftitle = {g['id']: (g.get('title') or '').strip() for g in fl.get('groups', [])}
        t2start = collections.defaultdict(list)
        for gid, t in ftitle.items(): t2start[t].append(started.get(gid))
        for eg in ae.get('eventGroups', []):
            t = (eg.get('title') or '').strip()
            risk = eg.get('seriousNumAtRisk', eg.get('otherNumAtRisk'))
            if t in t2start and len(t2start[t]) == 1 and str(t2start[t][0]).isdigit() and str(risk).isdigit():
                st = int(t2start[t][0]); studies_eval.add(nct)
                if st == int(risk): c['same'] += 1
                else: c['differs'] += 1; studies_diff.add(nct)
            else:
                c['no unique title match'] += 1
print(dict(c), 'studies evaluable', len(studies_eval), 'studies with >=1 differing group', len(studies_diff))
