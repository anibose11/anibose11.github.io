import json, glob, sys, collections
c = collections.Counter(); ex = []
nstud=0; nout=0
for fn in sorted(glob.glob(sys.argv[1] + '/study_pages/batch_*.json')):
    d = json.load(open(fn))
    studies = d.get('studies', d if isinstance(d, list) else [])
    for s in studies:
        nstud+=1
        om = s.get('resultsSection', {}).get('outcomeMeasuresModule', {})
        for o in om.get('outcomeMeasures', []):
            nout+=1
            t = (o.get('typeUnitsAnalyzed') or '').strip().lower()
            u = (o.get('denomUnitsSelected') or '').strip().lower()
            units_in_denoms = sorted({(dd.get('units') or '').strip().lower() for dd in o.get('denoms', [])})
            key = ('type' if t else '-', 'sel' if u else '-', 'same' if (t and u and t == u) else ('diff' if t and u else ''))
            c[key] += 1
            if t and u and t != u and len(ex) < 5: ex.append((s['protocolSection']['identificationModule']['nctId'], t, u))
            if u and u != 'participants' and not t and len(ex)<10: ex.append(('selnotype', s['protocolSection']['identificationModule']['nctId'], u, units_in_denoms))
print(nstud, nout); print(c.most_common()); print(ex)
