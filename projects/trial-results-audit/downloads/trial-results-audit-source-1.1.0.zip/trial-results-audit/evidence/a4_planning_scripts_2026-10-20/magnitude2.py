import csv, gzip, json, sys, collections
base = sys.argv[1]; csv.field_size_limit(10**9)
olc = {}
with gzip.open(base + '/denominator_provenance.csv.gz', 'rt', newline='') as f:
    for r in csv.DictReader(f):
        lst = json.loads(r['outcome_level_denominators']) if r['outcome_level_denominators'] else []
        part = [d for d in lst if d.get('units','').strip().lower() == 'participants']
        if len(part) == 1 and part[0]['value'].isdigit():
            olc[(r['nct_id'], r['outcome_ordinal'], r['group_id'])] = int(part[0]['value'])
rows = []
with gzip.open(base + '/evidence_table.csv.gz', 'rt', newline='') as f:
    for r in csv.DictReader(f):
        if r['split']=='heldout' and r['cohort_status']=='confirmed': rows.append(r)
outs = collections.defaultdict(lambda: [False, r['outcome_type']])
prim_out_total = set(); prim_out_aff = set()
for r in rows:
    k=(r['nct_id'], r['outcome_ordinal'])
    if r['outcome_type']=='PRIMARY': prim_out_total.add(k)
    if r['rule_id']=='B1_ROW_SPECIFIC_DENOMINATOR':
        o = olc.get((r['nct_id'], r['outcome_ordinal'], r['group_id']))
        if o is not None and r['participant_denominator'].isdigit() and int(r['participant_denominator'])!=o and r['outcome_type']=='PRIMARY':
            prim_out_aff.add(k)
print('primary outcomes with values', len(prim_out_total), 'affected', len(prim_out_aff), round(100*len(prim_out_aff)/len(prim_out_total),1))
# two-arm risk ratio change for COUNT_OF_PARTICIPANTS rows
cells = collections.defaultdict(list)
for r in rows:
    if r['param_type']!='COUNT_OF_PARTICIPANTS' or r['rule_id']!='B1_ROW_SPECIFIC_DENOMINATOR': continue
    o = olc.get((r['nct_id'], r['outcome_ordinal'], r['group_id']))
    if o is None or not r['participant_denominator'].isdigit() or not r['value_text'].isdigit(): continue
    cells[(r['nct_id'], r['outcome_ordinal'], r['class_title'], r['category_title'])].append((r['group_id'], int(r['value_text']), int(r['participant_denominator']), o))
n=0; big=0; studies=set(); flips=0
for k, g in cells.items():
    g = sorted(g)
    if len(g) < 2: continue
    (ga, xa, na, oa), (gb, xb, nb, ob) = g[0], g[1]
    if min(na, nb, oa, ob) == 0 or xa == 0 or xb == 0: continue
    if na == oa and nb == ob: continue
    rr_row = (xa/na)/(xb/nb); rr_out = (xa/oa)/(xb/ob)
    n += 1
    ch = abs(rr_out/rr_row - 1)
    if ch >= 0.10: big += 1; studies.add(k[0])
    if (rr_row-1)*(rr_out-1) < 0: flips += 1
print('two-arm count rows with differing denominators', n, 'RR changed >=10%:', big, 'in studies', len(studies), 'direction flips', flips)
