"""Recount the numbers the revised abstract and text rely on, straight from the raw registry pages.

AI check written on 24 Oct 2026 by Claude Code running Claude Opus 5.5 (claude-opus-5-5).
It does not import or call any project code (src/tra, sql/, R/) and does not read the
warehouse or the CSV exports: it re-implements the written tier rules (docs/rules.md,
frozen) in plain Python over the cached API pages, so it is a different method from the
SQL views that produced the published tables.  Same agent that edits the manuscript,
so it is a re-computation, not an independent review.

Inputs (read only, workspace copy):
  data/raw/ctgov-20261007T093305Z/study_pages/batch_*.json   (raw API pages, hashes in source_manifest.json)
  data/frozen/ctgov-20261007T093305Z/manifest.csv            (split and cohort status)
Output: printed JSON (saved by the caller).
"""
import csv
import glob
import json
import os
import sys
from collections import Counter, defaultdict

ROOT = sys.argv[1]
RAW = os.path.join(ROOT, 'data/raw/ctgov-20261007T093305Z/study_pages')
MAN = os.path.join(ROOT, 'data/frozen/ctgov-20261007T093305Z/manifest.csv')

WS = ' \t\r\n'


def norm(u):
    if u is None:
        return ''
    s = u.strip(WS)
    return ''.join(chr(ord(c) + 32) if 'A' <= c <= 'Z' else c for c in s)


def usable(t):
    return isinstance(t, str) and t != '' and all('0' <= c <= '9' for c in t) and int(t) <= 2147483647


def counts_for(denoms, gid, unit):
    out = []
    for d in denoms or []:
        if norm(d.get('units')) != unit:
            continue
        for c in d.get('counts') or []:
            if c.get('groupId') == gid:
                out.append(c.get('value'))
    return out


def one_usable(vals):
    return int(vals[0]) if len(vals) == 1 and usable(vals[0]) else None


def classify(o, cls, gid):
    """Return (tier, rule, participant denominator) for one measurement."""
    if o.get('reportingStatus') != 'POSTED':
        return 'D', 'D_NOT_POSTED', None
    sel = o.get('denomUnitsSelected')
    u = norm(sel) if sel is not None and sel.strip(WS) != '' else 'participants'
    in_participants = u == 'participants'
    row_mode = any(len(c.get('denoms') or []) > 0 for c in (o.get('classes') or []))
    if row_mode:
        cds = cls.get('denoms') or []
        if not cds:
            return 'C', 'C4', None
        if not any(norm(d.get('units')) == 'participants' for d in cds):
            return 'C', 'C5', None
        vals = counts_for(cds, gid, 'participants')
        if not vals:
            return 'C', 'C1', None
        if len(vals) > 1:
            return 'C', 'C3', None
        if not usable(vals[0]):
            return 'C', 'C2', None
        if not in_participants and one_usable(counts_for(cds, gid, u)) is None:
            return 'C', 'C6', None
        return 'B', 'B1', int(vals[0])
    ods = o.get('denoms') or []
    vals = counts_for(ods, gid, 'participants')
    if not vals:
        return 'C', 'C1', None
    if len(vals) > 1:
        return 'C', 'C3', None
    if not usable(vals[0]):
        return 'C', 'C2', None
    if not in_participants and one_usable(counts_for(ods, gid, u)) is None:
        return 'C', 'C6', None
    if in_participants:
        return 'A', 'A', int(vals[0])
    return 'B', 'B2', int(vals[0])


def main():
    scope = set()
    with open(MAN, newline='') as f:
        for r in csv.DictReader(f):
            if r['split'] == 'heldout' and r['cohort_status'] == 'confirmed':
                scope.add(r['nct_id'])
    rank = {'D': 0, 'A': 1, 'B': 2, 'C': 3}
    n = Counter()
    group_tier = Counter()
    rule_meas = Counter()
    studies_with_values = set()
    studies_diff = set()
    outcomes_with_values = 0
    outcomes_diff = 0
    prim_meas = 0
    prim_diff = 0
    b1_groups = 0
    b1_groups_diff = 0
    top = Counter()
    flat_cats = Counter()
    seen = set()
    for fn in sorted(glob.glob(os.path.join(RAW, 'batch_*.json'))):
        for s in json.load(open(fn)).get('studies', []):
            nct = s['protocolSection']['identificationModule']['nctId']
            if nct not in scope or nct in seen:
                continue
            seen.add(nct)
            oms = (s.get('resultsSection') or {}).get('outcomeMeasuresModule', {}).get('outcomeMeasures', []) or []
            for o in oms:
                n['outcomes'] += 1
                gtier = {}
                gdiff = defaultdict(bool)
                gb1 = defaultdict(bool)
                o_has_meas = False
                o_diff = False
                is_primary = o.get('type') == 'PRIMARY'
                for cls in o.get('classes') or []:
                    for cat in cls.get('categories') or []:
                        for m in cat.get('measurements') or []:
                            gid = m.get('groupId')
                            tier, rule, pden = classify(o, cls, gid)
                            o_has_meas = True
                            if tier != 'D':
                                n['measurements'] += 1
                                rule_meas[rule] += 1
                                if is_primary:
                                    prim_meas += 1
                            prev = gtier.get(gid)
                            gtier[gid] = tier if prev is None or rank[tier] > rank[prev] else prev
                            if rule == 'B1':
                                gb1[gid] = True
                                # what a one-count-per-arm export attaches: the outcome-level participant count text
                                oc = counts_for(o.get('denoms') or [], gid, 'participants')
                                if len(oc) == 1 and usable(oc[0]):
                                    if int(oc[0]) != pden:
                                        flat_cats['B1 outcome-level count attached, row count differs'] += 1
                                        gdiff[gid] = True
                                        o_diff = True
                                        top[nct] += 1
                                        if is_primary:
                                            prim_diff += 1
                                    else:
                                        flat_cats['B1 outcome-level count attached, row count equal'] += 1
                                else:
                                    flat_cats['B1 no single usable outcome-level count'] += 1
                if o.get('reportingStatus') == 'POSTED' and o_has_meas:
                    outcomes_with_values += 1
                    studies_with_values.add(nct)
                    if o_diff:
                        outcomes_diff += 1
                        studies_diff.add(nct)
                for g in o.get('groups') or []:
                    gid = g.get('id')
                    if o.get('reportingStatus') != 'POSTED' or gid not in gtier:
                        group_tier['D'] += 1
                        continue
                    group_tier[gtier[gid]] += 1
                    if gb1[gid]:
                        b1_groups += 1
                        if gdiff[gid]:
                            b1_groups_diff += 1
    applicable = group_tier['A'] + group_tier['B'] + group_tier['C']
    top10 = sum(v for _, v in top.most_common(10))
    res = {
        'studies_in_scope': len(seen),
        'outcome_measures': n['outcomes'],
        'outcomes_posted_with_values': outcomes_with_values,
        'applicable_outcome_groups': applicable,
        'group_tiers': dict(group_tier),
        'resolvable_groups_A_or_B': group_tier['A'] + group_tier['B'],
        'resolvable_pct': round(100 * (group_tier['A'] + group_tier['B']) / applicable, 2),
        'tier_B_pct': round(100 * group_tier['B'] / applicable, 1),
        'measurements_tier_A_B_C': n['measurements'],
        'measurement_rules': dict(rule_meas),
        'flat_categories_for_B1': dict(flat_cats),
        'row_count_differs_measurements': flat_cats['B1 outcome-level count attached, row count differs'],
        'row_count_differs_pct_of_measurements': round(100 * flat_cats['B1 outcome-level count attached, row count differs'] / n['measurements'], 1),
        'studies_with_values': len(studies_with_values),
        'studies_with_a_differing_row': len(studies_diff),
        'outcomes_with_a_differing_row': outcomes_diff,
        'primary_outcome_measurements': prim_meas,
        'primary_outcome_measurements_differing': prim_diff,
        'primary_differing_pct': round(100 * prim_diff / prim_meas, 1),
        'top10_studies_measurements': top10,
        'top_study': top.most_common(1),
        'b1_groups': b1_groups,
        'b1_groups_with_a_differing_row': b1_groups_diff,
    }
    print(json.dumps(res, indent=1))


if __name__ == '__main__':
    main()
