## 4. Arm-differential consequence analysis (no account needed; runs offline)

**Question.** When an automated pipeline replaces a row's own number analyzed with the outcome-level count, how much does a two-arm comparison change? A per-value rescaling is a fixed function of the ratio of the two counts, so the analysis concentrates on comparisons between arms, where the effect depends on whether the ratio differs between the arms.

**Who is affected, stated in advance.** A person reading the registry's web table sees the row's count. The harm falls on automated pipelines that keep one count per arm and outcome.

### 4.1 Unit and eligibility

- **Comparison cell:** one study, one outcome, one row (class) and one category, in an outcome with exactly two outcome groups. The group with the lower `group_id` is arm 1.
- **Affected cell:** at least one of its two measurements is B1 and its row-level count differs from that group's outcome-level participant count.
- **Excluded, each reported with its count:** outcomes with three or more groups; tier C or D measurements; outcomes analyzed in another unit; values that are not plain numbers; a missing outcome-level participant count for either group.

### 4.2 Count-of-participants outcomes (primary)

1. Eligible: parameter type COUNT_OF_PARTICIPANTS and both values integers x with 0 ≤ x ≤ row-level n.
2. Cells where x exceeds the outcome-level n in either arm cannot form a proportion under the export. They are counted and reported as a consequence of their own, and excluded from the interval calculations.
3. Under each denominator (row-level n, the reference; outcome-level n, the export), compute the risk in each arm, the risk difference (arm 2 minus arm 1) with a 95% Newcombe hybrid score interval (Wilson intervals per arm, no continuity correction), and the risk ratio with a 95% log interval when both counts are above 0.
4. Metrics: the absolute change in the risk difference in percentage points (median, interquartile range, and the shares above 1 and above 5 points); the share of affected cells whose risk-difference interval changes its relation to 0 (excludes 0 under one denominator and not the other), in each direction; the share whose risk ratio changes by 10% or more; and the share whose ratio of row-level to outcome-level n differs between the two arms by more than 5%.
5. Zero counts: the risk-difference interval needs no correction. For the risk ratio, cells with a zero count are left out of the primary figures; a sensitivity analysis adds 0.5 to all four cells of each such comparison.

### 4.3 Mean-type outcomes (secondary)

1. Eligible: parameter type MEAN or LEAST_SQUARES_MEAN, dispersion "Standard Deviation" or "Standard Error", all values plain numbers.
2. Dispersion given as a standard deviation: take SE = SD/√n under each n; report the mean difference with a normal 95% interval, the share whose interval changes its relation to 0, and the ratio of inverse-variance weights.
3. Dispersion given as a standard error: the interval does not depend on n. Report, in one line, how the standard deviation derived as SE·√n changes, since that value feeds standardized mean differences.

### 4.4 Per-value summary (one line)

The distribution of row-level n divided by outcome-level n among the 22,505 measurements: median, interquartile range, and the shares below 0.5 and above 1.

### 4.5 Study level, subsets and sensitivity

- Studies with at least one affected count-of-participants cell whose interval changes its relation to 0.
- Primary outcomes reported separately.
- An exploratory whole-trial bootstrap (2,000 replicates, seed 20261024) gives a percentile range for the main share in 4.2; it is not a confidence interval for any population.
- Repeat without NCT02443155, and without the ten studies contributing most.

### 4.6 How the result will be described (fixed now)

The consequence is called **material** if either of these holds; otherwise it is called **small** and reported as a bound on the harm:
- at least 5% of affected count-of-participants cells change the relation of their risk-difference interval to 0;
- the median absolute change in the risk difference is at least 1 percentage point.

Both outcomes are reported, whichever occurs.

### 4.7 Code, outputs and checking

- A new module, `src/tra/a4_consequence.py`, reading only the pinned inputs. Tables go to `results/tables/heldout_posthoc_A4/consequence/`, and every table and sentence that uses them is labelled "post hoc (amendment 4)".
- A separate AI agent recomputes the headline numbers of 4.2 and 4.3 with separately written code and a different route (from the raw registry pages, or in R or SQL instead of the Python module). The result goes to `deep/S2/validation/ai_check_consequence_<UTC date>.json` with the model, date, inputs, outputs and agreement, and is described as an AI-agent recomputation. Animesh Bose reviews any disagreement.

