#!/usr/bin/env Rscript
# Independent recomputation of the amendment 4 arm-differential consequence analysis.
# Reads the raw registry batch pages. Usage: Rscript recount.R <repo_root> <output_json_path>
suppressPackageStartupMessages(library(jsonlite))
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2) stop("usage: Rscript recount.R <repo_root> <output_json_path>")
root <- args[1]; out_path <- args[2]
snap <- "ctgov-20261007T093305Z"
Z <- 1.959963984540054
say <- function(...) message(sprintf(...))

## ---------- helpers ----------
g <- function(x) if (is.null(x) || length(x) == 0) NA_character_ else as.character(x[[1]])
normu <- function(x) {                      # unit normalisation: trim space/tab/CR/LF, ASCII lower-case
  if (is.na(x)) return("")
  x <- gsub("^[ \t\r\n]+|[ \t\r\n]+$", "", x)
  chartr("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz", x)
}
usable <- function(v) !is.na(v) & grepl("^[0-9]+$", v) &
  suppressWarnings(as.numeric(v)) <= 2147483647
plain <- function(v) !is.na(v) & grepl("^-?[0-9]+(\\.[0-9]+)?$", trimws(v))
qs <- function(x) {
  x <- x[!is.na(x)]
  if (!length(x)) return(list(q25 = NA, median = NA, q75 = NA, n = 0L))
  q <- quantile(x, c(.25, .5, .75), names = FALSE, type = 7)
  list(q25 = q[1], median = q[2], q75 = q[3], n = length(x))
}
eqg <- function(a, b) !is.na(a) & !is.na(b) & a == b

# flatten a denoms list into parallel vectors (normalised units, groupId, value)
flat <- function(dl) {
  u <- character(0); gg <- character(0); v <- character(0)
  for (d in dl) {
    un <- normu(g(d$units))
    for (cc in d$counts) { u <- c(u, un); gg <- c(gg, g(cc$groupId)); v <- c(v, g(cc$value)) }
  }
  list(u = u, g = gg, v = v)
}
# n_out: smallest usable outcome-level participant count for the group
nout_of <- function(fl, gid) {
  i <- which(fl$u == "participants" & eqg(fl$g, gid))
  v <- fl$v[i]; v <- v[usable(v)]
  if (!length(v)) NA_real_ else min(as.numeric(v))
}
# shared checks C1, C3, C2, C6; returns tier "OK" with participant count if passed
core <- function(fl, gid, U) {
  i <- which(fl$u == "participants" & eqg(fl$g, gid))
  if (!length(i)) return(list("C", "C1", NA_real_))
  if (length(i) > 1) return(list("C", "C3", NA_real_))
  if (!usable(fl$v[i])) return(list("C", "C2", NA_real_))
  if (U != "participants") {
    j <- which(fl$u == U & eqg(fl$g, gid))
    if (length(j) != 1 || !usable(fl$v[j])) return(list("C", "C6", NA_real_))
  }
  list("OK", "", as.numeric(fl$v[i]))
}
row_tier <- function(cfl, gid, U) {
  if (is.null(cfl)) return(list("C", "C4", NA_real_))
  if (!any(cfl$u == "participants")) return(list("C", "C5", NA_real_))
  r <- core(cfl, gid, U)
  if (r[[1]] == "OK") list("B1", "B1_ROW_SPECIFIC_DENOMINATOR", r[[3]]) else r
}
out_tier <- function(ofl, gid, U) {
  r <- core(ofl, gid, U)
  if (r[[1]] != "OK") return(r)
  if (U == "participants") list("A", "A_OUTCOME_LEVEL", r[[3]])
  else list("B2", "B2_NON_PARTICIPANT_UNITS", r[[3]])
}

## ---------- per-outcome processing: one record per measurement ----------
proc_outcome <- function(nct, ord, om) {
  posted <- identical(g(om$reportingStatus), "POSTED")
  us <- normu(g(om$denomUnitsSelected)); U <- if (us == "") "participants" else us
  gids <- vapply(om$groups, function(x) g(x$id), "")
  ofl <- flat(om$denoms)
  classes <- om$classes
  rowmode <- any(vapply(classes, function(cl) !is.null(cl$denoms), NA))
  ci_ <- integer(0); ki_ <- integer(0); gid_ <- character(0); tier_ <- character(0)
  sub_ <- character(0); nrow_ <- numeric(0); nout_ <- numeric(0); val_ <- character(0); spr_ <- character(0)
  for (ci in seq_along(classes)) {
    cl <- classes[[ci]]
    cfl <- if (!is.null(cl$denoms)) flat(cl$denoms) else NULL
    for (ki in seq_along(cl$categories)) {
      for (ms in cl$categories[[ki]]$measurements) {
        gg <- g(ms$groupId)
        r <- if (!posted) list("D", "D", NA_real_)
             else if (rowmode) row_tier(cfl, gg, U) else out_tier(ofl, gg, U)
        ci_ <- c(ci_, ci - 1L); ki_ <- c(ki_, ki - 1L); gid_ <- c(gid_, gg)
        tier_ <- c(tier_, r[[1]]); sub_ <- c(sub_, r[[2]]); nrow_ <- c(nrow_, r[[3]])
        nout_ <- c(nout_, nout_of(ofl, gg)); val_ <- c(val_, g(ms$value)); spr_ <- c(spr_, g(ms$spread))
      }
    }
  }
  n <- length(gid_); if (!n) return(NULL)
  sg <- sort(gids, method = "radix")
  list(nct = rep(nct, n), ord = rep(as.integer(ord), n), cls = ci_, cat = ki_, gid = gid_,
       tier = tier_, sub = sub_, nrow = nrow_, nout = nout_, value = val_, spread = spr_,
       posted = rep(posted, n), type = rep(g(om$type), n), param = rep(g(om$paramType), n),
       disp = rep(g(om$dispersionType), n), Upart = rep(U == "participants", n),
       ngroups = rep(length(gids), n),
       g1 = rep(if (length(gids) == 2) sg[1] else NA_character_, n),
       g2 = rep(if (length(gids) == 2) sg[2] else NA_character_, n))
}

## ---------- read manifest and raw batches ----------
man <- read.csv(file.path(root, "data", "frozen", snap, "manifest.csv"),
                stringsAsFactors = FALSE, colClasses = "character")
man <- man[man$split == "heldout" & man$cohort_status == "confirmed", ]
man <- man[!duplicated(man$nct_id), ]
say("manifest: %d heldout confirmed studies", nrow(man))
raw_dir <- file.path(root, "data", "raw", snap)
recs <- list(); ri <- 0L; found <- 0L
for (bf in unique(man$batch_file)) {
  want <- man$nct_id[man$batch_file == bf]
  st <- fromJSON(file.path(raw_dir, bf), simplifyVector = FALSE)$studies
  ids <- vapply(st, function(s) g(s$protocolSection$identificationModule$nctId), "")
  for (id in want) {
    k <- match(id, ids)                       # first copy within the named batch file
    if (is.na(k)) { say("WARNING: %s not found in %s", id, bf); next }
    found <- found + 1L
    oms <- st[[k]]$resultsSection$outcomeMeasuresModule$outcomeMeasures
    for (oi in seq_along(oms)) {
      r <- proc_outcome(id, oi - 1L, oms[[oi]])
      if (!is.null(r)) { ri <- ri + 1L; recs[[ri]] <- r }
    }
  }
  say("read %s (%d wanted), studies found so far %d", bf, length(want), found)
  rm(st); invisible(gc(verbose = FALSE))
}
cols <- names(recs[[1]])
M <- as.data.frame(setNames(lapply(cols, function(cn) unlist(lapply(recs, `[[`, cn), use.names = FALSE)), cols),
                   stringsAsFactors = FALSE)
rm(recs)
M$differ <- M$tier == "B1" & (is.na(M$nout) | M$nrow != M$nout)
say("measurements parsed: %d", nrow(M))

## ---------- sanity ----------
dcount <- table(M$nct[M$differ])
dsort <- data.frame(nct = names(dcount), n = as.integer(dcount), stringsAsFactors = FALSE)
dsort <- dsort[order(-dsort$n, dsort$nct, method = "radix"), ]
top10 <- head(dsort$nct, 10)
sanity <- list(measurements_total = sum(M$posted & M$tier %in% c("A", "B1", "B2", "C")),
               measurements_differ = sum(M$differ), studies_differ = nrow(dsort),
               top10_differ = sum(head(dsort$n, 10)),
               top_study_n = if ("NCT02443155" %in% dsort$nct) dsort$n[dsort$nct == "NCT02443155"] else 0L,
               top10_studies = top10, studies_found = found)
say("sanity: total %d, differ %d, studies %d", sanity$measurements_total, sanity$measurements_differ, sanity$studies_differ)

## ---------- per-value summary ----------
pv <- M[M$differ & !is.na(M$nout) & M$nout > 0, ]
rat <- pv$nrow / pv$nout
per_value <- c(qs(rat), list(n_below_0.5 = sum(rat < 0.5), n_above_1 = sum(rat > 1)))

## ---------- affected cells and classification ----------
M$key <- paste(M$nct, M$ord, M$cls, M$cat, sep = "|")
akeys <- unique(M$key[M$differ])
MA <- M[M$key %in% akeys, ]
sp <- split(seq_len(nrow(MA)), MA$key)
cls_names <- c("a_one_group", "b_three_plus_groups", "c_not_one_measurement_per_group",
               "d_tier_C_or_D", "e_B2_or_non_participant_units", "f_n_out_missing",
               "g_value_not_plain_number", "h_cop_invalid_or_exceeds_n_row", "i_cop_zero_denominator",
               "j_cop_exceeds_n_out_no_proportion", "k_cop_analysed", "mean_excluded",
               "mean_sd_analysed", "mean_se_analysed", "other_type")
cell_n <- setNames(integer(length(cls_names)), cls_names); cell_d <- cell_n
cop_l <- list(); j_l <- list(); sd_l <- list(); se_l <- list()
for (key in names(sp)) {
  m <- MA[sp[[key]], ]; o <- m[1, ]; nd <- sum(m$differ)
  cl <- local({
    if (o$ngroups == 1) return("a_one_group")
    if (o$ngroups >= 3) return("b_three_plus_groups")
    if (o$ngroups != 2 || nrow(m) != 2 || anyNA(m$gid) ||
        !identical(sort(m$gid, method = "radix"), c(o$g1, o$g2))) return("c_not_one_measurement_per_group")
    if (any(m$tier %in% c("C", "D"))) return("d_tier_C_or_D")
    if (any(m$tier == "B2") || !o$Upart) return("e_B2_or_non_participant_units")
    if (anyNA(m$nout)) return("f_n_out_missing")
    if (!all(plain(m$value))) return("g_value_not_plain_number")
    a1 <- m[m$gid == o$g1, ]; a2 <- m[m$gid == o$g2, ]
    v1 <- as.numeric(trimws(a1$value)); v2 <- as.numeric(trimws(a2$value))
    rec <- c(nr1 = a1$nrow, nr2 = a2$nrow, no1 = a1$nout, no2 = a2$nout)
    pt <- o$param; ds <- o$disp
    if (identical(pt, "COUNT_OF_PARTICIPANTS")) {
      if (v1 < 0 || v2 < 0 || v1 %% 1 != 0 || v2 %% 1 != 0 || v1 > a1$nrow || v2 > a2$nrow)
        return("h_cop_invalid_or_exceeds_n_row")
      if (any(rec == 0)) return("i_cop_zero_denominator")
      row <- data.frame(study = o$nct, primary = identical(o$type, "PRIMARY"), x1 = v1, x2 = v2,
                        t(rec), stringsAsFactors = FALSE)
      if (v1 > a1$nout || v2 > a2$nout) { j_l[[length(j_l) + 1]] <<- row; return("j_cop_exceeds_n_out_no_proportion") }
      cop_l[[length(cop_l) + 1]] <<- row; return("k_cop_analysed")
    }
    if (pt %in% c("MEAN", "LEAST_SQUARES_MEAN") && !is.na(ds) &&
        ds %in% c("Standard Deviation", "Standard Error")) {
      if (!all(plain(m$spread)) || any(rec == 0)) return("mean_excluded")
      row <- data.frame(study = o$nct, m1 = v1, m2 = v2, s1 = as.numeric(trimws(a1$spread)),
                        s2 = as.numeric(trimws(a2$spread)), t(rec), stringsAsFactors = FALSE)
      if (ds == "Standard Deviation") { sd_l[[length(sd_l) + 1]] <<- row; return("mean_sd_analysed") }
      se_l[[length(se_l) + 1]] <<- row; return("mean_se_analysed")
    }
    "other_type"
  })
  cell_n[cl] <- cell_n[cl] + 1L; cell_d[cl] <- cell_d[cl] + nd
}
say("affected cells: %d", length(sp))
bind <- function(l, proto) if (length(l)) do.call(rbind, l) else proto
cop_proto <- data.frame(study = character(0), primary = logical(0), x1 = numeric(0), x2 = numeric(0),
                        nr1 = numeric(0), nr2 = numeric(0), no1 = numeric(0), no2 = numeric(0))
COP <- bind(cop_l, cop_proto); JC <- bind(j_l, cop_proto)
mean_proto <- data.frame(study = character(0), m1 = numeric(0), m2 = numeric(0), s1 = numeric(0),
                         s2 = numeric(0), nr1 = numeric(0), nr2 = numeric(0), no1 = numeric(0), no2 = numeric(0))
SD <- bind(sd_l, mean_proto); SE <- bind(se_l, mean_proto)

## ---------- count-of-participants metrics ----------
wilson <- function(x, n) { den <- n + Z^2; c0 <- (x + Z^2 / 2) / den
  h <- Z * sqrt(x * (n - x) / n + Z^2 / 4) / den; list(l = c0 - h, u = c0 + h) }
newc <- function(x1, n1, x2, n2) {          # Newcombe hybrid score (method 10)
  p1 <- x1 / n1; p2 <- x2 / n2; w1 <- wilson(x1, n1); w2 <- wilson(x2, n2); d <- p2 - p1
  list(d = d, lo = d - sqrt((p2 - w2$l)^2 + (w1$u - p1)^2), hi = d + sqrt((w2$u - p2)^2 + (p1 - w1$l)^2))
}
state <- function(lo, hi) ifelse(hi < 0, -1, ifelse(lo > 0, 1, 0))
cop_change <- function(d) {                 # per-cell indicator of interval relation change
  r <- newc(d$x1, d$nr1, d$x2, d$nr2); e <- newc(d$x1, d$no1, d$x2, d$no2)
  state(r$lo, r$hi) != state(e$lo, e$hi)
}
cop_stats <- function(d, jd) {
  n <- nrow(d)
  res <- list(cells = n, studies = length(unique(d$study)), no_proportion_cells = nrow(jd))
  if (!n) return(res)
  r <- newc(d$x1, d$nr1, d$x2, d$nr2); e <- newc(d$x1, d$no1, d$x2, d$no2)
  sr <- state(r$lo, r$hi); se_ <- state(e$lo, e$hi); ch <- sr != se_
  dpp <- abs(e$d - r$d) * 100
  bp <- d$x1 > 0 & d$x2 > 0
  rr_r <- (d$x2 / d$nr2) / (d$x1 / d$nr1); rr_e <- (d$x2 / d$no2) / (d$x1 / d$no1)
  zc <- !bp
  rs_r <- ((d$x2 + .5) / (d$nr2 + 1)) / ((d$x1 + .5) / (d$nr1 + 1))
  rs_e <- ((d$x2 + .5) / (d$no2 + 1)) / ((d$x1 + .5) / (d$no1 + 1))
  dr <- abs((d$nr2 / d$no2) / (d$nr1 / d$no1) - 1)
  c(res, list(
    rd_abs_change_pp = qs(dpp), n_rd_change_above_1pp = sum(dpp > 1), n_rd_change_above_5pp = sum(dpp > 5),
    interval_change_total = sum(ch), interval_change_share = sum(ch) / n,
    ref_excludes_export_contains = sum(sr != 0 & se_ == 0),
    ref_contains_export_excludes = sum(sr == 0 & se_ != 0),
    excludes_opposite_sides = sum(sr != 0 & se_ != 0 & sr != se_),
    studies_with_interval_change = length(unique(d$study[ch])),
    rr_cells_both_counts_positive = sum(bp),
    rr_change_ge_10pct = sum(abs(rr_e[bp] / rr_r[bp] - 1) >= 0.10),
    zero_count_cells = sum(zc),
    rr_sensitivity_change_ge_10pct = sum(abs(rs_e[zc] / rs_r[zc] - 1) >= 0.10),
    denom_ratio_differs_gt_5pct = sum(dr > 0.05)))
}
cop_all <- cop_stats(COP, JC)
cop_primary <- cop_stats(COP[COP$primary, ], JC[JC$primary, ])
cop_wo1 <- cop_stats(COP[COP$study != "NCT02443155", ], JC[JC$study != "NCT02443155", ])
cop_wo10 <- cop_stats(COP[!COP$study %in% top10, ], JC[!JC$study %in% top10, ])
say("COP analysed cells: %d", nrow(COP))

## ---------- bootstrap over studies ----------
bootstrap <- list(replicates = 2000L, seed = 20261024L, p2.5 = NA, p97.5 = NA)
if (nrow(COP)) {
  chg <- cop_change(COP)
  st_ids <- sort(unique(COP$study), method = "radix")
  nch <- as.numeric(tapply(chg, factor(COP$study, levels = st_ids), sum))
  ncl <- as.numeric(table(factor(COP$study, levels = st_ids)))
  set.seed(20261024)
  bs <- vapply(1:2000, function(b) { i <- sample.int(length(st_ids), replace = TRUE)
    sum(nch[i]) / sum(ncl[i]) }, 0)
  q <- quantile(bs, c(.025, .975), names = FALSE, type = 7)
  bootstrap$p2.5 <- q[1]; bootstrap$p97.5 <- q[2]; bootstrap$studies <- length(st_ids)
  bootstrap$point_share <- sum(chg) / length(chg)
}

## ---------- mean-type, SD ----------
mean_sd <- list(cells = nrow(SD), studies = length(unique(SD$study)))
if (nrow(SD)) {
  d <- SD$m2 - SD$m1
  ser <- sqrt((SD$s1 / sqrt(SD$nr1))^2 + (SD$s2 / sqrt(SD$nr2))^2)
  see <- sqrt((SD$s1 / sqrt(SD$no1))^2 + (SD$s2 / sqrt(SD$no2))^2)
  sr <- state(d - Z * ser, d + Z * ser); s_e <- state(d - Z * see, d + Z * see)
  ok <- ser != 0 & see != 0
  wr <- (1 / see[ok]^2) / (1 / ser[ok]^2)
  mean_sd <- c(mean_sd, list(interval_change = sum(sr != s_e),
                             weight_ratio_export_over_reference = qs(wr),
                             weight_ratio_cells = length(wr),
                             weight_ratio_off_by_more_than_10pct = sum(abs(wr - 1) > 0.10)))
}
## ---------- mean-type, SE ----------
mean_se <- list(cells = nrow(SE), studies = length(unique(SE$study)))
if (nrow(SE)) {
  f <- c(sqrt(SE$no1 / SE$nr1), sqrt(SE$no2 / SE$nr2))
  mean_se <- c(mean_se, list(sd_factor_sqrt_nout_over_nrow = qs(f)))
}

## ---------- output ----------
out <- list(sanity = sanity,
            cell_classes = list(cells = as.list(cell_n), differing_measurements = as.list(cell_d),
                                total_cells = length(sp)),
            per_value = per_value, cop_all = cop_all, cop_primary = cop_primary,
            cop_without_NCT02443155 = cop_wo1, cop_without_top10 = cop_wo10,
            bootstrap = bootstrap, mean_sd = mean_sd, mean_se = mean_se)
write_json(out, out_path, auto_unbox = TRUE, digits = NA, pretty = TRUE)
say("wrote %s", out_path)
