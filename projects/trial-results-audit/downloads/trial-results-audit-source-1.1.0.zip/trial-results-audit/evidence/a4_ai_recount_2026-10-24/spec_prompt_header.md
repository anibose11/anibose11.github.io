You are writing verification code for a registry methods study. Another program has already computed the analysis described below; your script is an independent recomputation, so do not try to guess what that program did. Work only from this specification.

Write ONE self-contained R script (base R plus the jsonlite package only; no other packages, no network access, no writing outside the output path). It is run as:

    Rscript recount.R <repo_root> <output_json_path>

It must read the RAW registry pages directly (not any derived export) and print nothing but progress lines to stderr. Return only the R code in a single ```r fenced block, with brief comments. Keep it under about 450 lines.

## Inputs

1. `<repo_root>/data/frozen/ctgov-20261007T093305Z/manifest.csv`: one row per study. Columns used: `nct_id`, `batch_file` (path relative to `<repo_root>/data/raw/ctgov-20261007T093305Z/`, e.g. `study_pages/batch_0000.json`), `split`, `cohort_status`. Analyse only studies with `split == "heldout"` and `cohort_status == "confirmed"` (1,961 studies), and take each study's record only from the batch file named in its row (a study can appear in more than one batch file; ignore other copies).
2. The batch files: JSON objects `{"studies": [ ... ]}` (27 files, about 157 MB in all). Read each with `jsonlite::fromJSON(path, simplifyVector = FALSE)` so the nesting stays as lists. For each study:
   - NCT ID: `protocolSection$identificationModule$nctId`
   - outcomes: `resultsSection$outcomeMeasuresModule$outcomeMeasures` (a list; may be absent). The 0-based position in this list is the outcome ordinal.
   - each outcome has: `type` ("PRIMARY", "SECONDARY", "OTHER_PRE_SPECIFIED", ...), `reportingStatus` ("POSTED" or other), `paramType` (e.g. "COUNT_OF_PARTICIPANTS", "MEAN", "LEAST_SQUARES_MEAN", "NUMBER", ...), `dispersionType` (e.g. "Standard Deviation", "Standard Error", "95% Confidence Interval"; may be absent), `denomUnitsSelected` (may be absent), `groups` (list of `{id, title}`), `denoms` (outcome-level: list of `{units, counts: [{groupId, value}]}`), `classes` (list of `{title?, denoms?, categories: [{title?, measurements: [{groupId, value, spread?, lowerLimit?, upperLimit?}]}]}`). All values are strings.

## Tier rules (frozen; apply exactly)

Unit names are compared after trimming spaces, tabs, CR and LF at both ends and folding ASCII A-Z to lower case. Blank means empty after trimming. Analysis unit U of an outcome: `denomUnitsSelected` when present and non-blank, otherwise "participants". A count covers a group when its `groupId` equals the group id. A count is usable when its text consists only of ASCII digits 0-9 (value at most 2147483647). An outcome is in row-specific mode when ANY of its classes has a `denoms` list (present, even if empty).

Tier of one measurement, first matching line decides:
0. reportingStatus is not POSTED -> D.
Row-specific mode:
1. the measurement's class has no `denoms` list -> C (C4)
2. the class has no denominator entry whose units are "participants" -> C (C5)
3. no participant-unit row count covers the group -> C (C1)
4. more than one participant-unit row count covers the group -> C (C3)
5. the covering count is not usable -> C (C2)
6. U is not participants and the row has no single usable count in units U for the group -> C (C6)
7. otherwise -> B1 (B1_ROW_SPECIFIC_DENOMINATOR); its participant denominator is that row count.
Otherwise (no class in the outcome has denoms):
1. no outcome-level participant-unit count covers the group -> C1
2. more than one covers the group -> C3
3. the covering count is not usable -> C2
4. U is not participants and the outcome has no single usable count in units U for the group -> C6
5. U is participants -> A (A_OUTCOME_LEVEL); participant denominator = the outcome-level participant count.
6. U is another unit -> B2 (B2_NON_PARTICIPANT_UNITS); participant denominator = outcome-level participant count.

## Operational definitions (fixed; use them exactly)

- Outcome-level participant count of a group (call it n_out): the smallest integer value among the outcome-level `denoms` entries whose units are "participants" (after normalisation) and whose count for that group is usable. Missing if none.
- Row-level count of a measurement (call it n_row): its participant denominator under the tier rules (for B1 the row count; for A and B2 the outcome-level count).
- A measurement DIFFERS when its tier is B1 and n_row is not equal to n_out (a missing n_out also counts as differing). Sanity targets that your script must report: 97,756 measurements in total across tiers A, B1, B2 and C in POSTED outcomes; 22,505 differing measurements; 385 studies with at least one; the ten studies with most differing measurements hold 8,450 of them; NCT02443155 holds 3,009.
- Comparison cell: one study, one outcome ordinal, one class index and one category index (0-based positions in the JSON lists). Number of outcome groups = length of the outcome's `groups` list.
- A cell is AFFECTED when at least one of its measurements differs. Every count below is over affected cells.
- Classification of affected cells, in this order (report the number of cells and the number of differing measurements in each class):
  a. outcome has 1 group; b. outcome has 3 or more groups; c. 2 groups but the cell does not have exactly one measurement for each of the two groups; d. any measurement in the cell is tier C or D; e. any measurement is B2 or the outcome's U is not participants; f. n_out missing for either group; g. a measurement value (`value`) is not a plain number (regex `^-?[0-9]+(\.[0-9]+)?$` after trimming); then by paramType:
  COUNT_OF_PARTICIPANTS: h. a value is not a non-negative integer, or a value exceeds its n_row -> excluded; i. any of n_row1, n_row2, n_out1, n_out2 is 0 -> excluded; j. a value exceeds its n_out -> counted separately ("no proportion under the export"); k. otherwise ANALYSED.
  MEAN or LEAST_SQUARES_MEAN with dispersionType exactly "Standard Deviation" or "Standard Error" (both arms the same paramType and dispersionType; otherwise excluded): spread not a plain number in either arm, or any denominator 0 -> excluded; otherwise ANALYSED (separately for SD and SE).
  anything else -> "other type".
- Arm 1 is the group whose id sorts first as a string (OG000 before OG001); arm 2 the other. The reference uses n_row for each arm; the export uses n_out for each arm.
- Count-of-participants metrics: risk p = x/n per arm; risk difference = p2 - p1; 95% Newcombe hybrid score interval (method 10: Wilson score interval for each arm without continuity correction, z = 1.959963984540054). Relation of an interval to 0 has three states: wholly below 0 (upper < 0), wholly above 0 (lower > 0), otherwise contains 0. A change is any move between states. Report: number of analysed cells and studies; median and quartiles (type 7, i.e. R's default quantile) of |RD_export - RD_reference| in percentage points; counts above 1 and above 5 points; number of cells whose interval changes relation to 0, split into (reference excludes 0, export contains 0), (reference contains 0, export excludes 0) and (excludes 0 on opposite sides); number of studies with at least one such cell. Risk ratio RR = p2/p1 computed only when x1 > 0 and x2 > 0; "changes by 10% or more" means |RR_export/RR_reference - 1| >= 0.10; report the count and the number of cells with both counts above 0. For cells with a zero count, a sensitivity analysis adds 0.5 to each count and 1 to each denominator (x+0.5, n+1) and reports the same 10% count. Also report how many cells have |(n_row2/n_out2)/(n_row1/n_out1) - 1| > 0.05.
- Repeat the count-of-participants metrics for (i) cells in PRIMARY outcomes only, (ii) all cells except study NCT02443155, (iii) all cells except the ten studies with most differing measurements (ties broken by NCT ID ascending).
- Bootstrap: resample whole studies with replacement from the studies that have analysed count-of-participants cells, 2,000 replicates, set.seed(20261024); for each replicate compute (cells whose interval changes relation)/(cells); report the 2.5th and 97.5th percentiles (quantile type 7). Exact agreement with another implementation is not expected for this item.
- Mean-type, Standard Deviation: SE_arm = SD/sqrt(n) under each denominator; mean difference d = m2 - m1; SE_d = sqrt(SE1^2 + SE2^2); normal 95% interval d +/- z*SE_d. Report analysed cells, studies, number whose interval changes relation to 0, and the median and quartiles of the inverse-variance weight ratio (1/SE_d,export^2) / (1/SE_d,reference^2), skipping cells where SE_d is 0, plus the number of cells with that ratio more than 10% away from 1.
- Mean-type, Standard Error: report analysed cells and the median and quartiles, over arm values (two per cell), of sqrt(n_out/n_row) (the factor by which an SD derived as SE*sqrt(n) changes).
- Per-value summary over all differing measurements with n_out present and > 0: median and quartiles of n_row/n_out, and the counts below 0.5 and above 1.

## Output

Write one JSON object (jsonlite::write_json with auto_unbox = TRUE, digits = NA, pretty = TRUE) with keys: `sanity` (measurements_total, measurements_differ, studies_differ, top10_differ, top_study_n), `cell_classes` (named counts of cells and of differing measurements), `per_value`, `cop_all`, `cop_primary`, `cop_without_NCT02443155`, `cop_without_top10`, `bootstrap`, `mean_sd`, `mean_se`. Use plain numbers (no rounding).

The specification below (amendment 4, section 4, of the study's records) is the design these definitions implement. Where it and the operational definitions above differ in detail, follow the operational definitions.

