"""Compare the amendment 4 consequence analysis (project module) with the separately written R recount.

Inputs: the module's consequence_run.json and recount_output_2026-10-24.json. Writes
../ai_check_consequence_2026-10-24.json. Usage: python3 -I -B compare.py <repo root>
"""
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1])
MOD = ROOT / "results/tables/heldout_posthoc_A4/consequence/consequence_run.json"
REC = HERE / "recount_output_2026-10-24.json"
a = json.loads(MOD.read_text())
b = json.loads(REC.read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows = []


def cmp(name, x, y, tol=1e-9):
    ok = (x is None and y is None) or (x is not None and y is not None and abs(float(x) - float(y)) <= tol * max(1, abs(float(x))))
    rows.append({"item": name, "module": x, "recount": y, "agree": bool(ok)})


r = a["reproduction_of_published_counts"]
s = b["sanity"]
cmp("measurements total", r["measurements_total"], s["measurements_total"])
cmp("differing measurements", r["measurements_differ"], s["measurements_differ"])
cmp("studies with a differing measurement", r["studies_differ"], s["studies_differ"])
cmp("differing measurements in top ten studies", r["top10_measurements"], s["top10_differ"])
cmp("NCT02443155 differing measurements", r["top_study"][1], s["top_study_n"])
rows.append({"item": "top ten study list", "module": a["top10_studies"], "recount": s["top10_studies"],
             "agree": a["top10_studies"] == s["top10_studies"]})

pv, qv = a["per_value_4_4"], b["per_value"]
cmp("per value: ratio median", pv["ratio_row_to_outcome_n"]["median"], qv["median"])
cmp("per value: ratio Q1", pv["ratio_row_to_outcome_n"]["q1"], qv["q25"])
cmp("per value: ratio Q3", pv["ratio_row_to_outcome_n"]["q3"], qv["q75"])
cmp("per value: below 0.5", pv["share_below_0_5"]["numerator"], qv["n_below_0.5"])
cmp("per value: above 1", pv["share_above_1"]["numerator"], qv["n_above_1"])

# cell flow: map module classes to recount classes
fa = a["flow_affected_cells"]
cb, db = b["cell_classes"]["cells"], b["cell_classes"]["differing_measurements"]
g = lambda k: fa.get(k, {"cells": 0, "differing_measurements": 0})
pairs = [("1 one-group outcome", ["a_one_group"]),
         ("2 outcome with three or more groups", ["b_three_plus_groups"]),
         ("3 two-group outcome but cell lacks a value for both groups", ["c_not_one_measurement_per_group"]),
         ("4 tier C or D measurement", ["d_tier_C_or_D"]),
         ("5 outcome analyzed in another unit", ["e_B2_or_non_participant_units"]),
         ("6 missing outcome-level participant count", ["f_n_out_missing"]),
         ("7 value not a plain number", ["g_value_not_plain_number"]),
         ("9 count of participants: a denominator of 0", ["i_cop_zero_denominator"]),
         ("10 count of participants: value above the outcome-level count (no proportion under the export)", ["j_cop_exceeds_n_out_no_proportion"]),
         ("11 count of participants: analysed", ["k_cop_analysed"]),
         ("13 mean type, standard deviation: analysed", ["mean_sd_analysed"]),
         ("14 mean type, standard error: analysed", ["mean_se_analysed"]),
         ("15 other parameter or dispersion type (not in sections 4.2-4.3)", ["other_type"])]
cmp("affected cells: total", sum(v["cells"] for v in fa.values()), b["cell_classes"]["total_cells"])
for k, ks in pairs:
    cmp("cells: " + k, g(k)["cells"], sum(cb[x] for x in ks))
    cmp("differing measurements: " + k, g(k)["differing_measurements"], sum(db[x] for x in ks))
m8 = sum(v["cells"] for k, v in fa.items() if k.startswith("8 ") or k.startswith("12 "))
cmp("cells: excluded count or mean-type cells (module classes 8 and 12)", m8, cb["h_cop_invalid_or_exceeds_n_row"] + cb["mean_excluded"])


def cop(name, x, y):
    cmp(name + ": cells", x["cells"], y["cells"])
    cmp(name + ": studies", x["studies"], y["studies"])
    cmp(name + ": median |RD change| pp", x["rd_abs_change_pp"]["median"], y["rd_abs_change_pp"]["median"], 1e-9)
    cmp(name + ": Q1 |RD change| pp", x["rd_abs_change_pp"]["q1"], y["rd_abs_change_pp"]["q25"], 1e-9)
    cmp(name + ": Q3 |RD change| pp", x["rd_abs_change_pp"]["q3"], y["rd_abs_change_pp"]["q75"], 1e-9)
    cmp(name + ": RD change > 1 pp", x["rd_change_above_1pp"]["numerator"], y["n_rd_change_above_1pp"])
    cmp(name + ": RD change > 5 pp", x["rd_change_above_5pp"]["numerator"], y["n_rd_change_above_5pp"])
    cmp(name + ": interval changes relation to 0", x["rd_interval_changes_relation_to_0"]["numerator"], y["interval_change_total"])
    cmp(name + ": excludes 0 -> contains 0", x["excludes_0_under_row_count_includes_under_export"]["numerator"], y["ref_excludes_export_contains"])
    cmp(name + ": contains 0 -> excludes 0", x["includes_0_under_row_count_excludes_under_export"]["numerator"], y["ref_contains_export_excludes"])
    cmp(name + ": opposite sides", x["excludes_0_on_opposite_sides"]["numerator"], y["excludes_opposite_sides"])
    cmp(name + ": studies with an interval change", x["studies_with_a_cell_whose_interval_changes"], y["studies_with_interval_change"])
    cmp(name + ": RR cells (both counts > 0)", x["rr_cells_both_counts_above_0"], y["rr_cells_both_counts_positive"])
    cmp(name + ": RR change >= 10%", x["rr_changes_10pct_or_more"]["numerator"], y["rr_change_ge_10pct"])
    cmp(name + ": zero-count cells", x["rr_sensitivity_zero_cells_0_5_added"]["cells"], y["zero_count_cells"])
    cmp(name + ": RR change >= 10% with 0.5 added", x["rr_sensitivity_zero_cells_0_5_added"]["rr_changes_10pct_or_more"]["numerator"], y["rr_sensitivity_change_ge_10pct"])
    cmp(name + ": n ratio differs between arms > 5%", x["n_ratio_differs_between_arms_by_more_than_5pct"]["numerator"], y["denom_ratio_differs_gt_5pct"])


cop("all", a["count_of_participants_4_2"], b["cop_all"])
cop("primary", a["count_of_participants_primary_outcomes"], b["cop_primary"])
cop("without NCT02443155", a["sensitivity_without_NCT02443155"], b["cop_without_NCT02443155"])
cop("without top ten", a["sensitivity_without_top10_studies"], b["cop_without_top10"])
cmp("no-proportion cells", a["count_of_participants_4_2"]["cop_cells_x_above_outcome_level_count"], b["cop_all"]["no_proportion_cells"])

ms, mr = a["mean_type_4_3"], b["mean_sd"]
cmp("mean SD: cells", ms["standard_deviation_cells"], mr["cells"])
cmp("mean SD: studies", ms["studies"], mr["studies"])
cmp("mean SD: interval changes relation to 0", ms["interval_changes_relation_to_0"]["numerator"], mr["interval_change"])
cmp("mean SD: weight ratio median", ms["inverse_variance_weight_ratio_export_to_row"]["median"], mr["weight_ratio_export_over_reference"]["median"])
cmp("mean SD: weight ratio Q1", ms["inverse_variance_weight_ratio_export_to_row"]["q1"], mr["weight_ratio_export_over_reference"]["q25"])
cmp("mean SD: weight ratio Q3", ms["inverse_variance_weight_ratio_export_to_row"]["q3"], mr["weight_ratio_export_over_reference"]["q75"])
cmp("mean SD: weight ratio cells", ms["inverse_variance_weight_ratio_export_to_row"]["n"], mr["weight_ratio_cells"])
cmp("mean SD: weight ratio off by > 10%", ms["weight_ratio_off_by_more_than_10pct"]["numerator"], mr["weight_ratio_off_by_more_than_10pct"])
se, sr = a["mean_type_4_3"], b["mean_se"]
cmp("mean SE: cells", se["standard_error_cells"], sr["cells"])
cmp("mean SE: SD factor median", se["derived_sd_factor_export_to_row_per_value"]["median"], sr["sd_factor_sqrt_nout_over_nrow"]["median"])
cmp("mean SE: SD factor Q1", se["derived_sd_factor_export_to_row_per_value"]["q1"], sr["sd_factor_sqrt_nout_over_nrow"]["q25"])
cmp("mean SE: SD factor Q3", se["derived_sd_factor_export_to_row_per_value"]["q3"], sr["sd_factor_sqrt_nout_over_nrow"]["q75"])

bm, br = a["count_of_participants_4_2"]["bootstrap_share_interval_changes"], b["bootstrap"]
boot = {"module": [bm["p2_5"], bm["p97_5"]], "recount": [br["p2.5"], br["p97.5"]],
        "note": "different random number generators (Python random, R Mersenne-Twister sample.int) and percentile rules; "
                "exact agreement is not expected. Agreement criterion: both ends within 0.5 percentage points."}
boot["agree_within_0_5pp"] = all(abs(x - y) <= 0.005 for x, y in zip(boot["module"], boot["recount"]))

dis = [x for x in rows if not x["agree"]]
out = {
    "check": "AI-agent recomputation of amendment 4, section 4 (arm-differential consequence analysis), post hoc",
    "written_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    "how": ("The project module (src/tra/a4_consequence.py) was written by Claude Code running Claude Opus 5.5 "
            "(claude-opus-5-5) and reads the pinned exports. The recount (recount.R) was written by a separate request "
            "to the same model (claude-opus-5-5) through the Anthropic API on 24 Oct 2026, given only a written "
            "specification (spec_prompt_header.md and spec_amendment_section4.md; request.json) and not the module or "
            "its output. It reads the raw registry pages, applies the frozen tier rules itself in base R with jsonlite, "
            "and was run unchanged by the Claude Code session. Both are AI-written; this is an AI-agent recomputation, "
            "not an independent human check. The specification fixed the same operational definitions for both, so a "
            "shared misreading of amendment 4 would not be detected."),
    "models": {"module_and_comparison": "claude-opus-5-5 via Claude Code", "recount_code": json.loads((HERE / "response.json").read_text()).get("model")},
    "inputs_sha256": {"consequence_run.json": sha(MOD), "recount_output_2026-10-24.json": sha(REC), "recount.R": sha(HERE / "recount.R"),
                      "spec_prompt_header.md": sha(HERE / "spec_prompt_header.md"), "spec_amendment_section4.md": sha(HERE / "spec_amendment_section4.md"),
                      "a4_consequence.py": sha(ROOT / "src/tra/a4_consequence.py")},
    "items_compared": len(rows),
    "items_agreeing": len(rows) - len(dis),
    "disagreements": dis,
    "bootstrap": boot,
    "items": rows,
    "author_review": "pending: Animesh Bose reviews any disagreement (deep/S2/AUTHOR_REVIEW.md)",
}
(HERE.parent / "ai_check_consequence_2026-10-24.json").write_text(json.dumps(out, indent=1) + "\n")
print(json.dumps({"items": len(rows), "disagree": dis, "bootstrap": boot}, indent=1))
