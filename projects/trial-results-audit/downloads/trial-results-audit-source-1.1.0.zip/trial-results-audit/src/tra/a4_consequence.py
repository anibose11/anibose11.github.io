"""Amendment 4, section 4 (post hoc): arm-differential consequence analysis.

When an automated pipeline replaces a row's own number analyzed with the outcome-level participant count, how much
does a two-arm comparison change? This module answers docs/amendment_A4_2026-10-24.md, section 4, and nothing else.

It reads only the inputs pinned in amendment 4, section 1, item 5 (their SHA-256 values are checked first):
  results/exports/evidence_table.csv.gz           one row per held-out measurement, with tier and denominators
  results/exports/denominator_provenance.csv.gz   one row per outcome group, with the outcome-level counts
  data/frozen/ctgov-20261007T093305Z/manifest.csv (checked, used for the study list)
  source_manifest.json                            (checked only)
It writes results/tables/heldout_posthoc_A4/consequence/. Standard library only; no database, no network.
The frozen modules are not imported or changed.

Usage: python3 -I -B src/tra/a4_consequence.py [repo root]

Implementation choices that the amendment leaves open are listed in IMPLEMENTATION_NOTES and written to
consequence_run.json with the outputs.
"""
from __future__ import annotations

import csv
import datetime as dt
import gzip
import hashlib
import json
import math
import random
import re
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

LABEL = "post hoc (amendment 4)"
SNAP = "ctgov-20261007T093305Z"
PINNED = {
    "results/exports/evidence_table.csv.gz": "f5df29d2488c14d90f24f66f6f608a2a6ad61bdc7fd7395ecb36fa4273a47753",
    "results/exports/denominator_provenance.csv.gz": "7d868a300e3f60074c81fc775b5a2ced16b49f5ce75c22ab4a535e0d0c7865df",
    f"data/frozen/{SNAP}/manifest.csv": "7e73e9c1b6da259035aec6f58deea3a44cb0f39f235dde278be3bdf7a2f3196c",
    "source_manifest.json": "9c7ac70909f913d178c1d60bdddb568d6c7c8188426fc38c9965bf0cf549231c",
}
Z = 1.959963984540054  # standard normal 0.975 quantile
BOOT_SEED = 20261024
BOOT_REPS = 2000
TOP_STUDY = "NCT02443155"
MATERIAL_SHARE = 0.05  # amendment 4, section 4.6
MATERIAL_MEDIAN_PP = 1.0

IMPLEMENTATION_NOTES = [
    "Outcome-level participant count of a group: the smallest integer value among the outcome-level denominators "
    "whose units are 'participants' after trimming and case folding (as in src/tra/posthoc.py).",
    "A measurement 'differs' when its rule is B1_ROW_SPECIFIC_DENOMINATOR and its participant denominator is not "
    "equal to the outcome-level participant count, a missing count included (as in src/tra/posthoc.py); this "
    "reproduces the 22,505 measurements before anything else is computed.",
    "Comparison cell: one study, outcome, class index and category index, taken from the measurement pointer. "
    "The number of outcome groups is the number of distinct group ids in denominator_provenance for that outcome.",
    "Arm 1 is the group whose id sorts first (OG000 before OG001).",
    "A value is a plain number when it matches -?digits with an optional decimal part and nothing else.",
    "Cells with a denominator of 0 in either arm under either count are counted and excluded from intervals.",
    "A risk ratio 'changes by 10% or more' when |RR under the export / RR under the row-level count - 1| >= 0.10.",
    "The relation of an interval to 0 has three states: wholly below 0, containing 0 (an end exactly at 0 counts "
    "as containing it), wholly above 0. A change is any move between states.",
    "The share of cells whose interval changes its relation to 0 uses as denominator the affected "
    "count-of-participants cells where both denominators give a proportion in each arm.",
    "Bootstrap: whole studies are resampled with replacement from the studies that contribute to the share; "
    "2.5th and 97.5th percentiles of the replicate shares.",
    "Mean-type outcomes: the standard error of a mean is SD/sqrt(n); the inverse-variance weight of a mean "
    "difference is 1/(SE1^2 + SE2^2).",
    "Top ten studies: the ten studies with most differing measurements, recomputed here and checked against "
    "results/tables/heldout_posthoc/flat_row_count_differs_by_study.csv.",
]

PLAIN = re.compile(r"^-?\d+(\.\d+)?$")
INT = re.compile(r"^\d+$")
PTR = re.compile(r"^/resultsSection/outcomeMeasuresModule/outcomeMeasures/(\d+)/classes/(\d+)/categories/(\d+)/measurements/(\d+)$")


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def wilson(x: int, n: int) -> tuple[float, float]:
    p = x / n
    den = 1 + Z * Z / n
    centre = (p + Z * Z / (2 * n)) / den
    half = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / den
    return max(0.0, centre - half), min(1.0, centre + half)


def newcombe(x1: int, n1: int, x2: int, n2: int) -> tuple[float, float, float]:
    """Risk difference p2 - p1 with the Newcombe hybrid score interval (method 10, no continuity correction)."""
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1)
    l2, u2 = wilson(x2, n2)
    d = p2 - p1
    lo = d - math.sqrt((p2 - l2) ** 2 + (u1 - p1) ** 2)
    hi = d + math.sqrt((u2 - p2) ** 2 + (p1 - l1) ** 2)
    return d, lo, hi


def rr_log(x1: float, n1: float, x2: float, n2: float) -> tuple[float, float, float]:
    rr = (x2 / n2) / (x1 / n1)
    se = math.sqrt(1 / x2 - 1 / n2 + 1 / x1 - 1 / n1)
    return rr, rr * math.exp(-Z * se), rr * math.exp(Z * se)


def relation(lo: float, hi: float) -> str:
    if hi < 0:
        return "below"
    if lo > 0:
        return "above"
    return "contains"


def quantiles(xs: list[float]) -> dict:
    if not xs:
        return {"n": 0, "median": None, "q1": None, "q3": None}
    s = sorted(xs)
    if len(s) == 1:
        return {"n": 1, "median": s[0], "q1": s[0], "q3": s[0]}
    q = statistics.quantiles(s, n=4, method="inclusive")
    return {"n": len(s), "median": statistics.median(s), "q1": q[0], "q3": q[2]}


def share(k: int, n: int) -> dict:
    return {"numerator": k, "denominator": n, "share": (k / n) if n else None}


def write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def load(root: Path):
    held = set()
    with open(root / f"data/frozen/{SNAP}/manifest.csv", newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            if r["split"] == "heldout" and r["cohort_status"] == "confirmed":
                held.add(r["nct_id"])
    ol = {}  # (nct, outcome_ordinal, group_id) -> outcome-level participant count or None
    groups = defaultdict(set)  # (nct, outcome_ordinal) -> group ids
    with gzip.open(root / "results/exports/denominator_provenance.csv.gz", "rt", encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            key = (r["nct_id"], int(r["outcome_ordinal"]))
            groups[key].add(r["group_id"])
            vals = []
            for d in json.loads(r["outcome_level_denominators"] or "[]"):
                if (d.get("units") or "").strip().lower() == "participants" and INT.match(str(d.get("value", "")).strip()):
                    vals.append(int(str(d["value"]).strip()))
            ol[key + (r["group_id"],)] = min(vals) if vals else None
    meas = []
    with gzip.open(root / "results/exports/evidence_table.csv.gz", "rt", encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            if r["nct_id"] not in held:
                raise SystemExit(f"{r['nct_id']} is not a confirmed held-out study")
            m = PTR.match(r["measurement_pointer"])
            if not m:
                raise SystemExit("unexpected pointer " + r["measurement_pointer"])
            oi, ci, ki, _ = (int(x) for x in m.groups())
            if oi != int(r["outcome_ordinal"]):
                raise SystemExit("pointer and outcome ordinal disagree")
            pd = r["participant_denominator"].strip()
            r["_oi"], r["_ci"], r["_ki"] = oi, ci, ki
            r["_n_ref"] = int(pd) if INT.match(pd) else None
            r["_n_ol"] = ol.get((r["nct_id"], oi, r["group_id"]))
            r["_differs"] = r["rule_id"] == "B1_ROW_SPECIFIC_DENOMINATOR" and r["_n_ref"] != r["_n_ol"]
            meas.append(r)
    return held, groups, meas


def analyse(cells: list[dict]) -> dict:
    """Section 4.2 metrics for a list of computable count-of-participants cells."""
    n = len(cells)
    rd_change = [abs(c["rd_exp"] - c["rd_ref"]) * 100 for c in cells]
    moves = Counter((c["rel_ref"], c["rel_exp"]) for c in cells if c["rel_ref"] != c["rel_exp"])
    changed = sum(moves.values())
    lost = sum(v for (a, b), v in moves.items() if a != "contains" and b == "contains")
    gained = sum(v for (a, b), v in moves.items() if a == "contains" and b != "contains")
    crossed = changed - lost - gained
    rr_cells = [c for c in cells if c["rr_ok"]]
    rr10 = sum(1 for c in rr_cells if abs(c["rr_exp"] / c["rr_ref"] - 1) >= 0.10)
    ratio5 = sum(1 for c in cells if abs(c["r2"] / c["r1"] - 1) > 0.05)
    rr_cc = [c for c in cells if not c["rr_ok"]]
    rr10_cc = sum(1 for c in rr_cc if abs(c["rr_exp_cc"] / c["rr_ref_cc"] - 1) >= 0.10)
    q = quantiles(rd_change)
    return {
        "cells": n,
        "studies": len({c["nct"] for c in cells}),
        "rd_abs_change_pp": q,
        "rd_change_above_1pp": share(sum(1 for x in rd_change if x > 1), n),
        "rd_change_above_5pp": share(sum(1 for x in rd_change if x > 5), n),
        "rd_interval_changes_relation_to_0": share(changed, n),
        "excludes_0_under_row_count_includes_under_export": share(lost, n),
        "includes_0_under_row_count_excludes_under_export": share(gained, n),
        "excludes_0_on_opposite_sides": share(crossed, n),
        "studies_with_a_cell_whose_interval_changes": len({c["nct"] for c in cells if c["rel_ref"] != c["rel_exp"]}),
        "rr_cells_both_counts_above_0": len(rr_cells),
        "rr_changes_10pct_or_more": share(rr10, len(rr_cells)),
        "rr_sensitivity_zero_cells_0_5_added": {"cells": len(rr_cc), "rr_changes_10pct_or_more": share(rr10_cc, len(rr_cc))},
        "rr_changes_10pct_or_more_all_cells_with_0_5_for_zero_cells": share(rr10 + rr10_cc, n),
        "n_ratio_differs_between_arms_by_more_than_5pct": share(ratio5, n),
    }


def bootstrap(cells: list[dict]) -> dict:
    by = defaultdict(lambda: [0, 0])
    for c in cells:
        by[c["nct"]][0] += 1
        by[c["nct"]][1] += c["rel_ref"] != c["rel_exp"]
    ids = sorted(by)
    rng = random.Random(BOOT_SEED)
    reps = []
    for _ in range(BOOT_REPS):
        tot = chg = 0
        for _ in ids:
            a, b = by[ids[rng.randrange(len(ids))]]
            tot += a
            chg += b
        reps.append(chg / tot if tot else 0.0)
    reps.sort()
    return {"replicates": BOOT_REPS, "seed": BOOT_SEED, "studies_resampled": len(ids),
            "p2_5": reps[int(0.025 * BOOT_REPS)], "p97_5": reps[int(0.975 * BOOT_REPS) - 1],
            "note": "percentile range of whole-study resamples; not a confidence interval for any population"}


def run(root: Path) -> dict:
    started = utc_now()
    hashes = {k: sha256(root / k) for k in PINNED}
    bad = {k: v for k, v in hashes.items() if v != PINNED[k]}
    if bad:
        raise SystemExit(f"pinned input changed: {bad}")
    held, groups, meas = load(root)

    # Reproduce the published post hoc count before anything else.
    differs = [m for m in meas if m["_differs"]]
    by_study = Counter(m["nct_id"] for m in differs)
    top = sorted(by_study.items(), key=lambda kv: (-kv[1], kv[0]))
    top10 = [k for k, _ in top[:10]]
    checks = {"measurements_total": len(meas), "measurements_differ": len(differs),
              "studies_differ": len(by_study), "top10_measurements": sum(by_study[k] for k in top10),
              "top_study": top[0]}
    with open(root / "results/tables/heldout_posthoc/flat_row_count_differs_spread.csv", newline="", encoding="utf-8") as fh:
        pub = {r["measure"][:40]: (int(r["numerator"]), int(r["denominator"])) for r in csv.DictReader(fh)}
    pub_vals = list(pub.values())
    if (len(differs), len(meas)) != pub_vals[0] or len(by_study) != pub_vals[1][0] or checks["top10_measurements"] != pub_vals[3][0]:
        raise SystemExit(f"post hoc counts not reproduced: {checks} vs {pub_vals}")
    with open(root / "results/tables/heldout_posthoc/flat_row_count_differs_by_study.csv", newline="", encoding="utf-8") as fh:
        pub_top = [r["nct_id"] for r in csv.DictReader(fh)][:10]
    if pub_top != top10:
        raise SystemExit("top ten studies differ from the published table")

    # 4.4 per-value summary
    ratios = [m["_n_ref"] / m["_n_ol"] for m in differs if m["_n_ref"] is not None and m["_n_ol"]]
    per_value = {"measurements": len(differs), "with_ratio": len(ratios),
                 "without_outcome_level_count_or_zero": len(differs) - len(ratios),
                 "ratio_row_to_outcome_n": quantiles(ratios),
                 "share_below_0_5": share(sum(1 for r in ratios if r < 0.5), len(ratios)),
                 "share_above_1": share(sum(1 for r in ratios if r > 1), len(ratios))}

    # Build comparison cells
    cells = defaultdict(list)
    for m in meas:
        cells[(m["nct_id"], m["_oi"], m["_ci"], m["_ki"])].append(m)
    flow = Counter()
    flow_meas = Counter()
    cop, mean_sd, mean_se = [], [], []
    noncomp = Counter()
    for key, ms in sorted(cells.items()):
        if not any(m["_differs"] for m in ms):
            continue
        nct, oi = key[0], key[1]
        k = len(groups[(nct, oi)])

        def mark(reason):
            flow[reason] += 1
            flow_meas[reason] += sum(1 for m in ms if m["_differs"])
        if k == 1:
            mark("1 one-group outcome")
            continue
        if k >= 3:
            mark("2 outcome with three or more groups")
            continue
        if len(ms) != 2 or len({m["group_id"] for m in ms}) != 2:
            mark("3 two-group outcome but cell lacks a value for both groups")
            continue
        if any(m["tier"] in ("C", "D") for m in ms):
            mark("4 tier C or D measurement")
            continue
        if any(m["rule_id"] == "B2_NON_PARTICIPANT_UNITS" or (m["analysis_unit"] or "").strip().lower() != "participants" for m in ms):
            mark("5 outcome analyzed in another unit")
            continue
        if any(m["_n_ol"] is None for m in ms):
            mark("6 missing outcome-level participant count")
            continue
        if any(not PLAIN.match((m["value_text"] or "").strip()) for m in ms):
            mark("7 value not a plain number")
            continue
        ms = sorted(ms, key=lambda m: m["group_id"])
        a1, a2 = ms
        pt, disp = a1["param_type"], a1["dispersion_type"]
        base = {"nct": nct, "oi": oi, "ci": key[2], "ki": key[3], "type": a1["outcome_type"],
                "g1": a1["group_id"], "g2": a2["group_id"],
                "n1r": a1["_n_ref"], "n2r": a2["_n_ref"], "n1o": a1["_n_ol"], "n2o": a2["_n_ol"]}
        if pt == "COUNT_OF_PARTICIPANTS":
            xs = [(m["value_text"] or "").strip() for m in ms]
            if not all(INT.match(x) for x in xs):
                mark("8 count of participants: value not an integer")
                continue
            x1, x2 = int(xs[0]), int(xs[1])
            if not (x1 <= a1["_n_ref"] and x2 <= a2["_n_ref"]):
                mark("8 count of participants: value above the row-level count")
                continue
            if 0 in (a1["_n_ref"], a2["_n_ref"], a1["_n_ol"], a2["_n_ol"]):
                mark("9 count of participants: a denominator of 0")
                continue
            if x1 > a1["_n_ol"] or x2 > a2["_n_ol"]:
                mark("10 count of participants: value above the outcome-level count (no proportion under the export)")
                noncomp["cop_x_above_outcome_level"] += 1
                cop.append(dict(base, x1=x1, x2=x2, computable=False))
                continue
            mark("11 count of participants: analysed")
            c = dict(base, x1=x1, x2=x2, computable=True)
            n1r, n2r, n1o, n2o = a1["_n_ref"], a2["_n_ref"], a1["_n_ol"], a2["_n_ol"]
            c["rd_ref"], lo, hi = newcombe(x1, n1r, x2, n2r)
            c["rel_ref"] = relation(lo, hi)
            c["ci_ref"] = (lo, hi)
            c["rd_exp"], lo, hi = newcombe(x1, n1o, x2, n2o)
            c["rel_exp"] = relation(lo, hi)
            c["ci_exp"] = (lo, hi)
            c["r1"], c["r2"] = n1r / n1o, n2r / n2o
            c["rr_ok"] = x1 > 0 and x2 > 0
            if c["rr_ok"]:
                c["rr_ref"] = rr_log(x1, n1r, x2, n2r)[0]
                c["rr_exp"] = rr_log(x1, n1o, x2, n2o)[0]
            else:
                c["rr_ref_cc"] = rr_log(x1 + .5, n1r + 1, x2 + .5, n2r + 1)[0]
                c["rr_exp_cc"] = rr_log(x1 + .5, n1o + 1, x2 + .5, n2o + 1)[0]
            cop.append(c)
        elif pt in ("MEAN", "LEAST_SQUARES_MEAN") and disp in ("Standard Deviation", "Standard Error"):
            if a2["dispersion_type"] != disp or a2["param_type"] != pt:
                mark("12 mean type: arms differ in parameter or dispersion")
                continue
            sp = [(m["spread_text"] or "").strip() for m in ms]
            if not all(PLAIN.match(s) for s in sp):
                mark("12 mean type: dispersion not a plain number")
                continue
            if 0 in (a1["_n_ref"], a2["_n_ref"], a1["_n_ol"], a2["_n_ol"]):
                mark("12 mean type: a denominator of 0")
                continue
            m1, m2 = float(a1["value_text"]), float(a2["value_text"])
            s1, s2 = float(sp[0]), float(sp[1])
            c = dict(base, m1=m1, m2=m2, s1=s1, s2=s2, disp=disp)
            if disp == "Standard Deviation":
                mark("13 mean type, standard deviation: analysed")
                se_r = math.sqrt(s1 ** 2 / a1["_n_ref"] + s2 ** 2 / a2["_n_ref"])
                se_o = math.sqrt(s1 ** 2 / a1["_n_ol"] + s2 ** 2 / a2["_n_ol"])
                d = m2 - m1
                c["rel_ref"] = relation(d - Z * se_r, d + Z * se_r) if se_r > 0 else ("above" if d > 0 else "below" if d < 0 else "contains")
                c["rel_exp"] = relation(d - Z * se_o, d + Z * se_o) if se_o > 0 else ("above" if d > 0 else "below" if d < 0 else "contains")
                c["w_ratio"] = (se_r ** 2 / se_o ** 2) if se_o > 0 else None
                mean_sd.append(c)
            else:
                mark("14 mean type, standard error: analysed")
                c["sd_factor"] = [math.sqrt(a1["_n_ol"] / a1["_n_ref"]), math.sqrt(a2["_n_ol"] / a2["_n_ref"])]
                mean_se.append(c)
        else:
            mark("15 other parameter or dispersion type (not in sections 4.2-4.3)")

    comp = [c for c in cop if c["computable"]]
    primary = [c for c in comp if c["type"] == "PRIMARY"]
    main = analyse(comp)
    main["cop_cells_x_above_outcome_level_count"] = noncomp["cop_x_above_outcome_level"]
    main["cop_cells_eligible_incl_x_above_outcome_level"] = len(cop)
    main["bootstrap_share_interval_changes"] = bootstrap(comp)
    out = {
        "label": LABEL,
        "amendment": "docs/amendment_A4_2026-10-24.md, section 4",
        "started_utc": started,
        "inputs_sha256": hashes,
        "implementation_notes": IMPLEMENTATION_NOTES,
        "reproduction_of_published_counts": checks,
        "flow_affected_cells": {k: {"cells": v, "differing_measurements": flow_meas[k]} for k, v in sorted(flow.items(), key=lambda kv: int(kv[0].split()[0]))},
        "per_value_4_4": per_value,
        "count_of_participants_4_2": main,
        "count_of_participants_primary_outcomes": analyse(primary),
        "sensitivity_without_NCT02443155": analyse([c for c in comp if c["nct"] != TOP_STUDY]),
        "sensitivity_without_top10_studies": analyse([c for c in comp if c["nct"] not in top10]),
        "top10_studies": top10,
    }
    sd_rel = [c for c in mean_sd if c["rel_ref"] != c["rel_exp"]]
    w = [c["w_ratio"] for c in mean_sd if c["w_ratio"] is not None]
    out["mean_type_4_3"] = {
        "standard_deviation_cells": len(mean_sd),
        "studies": len({c["nct"] for c in mean_sd}),
        "interval_changes_relation_to_0": share(len(sd_rel), len(mean_sd)),
        "inverse_variance_weight_ratio_export_to_row": quantiles(w),
        "weight_ratio_off_by_more_than_10pct": share(sum(1 for x in w if abs(x - 1) > 0.10), len(w)),
        "standard_error_cells": len(mean_se),
        "derived_sd_factor_export_to_row_per_value": quantiles([f for c in mean_se for f in c["sd_factor"]]),
    }
    e = main
    out["material_4_6"] = {
        "share_interval_changes": e["rd_interval_changes_relation_to_0"]["share"],
        "median_abs_rd_change_pp": e["rd_abs_change_pp"]["median"],
        "threshold_share": MATERIAL_SHARE, "threshold_median_pp": MATERIAL_MEDIAN_PP,
        "material": bool((e["rd_interval_changes_relation_to_0"]["share"] or 0) >= MATERIAL_SHARE
                         or (e["rd_abs_change_pp"]["median"] or 0) >= MATERIAL_MEDIAN_PP),
    }
    out["finished_utc"] = utc_now()

    od = root / "results/tables/heldout_posthoc_A4/consequence"
    od.mkdir(parents=True, exist_ok=True)
    with open(od / "consequence_run.json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
        fh.write("\n")
    write_csv(od / "consequence_cells_count_of_participants.csv",
              ["nct_id", "outcome_ordinal", "class_index", "category_index", "outcome_type", "arm1_group", "arm2_group",
               "x1", "x2", "n1_row", "n2_row", "n1_outcome", "n2_outcome", "computable",
               "rd_row", "rd_row_lo", "rd_row_hi", "rd_export", "rd_export_lo", "rd_export_hi",
               "relation_row", "relation_export", "label"],
              [[c["nct"], c["oi"], c["ci"], c["ki"], c["type"], c["g1"], c["g2"], c["x1"], c["x2"],
                c["n1r"], c["n2r"], c["n1o"], c["n2o"], c["computable"],
                *((f"{c['rd_ref']:.6f}", f"{c['ci_ref'][0]:.6f}", f"{c['ci_ref'][1]:.6f}",
                   f"{c['rd_exp']:.6f}", f"{c['ci_exp'][0]:.6f}", f"{c['ci_exp'][1]:.6f}",
                   c["rel_ref"], c["rel_exp"]) if c["computable"] else ("",) * 8), LABEL] for c in cop])
    write_csv(od / "consequence_flow.csv", ["step", "unit", "cells", "differing_measurements", "label"],
              [[k, "comparison cell", v["cells"], v["differing_measurements"], LABEL] for k, v in out["flow_affected_cells"].items()])
    summ = []

    def add(scope, measure, num, den):
        summ.append([scope, measure, num, den, f"{100 * num / den:.1f}" if den else "", LABEL])
    for scope, key in (("all affected cells", "count_of_participants_4_2"), ("primary outcomes", "count_of_participants_primary_outcomes"),
                       ("without NCT02443155", "sensitivity_without_NCT02443155"), ("without the ten largest contributors", "sensitivity_without_top10_studies")):
        a = out[key]
        add(scope, "risk-difference interval changes its relation to 0", a["rd_interval_changes_relation_to_0"]["numerator"], a["cells"])
        add(scope, "absolute change in risk difference above 1 percentage point", a["rd_change_above_1pp"]["numerator"], a["cells"])
        add(scope, "absolute change in risk difference above 5 percentage points", a["rd_change_above_5pp"]["numerator"], a["cells"])
        add(scope, "risk ratio changes by 10% or more (both counts above 0)", a["rr_changes_10pct_or_more"]["numerator"], a["rr_cells_both_counts_above_0"])
    write_csv(od / "consequence_summary.csv", ["scope", "measure", "numerator", "denominator", "percent", "label"], summ)
    with open(od / "SHA256SUMS.txt", "w", encoding="utf-8") as fh:
        for p in sorted(od.glob("*")):
            if p.name != "SHA256SUMS.txt":
                fh.write(f"{sha256(p)}  {p.name}\n")
    return out


if __name__ == "__main__":
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]
    res = run(root)
    print(json.dumps({k: res[k] for k in ("reproduction_of_published_counts", "flow_affected_cells", "material_4_6")}, indent=1))
