"""Render stage: figures, report, project page, workbook, data dictionary and downloads.

All numbers come from tra.facts (which reads the held-out result tables). Templates live in report/ and site_src/.
Pages are rendered with Python-Markdown and Jinja2.
"""
from __future__ import annotations

import csv
import gzip
import html
import json
import shutil
from pathlib import Path

import jinja2
import markdown
import yaml

from .config import DOCS_DIR, EVIDENCE_DIR, RESULTS_DIR, ROOT, SLUG, TABLES_DIR, write_json
from .docs_gen import write_data_dictionary, write_source_manifest
from .facts import Facts
from .figures import write_figures

SITE = ROOT / "site" / "projects" / SLUG
REPORT_DIR = ROOT / "report"
# Author declarations and the corresponding e-mail: kept out of the source archive and the public pages.
DECL_FILE = REPORT_DIR / "declarations.yaml"
DEPOSIT_FILE = ROOT / "config" / "deposit.yaml"

CHECK_NAMES = {
    "K1": "Participant count above its participant denominator",
    "K2": "Unit count above its unit denominator",
    "K3": "Interval limits out of order",
    "K4": "Point value outside its interval",
    "K5": "Percentage of participants outside 0 to 100",
    "K6": "Adverse event participants affected above participants at risk",
    "K7": "Adverse event participants affected above number of events",
    "K8": "Adverse event group totals: affected above at risk",
    "K9": "Baseline participant count above its denominator",
    "K10": "Analysis confidence limits reversed, or estimate outside them",
    "K11": "Non-zero value with zero participants analyzed",
    "K12": "Category counts not adding up to participants analyzed",
}


def figure_captions(f: Facts) -> list[dict]:
    """Titles (at most 15 words) and legends for Figures 1 to 3, in order of first citation."""
    return [
        {"file": "fig1_tiers_by_structure.svg",
         "title": "Denominator tier of each outcome group, overall and by outcome table structure",
         "legend": (f"Held-out portion; unit: applicable outcome group (n = {f.n('og_applicable')}). Tier A: one usable "
                    "outcome-level participant count, no row-level counts, analysis in participants. Tier B: an explicit rule "
                    "is needed, because the rows report their own numbers analyzed or the outcome is analyzed in another unit "
                    "with the participant count held separately. Tier C: no participant count can be attached without "
                    "unsupported inference. Tier D groups are excluded. Percentages are of the groups in each bar, and the number of tier C "
                    "groups is printed beside the bars that have any. Source data: Additional file 4, sheet By structure.")},
        {"file": "fig2_flat_denominator.svg",
         "title": "Denominator attached by a flat export compared with the applicable participant denominator",
         "legend": (f"Held-out portion; unit: measurement (n = {f.n('flat_meas_total')}). Each bar counts measurements by how the "
                    "outcome-level participant count attached by the declared flat export compares with the most specific "
                    "participant denominator under the written rules. Orange bars mark measurements for which the attached count is "
                    "not, or cannot be shown to be, the applicable denominator: the row reported its own, different number analyzed, "
                    "the values are per another unit, no participant count can be attached safely, or the value could not "
                    f"be located uniquely in the flat file ({f.n('flat_not_identifiable')} tier A measurements, not included in the "
                    f"{f.n('flat_not_applicable_count')} measurements given in the text). The second bar is empty because, wherever "
                    "the outcome-level count applied and the value could be located, the flat export attached it. Source data: "
                    "Additional file 4, sheet Flat denominators.")},
        {"file": "fig3_retention_by_family.svg",
         "title": "Source values returned with identical text, by field family and representation",
         "legend": ("Held-out portion; unit: source scalar. Blue: relational warehouse; orange: declared flat export. A value "
                    "counts as returned when exactly one row matches its full context and a cell holds the identical text; statistical "
                    "analyses, which have no context below their outcome, were matched by order within the outcome. "
                    "Adverse events and the more-information module are omitted because the flat export does not attempt "
                    "them. Where both representations reach 100% the dots overlap. Source data: Additional file 4, sheet "
                    "Retention.")},
    ]


def load_declarations() -> dict | None:
    return yaml.safe_load(DECL_FILE.read_text(encoding="utf-8")) if DECL_FILE.exists() else None


def load_deposit() -> dict:
    d = yaml.safe_load(DEPOSIT_FILE.read_text(encoding="utf-8")) if DEPOSIT_FILE.exists() else {}
    return {"repository": d.get("repository") or "Zenodo", "doi": d.get("doi"), "version": str(d.get("version") or "1.0.0"),
            "year": str(d.get("year") or "2026")}


def apply_deposit_doi(deposit: dict) -> None:
    """Write the archived version's DOI into CITATION.cff and the README once config/deposit.yaml has one."""
    doi = deposit.get("doi")
    if not doi:
        return
    cff = ROOT / "CITATION.cff"
    text = cff.read_text(encoding="utf-8")
    text = text.replace(' No DOI has been assigned."', '"')
    lines = [ln for ln in text.splitlines() if not ln.startswith("doi:")]
    at = next(i for i, ln in enumerate(lines) if ln.startswith("version:"))
    lines.insert(at, f"doi: {doi}")
    cff.write_text("\n".join(lines) + "\n", encoding="utf-8")
    readme = ROOT / "README.md"
    r = readme.read_text(encoding="utf-8")
    note = f"Archived version: {deposit['repository']}, https://doi.org/{doi}"
    lines = [ln for ln in r.splitlines() if not ln.startswith("Archived version: ")]
    head = next(i for i, ln in enumerate(lines) if ln.startswith("The full report"))
    lines.insert(head + 1, "")
    lines.insert(head + 2, note)
    readme.write_text("\n".join(lines).replace("\n\n\n", "\n\n") + "\n", encoding="utf-8")


def render_manuscript(f: Facts, fig_svg: dict, journal: bool, decl: dict | None, deposit: dict,
                      author_review: dict | None) -> tuple[str, object]:
    from . import references
    from .references import Citer
    if deposit.get("doi"):
        references.REFS["deposit"] = (f"Bose A. trial-results-audit: clinical trial results warehouse and denominator audit, "
                                      f"version {deposit['version']} [software and derived data]. {deposit['repository']}. "
                                      f"{deposit['year']}. https://doi.org/{deposit['doi']}.")
    citer = Citer()
    env = _env(REPORT_DIR)
    tn = (lambda v: str(int(v))) if journal else (lambda v: f"{int(v):,}")
    md = env.get_template("manuscript.md.j2").render(
        f=f, fig=fig_svg, figs=figure_captions(f), cite=citer, author_review=author_review, journal=journal,
        decl=decl, deposit=deposit, tn=tn, check_names=CHECK_NAMES)
    return md, citer


def _env(path: Path) -> jinja2.Environment:
    env = jinja2.Environment(loader=jinja2.FileSystemLoader(str(path)), undefined=jinja2.StrictUndefined,
                             autoescape=False, keep_trailing_newline=True)
    env.filters["thousands"] = lambda v: f"{int(v):,}"
    env.filters["esc"] = lambda v: html.escape(str(v), quote=True)
    env.filters["r1"] = _round1
    env.globals["pct1"] = lambda n, d: _pct(n, d, 1)
    env.globals["pct2"] = lambda n, d: _pct(n, d, 2)
    return env


def _pct(n, d, digits: int) -> str:
    """Percentage from counts, rounded half up once, with a fixed number of decimals."""
    from decimal import Decimal, ROUND_HALF_UP
    n, d = int(n), int(d)
    if not d:
        return "n/a"
    q = (Decimal(100) * n / d).quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)
    return f"{q}%"


def _round1(v) -> str:
    """One decimal, rounding half up on the decimal text (avoids binary-float artefacts such as 72.35 -> 72.3)."""
    from decimal import Decimal, ROUND_HALF_UP
    return str(Decimal(str(v)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))


def md_to_html(text: str) -> str:
    return markdown.markdown(text, extensions=["tables", "fenced_code", "toc", "attr_list", "md_in_html"],
                             extension_configs={"toc": {"permalink": False}})


def wrap_tables(html_text: str) -> str:
    """Make wide tables scroll inside a focusable, labeled region."""
    out, i = [], 0
    while True:
        j = html_text.find("<table>", i)
        if j < 0:
            out.append(html_text[i:])
            break
        k = html_text.find("</table>", j) + len("</table>")
        out.append(html_text[i:j])
        out.append('<div class="table-wrap" role="region" tabindex="0" aria-label="Scrollable table">'
                   + html_text[j:k] + "</div>")
        i = k
    return "".join(out).replace("<td>", "<td>").replace("<th>", "<th>")


def table_html(rows: list[dict], cols: list[tuple[str, str]], caption: str, numeric: set[str] = frozenset()) -> str:
    th = "".join(f'<th scope="col"{" class=\"num\"" if c in numeric else ""}>{html.escape(label)}</th>' for c, label in cols)
    body = []
    for r in rows:
        tds = []
        for c, _ in cols:
            v = r.get(c, "")
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                v = f"{v:,}" if isinstance(v, int) else f"{v:,.1f}"
            tds.append(f'<td{" class=\"num\"" if c in numeric else ""}>{html.escape(str(v))}</td>')
        body.append("<tr>" + "".join(tds) + "</tr>")
    return (f'<div class="table-wrap" role="region" tabindex="0" aria-label="{html.escape(caption)}"><table>'
            f"<caption>{html.escape(caption)}</caption><thead><tr>{th}</tr></thead><tbody>{''.join(body)}</tbody></table></div>")


def write_workbook(f: Facts, path: Path):
    """Aggregate tables only, with a definitions sheet; no record-level data."""
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active
    ws.title = "Definitions"
    defs = [
        ("Workbook", "Aggregate result tables of the trial-results-audit held-out audit (ClinicalTrials.gov results, API v2)."),
        ("Snapshot", f"{f.snapshot}; API {f['api_version'].value}; data timestamp {f['data_timestamp'].value} (UTC)."),
        ("Scope", "Held-out portion of the confirmed cohort unless a sheet says otherwise. Percentages describe this finite corpus; no sampling intervals."),
        ("Units", "Every sheet has a unit column: study, outcome, outcome group, measurement, source scalar, object or applicable check."),
        ("Tier A", "Directly structured and applicable: one integer outcome-level participant count for the group, no row-level counts, analyzed in participants."),
        ("Tier B", "Needs a written, reproducible rule: row-level counts (B1) or another analysis unit with the participant count held separately (B2)."),
        ("Tier C", "Ambiguous and not safely resolvable by the written rules (C1 to C6; Additional file 1 of the article, docs/rules.md in the source archive)."),
        ("Tier D", "Not applicable: outcome not posted, or the group has no measurement rows. Excluded from percentage denominators."),
        ("Checks", "A failed check is a possible source inconsistency, not a confirmed error. Not-evaluable cases are counted apart."),
        ("Post hoc", "Sheets whose names start with 'Post hoc' were added after the single held-out run; they describe the held-out results further and change no prespecified result."),
        ("Source", "ClinicalTrials.gov, U.S. National Library of Medicine. Modifications are described in the denominator rules and the data dictionary (Additional files 1 and 2 of the article; docs/rules.md and docs/data_dictionary.csv in the source archive)."),
    ]
    ws.append(["Term", "Definition"])
    for r in defs:
        ws.append(list(r))
    ws["A1"].font = ws["B1"].font = Font(bold=True)
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 120
    sheets = [("Primary tiers", "primary_outcome_group_tiers_long.csv"), ("Measurement tiers", "measurement_rules.csv"),
              ("By structure", "tiers_by_structure.csv"), ("By condition", "tiers_by_condition_group.csv"),
              ("By year", "tiers_by_results_first_posted_year.csv"), ("By analysis unit", "tiers_by_analysis_unit.csv"),
              ("Outcomes", "outcome_status_and_population_description.csv"), ("Flat denominators", "flat_denominator_comparison.csv"),
              ("By parameter type", "tiers_by_param_type.csv"), ("By outcome type", "tiers_by_outcome_type.csv"),
              ("Population description", "population_description_by_outcome_type.csv"),
              ("Retention", "retention_flat_vs_warehouse.csv"), ("Fidelity", "warehouse_fidelity.csv"), ("Checks", "checks_summary.csv"),
              ("Cross-module labels", "cross_module_label_identity.csv"), ("Sensitivity", "sensitivity_analyses.csv"),
              ("Bootstrap (exploratory)", "exploratory_trial_bootstrap.csv"), ("Cohort flow", "cohort_flow.csv"),
              ("Ledger summary", "issue_ledger_summary.csv"),
              ("Post hoc flat spread", "../heldout_posthoc/flat_row_count_differs_spread.csv"),
              ("Post hoc analysis order", "../heldout_posthoc/flat_analysis_order_matching.csv")]
    for title, fname in sheets:
        ws = wb.create_sheet(title[:31])
        with open(f.tables / fname, encoding="utf-8") as fh:
            rows = list(csv.reader(fh))
        for i, r in enumerate(rows):
            out = []
            for v in r:
                try:
                    if title == "Retention":
                        v = v.replace("row-specific denominators", "row-level denominators").replace(
                            "measurement values", "measurement fields")
                    out.append(int(v) if v.lstrip("-").isdigit() else float(v) if v.replace(".", "", 1).lstrip("-").isdigit() else v)
                except ValueError:
                    out.append(v)
            ws.append(out)
        for c in ws[1]:
            c.font = Font(bold=True)
        ws.freeze_panes = "A2"
    ex = f.example
    ws = wb.create_sheet("Worked example")
    ws.append(["unit", "nct_id", "registry_url", "outcome_title", "time_frame", "row", "category", "group", "value", "spread",
               "row_level_participants_analyzed", "denominator_scope", "rule", "measurement_pointer", "denominator_pointer"])
    for m in ex.get("measurements", []):
        ws.append(["measurement", ex["study"]["nct_id"], ex["study"]["registry_url"], ex["study"]["title"], ex["study"]["time_frame"],
                   m["class_title"], m.get("category_title"), m["group_title"], m["value_text"], m["spread_text"], m["participant_denominator"],
                   m["denominator_scope"], m["rule_id"], m["measurement_pointer"], m["denominator_pointer"]])
    for c in ws[1]:
        c.font = Font(bold=True)
    ws.freeze_panes = "A2"
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def write_runtime_manifest():
    """Versions of everything that produced the outputs, including the reporting renderer actually used."""
    import platform
    import subprocess
    from importlib import metadata
    from . import pg

    def cmd(args):
        try:
            return subprocess.run(args, capture_output=True, text=True).stdout.strip()
        except OSError:
            return None
    with pg.connect() as conn:
        pgv = pg.server_version(conn)
    pkgs = {d: metadata.version(d) for d in ("psycopg", "httpx", "PyYAML", "numpy", "Jinja2", "Markdown", "openpyxl", "pytest")}
    manifest = {
        "os": f"{platform.system()} {platform.release()} ({platform.machine()})",
        "macos_version": cmd(["sw_vers", "-productVersion"]),
        "cpu": cmd(["sysctl", "-n", "machdep.cpu.brand_string"]),
        "memory_bytes": int(cmd(["sysctl", "-n", "hw.memsize"]) or 0),
        "python": platform.python_version(),
        "python_packages": pkgs,
        "r": cmd(["Rscript", "--version"]) or cmd(["R", "--version"]),
        "r_jsonlite": cmd(["Rscript", "-e", "cat(as.character(packageVersion('jsonlite')))"]),
        "postgresql": pgv,
        "reporting_renderer": f"Python-Markdown {pkgs['Markdown']} with Jinja2 {pkgs['Jinja2']} (src/tra/render.py)",
        "figures": "SVG written directly by src/tra/figures.py (no plotting library)",
        "docker": "not used",
    }
    write_json(EVIDENCE_DIR / "runtime_manifest.json", manifest)


def render() -> None:
    f = Facts()
    SITE.mkdir(parents=True, exist_ok=True)
    (SITE / "assets").mkdir(exist_ok=True)
    (SITE / "downloads").mkdir(exist_ok=True)
    for old_svg in (SITE / "assets").glob("fig*.svg"):
        old_svg.unlink()
    figs = write_figures(f.tables, SITE / "assets")
    fig_svg = {k: p.read_text(encoding="utf-8") for k, p in figs.items()}
    shutil.copy(ROOT / "site_src" / "style.css", SITE / "assets" / "style.css")

    write_data_dictionary()
    write_source_manifest(terms=json.loads((DOCS_DIR / "terms_of_use.json").read_text()) if (DOCS_DIR / "terms_of_use.json").exists() else None)
    write_workbook(f, RESULTS_DIR / "trial_results_audit_tables.xlsx")
    write_runtime_manifest()

    review_file = ROOT / "review" / "author_review.json"
    author_review = json.loads(review_file.read_text()) if review_file.exists() else None
    decl, deposit = load_declarations(), load_deposit()
    apply_deposit_doi(deposit)
    # journal variant (title page with e-mail, figures as separate files): private, used for the submission files
    journal_md, jciter = render_manuscript(f, fig_svg, True, decl, deposit, author_review)
    (REPORT_DIR / "manuscript.md").write_text(journal_md, encoding="utf-8")
    # web variant (figures inline, no e-mail): rendered as report.html and offered as a download
    manuscript_md, citer = render_manuscript(f, fig_svg, False, decl, deposit, author_review)
    (REPORT_DIR / "manuscript_web.md").write_text(manuscript_md, encoding="utf-8")
    if citer.unused():
        print("References listed but not cited:", citer.unused())
    ctx = {"f": f, "fig": fig_svg, "table_html": table_html, "author_review": author_review, "cite": citer}
    # page templates
    senv = _env(ROOT / "site_src")
    write_json(EVIDENCE_DIR / "claims.json", f.claims())
    report_html = senv.get_template("report.html.j2").render(body=wrap_tables(md_to_html(manuscript_md)), **ctx)
    (SITE / "report.html").write_text(report_html, encoding="utf-8")
    index_html = senv.get_template("index.html.j2").render(**ctx, downloads=_downloads(f))
    (SITE / "index.html").write_text(index_html, encoding="utf-8")
    print(f"Rendered {SITE.relative_to(ROOT)}/index.html and report.html; claims: {len(f.items)}")


DOWNLOADS = [
    # (published name, source path relative to ROOT, description)
    ("trial-results-audit-source.zip", None, "Source archive: code, SQL, R reference, tests, documentation and result tables"),
    ("trial_results_audit_tables.xlsx", "results/trial_results_audit_tables.xlsx", "Aggregate result tables with a definitions sheet"),
    ("primary_outcome_group_tiers_long.csv", "results/tables/heldout/primary_outcome_group_tiers_long.csv", "Primary result by tier (unit: outcome group)"),
    ("flat_denominator_comparison.csv", "results/tables/heldout/flat_denominator_comparison.csv", "Denominator attached by the flat export (unit: measurement)"),
    ("retention_flat_vs_warehouse.csv", "results/tables/heldout/retention_flat_vs_warehouse.csv", "Exact-text retention by field family (unit: source scalar)"),
    ("checks_summary.csv", "results/tables/heldout/checks_summary.csv", "Check results (unit: applicable check)"),
    ("issue_ledger.csv", "results/tables/heldout/issue_ledger.csv", "Issue ledger with source pointers and evidence"),
    ("denominator_provenance.csv.gz", "results/exports/denominator_provenance.csv.gz", "Denominator provenance explorer export (unit: outcome group)"),
    ("evidence_table.csv.gz", "results/exports/evidence_table.csv.gz", "Cautious evidence table (unit: measurement)"),
    ("redcap_ledger_review_dictionary.csv", "redcap/trial_results_ledger_review_dictionary.csv", "REDCap data dictionary for reviewing ledger items (instrument, not a completed review)"),
    ("redcap_ledger_review_example_import.csv", "redcap/ledger_review_example_import.csv", "Example REDCap import with review fields blank"),
    ("redcap_local_checks.json", "redcap/redcap_local_checks.json", "Local format checks of the REDCap files (no server import)"),
    ("tableau_spec.md", "docs/tableau_spec.md", "Tableau import and interaction specification"),
    ("data_dictionary.csv", "docs/data_dictionary.csv", "Source-to-warehouse data dictionary"),
    ("rules.md", "docs/rules.md", "Tier rules and check catalog"),
    ("analysis_plan.md", "docs/analysis_plan.md", "Analysis plan with dated amendments"),
    ("claims.json", "evidence/claims.json", "Main reported numbers mapped to their output files"),
    ("source_manifest.json", "source_manifest.json", "Retrieval URLs, times, API version and SHA-256 of the raw pages"),
    ("manuscript.md", "report/manuscript_web.md", "Full report as Markdown"),
]


def _downloads(f: Facts) -> list[dict]:
    items = []
    for name, src, desc in DOWNLOADS:
        if src:
            sp = ROOT / src
            if not sp.exists():
                continue
            shutil.copy(sp, SITE / "downloads" / name)
        items.append({"name": name, "desc": desc, "path": f"downloads/{name}"})
    return items
