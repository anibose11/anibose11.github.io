"""Command-line entry point: python -m tra <stage> [options].

Stages run in order: acquire, freeze, build, analyze, freeze-parser, validate, posthoc, render, package.
The build and analyze stages run on the development portion before freeze-parser; after it, build runs on both
portions and analyze on the held-out portion. Each stage reads only frozen inputs from earlier stages and can be
rerun on its own, except freeze-parser and the held-out analysis, which run once.
"""
from __future__ import annotations

import argparse
import sys


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m tra", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="stage", required=True)

    a = sub.add_parser("acquire", help="retrieve and freeze the registry snapshot (network)")
    a.add_argument("--force", action="store_true", help="start a new snapshot even if one is frozen")

    sub.add_parser("freeze", help="build the frozen manifest, condition confirmation and development/held-out split")

    b = sub.add_parser("build", help="start the project PostgreSQL cluster, create schema, load snapshot, build flat baseline and reference")
    b.add_argument("--split", choices=["development", "heldout", "all"], default="development")
    b.add_argument("--skip-reference", action="store_true")
    b.add_argument("--fresh", action="store_true", help="drop and recreate the warehouse schemas first")

    z = sub.add_parser("analyze", help="tiers, checks, comparisons, tables and figures")
    z.add_argument("--split", choices=["development", "heldout", "all"], default="development")
    z.add_argument("--rerun-check", action="store_true",
                   help="for the held-out split: recompute into a separate run directory and compare with the frozen run")

    sub.add_parser("freeze-parser", help="hash and freeze parser, SQL and rule files before the held-out run")

    v = sub.add_parser("validate", help="tests, idempotency, reconciliation, round trip, reproducibility")
    v.add_argument("--quick", action="store_true", help="unit and fixture tests only")

    sub.add_parser("posthoc", help="post hoc descriptive tables added after the held-out run (labeled as post hoc)")
    sub.add_parser("render", help="report, manuscript, site pages and exports")
    sub.add_parser("package", help="source archive, handoff files and the project bundle ZIP")
    d = sub.add_parser("demo", help="fast fixture demo in a temporary database (software test, not study evidence)")
    d.add_argument("--keep", action="store_true")

    db = sub.add_parser("db", help="manage the project-local PostgreSQL cluster")
    db.add_argument("action", choices=["start", "stop", "status", "psql-uri"])

    args = p.parse_args(argv)

    if args.stage == "acquire":
        from .acquire import acquire
        acquire(force=args.force)
    elif args.stage == "freeze":
        from .manifest import freeze_manifest
        freeze_manifest()
    elif args.stage == "build":
        from .build import build
        build(split=args.split, skip_reference=args.skip_reference, fresh=args.fresh)
    elif args.stage == "analyze":
        from .analyze import analyze
        analyze(split=args.split, rerun_check=args.rerun_check)
    elif args.stage == "freeze-parser":
        from .freeze import freeze_parser
        freeze_parser()
    elif args.stage == "validate":
        from .validate import validate
        return validate(quick=args.quick)
    elif args.stage == "posthoc":
        from .posthoc import posthoc
        posthoc()
    elif args.stage == "render":
        from .render import render
        render()
    elif args.stage == "package":
        from .package import package
        package()
    elif args.stage == "demo":
        from .demo import demo
        return demo(keep=args.keep)
    elif args.stage == "db":
        from . import pg
        return pg.cli(args.action)
    return 0


if __name__ == "__main__":
    sys.exit(main())
