# Interval and presentation rules shared by R/estimate.R and the R tests.
# Implements the NCHS Data Presentation Standards for Proportions
# (Parker JD et al., Vital Health Stat 2(175), 2017).

# Korn-Graubard interval as specified by the NCHS standards (Parker et al. 2017).
# cap = FALSE is used only to explain a reconciliation difference (see the
# reference reconciliation table); every reported interval uses cap = TRUE.
kg_interval <- function(p, se, n, df, alpha = 0.05, cap = TRUE) {
  neff <- if (p > 0 && p < 1 && se > 0) p * (1 - p) / se^2 else n
  if (cap) neff <- min(n, neff)
  neff_df <- if (df >= 1 && n > 1) neff * (qt(1 - alpha / 2, n - 1) / qt(1 - alpha / 2, df))^2 else neff
  if (cap) neff_df <- min(neff_df, n)
  x <- p * neff_df
  lo <- if (x > 0) qbeta(alpha / 2, x, neff_df - x + 1) else 0
  hi <- if (x < neff_df) qbeta(1 - alpha / 2, x + 1, neff_df - x) else 1
  list(lo = lo, hi = hi, neff = neff, neff_df = neff_df)
}

nchs_rule <- function(p, n, n_events, neff, lo, hi, df) {
  width <- hi - lo
  rel <- if (p > 0) 100 * width / p else Inf
  zero <- n_events == 0 || n_events == n
  if (n < 30 || neff < 30) return(list(status = "suppressed", reason = "sample size or effective sample size below 30", width = width, rel = rel))
  if (width >= 0.30) return(list(status = "suppressed", reason = "absolute CI width 0.30 or more", width = width, rel = rel))
  if (width > 0.05 && rel > 130) return(list(status = "suppressed", reason = "relative CI width above 130 percent", width = width, rel = rel))
  flags <- c()
  if (zero) flags <- c(flags, "0 events or complement")
  if (df < 8) flags <- c(flags, "fewer than 8 degrees of freedom")
  if (length(flags)) return(list(status = "flagged", reason = paste(flags, collapse = "; "), width = width, rel = rel))
  list(status = "presented", reason = "", width = width, rel = rel)
}

