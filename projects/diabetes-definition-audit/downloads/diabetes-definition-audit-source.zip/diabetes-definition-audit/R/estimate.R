#!/usr/bin/env Rscript
# Survey estimation for the diabetes definition audit.
#
# Usage: Rscript R/estimate.R <release> <analytic_for_r.csv> <out_dir> <config_dir>
#
# Every estimate is a domain estimate from the full NHANES design (strata
# SDMVSTRA, PSUs SDMVPSU, nest = TRUE). Domains are formed by subsetting the
# design object, never by dropping records before the design is declared.
# Proportion intervals follow the NCHS Data Presentation Standards for
# Proportions (Korn-Graubard, with the degrees-of-freedom adjustment).

suppressPackageStartupMessages({
  library(survey)
  library(jsonlite)
  library(yaml)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 4) stop("usage: estimate.R <release> <analytic_for_r.csv> <out_dir> <config_dir>")
release <- args[[1]]; infile <- args[[2]]; outdir <- args[[3]]; cfgdir <- args[[4]]
# A fifth argument "fixture" marks the synthetic test fixture: group tables and
# the reconciliation with published NCHS estimates are skipped for it.
is_fixture <- length(args) >= 5 && identical(args[[5]], "fixture")
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

fr <- read.csv(infile, stringsAsFactors = FALSE)
fr$one <- 1
cfg <- yaml::read_yaml(file.path(cfgdir, "analysis_configs.yaml"))
rules <- yaml::read_yaml(file.path(cfgdir, "compatibility_rules.yaml"))
phen <- yaml::read_yaml(file.path(cfgdir, "phenotypes.yaml"))

options(survey.lonely.psu = "fail")  # any singleton stratum stops the run; checked below

script_dir <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(sub("^--file=", "", a[1]))) else "R"
})
source(file.path(script_dir, "functions.R"))

weight_col <- c(fasting = "w_fast", a1c_lab = "w_a1c", exam = "w_exam")
weight_var <- c()
for (v in names(rules$releases[[release]]$weights)) for (r in rules$releases[[release]]$weights[[v]]) weight_var[[r]] <- v
domain_col <- c(A = "in_a", H = "in_h", F = "in_f", P = "in_p", P_NARROW = "in_p_narrow")
pheno_col <- c(DX = "dx", A1C65 = "a1c65", FPG126 = "fpg126", BIO_EITHER = "bio_either",
               TOTAL_A1C_FPG = "total_a1c_fpg", TOTAL_A1C = "total_a1c")
domain_label <- sapply(rules$domains, function(d) d$label)

designs <- list()
get_design <- function(role) {
  if (is.null(designs[[role]])) {
    designs[[role]] <<- svydesign(ids = ~sdmvpsu, strata = ~sdmvstra,
                                  weights = as.formula(paste0("~", weight_col[[role]])),
                                  nest = TRUE, data = fr)
  }
  designs[[role]]
}
unit_design <- function(data) svydesign(ids = ~sdmvpsu, strata = ~sdmvstra, weights = ~one, nest = TRUE, data = data)

full_df <- length(unique(paste(fr$sdmvstra, fr$sdmvpsu))) - length(unique(fr$sdmvstra))
domain_df <- function(mask) {
  s <- fr[mask, ]
  length(unique(paste(s$sdmvstra, s$sdmvpsu))) - length(unique(s$sdmvstra))
}
domain_singletons <- function(mask) {
  s <- fr[mask, ]
  k <- tapply(s$sdmvpsu, s$sdmvstra, function(x) length(unique(x)))
  sum(k < 2)
}

# Proportion of phenotype `pc` (column name) in domain mask with weight role.
estimate_prop <- function(pc, dmask, role) {
  des <- get_design(role)
  sub <- des[dmask, ]
  f <- as.formula(paste0("~", pc))
  m <- svymean(f, sub)
  p <- unname(coef(m)[1]); se <- unname(SE(m)[1])
  n <- sum(dmask); npos <- sum(dmask & fr[[pc]] == 1, na.rm = TRUE)
  ddf <- domain_df(dmask)
  kg <- kg_interval(p, se, n, ddf)
  # With fewer than 1 degree of freedom no t-based interval exists; the
  # estimate is suppressed by the sample size rule in that case anyway.
  ok_df <- ddf >= 1
  lg <- if (ok_df) svyciprop(f, sub, method = "logit", df = ddf) else structure(NA, ci = c(NA_real_, NA_real_))
  sb <- if (ok_df) svyciprop(f, sub, method = "beta", df = ddf) else structure(NA, ci = c(NA_real_, NA_real_))
  pop <- svytotal(~one, sub)
  rule <- nchs_rule(p, n, npos, kg$neff, kg$lo, kg$hi, ddf)
  data.frame(
    estimate = p, se = se, ci_low = kg$lo, ci_high = kg$hi,
    ci_low_logit = unname(attr(lg, "ci")[1]), ci_high_logit = unname(attr(lg, "ci")[2]),
    ci_low_svy_beta = unname(attr(sb, "ci")[1]), ci_high_svy_beta = unname(attr(sb, "ci")[2]),
    ci_low_wald = if (ok_df) p - qt(0.975, ddf) * se else NA_real_,
    ci_high_wald = if (ok_df) p + qt(0.975, ddf) * se else NA_real_,
    n_unweighted = n, n_positive_unweighted = npos,
    weighted_denominator = unname(coef(pop)[1]),
    n_effective = kg$neff, n_effective_df_adjusted = kg$neff_df,
    design_effect = if (p > 0 && p < 1) se^2 / (p * (1 - p) / n) else NA_real_,
    df_domain = ddf, df_full_design = full_df, singleton_strata_in_domain = domain_singletons(dmask),
    nchs_status = rule$status, nchs_reason = rule$reason,
    ci_width = rule$width, ci_relative_width_pct = rule$rel,
    stringsAsFactors = FALSE)
}

# Joint linearization of two ratio estimators that may use different domains
# and weights: totals on a unit-weight design with the same strata and PSUs.
joint_contrast <- function(pcL, maskL, roleL, pcR, maskR, roleR) {
  d <- fr
  yL <- ifelse(maskL, d[[pcL]], 0); yR <- ifelse(maskR, d[[pcR]], 0)
  wL <- d[[weight_col[[roleL]]]]; wR <- d[[weight_col[[roleR]]]]
  d$nL <- wL * yL * maskL; d$dL <- wL * maskL
  d$nR <- wR * yR * maskR; d$dR <- wR * maskR
  ud <- unit_design(d)
  tt <- svytotal(~nL + dL + nR + dR, ud)
  diff <- svycontrast(tt, quote(nL / dL - nR / dR))
  left <- svycontrast(tt, quote(nL / dL)); right <- svycontrast(tt, quote(nR / dR))
  list(estimate = unname(coef(diff)), se = unname(SE(diff)),
       left = unname(coef(left)), left_se = unname(SE(left)),
       right = unname(coef(right)), right_se = unname(SE(right)))
}

# Paired contrast in one domain with one weight: joint svymean and svycontrast.
paired_contrast <- function(pcL, pcR, dmask, role) {
  sub <- get_design(role)[dmask, ]
  m <- svymean(as.formula(paste0("~", pcL, "+", pcR)), sub)
  cc <- svycontrast(m, setNames(c(1, -1), c(pcL, pcR)))
  list(estimate = unname(coef(cc)), se = unname(SE(cc)), cov = unname(vcov(m)[1, 2]))
}

# ---------------------------------------------------------------- configurations
conf_all <- c(cfg$configurations, cfg$auxiliary)
conf_index <- list()
for (c in conf_all) conf_index[[c$id]] <- list(phenotype = c$phenotype, domain = c$domain, weight_role = c$weight_role, role = c$role)
for (s in cfg$sensitivity_variants) {
  b <- conf_index[[s$base]]
  conf_index[[s$id]] <- list(phenotype = b$phenotype, domain = s$domain, weight_role = b$weight_role, role = s$role)
}

est_rows <- list()
for (id in names(conf_index)) {
  ci <- conf_index[[id]]
  mask <- fr[[domain_col[[ci$domain]]]] == 1
  r <- estimate_prop(pheno_col[[ci$phenotype]], mask, ci$weight_role)
  est_rows[[id]] <- cbind(data.frame(
    release = release, config_id = id, phenotype = ci$phenotype,
    phenotype_label = phen$phenotypes[[ci$phenotype]]$label,
    sample_universe = paste0(ci$domain, ": ", domain_label[[ci$domain]]),
    domain = ci$domain, weight = weight_var[[ci$weight_role]], role = ci$role,
    stringsAsFactors = FALSE), r)
}
estimates <- do.call(rbind, est_rows)
write.csv(estimates, file.path(outdir, "estimates.csv"), row.names = FALSE)

# --------------------------------------------------------------------- contrasts
con_rows <- list()
for (k in cfg$contrasts) {
  L <- conf_index[[k$left]]; R <- conf_index[[k$right]]
  mL <- fr[[domain_col[[L$domain]]]] == 1; mR <- fr[[domain_col[[R$domain]]]] == 1
  same <- identical(L$domain, R$domain) && identical(L$weight_role, R$weight_role)
  jc <- joint_contrast(pheno_col[[L$phenotype]], mL, L$weight_role, pheno_col[[R$phenotype]], mR, R$weight_role)
  method <- "joint linearization of weighted totals (unit-weight design, delta method)"
  est <- jc$estimate; se <- jc$se; se_alt <- NA_real_
  if (same) {
    pc <- paired_contrast(pheno_col[[L$phenotype]], pheno_col[[R$phenotype]], mL, L$weight_role)
    se_alt <- se; est <- pc$estimate; se <- pc$se
    method <- "paired: joint svymean in one domain with one weight, svycontrast"
  }
  dfc <- domain_df(mL | mR)
  tval <- est / se
  con_rows[[k$id]] <- data.frame(
    release = release, contrast_id = k$id, left = k$left, right = k$right, kind = k$kind, label = k$label,
    left_phenotype = L$phenotype, left_universe = L$domain, left_weight = weight_var[[L$weight_role]],
    right_phenotype = R$phenotype, right_universe = R$domain, right_weight = weight_var[[R$weight_role]],
    left_n = sum(mL), right_n = sum(mR),
    left_estimate = jc$left, right_estimate = jc$right,
    estimate = est, se = se, ci_low = est - qt(0.975, dfc) * se, ci_high = est + qt(0.975, dfc) * se,
    t = tval, df = dfc, p_value = 2 * pt(-abs(tval), dfc),
    se_joint_totals_method = jc$se, se_difference_between_methods = if (same) abs(se - jc$se) else NA_real_,
    method = method, stringsAsFactors = FALSE)
}
contrasts <- do.call(rbind, con_rows)
write.csv(contrasts, file.path(outdir, "contrasts.csv"), row.names = FALSE)

# Exact additivity of the declared decompositions.
getc <- function(id) contrasts[contrasts$contrast_id == id, "estimate"]
decomp <- data.frame(
  release = release,
  decomposition = c("HbA1c (domain H) minus glucose (domain P)", "Composite without glucose (H) minus full composite (P)"),
  naive_contrast = c("C3", "C5"), naive_difference = c(getc("C3"), getc("C5")),
  sample_part_contrast = c("C2", "C6"), sample_part = c(getc("C2"), getc("C6")),
  definition_part_contrast = c("C1", "C7"), definition_part = c(getc("C1"), getc("C7")),
  stringsAsFactors = FALSE)
decomp$additivity_error <- decomp$naive_difference - (decomp$sample_part + decomp$definition_part)
describe <- function(id) {
  x <- contrasts[contrasts$contrast_id == id, ]
  sprintf("%s (%s, %s, n = %d) minus %s (%s, %s, n = %d)", x$left_phenotype, x$left_universe, x$left_weight, x$left_n,
          x$right_phenotype, x$right_universe, x$right_weight, x$right_n)
}
decomp$naive_comparison <- sapply(decomp$naive_contrast, describe)
decomp$sample_part_comparison <- sapply(decomp$sample_part_contrast, describe)
decomp$definition_part_comparison <- sapply(decomp$definition_part_contrast, describe)
write.csv(decomp, file.path(outdir, "decomposition.csv"), row.names = FALSE)

# -------------------------------------------------------------------- agreement
mP <- fr$in_p == 1
fr$c11 <- as.integer(fr$a1c65 == 1 & fr$fpg126 == 1)
fr$c10 <- as.integer(fr$a1c65 == 1 & fr$fpg126 == 0)
fr$c01 <- as.integer(fr$a1c65 == 0 & fr$fpg126 == 1)
fr$c00 <- as.integer(fr$a1c65 == 0 & fr$fpg126 == 0)
designs <- list()  # rebuild with the new columns
cells <- c(c11 = "HbA1c >= 6.5 and glucose >= 126", c10 = "HbA1c >= 6.5 only", c01 = "glucose >= 126 only", c00 = "both below threshold")
agr <- list()
for (cc in names(cells)) {
  r <- estimate_prop(cc, mP, "fasting")
  agr[[cc]] <- cbind(data.frame(release = release, measure = paste0("cell ", cc), description = cells[[cc]],
                                sample_universe = paste0("P: ", domain_label[["P"]]), weight = weight_var[["fasting"]],
                                stringsAsFactors = FALSE), r[, c("estimate", "se", "ci_low", "ci_high", "n_unweighted", "n_positive_unweighted", "df_domain", "nchs_status", "nchs_reason")])
}
subP <- get_design("fasting")[mP, ]
m4 <- svymean(~c11 + c10 + c01 + c00, subP)
dfP <- domain_df(mP)
derived <- list(
  percent_agreement = quote(c11 + c00),
  cohens_kappa = quote(((c11 + c00) - ((c11 + c10) * (c11 + c01) + (c00 + c01) * (c00 + c10))) /
                         (1 - ((c11 + c10) * (c11 + c01) + (c00 + c01) * (c00 + c10)))),
  share_of_either_positive_hba1c_only = quote(c10 / (c11 + c10 + c01)),
  share_of_either_positive_glucose_only = quote(c01 / (c11 + c10 + c01)),
  share_of_either_positive_both = quote(c11 / (c11 + c10 + c01)),
  share_of_glucose_positive_also_hba1c_positive = quote(c11 / (c11 + c01)),
  share_of_hba1c_positive_also_glucose_positive = quote(c11 / (c11 + c10)))
for (nm in names(derived)) {
  sc <- svycontrast(m4, derived[[nm]])
  e <- unname(coef(sc)); s <- unname(SE(sc))
  agr[[nm]] <- data.frame(release = release, measure = nm, description = deparse1(derived[[nm]]),
                          sample_universe = paste0("P: ", domain_label[["P"]]), weight = weight_var[["fasting"]],
                          estimate = e, se = s, ci_low = e - qt(0.975, dfP) * s, ci_high = e + qt(0.975, dfP) * s,
                          n_unweighted = sum(mP), n_positive_unweighted = NA, df_domain = dfP,
                          nchs_status = "not applicable (derived ratio; Wald t interval)", nchs_reason = "", stringsAsFactors = FALSE)
}
agreement <- do.call(rbind, agr)
write.csv(agreement, file.path(outdir, "agreement.csv"), row.names = FALSE)

# ---------------------------------------------------------------------- overlap
ov <- list()
for (dx in 1:0) for (a in 1:0) for (g in 1:0) {
  nm <- sprintf("ov_dx%d_a%d_g%d", dx, a, g)
  fr[[nm]] <- as.integer(fr$dx == dx & fr$a1c65 == a & fr$fpg126 == g)
}
designs <- list()
for (dx in 1:0) for (a in 1:0) for (g in 1:0) {
  nm <- sprintf("ov_dx%d_a%d_g%d", dx, a, g)
  r <- estimate_prop(nm, mP, "fasting")
  ov[[nm]] <- cbind(data.frame(release = release, cell = nm,
                               diagnosed = c("no", "yes")[dx + 1], hba1c_6_5_or_more = c("no", "yes")[a + 1],
                               glucose_126_or_more = c("no", "yes")[g + 1],
                               sample_universe = paste0("P: ", domain_label[["P"]]), weight = weight_var[["fasting"]],
                               stringsAsFactors = FALSE),
                    r[, c("estimate", "se", "ci_low", "ci_high", "n_unweighted", "n_positive_unweighted", "df_domain", "nchs_status", "nchs_reason")])
}
write.csv(do.call(rbind, ov), file.path(outdir, "overlap.csv"), row.names = FALSE)

# ---------------------------------- sensitivity 3: diagnosed, both below threshold
fr$bioneg <- as.integer(fr$bio_either == 0)
designs <- list()
s3 <- list()
for (lvl in c("all diagnosed", "treated", "not treated", "treatment unknown")) {
  base <- mP & fr$dx == 1 & !is.na(fr$dx)
  m <- switch(lvl,
              "all diagnosed" = base,
              "treated" = base & !is.na(fr$dx_treated) & fr$dx_treated == 1,
              "not treated" = base & !is.na(fr$dx_treated) & fr$dx_treated == 0,
              "treatment unknown" = base & is.na(fr$dx_treated))
  if (sum(m) == 0) next
  r <- estimate_prop("bioneg", m, "fasting")
  s3[[lvl]] <- cbind(data.frame(release = release, group = lvl,
                                measure = "share of diagnosed adults with HbA1c < 6.5 and glucose < 126",
                                sample_universe = paste0("P with DX = 1 (", lvl, ")"), weight = weight_var[["fasting"]],
                                stringsAsFactors = FALSE), r)
}
write.csv(do.call(rbind, s3), file.path(outdir, "s3_diagnosed_below_threshold.csv"), row.names = FALSE)

if (!is_fixture) {
# ------------------------------------------------- missingness by demographic group
mA <- fr$in_a == 1
fr$miss_a1c <- as.integer(fr$a1c_status != "measured")
fr$fs_not_assigned <- as.integer(fr$fast_status == "not_in_fasting_subsample")
fr$fs_no_blood <- as.integer(fr$fast_status == "subsample_no_blood")
fr$fs_criterion <- as.integer(fr$fast_status == "fasting_criterion_not_met")
fr$fs_valid <- as.integer(fr$fast_status == "valid")
fr$not_in_p <- as.integer(fr$in_p != 1)
fr$overall <- "All adults in domain A"
designs <- list()
statuses <- c(miss_a1c = "No HbA1c result (no blood or no result)",
              fs_not_assigned = "Not assigned to the fasting subsample",
              fs_no_blood = "Assigned, no blood specimen",
              fs_criterion = "Assigned, fasted outside 8 to <24 h",
              fs_valid = "Valid fasting glucose",
              not_in_p = "Not in the common paired domain P")
miss <- list()
for (gv in c("overall", "age_group", "sex_label", "reth_label")) {
  for (lv in sort(unique(fr[[gv]][mA]))) {
    gm <- mA & fr[[gv]] == lv
    for (st in names(statuses)) {
      r <- estimate_prop(st, gm, "exam")
      miss[[paste(gv, lv, st)]] <- cbind(data.frame(release = release, group_variable = gv, group = lv,
                                                   status = st, status_label = statuses[[st]],
                                                   sample_universe = paste0("A: ", domain_label[["A"]]),
                                                   weight = weight_var[["exam"]], stringsAsFactors = FALSE),
                                        r[, c("estimate", "se", "ci_low", "ci_high", "n_unweighted", "n_positive_unweighted", "df_domain", "nchs_status", "nchs_reason")])
    }
  }
}
write.csv(do.call(rbind, miss), file.path(outdir, "missingness_by_group.csv"), row.names = FALSE)

# ------------------------------------- paired estimates by demographic group (P)
pg <- list()
for (gv in c("age_group", "sex_label", "reth_label")) {
  for (lv in sort(unique(fr[[gv]][mP]))) {
    gm <- mP & fr[[gv]] == lv
    a <- estimate_prop("a1c65", gm, "fasting"); g <- estimate_prop("fpg126", gm, "fasting")
    pc <- paired_contrast("a1c65", "fpg126", gm, "fasting")
    dfg <- domain_df(gm)
    pg[[paste(gv, lv)]] <- data.frame(
      release = release, group_variable = gv, group = lv,
      sample_universe = paste0("P: ", domain_label[["P"]], ", ", lv), weight = weight_var[["fasting"]],
      n_unweighted = sum(gm),
      hba1c_estimate = a$estimate, hba1c_se = a$se, hba1c_ci_low = a$ci_low, hba1c_ci_high = a$ci_high, hba1c_n_positive = a$n_positive_unweighted, hba1c_nchs_status = a$nchs_status,
      glucose_estimate = g$estimate, glucose_se = g$se, glucose_ci_low = g$ci_low, glucose_ci_high = g$ci_high, glucose_n_positive = g$n_positive_unweighted, glucose_nchs_status = g$nchs_status,
      difference = pc$estimate, difference_se = pc$se,
      difference_ci_low = pc$estimate - qt(0.975, dfg) * pc$se, difference_ci_high = pc$estimate + qt(0.975, dfg) * pc$se,
      difference_note = if (a$nchs_status == "suppressed" || g$nchs_status == "suppressed") "a component estimate is suppressed under the NCHS standards; interpret the difference with caution" else "",
      df_domain = dfg, singleton_strata_in_domain = domain_singletons(gm), stringsAsFactors = FALSE)
  }
}
write.csv(do.call(rbind, pg), file.path(outdir, "paired_by_group.csv"), row.names = FALSE)
}

# --------------------------------------------------------------- design checks
k1 <- estimates[estimates$config_id == "K1", ]
designs <- list()
pc12 <- paired_contrast("a1c65", "fpg126", fr$in_p == 1, "fasting")
# Self-contrast used only to read the totals-method SE of K1; the difference is
# identically zero, so its own SE is NaN by construction and is ignored.
jk1 <- suppressWarnings(joint_contrast("a1c65", fr$in_p == 1, "fasting", "a1c65", fr$in_p == 1, "fasting"))
checks <- list(
  release = release,
  r_version = R.version.string,
  survey_version = as.character(packageVersion("survey")),
  n_records_in_design = nrow(fr),
  n_strata = length(unique(fr$sdmvstra)),
  n_psu = length(unique(paste(fr$sdmvstra, fr$sdmvpsu))),
  df_full_design = full_df,
  singleton_strata_full_design = domain_singletons(rep(TRUE, nrow(fr))),
  lonely_psu_option = getOption("survey.lonely.psu"),
  df_by_domain = lapply(domain_col, function(d) domain_df(fr[[d]] == 1)),
  singleton_strata_by_domain = lapply(domain_col, function(d) domain_singletons(fr[[d]] == 1)),
  k1_se_svymean = k1$se,
  k1_se_joint_totals = jk1$left_se,
  k1_se_abs_difference = abs(k1$se - jk1$left_se),
  max_abs_se_difference_paired_vs_totals = max(contrasts$se_difference_between_methods, na.rm = TRUE),
  max_abs_decomposition_additivity_error = max(abs(decomp$additivity_error)),
  k1_k2_sampling_covariance = pc12$cov,
  k1_k2_sampling_correlation = pc12$cov / (estimates$se[estimates$config_id == "K1"] * estimates$se[estimates$config_id == "K2"]),
  c1_se_paired = as.numeric(pc12$se),
  c1_se_if_covariance_ignored_illustration_only = sqrt(estimates$se[estimates$config_id == "K1"]^2 + estimates$se[estimates$config_id == "K2"]^2)
)
writeLines(toJSON(checks, auto_unbox = TRUE, digits = NA, pretty = TRUE), file.path(outdir, "design_checks.json"))
# ---------------------------------------- external reconciliation (published NCHS)
ref_all <- yaml::read_yaml(file.path(cfgdir, "reference_aggregates.yaml"))
ref <- ref_all$nchs_db516
recon <- list()
if (identical(ref$release, release) && !is_fixture) {
  fr$undx <- as.integer(fr$dx == 0 & fr$bio_either == 1)
  fr$age_nchs <- ifelse(fr$age <= 39, "20-39", ifelse(fr$age <= 59, "40-59", "60+"))
  designs <- list()
  measure_col <- c(total = "total_a1c_fpg", diagnosed = "dx", undiagnosed = "undx")
  for (r in ref$rows) {
    g <- switch(r$group, all = rep(TRUE, nrow(fr)), men = fr$sex_label == "Male",
                women = fr$sex_label == "Female", fr$age_nchs == r$group)
    m <- mP & g
    e <- estimate_prop(measure_col[[r$measure]], m, "fasting")
    ours <- 100 * c(e$estimate, e$ci_low, e$ci_high, e$se)
    unc <- kg_interval(e$estimate, e$se, e$n_unweighted, e$df_domain, cap = FALSE)
    recon[[length(recon) + 1]] <- data.frame(
      release = release, source = "NCHS Data Brief 516", table = r$table, measure = r$measure, group = r$group,
      sample_universe = "P: adults 20+, examined, not pregnant, DIQ010 answered, valid fasting glucose and HbA1c",
      weight = weight_var[["fasting"]],
      published_n = r$sample_n, our_n = e$n_unweighted,
      published_percent = r$percent, our_percent = ours[1],
      published_ci_low = r$ci_low, our_ci_low = ours[2], published_ci_high = r$ci_high, our_ci_high = ours[3],
      published_se = r$se, our_se = ours[4],
      n_match = r$sample_n == e$n_unweighted,
      percent_match = abs(ours[1] - r$percent) <= 0.05 + 1e-9,
      ci_match = abs(ours[2] - r$ci_low) <= 0.05 + 1e-9 && abs(ours[3] - r$ci_high) <= 0.05 + 1e-9,
      se_match = abs(ours[4] - r$se) <= 0.05 + 1e-9,
      our_ci_low_without_neff_cap = 100 * unc$lo, our_ci_high_without_neff_cap = 100 * unc$hi,
      ci_match_without_neff_cap = abs(100 * unc$lo - r$ci_low) <= 0.05 + 1e-9 && abs(100 * unc$hi - r$ci_high) <= 0.05 + 1e-9,
      stringsAsFactors = FALSE)
  }
}
for (r in ref$sample_size_only) {
  if (identical(r$release, release) && !is_fixture) {
    recon[[length(recon) + 1]] <- data.frame(
      release = release, source = "NCHS Data Brief 516", table = r$table, measure = "sample size", group = r$group,
      sample_universe = "P", weight = weight_var[["fasting"]], published_n = r$sample_n, our_n = sum(mP),
      published_percent = NA, our_percent = NA, published_ci_low = NA, our_ci_low = NA,
      published_ci_high = NA, our_ci_high = NA, published_se = NA, our_se = NA,
      n_match = r$sample_n == sum(mP), percent_match = NA, ci_match = NA, se_match = NA,
      our_ci_low_without_neff_cap = NA, our_ci_high_without_neff_cap = NA, ci_match_without_neff_cap = NA,
      stringsAsFactors = FALSE)
  }
}
if (length(recon)) write.csv(do.call(rbind, recon), file.path(outdir, "reference_reconciliation.csv"), row.names = FALSE)

# ------------------------------------------- post hoc analyses (not prespecified)
# Added after the planned analyses (analysis plan amendment 8) and reported as
# exploratory: the parts of the primary contrast among adults without and with a
# reported diagnosis (they sum to C1), agreement among adults without a reported
# diagnosis, and the primary contrast with the HbA1c cut point one reporting unit
# (0.1) below and above 6.5%.
if (!is_fixture) {
fr$undx_a1c <- as.integer(fr$dx == 0 & fr$a1c65 == 1)
fr$undx_fpg <- as.integer(fr$dx == 0 & fr$fpg126 == 1)
fr$dx_a1c <- as.integer(fr$dx == 1 & fr$a1c65 == 1)
fr$dx_fpg <- as.integer(fr$dx == 1 & fr$fpg126 == 1)
fr$a1c64 <- as.integer(round(fr$lbxgh * 10) >= 64)
fr$a1c66 <- as.integer(round(fr$lbxgh * 10) >= 66)
designs <- list()
uP <- paste0("P: ", domain_label[["P"]])
ph_row <- function(id, label, universe, mask, est, se, left = NULL, right = NULL, interval) {
  d <- domain_df(mask); t <- est / se
  na <- function(x, f) if (is.null(x)) NA else x[[f]]
  data.frame(release = release, analysis = id, label = label, sample_universe = universe,
             weight = weight_var[["fasting"]], n_unweighted = sum(mask),
             left_estimate = na(left, "estimate"), left_ci_low = na(left, "ci_low"), left_ci_high = na(left, "ci_high"),
             left_n_positive = na(left, "n_positive_unweighted"), left_nchs_status = na(left, "nchs_status"),
             right_estimate = na(right, "estimate"), right_ci_low = na(right, "ci_low"), right_ci_high = na(right, "ci_high"),
             right_n_positive = na(right, "n_positive_unweighted"), right_nchs_status = na(right, "nchs_status"),
             estimate = est, se = se, ci_low = est - qt(0.975, d) * se, ci_high = est + qt(0.975, d) * se,
             df = d, p_value = 2 * pt(-abs(t), d), interval = interval, stringsAsFactors = FALSE)
}
paired_row <- function(id, label, pcL, pcR) {
  pc <- paired_contrast(pcL, pcR, mP, "fasting")
  ph_row(id, label, uP, mP, pc$estimate, pc$se,
         left = estimate_prop(pcL, mP, "fasting"), right = estimate_prop(pcR, mP, "fasting"),
         interval = "difference: 95% t interval (paired); components: Korn-Graubard")
}
ph <- list(
  paired_row("PH1", "No reported diagnosis and HbA1c >= 6.5 minus no reported diagnosis and glucose >= 126 (share of all adults in P)", "undx_a1c", "undx_fpg"),
  paired_row("PH2", "Reported diagnosis and HbA1c >= 6.5 minus reported diagnosis and glucose >= 126 (share of all adults in P)", "dx_a1c", "dx_fpg"))
mU <- mP & fr$dx == 0
mu4 <- svymean(~c11 + c10 + c01 + c00, get_design("fasting")[mU, ])
uU <- paste0(uP, ", no reported diagnosis")
undx_derived <- list(
  PH3_kappa = c("Cohen's kappa, HbA1c >= 6.5 versus glucose >= 126, adults without a reported diagnosis",
                quote(((c11 + c00) - ((c11 + c10) * (c11 + c01) + (c00 + c01) * (c00 + c10))) /
                        (1 - ((c11 + c10) * (c11 + c01) + (c00 + c01) * (c00 + c10))))),
  PH3_agreement = c("Percent agreement, adults without a reported diagnosis", quote(c11 + c00)),
  PH3_one_test_only = c("Share above only one threshold among adults above either, no reported diagnosis",
                        quote((c10 + c01) / (c11 + c10 + c01))))
for (nm in names(undx_derived)) {
  sc <- svycontrast(mu4, undx_derived[[nm]][[2]])
  ph[[length(ph) + 1]] <- ph_row(nm, undx_derived[[nm]][[1]], uU, mU, unname(coef(sc)), unname(SE(sc)),
                                 interval = "95% t interval (delta method)")
}
ph[[length(ph) + 1]] <- paired_row("PH4", "HbA1c >= 6.4 minus glucose >= 126", "a1c64", "fpg126")
ph[[length(ph) + 1]] <- paired_row("PH5", "HbA1c >= 6.6 minus glucose >= 126", "a1c66", "fpg126")
posthoc <- do.call(rbind, ph)
# The two parts of the primary contrast must add up to it exactly.
stopifnot(abs(sum(posthoc$estimate[posthoc$analysis %in% c("PH1", "PH2")]) - getc("C1")) < 1e-12)
write.csv(posthoc, file.path(outdir, "posthoc.csv"), row.names = FALSE)
}

cat("estimation complete:", release, nrow(estimates), "estimates,", nrow(contrasts), "contrasts\n")
