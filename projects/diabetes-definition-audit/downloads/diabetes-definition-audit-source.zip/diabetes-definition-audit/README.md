# Diabetes estimates under different definitions and laboratory denominators

A phenotype and denominator audit for diabetes prevalence estimated from NHANES. It separates how much of the difference between an HbA1c-based and a fasting glucose-based estimate comes from the definition and how much from the laboratory sample and survey weight in which each biomarker is measured, and it provides a checker that refuses incompatible phenotype, domain, and weight combinations.

Data: NHANES August 2021-August 2023 (primary) and NHANES 2017-March 2020 pre-pandemic (separate replication), CDC National Center for Health Statistics public-use files. Results are estimates under surveillance definitions, not diagnoses of individual people.

## Main results (August 2021-August 2023, adults 20+, not pregnant)

| Estimate | Sample universe, unweighted n, and weight | Weighted value (95% CI) |
|---|---|---|
| HbA1c at or above 6.5% | paired domain P, n = 2,938, WTSAF2YR | 10.8% (9.1 to 12.7) |
| Fasting glucose at or above 126 mg/dL | paired domain P, n = 2,938, WTSAF2YR | 11.2% (9.5 to 13.1) |
| Paired difference, HbA1c minus glucose | domain P, WTSAF2YR | -0.41 points (-1.15 to 0.33) |
| HbA1c at or above 6.5% | HbA1c laboratory domain H, n = 5,729, WTPH2YR | 10.5% (9.2 to 12.0) |
| Sample and weight part, HbA1c in H minus in P | joint linearization | -0.24 points (-1.44 to 0.96) |

Percentages are weighted survey estimates; n is the unweighted count. These values are copied from `results/tables/2021-2023/`; `evidence/claims.json` maps every headline number to its file, row, numerator, denominator, and source checksums. The composite and its parts reproduce NCHS Data Brief 516.

## Requirements

- macOS (tested) or Linux, Python 3.12 or newer (the locked numpy requires it; 3.13.5 tested), R 4.5 (4.5.1 tested) with internet access to CRAN for `make setup`.
- Quarto 1.6 for the documents (the version bundled with RStudio is found automatically; set `QUARTO=/path/to/quarto` otherwise). The analysis itself does not need Quarto.
- About 30 MB of disk for the NHANES files.

## Reproduce

```
make setup          # .venv from requirements.lock, R library from renv.lock
make demo           # under 20 seconds: synthetic fixture through the real build SQL and R code
make test           # Python and R tests
make acquire        # downloads the 12 data files and their documentation and listing pages (about 19 MB) by following the official listing links
make pipeline       # build, analyze, validate, render (about 20 seconds)
make repro-check    # rerun from cache and compare every table value within 1e-9
```

Check a configuration before using it:

```
make check-config ARGS="--phenotype FPG126 --domain H --weight WTPH2YR"   # refused, exit code 2
make check-config ARGS="--phenotype A1C65 --domain P --weight WTSAF2YR"   # accepted
make check-config ARGS="--list"
```

A refusal is the intended result for such a request: it means the request would compare different denominators or use a weight that does not belong to the sample.

## Stages and outputs

Each target runs `PYTHONPATH=src .venv/bin/python -m ddaudit <stage>` inside the project environment.

| Stage | Command | Main outputs |
|---|---|---|
| acquire | `make acquire` | `data/raw/<release>/` (XPT, documentation and listing snapshots), `source_manifest.json` |
| build | `make build` | analytic frame (Python + DuckDB SQL in `sql/`), `results/tables/<release>/participant_flow.csv`, join checks, codebook reconciliation |
| analyze | `make analyze` | configuration check, `R/estimate.R` survey estimates, contrasts, decomposition, agreement, overlap, group tables, NCHS reconciliation, direct cross-tab and second-implementation checks |
| validate | `make validate` | `results/validation/validation_summary.csv` |
| render | `make render` | figures, `results/exports/` (Excel workbook with a definitions sheet, Tableau-ready CSVs), `evidence/claims.json`, manuscript and supplement (HTML, PDF, DOCX) |

## Repository map

- `config/` phenotype specification, compatibility rules, the eight configurations, sources, published reference aggregates
- `sql/` join checks, analytic frame, phenotypes, participant flow
- `R/` survey estimation (`estimate.R`) and interval and presentation rules (`functions.R`)
- `src/ddaudit/` Python package (acquire, build, checker, analyze, validate, figures, render, demo, repro)
- `docs/` analysis plan (frozen copy and hash), contribution decision, prior art, literature search log, phenotype specification, data dictionary, data sources, Tableau specification, research notes
- `tests/` Python and R tests and the labeled synthetic fixture
- `manuscript/` current editable templates; `manuscript/build/` legacy generated renders retained for provenance. The reviewed journal files and public exports are supplied separately from this source archive.

## Software checks, source reconciliation, and external reconciliation

These are kept apart. Software checks (joins, domain nesting, Python reproduction of every reported point estimate, and a second implementation of the linearized variance for every proportion and contrast) test the code. Source reconciliation compares file counts with the NCHS codebooks. External reconciliation compares estimates with NCHS Data Brief 516. None of them is independent expert review of the conclusions.

`.venv/bin/python -I scripts/independent_recheck.py OUT_DIR` repeats the headline numbers without the `ddaudit` package: it downloads the twelve files again into OUT_DIR, compares their checksums with `source_manifest.json`, rebuilds domains P and H with pandas, recomputes the primary estimates, their linearized standard errors, the two contrasts, and the 18 NCHS Data Brief 516 rows, and checks the documentation pages for the variable names and codes used. It exits with status 0 only if the checksums, the rebuilt estimates, the 18 Data Brief rows, and the documentation terms all agree.

## Limitations

Single measurements, self-reported diagnosis, an HbA1c instrument change during 2021-2023 with no participant-level instrument flag or changeover date, low 2021-2023 response, no reweighting for item nonresponse, and pregnancy identifiable only at ages 20 to 44. See the Limitations section in the current template (`manuscript/manuscript.md.tmpl`) or reviewed journal manuscript. `make render` regenerates `manuscript/build/`; the existing build files predate the final editorial review and must not be used as current submission or public exports.

## License

Code: MIT (see `LICENSE`). NHANES data are public-use files from NCHS and are not redistributed here beyond what `make acquire` downloads; see `THIRD_PARTY_NOTICES.md`.
