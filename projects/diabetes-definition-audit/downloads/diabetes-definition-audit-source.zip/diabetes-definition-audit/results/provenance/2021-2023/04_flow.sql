-- Participant flow. Each row is a sequential step; n is the number of
-- participants remaining after the step and n_removed the number excluded at
-- that step. weight_sum is the sum of the weight named in weight_used for the
-- participants remaining (an estimate of the population represented).
WITH a AS (SELECT * FROM analytic),
steps AS (
    SELECT 1 AS step, 'all' AS branch, 'Participants in the demographics file' AS description,
           count(*) AS n, sum(w_int) AS weight_sum, 'interview weight' AS weight_used FROM a
    UNION ALL
    SELECT 2, 'all', 'Interviewed and examined (RIDSTATR = 2)',
           count(*), sum(w_exam), 'examination weight' FROM a WHERE ridstatr = 2
    UNION ALL
    SELECT 3, 'all', 'Aged 20 or older',
           count(*), sum(w_exam), 'examination weight' FROM a WHERE ridstatr = 2 AND age >= 20
    UNION ALL
    SELECT 4, 'all', 'Excluding pregnant at the examination (RIDEXPRG = 1)',
           count(*), sum(w_exam), 'examination weight' FROM a
    WHERE ridstatr = 2 AND age >= 20 AND preg_status <> 'pregnant_at_exam'
    UNION ALL
    SELECT 5, 'all', 'Excluding pregnancy not ascertained at the examination but reported at the interview (RIDEXPRG = 3 and RHD143 = 1)',
           count(*), sum(w_exam), 'examination weight' FROM a
    WHERE ridstatr = 2 AND age >= 20 AND preg_status NOT IN ('pregnant_at_exam', 'pregnant_reported_at_interview')
    UNION ALL
    SELECT 6, 'all', 'Excluding DIQ010 refused, don''t know, or missing: domain A',
           count(*), sum(w_exam), 'examination weight' FROM a WHERE in_a
    UNION ALL
    SELECT 7, 'hba1c', 'Excluding zero phlebotomy weight (no blood specimen) or absent from the HbA1c file',
           count(*), sum(w_a1c), 'phlebotomy weight (WTPH2YR)' FROM a
    WHERE in_a AND a1c_status IN ('measured', 'weight_but_no_result', 'result_but_zero_weight') AND w_a1c > 0
    UNION ALL
    SELECT 8, 'hba1c', 'Excluding positive weight but no HbA1c result: domain H',
           count(*), sum(w_a1c), 'phlebotomy weight (WTPH2YR)' FROM a WHERE in_h
    UNION ALL
    SELECT 9, 'fasting', 'Assigned to the fasting subsample (record in GLU file)',
           count(*), sum(w_exam), 'examination weight' FROM a WHERE in_a AND in_glu_file
    UNION ALL
    SELECT 10, 'fasting', 'Excluding subsample members with no blood specimen',
           count(*), sum(w_exam), 'examination weight' FROM a
    WHERE in_a AND in_glu_file AND fast_status <> 'subsample_no_blood'
    UNION ALL
    SELECT 11, 'fasting', 'Excluding fast outside 8 to less than 24 hours (zero fasting weight, glucose not used)',
           count(*), sum(w_fast), 'fasting subsample weight' FROM a
    WHERE in_a AND fast_status IN ('valid', 'weight_but_no_result')
    UNION ALL
    SELECT 12, 'fasting', 'Excluding positive weight but no glucose result: domain F',
           count(*), sum(w_fast), 'fasting subsample weight' FROM a WHERE in_f
    UNION ALL
    SELECT 13, 'paired', 'Excluding no HbA1c result: common paired domain P',
           count(*), sum(w_fast), 'fasting subsample weight' FROM a WHERE in_p
    UNION ALL
    SELECT 14, 'paired', 'Excluding intake within 8 hours or unknown on any FASTQX item: domain P-narrow',
           count(*), sum(w_fast), 'fasting subsample weight' FROM a WHERE in_p_narrow
)
SELECT step, branch, description, n,
       CASE
           WHEN step = 1 THEN NULL
           WHEN step = 7 THEN (SELECT n FROM steps WHERE step = 6) - n
           WHEN step = 9 THEN (SELECT n FROM steps WHERE step = 6) - n
           ELSE lag(n) OVER (ORDER BY step) - n
       END AS n_removed,
       weight_sum, weight_used
FROM steps
ORDER BY step;
