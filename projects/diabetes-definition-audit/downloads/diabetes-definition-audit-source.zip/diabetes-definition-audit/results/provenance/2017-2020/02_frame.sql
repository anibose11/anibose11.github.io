-- Analytic frame: one row per participant in the demographics file, with
-- every component left-joined on SEQN. Placeholders such as CASE WHEN g.SEQN IS NOT NULL THEN d.WTMECPRP END are
-- filled from config/sources.yaml for the release being built.
-- Laboratory values are rounded to their published precision (LBXGH one
-- decimal, LBXGLU whole mg/dL) to remove floating point noise from the SAS
-- transport conversion; the build verifies that rounding changes no value by
-- more than 1e-6.
CREATE OR REPLACE TABLE frame AS
SELECT
    CAST(d.SEQN AS BIGINT)            AS seqn,
    '2017-2020'                      AS release,
    CAST(d.RIDSTATR AS INTEGER)       AS ridstatr,
    CAST(d.RIDAGEYR AS INTEGER)       AS age,
    CAST(d.RIAGENDR AS INTEGER)       AS sex,
    CAST(d.RIDRETH3 AS INTEGER)       AS reth3,
    CAST(d.RIDEXPRG AS INTEGER)       AS ridexprg,
    CAST(d.SDMVPSU AS INTEGER)        AS sdmvpsu,
    CAST(d.SDMVSTRA AS INTEGER)       AS sdmvstra,
    coalesce(d.WTINTPRP, 0)             AS w_int,
    coalesce(d.WTMECPRP, 0)            AS w_exam,
    g.SEQN IS NOT NULL                AS in_ghb_file,
    CASE WHEN g.SEQN IS NOT NULL THEN d.WTMECPRP END                          AS w_a1c_raw,
    coalesce(CASE WHEN g.SEQN IS NOT NULL THEN d.WTMECPRP END, 0)             AS w_a1c,
    round(g.LBXGH, 1)                 AS lbxgh,
    u.SEQN IS NOT NULL                AS in_glu_file,
    u.WTSAFPRP                         AS w_fast_raw,
    coalesce(u.WTSAFPRP, 0)            AS w_fast,
    round(u.LBXGLU, 0)                AS lbxglu,
    f.SEQN IS NOT NULL                AS in_fastqx_file,
    f.PHAFSTHR                        AS phafsthr,
    f.PHAFSTMN                        AS phafstmn,
    f.PHAFSTHR + coalesce(f.PHAFSTMN, 0) / 60.0 AS fast_hours,
    CAST(f.PHQ020 AS INTEGER) AS phq020, f.PHACOFHR + coalesce(f.PHACOFMN, 0) / 60.0 AS t_coffee,
    CAST(f.PHQ030 AS INTEGER) AS phq030, f.PHAALCHR + coalesce(f.PHAALCMN, 0) / 60.0 AS t_alcohol,
    CAST(f.PHQ040 AS INTEGER) AS phq040, f.PHAGUMHR + coalesce(f.PHAGUMMN, 0) / 60.0 AS t_gum,
    CAST(f.PHQ050 AS INTEGER) AS phq050, f.PHAANTHR + coalesce(f.PHAANTMN, 0) / 60.0 AS t_antacid,
    CAST(f.PHQ060 AS INTEGER) AS phq060, f.PHASUPHR + coalesce(f.PHASUPMN, 0) / 60.0 AS t_supplement,
    i.SEQN IS NOT NULL                AS in_diq_file,
    CAST(i.DIQ010 AS INTEGER)         AS diq010,
    CAST(i.DIQ050 AS INTEGER)         AS diq050,
    CAST(i.DIQ070 AS INTEGER)         AS diq070,
    r.SEQN IS NOT NULL                AS in_rhq_file,
    CAST(r.RHD143 AS INTEGER)         AS rhd143,
    g.LBXGH                           AS lbxgh_unrounded,
    u.LBXGLU                          AS lbxglu_unrounded
FROM demo d
LEFT JOIN ghb g    ON g.SEQN = d.SEQN
LEFT JOIN glu u    ON u.SEQN = d.SEQN
LEFT JOIN fastqx f ON f.SEQN = d.SEQN
LEFT JOIN diq i    ON i.SEQN = d.SEQN
LEFT JOIN rhq r    ON r.SEQN = d.SEQN;
