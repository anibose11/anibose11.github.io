-- Join cardinality checks. Every component must have unique SEQN values and
-- every component SEQN must exist in the demographics file. The build stage
-- stops if any n_duplicate_seqn or n_not_in_demo value is non-zero.
SELECT 'demo' AS component, count(*) AS n_rows, count(DISTINCT SEQN) AS n_distinct_seqn,
       count(*) - count(DISTINCT SEQN) AS n_duplicate_seqn, 0 AS n_not_in_demo
FROM demo
UNION ALL
SELECT 'ghb', count(*), count(DISTINCT SEQN), count(*) - count(DISTINCT SEQN),
       count(*) FILTER (WHERE SEQN NOT IN (SELECT SEQN FROM demo))
FROM ghb
UNION ALL
SELECT 'glu', count(*), count(DISTINCT SEQN), count(*) - count(DISTINCT SEQN),
       count(*) FILTER (WHERE SEQN NOT IN (SELECT SEQN FROM demo))
FROM glu
UNION ALL
SELECT 'fastqx', count(*), count(DISTINCT SEQN), count(*) - count(DISTINCT SEQN),
       count(*) FILTER (WHERE SEQN NOT IN (SELECT SEQN FROM demo))
FROM fastqx
UNION ALL
SELECT 'diq', count(*), count(DISTINCT SEQN), count(*) - count(DISTINCT SEQN),
       count(*) FILTER (WHERE SEQN NOT IN (SELECT SEQN FROM demo))
FROM diq
UNION ALL
SELECT 'rhq', count(*), count(DISTINCT SEQN), count(*) - count(DISTINCT SEQN),
       count(*) FILTER (WHERE SEQN NOT IN (SELECT SEQN FROM demo))
FROM rhq;
