# Literature search log: prior art on diabetes definition and laboratory sample/weight choice in NHANES

Search run: 2026-10-07 (all searches, fetches, and access dates below are 2026-10-07 unless stated).
Scope: a small, reproducible prior-art search run on 2026-10-07 after the analysis plan was frozen. The log was finalized shortly after the first estimation run; no estimate was consulted in any search or screening decision. No NHANES data files (.xpt) were downloaded and no weighted estimate was computed from NHANES data during this search. Numbers quoted below are published figures read in the cited sources.

Research question this search serves: for NHANES August 2021-August 2023, how much of the difference between HbA1c-based and fasting plasma glucose (FPG)-based diabetes prevalence comes from the biomarker definition, and how much comes from the laboratory analytic sample and survey weight (HbA1c phlebotomy sample with WTPH2YR versus fasting subsample with WTSAF2YR)?

## 1. Sources and tools

| Source | Access method | Notes |
|---|---|---|
| PubMed | NCBI E-utilities esearch / esummary / efetch via curl (`https://eutils.ncbi.nlm.nih.gov/entrez/eutils/`) | `sort=relevance`; hit counts are the esearch `count` field |
| PubMed Central | NCBI efetch `db=pmc` and Europe PMC `fullTextXML` | Used to read methods and results where open |
| Europe PMC | REST API `https://www.ebi.ac.uk/europepmc/webservices/rest/search` | Searches full text by default, so counts are much larger than PubMed; top 25 by relevance screened |
| Crossref | REST API `https://api.crossref.org/works?query.bibliographic=...` | Crossref scores partial term matches, so `total-results` is not a meaningful relevance count; top 15 screened |
| Publisher and agency pages | web pages, curl | bmjopen.bmj.com returned HTTP 403 to automated requests; cdc.gov HTML returned 403 to curl but the Data Brief PDF was retrieved and parsed locally; wwwn.cdc.gov pages returned 200 to curl |
| Software | web search engine, CRAN pages, CRAN GitHub mirror source (`github.com/cran/<pkg>`) | Source code inspected directly with grep |

## 2. Search strings, dates, and hit counts

### 2.1 PubMed (date run 2026-10-07)

| ID | Query (exact string sent as `term`) | Hits | Screened | Relevant at title/abstract screen |
|---|---|---|---|---|
| a | `NHANES AND (HbA1c OR "glycated hemoglobin" OR A1C) AND ("fasting plasma glucose" OR "fasting glucose") AND (discordance OR agreement OR concordance)` | 11 | 11 titles | Tucker 2020 (PMID 32668564), James 2011 (21270196), Karnchanasorn 2016 (27597979), Okosun 2012 (22268513) |
| b | `NHANES AND diabetes AND (definition OR definitions OR "case definition") AND prevalence AND (undiagnosed)` | 13 | 13 titles | Fang 2022 (35817030), Menke 2015 (26348752), Vable 2011 (21671525) |
| c | `NHANES AND ("fasting subsample" OR "subsample weight" OR "sample weight") AND (glucose OR diabetes)` | 58 | 58 titles | None new. The phrase expansion matched body-weight terms; adolescent prevalence papers (Demmer 2013, 23887044; Duncan 2006, 16651496) screened out as youth-only |
| d | `("total diabetes" OR "undiagnosed diabetes") AND NHANES AND "2021"` | 13 | 13 titles | Gwira 2024 NCHS Data Brief 516 (40085919), Hu 2025 (40736548), Harding 2025 (40339738), Claudel 2026 (42396720) |
| e (software) | see 2.4 | n/a | n/a | n/a |
| f (supplementary) | `NHANES AND (A1C OR HbA1c OR "glycated hemoglobin") AND ("fasting plasma glucose" OR "fasting glucose") AND diabetes AND prevalence AND (criteria OR criterion)` | 48 | 48 titles | Davidson and Pan 2014 (24768273), Ford 2019 (31187544), Ram 2024 (38442986), Fang 2020 (32327419), Menke 2018 Diab Vasc Dis Res (29113512) |
| g (supplementary, weight misuse) | `NHANES AND ("sample weights" OR "survey weights" OR "sampling weights" OR "survey design") AND (misuse OR incorrect OR inappropriate OR "methodological quality" OR errors)` | 86 | 86 titles | Kim 2013 KNHANES appraisal (23573374); NCHS design and estimation reports (for example 33663649, 25093338) noted as methods references only |
| h (supplementary) | `NHANES AND diabetes AND prevalence AND ("2021-2023" OR "August 2021")` | 39 | 39 titles | Same four 2021-2023 papers as query d |
| i (supplementary, weight misuse, title/abstract restricted) | `("National Health and Nutrition Examination Survey"[tiab] OR NHANES[tiab]) AND ("survey weights"[tiab] OR "sampling weights"[tiab] OR "sample weights"[tiab] OR "complex survey design"[tiab]) AND (review[tiab] OR reporting[tiab] OR appraisal[tiab] OR "published studies"[tiab] OR "published articles"[tiab]) AND (inappropriate[tiab] OR incorrect[tiab] OR misuse[tiab] OR errors[tiab] OR "did not account"[tiab] OR "failed to"[tiab])` | 2 | 2 | None relevant (Graubard 1999, 10379963, general survey methods; Tian 2026, 41659825, CKM prevalence) |
| j | `formulaic research articles NHANES` | 2 | 2 | Suchak 2025 PLoS Biol (40338847) screened; full text grep found no discussion of survey weights; excluded |
| k | `("NHANES" OR "National Health and Nutrition Examination Survey") AND "subsample weights"` | 7 | 7 | None on diabetes definitions |
| l | `NHANES AND ("phlebotomy weight" OR "phlebotomy weights" OR WTPH2YR)` | 7 | 7 | None on diabetes; two NCHS data briefs on other analytes (40048464 anemia; 41875385 cholesterol) |
| m | `NHANES AND (HbA1c OR A1C) AND ("fasting subsample" OR "morning subsample") AND (prevalence) AND (bias OR representativeness OR comparison)` | 0 | 0 | None |

Verification lookups for named papers (PubMed, 2026-10-07):

| Lookup string | Hits | Result |
|---|---|---|
| `Cowie CC[au] AND A1C criteria AND 1988-2006` | 1 | PMID 20067953, verified |
| `Carson AP[au] AND A1C AND fasting glucose AND diabetes AND 2010[dp]` | 2 | PMID 19808920 (Carson 2010), 20628087 (Mann 2010, prediabetes) |
| `Selvin E[au] AND short-term variability AND classification of diabetes` | 1 | PMID 17646610 |
| `Selvin E[au] AND "Performance of A1C for the classification and prediction of diabetes"` | 1 | PMID 20855549 (ARIC plus NHANES III repeat-test subsample of 691) |
| `Wang L[au] AND Trends in Prevalence of Diabetes AND Control of Risk Factors AND 1999-2018` | 1 | PMID 34170288 |
| `Fang M[au] AND Selvin E[au] AND (undiagnosed OR confirmed) AND diabetes` | 6 | PMID 35817030 (Fang 2022) among others |
| `Selvin E[au] AND confirmatory testing AND undiagnosed diabetes` | 3 | PMID 29059691 (Selvin 2017, confirmatory definition), 29913486 (Selvin 2018, prognosis), 35817030 |
| `"Trends in Diabetes Treatment and Control"[ti]` | 0 | Exact-title tag returned nothing |
| `Fang M[au] AND Selvin E[au] AND (treatment OR control) AND diabetes AND 1999-2018` | 2 | PMID 34107181: "Trends in Diabetes Treatment and Control in U.S. Adults, 1999-2018", N Engl J Med 2021;384:2219-2228. It is in NEJM 2021, not Annals of Internal Medicine 2023. The confirmed-definition paper is Selvin et al., Ann Intern Med 2017 (29059691), not a Fang paper |
| `Xu G[au] AND diabetes AND prevalence AND United States AND (2018[dp] OR 2019[dp])` | 7 | PMID 30181166 (Xu 2018 BMJ). Abstract states the setting was "National Health Interview Survey, 2016 and 2017" (self-report only); excluded |
| `10.1136/bmjopen-2020-046060[doi]` | 1 | PMID 34140342 (starting-point paper, Wade 2021) |

### 2.2 Europe PMC (date run 2026-10-07; `resultType=lite`, `pageSize=25`)

| ID | Query | hitCount | Screened | New relevant items |
|---|---|---|---|---|
| E1 | `NHANES AND (HbA1c OR "glycated hemoglobin" OR A1C) AND ("fasting plasma glucose" OR "fasting glucose") AND (discordance OR agreement OR concordance)` | 1,328 | top 25 | None new |
| E2 | `NHANES AND diabetes AND (definition OR definitions OR "case definition") AND prevalence AND undiagnosed` | 1,404 | top 25 | Claudel 2026 and Harding 2025 (already found) |
| E3 | `NHANES AND ("fasting subsample" OR "subsample weight" OR "sample weight") AND (glucose OR diabetes)` | 1,213 | top 25 | None new |
| E4 | `("total diabetes" OR "undiagnosed diabetes") AND NHANES AND "2021"` | 220 | top 25 | Claudel 2026, Harding 2025, Hu 2025 (already found); others were association or prediction studies |
| E5 | `NHANES AND ("fasting subsample weight" OR "fasting sample weight" OR "WTSAF2YR") AND (HbA1c OR A1C) AND diabetes` | 119 | top 25 | None on definition or weight comparison |
| E6 | `NHANES AND (WTPH2YR OR "phlebotomy weight" OR "phlebotomy subsample")` | 6 | 6 | None on diabetes prevalence or definitions |

### 2.3 Crossref (date run 2026-10-07; `rows=15`)

| ID | `query.bibliographic` | total-results | New relevant items in top 15 |
|---|---|---|---|
| C1 | `NHANES HbA1c fasting plasma glucose agreement diabetes prevalence United States` | 650,653 | Menke 2018 Ann Epidemiol (10.1016/j.annepidem.2018.07.012, prediabetes; excluded on title); Rosella 2015 Diabetes Care (10.2337/dc14-2474, Canada; excluded on title as non-US; not read) |
| C2 | `NHANES fasting subsample weight HbA1c diabetes prevalence` | 1,343,724 | None new |
| C3 | `undiagnosed diabetes NHANES 2021-2023 prevalence` | 20,063,395 | Data Brief 516 DOI 10.15620/cdc/165794 confirmed; Fang 2022 supplement on figshare (10.2337/figshare.20098115) |

The first Crossref attempt for C1 and C2 returned an empty body; both were rerun after a short pause and the rerun results are recorded.

### 2.4 Software search (date run 2026-10-07)

| Query or source | Tool | Result |
|---|---|---|
| `nhanesA R package CRAN NHANES data retrieval` | web search engine | nhanesA CRAN page |
| `R package NHANES survey weight selection helper fasting subsample weight check "least common denominator"` | web search engine | nhanesdata `create_design()`; nhanesA vignette "Using Survey Weights with nhanesA"; CDC NHANES weighting tutorial |
| `tool warns mixing NHANES subsample weights fasting MEC weight mismatch R Python package validation` | web search engine | No dedicated guard tool found; results repeated nhanesdata and CDC tutorial |
| `NHANES published studies incorrect use of survey weights subsample weights review methodological errors` | web search engine | General guidance pages; no NHANES-specific appraisal of subsample-weight misuse located |
| CRAN index pages for survey, nhanesA, nhanesdata, RNHANES | curl | survey 4.5 (published 2026-02-24); nhanesA 1.4.1 (2025-10-14); nhanesdata 0.2.2 (2026-05-04); RNHANES "removed from the CRAN repository" and "Archived on 2026-04-27" |
| `github.com/cran/nhanesA` R sources (version 1.4.1) | curl plus grep for `WTSAF`, `WTPH`, `WTMEC`, `weight` | No match in any of the 12 R source files (nhanes.R alone is 603 lines, confirming the files were retrieved) |
| `github.com/cran/nhanesdata` `R/create_design.R` (version 0.2.2) | curl plus grep | Weight mapping covers `wtint2yr/4yr`, `wtmec2yr/4yr`, `wtsaf2yr/4yr` only; `valid_cycles <- seq(1999, 2021, by = 2)`; zero matches for `wtph` |

Software findings:

- nhanesA 1.4.1 retrieves tables and has a vignette on weights. The vignette (dated 2025-10-13; read on the web page at `https://cran.r-project.org/web/packages/nhanesA/vignettes/UsingSurveyWeights.html`) says the weight choice "hinges on the specific dataset components and analyses you're focusing on" and its worked example uses WTMEC2YR. The package source contains no weight-selection or weight-checking code.
- nhanesdata 0.2.2 `create_design()` documentation (`https://cran.r-project.org/web/packages/nhanesdata/refman/nhanesdata.html`) describes "3 categories of weights: Interview weight, Mobile Exam Center (MEC) weight, Fasting weight" and advises "Use the weight category with the lowest probability of selection, but only if at least one variable from that category is to be used." The source has no phlebotomy weight (WTPH2YR) option and does not cross-check which variables are present against the chosen weight category.
- survey 4.5 (Lumley) is a general complex-survey engine; it applies whatever weight the analyst supplies and has no NHANES-specific weight logic.
- No tool was located that refuses or warns when an estimate mixes phenotypes measured in different NHANES laboratory subsamples, or when a fasting-glucose phenotype is paired with a phlebotomy or MEC weight.

### 2.5 Official NCHS guidance read for context (not prior-art papers)

| Page | URL | Key wording (verbatim) |
|---|---|---|
| NHANES Tutorials, Weighting Module | `https://wwwn.cdc.gov/nchs/nhanes/tutorials/weighting.aspx` | "A good rule of thumb is to use "the least common denominator" where the variable that was collected on the smallest number of respondents is the "least common denominator."" and, for August 2021-August 2023, "For the first time, phlebotomy weights were included to address possible nonresponse bias." |
| GHB_L documentation (HbA1c, Aug 2021-Aug 2023) | `https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm` | "The phlebotomy weight should be used for analyses that use variables derived from blood analytes" |
| GLU_L documentation (fasting glucose, Aug 2021-Aug 2023) | `https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm` | "Plasma glucose was measured in a fasting subsample of participants 12 years and older. Special sample weights are required to analyze these data properly." and, for 311 participants outside the fasting window, "to include these data in the analysis, a reweighting would be required." |

Both laboratory files therefore name a weight that "should be used", and the general rule resolves a joint HbA1c and FPG analysis to the fasting subsample weight. The guidance does not say how an HbA1c-only estimate in the phlebotomy sample should be compared with an FPG estimate in the fasting subsample.

## 3. Screening decisions

Inclusion rule applied: the item's task or data closely overlaps this project on at least one of (i) NHANES or a comparable survey, (ii) a comparison of HbA1c-based and FPG-based diabetes definitions, or (iii) laboratory sample or survey weight handling for diabetes phenotypes. Items had to be verifiable (citation confirmed in PubMed or Crossref) and readable at least at abstract level.

### 3.1 Included (10)

| Rank | Item | Read level | Main reason |
|---|---|---|---|
| 1 | Gwira, Fryar, Gu 2024, NCHS Data Brief 516 | full text (PDF) | Same cycle and definitions; official estimates use fasting sample weights for all components |
| 2 | Cowie et al. 2010, Diabetes Care 33:562-568 | full text (PMC) | HbA1c prevalence estimated in the full examined sample with examination weights and separately compared with FPG in the OGTT subsample with OGTT weights; notes subsample estimates "may differ slightly" |
| 3 | Hu et al. 2025, Acta Diabetol 62:2159-2170 | full text (PMC) | Includes 2021-2023; explicitly uses "least common denominator" fasting subsample weights; reports that people missing FPG had lower unweighted prevalence |
| 4 | Davidson and Pan 2014, J Diabetes Complications 28:464-469 | full text (PMC author manuscript) | Compares total prevalence with FPG-only versus HbA1c-only criteria using fasting weights |
| 5 | Harding et al. 2025, Diabetes Metab 51:101659 | full text (PMC author manuscript) | 2021-2023 cycle, A1C or FPG definition with a both-tests sensitivity analysis; weight variable not named |
| 6 | Carson et al. 2010, Diabetes Care 33:95-97 | full text (PMC) | HbA1c versus FPG agreement in a common fasting sample, kappa reported |
| 7 | Menke et al. 2015, JAMA 314:1021-1029 | full text (publisher web page) | Definition-dependent prevalence; composite weights combining interview, MEC, FPG (and OGTT) weights |
| 8 | Claudel and Verma 2026, Diabetes Obes Metab 28:8581-8594 | full text (PMC web page) | 2013-2023 including 2021-2023; retains participants missing one of HbA1c or FPG; weight applied to dysglycemia estimates is ambiguous in the text |
| 9 | Fang, Wang, Coresh, Selvin 2022, Diabetes Care 45:1994-2002 | full text (PMC web page) | Confirmed versus conventional undiagnosed-diabetes definitions in the paired HbA1c plus FPG sample; reports how much the definition moves prevalence |
| 10 | Wade et al. 2021, BMJ Open 11:e046060 (starting point) | full text (Europe PMC XML; publisher page returned 403) | HbA1c versus FPG concordance in a paired, unweighted rural South African cohort; background for discordance only |

### 3.2 Excluded after reading (with reasons)

| Item | Read level | Reason |
|---|---|---|
| Selvin et al. 2017, Ann Intern Med 167:769-776 (PMID 29059691) | full text (PMC) | Confirmed-definition trends through 2014; same group and same paired fasting-sample approach as Fang 2022, which supersedes it for this purpose. Retained as a background citation for the confirmed definition |
| Wang et al. 2021, JAMA 326(8), start page 704 per Crossref, end page not verified (PMID 34170288; DOI 10.1001/jama.2021.9883) | full text (PMC web page) | Trend paper; weights described only as "used appropriately" across interview, examination, fasting, and OGTT samples, with no per-definition detail and no definitional comparison |
| Tucker 2020, J Clin Med 9:2207 (PMID 32668564) | full text (PMC) | Agreement of OGTT, HbA1c, FPG within the OGTT subsample with OGTT weights; centred on OGTT as reference; no sample or weight comparison |
| Selvin et al. 2007, Arch Intern Med 167:1545-1551 (PMID 17646610) | abstract | Within-person variability in NHANES III second examination (n = 685); informs single-measurement limitation only |
| James et al. 2011, Diabetes Care 34:387-391 (PMID 21270196) | abstract plus methods excerpt | Prediabetes outcome. Methods note that "Interview and OGTT subsample weights (provided by NCHS) were used so that the sum of the sample weights from the two subsamples summed to the total U.S. noninstitutionalized population"; useful as an example of composite weighting |
| Ford et al. 2019, Diabet Med 36:1234-1242 (PMID 31187544) | abstract plus methods excerpt | HbA1c cutoff performance by race against OGTT-defined status; not a prevalence-by-definition or weight study |
| Ram et al. 2024, BMJ Open Diabetes Res Care 12:e003470 (PMID 38442986) | abstract | FPG-HbA1c relationship by age and race (apparent glycation ratio); authors employed by a device manufacturer; not prevalence |
| Karnchanasorn et al. 2016, J Diabetes Res 2016:6195494 (PMID 27597979) | abstract | Sensitivity of HbA1c against FPG and 2hPG; abstract does not describe survey weighting |
| Selvin et al. 2011, Diabetes Care 34:84-89 (PMID 20855549) | abstract | Mainly ARIC cohort; NHANES III repeat-test subpopulation of 691 |
| Fang et al. 2021, N Engl J Med 384:2219-2228 (PMID 34107181) | abstract | Treatment and control among adults with diabetes; not a definition or weight comparison |
| Xu et al. 2018, BMJ 362:k1497 (PMID 30181166) | abstract | National Health Interview Survey, self-reported diagnosed diabetes only |
| Kim et al. 2013, J Prev Med Public Health 46:96-104 (PMID 23573374) | abstract | KNHANES (Korea); found "only 19.8% of all articles used survey design analysis"; concerns ignoring the design, not subsample-weight choice |
| Suchak et al. 2025, PLoS Biol 23:e3003152 (PMID 40338847) | full-text grep | About formulaic NHANES association papers; no discussion of survey or subsample weights found |
| Mann et al. 2010 (20628087), Menke 2018 (29113512; and Ann Epidemiol 2018), Okosun 2012, Vable 2011, Fang 2020 (32327419), Rosella 2015 (Canada) | title or abstract | Prediabetes focus, older-adult guideline focus, or non-US survey; not read further |

## 4. Candidate characterisation (closest five first)

Every quotation below was read in the source on 2026-10-07 at the URL given. "Not verified" marks a detail the accessible text did not state.

### 4.1 Gwira JA, Fryar CD, Gu Q. NCHS Data Brief No. 516, November 2024

- Citation: Gwira JA, Fryar CD, Gu Q. Prevalence of total, diagnosed, and undiagnosed diabetes in adults: United States, August 2021-August 2023. NCHS Data Brief, no 516. Hyattsville, MD: National Center for Health Statistics; 2024. DOI 10.15620/cdc/165794. PMID 40085919. PMCID PMC12035661 (abstract-only record in PMC).
- Source read: `https://www.cdc.gov/nchs/data/databriefs/db516.pdf` (retrieved and text-extracted locally); `https://www.cdc.gov/nchs/products/databriefs/db516.htm`.
- Data and task: NHANES August 2021-August 2023, adults 20 and older, diagnosed, undiagnosed, and total diabetes, plus trends from 1999-2000.
- Definitions: undiagnosed diabetes is "8- to 24-hour fasting plasma glucose greater than or equal to 126 mg/dL or hemoglobin A1c greater than or equal to 6.5%" in someone reporting no diagnosis.
- Weight and sample: "Fasting sample weights were used to account for differential probabilities of selection, nonresponse, and noncoverage." Every data table note reads "Estimates are weighted using fasting sample weights." The trend table lists an unweighted sample size of 2,938 for August 2021-August 2023. HbA1c is therefore used only within the fasting subsample; the phlebotomy weight is not mentioned. Fasting glucose was adjusted "using forward regression equations provided by the National Center for Health Statistics" for trend comparisons.
- Published headline: "the prevalence of total, diagnosed, and undiagnosed diabetes in U.S. adults was 15.8%, 11.3%, and 4.5%, respectively."
- Limitation relevant here: no HbA1c-only or FPG-only estimates and no estimate in the larger phlebotomy sample, so the brief cannot show how much the fasting-subsample restriction moves an HbA1c-based figure.
- Overlap: very high (same cycle, same thresholds, same composite).
- This project adds: separate HbA1c-only and FPG-only estimates in one paired domain, and the HbA1c estimate re-run in the full phlebotomy domain with WTPH2YR, so the official composite can be decomposed.

### 4.2 Cowie CC et al. Diabetes Care 2010

- Citation: Cowie CC, Rust KF, Byrd-Holt DD, Gregg EW, Ford ES, Geiss LS, et al. Prevalence of diabetes and high risk for diabetes using A1C criteria in the U.S. population in 1988-2006. Diabetes Care. 2010;33(3):562-568. DOI 10.2337/dc09-1524. PMID 20067953. PMCID PMC2827508.
- Source read: Europe PMC full text XML for PMC2827508; `https://pmc.ncbi.nlm.nih.gov/articles/PMC2827508/`.
- Data and task: NHANES 1988-1994, 1999-2002, 2003-2006; HbA1c-defined undiagnosed and total diabetes, compared with FPG and 2-hour glucose criteria.
- Weight and sample: HbA1c prevalence (Table 1, n = 13,094) "were calculated among examined individuals with known diabetes status based on interview and with valid A1C, using examination sample weights". The comparison with FPG and 2-hour glucose "was calculated among individuals in the OGTT subsample in 2005–2006, using OGTT sample weights." The figure note says the comparison used the OGTT subsample "(n = 2,017); consequently some estimates may differ slightly from those in Table 1."
- Key published result: "Standardized prevalence of undiagnosed diabetes using A1C criteria (1.8%) in this report was one-third that using either FPG or 2-h glucose criteria".
- Limitation relevant here: the authors acknowledge that moving HbA1c from its own examined sample to the subsample changes estimates but do not quantify or test the difference; the data predate the 2021-2023 phlebotomy weight.
- Overlap: high; it is the clearest located precedent for estimating HbA1c in its larger sample while comparing definitions in a smaller paired subsample.
- This project adds: a formal estimate, with design-based uncertainty, of the HbA1c-only difference between the full phlebotomy domain (WTPH2YR) and the paired fasting domain (WTSAF2YR) for 2021-2023.

### 4.3 Hu M et al. Acta Diabetologica 2025

- Citation: Hu M, Le MH, Yeo YH, Wijarnpreecha K, Likhitsup A, Kim D, et al. Diabetes prevalence and management patterns in US adults, 2001-2023. Acta Diabetol. 2025;62(12):2159-2170. DOI 10.1007/s00592-025-02572-6. PMID 40736548. PMCID PMC12727772.
- Source read: Europe PMC full text XML for PMC12727772.
- Data and task: NHANES 2001-2002 through 2021-2023; prevalence of diagnosed and undiagnosed diabetes, control, and medication use; adults 18 and older.
- Weight and sample: inclusion required "available data on diabetes diagnosis, fasting glucose, and hemoglobin A1C". "Following the "least common denominator" approach recommended by NHANES reporting guidelines" (citations omitted), "fasting subsample weights were used to ensure consistency across analyses". Exclusions included "missing fasting glucose (n = 31,382)".
- Missingness check: "Among those with missing fasting glucose levels (n = 31,382), the unweighted prevalence of diabetes was lower than in the overall cohort (11.1% by HBA1C ≥ 6.5% and 12.2% by self-report)". The limitations add that these individuals "appeared to have lower prevalence of diabetes than those with non-missing data, so our estimates may inflate true disease prevalence."
- Limitation relevant here: the comparison is unweighted, pools all cycles, and mixes people never selected for the fasting subsample with fasting-subsample members who lacked a valid glucose, so it cannot separate design-based subsampling from nonresponse.
- Overlap: high; the closest located analysis to the project's sample question.
- This project adds: a weighted, cycle-specific comparison using the documented weights for each domain (WTPH2YR for the phlebotomy domain, WTSAF2YR for the fasting domain), with a description of who is missing from each laboratory domain.

### 4.4 Davidson MB, Pan D. Journal of Diabetes and Its Complications 2014

- Citation: Davidson MB, Pan D. Epidemiological ramifications of diagnosing diabetes with HbA1c levels. J Diabetes Complications. 2014;28(4):464-469. DOI 10.1016/j.jdiacomp.2014.03.016. PMID 24768273. PMCID PMC4287398.
- Source read: NCBI PMC efetch XML for PMC4287398 (author manuscript).
- Data and task: NHANES 1999-2010, adults 20 and older (analytic sample 12,484); total prevalence (history plus laboratory) using "only FPG ≥126 mg/dl (7.0 mmol/L), only HbA1c ≥6.5% (48 mmol/mol) or either one".
- Weight and sample: "Sample "fasting" weights, provided by the NCHS, were used to correct for differential selection probabilities and to adjust for non-coverage and non-response." Group differences were "analyzed by chi-square tests"; the text does not state that these tests were design-adjusted (not verified).
- Key published result: prevalence "was significantly increased when the FPG criterion was used compared with the HbA1c criterion in the entire (11.5% vs 10.5%, P = 0.018)" population.
- Limitation relevant here: definitional comparison only inside the fasting sample; no examination of HbA1c in its own larger sample.
- Overlap: high on the definition question.
- This project adds: the same definitional contrast for 2021-2023, a paired design-based difference with a confidence interval, and the second axis (sample and weight).

### 4.5 Harding JL et al. Diabetes & Metabolism 2025

- Citation: Harding JL, Hu C, Varghese JS, Carrillo-Larco RM, Ali MK. Diabetes prevalence, awareness, and control in the United States, 2017-2023. Diabetes Metab. 2025;51(4):101659. DOI 10.1016/j.diabet.2025.101659. PMID 40339738. PMCID PMC12162209.
- Source read: NCBI PMC efetch XML for PMC12162209 (author manuscript).
- Data and task: NHANES 2017-March 2020 versus August 2021-August 2023; non-pregnant adults 20 and older.
- Weight and sample: participants "had hemoglobin (HbA1c) and fasting plasma glucose (FPG) measures available (n = 3,759 (response rate 46.9%), and 2,938 (response rate = 25.7%) for each period, respectively." Weights: "Sampling weights that were developed by the NCHS to minimize nonresponse bias were used" and "All analyses used recommended sample weights". The specific weight variable is not named (not verified). The 2,938 matches the unweighted 2021-2023 sample size in Data Brief 516.
- Definition sensitivity: "In sensitivity analyses, to assess the influence of a more specific diabetes definition, we defined undiagnosed diabetes as having both an elevated HbA1c (>=6.5%) and an elevated FPG level (>=126 mg/dl)."
- Limitation relevant here: HbA1c restricted to the paired fasting sample; no HbA1c-only or FPG-only estimates.
- Overlap: high (same cycle and composite).
- This project adds: single-biomarker estimates, an explicit statement of which weight goes with which domain, and the phlebotomy-domain HbA1c estimate.

### 4.6 to 4.10 Other included items

- Carson AP, Reynolds K, Fonseca VA, Muntner P. Comparison of A1C and fasting glucose criteria to diagnose diabetes among U.S. adults. Diabetes Care. 2010;33(1):95-97. DOI 10.2337/dc09-1227. PMID 19808920. PMCID PMC2797994. Read full text (Europe PMC XML). NHANES 1999-2006; "limited to 6,890 participants without self-reported diabetes who attended a morning examination, fasted for ≥9 h at the time of their blood collection, and had valid plasma glucose and A1C values." Weights: "Analyses were weighted to represent the U.S. population" (variable not named; not verified). Result: "the prevalence of undiagnosed diabetes was 2.3% using A1C and 3.6% using fasting glucose" with "κ = 0.60". Adds: 2021-2023 update in a paired domain and the sample/weight axis.
- Menke A, Casagrande S, Geiss L, Cowie CC. Prevalence of and trends in diabetes among adults in the United States, 1988-2012. JAMA. 2015;314(10):1021-1029. DOI 10.1001/jama.2015.10029. PMID 26348752. No PMC copy. Read at `https://jamanetwork.com/journals/jama/fullarticle/2434682` on the web page (two readings gave identical wording). Methods: "We used data from the morning examination session (after an 8- to 24-hour fast) to include FPG level in diabetes definitions." Weights: "for the hemoglobin A1c or FPG diabetes definition, a combination of the interview, mobile examination center, and FPG weights were used". How the combination was constructed is not described in the passages read (not verified). Abstract: prevalence "was 12% to 14% among US adults, depending on the criteria used". Adds: single-biomarker contrasts and a documented, reproducible weight choice per domain.
- Claudel SE, Verma A. Trends in prevalence of diabetes, pre-diabetes, and cardiometabolic risk factor control among U.S. adults, 2013-2023. Diabetes Obes Metab. 2026;28(9):8581-8594. DOI 10.1111/dom.71059. PMID 42396720. PMCID PMC13448958. Read at `https://pmc.ncbi.nlm.nih.gov/articles/PMC13448958/` on the web page (three readings gave consistent wording). Exclusions: "missing both haemoglobin A1c and fasting blood glucose". Weights: "We applied survey weights to all analyses using a combined weight for the four NHANES cycles" and "For analyses of the fasting laboratories (e.g., LDL‐C), we used subsample weights for fasting labs." Also: "analyses involving these variables use the fasting subsample weights" for fasting glucose. Which weight produced the dysglycemia prevalence, which uses fasting glucose where available, could not be determined from the text (not verified). Limitation stated by authors: "Participation in fasting laboratory assessments was low, potentially introducing selection bias". Adds: an explicit domain and weight per phenotype, and a check that rejects mixed-domain composites.
- Fang M, Wang D, Coresh J, Selvin E. Undiagnosed diabetes in U.S. adults: prevalence and trends. Diabetes Care. 2022;45(9):1994-2002. DOI 10.2337/dc22-0242. PMID 35817030. PMCID PMC9472490. Read at `https://pmc.ncbi.nlm.nih.gov/articles/PMC9472490/` on the web page. Population: "aged ≥20 years, nonpregnant, and had measures of their diabetes status, HbA1c, and FPG available (N = 30,492)" across NHANES III to 2017-March 2020. Weights: "recommended sample weights" (variable not named; not verified). Definitions: confirmed undiagnosed diabetes requires both elevated HbA1c and FPG. Sensitivity: "In 2017–2020, the prevalence of undiagnosed diabetes, based on the conventional definition, was 3.5% (95% CI 2.8, 4.1)." Adds: single-biomarker components for 2021-2023 and the sample/weight axis, which Fang 2022 does not address.
- Wade AN, Crowther NJ, Abrahams-Gessel S, Berkman L, George JA, Gómez-Olivé FX, et al. Concordance between fasting plasma glucose and HbA1c in the diagnosis of diabetes in black South African adults: a cross-sectional study. BMJ Open. 2021;11(6):e046060. DOI 10.1136/bmjopen-2020-046060. PMID 34140342. PMCID PMC8212405. Publisher URL `https://bmjopen.bmj.com/content/11/6/e046060` returned HTTP 403; full text read from Europe PMC XML. Cohort nested in HAALSI and AWI-Gen (Agincourt HDSS); 765 participants aged 40-70 without known diabetes; both tests in the same fasting visit ("Venous blood samples were collected at the clinic visit after an overnight fast"). No survey weighting is described; analyses in Stata 14.2. Result: "The prevalence of HbA1c-defined diabetes was four times the prevalence of FPG-defined diabetes (17.5% vs 4.2%)" with "kappa 0.23". Limitation relevant here: unweighted, paired, non-US cohort, so it informs the discordance concept only. Adds: a nationally weighted US analysis that separates definition from sample and weight.

## 5. Final inclusion list

Ranked by closeness to this project:

1. Gwira JA, Fryar CD, Gu Q. NCHS Data Brief 516; 2024. doi:10.15620/cdc/165794
2. Cowie CC, et al. Diabetes Care. 2010;33(3):562-568. doi:10.2337/dc09-1524
3. Hu M, et al. Acta Diabetol. 2025;62(12):2159-2170. doi:10.1007/s00592-025-02572-6
4. Davidson MB, Pan D. J Diabetes Complications. 2014;28(4):464-469. doi:10.1016/j.jdiacomp.2014.03.016
5. Harding JL, et al. Diabetes Metab. 2025;51(4):101659. doi:10.1016/j.diabet.2025.101659
6. Carson AP, et al. Diabetes Care. 2010;33(1):95-97. doi:10.2337/dc09-1227
7. Menke A, et al. JAMA. 2015;314(10):1021-1029. doi:10.1001/jama.2015.10029
8. Claudel SE, Verma A. Diabetes Obes Metab. 2026;28(9):8581-8594. doi:10.1111/dom.71059
9. Fang M, et al. Diabetes Care. 2022;45(9):1994-2002. doi:10.2337/dc22-0242
10. Wade AN, et al. BMJ Open. 2021;11(6):e046060. doi:10.1136/bmjopen-2020-046060

The structured records are in `docs/research/prior_art_candidates.json`; the array order of the ten `include: true` records equals this rank, followed by four records read and excluded (Selvin 2017, Wang 2021, Tucker 2020, Selvin 2007).

Background citations retained (not prior art for the core question): Selvin E, et al. Ann Intern Med. 2017;167(11):769-776, doi:10.7326/M17-1272 (confirmed definition); Selvin E, et al. Arch Intern Med. 2007;167(14):1545-1551, doi:10.1001/archinte.167.14.1545 (within-person variability); NHANES weighting tutorial and the GHB_L and GLU_L documentation pages (weight rules).

## 6. What the located literature does and does not cover

Three weighting approaches appear in the located work:

1. Restrict every component, HbA1c included, to the fasting subsample and use the fasting weight (Data Brief 516; Hu 2025; Davidson and Pan 2014; very likely Harding 2025, Carson 2010, Fang 2022, whose weight variables are not named).
2. Combine weights across samples so that diagnosed and undiagnosed components each come from their own sample (Menke 2015; James 2011 for prediabetes; Wang 2021 describes weights only in general terms).
3. Estimate HbA1c in its own larger examined sample with the examination weight (Cowie 2010, Table 1), alongside a separate paired-subsample comparison.

No located study, for any cycle, reports a design-based estimate of how much an HbA1c-defined prevalence changes between the HbA1c laboratory sample and the fasting subsample. No located study uses WTPH2YR, which NCHS introduced for the first time in August 2021-August 2023, for a diabetes definition comparison. The 2021-2023 analyses located (Data Brief 516, Harding 2025, Hu 2025, Claudel 2026) either restrict to the fasting subsample or describe weighting in terms that do not identify the weight applied to each phenotype. No software tool located checks that a phenotype is paired with the weight of the laboratory domain it was measured in.

## 7. Search limitations

- Small, single-reviewer search; Embase, Web of Science, Scopus, Google Scholar, and grey literature beyond CDC were not searched. Conference abstracts were not screened except where Crossref surfaced them.
- Europe PMC and Crossref counts are inflated by full-text and partial-term matching; only the top-ranked records were screened, so a relevant but low-ranked record could have been missed.
- Several full texts (Menke 2015, Fang 2022, Claudel 2026, Wang 2021) were read on the publisher or PMC web pages; quoted wording was checked by reading the page more than once. The two quotations used in the manuscript were checked against primary records on 2026-10-07: Menke 2015 ('12% to 14% among US adults, depending on the criteria used') in the PubMed abstract (PMID 26348752), and Cowie 2010 ('may differ slightly') in the Europe PMC full text (PMC2827508).
- Where an article did not name its weight variable, this log says "not named; not verified" rather than inferring it.
