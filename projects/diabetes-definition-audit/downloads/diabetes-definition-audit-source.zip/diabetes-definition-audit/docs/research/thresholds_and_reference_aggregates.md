# Diagnostic thresholds and published reference aggregates

Scope: verified diagnostic thresholds (ADA, IEC, WHO) and the published NHANES August 2021–August 2023 diabetes aggregates and surveillance definitions (NCHS Data Brief No. 516; CDC National Diabetes Statistics Report). The published aggregates are recorded here only as an external reference for later reconciliation. No NHANES data files were downloaded and no estimates were computed for this note.

Access date for every source below: 2026-10-07 (unless a different date is stated).

Quoting policy used in this note:

- NCHS and CDC material is U.S. government work. The NCHS brief states: "All material appearing in this report is in the public domain and may be reproduced or copied without permission; citation as to source, however, is appreciated." Definitions and methods from NCHS and CDC are therefore quoted verbatim.
- The ADA Standards (copyright ADA, reuse restricted by the publisher's license notice) and the WHO report (copyright WHO, all rights reserved) are paraphrased. Numeric thresholds are recorded as printed because they are factual values. One short verbatim ADA quote is included for the confirmation rule.
- The IEC 2009 report is distributed under CC BY-NC-ND 3.0 (per the PMC XML license statement); it is also paraphrased here, with location pointers.

---

## 1. ADA Standards of Care in Diabetes, 2026 edition, Section 2

### 1.1 Verified citation

American Diabetes Association Professional Practice Committee for Diabetes. 2. Diagnosis and Classification of Diabetes: Standards of Care in Diabetes—2026. Diabetes Care. 2026;49(Suppl 1):S27–S49. doi:10.2337/dc26-S002. PMID: 41358893. PMCID: PMC12690183.

- Suggested citation printed in the article footnotes (PMC copy): "American Diabetes Association Professional Practice Committee for Diabetes. 2. Diagnosis and classification of diabetes: Standards of Care in Diabetes—2026. Diabetes Care 2026;49(Suppl. 1):S27–S49"
- Published online 2025-12-08; issue date 2026-01-01 (Crossref metadata; PMC header reads "Diabetes Care. 2025 Dec 8;49(Suppl 1):S27–S49").
- Note on the title: the official title contains an em dash ("Diabetes—2026"); it is kept verbatim in citations only.
- Edition check: the 2026 edition is the current published edition as of the access date (the 2027 edition would be expected in December 2026). No 2026 "living standards" change to the Section 2 diagnostic thresholds was found in a web search; this was not exhaustively verified.

DOI verification:

- `https://doi.org/api/handles/10.2337/dc26-S002` returned responseCode 1, resolving to `https://diabetesjournals.org/care/article/49/Supplement_1/S27/163926/2-Diagnosis-and-Classification-of-Diabetes`.
- Crossref (`https://api.crossref.org/works/10.2337/dc26-S002`): title "2. Diagnosis and Classification of Diabetes: Standards of Care in Diabetes—2026", Diabetes Care, volume 49, issue Supplement_1, pages S27-S49.
- PubMed esummary for PMID 41358893 and the PMC ID converter confirm DOI, PMID and PMCID.

Access route: the diabetesjournals.org version-of-record page returned a browser verification interstitial ("Just a moment...") and was not bypassed. The full text was read from the PMC copy of the same article: `https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/` (same DOI, same pagination).

License notice on the PMC copy (paraphrased): copyright 2025 ADA; educational, noncommercial use if properly cited and unaltered; reproduction, redistribution, and text or data mining require ADA permission.

### 1.2 Table 2.1, criteria for the diagnosis of diabetes in nonpregnant individuals (values as printed)

| Test | Threshold as printed | Conditions attached in Table 2.1 (paraphrased) |
|---|---|---|
| A1C | A1C ≥6.5% (≥48 mmol/mol) | Laboratory method that is NGSP certified and standardized to the DCCT assay. Marked with the confirmation asterisk. |
| Fasting plasma glucose | FPG ≥126 mg/dL (≥7.0 mmol/L) | Fasting defined as no caloric intake for at least 8 h. Marked with the confirmation asterisk. |
| 2-h plasma glucose | 2-h PG ≥200 mg/dL (≥11.1 mmol/L) during OGTT | 75 g anhydrous glucose load, as described by WHO. Marked with the confirmation asterisk. |
| Random plasma glucose | ≥200 mg/dL (≥11.1 mmol/L) | Only with classic symptoms of hyperglycemia or hyperglycemic crisis. |

Confirmation rule (Table 2.1 asterisk footnote, verbatim opening): "In the absence of unequivocal hyperglycemia, diagnosis requires two abnormal results from different tests". The footnote continues (paraphrased) that the two results may come from the same sample time (for example A1C and FPG) or from the same test repeated at two time points.

Recommendations 2.1a and 2.1b (paraphrased): diagnose diabetes from A1C or plasma glucose criteria (FPG, 2-h PG, or random glucose with symptoms or crisis); without unequivocal hyperglycemia, confirmatory testing is required. Both graded B.

### 1.3 Table 2.2, criteria defining prediabetes in nonpregnant individuals (values as printed)

| Test | Range as printed |
|---|---|
| A1C | 5.7–6.4% (39–47 mmol/mol) |
| FPG (IFG) | 100 mg/dL (5.6 mmol/L) to 125 mg/dL (6.9 mmol/L) |
| 2-h PG during 75-g OGTT (IGT) | 140 mg/dL (7.8 mmol/L) to 199 mg/dL (11.0 mmol/L) |

Table 2.2 note (paraphrased): for all three tests, risk is continuous below the lower limit and rises disproportionately at the upper end of the range.

Section "Diagnosis of Prediabetes" (paraphrased): WHO and several other organizations set the IFG lower limit at 110 mg/dL (6.1 mmol/L); ADA used that limit in 1997 and adopted 100–125 mg/dL in 2003.

### 1.4 Statements on A1C and glucose discordance (paraphrased, with location)

- "Screening and Diagnosis of Diabetes" subsection: FPG, 2-h PG, and A1C reflect different aspects of glucose metabolism, and their diagnostic cut points identify groups with incomplete concordance (citing the 2009 International Expert Committee report, reference 3). Detection rates of the tests differ across populations and individuals. Compared with FPG and A1C cut points, 2-h PG classifies more people as having prediabetes or diabetes.
- Recommendation 2.3 (grade B): when glucose values and A1C are consistently and substantially discordant, evaluate for a problem or interference with either test.
- Recommendation 2.4 (grade B): where the A1C to glycemia relationship is altered (some hemoglobin variants, pregnancy, G6PD deficiency, HIV, conditions altering red blood cell turnover), use plasma glucose criteria.
- "Confirming the Diagnosis" subsection: two abnormal results, at the same time or at two time points, confirm the diagnosis. When two different tests are discordant, the test above the cut point should be repeated, considering factors that affect A1C or glucose; the diagnosis rests on the confirmatory test. A person meeting the A1C criterion twice but with FPG below 126 mg/dL should still be considered to have diabetes. Persistent, substantial discordance should prompt follow-up for analytic problems or interference.
- Table 2.3 (paraphrased; data attributed to Selvin, reference 236): glucose is an acute measure, needs fasting or timed samples, has poor preanalytic stability (glycolysis), is not standardized, and has high within-person variability. A1C reflects about 2–3 months of exposure, does not require fasting, has good preanalytic stability, is well standardized, and has low within-person variability, but is affected by altered erythrocyte turnover (anemia, iron status, hemolysis, transfusion, and similar), HIV, cirrhosis, kidney failure, dialysis, pregnancy, and some hemoglobin variants.
- Narrative text (paraphrased): glucose concentrations are falsely low when samples are not processed promptly; A1C has lower sensitivity at its cut point than 2-h PG.

Relevance to this audit (factual, not a finding): NHANES collects a single A1C and, for the fasting subsample, a single FPG at one visit. Population surveillance definitions (Sections 2 and 3 below) therefore classify undiagnosed diabetes from one elevated value of either test without the clinical confirmation step described in Table 2.1.

---

## 2. NCHS Data Brief No. 516 (August 2021–August 2023)

### 2.1 Verified citation

Suggested citation as printed on the brief page (verbatim): "Gwira JA, Fryar CD, Gu Q. Prevalence of total, diagnosed, and undiagnosed diabetes in adults: United States, August 2021–August 2023. NCHS Data Brief, no 516. Hyattsville, MD: National Center for Health Statistics. 2024. DOI: https://dx.doi.org/10.15620/cdc/165794."

- URL: `https://www.cdc.gov/nchs/products/databriefs/db516.htm` (read in full in a browser; plain HTTP clients received HTTP 403 from the CDC edge server).
- Byline as printed: "Jane A. Gwira, M.D., M.P.H., Cheryl D. Fryar, M.S.P.H., and Qiuping Gu, M.D., Ph.D."
- Header as printed: "NCHS Data Brief No. 516, November 2024". Page footer: "Last Reviewed: November 6, 2024".
- DOI 10.15620/cdc/165794 resolves (`https://doi.org/api/handles/10.15620/cdc/165794`, responseCode 1) to `https://stacks.cdc.gov/view/cdc/165794`. The CDC Stacks landing page itself returned HTTP 403 to direct requests and was not read.
- Metadata discrepancy to be aware of: the DOI registration metadata returned by `https://api.crossref.org/works/10.15620/cdc/165794` lists authors "Jane Baumblatt, Cheryl Fryar, Qiuping Gu, Jill Ashman" and an issued date of 2024-11-06. This differs from the byline and suggested citation printed in the brief. The brief's own suggested citation (Gwira, Fryar, Gu) is the one to use.
- About the authors (verbatim): "Jane A. Gwira was a Centers for Disease Control and Prevention Preventive Medicine resident at the National Center for Health Statistics, Division of Health and Nutrition Examination Surveys, during the analysis and writing of this report. Cheryl D. Fryar and Qiuping Gu are with the National Center for Health Statistics, Division of Health and Nutrition Examination Surveys."
- Diagnostic criteria reference used by the brief (its reference 1, verbatim): "American Diabetes Association. Diagnosis and classification of diabetes: Standards of care in diabetes—2024. Diabetes Care 47(Supp1):S20–S42. 2024." (The 2024 Section 2 DOI 10.2337/dc24-S002 resolves; Crossref gives Diabetes Care vol 47, Supplement_1, pages S20-S42.)
- Operations reference (its reference 4): Terry AL, Chiappa MM, McAllister J, Woodwell DA, Graber JE. Plan and operations of the National Health and Nutrition Examination Survey, August 2021–August 2023. Vital Health Stat 1(66). 2024. DOI 10.15620/cdc/151927 (resolves to `https://stacks.cdc.gov/view/cdc/151927`).

### 2.2 Definitions (verbatim, "Definitions" section)

- "Diagnosed diabetes: Defined as the survey respondent answering yes to the question: “Other than during pregnancy, have you ever been told by a doctor or health professional that you have diabetes or sugar diabetes?”"
- "Undiagnosed diabetes: Defined as the survey respondent reporting never having received a diabetes diagnosis from a healthcare provider and 8- to 24-hour fasting plasma glucose greater than or equal to 126 mg/dL or hemoglobin A1c greater than or equal to 6.5%."
- "Total diabetes: Combined prevalence of diagnosed and undiagnosed diabetes."
- Population: adults age 20 and older (figure and table titles read "adults age 20 and older").

### 2.3 Data source and methods (verbatim excerpts)

- "Criteria from the American Diabetes Association were used to define diabetes (1). Fasting plasma glucose data after an 8- to 24-hour fast were used. Fasting sample weights were used to account for differential probabilities of selection, nonresponse, and noncoverage. Analyses excluded pregnant women."
- "Standard errors of percentages were estimated using Taylor series linearization. Pairwise differences between groups were evaluated using t statistics. Stated differences were statistically significant at p less than 0.05."
- "Fasting plasma glucose values were adjusted using forward regression equations provided by the National Center for Health Statistics (5–7). Statistical analyses were conducted using SAS release 9.4 (SAS Institute Inc., Cary, N.C.) and SAS-callable SUDAAN release 11.0 (RTI International, Research Triangle Park, N.C.)."
- Table notes (verbatim, Tables 1–4): "Sample size is unweighted. Estimates are weighted using fasting sample weights."
- Age adjustment (verbatim, Table 1 note): "Age-adjusted estimates for adults age 20 and older were age adjusted by the direct method to the U.S. Census 2000 population using age groups 20–39, 40–59, and 60 and older."
- Summary (verbatim): "Consequently, slightly more than one-quarter of adults with diabetes had undiagnosed diabetes."

Implications as stated or not stated (no inference beyond the text):

- Weight: the brief says "fasting sample weights" were used for all estimates, including diagnosed diabetes. It does not name the NHANES variable. The fasting subsample weight in the August 2021–August 2023 GLU_L file is WTSAF2YR (Section 5), but the brief itself does not state the variable name.
- Analytic sample: the same sample size (2,938) is shown for total, diagnosed, and undiagnosed estimates, consistent with a single fasting-subsample analytic sample. The brief does not state how missing A1C or FPG values, "borderline" responses, or refusals were handled.
- Pregnancy: "Analyses excluded pregnant women." The method of determining pregnancy is not stated.
- Confidence interval method: the brief states the variance method (Taylor series linearization) but does not state the method used for the 95% confidence intervals.

### 2.4 Published estimates (verbatim from embedded data tables)

Table 1. Prevalence of total, diagnosed, and undiagnosed diabetes in adults age 20 and older, by sex: United States, August 2021–August 2023.

| Diabetes category and sex | Sample size | Percent (95% CI) | SE | Age-adjusted percent (95% CI) | SE |
|---|---|---|---|---|---|
| Total | 2,938 | 15.8 (13.6–18.2) | 1.1 | 14.3 (12.1–16.7) | 1.0 |
| Total, men | 1,306 | 18.0 (15.7–20.4) | 1.1 | 16.6 (14.0–19.4) | 1.2 |
| Total, women | 1,632 | 13.7 (11.0–16.7) | 1.3 | 12.2 (9.9–14.8) | 1.1 |
| Diagnosed | 2,938 | 11.3 (9.3–13.5) | 1.0 | 10.1 (8.3–12.1) | 0.8 |
| Diagnosed, men | 1,306 | 12.9 (11.0–15.0) | 0.9 | 11.7 (9.9–13.7) | 0.8 |
| Diagnosed, women | 1,632 | 9.7 (7.3–12.7) | 1.2 | 8.6 (6.7–10.9) | 0.9 |
| Undiagnosed | 2,938 | 4.5 (3.3–5.9) | 0.6 | 4.2 (2.9–5.7) | 0.6 |
| Undiagnosed, men | 1,306 | 5.1 (3.6–6.9) | 0.8 | 4.9 (3.3–6.9) | 0.8 |
| Undiagnosed, women | 1,632 | 3.9 (2.8–5.3) | 0.6 | 3.5 (2.4–5.1) | 0.6 |

Figure note (verbatim): "Diagnosed and undiagnosed diabetes may not sum to total due to rounding."

Table 2. By age group (crude).

| Category | Age group | Sample size | Percent (95% CI) | SE |
|---|---|---|---|---|
| Total | 20–39 | 688 | 3.6 (2.0–5.9) | 0.9 |
| Total | 40–59 | 861 | 17.7 (14.7–21.0) | 1.4 |
| Total | 60 and older | 1,389 | 27.3 (23.0–31.9) | 2.0 |
| Diagnosed | 20–39 | 688 | 2.2 (1.1–4.0) | 0.6 |
| Diagnosed | 40–59 | 861 | 12.1 (10.0–14.5) | 1.0 |
| Diagnosed | 60 and older | 1,389 | 20.5 (16.2–25.3) | 2.1 |
| Undiagnosed | 20–39 | 688 | 1.3 (0.5–3.0) | 0.5 |
| Undiagnosed | 40–59 | 861 | 5.6 (3.3–8.9) | 1.2 |
| Undiagnosed | 60 and older | 1,389 | 6.8 (5.3–8.5) | 0.7 |

Table 3. By weight status (crude). Total: underweight or normal 6.8 (5.1–8.9), n=779; overweight 12.3 (9.6–15.5), n=936; obesity 24.2 (21.1–27.5), n=1,190. Diagnosed: 5.2 (3.1–8.2); 9.5 (7.1–12.5); 16.3 (13.8–19.1). Undiagnosed: 1.6 (0.6–3.4); 2.8 (1.8–4.1); 7.9 (5.5–10.9).

Table 4. By education (crude). Total: high school, GED, or less 19.6 (15.8–24.0), n=932; some college 17.2 (14.1–20.7), n=884; bachelor's or more 10.7 (7.8–14.2), n=1,122. Diagnosed: 14.6 (11.5–18.3); 12.0 (9.4–14.9); 7.3 (4.8–10.6). Undiagnosed: 5.0 (3.5–6.9); 5.2 (3.3–7.9); 3.4 (1.9–5.4).

Table 5. Age-adjusted trend, selected rows. 2017–2020: n=3,757; total 14.8 (13.1–16.7); diagnosed 10.6 (9.1–12.2); undiagnosed 4.2 (3.6–4.9). August 2021–August 2023: n=2,938; total 14.3 (12.1–16.7); diagnosed 10.1 (8.3–12.1); undiagnosed 4.2 (2.9–5.7). The 1999–2000 row: total 9.7 (7.6–12.1).

### 2.5 Data tables and code availability

- Data tables: embedded in the HTML page as "Data table for Figure 1" through "Figure 5" (Tables 1–5 above). A PDF version is linked from the page (`https://www.cdc.gov/nchs/data/databriefs/db516.pdf`, listed as 548 KB); it was not opened for this note.
- SAS or other analytic code: no code link appears on the brief page. The NHANES Tutorials sample code matrix (`https://wwwn.cdc.gov/nchs/nhanes/tutorials/samplecode.aspx`) lists code for 7 NCHS publications (DB 52, 270, 303, 511, 369, 405, and Vital Health Stat Series 3 No. 46); DB 516 is not among them. No NCHS-published code for DB 516 was found. (A GitHub search could not be completed without authentication, so a third-party or CDC GitHub copy was not ruled out.)
- The CDC analysis note in Section 3.3 publishes SAS and SUDAAN code for CDC's own diabetes definitions, which differ from the NCHS brief in age range and weighting.

---

## 3. CDC National Diabetes Statistics Report (NDSR), current version

### 3.1 Location, version, and citation

- CDC landing page: `https://www.cdc.gov/diabetes/php/data-research/index.html`, dated "SEPT. 16, 2026", links "latest data" to the full report hosted in the U.S. Diabetes Surveillance System (USDSS).
- The former methods URL `https://www.cdc.gov/diabetes/php/data-research/methods.html` returned "Page Not Found" on the access date. An archived copy exists at `https://archive.cdc.gov/www_cdc_gov/diabetes/php/data-research/methods.html` (seen in search results only, not read).
- Full report: `https://usdss.cdc.gov/diabetes/report.html`. The report states (verbatim): "This report was last updated on March 11, 2026."
- Citation generated by the report's "Full Report Citation" panel (verbatim): "Centers for Disease Control and Prevention. (2026) National Diabetes Statistics Report, 11 Mar 2026. Available at https://usdss.cdc.gov/diabetes/report.html. (Accessed: 10/07/2026)."

### 3.2 Detailed methods, "Prevalence of Diabetes (Diagnosed and Undiagnosed) Among Adults Aged 18 Years or Older" (verbatim)

"The percentage of adults aged 18 years or older with diabetes (diagnosed or undiagnosed) was estimated using August 2021-August 2023 NHANES data. People who self-reported being told by a doctor or health professional that they had diabetes (other than during pregnancy) were classified as having diagnosed diabetes. Those not reporting a history of diagnosed diabetes but who had either a fasting plasma glucose greater than or equal to 126 mg/dl or an A1C level greater than or equal to 6.5% were classified as having undiagnosed diabetes. For consistency with other recent CDC diabetes estimates, no regression equations were applied to 2021-2023 NHANES fasting plasma glucose data. Pregnant women were excluded. People with diagnosed diabetes from the interviewed sample were combined with people with undiagnosed diabetes from the phlebotomy (or MEC in previous cycles) and fasting plasma glucose subsamples. Appropriate sampling weights were used so that estimates were representative of the total U.S. adult civilian, non-institutionalized population."

Age adjustment (verbatim): "Age-adjusted percentages of diagnosed and undiagnosed diabetes were calculated among adults aged 18 years or older by sex, race and ethnicity, and education level by the direct method to the 2000 U.S. Census standard population, using age groups 18-44, 45-64, and 65 years or older."

Trend methods (verbatim, separate methods panel): "For consistency with other recent CDC diabetes estimates, fasting plasma glucose values were adjusted using forward regression equations provided by NCHS."

### 3.3 Analysis Note, "Estimation of National Total Diabetes, Undiagnosed Diabetes and Prediabetes Prevalence" (verbatim excerpts, same USDSS page)

Exclusions:

- "Fasting status: Reasonable fasting hours for lab measures are defined as 8 or more hours and less than 24 hours. Cases outside of these values or with missing fasting time data are excluded from analyses."
- "Pregnancy status: NHANES determines current pregnancy status using self-report and/or urine pregnancy testing. Pregnant females are excluded from analyses. Beginning with the 2007-2008 cycle, pregnancy-based exclusions were limited to females aged 20-44 years, as NHANES publicly releases pregnancy status data only for this age group."
- "Undetermined diabetes status: Individuals without self-reported diagnosed diabetes were excluded if both A1C and FPG were missing, or if one lab value was in the normal range and the other was missing, such that diabetes or prediabetes could not be ruled out."

Classification (verbatim): "Undiagnosed diabetes Among individuals without self-reported diagnosed diabetes (including responses of “no,” “borderline,” “don’t know/refused,’Section” or missing), those with either A1C≥6.5 or FPG≥126. Classification was based on any available lab value; both measures were not required." (The stray characters "’Section" are reproduced as printed.)

FPG bridging: the note's Table 1 lists the forward bridging equations; for the August 2021–August 2023 cycle the 2021–2023 method is the reference method, and the published SAS line is "else if SDDSRVYR ge 9 then FPG=LBXGLU;" (no adjustment for 2015–2016 onward).

Sampling weights (verbatim): "Diabetes prevalence estimates integrate information from different NHANES components: diagnosed diabetes is identified from questionnaire data collected in the full interview sample, while undiagnosed diabetes and prediabetes are identified from laboratory measures collected in the examination and fasting subsamples. Accordingly, component-specific prevalence estimates were calculated using the appropriate NHANES sample weights for each data source (interview weights for diagnosed diabetes; MEC, phlebotomy, or fasting subsample weights for laboratory-defined diabetes). These component-specific estimates were then combined analytically to derive total diabetes prevalence, rather than by pooling participants with different weights into a single analytic sample."

Composite weight code published for the August 2021–August 2023 adult example (verbatim SAS):

```
if DM4_FPGA1C=1 then WT2YR=WTINT2YR;
    else if DM4_FPGA1C ne 1 and DM4_A1C=2 then WT2YR=WTPH2YR;
    else if DM4_FPGA1C ne 1 and WTSAF2YR>=0 then WT2YR=WTSAF2YR;
    else if DM4_FPGA1C ne 1 and WTSAF2YR=. then WT2YR=0;
```

Observation on the published code (as printed, not confirmed with CDC): the A1C status lines are conditioned on fasting status, for example "else if FAST=1 and 6.5<=A1C then DM4_A1C=2;", with "FAST=(8 LE PHAFSTHR LT 24);". As printed, A1C-based classification in the example code is therefore restricted to participants with an 8 to less than 24 hour fast, while A1C-classified cases receive WTPH2YR. The narrative text does not discuss this.

Weight variables listed in the note's Table 2 (verbatim labels): "WTINT2YR Numeric; full sample 2-year interview weight", "WTSAF2YR Numeric; fasting subsample 2-year MEC weight", "WTPH2YR Numeric; Phlebotomy 2-year weight Range of Values (Laboratory; 2021-2023)".

Stated differences from NCHS (verbatim FAQ): "For example, NCHS typically reports adult estimates for persons aged ≥20 years, whereas our analyses are based on adults aged ≥18 years. In addition, NCHS may apply stricter exclusion criteria, while the National Diabetes Statistic Report retains all participants who self-report a diabetes diagnosis. Weighting procedures also vary as NCHS generally applies a single weight, while we employ a composite weight to account for multiple data sources."

References cited by the note for the weighting approach (recorded, not independently verified unless marked): Li X. Determining the appropriate sample weight for three diabetes measures in the National Health and Nutrition Examination Survey. Joint Statistical Meetings; August 2016; Chicago, IL (not verified). Cowie CC, et al. Full accounting of diabetes and pre-diabetes in the U.S. population in 1988-1994 and 2005-2006. Diabetes Care. 2009;32(2):287-294. doi:10.2337/dc08-1296 (DOI resolves; Crossref metadata matches). Menke A, Casagrande S, Geiss L, Cowie CC. Prevalence of and trends in diabetes among adults in the United States, 1988-2012. JAMA. 2015;314(10):1021-1029. doi:10.1001/jama.2015.10029 (DOI resolves; Crossref metadata matches).

### 3.4 Published NDSR aggregates for adults aged 18 years or older, August 2021–August 2023

Age-adjusted (table "Age-Adjusted Prevalence of Diagnosed, Undiagnosed, and Total Diabetes Among Adults Aged 18 Years or Older, United States, 2021–2023"):

| Group | Diagnosed % (95% CI) | Undiagnosed % (95% CI) | Total % (95% CI) |
|---|---|---|---|
| Total | 9.8 (8.5–11.3) | 3.7 (2.9–4.7) | 13.5 (12.0–15.2) |
| Men | 10.6 (9.4–12.0) | 4.3 (3.0–6.0) | 14.9 (13.2–16.8) |
| Women | 9.1 (7.6–10.9) | 3.3 (2.5–4.3) | 12.4 (10.3–14.7) |

Crude (table "Estimated Crude Prevalence of Diagnosed Diabetes, Undiagnosed Diabetes, and Total Diabetes Among Adults Aged 18 Years or Older, United States, 2021–2023"):

| Group | Diagnosed % (95% CI) | Undiagnosed % (95% CI) | Total % (95% CI) |
|---|---|---|---|
| Total | 10.9 (9.3–12.7) | 4.0 (3.3–5.0) | 14.9 (13.1–16.9) |
| 18-44 | 2.9 (2.2–4.0) | 1.7 (1.0–2.8) | 4.6 (3.5–6.1) |
| 45-64 | 15.5 (13.4–17.8) | 5.1 (3.5–7.4) | 20.6 (17.8–23.8) |
| ≥65 | 21.3 (17.2–25.9) | 7.5 (6.0–9.4) | 28.8 (24.0–34.0) |
| Men | 11.4 (10.0–13.0) | 4.5 (3.3–6.2) | 15.9 (14.2–17.8) |
| Women | 10.4 (8.4–12.9) | 3.6 (2.8–4.5) | 14.0 (11.5–16.9) |

Headline text (verbatim): "11.0 million Adults aged 18 years or older that had undiagnosed diabetes 4.0% of all U.S. adults or 27.6% of all U.S. adults with diabetes".

Internal inconsistency to flag: the Analysis Note's "Example 2" states "The estimated age-adjusted prevalence of diabetes among U.S. adults (aged 18+) was 13.8% of the U.S. adult population", while the report's age-adjusted table gives 13.5 (12.0–15.2) and the trend table gives 13.5 (12.1–15.6) for 2021–2023. Not reconciled; the source does not explain the difference.

---

## 4. Context citations: IEC 2009 and WHO 2011

### 4.1 International Expert Committee (2009)

International Expert Committee. International Expert Committee report on the role of the A1C assay in the diagnosis of diabetes. Diabetes Care. 2009;32(7):1327–1334. doi:10.2337/dc09-9033. PMID: 19502545. PMCID: PMC2699715.

- DOI resolves (`https://doi.org/api/handles/10.2337/dc09-9033`, responseCode 1) to `https://diabetesjournals.org/care/article/32/7/1327/26886/International-Expert-Committee-Report-on-the-Role`. Crossref: Diabetes Care 32(7):1327-1334, issued 2009-07-01, author "The International Expert Committee".
- Full text read from Europe PMC XML: `https://www.ebi.ac.uk/europepmc/webservices/rest/PMC2699715/fullTextXML`. License per the XML: CC BY-NC-ND 3.0.
- Key content (paraphrased, Table 2 "Recommendation of the International Expert Committee" and "Recommendations and conclusions"): diabetes should be diagnosed at A1C ≥6.5%; the diagnosis should be confirmed with a repeat A1C, except in symptomatic people with plasma glucose >200 mg/dL (>11.1 mmol/L); when A1C testing is not possible, prior glucose-based methods with confirmation are acceptable; the committee advised against mixing different methods to diagnose diabetes; individuals with A1C from 6.0% to below 6.5% were described as likely at highest risk of progression. The 6.5% cut point was justified mainly by the A1C level at which moderate retinopathy prevalence rises.

### 4.2 WHO consultation (2011)

World Health Organization. Use of Glycated Haemoglobin (HbA1c) in the Diagnosis of Diabetes Mellitus: Abbreviated Report of a WHO Consultation. Geneva: World Health Organization; 2011. WHO reference number WHO/NMH/CHP/CPM/11.1. NCBI Bookshelf NBK304267. PMID: 26158184.

- WHO publication page: `https://www.who.int/publications/i/item/use-of-glycated-haemoglobin-(-hba1c)-in-diagnosis-of-diabetes-mellitus` (read on the web page: publication date 13 January 2011; reference number WHO/NMH/CHP/CPM/11.1; no ISBN listed).
- Recommendation text read at `https://www.ncbi.nlm.nih.gov/books/NBK304271/` (chapter 2). Paraphrased: HbA1c can be used to diagnose diabetes if stringent quality assurance is in place, assays are standardized to international reference values, and no condition precludes accurate measurement; 6.5% is the recommended cut point; a value below 6.5% does not exclude diabetes diagnosed by glucose tests. Quality of evidence: moderate (GRADE). Strength: conditional.
- PubMed record 26158184 (esummary) lists the book title, publisher World Health Organization, Geneva, 2011, and Bookshelf accession NBK304267.

---

## 5. NHANES August 2021–August 2023 laboratory documentation relevant to the weights

Read for context only (documentation pages, no data files downloaded).

GLU_L, Plasma Fasting Glucose: `https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm`. "First Published: September 2024". Eligible sample (verbatim): "All examined participants 12 years and older were eligible." Subsample weights (verbatim): "Plasma glucose was measured in a fasting subsample of participants 12 years and older. Special sample weights are required to analyze these data properly." and "Participants included in the fasting subsample but did not provide a blood specimen (n=324) have an assigned sample weight value of “0” in their records. In addition, participants who provided blood specimen but did not meet the 8 to less than 24 hour fasting criteria (n=311) have the sample weight value assigned as “0” (WTSAF2YR=0) as well. Plasma fasting glucose measurements for these 311 participants are included in the dataset." Codebook label: "WTSAF2YR - Fasting Subsample 2 Year MEC Weight".

GHB_L, Glycohemoglobin: `https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm`. "First Published: September 2024". Eligible sample (verbatim): "Examined participants aged 12 years and older were eligible." Instrument change (verbatim): "During the cycle, the laboratory instrument changed from the Tosoh G8 to the Bio-Rad D-100." Phlebotomy weight (verbatim): "Therefore, an additional phlebotomy weight, WTPH2YR, has been included in this data release to address possible nonresponse bias. Participants who are eligible but did not provide a blood specimen have their phlebotomy weight assigned a value of “0” in their records. The phlebotomy weight should be used for analyses that use variables derived from blood analytes, and is included in all relevant data files."

---

## 6. Definitions side by side (for reconciliation)

| Feature | NCHS Data Brief 516 | CDC NDSR (USDSS, updated 11 Mar 2026) |
|---|---|---|
| Age | 20 and older | 18 and older |
| Diagnosed | Self-report, "Other than during pregnancy" doctor or health professional question | Self-report, same concept |
| Undiagnosed | No reported diagnosis and FPG ≥126 mg/dL (8 to 24 h fast) or A1C ≥6.5% | No reported diagnosis (including borderline, don't know, refused, missing) and A1C ≥6.5 or FPG ≥126; either value sufficient |
| Fasting window | 8 to 24 hours | 8 or more and less than 24 hours |
| Weight | "fasting sample weights" for all estimates | Composite: WTINT2YR (diagnosed), WTPH2YR (A1C-defined undiagnosed), WTSAF2YR (other lab-defined) |
| Pregnancy | Pregnant women excluded | Pregnant females excluded; pregnancy data released only for ages 20-44 |
| FPG calibration for 2021–2023 | "adjusted using forward regression equations" (identity for this cycle per CDC Table 1) | "no regression equations were applied to 2021-2023" FPG |
| Age standard | 2000 Census; 20–39, 40–59, 60+ | 2000 Census; 18-44, 45-64, 65+ |
| Total, crude | 15.8 (13.6–18.2) | 14.9 (13.1–16.9) |
| Undiagnosed, crude | 4.5 (3.3–5.9) | 4.0 (3.3–5.0) |
| Total, age-adjusted | 14.3 (12.1–16.7) | 13.5 (12.0–15.2) |
| Analytic n | 2,938 (unweighted) | Not stated |

---

## 7. Not verified or open items

1. The ADA version-of-record page on diabetesjournals.org was not read (browser verification interstitial, not bypassed). Content was read from the PMC copy with the same DOI and pagination.
2. No 2026 living-standards amendment to ADA Section 2 thresholds was found; this was not exhaustively checked.
3. For this note the NCHS DB 516 content came from the HTML page; the CDC Stacks record was not read (HTTP 403). The DB 516 PDF was retrieved and text-extracted separately for the literature search log (docs/literature_search_log.md), and the values used for reconciliation (config/reference_aggregates.yaml) match the HTML data tables.
4. The NCHS brief does not name the weight variable (WTSAF2YR is inferred from GLU_L documentation, not stated by NCHS), does not state the confidence interval method, and does not state handling of missing laboratory values or "borderline" responses.
5. No NCHS-published analytic code for DB 516 was found; a GitHub search could not be completed without authentication.
6. DOI registration metadata for 10.15620/cdc/165794 lists authors (Baumblatt, Fryar, Gu, Ashman) that differ from the brief's byline (Gwira, Fryar, Gu). The brief's printed citation is used.
7. CDC NDSR Analysis Note Example 2 states 13.8% age-adjusted total diabetes for adults 18+, while the NDSR tables show 13.5%. Not reconciled.
8. The CDC example code conditions A1C classification on an 8 to less than 24 hour fast while weighting A1C-defined cases with WTPH2YR. Whether the production estimates used this exact logic was not confirmed.
9. The Li X (2016, Joint Statistical Meetings) weighting reference cited by CDC was not located or verified.
10. The archived CDC NDSR methods page (archive.cdc.gov) was not read.

---

## 8. Access log

| Source | URL | Access route | Date |
|---|---|---|---|
| ADA 2026 Section 2 (full text) | https://pmc.ncbi.nlm.nih.gov/articles/PMC12690183/ | Browser, page text and tables | 2026-10-07 |
| ADA 2026 Section 2 DOI | https://doi.org/10.2337/dc26-S002 | doi.org handle API; Crossref API; PubMed esummary | 2026-10-07 |
| ADA 2024 Section 2 DOI (cited by NCHS and CDC) | https://doi.org/10.2337/dc24-S002 | doi.org handle API; Crossref API | 2026-10-07 |
| NCHS Data Brief 516 | https://www.cdc.gov/nchs/products/databriefs/db516.htm | Browser, page text and embedded tables | 2026-10-07 |
| NCHS DB 516 DOI | https://dx.doi.org/10.15620/cdc/165794 | doi.org handle API; Crossref API | 2026-10-07 |
| NHANES Plan and Operations DOI | https://dx.doi.org/10.15620/cdc/151927 | doi.org handle API | 2026-10-07 |
| NHANES Tutorials sample code | https://wwwn.cdc.gov/nchs/nhanes/tutorials/samplecode.aspx | Browser | 2026-10-07 |
| CDC NDSR landing page | https://www.cdc.gov/diabetes/php/data-research/index.html | Browser | 2026-10-07 |
| CDC NDSR full report, methods, analysis note, citation | https://usdss.cdc.gov/diabetes/report.html | Browser, page text and methods panels | 2026-10-07 |
| NHANES GLU_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm | Browser | 2026-10-07 |
| NHANES GHB_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm | Browser | 2026-10-07 |
| IEC 2009 (full text XML) | https://www.ebi.ac.uk/europepmc/webservices/rest/PMC2699715/fullTextXML | curl | 2026-10-07 |
| IEC 2009 DOI and IDs | https://doi.org/10.2337/dc09-9033 | doi.org handle API; Crossref API; PubMed esummary; PMC ID converter | 2026-10-07 |
| WHO 2011 publication page | https://www.who.int/publications/i/item/use-of-glycated-haemoglobin-(-hba1c)-in-diagnosis-of-diabetes-mellitus | web page | 2026-10-07 |
| WHO 2011 recommendation text | https://www.ncbi.nlm.nih.gov/books/NBK304271/ | Browser | 2026-10-07 |
| WHO 2011 PubMed record | https://pubmed.ncbi.nlm.nih.gov/26158184/ | PubMed esummary | 2026-10-07 |
| Cowie 2009 and Menke 2015 DOIs | https://doi.org/10.2337/dc08-1296 ; https://doi.org/10.1001/jama.2015.10029 | doi.org handle API; Crossref API | 2026-10-07 |
