# NHANES source verification: diabetes definition and laboratory weight audit

Project: how diabetes prevalence estimates from NHANES August 2021-August 2023 change with (a) the biomarker definition (HbA1c, fasting plasma glucose, self-reported diagnosis) and (b) the laboratory analytic sample and weight (phlebotomy sample with WTPH2YR versus fasting subsample with WTSAF2YR).

Access date for every source below: 2026-10-07 (US Eastern).

How sources were read:

- Official documentation pages on wwwn.cdc.gov were retrieved as raw HTML with `curl` and converted to text locally, so quotations below are copied from the page text, not from a summary.
- Linked PDFs (laboratory method files, Laboratory Procedures Manual, questionnaire instruments, Federal Register notice) were retrieved with `curl` and text-extracted with `pypdf`. Page numbers given as "PDF p. N" are the page index of the PDF file, not the printed page label, unless the printed label is quoted.
- Two www.cdc.gov pages (the Ethics Review Board page and the Plan and Operations report) returned HTTP 403 to `curl`. The ERB page was read on the web page and confirmed in a web browser on 2026-10-07 (see section 7.5). The Plan and Operations PDF was downloaded as a binary file and text-extracted locally with `pypdf`, so those quotes are verbatim.
- No NHANES data file (.xpt) was downloaded. Data file URLs were taken from the official data listing pages and checked with HTTP HEAD requests only (status, size, Last-Modified header). No weighted estimate was computed or looked up.
- Counts quoted from codebooks are the unweighted frequency counts printed on the documentation pages. Where this note does simple arithmetic on those printed counts, it is labeled "arithmetic on printed counts".

---

## 1. Glycohemoglobin, GHB_L (August 2021-August 2023)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm (HTTP 200, accessed 2026-10-07)

Data file URL (from the Laboratory data listing page, href `/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.xpt`): https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.xpt
Listing page: https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2021-2023 shows "GHB_L Data [XPT - 169.9 KB]" with Date Published "September 2024".
HEAD check: HTTP 200, content-length 174000 bytes, Last-Modified "Wed, 10 Jul 2024 18:02:37 GMT".

Release dates on the page: "First Published: September 2024" and "Last Revised: NA".

Variables in the codebook (complete list): SEQN, WTPH2YR, LBXGH. There is no variable that identifies which instrument measured a given specimen.

Eligible sample: "Examined participants aged 12 years and older were eligible."

Codebook entries:

- WTPH2YR, SAS label "Phlebotomy 2 Year Weight", Target "Both males and females 12 YEARS - 150 YEARS". Codes: "4391.8220579 to 241728.85724 | Range of Values | 6750"; "0 | No blood sample provided | 449"; ". | Missing | 0". Total 7199.
- LBXGH, SAS label "Glycohemoglobin (%)", Target "Both males and females 12 YEARS - 150 YEARS". Codes: "3.2 to 17.1 | Range of Values | 6715"; "0 | No Lab Result | 0"; ". | Missing | 484". Total 7199.
- Arithmetic on printed counts: 484 missing LBXGH minus 449 zero-weight records leaves about 35 records that would have a positive WTPH2YR but no HbA1c value, if every zero-weight record is also missing LBXGH. This must be confirmed in the data; it bears on the documented advice to evaluate item nonresponse.

How WTPH2YR was constructed (exact wording, Analytic Notes, "Phlebotomy Weights"):

> "For the August 2021-August 2023 cycle, analysis of nonresponse patterns for the phlebotomy component in the MEC examination revealed differences by age group and race/ethnicity, among other characteristics. For example, approximately 67% of children aged 1-17 years who were examined in the MEC provided a blood specimen through phlebotomy, while 95% of examined adults aged 18 and older provided a blood specimen. Therefore, an additional phlebotomy weight, WTPH2YR, has been included in this data release to address possible nonresponse bias. Participants who are eligible but did not provide a blood specimen have their phlebotomy weight assigned a value of "0" in their records. The phlebotomy weight should be used for analyses that use variables derived from blood analytes, and is included in all relevant data files."

No further technical detail on the adjustment cells or calibration of WTPH2YR is given on this page. The Brief Overview (section 7.2) says a full weighting report "is forthcoming"; no such report for 2021-2023 is listed on the Survey Methods and Analytic Guidelines page as of the access date (section 7.4).

Item nonresponse advice:

> "Analysts should evaluate the extent of missing data in the dataset related to the outcome of interest as well as any predictor variables used in the analyses to determine whether additional re-weighting for item non-response is necessary."

Instrument change (Description of Laboratory Methodology):

> "There was a change to the lab equipment for the glycohemoglobin test in August 2021-August 2023. During the cycle, the laboratory instrument changed from the Tosoh G8 to the Bio-Rad D-100."

Secondary method: "In August 2021-August 2023, only 1.9% of the blood specimens required to be retested by the Ultra 2 HPLC method. A lab instrumentation change was made for this secondary method during the data collection period."

The same section also states: "There were no changes to the lab method, or lab site for this component in the NHANES August 2021 - August 2023 cycle." (Unlike GLU_L, this sentence does not mention "lab equipment", so it is consistent with the instrument change.)

Bridging study (Analytic Notes, heading "No Correction Needed for Glycohemoglobin Results for NHANES August 2021-August 2023"):

> "A method validation (bridging) study was performed to compare results from a laboratory instrument change that occurred during the August 2021–August 2023 survey cycle. The Tosoh G8 was upgraded to the Bio-Rad D-100 during the cycle. Randomly selected whole blood samples (n=165 NHANES, n=36 non-NHANES, total n=201) were measured using both instruments and the results were used to conduct the analysis. No substantial differences were found between results from the two instruments. On average, GHB values measured from the Tosoh G8 were only 2.3% higher than values from the Bio-Rad D-100, which is below the total allowable error of 3% in Westgard's Desirable Biological Variation Database (Westgard, 2014). Data from the bridging study also indicated the correlation coefficient (r) between the measurements was 0.999. Therefore, the NHANES August 2021–August 2023 GHB data did not have to be adjusted."

Not documented on the page: the date of the G8 to D-100 changeover and the share of specimens measured on each instrument. Arithmetic only: a 2.3% relative difference at an HbA1c of 6.5% is about 0.15 percentage points; the page does not say whether 2.3% applies uniformly across the range or near the 6.5% threshold.

Detection limits: "Since this data is reported in percent, the use of lower limits of detection (LLODs) isn't applicable."

Linkage and design variables: "The recommended procedure for variance estimation requires use of stratum and PSU variables (SDMVSTRA and SDMVPSU, respectively) in the demographic data file." "This laboratory data file can be linked to the other NHANES data files using the unique survey participant identifier (i.e., SEQN)."

Laboratory method files listed on the page (all labeled "(September 2024)"):

- Glycohemoglobin_G8: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GHB-L-MET-G8-508.pdf
- Glycohemoglobin_D-100: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GHB-L-MET-D-100-508.pdf
- Glycohemoglobin_Premier: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GHB-L-MET-Premier-508.pdf (not opened)

Laboratory site: "Whole blood specimens were processed, stored, and shipped to the University of Missouri-Columbia, MO for analysis."

### 1a. GHB method files (PDFs read 2026-10-07)

D-100 method file (title page "Revised Date: Dec 5th, 2023"; running footer "NHANES 2021-2022"):

- Calibration: "Calibrators are high -quality materials that are traceable to the NGSP (http://www.ngsp.org/) and IFCC networks."
- Reporting: "Results are expressed as %HbA1c aligned to NGSP units and are rounded to one decimal place."
- Section 9, Reportable range (PDF p. 17): "3.5 to 20.0% HbA1c. HbA1c results less than 3.5 % are reported as "< 3.5", and HbA1c results greater than 20.0 % are reported as "> 20.0""
- Special considerations (PDF p. 19): "The HbA1c test should not be used to replace glucose testing in pediatric patients, pregnant women, or patients with Type 1 Diabetes."

G8 method file (title page "Revised Date: December 30, 2021"):

- Section 9, Reportable range (PDF p. 21): "Results below 4.0% or above 14.0% are reanalyzed for verification prior to results being reported." and "The established AMR is 3.1 – 19.5%."

Both method files end with an identical table headed "August 2021-August 2023 Summary Statistics and QC Chart" for LBXGH (QC lots dated 28SEP21 to 23AUG23). Neither file states the changeover date.

---

## 2. Plasma fasting glucose, GLU_L (August 2021-August 2023)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm (HTTP 200, accessed 2026-10-07)

Data file URL (listing href `/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.xpt`): https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.xpt
Listing: "GLU_L Data [XPT - 126.2 KB]", Date Published "September 2024". HEAD check: HTTP 200, content-length 129200, Last-Modified "Wed, 10 Jul 2024 15:15:21 GMT".

Release dates on the page: "First Published: September 2024", "Last Revised: NA".

Variables in the codebook (complete list): SEQN, WTSAF2YR, LBXGLU, LBDGLUSI. WTPH2YR is not in GLU_L (confirmed on the 2021-2023 Laboratory variable list, which lists WTSAF2YR for GLU_L, INS_L and TRIGLY_L, and WTPH2YR for GHB_L and other blood files: https://wwwn.cdc.gov/nchs/nhanes/search/variablelist.aspx?Component=Laboratory&Cycle=2021-2023).

Eligible sample: "All examined participants 12 years and older were eligible."

Codebook entries:

- WTSAF2YR, SAS label "Fasting Subsample 2 Year MEC Weight", Target "Both males and females 12 YEARS - 150 YEARS". Codes: "11459.183689 to 561922.42956 | Range of Values | 3361"; "0 | No Lab Result or Not Fasting for 8 to <24 hours | 635"; ". | Missing | 0". Total 3996.
- LBXGLU, SAS label "Fasting Glucose (mg/dL)", same Target. Codes: "59 to 561 | Range of Values | 3672"; ". | Missing | 324". Total 3996.
- LBDGLUSI, SAS label "Fasting Glucose (mmol/L)", same Target. Codes: "3.28 to 31.1 | Range of Values | 3672"; ". | Missing | 324".
- Unit conversion: "The plasma fasting glucose value in mg/dL (LBXGLU) was converted to mmol/L (LBDGLUSI) by multiplying by 0.05551 (rounded to 3 decimals)."

Fasting subsample and who has a zero weight (Analytic Notes, "Subsample Weights"):

> "Plasma glucose was measured in a fasting subsample of participants 12 years and older. Special sample weights are required to analyze these data properly. Specific sample weights for this subsample are included in this data file and should be used when analyzing these data."

> "Participants included in the fasting subsample but did not provide a blood specimen (n=324) have an assigned sample weight value of "0" in their records. In addition, participants who provided blood specimen but did not meet the 8 to less than 24 hour fasting criteria (n=311) have the sample weight value assigned as "0" (WTSAF2YR=0) as well. Plasma fasting glucose measurements for these 311 participants are included in the dataset. However, to include these data in the analysis, a reweighting would be required."

Arithmetic on printed counts: 324 + 311 = 635 zero weights; 3672 glucose values minus 311 out-of-window values = 3361 positive weights. So every record with WTSAF2YR > 0 should have a glucose value, and 311 records carry a glucose value with WTSAF2YR = 0. An analysis must restrict to WTSAF2YR > 0, not to non-missing LBXGLU.

Fasting-duration eligibility: "8 to less than 24 hour fasting criteria" (quoted above). The page does not state which FASTQX_L variables NCHS used to apply this rule.

Phlebotomy coverage note (also on this page): "For example, in August 2021–August 2023, approximately 67% of children aged 1-17 years who were examined in the MEC provided a blood specimen through phlebotomy, while 95% of examined adults aged 18 and older provided a blood specimen."

Which weight: the page recommends the subsample weight in the file (quoted above). It does not mention WTPH2YR. See section 7 for the cycle-level guidance and section 11 for the tension between sources.

Methods and calibration: "There were no changes to the lab method, lab equipment, or lab site for this component in the NHANES August 2021–August 2023 cycle." Method file: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GLU-L-MET-508.pdf (September 2024). Method file section 9 (PDF p. 12): "A. Analytic Range – 2 – 728 mg/dL", "B. Limit of Detection (LOD) – 2 mg/dL".

Comparability: "If August 2021–August 2023 data are compared or combined with the 2015-2016 data, no adjustments are needed for equipment changes. As mentioned in the 2015-2016 documentation, most of the 2015-2016 samples were measured using the Cobas C311, which is the same instrument used in 2017-2023."

Detection limits: the page says an "LC" flag variable exists (example "LBDGLULC") and gives LLOD 2.0 mg/dL for LBXGLU, but LBDGLULC does not appear in the GLU_L codebook. The printed minimum (59 mg/dL) is far above the LLOD, so this does not affect diabetes classification.

Other links on the page:

- "August 2021–August 2023 Laboratory Data Overview" link: https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewlab.aspx?BeginYear=2021. When followed on 2026-10-07 it returned a page headed "NHANES 2021-2022 Laboratory Data Overview" with the text "The requested survey cycle is not valid or content is not available."
- Fasting Questionnaire link: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/FASTQX_L.htm, described as including "fasting status, length of fast and the time of venipuncture."

---

## 3. Demographics, DEMO_L (August 2021-August 2023)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DEMO_L.htm (HTTP 200, accessed 2026-10-07)

Data file URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DEMO_L.xpt (listing "DEMO_L Data [XPT - 2.5 MB]", Date Published "September 2024"; HEAD: HTTP 200, content-length 2582160, Last-Modified "Mon, 16 Sep 2024 18:36:04 GMT"). Listing page: https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Demographics&Cycle=2021-2023

Release dates: "First Published: September 2024", "Last Revised: NA".

Eligible sample: "All participants in the NHANES August 2021-August 2023 sample are included in this dataset."

Key notes (exact wording):

- SDDSRVYR: "A value of "12" denotes NHANES August 2021-August 2023 data."
- RIDSTATR: "identifies whether a participant was both interviewed at home or by telephone and examined in the mobile examination center (MEC), or was only interviewed but never participated in the examination."
- RIDAGEYR: "Due to disclosure concerns, all responses of participants aged 80 years and older are coded as "80." In NHANES August 2021-August 2023, the weighted mean age for participants 80 years and older is 85 years."
- Analytic Notes: "Age at screening: used to determine eligibility for an examination component and should be used for most analyses."
- RIDRETH3 and RIDRETH1 derivation: RIDRETH3 uses codes 1, 2, 3, 4, 6, 7 ("Code "5" was not used in RIDRETH3"); RIDRETH1 groups non-Hispanic Asian into code 5 ("Codes "6" and "7" were not used in RIDRETH1").
- RIDEXPRG (universe and derivation): "Pregnancy status at the time of the health examination was ascertained for females 8–59 years of age. Due to disclosure risk, pregnancy status is released only for women 20-44 years of age. RIDEXPRG values are based on self-reported pregnancy status and urine pregnancy test results." and "If the respondent reported did not know her pregnancy status and the urine test was negative, the respondent was coded "could not be determined" (RIDEXPRG=3). People who were interviewed, but not examined also have an RIDEXPRG value = 3 (could not be determined)."
- Analytic Notes on pregnancy: "The percentage of pregnant women/girls aged 8-19 or 45-59 years is less than 1% in NHANES August 2021-August 2023."
- Design: "notable design changes were made to adapt to the pandemic environment, including no person-level oversampling by race and Hispanic origin and income. As a result, the number of participants for certain demographic subgroups are noticeably lower than in previous cycles, and users should expect reduced statistical precision for these groups. Additionally, person-level oversampling based on age group was added."
- Period and gap: "Although the August 2021-August 2023 cycle represents a two-year data collection period, there is a 15-month gap between it and the previous dataset (2017-March 2020)." and "Data users are urged to proceed with caution before combining August 2021-August 2023 with previous cycles to calculate cross sectional health estimates or conducting trend analysis, given the 15-month period with unobserved data may include unusual patterns." (Note: the Brief Overview and the tutorial describe the same gap as "1.5-year"; the Brief Overview elsewhere says "16-month pause".)
- MVUs: "Fifteen MVUs and 30 masked primary sampling units (PSUs) are included in the NHANES August 2021-August 2023. Each stratum has 2 PSUs."
- Weights: "The 2-year sample weights (WTINT2YR, WTMEC2YR, depending on the analysis) should be used for all NHANES August 2021-August 2023 analyses."

Codebook values used (unweighted counts as printed): total N = 11933.

- RIDSTATR: 1 "Interviewed only" 3073; 2 "Both interviewed and MEC examined" 8860; "." Missing 0.
- RIAGENDR: 1 Male 5575; 2 Female 6358; Missing 0.
- RIDAGEYR: "0 to 79" 11408; 80 "80 years of age and over" 525; Missing 0.
- RIDRETH1: 1 Mexican American 1117; 2 Other Hispanic 1373; 3 Non-Hispanic White 6217; 4 Non-Hispanic Black 1597; 5 Other Race - Including Multi-Racial 1629; Missing 0.
- RIDRETH3: 1 1117; 2 1373; 3 6217; 4 1597; 6 Non-Hispanic Asian 681; 7 Other Race - Including Multi-Racial 948; Missing 0.
- RIDEXPRG, Target "Females only 20 YEARS - 44 YEARS": 1 "Yes, positive lab pregnancy test or self-reported pregnant at exam" 41; 2 "The participant was not pregnant at exam" 1065; 3 "Cannot ascertain if the participant is pregnant at exam" 397; Missing 10430.
- WTINT2YR: "4584.463196 to 170968.343177" 11933; Missing 0.
- WTMEC2YR: "4581.595095 to 227108.296958" 8860; 0 "Not MEC Examined" 3073; Missing 0.
- SDMVSTRA: "173 to 187"; SDMVPSU: "1 to 2"; no missing.
- Optional covariates: DMDEDUC2 (adults 20+; 7 Refused, 9 Don't know, "." Missing 4139); INDFMPIR ("0 to 4.99", 5 = "Value greater than or equal to 5.00", Missing 2041).

Reference listed on the page: "Terry AL, Chiappa MM, McAllister J, Woodwell DA, Graber JE. Plan and operations of the National Health and Nutrition Examination Survey, August 2021–August 2023. National Center for Health Statistics. Vital Health Stat 1(66). 2024." The Brief Overview gives "doi:10.15620/cdc/151927"; on 2026-10-07 https://doi.org/10.15620/cdc/151927 redirected (HTTP 302) to https://stacks.cdc.gov/view/cdc/151927 (HTTP 200). PDF: https://www.cdc.gov/nchs/data/series/sr_01/sr01-066.pdf.

### 3a. Plan and Operations report (sr01-066), text extracted from PDF

- (PDF p. 16) "Specimens provided by female participants ages 12–59 and menstruating female participants ages 8–11 were also tested for pregnancy."
- (PDF p. 16) "The venipuncture protocol stayed the same as in the 2019–2020 survey cycle."
- (PDF p. 10) "To reduce possible exposure to SARS-CoV-2 by limiting the time participants spent in the MEC, DHNES shortened examination sessions from 4 hours to 2.5 hours."
- The report text that was extracted did not contain the words "fast", "glycohemoglobin" or "glucose"; fasting procedures were therefore taken from the Laboratory Procedures Manual (section 5a).

---

## 4. Diabetes questionnaire, DIQ_L (August 2021-August 2023)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DIQ_L.htm (HTTP 200, accessed 2026-10-07)

Data file URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DIQ_L.xpt (Questionnaire listing "DIQ_L Data [XPT - 827.7 KB]", Date Published "September 2024"; HEAD: HTTP 200, content-length 847600, Last-Modified "Mon, 04 Dec 2023 23:56:58 GMT"). Listing: https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Questionnaire&Cycle=2021-2023

Instrument PDF (from https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/questionnaires.aspx?Cycle=2021-2023): https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/questionnaires/DIQ-L-508.pdf

Release dates: "First Published: September 2024", "Last Revised: NA".

Eligible sample (the page joins the cycle dates with a box-drawing character, shown here as a hyphen): "All survey participants aged 1 year and older in the NHANES August 2021-August 2023 sample are included in this dataset. The questions asked varied by age and history of diabetes."

Mode: "These questions were asked in the home or on the phone, by trained interviewers using the Computer-Assisted Personal Interview (CAPI) system." "A proxy provided information for survey participants who were under 16 years of age and for participants who could not answer the questions themselves."

DIQ010 (codebook), SAS label "Doctor told you have diabetes", Target "Both males and females 1 YEARS - 150 YEARS":

> English Text: "The next questions are about specific medical conditions. {Other than during pregnancy, {have you/has SP}/{Have you/Has SP}} ever been told by a doctor or health professional that {you have/{he/she/SP} has} diabetes or sugar diabetes?"

> English Instructions: "CAPI INSTRUCTION: IF SP AGE < 15, DISPLAY "HAVE SP" FOR THE FIRST DISPLAY AND "SP HAS" FOR THE SECOND DISPLAY. IF SP IS FEMALE AND AGE >= 20, DISPLAY "OTHER THAN DURING PREGNANCY, {HAVE YOU/HAS SP}"."

Codes: 1 Yes 1081; 2 No 10371 (skip to DIQ159); 3 Borderline 284 (DIQ159); 7 Refused 0 (DIQ159); 9 Don't know 4 (DIQ159); "." Missing 4. Total 11744.

DIQ010 in the instrument PDF (p. 1) differs slightly from the codebook:

- Wording: "{Other than during pregnancy, {have you/has SP}/{Have you/Has SP}} ever been told by a doctor or other health professional that ..." (instrument says "doctor or other health professional").
- Display rule: "IF SP IS (FEMALE OR DMQ.510 = 7 OR 9) AND AGE >= 20, DISPLAY "OTHER THAN DURING PREGNANCY, {HAVE YOU/HAS SP}"." The meaning of DMQ.510 was not verified (it was not found in the text extracted from DMQ-L-508.pdf).
- Code 3 label in the instrument: "BORDERLINE OR PREDIABETES"; the codebook label is "Borderline".
- Help screen (instrument p. 4): "Diabetes: A disease that occurs when your blood glucose, also called blood sugar, is too high. Do not include gestational diabetes or diabetes that was only present during pregnancy. Also, do not include self-diagnosed diabetes, pre-diabetes or high sugar."

Skip logic:

- DIQ159 check item: "IF ANY AGE AND DIQ.010 = 1 (YES), GO TO DIQ.050. IF AGE >=12 AND DIQ.010 = 3, GO TO DIQ.180. IF AGE < 12, GO TO END OF SECTION. OTHERWISE, CONTINUE."
- DIQ065 check item: "IF DIQ.010 = 1 (YES) OR DIQ.010 = 3 (BORDERLINE OR PREDIABETES) OR DIQ.160 = 1 (YES) CONTINUE. OTHERWISE, GO TO END OF SECTION."

DIQ050, SAS label "Taking insulin now", Target 1 YEARS - 150 YEARS. Codebook text "{Is SP/Are you} now taking insulin"; instrument text "Insulin can be taken by shot or pump. {Is SP/Are you} now taking insulin?" Codes: 1 Yes 344; 2 No 737 (skip to DIQ065); 7 Refused 0; 9 Don't know 0; Missing 10663. Universe in practice: DIQ010 = 1 only. Analytic Notes: "The insulin use question (variables DIQ050, DID060, DIQ060U) was only asked for participants with diagnosed diabetes in the DIQ_L data."

DIQ070, SAS label "Take diabetic pills to lower blood sugar", Target 1 YEARS - 150 YEARS. Text: "{Is SP/Are you} now taking diabetic pills to lower {{his/her}/your} blood sugar? These are sometimes called oral agents or oral hypoglycemic agents." Codes: 1 Yes 885; 2 No 1389; 7 Refused 0; 9 Don't know 7; Missing 9463. Universe in practice: DIQ010 = 1 or 3, or DIQ160 = 1 (DIQ065 check item). Implication: a "pills" response from someone with DIQ010 = 3 or DIQ160 = 1 is possible; a definition that counts medication use as diagnosed diabetes needs an explicit rule for these respondents.

DIQ160 (prediabetes), Target 12 YEARS - 150 YEARS: 1 Yes 918; 2 No 7089; 7 Refused 0; 9 Don't know 15; Missing 3722.

Weight guidance on this page (exact):

> "Interview weights should only be used if questionnaire data are analyzed by themselves. However, if DIQ data are merged with the MEC examination data or laboratory full sample data, the MEC examination weights should be used for analyses. If DIQ data are merged with the laboratory fasting glucose data, fasting subsample weights should be used for analyses."

This paragraph does not mention WTPH2YR (see section 11).

Content change: "The questions about the participants' knowledge of their own levels of A1C, blood pressure, and cholesterol and knowledge of appropriate target levels, as suggested by their physicians were not collected in this survey cycle."

---

## 5. Fasting questionnaire, FASTQX_L (August 2021-August 2023)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/FASTQX_L.htm (HTTP 200, accessed 2026-10-07)

Data file URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/FASTQX_L.xpt (Laboratory listing "FASTQX_L Data [XPT - 1.3 MB]", Date Published "September 2024"; HEAD: HTTP 200, content-length 1330000, Last-Modified "Tue, 02 Apr 2024 20:21:30 GMT").

Release dates: "First Published: September 2024", "Last Revised: NA".

Eligible sample: "Examined participants aged 1 year and older were eligible." Mode: "The MEC phlebotomist administered the questionnaire to determine the fasting status of the survey participant."

How fasting time is computed (exact):

> "Use PHAFSTHR and PHAFSTMN to determine the duration of fasting in hours and minutes, respectively. When calculating a fasting time in hours and minutes, pay careful attention to the other times in hours and minutes."

> "If you are using fasting status in any of your analyses, please consider the answers to PHACOFHR/PHACOFMN, PHAALCHR/PHAALCMN, PHAGUMHR/PHAGUMMN/ PHAANTHR/PHAANTMN, and PHASUPHR/PHASUPMN with the times in hours and minutes in addition to the PHAFSTHR and PHSFSTMN times."

> "Use PHDSESN to determine the session in which the survey participant was examined."

Note: the codebook variable in FASTQX_L is PHDSESNZ, not PHDSESN, and "PHSFSTMN" in the quoted sentence appears to be a typo for PHAFSTMN.

Admissible fasting window: FASTQX_L itself does not state one. The 8 to less than 24 hour rule is stated in GLU_L (section 2).

Codebook entries (Target for all: "Both males and females 1 YEARS - 150 YEARS"; total 8727):

- PHAFSTHR, "Total length of 'food fast' (hours)", English Text "The time (in hours) between when the examinee last ate or drank anything other than water and the time of the venipuncture." Codes: "0 to 29" 8609; 30 "30 hours or more" 23; Missing 95.
- PHAFSTMN, "Total length of 'food fast' (minutes)". Codes: "0 to 59" 8632; Missing 95.
- PHDSESNZ, "Session in which SP was examined". Codes: 0 morning 4756; 1 afternoon/evening 3971; Missing 0.
- PHQ020 to PHQ060 (Yes 1 / No 2 / Missing; no refused or don't know codes printed) with hours/minutes pairs PHACOFHR/MN, PHAALCHR/MN, PHAGUMHR/MN, PHAANTHR/MN, PHASUPHR/MN. Yes counts: coffee/tea with cream or sugar 29; alcohol 25; gum, mints, lozenges or cough drops 311; antacids, laxatives, anti-diarrheals 105; dietary supplements 219.

### 5a. Laboratory Procedures Manual 2021 (fasting instructions)

URL: https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/manuals/2021-Laboratory-Procedures-508.pdf (linked from GHB_L and GLU_L; 500 PDF pages; read 2026-10-07)

- Section 3.8 (printed page "3-22", PDF p. 75): "No primary SPs aged 1-11 years or SPs assigned to afternoon or evening blocks are asked to fast. All other primary SPs aged 12 years and older appointed to a morning block are asked to fast for 8 hours; this includes diabetics."
- (PDF p. 76) "The phlebotomist administers the fasting questionnaire to all SPs, and the application calculates and displays the fasting time in number of hours and minutes."
- (PDF p. 57) "For SPs aged 12 years and older who are examined during a morning session, the form includes the question, "Did you eat or drink anything, other than plain water, after 11:30 p.m. last night?""
- (PDF p. 83) "If the SP will not meet the 8-hour fast during the session, they are prompted to have their blood drawn without waiting for the 8-hour fast."

Inference (not stated in GLU_L): the fasting subsample corresponds to participants aged 12 and older examined in a morning session. The NHANES weighting tutorial describes the general design the same way (section 7.1).

---

## 6. Reproductive health (RHQ_L), urine pregnancy test (UCPREG_L), and gestational diabetes

### 6a. RHQ_L

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/RHQ_L.htm (HTTP 200, accessed 2026-10-07)
Data file URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/RHQ_L.xpt (Questionnaire listing "RHQ_L Data [XPT - 400.4 KB]", Date Published "September 2024"; HEAD: HTTP 200, content-length 410000, Last-Modified "Tue, 02 Jan 2024 14:13:19 GMT").
Instrument PDF (listed): https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/questionnaires/RHQ-ACASI-L-508.pdf (not opened).

Release dates: "First Published: September 2024", "Last Revised: NA". Eligible: "Female participants aged 12 years and older were eligible."

Mode change: "These questions were asked at the Mobile Examination Center (MEC) during the MEC Interview using the Audio Computer-Assisted Self-Interview (ACASI) system, in English and Spanish only. The interview was not administered to proxy informants due to the sensitive nature of the questions. In previous NHANES cycles, reproductive health questions were asked face-to-face using the Computer Assisted Personal Interview system."

Gestational diabetes item dropped (exact):

> "Several questions were dropped in NHANES August 2021-August 2023 and are not included in this data file: RHQ.018, RHQ.020, RHQ.070, RHQ.071, [...], RHQ.074, RHQ.076, RHQ.160, RHQ.162, RHQ.171, RHQ.172, RHQ.180, RHQ.190, RHQ.197, RHQ.421, RHQ.540,[...], RHQ.554. RHQ.570."

(Each "[...]" stands for an item range printed on the page, RHQ.073A to RHQ.073N and RHQ.542A to RHQ542D. The page joins each range with a dash character that is left out here; nothing else is omitted.)

RHQ.162 is the gestational diabetes question in the 2017-March 2020 file (section 9e). A search of the full 2021-2023 Questionnaire variable list (public and RDC rows) for "gestation" and "pregnan" returned only DIQ010, RHD143, RHQ131 (public and RDC versions) and two WIC items (https://wwwn.cdc.gov/nchs/nhanes/search/variablelist.aspx?Component=Questionnaire&Cycle=2021-2023). No gestational diabetes variable was found for 2021-2023.

Disclosure limit: "This public use data file excludes select variables related to pregnancy and hysterectomy for females aged 12-19 and older than 44 years due to disclosure risks."

RHD143, SAS label "Are you pregnant now?", Target "Females only 20 YEARS - 44 YEARS". Codes: 1 Yes 30; 2 No 536; 7 Refused 0; 9 Don't know 1; Missing 3350. Analytic note: "RHD143: Current pregnancy status from question: "are you pregnant now?" Please note that these responses may differ from the pregnancy status variable RIDEXPRG in the DEMO data file."

### 6b. UCPREG_L (urine pregnancy test)

Documentation URL: https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/UCPREG_L.htm (HTTP 200, accessed 2026-10-07); data URL https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/UCPREG_L.xpt (HEAD 200, content-length 19200).

- Eligible: "Examined female participants aged 12–59 years, and menstruating females aged 8–11 years were eligible. However, due to disclosure risks, only females 20-44 years of age have urine pregnancy results in this file."
- URXPREG "Urine Pregnancy Result", Target "Females only 20 YEARS - 44 YEARS": 1 Positive 41; 2 Negative 1078; 3 Not Done 11; 4 Invalid 0; Missing 4.

### 6c. Implications for pregnancy handling (from the sources above)

- Current pregnancy can be identified in public data only for women aged 20 to 44 (RIDEXPRG, RHD143, URXPREG). Pregnant participants aged 12 to 19 or 45 to 59 cannot be identified; DEMO_L says they are under 1% of those age groups.
- RIDEXPRG = 3 ("Cannot ascertain", n = 397 printed) needs an explicit rule (keep or exclude) and a sensitivity check.
- The "Other than during pregnancy" wording of DIQ010 is displayed only to females aged 20 and older (codebook), while the help screen tells all respondents to exclude gestational diabetes.
- History of gestational diabetes cannot be studied in 2021-2023 public data because RHQ.162 was dropped.
- The D-100 method file states HbA1c "should not be used to replace glucose testing in pediatric patients, pregnant women, or patients with Type 1 Diabetes."

---

## 7. Weighting tutorial, cycle guidance, variance estimation

### 7.1 NHANES weighting tutorial

URL: https://wwwn.cdc.gov/nchs/nhanes/tutorials/weighting.aspx (HTTP 200, accessed 2026-10-07; the page itself carries no visible revision date in the extracted text)

- Subsample weights: "For example, participants who were selected to schedule their MEC exam in a morning session (half of all examined participants) were asked to give a fasting blood sample." and "Each component subsample has its own designated weight, which accounts for the additional probability of selection into the subsample component, as well as an additional adjustment for component nonresponse."
- Nonresponse adjustment scope: "Adjustments made for survey non-response account only for sampled person interview or exam non-response, but not for item non-response".
- Smallest-subpopulation rule: "A good rule of thumb is to use "the least common denominator" where the variable that was collected on the smallest number of respondents is the "least common denominator." The sample weight that applies to that variable is the appropriate one to use for that particular analysis." and "You must use the weight of the smallest subpopulation that includes all the variables you want to include in your analysis."
- Example 5, specific to 2021-2023: "You are performing an NHANES August 2021-August 2023 analysis looking at the association of age and serum vitamin D levels among adults age 20 and older." Answer: "You would use phlebotomy weights (wtph2yr). For the August 2021-August 2023 cycle, analysis of nonresponse patterns for the phlebotomy component of the MEC exam revealed differences by age group and race and Hispanic origin. For the first time, phlebotomy weights were included to address possible nonresponse bias."
- Warning: "It is important to check all the variables in your analysis and use the weight that is appropriate for the variable of interest that was collected on the smallest number of respondents, otherwise you will not obtain estimates appropriately adjusted for survey non-response." and "Similarly, for August 2021-August 2023, the phlebotomy weights are provided in the data files for each laboratory component."
- Combining cycles: "It is generally not recommended to combine the August 2021-August 2023 cycle with other cycles given the 1.5-year gap between this cycle and the 2017-March 2020 cycle."
- Pre-pandemic weight scaling example: "The 2017-March 2020 pre-pandemic files represent a 3.2-year period, in contrast to previous data releases which represent a 2-year period."
- Population counts: "analysts are advised NOT to use the sum of weights to determine population estimates for a given health condition because the potential for exclusions or missing data for that health condition may lead to population underestimates."

### 7.2 Brief Overview for August 2021-August 2023 (cycle analytic guidelines)

URL: https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewbrief.aspx?Cycle=2021-2023 (title "Brief Overview of Sample Design, Nonresponse Bias Assessment, and Analytic Guidelines for NHANES August 2021-August 2023"; "First published: September 20, 2024"; accessed 2026-10-07)

- "A full report on the sample design, nonresponse bias assessment, survey weighting method and analytic guidelines is forthcoming."
- Response rates: "The unweighted interview and examination response rates for the August 2021 – August 2023 cycle were 34.6% and 25.7% respectively." and "These are markedly lower than those for 2017 – March 2020 which were 51.0% and 46.9% respectively." Footnote: the rates are unconditional and incorporate "screener response rate 65.6%"; the 2017-March 2020 screener rate was "88.7%".
- Design: "this cycle included 30 primary sampling units (PSUs)"; no oversampling by race and Hispanic origin and income; "this was the first cycle where all the people encountered in a household who were ages 0–19 years and 60 years and older were selected."
- Weights released: "the August 2021 – August 2023 data have been released with the initial set of survey weights, which had the lowest impact on variance".
- New phlebotomy weights: "Most notably, young children had a lower response rate to the blood draw. Therefore, an additional phlebotomy weight has been included in this data release to address possible nonresponse bias. This weight should be used for analyses that use variables derived from blood analytes and is included in all relevant data files."
- Choosing the weight: "The NHANES Tutorial reviews how to select the appropriate survey weights for NHANES analyses using the principle that the weights for the smallest subpopulation should be used." and "For this cycle, when a blood analyte variable is included, it is best to use the phlebotomy weights which account for nonresponse to the blood draw in the MEC."
- Precision: "Estimates for subgroups may have lower precision and as a result, statistical power to detect differences between groups may be lower. In addition, estimates for age and race/Hispanic origin subgroups, particularly children and adolescent age groups, may show unexpected patterns."
- Combining: "Analysts should use caution when combining August 2021-August 2023 with earlier cycles." Direct comparison: "Direct statistical comparison may be conducted using standard analytic techniques and guidance for analyses using sample weights and design variables".
- Trend midpoint: "The midpoint is August 2022 (or 2022.7)."

The page does not say how WTSAF2YR relates to WTPH2YR (for example, whether WTSAF2YR was derived from or calibrated to WTPH2YR). Not documented.

### 7.3 Variance estimation tutorial

URL: https://wwwn.cdc.gov/nchs/nhanes/tutorials/VarianceEstimation.aspx (accessed 2026-10-07)

- "Currently NCHS recommends the use of the Taylor Series Linearization methods for variance estimation in all NHANES surveys".
- Degrees of freedom: "the design degrees of freedom are properly calculated by subtracting the number of clusters (strata) in the first stage of sampling from the number of primary sampling units (PSUs) selected in the first stage of sampling" and "Most two-year public data releases of continuous NHANES have 15 degrees of freedom (30 PSUs – 15 strata.)" With DEMO_L's 15 strata and 30 PSUs, design df = 15.
- Subgroups: "your statistical software requires all observations with a non-zero value for your weight variable, as well as an indicator for which records are in your subpopulation of interest." and "For an analysis on a subgroup, the degrees of freedom should be based on the number of strata and PSUs containing the observations of interest."

### 7.4 Survey Methods and Analytic Guidelines page and the 2026 quality guidance

URL: https://wwwn.cdc.gov/nchs/nhanes/analyticguidelines.aspx (accessed 2026-10-07). The newest sample design and estimation report listed is "National Health and Nutrition Examination Survey, 2017–March 2020 Prepandemic File: Sample Design, Estimation, and Analytic Guidelines" (May 2022, https://www.cdc.gov/nchs/data/series/sr_02/sr02-190.pdf). No 2021-2023 Series 2 weighting report is listed. The page lists "Guidelines for High Quality Analyses of NHANES Data" (January 2026).

Guidelines for High Quality Analyses of NHANES Data: https://wwwn.cdc.gov/nchs/nhanes/QualityAnalysesGuidelines.aspx ("First published: January 26, 2026"). Relevant wording:

- "Failing to account for skip patterns in questionnaires and lab testing algorithms can result in inappropriate denominators for estimates. Researchers should specify the questions used in their analyses, include definitions of denominators in proportions, and assess whether sample sizes and estimates appear plausible."
- "Analysts presenting trend analyses of lab results should assess and document whether lab methods remained constant for the period studied."
- "Analyses should use appropriate survey weights and specify which weights were used."
- "If the survey design variables are not incorporated using specific statistical software (e.g., SUDAAN or survey procedures in SAS or R), analysts will overestimate precision".
- Statistical reliability guidance: https://www.cdc.gov/nchs/data/series/sr_02/sr02_175.pdf (linked, not opened).
- The page also notes concerns about low-quality NHANES-based studies "driven by freely available data and new artificial intelligence tools." This is relevant to how the manuscript documents its weight choices, denominators and checks.

### 7.5 Ethics review (for the ethics statement)

ERB page: https://www.cdc.gov/nchs/nhanes/about/erb.html (`curl` returned HTTP 403; read on the web page and confirmed in a web browser on 2026-10-07). Rows: "NHANES 2025-2026 | Protocol #2024-01"; "NHANES 2021-2022 | Protocol #2021-05"; "NHANES 2019–2020 | Continuation of Protocol #2018-01"; "NHANES 2017-2018 | Protocol #2018-01 Effective beginning October 26, 2017"; "Continuation of Protocol #2011-17 Effective through October 26, 2017"; page dated "Mar. 24, 2026". The table labels the cycle "NHANES 2021-2022", not "August 2021-August 2023". Consent: the NHANES "Brochures and Consent Documents" page for the cycle (https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/documents.aspx?Cycle=2021-2023, read in a web browser on 2026-10-07) lists an Adult Consent Brochure, a Child Assent Brochure, a MEC Consent and Assent Form, and a Specimen Storage and Continuing Studies Consent, and states that these documents "are part of the protocol".

### 7.6 Suggested citation (from NCHS)

URL: https://wwwn.cdc.gov/nchs/nhanes/NhanesCitation.aspx. For data: "Centers for Disease Control and Prevention (CDC). National Center for Health Statistics (NCHS). National Health and Nutrition Examination Survey Data. Hyattsville, MD: U.S. Department of Health and Human Services, Centers for Disease Control and Prevention, [appropriate year][web URL]."

---

## 8. Is there a newer complete NHANES release? (status on 2026-10-07)

Short answer: no. As of 2026-10-07, August 2021-August 2023 is the most recent NHANES cycle with public GHB, GLU, DEMO, DIQ and FASTQX files.

What was seen:

- Site navigation lists "NHANES 2025-2027" above "NHANES 08/2021-08/2023". There is no 2023-2025 entry in the navigation.
- https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2025-2027 and the Demographics equivalent are headed "These datasets are not yet released" and say "Please sign up for the NHANES Listerv or check the What's New page for updates on NHANES data releases."
- https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?Cycle=2025-2027 shows the headings Demographics, Dietary, Examination, Laboratory and Questionnaire Data, but each link target is "#". Only "Brochures and Consent Documents" has a real link.
- https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewbrief.aspx?Cycle=2025-2027 says "The requested survey cycle is not valid or content is not available."
- https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/releasenotes.aspx?Cycle=2025-2027 is headed "NHANES 2025-2027 Release Notes" but its body text describes the 2019-March 2020 convenience samples, which looks like placeholder text, not a 2025-2027 release.
- The all-cycles Laboratory listing (https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory) lists GHB_L, GLU_L and FASTQX_L (2021-2023, "September 2024") as the newest glycohemoglobin, plasma fasting glucose and fasting questionnaire files. No file with an "_M" suffix appears in that page's HTML.
- Latest Data Releases (https://wwwn.cdc.gov/nchs/nhanes/DataReleases/Latest.aspx): the newest entries are "September 2026" (reports on August 2021-August 2023 data) and "August 2026" data releases BCHE_L, COT_L, PFAS_L (2021-2023) and DEET_J (2017-2018). There are no 2025-2027 data releases.
- NHANES "New Content and Proposal Guidelines" letter dated September 15, 2025 (https://wwwn.cdc.gov/nchs/nhanes/proposalguidelines.aspx): "NHANES relaunched in early 2025 and the first few months of the survey have proven quite challenging." and "Therefore, we have expanded the length of the data collection cycle to include calendar year 2027."
- Federal Register notice (publication date 5/13/2024, FR Doc. 2024-10357, https://public-inspection.federalregister.gov/2024-10357.pdf): "In 2025-2026, the Program is not considering any substantial changes to NHANES content or procedures."
- A web search summary claimed that NHANES left the field in August 2023 and returned in January 2025 with a new contractor. The supporting document (stacks.cdc.gov) returned HTTP 403, so this is **not verified**.
- Probe, not evidence: a hand-built URL with `Cycle=2023-2025` returned a page titled "2023-2025 Laboratory Data - Continuous NHANES" that listed the same `_L` files from `/Public/2021/`. This URL is not linked from the site navigation and appears to map to the 2021-2023 cycle. It is not a separate release and is not used anywhere in this note.

---

## 9. 2017-March 2020 pre-pandemic files (possible separate replication)

Listing pages (accessed 2026-10-07): https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2017-2020, ...Component=Demographics&Cycle=2017-2020, ...Component=Questionnaire&Cycle=2017-2020.

| File | Doc URL | Data URL | Listing date | HEAD (size, Last-Modified) |
|---|---|---|---|---|
| P_GHB | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_GHB.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_GHB.xpt | May 2021 | 167600; Fri, 05 Mar 2021 |
| P_GLU | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_GLU.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_GLU.xpt | May 2021 | 164160; Wed, 17 Mar 2021 |
| P_DEMO | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_DEMO.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_DEMO.xpt | May 2021 | 3614720; Tue, 23 Mar 2021 |
| P_DIQ | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_DIQ.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_DIQ.xpt | May 2021 | 3361520; Thu, 04 Mar 2021 |
| P_FASTQX | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_FASTQX.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_FASTQX.xpt | May 2021 | 2096800; Tue, 09 Mar 2021 |
| P_RHQ | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_RHQ.htm | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/P_RHQ.xpt | August 2021 | 1365600; Thu, 10 Jun 2021 |

All six documentation pages show "Last Revised: NA".

### 9a. P_GHB

- Variables: SEQN and LBXGH only. There is **no phlebotomy weight** in the pre-pandemic release.
- Eligible: "All examined participants 12 years and older in the NHANES 2017-March 2020 pre-pandemic sample were eligible."
- LBXGH: "2.8 to 16.2" 9737; Missing 672.
- Weight wording: "The resulting sample weights in the demographic data file should be used to calculate estimates from the combined cycles." So the HbA1c weight for this file is WTMECPRP (P_DEMO).
- Phlebotomy coverage: "in 2017-March 2020, approximately 76% of children aged 1-17 years who were examined in the MEC provided a blood specimen through phlebotomy, while 95% of examined adults age 18 and older provided a blood specimen."
- Secondary-method instrument change: "This instrument change did not significantly affect the resulted glycohemoglobin values; the mean relative error between results from the two instruments was 0.5% (ranged from -4.0% to 5.2%)." Primary method was the Tosoh G8 (method files GHB-J-G8-508.pdf and GHB-K-G8-MET-508.pdf).

### 9b. P_GLU

- Variables: SEQN, WTSAFPRP, LBXGLU, LBDGLUSI.
- WTSAFPRP "Fasting Subsample Weight": "4808.069916 to 741259.18875" 4476; 0 "No Lab Result or Not Fasting for 8 -< 24 Hours" 614; Missing 0. Total 5090.
- LBXGLU "47 to 524" 4744; Missing 346.
- Rule (exact): "Participants included in the fasting subsample but did not provide a blood specimen (n=346) have an assigned sample weight value of "0" in their records. In addition, participants whom provided blood specimen but did not meet the 8 to less than 24 hour fasting criteria (n=268) have the sample weight value assigned as "0" (WTSAFPRP=0) as well."
- "In the 2017-March pre-pandemic NHANES cycle, the variables PHAFSTHR (total length of "food fast", hours) and PHAFSTMN (Total length of "food fast", minutes) will not be reported in this file. PHAFSTHR and PHAFSTMN can be found in the Fasting Questionnaire File (P_FASTQX)."

### 9c. P_DEMO

- SDDSRVYR: "A value of "66" denotes NHANES 2017–March 2020 pre-pandemic data."
- Weights: "The special sample weights (WTINTPRP, WTMECPRP) should be used for all NHANES 2017-March 2020 pre-pandemic data analyses."
- WTMECPRP "Full sample MEC exam weight": "0 to 367555.74298 | Range of Values | 15560" (zeros are inside the printed range; there is no separate 0 code). WTINTPRP: "1017.784203 to 338363.60019".
- MVUs: "Twenty-four masked variance strata and 49 masked primary sampling units (PSUs) are included in the NHANES 2017-March 2020 pre-pandemic demographics file. Each stratum has 2-3 PSUs." Using the tutorial formula, design df = 49 minus 24 = 25. SDMVSTRA "149 to 172"; SDMVPSU "1 to 3".
- RIDSTATR: 1 Interviewed only 1260; 2 Both 14300. RIDEXPRG (Females 20-44): 1 = 87; 2 = 1604; 3 = 183; Missing 13686. RIDRETH1 codes 1 to 5 and RIDRETH3 codes 1, 2, 3, 4, 6, 7 as in DEMO_L.
- Restriction: "These sample weights are not appropriate for independent analyses of the 2019-2020 data and will not yield nationally representative results for either the 2017-2018 data alone or the 2019-March 2020 data alone."

### 9d. P_DIQ and P_FASTQX

- P_DIQ DIQ010: same English Text and CAPI instruction as DIQ_L (including "IF SP IS FEMALE AND AGE >= 20, DISPLAY "OTHER THAN DURING PREGNANCY..."). Codes: 1 Yes 1445; 2 No 13249; 3 Borderline 284; 7 Refused 0; 9 Don't know 8; Missing 0. DIQ050: 1 = 427, 2 = 1017, 9 = 1, Missing 13541. DIQ070: 1 = 1128, 2 = 1546, 9 = 5, Missing 12307. Same DIQ159 and DIQ065 check items. "The insulin use question (variables DIQ050, DID060, DIQ060U) was only reported for participants with diagnosed diabetes in the P_DIQ data."
- P_FASTQX: same "Use PHAFSTHR and PHAFSTMN..." note. PHAFSTHR "0 to 29" 13269, 30 "30 hours or more" 36, Missing 467. Session variable is **PHDSESN** with three codes: 0 morning 6454; 1 afternoon 5090; 2 evening 2228 (2021-2023 uses PHDSESNZ with two codes).

### 9e. P_RHQ (gestational diabetes available here, not in 2021-2023)

- RHQ162 "During pregnancy, told you have diabetes": "During {any/your/SP's} pregnancy, {were you/was SP} ever told by a doctor or other health professional that {you/she} had diabetes, sugar diabetes or gestational diabetes? Please do not include diabetes that {you/SP} may have known about before the pregnancy." Target "Females only 20 YEARS - 150 YEARS". Codes: 1 Yes 293; 2 No 3098; 3 Borderline 17; 7 Refused 1; 9 Don't know 1; Missing 1904.
- RHD143 (Females 20-44): 1 = 67; 2 = 1009; 9 = 16; Missing 4222.
- "This data file contains complete records for variables related to pregnancy only for females aged 20-44 years."

### 9f. Guidance on combining or comparing with 2021-2023

- Tutorial: "It is generally not recommended to combine the August 2021-August 2023 cycle with other cycles given the 1.5-year gap between this cycle and the 2017-March 2020 cycle."
- Brief Overview 2021-2023: "Analysts should use caution when combining August 2021-August 2023 with earlier cycles." Direct comparison is allowed: "Direct statistical comparison may be conducted using standard analytic techniques".
- 2021-2023 Release Notes (https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/releasenotes.aspx?Cycle=2021-2023): "This data release will allow for analyses of data collected in August 2021-August 2023 as well as the combination of these data with those collected in previous cycles from 1999-2000 through 2017-March 2020."
- 2017-March 2020 Brief Overview (https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewbrief.aspx?cycle=2017-2020, "First published: May 27, 2021", "Last Updated: June 22, 2021"): "comparisons or examination of trends between 2017-2018 and 2019-March 2020 data are not possible and should not be conducted because the 2019-March 2020 data do not represent any defined population." and "the 2017-March 2020 pre-pandemic files represent a 3.2-year period".
- No source found says that pre-pandemic data "must not" be combined with 2021-2023; the official wording is "generally not recommended" (tutorial) and "use caution" (Brief Overview). A separate, unpooled replication in the 2017-March 2020 file is consistent with all of these sources. Its weight comparison is different: there is no phlebotomy weight, so the pre-pandemic contrast is WTMECPRP (HbA1c) versus WTSAFPRP (fasting glucose), not WTPH2YR versus WTSAF2YR.

---

## 10. Variable table (planned analysis variables)

Type is the documented content. All are numeric fields in SAS transport (.xpt) files. "Missing" means the SAS missing value "." unless stated. Universe is the codebook "Target" plus the skip logic quoted above.

| File | Variable | SAS label | Type / units | Value codes, including refused / don't know / missing | Universe |
|---|---|---|---|---|---|
| DEMO_L | SEQN | Respondent sequence number | ID | none | All participants, 0-150 y |
| DEMO_L | SDDSRVYR | Data release cycle | categorical | 12 = August 2021-August 2023; . missing (0) | All |
| DEMO_L | RIDSTATR | Interview/Examination status | categorical | 1 Interviewed only; 2 Both interviewed and MEC examined; . (0) | All |
| DEMO_L | RIAGENDR | Gender | categorical | 1 Male; 2 Female; . (0) | All |
| DEMO_L | RIDAGEYR | Age in years at screening | years, integer | 0-79; 80 = 80 years and over (top-coded); . (0) | All |
| DEMO_L | RIDRETH1 | Race/Hispanic origin | categorical | 1 Mexican American; 2 Other Hispanic; 3 NH White; 4 NH Black; 5 Other Race incl. multiracial; . (0) | All |
| DEMO_L | RIDRETH3 | Race/Hispanic origin w/ NH Asian | categorical | 1; 2; 3; 4; 6 NH Asian; 7 Other incl. multiracial; code 5 unused; . (0) | All |
| DEMO_L | RIDEXPRG | Pregnancy status at exam | categorical | 1 Yes (positive lab test or self-reported); 2 Not pregnant; 3 Cannot ascertain; . missing outside universe | Females 20-44 (public release); interviewed-only also coded 3 |
| DEMO_L | WTINT2YR | Full sample 2-year interview weight | weight | 4584.463196 to 170968.343177; . (0) | All |
| DEMO_L | WTMEC2YR | Full sample 2-year MEC exam weight | weight | 4581.595095 to 227108.296958; 0 Not MEC examined; . (0) | All |
| DEMO_L | SDMVSTRA | Masked variance pseudo-stratum | design | 173 to 187 (15 strata) | All |
| DEMO_L | SDMVPSU | Masked variance pseudo-PSU | design | 1 to 2 | All |
| DEMO_L | DMDEDUC2 (optional) | Education level - Adults 20+ | categorical | 1-5; 7 Refused; 9 Don't know; . | 20-150 y |
| DEMO_L | INDFMPIR (optional) | Ratio of family income to poverty | ratio | 0 to 4.99; 5 = 5.00 or more; . | All |
| GHB_L | SEQN | Sequence number | ID | none | Examined, 12-150 y |
| GHB_L | WTPH2YR | Phlebotomy 2 Year Weight | weight | 4391.8220579 to 241728.85724; 0 No blood sample provided; . (0) | Examined, 12-150 y |
| GHB_L | LBXGH | Glycohemoglobin (%) | percent (NGSP units, 1 decimal) | 3.2 to 17.1; 0 No Lab Result (0 records); . missing (484) | Examined, 12-150 y |
| GLU_L | SEQN | Respondent sequence number | ID | none | Fasting subsample, 12-150 y |
| GLU_L | WTSAF2YR | Fasting Subsample 2 Year MEC Weight | weight | 11459.183689 to 561922.42956; 0 No Lab Result or Not Fasting for 8 to <24 hours; . (0) | Fasting subsample, 12-150 y |
| GLU_L | LBXGLU | Fasting Glucose (mg/dL) | mg/dL | 59 to 561; . missing (324) | Fasting subsample, 12-150 y |
| GLU_L | LBDGLUSI | Fasting Glucose (mmol/L) | mmol/L (= mg/dL x 0.05551) | 3.28 to 31.1; . (324) | Fasting subsample, 12-150 y |
| DIQ_L | DIQ010 | Doctor told you have diabetes | categorical | 1 Yes; 2 No; 3 Borderline (instrument: "Borderline or prediabetes"); 7 Refused; 9 Don't know; . (4) | 1-150 y; "Other than during pregnancy" shown to females 20+ |
| DIQ_L | DIQ050 | Taking insulin now | categorical | 1 Yes; 2 No; 7 Refused; 9 Don't know; . | Asked only if DIQ010 = 1 |
| DIQ_L | DIQ070 | Take diabetic pills to lower blood sugar | categorical | 1 Yes; 2 No; 7 Refused; 9 Don't know; . | Asked if DIQ010 = 1 or 3, or DIQ160 = 1 |
| DIQ_L | DIQ160 (sensitivity) | Ever told you have prediabetes | categorical | 1 Yes; 2 No; 7 Refused; 9 Don't know; . | 12-150 y, if not routed past by DIQ159 |
| FASTQX_L | PHAFSTHR | Total length of 'food fast' (hours) | hours | 0 to 29; 30 = 30 hours or more; . (95) | Examined, 1-150 y |
| FASTQX_L | PHAFSTMN | Total length of 'food fast' (minutes) | minutes | 0 to 59; . (95) | Examined, 1-150 y |
| FASTQX_L | PHDSESNZ | Session in which SP was examined | categorical | 0 morning; 1 afternoon/evening; . (0) | Examined, 1-150 y |
| FASTQX_L | PHQ020-PHQ060 and PHAxxxHR/MN (sensitivity) | items consumed since last meal, with hours/minutes | categorical / time | 1 Yes; 2 No; .; times as ranges | Examined, 1-150 y |
| RHQ_L | RHD143 (sensitivity) | Are you pregnant now? | categorical | 1 Yes; 2 No; 7 Refused; 9 Don't know; . | Females 20-44 (public release) |
| UCPREG_L | URXPREG (sensitivity) | Urine Pregnancy Result | categorical | 1 Positive; 2 Negative; 3 Not Done; 4 Invalid; . | Females 20-44 (public release) |
| P_DEMO | SEQN, SDDSRVYR, RIDSTATR, RIAGENDR, RIDAGEYR, RIDRETH1, RIDRETH3, RIDEXPRG | as DEMO_L | as DEMO_L | SDDSRVYR = 66; other codes as DEMO_L | All (RIDEXPRG females 20-44) |
| P_DEMO | WTINTPRP | Full sample interview weight | weight | 1017.784203 to 338363.60019 | All |
| P_DEMO | WTMECPRP | Full sample MEC exam weight | weight | 0 to 367555.74298 (zeros inside range) | All |
| P_DEMO | SDMVSTRA, SDMVPSU | Masked variance pseudo-stratum / PSU | design | 149 to 172 (24 strata); 1 to 3 | All |
| P_GHB | LBXGH | Glycohemoglobin (%) | percent | 2.8 to 16.2; . (672) | Examined, 12-150 y |
| P_GLU | WTSAFPRP | Fasting Subsample Weight | weight | 4808.069916 to 741259.18875; 0 No Lab Result or Not Fasting for 8 -< 24 Hours; . (0) | Fasting subsample, 12-150 y |
| P_GLU | LBXGLU, LBDGLUSI | Fasting Glucose (mg/dL), (mmol/L) | mg/dL, mmol/L | 47 to 524; 2.61 to 29.1; . (346) | Fasting subsample, 12-150 y |
| P_DIQ | DIQ010, DIQ050, DIQ070 | as DIQ_L | categorical | as DIQ_L | as DIQ_L |
| P_FASTQX | PHAFSTHR, PHAFSTMN | Total length of "food fast," hours / minutes | hours / minutes | 0-29, 30 = 30+; 0-59; . (467) | Examined, 1-150 y |
| P_FASTQX | PHDSESN | Session in which SP was examined | categorical | 0 morning; 1 afternoon; 2 evening | Examined, 1-150 y |
| P_RHQ | RHQ162 (pre-pandemic only) | During pregnancy, told you have diabetes | categorical | 1 Yes; 2 No; 3 Borderline; 7 Refused; 9 Don't know; . | Females 20-150 y (pregnancy items complete only for 20-44) |

---

## 11. Discrepancies and gaps in the documentation, and how the analysis handles them

1. **Weight guidance differs across sources.** GHB_L, the Brief Overview, and tutorial Example 5 say to use WTPH2YR for blood analytes. GLU_L says to use its own subsample weight (WTSAF2YR) and does not mention WTPH2YR. DIQ_L says that when DIQ is merged with "laboratory full sample data, the MEC examination weights should be used", which predates or ignores WTPH2YR. The tutorial's "smallest subpopulation" rule points to WTSAF2YR whenever fasting glucose is part of the definition, and to WTPH2YR for HbA1c-only and HbA1c plus self-report definitions. The analysis follows this rule and cites the Brief Overview and tutorial.
2. **The relationship between WTSAF2YR and WTPH2YR is not documented.** Whether WTSAF2YR includes the same phlebotomy nonresponse adjustment as WTPH2YR is not stated. The Brief Overview says the full weighting report "is forthcoming", and none is listed on the guidelines page as of 2026-10-07.
3. **Fasting window.** WTSAF2YR = 0 for 311 participants with glucose values outside "8 to less than 24 hour" fasting. Analyses must filter on WTSAF2YR > 0, not on non-missing LBXGLU. Using those 311 values "would require" reweighting (GLU_L).
4. **HbA1c instrument change.** G8 to D-100 partway through the cycle, with no adjustment applied, a reported mean 2.3% higher G8 value, no changeover date on the documentation page, and no instrument flag in the public file. Reported as a measurement limitation; a per-instrument sensitivity analysis is not possible with public data.
5. **Possible HbA1c item nonresponse among positive-weight records** (about 35, arithmetic on printed counts). Checked in the data: these adults are counted in the participant flow and reported as a limitation, without reweighting.
6. **Gestational diabetes.** The RHQ.162 item was dropped in 2021-2023, so no gestational diabetes history variable exists for this cycle. DIQ010 excludes pregnancy-only diabetes through its wording (females 20+) and help screen (all respondents).
7. **Pregnancy exclusion limited to ages 20-44** in public files. RIDEXPRG = 3 is handled by a stated rule in the phenotype specification.
8. **Variable name and text inconsistencies.** FASTQX_L text says "PHDSESN" while the 2021-2023 variable is PHDSESNZ (two categories, versus three in P_FASTQX). The text also says "PHSFSTMN" (typo). GLU_L mentions LBDGLULC, which is not in its codebook. The DIQ010 display rule in the instrument includes "DMQ.510 = 7 OR 9", which is not in the codebook and was not verified. DIQ010 code 3 is "Borderline" in the codebook and "Borderline or prediabetes" in the instrument.
9. **Gap length wording.** The gap is described as "15-month" (DEMO_L), "1.5-year" (Brief Overview, tutorial) and "16-month pause" (Brief Overview).
10. **Broken link.** The Laboratory Data Overview link for 2021 returns "The requested survey cycle is not valid or content is not available."
11. **Design df.** 15 for 2021-2023 (30 PSUs, 15 strata) and 25 for 2017-March 2020 (49 masked PSUs, 24 strata). Subgroup df can be lower.
12. **Data file provenance.** HEAD Last-Modified dates for several 2021-2023 .xpt files (for example DIQ_L "Mon, 04 Dec 2023") are earlier than the documented publication date (September 2024). This is server metadata, not a documented revision. SHA-256 checksums and download timestamps were recorded at download (source_manifest.json).

---

## 12. Source list (all accessed 2026-10-07)

| Source | URL | Retrieval |
|---|---|---|
| GHB_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm | curl, HTTP 200 |
| GLU_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GLU_L.htm | curl, HTTP 200 |
| DEMO_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DEMO_L.htm | curl, HTTP 200 |
| DIQ_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/DIQ_L.htm | curl, HTTP 200 |
| DIQ instrument 2021-2023 | https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/questionnaires/DIQ-L-508.pdf | curl + pypdf |
| FASTQX_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/FASTQX_L.htm | curl, HTTP 200 |
| RHQ_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/RHQ_L.htm | curl, HTTP 200 |
| UCPREG_L documentation | https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/UCPREG_L.htm | curl, HTTP 200 |
| GHB D-100 method | https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GHB-L-MET-D-100-508.pdf | curl + pypdf |
| GHB G8 method | https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GHB-L-MET-G8-508.pdf | curl + pypdf |
| GLU method | https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/labmethods/GLU-L-MET-508.pdf | curl + pypdf |
| Laboratory Procedures Manual 2021 | https://wwwn.cdc.gov/nchs/data/nhanes/public/2021/manuals/2021-Laboratory-Procedures-508.pdf | curl + pypdf |
| Plan and Operations, Aug 2021-Aug 2023 | https://www.cdc.gov/nchs/data/series/sr_01/sr01-066.pdf | PDF download + pypdf |
| Lab / Demo / Questionnaire listings 2021-2023 | https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2021-2023 (and Demographics, Questionnaire) | curl |
| Lab / Questionnaire variable lists 2021-2023 | https://wwwn.cdc.gov/nchs/nhanes/search/variablelist.aspx?Component=Laboratory&Cycle=2021-2023 ; ...Component=Questionnaire&Cycle=2021-2023 | curl |
| Brief Overview 2021-2023 | https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewbrief.aspx?Cycle=2021-2023 | curl |
| Release Notes 2021-2023 | https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/releasenotes.aspx?Cycle=2021-2023 | curl |
| Weighting tutorial | https://wwwn.cdc.gov/nchs/nhanes/tutorials/weighting.aspx | curl |
| Variance estimation tutorial | https://wwwn.cdc.gov/nchs/nhanes/tutorials/VarianceEstimation.aspx | curl |
| Survey Methods and Analytic Guidelines | https://wwwn.cdc.gov/nchs/nhanes/analyticguidelines.aspx | curl |
| Guidelines for High Quality Analyses | https://wwwn.cdc.gov/nchs/nhanes/QualityAnalysesGuidelines.aspx | curl |
| Suggested citation | https://wwwn.cdc.gov/nchs/nhanes/NhanesCitation.aspx | curl |
| ERB approvals | https://www.cdc.gov/nchs/nhanes/about/erb.html | curl 403; confirmed in a web browser |
| 2025-2027 cycle pages | https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?Cycle=2025-2027 ; datapage ...Cycle=2025-2027 ; overviewbrief ...Cycle=2025-2027 ; releasenotes ...Cycle=2025-2027 | curl |
| Latest Data Releases | https://wwwn.cdc.gov/nchs/nhanes/DataReleases/Latest.aspx | curl |
| Proposal guidelines letter (Sept 15, 2025) | https://wwwn.cdc.gov/nchs/nhanes/proposalguidelines.aspx | curl |
| Federal Register 2024-10357 | https://public-inspection.federalregister.gov/2024-10357.pdf | curl + pypdf |
| 2017-March 2020 docs | P_GHB, P_GLU, P_DEMO, P_DIQ, P_FASTQX, P_RHQ .htm URLs in section 9 | curl |
| 2017-March 2020 Brief Overview | https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/overviewbrief.aspx?cycle=2017-2020 | curl |
