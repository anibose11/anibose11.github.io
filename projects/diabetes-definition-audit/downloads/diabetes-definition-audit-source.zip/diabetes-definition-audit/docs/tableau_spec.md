# Tableau import and interaction specification

No Tableau workbook was built or tested. The files below are analysis-ready aggregate tables for anyone who wants to build one.

## Files (results/exports/)

| File | Grain | Key columns |
|---|---|---|
| tableau_estimates.csv | one row per release x configuration | release, config_id, phenotype, sample_universe, weight, denominator_n_unweighted, numerator_n_unweighted, estimate_percent, ci_low_percent, ci_high_percent, se_percentage_points, degrees_of_freedom, nchs_status, suppressed |
| tableau_contrasts.csv | one row per release x contrast | release, contrast_id, kind, left/right configuration with phenotype, universe, weight, and unweighted denominator, difference_percentage_points, ci_low_pp, ci_high_pp, p_value (shown as <0.0001 when smaller), component_suppressed, units |
| tableau_missingness.csv | one row per release x group x laboratory status | group_variable, group, status, share_percent with interval, denominator, nchs_status |
| tableau_paired_by_group.csv | one row per release x group (domain P) | n_unweighted, HbA1c and glucose percents with intervals and NCHS status, difference in points with interval, difference_note, suppressed_component, units |

Units: `_percent` columns are percent of the stated sample universe; `_pp` columns are percentage points.

## Permitted interactions

- Filter rows by release, configuration, phenotype, domain, contrast kind, or group. Filtering only selects rows; each row is a complete survey estimate.
- Display intervals as error bars from the `ci_low` and `ci_high` columns.
- Show `nchs_status` as a mark property (for example hollow marks for flagged rows) and hide or mask rows with `suppressed = TRUE`, with a footnote giving the reason.

## Not permitted

- Summing, averaging, or re-weighting `estimate_percent` across rows, or computing a new percent from the numerator and denominator columns. Unweighted counts are not the basis of the weighted estimates.
- Computing a difference between two rows from different sample universes or weights and labeling it a definition difference. Use `tableau_contrasts.csv`, where each difference has its own design-based interval.
- Combining rows from the two releases into a trend.

## Labels

Every view should state the sample universe, the weight, and the unweighted denominator, and describe results as estimates under surveillance definitions.
