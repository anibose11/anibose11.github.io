# Data sources

All source files are public-use files released by the CDC National Center for Health Statistics (NCHS). Exact URLs, listing dates, retrieval times, HTTP headers, sizes, and SHA-256 checksums are in `source_manifest.json`.

## Releases and files

| Release | Reference period | Files | Listing date (as printed) |
|---|---|---|---|
| NHANES August 2021-August 2023 (primary) | August 2021 to August 2023 | DEMO_L, GHB_L, GLU_L, FASTQX_L, DIQ_L, RHQ_L | September 2024 |
| NHANES 2017-March 2020 pre-pandemic (replication) | January 2017 to March 2020 | P_DEMO, P_GHB, P_GLU, P_FASTQX, P_DIQ, P_RHQ | May 2021 (P_RHQ August 2021) |

Release year, reference period, listing date, and retrieval date (2026-10-07) are different things and are recorded separately in the manifest. Server Last-Modified headers can predate the listing date; they are recorded but not interpreted.

## How files were obtained

The acquire stage reads the official NCHS listing page for each component (for example `https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2021-2023`), stores it with a checksum, and follows the documentation and data links printed on it. It does not construct URLs. Each data file must start with the SAS transport header; an HTML page served in its place is rejected. Downloads use certificate verification and at most three attempts. Cached files are reused only when their SHA-256 matches the manifest.

The CDC server returns XPT files with the content type `text/plain`; validation relies on the file header, not on the content type.

## Newer releases

On 2026-10-07 the NHANES 2025-2027 data pages stated "These datasets are not yet released", and no newer complete release with glycohemoglobin, fasting glucose, and fasting questionnaire files was listed.

## Permitted use and citation

NHANES public-use data may be used under the NCHS data user agreement (https://www.cdc.gov/nchs/policy/data-user-agreement.html), which permits use for statistical reporting and analysis only and prohibits any attempt to identify participants. The suggested NCHS citation form is: Centers for Disease Control and Prevention (CDC). National Center for Health Statistics (NCHS). National Health and Nutrition Examination Survey Data. Hyattsville, MD: U.S. Department of Health and Human Services, Centers for Disease Control and Prevention, [year], [URL].

## Rebuilding a historical snapshot

NCHS can revise a file in place. The manifest checksums identify the exact bytes analyzed; if a later download differs, `make acquire` stops with a checksum error instead of silently replacing the cached file, and `python -m ddaudit acquire --refresh` reports which files changed.

## Published aggregates used for reconciliation

NCHS Data Brief 516 (Gwira, Fryar, Gu; November 2024; doi:10.15620/cdc/165794), Tables 1 and 2, copied into `config/reference_aggregates.yaml`. The CDC National Diabetes Statistics Report (updated 11 March 2026) is recorded for context only, because its age range and weighting differ.
