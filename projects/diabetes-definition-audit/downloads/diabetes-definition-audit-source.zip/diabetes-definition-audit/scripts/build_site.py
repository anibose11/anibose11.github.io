"""Build the static project page and the source archive.

Output: site/projects/diabetes-definition-audit/{index.html, report.html, assets/, downloads/}

The source archive is built from an allowlist: project code, SQL, R, configuration,
tests with the synthetic fixture, documentation, and small result files. It never
includes environments, NHANES data files, caches, logs, private notes, the
submission copy of the manuscript, or delivery folders.
"""

from __future__ import annotations

import hashlib
import re
import shutil
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ddaudit.values import collect, fill  # noqa: E402

SLUG = "diabetes-definition-audit"
SITE = ROOT / "site" / "projects" / SLUG
ARCHIVE_DIR = SLUG  # single top-level folder inside the source archive

ALLOW_FILES = [
    "README.md", "LICENSE", "THIRD_PARTY_NOTICES.md", "CITATION.cff", "Makefile", "requirements.in",
    "requirements.lock", "renv.lock", "DESCRIPTION", ".Rprofile", ".gitignore", "renv/activate.R",
    "renv/settings.json", "renv/.gitignore", "source_manifest.json", "manuscript/report.css",
    "results/run_manifest.json", "results/document_values.json", "evidence/claims.json",
]
ALLOW_GLOBS = [
    "src/ddaudit/*.py", "sql/*.sql", "R/*.R", "config/*.yaml", "scripts/*.py", "site_src/*",
    "tests/*.py", "tests/r/*.R", "tests/fixtures/make_fixture.py", "tests/fixtures/mini/2021-2023/*",
    "manuscript/*.md.tmpl", "docs/*.md", "docs/*.csv", "docs/*.sha256", "docs/research/*.md", "docs/research/*.json",
    "results/tables/*/*.csv", "results/tables/*/*.json", "results/validation/*.csv", "results/validation/*.json",
    "results/validation/*/*.csv", "results/validation/*/*.json", "results/provenance/*/*.sql",
    "results/figures/*.png", "results/exports/*",
]
FORBIDDEN_PARTS = {".venv", ".rboot", "data", ".demo", ".repro", ".local", "logs", "handoff", "deliverables", "site",
                   "__pycache__", "submission", "build", "library", "staging", ".git"}

DOWNLOADS = [
    # (published name, source path, label, description)
    ("diabetes-definition-audit-source.zip", None, "Source archive", "code, SQL, R, configuration, tests, fixture, documentation, and result tables"),
    ("manuscript.pdf", "manuscript/build/manuscript.pdf", "Download manuscript (PDF)", ""),
    ("manuscript.docx", "manuscript/build/manuscript.docx", "Download manuscript (Word)", ""),
    ("supplementary.html", "manuscript/build/supplementary.html", "Supplementary material (HTML)", "participant flow, validation, group tables and additional analyses"),
    ("supplementary.pdf", "manuscript/build/supplementary.pdf", "Supplementary material (PDF)", ""),
    ("strobe_checklist.pdf", "manuscript/build/strobe_checklist.pdf", "STROBE checklist (PDF)", "reporting checklist with manuscript locations"),
    ("diabetes-definition-audit-results.xlsx", "results/exports/diabetes-definition-audit-results.xlsx", "Results workbook", "aggregate tables with a definitions sheet, thresholds and units, domains and weights; no person-level data"),
    ("tableau_estimates.csv", "results/exports/tableau_estimates.csv", "Estimates", "every configuration in both releases with universe, weight, denominator, interval, and NCHS status"),
    ("tableau_contrasts.csv", "results/exports/tableau_contrasts.csv", "Contrasts", "paired, selection and weighting, and naive differences with design-based intervals"),
    ("tableau_missingness.csv", "results/exports/tableau_missingness.csv", "Laboratory status by group", "fasting subsample and HbA1c status by age, sex, and race and Hispanic origin"),
    ("tableau_paired_by_group.csv", "results/exports/tableau_paired_by_group.csv", "Paired estimates by group", "HbA1c and glucose estimates and their difference by group"),
    ("participant_flow_2021-2023.csv", "results/tables/2021-2023/participant_flow.csv", "Participant flow, 2021 to 2023", "count remaining and removed at each step, with the weight used"),
    ("participant_flow_2017-2020.csv", "results/tables/2017-2020/participant_flow.csv", "Participant flow, 2017 to March 2020", "participant counts at each step of the replication"),
    ("reference_reconciliation.csv", "results/tables/2021-2023/reference_reconciliation.csv", "NCHS reconciliation", "published and reproduced NCHS Data Brief 516 estimates"),
    ("validation_summary.csv", "results/validation/validation_summary.csv", "Automated checks", "software checks, source reconciliation, and external reconciliation"),
    ("phenotype_spec.md", "docs/phenotype_spec.md", "Phenotype specification", "version 1.0.0: measures, codes, thresholds, boundaries, domains, weights"),
    ("data_dictionary.csv", "docs/data_dictionary.csv", "Data dictionary", "source variable, SAS label, universe, analysis column, and rule"),
    ("analysis_plan.md", "docs/analysis_plan.md", "Analysis plan", "frozen before any estimate, with dated amendments"),
    ("contribution_decision.md", "docs/contribution_decision.md", "Contribution decision", "users, estimand, comparator, and what counts as a negative result"),
    ("prior_art.csv", "docs/prior_art.csv", "Prior work", "the five closest studies and what this project adds"),
    ("claims.json", "evidence/claims.json", "Claims ledger", "each headline number with its file, row, numerator, denominator, and source checksums"),
]

INDEX_FIGURES = ["fig1_paired_common_denominator.png", "fig2_sample_and_definition_parts.png", "fig3_overlap_of_definitions.png"]


# Venue-planning notes are not reproducibility material and stay out of the archive.
EXCLUDE_FILES = {"docs/research/journal_requirements.md", "docs/research/source_crosscheck.md", "docs/journal_fit.md", "scripts/build_bundle.py",
                 "scripts/verify_bundle.py"}
# The archived Makefile keeps the research targets and drops the delivery targets.
MAKEFILE_DROP = ("bundle", "verify-bundle")


def allowed_files() -> list[Path]:
    files = {ROOT / f for f in ALLOW_FILES if (ROOT / f).exists()}
    for g in ALLOW_GLOBS:
        files.update(p for p in ROOT.glob(g) if p.is_file())
    files = {p for p in files if p.relative_to(ROOT).as_posix() not in EXCLUDE_FILES}
    out = []
    for p in sorted(files):
        rel = p.relative_to(ROOT)
        if FORBIDDEN_PARTS & set(rel.parts[:-1]) and not str(rel).startswith("renv/"):
            continue
        if p.suffix in {".xpt", ".parquet", ".duckdb", ".pyc"}:
            continue
        out.append(p)
    return out


def archived_makefile(p: Path) -> bytes:
    out, skip = [], False
    for line in p.read_text().splitlines():
        if re.match(r"^#\s+make (bundle|verify-bundle)\b", line):
            continue
        if re.match(r"^(bundle|verify-bundle):", line):
            skip = True
            continue
        if skip and (line.startswith("\t") or not line.strip()):
            if not line.strip():
                skip = False
            continue
        skip = False
        if line.startswith(".PHONY:"):
            line = " ".join(w for w in line.split() if w not in MAKEFILE_DROP)
        out.append(line)
    return ("\n".join(out).rstrip() + "\n").encode()


def build_source_zip(dest: Path) -> dict:
    files = allowed_files()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            rel = p.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(f"{ARCHIVE_DIR}/{rel}", date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o644 & 0xFFFF) << 16
            data = archived_makefile(p) if rel == "Makefile" else p.read_bytes()
            z.writestr(info, data)
    return {"files": len(files), "bytes": dest.stat().st_size}


def png_size(p: Path) -> tuple[int, int]:
    with open(p, "rb") as fh:
        head = fh.read(24)
    return struct.unpack(">II", head[16:24])


def human(n: int) -> str:
    return f"{n / 1024 / 1024:.1f} MB" if n >= 1024 * 1024 else f"{max(1, round(n / 1024))} KB"


def main() -> None:
    if SITE.exists():
        shutil.rmtree(SITE)
    (SITE / "assets").mkdir(parents=True)
    (SITE / "downloads").mkdir()
    shutil.copy2(ROOT / "site_src" / "site.css", SITE / "assets" / "site.css")
    for f in INDEX_FIGURES:
        shutil.copy2(ROOT / "results" / "figures" / f, SITE / "assets" / f)
    shutil.copy2(ROOT / "manuscript" / "build" / "manuscript.html", SITE / "report.html")
    src = build_source_zip(SITE / "downloads" / "diabetes-definition-audit-source.zip")
    items = []
    for name, path, label, desc in DOWNLOADS:
        target = SITE / "downloads" / name
        if path:
            shutil.copy2(ROOT / path, target)
        ext = target.suffix.lstrip(".").upper()
        filetype = "" if label.endswith(("(PDF)", "(Word)", "(HTML)")) else f"{ext}, "
        description = f": {desc}" if desc else ""
        items.append(f'        <li><a href="downloads/{name}">{label}</a> <span class="meta">({filetype}{human(target.stat().st_size)}){description}</span></li>')
    values = collect()
    html = fill((ROOT / "site_src" / "index.html.tmpl").read_text(), {**values, "downloads_list": "\n".join(items)})
    (SITE / "index.html").write_text(html)
    for f in INDEX_FIGURES:
        w, h = png_size(SITE / "assets" / f)
        if f'src="assets/{f}" width="{w}" height="{h}"' not in html:
            raise SystemExit(f"figure size attributes for {f} do not match the PNG ({w}x{h})")
    total = sum(p.stat().st_size for p in SITE.rglob("*") if p.is_file())
    print({"site": str(SITE.relative_to(ROOT)), "files": sum(1 for p in SITE.rglob("*") if p.is_file()), "bytes": total,
           "source_archive": src,
           "source_sha256": hashlib.sha256((SITE / "downloads" / "diabetes-definition-audit-source.zip").read_bytes()).hexdigest()})


if __name__ == "__main__":
    main()
