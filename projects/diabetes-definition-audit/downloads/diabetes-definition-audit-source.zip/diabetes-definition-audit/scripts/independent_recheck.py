"""Independent recheck of the headline numbers, written without the ddaudit package.

Downloads the twelve NHANES component files again into a new directory, compares their
SHA-256 checksums with source_manifest.json, rebuilds the paired domain P and the HbA1c
laboratory domain H from the raw files with pandas, recomputes the primary estimates,
their linearized standard errors, the two contrasts and the NCHS Data Brief 516 rows,
reclassifies the 25 sampled participants when the private sample file is present, and
checks the documentation pages for the variable names and response codes the phenotype
specification relies on.

Usage: .venv/bin/python scripts/independent_recheck.py OUT_DIR
Writes OUT_DIR/independent_recheck.json and prints a summary. Nothing in the project is
modified. The project's own results are read only for comparison.
"""
from __future__ import annotations

import csv
import hashlib
import html
import json
import re
import ssl
import sys
import urllib.request
from pathlib import Path

import certifi
import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "2021-2023": ("https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/",
                  {"demo": "DEMO_L", "ghb": "GHB_L", "glu": "GLU_L", "fastqx": "FASTQX_L", "diq": "DIQ_L", "rhq": "RHQ_L"},
                  {"a1c": "WTPH2YR", "fast": "WTSAF2YR"}),
    "2017-2020": ("https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/",
                  {"demo": "P_DEMO", "ghb": "P_GHB", "glu": "P_GLU", "fastqx": "P_FASTQX", "diq": "P_DIQ", "rhq": "P_RHQ"},
                  {"a1c": "WTMECPRP", "fast": "WTSAFPRP"}),
}
CTX = ssl.create_default_context(cafile=certifi.where())


def get(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (independent recheck)"})
    with urllib.request.urlopen(req, context=CTX, timeout=120) as r:
        return r.read()


def read_xpt(path: Path) -> pd.DataFrame:
    df = pd.read_sas(path, format="xport")
    num = df.select_dtypes("number").columns
    df[num] = df[num].mask(df[num].abs() < 1e-30, 0.0)  # SAS transport stores 0 as a tiny float
    return df


def lin_scores(df: pd.DataFrame, y: np.ndarray, w: np.ndarray, dom: np.ndarray) -> tuple[float, np.ndarray]:
    """Ratio estimate and its linearization scores over all records in the design."""
    wd = np.where(dom, w, 0.0)
    p = float((wd * y).sum() / wd.sum())
    return p, wd * (y - p) / wd.sum()


def design_var(df: pd.DataFrame, z: np.ndarray) -> float:
    t = pd.DataFrame({"h": df["SDMVSTRA"].values, "c": df["SDMVPSU"].values, "z": z})
    psu = t.groupby(["h", "c"])["z"].sum().reset_index()
    v = 0.0
    for _, g in psu.groupby("h"):
        n = len(g)
        v += n / (n - 1) * ((g["z"] - g["z"].mean()) ** 2).sum()
    return v


def build(rel: str, raw: Path) -> pd.DataFrame:
    _, comp, wt = FILES[rel]
    t = {k: read_xpt(raw / f"{v}.xpt") for k, v in comp.items()}
    d = t["demo"][["SEQN", "RIDSTATR", "RIDAGEYR", "RIAGENDR", "RIDEXPRG", "SDMVSTRA", "SDMVPSU"] + (["WTMECPRP"] if rel == "2017-2020" else [])]
    g = t["ghb"][["SEQN", "LBXGH"] + (["WTPH2YR"] if rel == "2021-2023" else [])]
    u = t["glu"][["SEQN", "LBXGLU", wt["fast"]]]
    df = (d.merge(g, on="SEQN", how="left").merge(u, on="SEQN", how="left")
           .merge(t["diq"][["SEQN", "DIQ010"]], on="SEQN", how="left")
           .merge(t["rhq"][["SEQN", "RHD143"]], on="SEQN", how="left"))
    assert df["SEQN"].is_unique and len(df) == len(d)
    a1c = df["LBXGH"].round(1)
    glu = df["LBXGLU"].round(0)
    preg = (df["RIDEXPRG"] == 1) | ((df["RIDEXPRG"] == 3) & (df["RHD143"] == 1))
    df["A"] = (df["RIDSTATR"] == 2) & (df["RIDAGEYR"] >= 20) & ~preg & df["DIQ010"].isin([1, 2, 3])
    wa = df[wt["a1c"]].fillna(0)
    if rel == "2017-2020":
        wa = wa.where(df["LBXGH"].notna() | df["SEQN"].isin(t["ghb"]["SEQN"]), 0)
    df["w_a1c"] = wa
    df["w_fast"] = df[wt["fast"]].fillna(0)
    df["H"] = df["A"] & (df["w_a1c"] > 0) & a1c.notna()
    df["F"] = df["A"] & (df["w_fast"] > 0) & glu.notna()
    df["P"] = df["F"] & a1c.notna()
    df["A1C65"] = (a1c >= 6.5).astype(float)
    df["FPG126"] = (glu >= 126).astype(float)
    df["DX"] = (df["DIQ010"] == 1).astype(float)
    df["TOTAL"] = ((df["DX"] + df["A1C65"] + df["FPG126"]) > 0).astype(float)
    df["UNDX"] = df["TOTAL"] - df["DX"]
    return df


def main(out: Path) -> int:
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / "source_manifest.json").read_text())["entries"]
    report: dict = {"downloads": [], "estimates": {}, "db516": [], "sample": {}, "documentation": []}

    for rel, (base, comp, _) in FILES.items():
        raw = out / "raw" / rel
        raw.mkdir(parents=True, exist_ok=True)
        for f in comp.values():
            b = get(base + f + ".xpt")
            assert b[:80].startswith(b"HEADER RECORD*******LIBRARY HEADER RECORD"), f
            (raw / f"{f}.xpt").write_bytes(b)
            sha = hashlib.sha256(b).hexdigest()
            want = manifest[f"{rel}/data_xpt/{f}"]["sha256"]
            report["downloads"].append({"release": rel, "file": f, "bytes": len(b), "sha256": sha, "manifest_sha256": want, "match": sha == want})
            page = html.unescape(re.sub(r"<[^>]+>", " ", get(base + f + ".htm").decode("utf-8", "replace")))
            (raw / f"{f}.txt").write_text(page)

    ours = {rel: pd.read_csv(ROOT / "results/tables" / rel / "estimates.csv").set_index("config_id") for rel in FILES}
    contr = {rel: pd.read_csv(ROOT / "results/tables" / rel / "contrasts.csv").set_index("contrast_id") for rel in FILES}
    for rel in FILES:
        df = build(rel, out / "raw" / rel)
        P, H = df["P"].values, df["H"].values
        k1, z1 = lin_scores(df, df["A1C65"].values, df["w_fast"].values, P)
        k2, z2 = lin_scores(df, df["FPG126"].values, df["w_fast"].values, P)
        k3, z3 = lin_scores(df, df["A1C65"].values, df["w_a1c"].values, H)
        r = {
            "n_A": int(df["A"].sum()), "n_H": int(H.sum()), "n_F": int(df["F"].sum()), "n_P": int(P.sum()),
            "K1_npos": int(df.loc[P, "A1C65"].sum()), "K2_npos": int(df.loc[P, "FPG126"].sum()),
            "K1": k1, "K1_se": design_var(df, z1) ** 0.5, "K2": k2, "K2_se": design_var(df, z2) ** 0.5,
            "K3": k3, "K3_se": design_var(df, z3) ** 0.5,
            "C1": k1 - k2, "C1_se": design_var(df, z1 - z2) ** 0.5,
            "C2": k3 - k1, "C2_se": design_var(df, z3 - z1) ** 0.5,
        }
        cmp = {
            "n_P": (r["n_P"], int(ours[rel].loc["K1", "n_unweighted"])), "n_H": (r["n_H"], int(ours[rel].loc["K3", "n_unweighted"])),
            "K1_npos": (r["K1_npos"], int(ours[rel].loc["K1", "n_positive_unweighted"])),
            "K2_npos": (r["K2_npos"], int(ours[rel].loc["K2", "n_positive_unweighted"])),
            "K1": (r["K1"], ours[rel].loc["K1", "estimate"]), "K1_se": (r["K1_se"], ours[rel].loc["K1", "se"]),
            "K2": (r["K2"], ours[rel].loc["K2", "estimate"]), "K2_se": (r["K2_se"], ours[rel].loc["K2", "se"]),
            "K3": (r["K3"], ours[rel].loc["K3", "estimate"]), "K3_se": (r["K3_se"], ours[rel].loc["K3", "se"]),
            "C1": (r["C1"], contr[rel].loc["C1", "estimate"]), "C1_se": (r["C1_se"], contr[rel].loc["C1", "se"]),
            "C2": (r["C2"], contr[rel].loc["C2", "estimate"]), "C2_se": (r["C2_se"], contr[rel].loc["C2", "se"]),
        }
        report["estimates"][rel] = {k: {"recheck": float(a), "pipeline": float(b), "abs_diff": abs(float(a) - float(b))} for k, (a, b) in cmp.items()}

        if rel == "2021-2023":
            ref = yaml.safe_load((ROOT / "config/reference_aggregates.yaml").read_text())["nchs_db516"]["rows"]
            groups = {"all": np.ones(len(df), bool), "men": (df["RIAGENDR"] == 1).values, "women": (df["RIAGENDR"] == 2).values,
                      "20-39": df["RIDAGEYR"].between(20, 39).values, "40-59": df["RIDAGEYR"].between(40, 59).values,
                      "60+": (df["RIDAGEYR"] >= 60).values}
            meas = {"total": "TOTAL", "diagnosed": "DX", "undiagnosed": "UNDX"}
            for row in ref:
                dom = P & groups[row["group"]]
                p, z = lin_scores(df, df[meas[row["measure"]]].values, df["w_fast"].values, dom)
                se = design_var(df, z) ** 0.5
                report["db516"].append({**{k: row[k] for k in ("measure", "group", "sample_n", "percent", "se")},
                                        "recheck_n": int(dom.sum()), "recheck_percent": round(100 * p, 3), "recheck_se": round(100 * se, 3),
                                        "match": bool(int(dom.sum()) == row["sample_n"] and abs(round(100 * p, 1) - row["percent"]) < 1e-9
                                                      and abs(round(100 * se, 1) - row["se"]) < 1e-9)})

            sample_file = ROOT / "handoff/author_validation_sample.csv"
            sample = list(csv.DictReader(open(sample_file))) if sample_file.exists() else []
            byseqn = df.set_index("SEQN")
            mism = []
            for s in sample:
                q = byseqn.loc[float(s["SEQN"])]
                mine = {"pipeline_DX": int(q["DX"]), "pipeline_A1C65": int(q["A1C65"]), "pipeline_FPG126": int(q["FPG126"]), "pipeline_in_domain_P": int(q["P"])}
                raw_ok = abs(q["LBXGH"] - float(s["LBXGH"])) < 1e-9 and abs(q["LBXGLU"] - float(s["LBXGLU"])) < 1e-9 and abs(q["WTSAF2YR"] - float(s["WTSAF2YR"])) < 1e-6
                if any(mine[k] != int(s[k]) for k in mine) or not raw_ok:
                    mism.append(s["SEQN"])
            report["sample"] = {"run": bool(sample), "n": len(sample), "mismatches": mism}

    checks = {
        "DEMO_L": ["RIDSTATR", "RIDAGEYR", "RIDEXPRG", "SDMVSTRA", "SDMVPSU", "WTMEC2YR",
                   "Yes, positive lab pregnancy test or self-reported pregnant at exam", "The participant was not pregnant at exam",
                   "Cannot ascertain if the participant is pregnant at exam", "Females only 20 YEARS - 44 YEARS"],
        "GHB_L": ["LBXGH", "WTPH2YR", "Glycohemoglobin (%)"],
        "GLU_L": ["LBXGLU", "WTSAF2YR", "Fasting Glucose (mg/dL)"],
        "DIQ_L": ["DIQ010", "Doctor told you have diabetes", "Borderline"],
        "RHQ_L": ["RHD143", "Are you pregnant now?"],
        "FASTQX_L": ["PHAFSTHR", "PHAFSTMN", "PHQ020", "PHQ030", "PHQ040", "PHQ050", "PHQ060"],
    }
    for f, terms in checks.items():
        text = re.sub(r"\s+", " ", (out / "raw/2021-2023" / f"{f}.txt").read_text())
        report["documentation"].append({"file": f, "missing_terms": [t for t in terms if t not in text]})

    (out / "independent_recheck.json").write_text(json.dumps(report, indent=2))
    ok_dl = all(d["match"] for d in report["downloads"])
    worst = max(v["abs_diff"] for rel in report["estimates"].values() for v in rel.values())
    ok_516 = sum(r["match"] for r in report["db516"])
    print(json.dumps({"downloads_match": f"{sum(d['match'] for d in report['downloads'])}/{len(report['downloads'])}",
                      "max_abs_diff_vs_pipeline": worst, "db516_rows_matching": f"{ok_516}/{len(report['db516'])}",
                      "sample_check": (f"{report['sample']['n']} participants, mismatches {report['sample']['mismatches']}"
                                       if report["sample"]["run"] else "participant sample check not run (sample file not included)"),
                      "documentation_missing": {d["file"]: d["missing_terms"] for d in report["documentation"] if d["missing_terms"]}}, indent=2))
    ok_doc = not any(d["missing_terms"] for d in report["documentation"])
    return 0 if ok_dl and worst < 1e-9 and ok_516 == len(report["db516"]) and ok_doc and not report["sample"]["mismatches"] else 1


if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1])))
