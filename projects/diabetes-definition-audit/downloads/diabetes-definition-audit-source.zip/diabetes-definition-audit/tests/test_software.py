"""Software tests. Fixture-based tests use invented data (tests/fixtures/mini).

Tests marked `realdata` read the saved full-run outputs and are skipped when
those outputs are absent (for example in a fresh source archive before
`make acquire` and `make pipeline`).
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ddaudit import acquire, checker, codebook, direct, values  # noqa: E402

REAL = ROOT / "results" / "tables" / "2021-2023" / "estimates.csv"
realdata = pytest.mark.skipif(not REAL.exists(), reason="full-run outputs not present")


# ---------------------------------------------------------------- acquisition
def test_listing_parser_reads_both_layouts():
    base = "https://wwwn.cdc.gov/nchs/nhanes/search/datapage.aspx?Component=Laboratory&Cycle=2021-2023"
    four = ('<table><thead><tr><th>Data File Name</th><th>Doc File</th><th>Data File</th><th>Date Published</th></tr></thead>'
            '<tbody><tr><td class="text-left">Glycohemoglobin</td><td><a href="/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.htm">GHB_L Doc</a></td>'
            '<td><a href="/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.xpt">GHB_L Data [XPT - 169.9 KB]</a></td><td>September 2024</td></tr></tbody></table>')
    five = ('<table><thead><tr><th>Years</th><th>Data File Name</th><th>Doc File</th><th>Data File</th><th>Date Published</th></tr></thead>'
            '<tbody><tr><td>2017-2020</td><td>Demographic Variables</td><td><a href="/x/P_DEMO.htm">P_DEMO Doc</a></td>'
            '<td><a href="/x/P_DEMO.xpt">P_DEMO Data [XPT - 3.4 MB]</a></td><td>May 2021</td></tr></tbody></table>')
    r4 = acquire.parse_listing(four, base)["GHB_L"]
    assert r4.data_url == "https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2021/DataFiles/GHB_L.xpt"
    assert r4.date_published == "September 2024" and r4.listed_size == "169.9 KB"
    r5 = acquire.parse_listing(five, base)["P_DEMO"]
    assert r5.description == "Demographic Variables" and r5.date_published == "May 2021"


def test_xpt_guard_rejects_html_error_page(tmp_path):
    p = tmp_path / "GHB_L.xpt"
    p.write_bytes(b"<!DOCTYPE html><html><body>Error</body></html>" + b" " * 4000)
    with pytest.raises(acquire.AcquireError):
        acquire.check_xpt(p)
    ok = tmp_path / "ok.xpt"
    ok.write_bytes(acquire.XPT_MAGIC + b"*" * 4000)
    acquire.check_xpt(ok)


def test_codebook_parser(tmp_path):
    html = ('<h3 class="vartitle" id="DIQ010">DIQ010 - Doctor told you have diabetes</h3><dl><dt>SAS Label: </dt>'
            '<dd>Doctor told you have diabetes</dd><dt>Target: </dt><dd> Both males and females 1 YEARS - 150 YEARS</dd></dl>'
            '<table class="values"><tbody><tr><td>1</td><td>Yes</td><td>1081</td><td>1081</td><td></td></tr>'
            '<tr><td>3.2 to 17.1</td><td>Range of Values</td><td>6715</td><td>6715</td><td></td></tr></tbody></table>')
    p = tmp_path / "doc.htm"
    p.write_text(html)
    cb = codebook.parse_doc(p)
    assert cb["DIQ010"]["sas_label"] == "Doctor told you have diabetes"
    assert cb["DIQ010"]["values"][0] == {"code": "1", "description": "Yes", "count": 1081, "skip_to": ""}
    assert codebook.parse_range("3.2 to 17.1") == (3.2, 17.1)


# ------------------------------------------------------------------- checker
@pytest.mark.parametrize("req, ok", [
    (dict(phenotype="A1C65", domain="P", weight="WTSAF2YR"), True),
    (dict(phenotype="A1C65", domain="H", weight="WTPH2YR"), True),
    (dict(phenotype="FPG126", domain="F", weight="WTSAF2YR"), True),
    (dict(phenotype="FPG126", domain="H", weight="WTPH2YR"), False),
    (dict(phenotype="A1C65", domain="H", weight="WTMEC2YR"), False),
    (dict(phenotype="TOTAL_A1C_FPG", domain="H", weight="WTPH2YR"), False),
    (dict(phenotype="A1C65", domain="P", weight="WTSAF2YR", imputed_glucose=True), False),
    (dict(phenotype="A1C65", domain="P", weight="WTSAF2YR", min_age=18), False),
    (dict(phenotype="A1C65", domain="H", weight="WTMECPRP", release="2017-2020"), True),
    (dict(phenotype="A1C65", domain="H", weight="WTPH2YR", release="2017-2020"), False),
    (dict(phenotype="A1C65", domain="P", weight="NOTAWEIGHT"), False),
])
def test_checker_decisions(req, ok):
    assert checker.check_config(**req).ok is ok


def test_checker_contrast_rules():
    k1 = checker.check_config("A1C65", "P", weight="WTSAF2YR").resolved
    k2 = checker.check_config("FPG126", "P", weight="WTSAF2YR").resolved
    k3 = checker.check_config("A1C65", "H", weight="WTPH2YR").resolved
    assert checker.check_contrast(k1, k2, "paired_definition").ok
    assert not checker.check_contrast(k3, k2, "paired_definition").ok
    assert checker.check_contrast(k3, k1, "selection_weighting").ok
    assert not checker.check_contrast(k1, k2, "selection_weighting").ok


def test_cli_refuses_with_nonzero_exit():
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    r = subprocess.run([sys.executable, "-m", "ddaudit", "check-config", "--phenotype", "FPG126", "--domain", "H",
                        "--weight", "WTPH2YR"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 2 and "REFUSED" in r.stdout
    r = subprocess.run([sys.executable, "-m", "ddaudit", "check-config", "--phenotype", "A1C65", "--domain", "P",
                        "--weight", "WTSAF2YR"], cwd=ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 0 and "ACCEPTED" in r.stdout


# -------------------------------------------------- variance implementation
def test_linearized_variance_matches_hand_formula():
    # Two strata with two PSUs each; a ratio estimator in a domain.
    df = pd.DataFrame({
        "sdmvstra": [1, 1, 1, 1, 2, 2, 2, 2], "sdmvpsu": [1, 1, 2, 2, 1, 1, 2, 2],
        "w": [10.0, 20.0, 15.0, 5.0, 8.0, 12.0, 30.0, 10.0], "d": [1, 1, 1, 0, 1, 1, 1, 1], "y": [1, 0, 1, 1, 0, 0, 1, 1]})
    p, z = direct.ratio_scores(df, "y", "d", "w")
    w = df.w * df.d
    assert p == pytest.approx((w * df.y).sum() / w.sum())
    t = pd.DataFrame({"h": df.sdmvstra, "j": df.sdmvpsu, "z": z}).groupby(["h", "j"]).z.sum()
    hand = sum(2 / 1 * ((t[h] - t[h].mean()) ** 2).sum() for h in (1, 2))
    assert direct.linearized_var(df, z) == pytest.approx(hand)


# ------------------------------------------------------------ documents
def test_fill_refuses_unknown_placeholders():
    assert values.fill("a {{x}} b", {"x": "1"}) == "a 1 b"
    with pytest.raises(KeyError):
        values.fill("{{missing_value}}", {})


def test_signed_formatting_uses_minus_sign_and_no_negative_zero():
    assert values.signed(-0.0041) == "−0.41"
    assert values.signed(0.00001) == "0.00"
    assert values.ci_pct(0.091, 0.127) == "9.1 to 12.7"


# ------------------------------------------------------------- fixture run
def test_fixture_demo_runs_and_classifies_boundaries():
    env = {**os.environ, "PYTHONPATH": str(ROOT / "src")}
    r = subprocess.run([sys.executable, "-m", "ddaudit", "demo"], cwd=ROOT, env=env, capture_output=True, text=True,
                       timeout=600)
    assert r.returncode == 0, r.stdout[-3000:] + r.stderr[-3000:]
    assert "mismatches: 0" in r.stdout


def test_fixture_and_real_files_cannot_mix(tmp_path, monkeypatch):
    from ddaudit import build, paths
    rel = tmp_path / "data" / "raw" / "2021-2023"
    rel.mkdir(parents=True)
    for f in (ROOT / "tests" / "fixtures" / "mini" / "2021-2023").glob("*.fixture.csv"):
        (rel / f.name).write_text(f.read_text())
    (rel / "GHB_L.xpt").write_bytes(acquire.XPT_MAGIC)
    monkeypatch.setattr(paths, "DATA_RAW", tmp_path / "data" / "raw")
    # Make the stub XPT readable so that the mixing guard itself is what fails.
    monkeypatch.setattr(build.pd, "read_sas", lambda *a, **k: pd.DataFrame({"SEQN": [1.0]}))
    cfg = {"build": {"tables": {"demo": "DEMO_L", "ghb": "GHB_L"}}}
    with pytest.raises(RuntimeError, match="mixes real files and fixture files"):
        build.read_release("2021-2023", cfg)


def test_compare_detects_value_missing_on_one_side(tmp_path):
    from ddaudit import repro
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir()
    b.mkdir()
    pd.DataFrame({"x": [0.1, 0.2]}).to_csv(a / "t.csv", index=False)
    pd.DataFrame({"x": [0.1, None]}).to_csv(b / "t.csv", index=False)
    assert not repro.compare(str(a), str(b))["identical_within_tolerance"]


# --------------------------------------------------------- real-data outputs
@realdata
def test_real_domains_and_reconciliation():
    flow = pd.read_csv(ROOT / "results" / "tables" / "2021-2023" / "participant_flow.csv").set_index("step")
    assert int(flow.loc[13, "n"]) == 2938  # equals the NCHS Data Brief 516 sample size
    rec = pd.read_csv(ROOT / "results" / "tables" / "2021-2023" / "reference_reconciliation.csv")
    assert rec.n_match.all() and rec.percent_match.all() and rec.se_match.all()


@realdata
def test_real_decomposition_is_additive():
    d = pd.read_csv(ROOT / "results" / "tables" / "2021-2023" / "decomposition.csv")
    assert np.allclose(d.additivity_error, 0, atol=1e-12)


@realdata
def test_every_table_names_universe_weight_and_denominator():
    t = ROOT / "results" / "tables" / "2021-2023"
    for name in ("estimates.csv", "agreement.csv", "overlap.csv", "missingness_by_group.csv",
                 "paired_by_group.csv", "s3_diagnosed_below_threshold.csv", "reference_reconciliation.csv"):
        cols = set(pd.read_csv(t / name).columns)
        assert "sample_universe" in cols and "weight" in cols, name
        assert cols & {"n_unweighted", "our_n"}, name


@realdata
def test_claims_point_to_existing_evidence():
    ledger = json.loads((ROOT / "evidence" / "claims.json").read_text())
    for c in ledger["claims"]:
        assert (ROOT / c["evidence"]["path"]).exists(), c["id"]
