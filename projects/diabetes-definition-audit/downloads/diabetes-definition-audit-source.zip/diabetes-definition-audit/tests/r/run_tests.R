# R tests for the interval and presentation rules (R/functions.R).
# Run from the project root: Rscript tests/r/run_tests.R
suppressPackageStartupMessages(library(testthat))
source("R/functions.R")

test_that("Korn-Graubard interval brackets the estimate and stays in [0, 1]", {
  ci <- kg_interval(0.108, 0.0082, 2938, 15)
  expect_true(ci$lo < 0.108 && ci$hi > 0.108)
  expect_true(ci$lo >= 0 && ci$hi <= 1)
})

test_that("zero events use the sample size and give a lower bound of 0", {
  ci <- kg_interval(0, 0, 50, 15)
  expect_equal(ci$lo, 0)
  expect_equal(ci$neff, 50)
  expect_true(ci$hi > 0 && ci$hi < 0.2)
})

test_that("effective sample size is capped at the sample size", {
  capped <- kg_interval(0.121, 0.0104, 861, 15)
  uncapped <- kg_interval(0.121, 0.0104, 861, 15, cap = FALSE)
  expect_equal(capped$neff, 861)
  expect_true(uncapped$neff > 861)
  expect_true((capped$hi - capped$lo) > (uncapped$hi - uncapped$lo))
})

test_that("fewer degrees of freedom widen the interval", {
  a <- kg_interval(0.2, 0.02, 1000, 15)
  b <- kg_interval(0.2, 0.02, 1000, 5)
  expect_true((b$hi - b$lo) > (a$hi - a$lo))
})

test_that("NCHS presentation rules", {
  expect_equal(nchs_rule(0.1, 25, 3, 25, 0.02, 0.26, 15)$status, "suppressed")   # n < 30
  expect_equal(nchs_rule(0.5, 100, 50, 80, 0.33, 0.67, 15)$status, "suppressed") # width >= 0.30
  expect_equal(nchs_rule(0.05, 100, 5, 60, 0.01, 0.12, 15)$status, "suppressed") # relative width > 130%
  expect_equal(nchs_rule(0.108, 2938, 371, 1436, 0.091, 0.127, 15)$status, "presented")
  expect_equal(nchs_rule(0.108, 2938, 371, 1436, 0.091, 0.127, 6)$status, "flagged") # df < 8
  expect_equal(nchs_rule(0, 400, 0, 400, 0, 0.009, 15)$status, "flagged")            # zero events
})

cat("R tests completed\n")
