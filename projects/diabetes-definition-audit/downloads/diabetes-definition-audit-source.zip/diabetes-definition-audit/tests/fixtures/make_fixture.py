"""Write the miniature synthetic fixture used by the tests and `make demo`.

SYNTHETIC FIXTURE: every value is invented to exercise boundaries and failure
cases (thresholds, zero weights, pregnancy rules, fasting rules). It is not
NHANES data and no result from it is a study result.

Run: python tests/fixtures/make_fixture.py   (rewrites tests/fixtures/mini/2021-2023/)
"""

from __future__ import annotations

import csv
import random
from pathlib import Path

OUT = Path(__file__).resolve().parent / "mini" / "2021-2023"
HEADER = "# SYNTHETIC FIXTURE: invented values for software tests; not NHANES data\n"

# Named boundary cases: SEQN -> overrides. Everyone else is a filler adult.
CASES = {
    101: dict(note="HbA1c 6.4 and FPG 125: both below threshold", LBXGH=6.4, LBXGLU=125),
    102: dict(note="HbA1c 6.5 and FPG 126: both at threshold (inclusive)", LBXGH=6.5, LBXGLU=126),
    103: dict(note="HbA1c 6.5 only", LBXGH=6.5, LBXGLU=125),
    104: dict(note="FPG 126 only", LBXGH=6.4, LBXGLU=126),
    105: dict(note="pregnant at exam: excluded", RIAGENDR=2, RIDAGEYR=30, RIDEXPRG=1),
    106: dict(note="pregnancy not ascertained at exam, pregnant at interview: excluded", RIAGENDR=2, RIDAGEYR=31, RIDEXPRG=3, RHD143=1),
    107: dict(note="pregnancy not ascertained, not reported at interview: retained", RIAGENDR=2, RIDAGEYR=32, RIDEXPRG=3, RHD143=2),
    108: dict(note="DIQ010 don't know: excluded from domain A", DIQ010=9),
    109: dict(note="DIQ010 borderline: not diagnosed", DIQ010=3),
    110: dict(note="fasted 6 h: zero fasting weight, glucose present, not used", WTSAF2YR=0.0, PHAFSTHR=6, LBXGLU=140),
    111: dict(note="fasting subsample, no blood", WTSAF2YR=0.0, LBXGLU=None, LBXGH=None, WTPH2YR=0.0),
    112: dict(note="not assigned to fasting subsample", in_glu=False),
    113: dict(note="no blood: zero phlebotomy weight", WTPH2YR=0.0, LBXGH=None, in_glu=False),
    114: dict(note="phlebotomy weight but no HbA1c result", LBXGH=None),
    115: dict(note="age 19: not in adult domain", RIDAGEYR=19),
    116: dict(note="interviewed only", RIDSTATR=1),
    117: dict(note="supplement 2 h before draw: fails narrow fasting rule", PHQ060=1, PHASUPHR=2, PHASUPMN=0),
    118: dict(note="diagnosed and treated, both biomarkers below threshold", DIQ010=1, DIQ070=1, LBXGH=5.6, LBXGLU=98),
    119: dict(note="gum answered yes with no time recorded: narrow status unknown, excluded from P-narrow", PHQ040=1, PHAGUMHR=None),
    120: dict(note="diagnosed, insulin no, pills don't know: treatment unknown", DIQ010=1, DIQ050=2, DIQ070=9),
    121: dict(note="diagnosed, insulin no, pills no: not treated", DIQ010=1, DIQ050=2, DIQ070=2),
}


def main() -> None:
    rng = random.Random(20261007)
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    seqns = list(range(1, 41)) + sorted(CASES)
    for i, seqn in enumerate(seqns):
        stratum = 1 + (i % 2)
        psu = 1 + ((i // 2) % 2)
        r = dict(SEQN=seqn, RIDSTATR=2, RIDAGEYR=rng.randint(20, 79), RIAGENDR=rng.choice([1, 2]),
                 RIDRETH3=rng.choice([1, 2, 3, 4, 6, 7]), RIDEXPRG=None, SDMVPSU=psu, SDMVSTRA=stratum,
                 WTINT2YR=round(rng.uniform(5000, 50000), 3), WTMEC2YR=None, WTPH2YR=None, LBXGH=None,
                 WTSAF2YR=None, LBXGLU=None, PHAFSTHR=10, PHAFSTMN=0, DIQ010=rng.choice([1, 2, 2, 2, 2, 3]),
                 DIQ050=None, DIQ070=None, RHD143=None, in_glu=True,
                 PHQ020=2, PHQ030=2, PHQ040=2, PHQ050=2, PHQ060=2, PHASUPHR=None, PHASUPMN=None,
                 PHAGUMHR=None, PHAGUMMN=None)
        r["WTMEC2YR"] = round(r["WTINT2YR"] * 1.1, 3)
        r["WTPH2YR"] = round(r["WTMEC2YR"] * 1.05, 3)
        r["WTSAF2YR"] = round(r["WTMEC2YR"] * 2.0, 3)
        r["LBXGH"] = round(rng.choice([5.2, 5.5, 5.8, 6.1, 6.6, 7.2, 8.0]), 1)
        r["LBXGLU"] = rng.choice([88, 95, 104, 118, 131, 150, 190])
        r.update({k: v for k, v in CASES.get(seqn, {}).items() if k != "note"})
        if r["RIAGENDR"] == 2 and 20 <= r["RIDAGEYR"] <= 44 and r["RIDEXPRG"] is None:
            r["RIDEXPRG"] = 2
        if r["DIQ010"] == 1 and r["DIQ050"] is None:
            r["DIQ050"] = 2
            r["DIQ070"] = r["DIQ070"] or 2
        if r["DIQ010"] == 1 and r["DIQ070"] is None:
            r["DIQ070"] = 2
        if r["RIDSTATR"] == 1:
            r.update(WTMEC2YR=0.0, WTPH2YR=None, LBXGH=None, WTSAF2YR=None, LBXGLU=None, in_glu=False)
        rows.append(r)

    def write(name, cols, keep=lambda r: True):
        with open(OUT / f"{name}.fixture.csv", "w", newline="") as fh:
            fh.write(HEADER)
            w = csv.writer(fh)
            w.writerow(cols)
            for r in rows:
                if keep(r):
                    w.writerow(["" if r.get(c) is None else r.get(c) for c in cols])

    examined = lambda r: r["RIDSTATR"] == 2  # noqa: E731
    write("DEMO_L", ["SEQN", "RIDSTATR", "RIDAGEYR", "RIAGENDR", "RIDRETH3", "RIDEXPRG", "SDMVPSU", "SDMVSTRA", "WTINT2YR", "WTMEC2YR"])
    write("GHB_L", ["SEQN", "WTPH2YR", "LBXGH"], examined)
    write("GLU_L", ["SEQN", "WTSAF2YR", "LBXGLU"], lambda r: examined(r) and r["in_glu"])
    write("FASTQX_L", ["SEQN", "PHQ020", "PHACOFHR", "PHACOFMN", "PHQ030", "PHAALCHR", "PHAALCMN", "PHQ040", "PHAGUMHR",
                       "PHAGUMMN", "PHQ050", "PHAANTHR", "PHAANTMN", "PHQ060", "PHASUPHR", "PHASUPMN", "PHAFSTHR", "PHAFSTMN"], examined)
    write("DIQ_L", ["SEQN", "DIQ010", "DIQ050", "DIQ070"])
    write("RHQ_L", ["SEQN", "RHD143"], lambda r: r["RIAGENDR"] == 2)
    with open(OUT / "CASES.md", "w") as fh:
        fh.write("# Synthetic fixture cases (not NHANES data)\n\n")
        for k, v in CASES.items():
            fh.write(f"- SEQN {k}: {v['note']}\n")


if __name__ == "__main__":
    main()
