-- Status variables, analysis domains, and phenotype indicators.
-- Thresholds come from config/phenotypes.yaml (${a1c_threshold} %, ${fpg_threshold} mg/dL).
-- Status columns keep "absent from file", "zero weight", "measured",
-- "not applicable", and "unknown" apart instead of collapsing them to 0.
CREATE OR REPLACE TABLE analytic AS
WITH s AS (
    SELECT
        *,
        CASE
            WHEN ridexprg = 1 THEN 'pregnant_at_exam'
            WHEN ridexprg = 3 AND rhd143 = 1 THEN 'pregnant_reported_at_interview'
            WHEN ridexprg = 3 THEN 'not_ascertained'
            WHEN ridexprg = 2 THEN 'not_pregnant_at_exam'
            ELSE 'item_not_applicable'
        END AS preg_status,
        CASE
            WHEN diq010 = 1 THEN 'yes'
            WHEN diq010 = 2 THEN 'no'
            WHEN diq010 = 3 THEN 'borderline'
            WHEN diq010 = 7 THEN 'refused'
            WHEN diq010 = 9 THEN 'dont_know'
            WHEN in_diq_file THEN 'missing'
            ELSE 'absent_from_file'
        END AS dx_status,
        CASE
            WHEN NOT in_ghb_file THEN 'absent_from_file'
            WHEN w_a1c > 0 AND lbxgh IS NOT NULL THEN 'measured'
            WHEN w_a1c > 0 THEN 'weight_but_no_result'
            WHEN lbxgh IS NOT NULL THEN 'result_but_zero_weight'
            ELSE 'no_blood_zero_weight'
        END AS a1c_status,
        CASE
            WHEN NOT in_glu_file THEN 'not_in_fasting_subsample'
            WHEN w_fast > 0 AND lbxglu IS NOT NULL THEN 'valid'
            WHEN w_fast > 0 THEN 'weight_but_no_result'
            WHEN lbxglu IS NOT NULL THEN 'fasting_criterion_not_met'
            ELSE 'subsample_no_blood'
        END AS fast_status,
        -- Narrow fasting items: TRUE = acceptable, FALSE = intake within the
        -- window, NULL = unknown (missing answer or missing time).
        CASE WHEN phq020 = 2 THEN TRUE WHEN phq020 = 1 AND t_coffee IS NOT NULL THEN t_coffee >= ${narrow_min_hours} END AS ok_coffee,
        CASE WHEN phq030 = 2 THEN TRUE WHEN phq030 = 1 AND t_alcohol IS NOT NULL THEN t_alcohol >= ${narrow_min_hours} END AS ok_alcohol,
        CASE WHEN phq040 = 2 THEN TRUE WHEN phq040 = 1 AND t_gum IS NOT NULL THEN t_gum >= ${narrow_min_hours} END AS ok_gum,
        CASE WHEN phq050 = 2 THEN TRUE WHEN phq050 = 1 AND t_antacid IS NOT NULL THEN t_antacid >= ${narrow_min_hours} END AS ok_antacid,
        CASE WHEN phq060 = 2 THEN TRUE WHEN phq060 = 1 AND t_supplement IS NOT NULL THEN t_supplement >= ${narrow_min_hours} END AS ok_supplement
    FROM frame
),
d AS (
    SELECT
        *,
        CASE
            WHEN ok_coffee AND ok_alcohol AND ok_gum AND ok_antacid AND ok_supplement THEN 'meets_narrow_rule'
            WHEN NOT coalesce(ok_coffee, TRUE) OR NOT coalesce(ok_alcohol, TRUE) OR NOT coalesce(ok_gum, TRUE)
                 OR NOT coalesce(ok_antacid, TRUE) OR NOT coalesce(ok_supplement, TRUE) THEN 'intake_within_window'
            ELSE 'unknown'
        END AS narrow_status,
        (ridstatr = 2 AND age >= 20
         AND preg_status NOT IN ('pregnant_at_exam', 'pregnant_reported_at_interview')
         AND diq010 IN (1, 2, 3)) AS in_a
    FROM s
),
e AS (
    SELECT
        *,
        (in_a AND a1c_status = 'measured') AS in_h,
        (in_a AND fast_status = 'valid') AS in_f,
        (in_a AND fast_status = 'valid' AND a1c_status = 'measured') AS in_p,
        (in_a AND fast_status = 'valid' AND a1c_status = 'measured' AND narrow_status = 'meets_narrow_rule') AS in_p_narrow,
        CASE WHEN diq010 = 1 THEN 1 WHEN diq010 IN (2, 3) THEN 0 END AS dx,
        CASE WHEN a1c_status <> 'measured' THEN NULL WHEN lbxgh >= ${a1c_threshold} THEN 1 ELSE 0 END AS a1c65,
        CASE WHEN fast_status <> 'valid' THEN NULL WHEN lbxglu >= ${fpg_threshold} THEN 1 ELSE 0 END AS fpg126
    FROM d
)
SELECT
    *,
    CASE WHEN a1c65 IS NULL OR fpg126 IS NULL THEN NULL ELSE greatest(a1c65, fpg126) END AS bio_either,
    CASE WHEN dx IS NULL OR a1c65 IS NULL OR fpg126 IS NULL THEN NULL ELSE greatest(dx, a1c65, fpg126) END AS total_a1c_fpg,
    CASE WHEN dx IS NULL OR a1c65 IS NULL THEN NULL ELSE greatest(dx, a1c65) END AS total_a1c,
    CASE
        WHEN dx IS DISTINCT FROM 1 THEN NULL
        WHEN diq050 = 1 OR diq070 = 1 THEN 1
        WHEN diq050 = 2 AND diq070 = 2 THEN 0
    END AS dx_treated,
    CASE WHEN age BETWEEN 20 AND 44 THEN '20-44' WHEN age BETWEEN 45 AND 64 THEN '45-64' WHEN age >= 65 THEN '65+' END AS age_group,
    CASE sex WHEN 1 THEN 'Male' WHEN 2 THEN 'Female' END AS sex_label,
    CASE reth3
        WHEN 1 THEN 'Mexican American'
        WHEN 2 THEN 'Other Hispanic'
        WHEN 3 THEN 'Non-Hispanic White'
        WHEN 4 THEN 'Non-Hispanic Black'
        WHEN 6 THEN 'Non-Hispanic Asian'
        WHEN 7 THEN 'Other or multiracial'
    END AS reth_label
FROM e
ORDER BY seqn;
