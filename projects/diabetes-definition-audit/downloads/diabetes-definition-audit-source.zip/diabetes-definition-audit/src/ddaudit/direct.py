"""Direct weighted cross-tabulations and a second implementation of the
linearized variance, used to check the R survey results.

This is a software cross-check written independently of R/estimate.R. It is
not external or expert scientific validation.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

WEIGHT_COL = {"fasting": "w_fast", "a1c_lab": "w_a1c", "exam": "w_exam"}
DOMAIN_COL = {"A": "in_a", "H": "in_h", "F": "in_f", "P": "in_p", "P_NARROW": "in_p_narrow"}
PHENO_COL = {"DX": "dx", "A1C65": "a1c65", "FPG126": "fpg126", "BIO_EITHER": "bio_either",
             "TOTAL_A1C_FPG": "total_a1c_fpg", "TOTAL_A1C": "total_a1c"}


def ratio_scores(df: pd.DataFrame, pc: str, dcol: str, wcol: str) -> tuple[float, np.ndarray]:
    d = df[dcol].astype(bool).to_numpy()
    w = df[wcol].to_numpy(float) * d
    y = np.where(d, df[pc].fillna(0).to_numpy(float), 0.0)
    W = w.sum()
    p = (w * y).sum() / W
    z = w * (y - p) / W
    return p, z


def linearized_var(df: pd.DataFrame, z: np.ndarray) -> float:
    """With-replacement variance of a total of scores z: PSU totals within strata.

    n_h is the number of PSUs in the stratum in the full design, so PSUs with no
    domain members contribute a zero total, as in survey::svyrecvar.
    """
    t = pd.DataFrame({"h": df["sdmvstra"].to_numpy(), "j": df["sdmvpsu"].to_numpy(), "z": z})
    psu = t.groupby(["h", "j"], sort=True)["z"].sum().reset_index()
    var = 0.0
    for _, g in psu.groupby("h"):
        n_h = len(g)
        if n_h < 2:
            raise ValueError("singleton stratum")
        dev = g["z"].to_numpy() - g["z"].mean()
        var += n_h / (n_h - 1) * (dev ** 2).sum()
    return float(var)


def direct_estimate(df: pd.DataFrame, phenotype: str, domain: str, role: str) -> dict:
    d = df[DOMAIN_COL[domain]].astype(bool)
    w = df.loc[d, WEIGHT_COL[role]].to_numpy(float)
    y = df.loc[d, PHENO_COL[phenotype]].to_numpy(float)
    p, z = ratio_scores(df, PHENO_COL[phenotype], DOMAIN_COL[domain], WEIGHT_COL[role])
    return {
        "weighted_numerator": float((w * y).sum()),
        "weighted_denominator": float(w.sum()),
        "estimate_direct": float((w * y).sum() / w.sum()),
        "se_python_linearized": linearized_var(df, z) ** 0.5,
        "n_unweighted": int(d.sum()),
        "n_positive_unweighted": int((y == 1).sum()),
    }


def direct_contrast(df: pd.DataFrame, left: tuple, right: tuple) -> dict:
    pL, zL = ratio_scores(df, PHENO_COL[left[0]], DOMAIN_COL[left[1]], WEIGHT_COL[left[2]])
    pR, zR = ratio_scores(df, PHENO_COL[right[0]], DOMAIN_COL[right[1]], WEIGHT_COL[right[2]])
    return {"estimate_direct": pL - pR, "se_python_linearized": linearized_var(df, zL - zR) ** 0.5}


def weighted_crosstab(df: pd.DataFrame, domain: str, role: str, row: str, col: str) -> pd.DataFrame:
    d = df[df[DOMAIN_COL[domain]].astype(bool)]
    w = d[WEIGHT_COL[role]]
    tab = d.assign(_w=w).pivot_table(index=row, columns=col, values="_w", aggfunc="sum", fill_value=0.0)
    return tab / tab.to_numpy().sum()


# ------------------------------------------------- cross-checks of every table
def _prop(df: pd.DataFrame, y: np.ndarray, d: np.ndarray, w: np.ndarray) -> tuple[float, float, np.ndarray]:
    d = d.astype(bool)
    ww = np.where(d, w, 0.0)
    yy = np.where(d, y, 0.0)
    W = ww.sum()
    p = (ww * yy).sum() / W
    z = ww * (yy - p) / W
    return float(p), linearized_var(df, z) ** 0.5, z


def table_checks(df: pd.DataFrame, tables_dir) -> pd.DataFrame:
    """Recompute the point estimates and standard errors of every proportion and
    difference in the agreement, overlap, sensitivity 3, missingness, group, post hoc,
    and NCHS reconciliation tables, and the point estimates of kappa and the agreement
    ratios. Returns one row per compared quantity."""
    rows = []
    w_fast, w_exam = df["w_fast"].to_numpy(float), df["w_exam"].to_numpy(float)
    P = df["in_p"].fillna(False).astype(bool).to_numpy()
    A = df["in_a"].fillna(False).astype(bool).to_numpy()
    a1c = df["a1c65"].fillna(0).to_numpy(float)
    fpg = df["fpg126"].fillna(0).to_numpy(float)
    dx = df["dx"].fillna(-1).to_numpy(float)

    def add(table, key, r_est, r_se, py_est, py_se):
        rows.append({"table": table, "key": key, "r_estimate": r_est, "python_estimate": py_est,
                     "abs_diff_estimate": abs(r_est - py_est), "r_se": r_se, "python_se": py_se,
                     "rel_diff_se": (abs(r_se - py_se) / r_se) if (r_se is not None and py_se is not None and r_se > 0) else 0.0})

    # agreement cells, percent agreement, kappa, shares
    cells = {"cell c11": a1c * fpg, "cell c10": a1c * (1 - fpg), "cell c01": (1 - a1c) * fpg, "cell c00": (1 - a1c) * (1 - fpg)}
    agr = pd.read_csv(tables_dir / "agreement.csv").set_index("measure")
    est = {}
    for k, y in cells.items():
        p, se, _ = _prop(df, y, P, w_fast)
        est[k] = p
        add("agreement", k, agr.loc[k, "estimate"], agr.loc[k, "se"], p, se)
    c11, c10, c01, c00 = (est[k] for k in ("cell c11", "cell c10", "cell c01", "cell c00"))
    pe = (c11 + c10) * (c11 + c01) + (c00 + c01) * (c00 + c10)
    derived = {"percent_agreement": c11 + c00, "cohens_kappa": ((c11 + c00) - pe) / (1 - pe),
               "share_of_either_positive_hba1c_only": c10 / (c11 + c10 + c01),
               "share_of_either_positive_glucose_only": c01 / (c11 + c10 + c01),
               "share_of_either_positive_both": c11 / (c11 + c10 + c01),
               "share_of_glucose_positive_also_hba1c_positive": c11 / (c11 + c01),
               "share_of_hba1c_positive_also_glucose_positive": c11 / (c11 + c10)}
    for k, v in derived.items():
        add("agreement (point estimate only)", k, agr.loc[k, "estimate"], None, v, None)
    # overlap cells
    ov = pd.read_csv(tables_dir / "overlap.csv")
    for _, r in ov.iterrows():
        dd, aa, gg = int(r.cell[5]), int(r.cell[8]), int(r.cell[11])
        y = ((dx == dd) & (a1c == aa) & (fpg == gg)).astype(float)
        p, se, _ = _prop(df, y, P, w_fast)
        add("overlap", r.cell, r.estimate, r.se, p, se)
    # sensitivity 3: diagnosed with both biomarkers below threshold
    s3 = pd.read_csv(tables_dir / "s3_diagnosed_below_threshold.csv")
    treated = df["dx_treated"].to_numpy(float)
    bioneg = (df["bio_either"].fillna(1).to_numpy(float) == 0).astype(float)
    for _, r in s3.iterrows():
        m = P & (dx == 1)
        if r.group == "treated":
            m = m & (treated == 1)
        elif r.group == "not treated":
            m = m & (treated == 0)
        elif r.group == "treatment unknown":
            m = m & np.isnan(treated)
        p, se, _ = _prop(df, bioneg, m, w_fast)
        add("s3_diagnosed_below_threshold", r.group, r.estimate, r.se, p, se)
    # missingness by group (exam weight, domain A)
    a1c_status = df["a1c_status"].to_numpy()
    fs = df["fast_status"].to_numpy()
    status_y = {"miss_a1c": a1c_status != "measured", "fs_not_assigned": fs == "not_in_fasting_subsample",
                "fs_no_blood": fs == "subsample_no_blood", "fs_criterion": fs == "fasting_criterion_not_met",
                "fs_valid": fs == "valid", "not_in_p": ~P}
    mg = pd.read_csv(tables_dir / "missingness_by_group.csv")
    for _, r in mg.iterrows():
        g = A if r.group_variable == "overall" else A & (df[r.group_variable].to_numpy() == r.group)
        p, se, _ = _prop(df, status_y[r.status].astype(float), g, w_exam)
        add("missingness_by_group", f"{r.group}/{r.status}", r.estimate, r.se, p, se)
    # paired estimates by group
    pg = pd.read_csv(tables_dir / "paired_by_group.csv")
    for _, r in pg.iterrows():
        g = P & (df[r.group_variable].to_numpy() == r.group)
        pa, sa, za = _prop(df, a1c, g, w_fast)
        pf, sf, zf = _prop(df, fpg, g, w_fast)
        add("paired_by_group", f"{r.group}/hba1c", r.hba1c_estimate, r.hba1c_se, pa, sa)
        add("paired_by_group", f"{r.group}/glucose", r.glucose_estimate, r.glucose_se, pf, sf)
        add("paired_by_group", f"{r.group}/difference", r.difference, r.difference_se, pa - pf, linearized_var(df, za - zf) ** 0.5)
    # Covariance of the two primary estimates (K1, K2) in domain P
    import json as _json
    dc = _json.loads((tables_dir / "design_checks.json").read_text())
    _, _, zA = _prop(df, a1c, P, w_fast)
    _, _, zG = _prop(df, fpg, P, w_fast)
    t = pd.DataFrame({"h": df["sdmvstra"].to_numpy(), "j": df["sdmvpsu"].to_numpy(), "a": zA, "g": zG})
    psu = t.groupby(["h", "j"], sort=True)[["a", "g"]].sum().reset_index()
    cov = 0.0
    for _, gq in psu.groupby("h"):
        n_h = len(gq)
        cov += n_h / (n_h - 1) * ((gq.a - gq.a.mean()) * (gq.g - gq.g.mean())).sum()
    rows.append({"table": "design_checks", "key": "k1_k2_sampling_covariance", "r_estimate": dc["k1_k2_sampling_covariance"],
                 "python_estimate": cov, "abs_diff_estimate": abs(dc["k1_k2_sampling_covariance"] - cov),
                 "r_se": None, "python_se": None, "rel_diff_se": 0.0})
    # post hoc analyses (not prespecified)
    ph_file = tables_dir / "posthoc.csv"
    if ph_file.exists():
        ph = pd.read_csv(ph_file).set_index("analysis")
        lbxgh = df["lbxgh"].to_numpy(float)
        a64 = (np.round(lbxgh * 10) >= 64).astype(float)
        a66 = (np.round(lbxgh * 10) >= 66).astype(float)
        undx, ydx = (dx == 0).astype(float), (dx == 1).astype(float)
        pairs = {"PH1": (undx * a1c, undx * fpg), "PH2": (ydx * a1c, ydx * fpg), "PH4": (a64, fpg), "PH5": (a66, fpg)}
        for k, (yl, yr) in pairs.items():
            pl, sl, zl = _prop(df, yl, P, w_fast)
            pr, sr, zr = _prop(df, yr, P, w_fast)
            add("posthoc", f"{k}/left", ph.loc[k, "left_estimate"], None, pl, None)
            add("posthoc", f"{k}/right", ph.loc[k, "right_estimate"], None, pr, None)
            add("posthoc", f"{k}/difference", ph.loc[k, "estimate"], ph.loc[k, "se"], pl - pr, linearized_var(df, zl - zr) ** 0.5)
        U = P & (dx == 0)
        e = {}
        for k, y in {"c11": a1c * fpg, "c10": a1c * (1 - fpg), "c01": (1 - a1c) * fpg, "c00": (1 - a1c) * (1 - fpg)}.items():
            e[k], _, _ = _prop(df, y, U, w_fast)
        pe = (e["c11"] + e["c10"]) * (e["c11"] + e["c01"]) + (e["c00"] + e["c01"]) * (e["c00"] + e["c10"])
        for k, v in {"PH3_kappa": ((e["c11"] + e["c00"]) - pe) / (1 - pe), "PH3_agreement": e["c11"] + e["c00"],
                     "PH3_one_test_only": (e["c10"] + e["c01"]) / (e["c11"] + e["c10"] + e["c01"])}.items():
            add("posthoc (point estimate only)", k, ph.loc[k, "estimate"], None, v, None)
    # NCHS reconciliation (percent scale in the table)
    rr = tables_dir / "reference_reconciliation.csv"
    if rr.exists():
        rec = pd.read_csv(rr).dropna(subset=["our_percent"])
        undx = ((dx == 0) & (df["bio_either"].fillna(0).to_numpy(float) == 1)).astype(float)
        ycol = {"total": df["total_a1c_fpg"].fillna(0).to_numpy(float), "diagnosed": (dx == 1).astype(float), "undiagnosed": undx}
        age = df["age"].to_numpy(float)
        sex = df["sex_label"].to_numpy()
        for _, r in rec.iterrows():
            g = {"all": P, "men": P & (sex == "Male"), "women": P & (sex == "Female"),
                 "20-39": P & (age <= 39), "40-59": P & (age >= 40) & (age <= 59), "60+": P & (age >= 60)}[r.group]
            p, se, _ = _prop(df, ycol[r.measure], g, w_fast)
            add("reference_reconciliation", f"{r.measure}/{r.group}", r.our_percent / 100, r.our_se / 100, p, se)
    return pd.DataFrame(rows)
