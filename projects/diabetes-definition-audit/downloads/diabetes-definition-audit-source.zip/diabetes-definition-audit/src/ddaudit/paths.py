"""Project paths. Everything is resolved relative to the project root."""

from __future__ import annotations

import os
from pathlib import Path

# CODE_ROOT holds the code, SQL, R scripts, and the renv library. ROOT holds
# config, data, and results; it differs from CODE_ROOT only for the synthetic
# demo, which runs in its own folder so fixture outputs never mix with real ones.
CODE_ROOT = Path(__file__).resolve().parents[2]
ROOT = Path(os.environ.get("DDAUDIT_ROOT", CODE_ROOT)).resolve()
CONFIG = ROOT / "config"
DATA_RAW = ROOT / "data" / "raw"
DATA_INTERIM = ROOT / "data" / "interim"
RESULTS = ROOT / "results"
TABLES = RESULTS / "tables"
FIGURES = RESULTS / "figures"
VALIDATION = RESULTS / "validation"
EXPORTS = RESULTS / "exports"
SQL = CODE_ROOT / "sql"
RDIR = CODE_ROOT / "R"
DOCS = ROOT / "docs"
EVIDENCE = ROOT / "evidence"
LOGS = ROOT / "logs"
MANIFEST = ROOT / "source_manifest.json"
FIXTURES = CODE_ROOT / "tests" / "fixtures"


def ensure_dirs() -> None:
    for p in (DATA_RAW, DATA_INTERIM, TABLES, FIGURES, VALIDATION, EXPORTS, EVIDENCE, LOGS):
        p.mkdir(parents=True, exist_ok=True)


def rel(path: Path) -> str:
    """Path relative to the project root, with forward slashes."""
    return Path(path).resolve().relative_to(ROOT.resolve()).as_posix()
