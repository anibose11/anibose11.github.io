"""Build stage: XPT files -> DuckDB -> checked analytic frame and phenotypes.

Outputs per release (paths relative to the project root):
  data/interim/<release>/analytic.parquet, analytic.csv   person-level, not shipped
  results/tables/<release>/join_checks.csv
  results/tables/<release>/participant_flow.csv
  results/tables/<release>/status_counts.csv
  results/validation/<release>/build_checks.json
  results/provenance/<release>/*.sql                      SQL as executed
  docs/data_dictionary.csv                                (primary release)
"""

from __future__ import annotations

import json
from pathlib import Path
from string import Template

import duckdb
import numpy as np
import pandas as pd
import yaml

from . import paths
from .codebook import parse_doc

# Source-to-analysis dictionary: (table role, source variable, analysis column, transformation).
DICTIONARY = [
    ("demo", "SEQN", "seqn", "integer key; unique per file; every component joined on it"),
    ("demo", "RIDSTATR", "ridstatr", "2 = interviewed and examined"),
    ("demo", "RIDAGEYR", "age", "years; 80 means 80 or older (top-coded)"),
    ("demo", "RIAGENDR", "sex / sex_label", "1 Male, 2 Female"),
    ("demo", "RIDRETH3", "reth3 / reth_label", "self-reported race and Hispanic origin recode; 5 unused"),
    ("demo", "RIDEXPRG", "ridexprg / preg_status", "females 20-44 at exam: 1 pregnant, 2 not, 3 cannot ascertain; others not applicable"),
    ("demo", "SDMVPSU", "sdmvpsu", "masked variance pseudo-PSU"),
    ("demo", "SDMVSTRA", "sdmvstra", "masked variance pseudo-stratum"),
    ("demo", "WTINT2YR", "w_int", "interview weight; flow table only"),
    ("demo", "WTMEC2YR", "w_exam", "examination weight; missingness description in domain A only"),
    ("ghb", "WTPH2YR", "w_a1c", "phlebotomy weight; 0 = no blood specimen; absent from file treated as 0"),
    ("ghb", "LBXGH", "lbxgh / a1c65", "percent, rounded to 1 decimal; a1c65 = 1 if >= 6.5"),
    ("glu", "WTSAF2YR", "w_fast", "fasting subsample weight; 0 = no blood or fast outside 8 to <24 h; absent = not in subsample"),
    ("glu", "LBXGLU", "lbxglu / fpg126", "mg/dL, whole numbers; fpg126 = 1 if >= 126 and fast_status = valid"),
    ("fastqx", "PHAFSTHR", "fast_hours", "hours since last food or drink other than water, plus PHAFSTMN/60"),
    ("fastqx", "PHAFSTMN", "fast_hours", "minutes component"),
    ("fastqx", "PHQ020", "phq020 / ok_coffee", "coffee or tea with cream or sugar since fasting time; with PHACOFHR, PHACOFMN"),
    ("fastqx", "PHQ030", "phq030 / ok_alcohol", "alcohol; with PHAALCHR, PHAALCMN"),
    ("fastqx", "PHQ040", "phq040 / ok_gum", "gum, mints, lozenges, cough drops, cold remedies; with PHAGUMHR, PHAGUMMN"),
    ("fastqx", "PHQ050", "phq050 / ok_antacid", "antacids, laxatives, anti-diarrheals; with PHAANTHR, PHAANTMN"),
    ("fastqx", "PHQ060", "phq060 / ok_supplement", "dietary supplements; with PHASUPHR, PHASUPMN"),
    ("diq", "DIQ010", "diq010 / dx / dx_status", "1 yes, 2 no, 3 borderline (coded 0), 7 refused, 9 don't know"),
    ("diq", "DIQ050", "diq050 / dx_treated", "taking insulin now; asked of diagnosed participants"),
    ("diq", "DIQ070", "diq070 / dx_treated", "taking diabetic pills now"),
    ("rhq", "RHD143", "rhd143 / preg_status", "pregnant now (interview), females 20-44; used only when RIDEXPRG = 3"),
]


def _clean_xpt(df: pd.DataFrame) -> pd.DataFrame:
    """SAS transport stores exact zero in a way that can read back as about 5e-79."""
    for c in df.columns:
        if pd.api.types.is_float_dtype(df[c]):
            df.loc[df[c].abs() < 1e-30, c] = 0.0
    return df


def read_release(release: str, cfg: dict) -> tuple[dict[str, pd.DataFrame], bool]:
    """Read the release's files. Returns (tables, is_fixture).

    Real NHANES files are SAS transport (.xpt). The synthetic test fixture uses
    files named <FILE>.fixture.csv and is read only when no .xpt file exists, so a
    fixture can never be mixed with real data in one build.
    """
    tables, kinds = {}, set()
    for role, fname in cfg["build"]["tables"].items():
        xpt = paths.DATA_RAW / release / f"{fname}.xpt"
        fix = paths.DATA_RAW / release / f"{fname}.fixture.csv"
        if xpt.exists():
            tables[role] = _clean_xpt(pd.read_sas(xpt, format="xport", encoding="latin-1"))
            kinds.add("xpt")
        elif fix.exists():
            tables[role] = pd.read_csv(fix, comment="#")
            kinds.add("fixture")
        else:
            raise FileNotFoundError(f"{xpt} missing; run `python -m ddaudit acquire` first")
    if len(kinds) > 1:
        raise RuntimeError(f"release {release} mixes real files and fixture files; refusing to build")
    return tables, kinds == {"fixture"}


def verify_source_hashes(release: str, cfg: dict) -> dict[str, str]:
    """Recompute SHA-256 of every file the build reads and compare with source_manifest.json."""
    from .acquire import sha256_file
    manifest = json.loads(paths.MANIFEST.read_text())["entries"]
    out = {}
    for fname in cfg["build"]["tables"].values():
        for kind, path in (("data_xpt", paths.DATA_RAW / release / f"{fname}.xpt"),
                           ("documentation", paths.DATA_RAW / release / "docs" / f"{fname}.htm")):
            key = f"{release}/{kind}/{fname}"
            if key not in manifest:
                raise RuntimeError(f"{key} is not in source_manifest.json; run `make acquire`")
            got = sha256_file(path)
            if got != manifest[key]["sha256"]:
                raise RuntimeError(f"{path} does not match source_manifest.json ({got[:12]} vs {manifest[key]['sha256'][:12]})")
            out[key] = got
    return out


def render_sql(name: str, params: dict) -> str:
    return Template((paths.SQL / name).read_text()).substitute(params)


def build_release(release: str, cfg: dict, phen: dict, write_dictionary: bool) -> dict:
    out_tables = paths.TABLES / release
    out_val = paths.VALIDATION / release
    out_prov = paths.RESULTS / "provenance" / release
    out_interim = paths.DATA_INTERIM / release
    for p in (out_tables, out_val, out_prov, out_interim):
        p.mkdir(parents=True, exist_ok=True)

    raw, is_fixture = read_release(release, cfg)
    verified = {} if is_fixture else verify_source_hashes(release, cfg)
    # One thread keeps floating-point summation order, and so every output, deterministic.
    con = duckdb.connect(config={"threads": 1})
    for role, df in raw.items():
        con.register(role, df)

    params = {
        "release": release,
        **cfg["build"]["weights"],
        "a1c_threshold": phen["thresholds"]["a1c"]["value"],
        "fpg_threshold": phen["thresholds"]["fpg"]["value"],
        "narrow_min_hours": phen["narrow_fasting"]["min_hours"],
        **{k: v.replace("'", "''") for k, v in cfg["build"].get("flow_labels", {}).items()},
    }
    checks: dict = {"release": release}

    sql = render_sql("01_join_checks.sql", params)
    (out_prov / "01_join_checks.sql").write_text(sql)
    joins = con.execute(sql).df()
    joins.to_csv(out_tables / "join_checks.csv", index=False)
    bad = joins[(joins.n_duplicate_seqn != 0) | (joins.n_not_in_demo != 0)]
    if len(bad):
        raise RuntimeError(f"join cardinality check failed:\n{bad}")
    checks["join_checks"] = "every component has unique SEQN and every SEQN is in DEMO"

    for name in ("02_frame.sql", "03_phenotypes.sql"):
        sql = render_sql(name, params)
        (out_prov / name).write_text(sql)
        con.execute(sql)

    n_demo = len(raw["demo"])
    n_frame = con.execute("SELECT count(*) FROM analytic").fetchone()[0]
    if n_frame != n_demo:
        raise RuntimeError(f"row reconciliation failed: frame {n_frame} vs DEMO {n_demo}")
    checks["rows_frame_equals_demo"] = n_frame

    # Rounding to published precision must not move any value materially.
    rd = con.execute("""
        SELECT max(abs(lbxgh - lbxgh_unrounded)) AS a1c, max(abs(lbxglu - lbxglu_unrounded)) AS glu
        FROM analytic""").fetchone()
    checks["max_rounding_change"] = {"lbxgh": rd[0], "lbxglu": rd[1]}
    if (rd[0] or 0) > 1e-6 or (rd[1] or 0) > 1e-6:
        raise RuntimeError(f"rounding changed laboratory values: {rd}")

    # Internal consistency with the documentation.
    q = lambda s: con.execute(s).fetchone()[0]  # noqa: E731
    checks["fasting_weight_outside_window"] = q(
        "SELECT count(*) FROM analytic WHERE w_fast > 0 AND NOT (fast_hours >= 8 AND fast_hours < 24)")
    checks["fasting_weight_positive_missing_fast_time"] = q(
        "SELECT count(*) FROM analytic WHERE w_fast > 0 AND fast_hours IS NULL")
    checks["zero_fasting_weight_with_glucose"] = q(
        "SELECT count(*) FROM analytic WHERE fast_status = 'fasting_criterion_not_met'")
    checks["zero_fasting_weight_with_glucose_window"] = con.execute("""
        SELECT count(*) FILTER (WHERE fast_hours < 8), count(*) FILTER (WHERE fast_hours >= 24),
               count(*) FILTER (WHERE fast_hours IS NULL), count(*) FILTER (WHERE fast_hours >= 8 AND fast_hours < 24)
        FROM analytic WHERE fast_status = 'fasting_criterion_not_met'""").fetchone()
    checks["hba1c_result_with_zero_weight"] = q(
        "SELECT count(*) FROM analytic WHERE a1c_status = 'result_but_zero_weight'")
    checks["laboratory_weight_without_examination"] = q(
        "SELECT count(*) FROM analytic WHERE (w_a1c > 0 OR w_fast > 0) AND ridstatr <> 2")
    checks["domain_nesting_violations"] = q("""
        SELECT count(*) FROM analytic
        WHERE (in_p AND NOT (in_h AND in_f)) OR (in_h AND NOT in_a) OR (in_f AND NOT in_a)
           OR (in_p_narrow AND NOT in_p)""")
    checks["null_phenotype_inside_domain"] = q("""
        SELECT count(*) FROM analytic
        WHERE (in_p AND (a1c65 IS NULL OR fpg126 IS NULL OR dx IS NULL OR total_a1c_fpg IS NULL))
           OR (in_h AND (a1c65 IS NULL OR total_a1c IS NULL)) OR (in_f AND fpg126 IS NULL)""")
    checks["psu_values"] = sorted(int(x) for x in con.execute("SELECT DISTINCT sdmvpsu FROM analytic").df().sdmvpsu)
    checks["n_strata"] = q("SELECT count(DISTINCT sdmvstra) FROM analytic")
    checks["n_psu"] = q("SELECT count(DISTINCT (sdmvstra, sdmvpsu)) FROM analytic")
    for k in ("fasting_weight_outside_window", "fasting_weight_positive_missing_fast_time",
              "domain_nesting_violations", "null_phenotype_inside_domain", "laboratory_weight_without_examination"):
        if checks[k]:
            raise RuntimeError(f"consistency check {k} failed: {checks[k]}")

    sql = render_sql("04_flow.sql", params)
    (out_prov / "04_flow.sql").write_text(sql)
    flow = con.execute(sql).df()
    flow.insert(0, "release", release)
    flow.to_csv(out_tables / "participant_flow.csv", index=False)

    status = con.execute("""
        SELECT 'examined adults 20+' AS scope, 'preg_status' AS variable, preg_status AS status, count(*) AS n
        FROM analytic WHERE ridstatr = 2 AND age >= 20 GROUP BY ALL
        UNION ALL SELECT 'examined adults 20+', 'dx_status', dx_status, count(*) FROM analytic WHERE ridstatr = 2 AND age >= 20 GROUP BY ALL
        UNION ALL SELECT 'domain A', 'a1c_status', a1c_status, count(*) FROM analytic WHERE in_a GROUP BY ALL
        UNION ALL SELECT 'domain A', 'fast_status', fast_status, count(*) FROM analytic WHERE in_a GROUP BY ALL
        UNION ALL SELECT 'domain A', 'preg_status', preg_status, count(*) FROM analytic WHERE in_a GROUP BY ALL
        UNION ALL SELECT 'domain P', 'narrow_status', narrow_status, count(*) FROM analytic WHERE in_p GROUP BY ALL
        ORDER BY 1, 2, 3""").df()
    status.insert(0, "release", release)
    status.to_csv(out_tables / "status_counts.csv", index=False)

    analytic = con.execute("SELECT * EXCLUDE (lbxgh_unrounded, lbxglu_unrounded) FROM analytic ORDER BY seqn").df()
    analytic.to_parquet(out_interim / "analytic.parquet", index=False)
    r_cols = ["seqn", "sdmvpsu", "sdmvstra", "w_exam", "w_a1c", "w_fast", "age", "age_group", "sex_label",
              "reth_label", "in_a", "in_h", "in_f", "in_p", "in_p_narrow", "dx", "a1c65", "fpg126", "bio_either",
              "total_a1c_fpg", "total_a1c", "dx_treated", "a1c_status", "fast_status", "in_glu_file", "lbxgh"]
    rdf = analytic[r_cols].copy()
    for c in ("in_a", "in_h", "in_f", "in_p", "in_p_narrow", "in_glu_file"):
        rdf[c] = rdf[c].fillna(False).astype(int)
    rdf.to_csv(out_interim / "analytic_for_r.csv", index=False, na_rep="NA")

    checks["synthetic_fixture"] = is_fixture
    checks["source_sha256_verified_against_manifest"] = verified

    # Domain P participants failing each narrow-fasting item (a participant can fail several).
    nf = con.execute("""
        SELECT 'coffee or tea with cream or sugar' AS item, count(*) FILTER (WHERE ok_coffee = FALSE) AS n_failing
        FROM analytic WHERE in_p
        UNION ALL SELECT 'alcohol', count(*) FILTER (WHERE ok_alcohol = FALSE) FROM analytic WHERE in_p
        UNION ALL SELECT 'gum, mints, lozenges, cough drops, cold remedies', count(*) FILTER (WHERE ok_gum = FALSE) FROM analytic WHERE in_p
        UNION ALL SELECT 'antacids, laxatives, anti-diarrheals', count(*) FILTER (WHERE ok_antacid = FALSE) FROM analytic WHERE in_p
        UNION ALL SELECT 'dietary supplements', count(*) FILTER (WHERE ok_supplement = FALSE) FROM analytic WHERE in_p
        UNION ALL SELECT 'any item (excluded from P-narrow)', count(*) FILTER (WHERE narrow_status = 'intake_within_window') FROM analytic WHERE in_p
        UNION ALL SELECT 'unknown answer or time', count(*) FILTER (WHERE narrow_status = 'unknown') FROM analytic WHERE in_p""").df()
    nf.insert(0, "release", release)
    nf.insert(1, "sample_universe", "P: domain P participants (unweighted counts)")
    nf.to_csv(out_tables / "narrow_fail_counts.csv", index=False)
    if is_fixture:
        checks["codebook_reconciliation"] = {"rows_checked": 0, "mismatches": 0, "note": "synthetic fixture; no NCHS codebook"}
    else:
        # Reconcile file counts with the published codebook frequencies.
        recon = reconcile_codebook(release, cfg, raw)
        recon.to_csv(out_val / "codebook_reconciliation.csv", index=False)
        checks["codebook_reconciliation"] = {
            "rows_checked": int(len(recon)), "mismatches": int((~recon.match).sum())}
        write_data_dictionary(release, cfg)

    checks = json.loads(json.dumps(checks, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
    (out_val / "build_checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    con.close()
    return {"release": release, "rows": n_frame, "checks": checks}


def _count_code(series: pd.Series, code: str) -> int | None:
    from .codebook import parse_range
    if code == ".":
        return int(series.isna().sum())
    rng = parse_range(code)
    if rng is not None:
        lo, hi = rng
        # Endpoints are printed rounded; allow half a unit in the last printed decimal.
        tol = max(0.5 * 10 ** -(len(p.split(".")[1]) if "." in p else 0) for p in code.split(" to "))
        return int(((series >= lo - tol) & (series <= hi + tol)).sum())
    try:
        v = float(code)
    except ValueError:
        return None
    return int((series.round(9) == v).sum())


RECON_VARS = {
    "demo": ["RIDSTATR", "RIAGENDR", "RIDRETH3", "RIDEXPRG", "WTMEC2YR", "WTMECPRP", "SDMVPSU", "SDMVSTRA"],
    "ghb": ["WTPH2YR", "LBXGH"],
    "glu": ["WTSAF2YR", "WTSAFPRP", "LBXGLU"],
    "fastqx": ["PHQ020", "PHQ030", "PHQ040", "PHQ050", "PHQ060"],
    "diq": ["DIQ010", "DIQ050", "DIQ070"],
    "rhq": ["RHD143"],
}


def reconcile_codebook(release: str, cfg: dict, raw: dict[str, pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for role, fname in cfg["build"]["tables"].items():
        cb = parse_doc(paths.DATA_RAW / release / "docs" / f"{fname}.htm")
        df = raw[role]
        for var in RECON_VARS.get(role, []):
            if var not in df.columns or var not in cb:
                continue
            total_doc = sum(v["count"] for v in cb[var]["values"])
            rows.append({"release": release, "file": fname, "variable": var, "code": "(all rows)",
                         "description": "file rows vs codebook total", "codebook_count": total_doc,
                         "file_count": len(df), "match": total_doc == len(df)})
            for v in cb[var]["values"]:
                got = _count_code(df[var], v["code"])
                if got is None:
                    continue
                rows.append({"release": release, "file": fname, "variable": var, "code": v["code"],
                             "description": v["description"], "codebook_count": v["count"],
                             "file_count": got, "match": got == v["count"]})
    return pd.DataFrame(rows)


def write_data_dictionary(release: str, cfg: dict) -> None:
    """Append or replace this release's rows in docs/data_dictionary.csv."""
    rows = []
    cbs = {role: parse_doc(paths.DATA_RAW / release / "docs" / f"{f}.htm") for role, f in cfg["build"]["tables"].items()}
    # Weight rows follow the release's own weight mapping in config/sources.yaml.
    wmap = cfg["build"]["weights"]
    a1c_expr = wmap["w_a1c"]
    a1c_var = a1c_expr.split(".")[-1].split()[0] if a1c_expr.startswith(("g.", "d.")) else "WTMECPRP"
    entries = []
    for role, var, col, transform in DICTIONARY:
        if col == "w_int":
            var = wmap["w_int"].split(".")[-1]
        elif col == "w_exam":
            var = wmap["w_exam"].split(".")[-1]
        elif col == "w_fast":
            var = wmap["w_fast"].split(".")[-1]
        elif col == "w_a1c" and not a1c_expr.startswith("g."):
            role, var = "demo", a1c_var
            transform = "examination weight used for HbA1c because this release has no phlebotomy weight; zero or absent HbA1c result excludes from domain H"
        entries.append((role, var, col, transform))
    for role, var, col, transform in entries:
        fname = cfg["build"]["tables"][role]
        cb = cbs[role].get(var, {})
        rows.append({"release": release, "source_file": fname, "source_variable": var,
                     "sas_label": cb.get("sas_label", ""), "target_universe": cb.get("target", ""),
                     "analysis_column": col, "transformation": transform})
    out = paths.DOCS / "data_dictionary.csv"
    new = pd.DataFrame(rows)
    if out.exists():
        old = pd.read_csv(out)
        new = pd.concat([old[old.release != release], new], ignore_index=True)
    order = {"2021-2023": 0, "2017-2020": 1}
    new = new.sort_values("release", key=lambda c: c.map(order), kind="stable")
    new.to_csv(out, index=False)


def build() -> dict:
    cfg = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    phen = yaml.safe_load((paths.CONFIG / "phenotypes.yaml").read_text())
    results = {}
    for rel_id, rel in cfg["releases"].items():
        if not (paths.DATA_RAW / rel_id).exists():
            results[rel_id] = {"status": "not acquired"}
            continue
        results[rel_id] = build_release(rel_id, rel, phen, write_dictionary=(rel.get("role") == "primary"))
    return {"rows": {k: v.get("rows") for k, v in results.items()}, "releases": results}
