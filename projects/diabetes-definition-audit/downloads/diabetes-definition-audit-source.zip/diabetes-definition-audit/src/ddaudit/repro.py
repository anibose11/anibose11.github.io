"""Snapshot substantive outputs and compare two snapshots within a tolerance.

Compared: every CSV under results/tables and results/validation, the document
values, and the claims ledger. Run identifiers and timestamps are ignored;
everything else must match exactly (strings) or within the tolerance (numbers).
"""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import pandas as pd

from . import paths

IGNORE_KEYS = {"run_id", "render_finished_utc", "analysis_started_utc", "analysis_finished_utc", "updated_utc"}


def snapshot(dest: str) -> dict:
    d = Path(dest).resolve()
    if d.exists():
        shutil.rmtree(d)
    n = 0
    for src_dir in (paths.TABLES, paths.VALIDATION):
        for f in src_dir.rglob("*"):
            if f.is_file() and f.suffix in {".csv", ".json"}:
                out = d / f.relative_to(paths.RESULTS)
                out.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, out)
                n += 1
    for f in (paths.RESULTS / "document_values.json", paths.EVIDENCE / "claims.json"):
        if f.exists():
            shutil.copy2(f, d / f.name)
            n += 1
    return {"snapshot": str(d), "files": n}


def _cmp_json(a, b, tol, path=""):
    diffs = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k in IGNORE_KEYS:
                continue
            if k not in a or k not in b:
                diffs.append(f"{path}/{k}: missing on one side")
            else:
                diffs += _cmp_json(a[k], b[k], tol, f"{path}/{k}")
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            diffs.append(f"{path}: list length {len(a)} vs {len(b)}")
        else:
            for i, (x, y) in enumerate(zip(a, b)):
                diffs += _cmp_json(x, y, tol, f"{path}[{i}]")
    elif isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        if not (math.isclose(a, b, abs_tol=tol) or (math.isnan(a) and math.isnan(b))):
            diffs.append(f"{path}: {a} vs {b}")
    elif a != b:
        diffs.append(f"{path}: {str(a)[:60]!r} vs {str(b)[:60]!r}")
    return diffs


def compare(left: str, right: str, tol: float = 1e-9) -> dict:
    L, R = Path(left).resolve(), Path(right).resolve()
    lf = {p.relative_to(L) for p in L.rglob("*") if p.is_file()}
    rf = {p.relative_to(R) for p in R.rglob("*") if p.is_file()}
    diffs, values, max_abs = [], 0, 0.0
    for missing in sorted(lf ^ rf):
        diffs.append(f"{missing}: present on one side only")
    for rel in sorted(lf & rf):
        a, b = L / rel, R / rel
        if rel.suffix == ".csv":
            x, y = pd.read_csv(a), pd.read_csv(b)
            if x.shape != y.shape or list(x.columns) != list(y.columns):
                diffs.append(f"{rel}: shape or columns differ")
                continue
            for c in x.columns:
                if pd.api.types.is_numeric_dtype(x[c]) and pd.api.types.is_numeric_dtype(y[c]):
                    xa, ya = x[c].to_numpy(float), y[c].to_numpy(float)
                    both_nan = pd.isna(xa) & pd.isna(ya)
                    one_nan = pd.isna(xa) ^ pd.isna(ya)
                    d = abs(xa - ya)
                    d[both_nan] = 0
                    d[one_nan] = math.inf  # a value missing on one side only is a difference
                    values += len(xa)
                    m = float(pd.Series(d).max()) if len(d) else 0.0
                    max_abs = max(max_abs, m if not math.isnan(m) else math.inf)
                    if m > tol or math.isnan(m):
                        diffs.append(f"{rel}:{c}: max abs difference {m}")
                else:
                    values += len(x)
                    if not x[c].fillna("<NA>").astype(str).equals(y[c].fillna("<NA>").astype(str)):
                        diffs.append(f"{rel}:{c}: text differs")
        elif rel.suffix == ".json":
            diffs += [f"{rel}{d}" for d in _cmp_json(json.loads(a.read_text()), json.loads(b.read_text()), tol)]
    return {"files_compared": len(lf & rf), "table_values_compared": values, "max_abs_difference": max_abs,
            "tolerance": tol, "differences": diffs[:50], "identical_within_tolerance": not diffs}
