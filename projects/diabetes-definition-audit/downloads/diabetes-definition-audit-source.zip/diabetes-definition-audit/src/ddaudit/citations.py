"""Number keyed citations in the manuscript template by order of first citation.

Citations are written as [@key] or [@key1; @key2] in the text, and the reference
list under "## References" as lines "[@key]: reference text". Writes the numbered
text (citations such as [3–5] or [10, 11], and a list "1. ..."). Fails on a cited
key without a reference or on a reference that is never cited.
"""
from __future__ import annotations

import re

GROUP = re.compile(r"\[(@[A-Za-z0-9_]+(?:;\s*@[A-Za-z0-9_]+)*)\]")


def compress(nums: list[int]) -> str:
    nums = sorted(set(nums))
    out, i = [], 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
            j += 1
        out.append(f"{nums[i]}–{nums[j]}" if j - i >= 2 else ", ".join(str(n) for n in nums[i:j + 1]))
        i = j + 1
    return ", ".join(out)


def number(text: str) -> str:
    body, rest = text.split("## References\n", 1)
    refs_block, tail = rest.split("\n## Tables", 1)
    refs = dict(re.findall(r"^\[@([A-Za-z0-9_]+)\]: (.+)$", refs_block, re.M))
    order: dict[str, int] = {}
    for m in GROUP.finditer(body):
        for k in re.findall(r"@([A-Za-z0-9_]+)", m.group(1)):
            if k not in refs:
                raise SystemExit(f"cited key without a reference: {k}")
            order.setdefault(k, len(order) + 1)
    unused = set(refs) - set(order)
    if unused:
        raise SystemExit(f"references never cited: {sorted(unused)}")
    body = GROUP.sub(lambda m: "[" + compress([order[k] for k in re.findall(r"@([A-Za-z0-9_]+)", m.group(1))]) + "]", body)
    lst = "\n".join(f"{n}. {refs[k]}" for k, n in sorted(order.items(), key=lambda kv: kv[1]))
    return body + "## References\n\n" + lst + "\n\n## Tables" + tail
