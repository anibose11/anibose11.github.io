"""Figures from the real-data result tables (PNG, light surface).

Palette: categorical slots validated with the dataviz validator (blue, orange,
aqua, yellow; light mode, adjacent and all-pairs checks pass). Two slots are
below 3:1 contrast on the surface, so every figure carries direct labels or a
legend and has a matching CSV table.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from . import paths  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#8a8984"
GRID = "#e4e3df"
BLUE, ORANGE, AQUA, YELLOW = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
NEUTRAL = "#6b6a66"
RELEASE_LABEL = {"2021-2023": "August 2021-August 2023", "2017-2020": "2017-March 2020 (replication)"}

plt.rcParams.update({
    "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 10,
    "axes.edgecolor": GRID,
    "axes.linewidth": 1,
    "axes.labelcolor": INK2,
    "xtick.color": INK2,
    "ytick.color": INK2,
    "axes.facecolor": SURFACE,
    "figure.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "svg.fonttype": "none",
})
DPI = 200


def _pct(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}%"


def _pp(x: float, d: int = 1) -> str:
    v = 100 * x
    txt = f"{v:+.{d}f}"
    if float(txt) == 0:
        return f"{0:.{d}f}"
    return txt.replace("-", "−")


def _grid_x(ax) -> None:
    ax.grid(axis="x", color=GRID, linewidth=1)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    ax.spines["left"].set_visible(False)


def _dot_ci(ax, y, est, lo, hi, color, label=None, hollow=False):
    ax.plot([lo, hi], [y, y], color=color, linewidth=2, solid_capstyle="round", zorder=2)
    ax.scatter([est], [y], s=64, color=SURFACE if hollow else color, edgecolor=color if hollow else SURFACE,
               linewidth=2, zorder=3, label=label)


def _load(release: str, name: str) -> pd.DataFrame:
    return pd.read_csv(paths.TABLES / release / name)


def _title(fig, title: str, subtitle: str) -> None:
    """Figures carry no embedded title: the manuscript and the project page give each
    figure a title and legend, as BMC asks. The arguments document the figure's content."""
    return None


def fig_paired(releases: list[str]) -> str:
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.2, 3.4), gridspec_kw={"width_ratios": [1.25, 1]})
    fig.subplots_adjust(left=0.2, right=0.97, top=0.86, bottom=0.17, wspace=0.12)
    yt, yl = [], []
    for i, rel in enumerate(releases):
        e = _load(rel, "estimates.csv").set_index("config_id")
        c = _load(rel, "contrasts.csv").set_index("contrast_id")
        y = len(releases) - 1 - i
        for off, cid, color, lab in ((0.14, "K1", BLUE, "HbA1c ≥ 6.5%"), (-0.14, "K2", ORANGE, "Fasting glucose ≥ 126 mg/dL")):
            r = e.loc[cid]
            _dot_ci(a1, y + off, r.estimate, r.ci_low, r.ci_high, color, label=lab if i == 0 else None)
            a1.text(r.ci_high + 0.003, y + off, _pct(r.estimate), va="center", fontsize=9, color=INK)
        d = c.loc["C1"]
        _dot_ci(a2, y, d.estimate, d.ci_low, d.ci_high, NEUTRAL)
        a2.text(d.estimate, y + 0.12, f"{_pp(d.estimate)} pts", ha="center", va="bottom", fontsize=9, color=INK)
        yt.append(y)
        yl.append(f"{RELEASE_LABEL[rel]}\nn = {int(e.loc['K1'].n_unweighted):,}")
    for a in (a1, a2):
        _grid_x(a)
        a.set_ylim(-0.6, len(releases) - 0.4)
    a1.set_yticks(yt, yl, fontsize=9, color=INK)
    a2.set_yticks([])
    a1.set_xlim(0.06, 0.16)
    a1.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:.0f}%"))
    a1.set_xlabel("Weighted prevalence, common paired domain")
    a2.axvline(0, color=INK2, linewidth=1)
    a2.set_xlim(-0.035, 0.02)
    a2.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:+.0f}".replace("-", "−").replace("+0", "0")))
    a2.set_xlabel("HbA1c minus glucose, percentage points")
    a1.legend(loc="upper center", bbox_to_anchor=(0.5, 1.17), ncol=2, frameon=False, fontsize=9, handletextpad=0.3)
    _title(fig, "Both thresholds measured in the same adults, with the same weight",
           "Adults 20+, not pregnant, valid fasting glucose and HbA1c (domain P), fasting subsample weight. "
           "Lines are 95% intervals: Korn-Graubard for prevalence,\nt with design degrees of freedom for the paired difference.")
    out = paths.FIGURES / "fig1_paired_common_denominator.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def fig_sample(releases: list[str]) -> str:
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(9.2, 3.9), gridspec_kw={"width_ratios": [1, 1.15]})
    fig.subplots_adjust(left=0.2, right=0.97, top=0.8, bottom=0.14, wspace=0.12)
    yt, yl = [], []
    rows2, labels2 = [], []
    for i, rel in enumerate(releases):
        e = _load(rel, "estimates.csv").set_index("config_id")
        c = _load(rel, "contrasts.csv").set_index("contrast_id")
        y = len(releases) - 1 - i
        for off, cid, color, lab in ((0.14, "K3", AQUA, "HbA1c laboratory domain H"), (-0.14, "K1", BLUE, "Common paired domain P")):
            r = e.loc[cid]
            _dot_ci(a1, y + off, r.estimate, r.ci_low, r.ci_high, color, label=lab if i == 0 else None)
            a1.text(r.ci_high + 0.0015, y + off, f"{_pct(r.estimate)} (n = {int(r.n_unweighted):,}, {r.weight})",
                    va="center", fontsize=8, color=INK)
        yt.append(y)
        yl.append(RELEASE_LABEL[rel])
        base = (len(releases) - 1 - i) * 3.6
        for k, (cid, color, lab) in enumerate((("C3", NEUTRAL, "Naive: HbA1c in H minus glucose in P"),
                                               ("C1", BLUE, "Definition part: HbA1c minus glucose in P"),
                                               ("C2", AQUA, "Sample and weight part: HbA1c in H minus in P"))):
            d = c.loc[cid]
            yy = base + 2 - k
            _dot_ci(a2, yy, d.estimate, d.ci_low, d.ci_high, color)
            a2.text(0.0275, yy, f"{_pp(d.estimate, 2)}", ha="right", va="center", fontsize=8.4, color=INK)
            rows2.append(yy)
            labels2.append(lab if i == 0 else "")
        a2.text(-0.0345, base + 2.5, RELEASE_LABEL[rel], fontsize=8.5, color=INK, weight="bold")
    _grid_x(a1)
    a1.set_ylim(-0.6, len(releases) - 0.4)
    a1.set_yticks(yt, yl, fontsize=9, color=INK)
    a1.set_xlim(0.075, 0.165)
    a1.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:.0f}%"))
    a1.set_xlabel("HbA1c ≥ 6.5%, weighted prevalence")
    a1.legend(loc="upper center", bbox_to_anchor=(0.5, 1.2), ncol=1, frameon=False, fontsize=9, handletextpad=0.3)
    _grid_x(a2)
    a2.axvline(0, color=INK2, linewidth=1)
    a2.set_yticks([])
    a2.set_xlim(-0.035, 0.028)
    a2.set_ylim(-0.6, 3.6 * len(releases) - 0.3)
    a2.set_xticks([-0.03, -0.02, -0.01, 0, 0.01, 0.02])
    a2.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:+.0f}".replace("-", "−").replace("+0", "0")))
    a2.set_xlabel("Difference (percentage points)")
    from matplotlib.lines import Line2D
    handles = [Line2D([0], [0], marker="o", color=col, markersize=7, linewidth=2, markeredgecolor=SURFACE)
               for col in (NEUTRAL, BLUE, AQUA)]
    a2.legend(handles, ["Naive cross-domain difference", "Definition part (paired, domain P)",
                        "Sample and weight part (HbA1c, H vs P)"],
              loc="upper center", bbox_to_anchor=(0.5, 1.27), ncol=1, frameon=False, fontsize=8.6, handletextpad=0.4)
    _title(fig, "Moving HbA1c to its larger laboratory sample barely changes it",
           "Left: the same HbA1c threshold in two domains. Right: the naive HbA1c-versus-glucose difference equals the definition part "
           "plus the sample\nand weight part exactly. The sample and weight part is a descriptive comparison, not a causal effect. Lines are 95% intervals.")
    out = paths.FIGURES / "fig2_sample_and_definition_parts.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def fig_overlap(release: str) -> str:
    ov = _load(release, "overlap.csv")
    ov = ov[~((ov.diagnosed == "no") & (ov.hba1c_6_5_or_more == "no") & (ov.glucose_126_or_more == "no"))].copy()

    def lab(r):
        parts = []
        parts.append("Diagnosed" if r.diagnosed == "yes" else "Not diagnosed")
        hi = [n for n, v in (("HbA1c", r.hba1c_6_5_or_more), ("glucose", r.glucose_126_or_more)) if v == "yes"]
        parts.append(" and ".join(hi) + " high" if hi else "both below threshold")
        return ", ".join(parts)
    ov["label"] = ov.apply(lab, axis=1)
    ov = ov.sort_values("estimate")
    fig, ax = plt.subplots(figsize=(8.6, 3.4))
    fig.subplots_adjust(left=0.36, right=0.95, top=0.96, bottom=0.14)
    y = np.arange(len(ov))
    ax.barh(y, ov.estimate, height=0.55, color=BLUE, edgecolor=SURFACE, linewidth=2)
    for yy, (_, r) in zip(y, ov.iterrows()):
        ax.plot([r.ci_low, r.ci_high], [yy, yy], color=INK2, linewidth=1)
        ax.text(r.ci_high + 0.0015, yy, f"{_pct(r.estimate)}  (n = {int(r.n_positive_unweighted)})", va="center", fontsize=8.5, color=INK)
    ax.set_yticks(y, ov.label, fontsize=9, color=INK)
    _grid_x(ax)
    ax.set_xlim(0, 0.105)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:.0f}%"))
    ax.set_xlabel("Weighted share of all adults in domain P (thin lines: 95% intervals)")
    allneg = _load(release, "overlap.csv").query("diagnosed == 'no' and hba1c_6_5_or_more == 'no' and glucose_126_or_more == 'no'").iloc[0]
    _title(fig, "One in five diagnosed adults had both biomarkers below threshold",
           f"{RELEASE_LABEL[release]}, domain P, fasting subsample weight. Not shown: no diagnosis and both below threshold, "
           f"{_pct(allneg.estimate)}.")
    out = paths.FIGURES / "fig3_overlap_of_definitions.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def fig_missingness(release: str) -> str:
    m = _load(release, "missingness_by_group.csv")
    order = [("overall", None), ("age_group", ["20-44", "45-64", "65+"]), ("sex_label", ["Female", "Male"]),
             ("reth_label", ["Mexican American", "Other Hispanic", "Non-Hispanic White", "Non-Hispanic Black",
                             "Non-Hispanic Asian", "Other or multiracial"])]
    statuses = [("fs_valid", "Valid fasting glucose", BLUE), ("fs_not_assigned", "Not assigned to fasting subsample", ORANGE),
                ("fs_no_blood", "Assigned, no blood specimen", AQUA), ("fs_criterion", "Assigned, fast outside 8 to <24 h", YELLOW)]
    rows = []
    for gv, levels in order:
        sub = m[m.group_variable == gv]
        for lv in (levels or sorted(sub.group.unique())):
            rows.append((gv, lv, sub[sub.group == lv].set_index("status")))
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    fig.subplots_adjust(left=0.24, right=0.97, top=0.84, bottom=0.1)
    ys = np.arange(len(rows))[::-1]
    any_suppressed = False
    for y, (gv, lv, t) in zip(ys, rows):
        left = 0.0
        for st, _, col in statuses:
            w = float(t.loc[st, "estimate"])
            suppressed = t.loc[st, "nchs_status"] == "suppressed"
            any_suppressed |= suppressed
            ax.barh(y, w, left=left, height=0.62, color=SURFACE if suppressed else col,
                    edgecolor=col if suppressed else SURFACE, linewidth=1 if suppressed else 2,
                    hatch="////" if suppressed else None)
            if st == "fs_valid" and not suppressed:
                ax.text(left + 0.012, y, _pct(w, 0), va="center", fontsize=8.2, color="white", weight="bold")
            left += w
    ax.set_yticks(ys, [lv for _, lv, _ in rows], fontsize=9, color=INK)
    ax.set_xlim(0, 1)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:.0f}%"))
    _grid_x(ax)
    ax.set_xlabel("Weighted share of adults in domain A (examination weight)")
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for _, _, c in statuses]
    labels = [lab for _, lab, _ in statuses]
    if any_suppressed:
        handles.append(plt.Rectangle((0, 0), 1, 1, facecolor=SURFACE, edgecolor=INK2, hatch="////", linewidth=1))
        labels.append("Hatched: suppressed under NCHS standards")
    ax.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.42, 1.17), ncol=3 if any_suppressed else 2,
              frameon=False, fontsize=8.4)
    _title(fig, "Most of the missing fasting glucose is missing by design",
           f"{RELEASE_LABEL[release]}. Fasting-subsample status within domain A. Estimates that do not meet the NCHS "
           "presentation standards are marked in the table (missingness_by_group.csv).")
    out = paths.FIGURES / "fig4_fasting_status_by_group.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def fig_sensitivity(release: str) -> str:
    e = _load(release, "estimates.csv").set_index("config_id")
    rows = [
        ("S1 fasting rule", "HbA1c, paired domain P", "K1", BLUE),
        ("S1 fasting rule", "HbA1c, narrow fasting domain", "K1_S1", BLUE),
        ("S1 fasting rule", "Glucose, paired domain P", "K2", ORANGE),
        ("S1 fasting rule", "Glucose, narrow fasting domain", "K2_S1", ORANGE),
        ("S2 sample", "HbA1c, laboratory domain H", "K3", BLUE),
        ("S2 sample", "Glucose, fasting domain F", "K4", ORANGE),
        ("S3 diagnosis", "Diagnosed (self-report)", "K5", AQUA),
        ("S3 diagnosis", "HbA1c or glucose high (biochemical only)", "K8", AQUA),
        ("S3 diagnosis", "Diagnosed, HbA1c high, or glucose high", "K6", AQUA),
    ]
    fig, ax = plt.subplots(figsize=(9.2, 4.0))
    fig.subplots_adjust(left=0.36, right=0.95, top=0.96, bottom=0.12)
    y = np.arange(len(rows))[::-1].astype(float)
    for yy, (grp, lab, cid, col) in zip(y, rows):
        r = e.loc[cid]
        _dot_ci(ax, yy, r.estimate, r.ci_low, r.ci_high, col)
        ax.text(r.ci_high + 0.002, yy, f"{_pct(r.estimate)}  (n = {int(r.n_unweighted):,})", va="center", fontsize=8.4, color=INK)
    ax.set_yticks(y, [f"{g}: {lab}" for g, lab, _, _ in rows], fontsize=8.8, color=INK)
    _grid_x(ax)
    ax.set_xlim(0.06, 0.21)
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:.0f}%"))
    ax.set_xlabel("Weighted prevalence (95% Korn-Graubard intervals)")
    _title(fig, "The three prespecified sensitivity checks",
           f"{RELEASE_LABEL[release]}. Blue: HbA1c ≥ 6.5%. Orange: fasting glucose ≥ 126 mg/dL. Aqua: definitions that use self-reported diagnosis.")
    out = paths.FIGURES / "fig5_sensitivity_checks.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def fig_groups(release: str) -> str:
    p = _load(release, "paired_by_group.csv")
    order = ["20-44", "45-64", "65+", "Female", "Male", "Mexican American", "Other Hispanic", "Non-Hispanic White",
             "Non-Hispanic Black", "Non-Hispanic Asian", "Other or multiracial"]
    p = p.set_index("group").loc[order].reset_index()
    fig, ax = plt.subplots(figsize=(8.6, 4.2))
    fig.subplots_adjust(left=0.27, right=0.95, top=0.96, bottom=0.12)
    y = np.arange(len(p))[::-1]
    for yy, (_, r) in zip(y, p.iterrows()):
        flagged = isinstance(r.difference_note, str) and r.difference_note != ""
        _dot_ci(ax, yy, r.difference, r.difference_ci_low, r.difference_ci_high, NEUTRAL, hollow=flagged)
        ax.text(r.difference_ci_high + 0.002, yy, f"{_pp(r.difference)} pts (n = {int(r.n_unweighted):,})" + (" \u2020" if flagged else ""),
                va="center", fontsize=8.3, color=INK)
    ax.axvline(0, color=INK2, linewidth=1)
    ax.set_yticks(y, p.group, fontsize=9, color=INK)
    _grid_x(ax)
    ax.set_xlim(-0.09, 0.1)
    ax.set_xticks(np.arange(-0.08, 0.081, 0.02))
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f"{100 * v:+.0f}".replace("-", "−").replace("+0", "0")))
    ax.set_xlabel("HbA1c minus glucose prevalence, percentage points (95% intervals)")
    _title(fig, "Paired difference by age, sex, and race and Hispanic origin",
           f"{RELEASE_LABEL[release]}, domain P. Hollow markers and * : one component estimate is suppressed under the NCHS standards.\n"
           "Race and Hispanic origin is a self-reported social classification; differences are not evidence of a biological mechanism.")
    out = paths.FIGURES / "figS1_paired_difference_by_group.png"
    fig.savefig(out, dpi=DPI)
    plt.close(fig)
    return paths.rel(out)


def make_figures(releases: list[str]) -> list[str]:
    paths.FIGURES.mkdir(parents=True, exist_ok=True)
    primary = releases[0]
    return [fig_paired(releases), fig_sample(releases), fig_overlap(primary), fig_missingness(primary),
            fig_sensitivity(primary), fig_groups(primary)]
