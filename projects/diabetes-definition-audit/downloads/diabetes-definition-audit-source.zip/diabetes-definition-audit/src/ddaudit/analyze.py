"""Analyze stage: configuration checks, R survey estimation, direct cross-tabs."""

from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess

import pandas as pd
import yaml

from . import paths
from .checker import check_all, load_configs
from .direct import direct_contrast, direct_estimate, table_checks, weighted_crosstab


def rscript() -> str:
    exe = os.environ.get("RSCRIPT") or shutil.which("Rscript")
    if not exe:
        raise RuntimeError("Rscript not found; install R 4.5 and run `make setup`")
    return exe


def run_r(release: str) -> None:
    infile = paths.DATA_INTERIM / release / "analytic_for_r.csv"
    outdir = paths.TABLES / release
    log = paths.LOGS / f"estimate_{release}.log"
    bc = paths.VALIDATION / release / "build_checks.json"
    fixture = bc.exists() and json.loads(bc.read_text()).get("synthetic_fixture", False)
    # Run from the code root so .Rprofile activates the renv library.
    cmd = [rscript(), str(paths.RDIR / "estimate.R"), release, str(infile), str(outdir), str(paths.CONFIG)]
    if fixture:
        cmd.append("fixture")
    with open(log, "w") as fh:
        res = subprocess.run(cmd, cwd=paths.CODE_ROOT, stdout=fh, stderr=subprocess.STDOUT)
    if res.returncode != 0:
        raise RuntimeError(f"R estimation failed for {release}; see {paths.rel(log)}")


def direct_checks(release: str) -> dict:
    df = pd.read_parquet(paths.DATA_INTERIM / release / "analytic.parquet")
    cfg = load_configs()
    est = pd.read_csv(paths.TABLES / release / "estimates.csv")
    con = pd.read_csv(paths.TABLES / release / "contrasts.csv")
    idx = {c["id"]: c for c in cfg["configurations"] + cfg.get("auxiliary", [])}
    for s in cfg.get("sensitivity_variants", []):
        idx[s["id"]] = {**idx[s["base"]], "domain": s["domain"], "id": s["id"]}
    rows = []
    for _, r in est.iterrows():
        c = idx[r.config_id]
        d = direct_estimate(df, c["phenotype"], c["domain"], c["weight_role"])
        rows.append({"release": release, "item": r.config_id, "kind": "estimate",
                     "phenotype": c["phenotype"], "sample_universe": r.sample_universe, "weight": r.weight,
                     "r_estimate": r.estimate, "direct_estimate": d["estimate_direct"],
                     "abs_diff_estimate": abs(r.estimate - d["estimate_direct"]),
                     "r_se": r.se, "python_se": d["se_python_linearized"],
                     "rel_diff_se": abs(r.se - d["se_python_linearized"]) / r.se,
                     "r_n": r.n_unweighted, "direct_n": d["n_unweighted"],
                     "r_n_positive": r.n_positive_unweighted, "direct_n_positive": d["n_positive_unweighted"],
                     "weighted_numerator": d["weighted_numerator"], "weighted_denominator": d["weighted_denominator"]})
    for _, k in con.iterrows():
        L, R = idx[k.left], idx[k.right]
        d = direct_contrast(df, (L["phenotype"], L["domain"], L["weight_role"]), (R["phenotype"], R["domain"], R["weight_role"]))
        rows.append({"release": release, "item": k.contrast_id, "kind": "contrast",
                     "phenotype": f"{L['phenotype']} vs {R['phenotype']}",
                     "sample_universe": f"{L['domain']} vs {R['domain']}", "weight": f"{k.left_weight} vs {k.right_weight}",
                     "r_estimate": k.estimate, "direct_estimate": d["estimate_direct"],
                     "abs_diff_estimate": abs(k.estimate - d["estimate_direct"]),
                     "r_se": k.se, "python_se": d["se_python_linearized"],
                     "rel_diff_se": abs(k.se - d["se_python_linearized"]) / k.se})
    out = pd.DataFrame(rows)
    out.to_csv(paths.VALIDATION / release / "direct_vs_survey.csv", index=False)

    tab = weighted_crosstab(df, "P", "fasting", "a1c65", "fpg126")
    agr = pd.read_csv(paths.TABLES / release / "agreement.csv").set_index("measure")
    cell_cmp = []
    for (a, g), name in {(1, 1): "cell c11", (1, 0): "cell c10", (0, 1): "cell c01", (0, 0): "cell c00"}.items():
        cell_cmp.append({"cell": name, "direct_crosstab": float(tab.loc[a, g]), "r_estimate": float(agr.loc[name, "estimate"]),
                         "abs_diff": abs(float(tab.loc[a, g]) - float(agr.loc[name, "estimate"]))})
    pd.DataFrame(cell_cmp).to_csv(paths.VALIDATION / release / "crosstab_vs_survey.csv", index=False)
    extra = {}
    if (paths.TABLES / release / "missingness_by_group.csv").exists():  # absent for the synthetic fixture
        tc = table_checks(df, paths.TABLES / release)
        tc.insert(0, "release", release)
        tc.to_csv(paths.VALIDATION / release / "tables_vs_survey.csv", index=False)
        extra = {"table_checks": int(len(tc)),
                 "table_checks_max_abs_diff_estimate": float(tc.abs_diff_estimate.max()),
                 "table_checks_max_rel_diff_se": float(tc.rel_diff_se.max())}
    return {
        **extra,
        "max_abs_diff_estimate": float(out.abs_diff_estimate.max()),
        "max_rel_diff_se": float(out.rel_diff_se.max()),
        "max_abs_diff_crosstab_cells": max(c["abs_diff"] for c in cell_cmp),
        "n_items": int(len(out)),
    }


def _utc() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def analyze() -> dict:
    sources = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    started = dt.datetime.now(dt.timezone.utc)
    man = paths.RESULTS / "run_manifest.json"
    from .render import code_tree_sha256
    run = {"run_id": started.strftime("%Y%m%dT%H%M%SZ"), "analysis_started_utc": _utc(),
           "analysis_code_tree_sha256": code_tree_sha256()}
    out = {}
    for release in sources["releases"]:
        if not (paths.DATA_INTERIM / release / "analytic_for_r.csv").exists():
            out[release] = {"status": "not built"}
            continue
        chk = check_all(release)
        (paths.TABLES / release).mkdir(parents=True, exist_ok=True)
        (paths.VALIDATION / release).mkdir(parents=True, exist_ok=True)
        (paths.TABLES / release / "config_check.json").write_text(json.dumps(chk, indent=2) + "\n")
        if not (chk["all_configurations_ok"] and chk["all_contrasts_ok"] and chk["all_examples_refused"]):
            raise RuntimeError(f"configuration check failed for {release}; see config_check.json")
        run_r(release)
        out[release] = {"config_check": "passed", "direct_checks": direct_checks(release)}
    run["analysis_finished_utc"] = _utc()
    man.parent.mkdir(parents=True, exist_ok=True)
    man.write_text(json.dumps(run, indent=2) + "\n")
    out["run_id"] = run["run_id"]
    return out
