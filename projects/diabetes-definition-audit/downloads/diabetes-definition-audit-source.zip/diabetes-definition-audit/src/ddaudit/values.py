"""Collect every reported number from the result tables into one flat dictionary.

Documents (manuscript, report, project page) are filled from this dictionary
through `fill()`, which fails on any unknown placeholder, so no number in the
text is typed by hand.
"""

from __future__ import annotations

import json
import re

import pandas as pd
import yaml

from . import paths

MINUS = "−"
REL_PREFIX = {"2021-2023": "r21", "2017-2020": "r17"}


def pct(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}%"


def num(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}"


def signed(x: float, d: int = 2) -> str:
    v = round(100 * x, d)
    if v == 0:
        return f"{0:.{d}f}"
    return (f"{v:+.{d}f}").replace("-", MINUS)


def ci_pct(lo: float, hi: float, d: int = 1) -> str:
    return f"{100 * lo:.{d}f} to {100 * hi:.{d}f}"


def ci_signed(lo: float, hi: float, d: int = 2) -> str:
    return f"{signed(lo, d)} to {signed(hi, d)}"


def pval(p: float) -> str:
    if p < 0.001:
        return "p < 0.001"
    return f"p = {p:.2f}" if p >= 0.01 else f"p = {p:.3f}"


def intc(n) -> str:
    return f"{int(n):,}"


def slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def collect() -> dict[str, str]:
    v: dict[str, str] = {}
    sources = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    for release in sources["releases"]:
        t = paths.TABLES / release
        if not (t / "estimates.csv").exists():
            continue
        r = REL_PREFIX[release]
        v[f"{r}_label"] = sources["releases"][release]["label"]
        flow = pd.read_csv(t / "participant_flow.csv").set_index("step")
        for step, row in flow.iterrows():
            v[f"{r}_flow{step}_n"] = intc(row.n)
            if not pd.isna(row.n_removed):
                v[f"{r}_flow{step}_removed"] = intc(row.n_removed)
        v[f"{r}_n_demo"] = intc(flow.loc[1, "n"])
        v[f"{r}_n_examined"] = intc(flow.loc[2, "n"])
        v[f"{r}_n_adults20"] = intc(flow.loc[3, "n"])
        v[f"{r}_n_A"] = intc(flow.loc[6, "n"])
        v[f"{r}_n_H"] = intc(flow.loc[8, "n"])
        v[f"{r}_n_F"] = intc(flow.loc[12, "n"])
        v[f"{r}_n_P"] = intc(flow.loc[13, "n"])
        v[f"{r}_n_Pn"] = intc(flow.loc[14, "n"])
        nA, nH = int(flow.loc[6, "n"]), int(flow.loc[8, "n"])
        v[f"{r}_n_A_without_a1c"] = intc(nA - nH)
        v[f"{r}_pct_A_without_a1c"] = f"{100 * (nA - nH) / nA:.1f}%"
        st = pd.read_csv(t / "status_counts.csv")
        for _, s in st.iterrows():
            v[f"{r}_status_{slug(s.scope)}_{s.variable}_{s.status}"] = intc(s.n)
        e = pd.read_csv(t / "estimates.csv")
        for _, x in e.iterrows():
            k = f"{r}_{x.config_id}"
            v[f"{k}_pct"] = pct(x.estimate)
            v[f"{k}_ci"] = ci_pct(x.ci_low, x.ci_high)
            v[f"{k}_n"] = intc(x.n_unweighted)
            v[f"{k}_npos"] = intc(x.n_positive_unweighted)
            v[f"{k}_weight"] = x.weight
            v[f"{k}_domain"] = x.domain
            v[f"{k}_status"] = x.nchs_status
            v[f"{k}_deff"] = f"{x.design_effect:.2f}"
            v[f"{k}_logit_ci"] = ci_pct(x.ci_low_logit, x.ci_high_logit)
            v[f"{k}_se"] = f"{100 * x.se:.2f}"
        c = pd.read_csv(t / "contrasts.csv")
        for _, x in c.iterrows():
            k = f"{r}_{x.contrast_id}"
            v[f"{k}_pp"] = signed(x.estimate)
            v[f"{k}_pp1"] = signed(x.estimate, 1)
            v[f"{k}_abs1"] = f"{abs(100 * x.estimate):.1f}"
            v[f"{k}_ci"] = ci_signed(x.ci_low, x.ci_high)
            v[f"{k}_p"] = pval(x.p_value)
            v[f"{k}_se"] = f"{100 * x.se:.2f}"
            v[f"{k}_df"] = str(int(x.df))
        a = pd.read_csv(t / "agreement.csv")
        for _, x in a.iterrows():
            k = f"{r}_agr_{slug(x.measure)}"
            if x.measure == "cohens_kappa":
                v[f"{k}"] = f"{x.estimate:.2f}"
                v[f"{k}_ci"] = f"{x.ci_low:.2f} to {x.ci_high:.2f}"
            else:
                v[f"{k}"] = pct(x.estimate)
                v[f"{k}_ci"] = ci_pct(x.ci_low, x.ci_high)
            if not pd.isna(x.n_positive_unweighted):
                v[f"{k}_npos"] = intc(x.n_positive_unweighted)
        both = a.set_index("measure").loc["share_of_either_positive_both"]
        v[f"{r}_agr_share_only_one"] = pct(1 - both.estimate, 0)
        v[f"{r}_agr_share_only_one_ci"] = ci_pct(1 - both.ci_high, 1 - both.ci_low, 0)
        ov = pd.read_csv(t / "overlap.csv")
        for _, x in ov.iterrows():
            v[f"{r}_{x.cell}"] = pct(x.estimate)
            v[f"{r}_{x.cell}_ci"] = ci_pct(x.ci_low, x.ci_high)
            v[f"{r}_{x.cell}_npos"] = intc(x.n_positive_unweighted)
        s3 = pd.read_csv(t / "s3_diagnosed_below_threshold.csv")
        for _, x in s3.iterrows():
            k = f"{r}_s3_{slug(x.group)}"
            v[k] = pct(x.estimate)
            v[f"{k}_ci"] = ci_pct(x.ci_low, x.ci_high)
            v[f"{k}_n"] = intc(x.n_unweighted)
            v[f"{k}_npos"] = intc(x.n_positive_unweighted)
            v[f"{k}_status"] = x.nchs_status
        m = pd.read_csv(t / "missingness_by_group.csv")
        for _, x in m.iterrows():
            k = f"{r}_miss_{slug(x.group)}_{x.status}"
            v[k] = pct(x.estimate)
            v[f"{k}_ci"] = ci_pct(x.ci_low, x.ci_high)
            v[f"{k}_status"] = x.nchs_status
        pg = pd.read_csv(t / "paired_by_group.csv")
        for _, x in pg.iterrows():
            k = f"{r}_grp_{slug(x.group)}"
            v[f"{k}_n"] = intc(x.n_unweighted)
            v[f"{k}_hba1c"] = pct(x.hba1c_estimate)
            v[f"{k}_glucose"] = pct(x.glucose_estimate)
            v[f"{k}_diff"] = signed(x.difference, 1)
            v[f"{k}_diff_ci"] = ci_signed(x.difference_ci_low, x.difference_ci_high, 1)
            v[f"{k}_hba1c_status"] = x.hba1c_nchs_status
            v[f"{k}_glucose_status"] = x.glucose_nchs_status
            v[f"{k}_df"] = str(int(x.df_domain))
        comp_sup = (pg.hba1c_nchs_status == "suppressed") | (pg.glucose_nchs_status == "suppressed")
        v[f"{r}_grp_n_suppressed_components"] = str(int((pg.hba1c_nchs_status == "suppressed").sum() + (pg.glucose_nchs_status == "suppressed").sum()))
        v[f"{r}_grp_suppressed_groups"] = " and ".join(sorted(pg.loc[comp_sup, "group"]))
        agesex = pg[pg.group_variable.isin(["age_group", "sex_label"])]
        v[f"{r}_grp_agesex_min"] = signed(agesex.difference.min(), 1)
        v[f"{r}_grp_agesex_max"] = signed(agesex.difference.max(), 1)
        v[f"{r}_grp_agesex_ci_lowest"] = signed(agesex.difference_ci_low.min(), 1)
        v[f"{r}_grp_agesex_ci_highest"] = signed(agesex.difference_ci_high.max(), 1)
        phf = t / "posthoc.csv"
        if phf.exists():
            for _, x in pd.read_csv(phf).iterrows():
                k = f"{r}_{x.analysis.lower()}"
                v[f"{k}_n"] = intc(x.n_unweighted)
                if x.analysis == "PH3_kappa":
                    v[k] = f"{x.estimate:.2f}"
                    v[f"{k}_ci"] = f"{x.ci_low:.2f} to {x.ci_high:.2f}"
                elif x.analysis.startswith("PH3"):
                    v[k] = pct(x.estimate, 0)
                    v[f"{k}_ci"] = ci_pct(x.ci_low, x.ci_high, 0)
                else:
                    v[f"{k}_pp"] = signed(x.estimate)
                    v[f"{k}_ci"] = ci_signed(x.ci_low, x.ci_high)
                    v[f"{k}_p"] = pval(x.p_value)
                    v[f"{k}_left"] = pct(x.left_estimate)
                    v[f"{k}_right"] = pct(x.right_estimate)
            ph = pd.read_csv(phf).set_index("analysis")
            k1 = pd.read_csv(t / "estimates.csv").set_index("config_id").loc["K1", "estimate"]
            c1 = c.set_index("contrast_id").loc["C1", "estimate"]
            # Shares of adults in P with HbA1c of exactly 6.4% and 6.5%, from the cut-point estimates.
            v[f"{r}_a1c_at_64"] = pct(ph.loc["PH4", "left_estimate"] - k1)
            v[f"{r}_a1c_at_65"] = pct(k1 - ph.loc["PH5", "left_estimate"])
            shifts = [abs(ph.loc["PH4", "estimate"] - c1), abs(ph.loc["PH5", "estimate"] - c1)]
            v[f"{r}_cut_shift_min"] = f"{100 * min(shifts):.1f}"
            v[f"{r}_cut_shift_max"] = f"{100 * max(shifts):.1f}"
        dc = json.loads((t / "design_checks.json").read_text())
        v[f"{r}_n_strata"] = str(dc["n_strata"])
        v[f"{r}_n_psu"] = str(dc["n_psu"])
        v[f"{r}_df"] = str(dc["df_full_design"])
        v[f"{r}_k1k2_corr"] = f"{dc['k1_k2_sampling_correlation']:.2f}"
        v[f"{r}_c1_se_paired"] = f"{100 * dc['c1_se_paired']:.2f}"
        v[f"{r}_c1_se_ignoring_cov"] = f"{100 * dc['c1_se_if_covariance_ignored_illustration_only']:.2f}"
        v[f"{r}_se_ratio"] = f"{dc['c1_se_if_covariance_ignored_illustration_only'] / dc['c1_se_paired']:.1f}"
        v["survey_version"] = dc["survey_version"]
        v["r_version"] = dc["r_version"].replace("R version ", "")
        bc = json.loads((paths.VALIDATION / release / "build_checks.json").read_text())
        v[f"{r}_codebook_rows"] = str(bc["codebook_reconciliation"]["rows_checked"])
        v[f"{r}_zero_fast_weight_glucose"] = intc(bc["zero_fasting_weight_with_glucose"])
        w = bc["zero_fasting_weight_with_glucose_window"]
        v[f"{r}_zero_fast_lt8"], v[f"{r}_zero_fast_ge24"], v[f"{r}_zero_fast_unknown"] = intc(w[0]), intc(w[1]), intc(w[2])
        cc = json.loads((t / "config_check.json").read_text())
        v[f"{r}_n_refusal_examples"] = str(len(cc["refused_examples"]))
        rr = t / "reference_reconciliation.csv"
        if rr.exists():
            rec = pd.read_csv(rr)
            pr = rec.dropna(subset=["published_percent"])
            v[f"{r}_recon_rows"] = str(len(pr)) if len(pr) else "0"
            v[f"{r}_recon_n_match"] = str(int(rec.n_match.sum()))
            v[f"{r}_recon_n_rows_all"] = str(len(rec))
            ux = rec[(rec.measure == "undiagnosed") & (rec.group == "all")]
            if len(ux):
                v[f"{r}_undx_pct"] = f"{ux.iloc[0].our_percent:.1f}%"
                v[f"{r}_undx_ci"] = f"{ux.iloc[0].our_ci_low:.1f} to {ux.iloc[0].our_ci_high:.1f}"
            if len(pr):
                v[f"{r}_recon_pct_match"] = str(int(pr.percent_match.astype(bool).sum()))
                v[f"{r}_recon_se_match"] = str(int(pr.se_match.astype(bool).sum()))
                v[f"{r}_recon_ci_match"] = str(int(pr.ci_match.astype(bool).sum()))
                v[f"{r}_recon_ci_match_uncapped"] = str(int(pr.ci_match_without_neff_cap.astype(bool).sum()))
                miss = pr[~pr.ci_match.astype(bool)]
                if len(miss):
                    x = miss.iloc[0]
                    v[f"{r}_recon_ci_miss_desc"] = f"{x.measure} diabetes at ages {x.group}"
                    v[f"{r}_recon_ci_miss_pub"] = f"{x.published_ci_low:.1f} to {x.published_ci_high:.1f}"
                    v[f"{r}_recon_ci_miss_ours"] = f"{x.our_ci_low:.1f} to {x.our_ci_high:.1f}"
                    v[f"{r}_recon_ci_miss_uncapped"] = f"{x.our_ci_low_without_neff_cap:.1f} to {x.our_ci_high_without_neff_cap:.1f}"
        # Narrow fasting exclusions by item (domain P), from the saved results table.
        nf = pd.read_csv(t / "narrow_fail_counts.csv").set_index("item")
        for key, item in (("coffee", "coffee or tea with cream or sugar"), ("alcohol", "alcohol"),
                          ("gum", "gum, mints, lozenges, cough drops, cold remedies"),
                          ("antacid", "antacids, laxatives, anti-diarrheals"), ("supplement", "dietary supplements"),
                          ("any", "any item (excluded from P-narrow)"), ("unknown", "unknown answer or time")):
            v[f"{r}_narrow_fail_{key}"] = intc(nf.loc[item, "n_failing"])
    vs = json.loads((paths.VALIDATION / "validation_summary.json").read_text())
    v["val_checks"] = str(vs["checks"])
    v["val_passed"] = str(vs["passed"])
    v["val_failed"] = str(vs["failed"])
    for k, n in vs["kinds"].items():
        v[f"val_kind_{slug(k)}"] = str(n)
    ref = yaml.safe_load((paths.CONFIG / "reference_aggregates.yaml").read_text())
    db = {(r["measure"], r["group"]): r for r in ref["nchs_db516"]["rows"]}
    v["nchs_total"] = f"{db[('total', 'all')]['percent']:.1f}%"
    v["nchs_dx"] = f"{db[('diagnosed', 'all')]['percent']:.1f}%"
    v["nchs_undx"] = f"{db[('undiagnosed', 'all')]['percent']:.1f}%"
    nd = ref["cdc_ndsr_2026"]
    v["ndsr_total"] = f"{nd['total_crude_percent']['percent']:.1f}%"
    v["ndsr_total_ci"] = f"{nd['total_crude_percent']['ci_low']:.1f} to {nd['total_crude_percent']['ci_high']:.1f}"
    v["ndsr_undx"] = f"{nd['undiagnosed_crude_percent']['percent']:.1f}%"
    v.update(table_blocks())
    plan = (paths.DOCS / "analysis_plan.md").read_text()
    v["plan_amendments"] = plan.split("## Amendments", 1)[1].strip().replace("results/tables/<release>/posthoc.csv", "`results/tables/<release>/posthoc.csv`")
    man = paths.RESULTS / "run_manifest.json"
    if man.exists():
        rm = json.loads(man.read_text())
        v["run_id"] = rm["run_id"]
        for k, val in rm["versions"].items():
            v[f"ver_{slug(k)}"] = str(val)
    return v


PLACEHOLDER = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


def fill(template: str, values: dict[str, str]) -> str:
    missing = sorted({m for m in PLACEHOLDER.findall(template) if m not in values})
    if missing:
        raise KeyError(f"unknown placeholders: {missing[:20]}")
    return PLACEHOLDER.sub(lambda m: values[m.group(1)], template)


# ------------------------------------------------------------ table blocks
ROLE_SHORT = {
    "primary paired contrast": "primary",
    "secondary contrast, broader HbA1c domain": "secondary",
    "sensitivity 2, single-biomarker glucose domain": "sensitivity 2",
    "composite component": "composite part",
    "surveillance composite": "composite",
    "composite without fasting glucose": "composite, no glucose",
    "sensitivity 3, biochemical only": "sensitivity 3",
    "needed for the composite decomposition only": "auxiliary",
    "sensitivity 1, narrow fasting rule": "sensitivity 1",
}
DOMAIN_SHORT = {"P": "P (paired)", "H": "H (HbA1c laboratory)", "F": "F (fasting glucose)", "P_NARROW": "P-narrow"}


def md_table(header: list[str], rows: list[list[str]], align: list[str] | None = None) -> str:
    align = align or ["l"] * len(header)
    sep = ["---:" if a == "r" else "---" for a in align]
    out = ["| " + " | ".join(header) + " |", "| " + " | ".join(sep) + " |"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


def table_blocks() -> dict[str, str]:
    b: dict[str, str] = {}
    rels = [r for r in ("2021-2023", "2017-2020") if (paths.TABLES / r / "estimates.csv").exists()]
    rows = []
    for rel in rels:
        e = pd.read_csv(paths.TABLES / rel / "estimates.csv")
        for _, x in e.iterrows():
            rows.append([rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023"), x.config_id,
                         x.phenotype, DOMAIN_SHORT.get(x.domain, x.domain), x.weight, intc(x.n_unweighted),
                         intc(x.n_positive_unweighted), f"{100 * x.estimate:.1f} ({ci_pct(x.ci_low, x.ci_high)})",
                         ROLE_SHORT.get(x.role, x.role), x.nchs_status])
    b["table_estimates"] = md_table(
        ["Release", "ID", "Phenotype", "Sample universe", "Weight", "Denominator n", "Positive n", "Percent (95% CI)", "Role", "NCHS standard"],
        rows, ["l", "l", "l", "l", "l", "r", "r", "r", "l", "l"])
    rows = []
    keep = ["C1", "C2", "C3", "C4", "C5", "C6", "C7", "C8", "C9", "C10", "C11", "C12"]
    for rel in rels:
        c = pd.read_csv(paths.TABLES / rel / "contrasts.csv").set_index("contrast_id")
        for k in keep:
            x = c.loc[k]
            dom = lambda d: d.replace("P_NARROW", "P-narrow")  # noqa: E731
            rows.append([rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023"), k, x.label,
                         f"{x.left}: {x.left_phenotype}; {dom(x.left_universe)}, {x.left_weight}; n = {intc(x.left_n)}",
                         f"{x.right}: {x.right_phenotype}; {dom(x.right_universe)}, {x.right_weight}; n = {intc(x.right_n)}",
                         f"{signed(x.estimate)} ({ci_signed(x.ci_low, x.ci_high)})", pval(x.p_value).replace("p ", "").replace("= ", "")])
    b["table_contrasts"] = md_table(["Release", "ID", "Contrast", "Left: phenotype; domain, weight; denominator",
                                     "Right: phenotype; domain, weight; denominator",
                                     "Difference, percentage points (95% CI)", "p"], rows, ["l", "l", "l", "l", "l", "r", "r"])
    rows = []
    for rel in rels:
        a = pd.read_csv(paths.TABLES / rel / "agreement.csv").set_index("measure")
        n = intc(a.loc["cell c11", "n_unweighted"])
        lab = rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023")
        for meas, desc in (("cell c11", "HbA1c \u2265 6.5% and glucose \u2265 126 mg/dL"), ("cell c10", "HbA1c \u2265 6.5% only"),
                           ("cell c01", "Glucose \u2265 126 mg/dL only"), ("cell c00", "Both below threshold")):
            x = a.loc[meas]
            rows.append([lab, desc, intc(x.n_positive_unweighted), f"{100 * x.estimate:.1f} ({ci_pct(x.ci_low, x.ci_high)})"])
        x = a.loc["percent_agreement"]
        rows.append([lab, "Percent agreement", "", f"{100 * x.estimate:.1f} ({ci_pct(x.ci_low, x.ci_high)})"])
        x = a.loc["cohens_kappa"]
        rows.append([lab, "Cohen's kappa", "", f"{x.estimate:.2f} ({x.ci_low:.2f} to {x.ci_high:.2f})"])
        for meas, desc in (("share_of_either_positive_hba1c_only", "Share of either-positive adults positive on HbA1c only"),
                           ("share_of_either_positive_glucose_only", "Share of either-positive adults positive on glucose only")):
            x = a.loc[meas]
            rows.append([lab, desc, "", f"{100 * x.estimate:.1f} ({ci_pct(x.ci_low, x.ci_high)})"])
        rows.append([lab, f"Sample universe: domain P, weight {a.loc['cell c11', 'weight']}, denominator n = {n}", "", ""])
    b["table_agreement"] = md_table(["Release", "Measure", "Positive n", "Percent or kappa (95% CI)"], rows, ["l", "l", "r", "r"])
    rows = []
    for rel in rels:
        f = pd.read_csv(paths.TABLES / rel / "participant_flow.csv")
        lab = rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023")
        for _, x in f.iterrows():
            rows.append([lab, int(x.step), x.branch, x.description, intc(x.n), "" if pd.isna(x.n_removed) else intc(x.n_removed),
                         x.weight_used])
    b["table_flow"] = md_table(["Release", "Step", "Branch", "Description", "Remaining n (unweighted)", "Removed n",
                                "Weight carried at this step"], rows, ["l", "r", "l", "l", "r", "r", "l"])
    rr = paths.TABLES / "2021-2023" / "reference_reconciliation.csv"
    if rr.exists():
        r = pd.read_csv(rr)
        rows = [[x.table, x.measure, x.group, f"{x.published_n:,} / {x.our_n:,}",
                 f"{x.published_percent:.1f} / {x.our_percent:.2f}",
                 f"{x.published_ci_low:.1f} to {x.published_ci_high:.1f} / {x.our_ci_low:.2f} to {x.our_ci_high:.2f}",
                 f"{x.published_se:.1f} / {x.our_se:.2f}", "yes" if x.ci_match else "no (yes without the cap)"] for _, x in r.iterrows()]
        b["table_recon"] = md_table(["NCHS table", "Measure", "Group", "n, published / study", "Percent, published / study",
                                     "95% CI, published / study", "SE, published / study", "CI matches"], rows,
                                    ["l", "l", "l", "r", "r", "r", "r", "l"])
    rows = []
    g = pd.read_csv(paths.TABLES / "2021-2023" / "paired_by_group.csv")
    for _, x in g.iterrows():
        sup_a, sup_g = x.hba1c_nchs_status == "suppressed", x.glucose_nchs_status == "suppressed"
        rows.append([x.group, intc(x.n_unweighted),
                     "suppressed" if sup_a else f"{100 * x.hba1c_estimate:.1f} ({ci_pct(x.hba1c_ci_low, x.hba1c_ci_high)})",
                     "suppressed" if sup_g else f"{100 * x.glucose_estimate:.1f} ({ci_pct(x.glucose_ci_low, x.glucose_ci_high)})",
                     f"{signed(x.difference, 1)} ({ci_signed(x.difference_ci_low, x.difference_ci_high, 1)})" +
                     (" \u2020" if (sup_a or sup_g) else ""), int(x.df_domain)])
    b["table_groups"] = md_table(["Group (domain P, WTSAF2YR)", "Denominator n", "HbA1c \u2265 6.5%, % (95% CI)",
                                  "Glucose \u2265 126 mg/dL, % (95% CI)", "Difference, points (95% CI)", "df"], rows,
                                 ["l", "r", "r", "r", "r", "r"])
    m = pd.read_csv(paths.TABLES / "2021-2023" / "missingness_by_group.csv")
    piv = m.pivot_table(index=["group_variable", "group"], columns="status", values="estimate", sort=False)
    nn = m.drop_duplicates(["group_variable", "group"]).set_index(["group_variable", "group"]).n_unweighted
    sup = m[m.nchs_status == "suppressed"].set_index(["group_variable", "group", "status"]).index
    flg = m[m.nchs_status == "flagged"].set_index(["group_variable", "group", "status"]).index
    rows = []
    for idx, x in piv.iterrows():
        def cell(st):
            if (idx[0], idx[1], st) in sup:
                return "suppressed"
            return f"{100 * x[st]:.1f}" + (" \u2021" if (idx[0], idx[1], st) in flg else "")
        rows.append([idx[1], intc(nn.loc[idx]), cell("fs_valid"), cell("fs_not_assigned"), cell("fs_no_blood"),
                     cell("fs_criterion"), cell("miss_a1c")])
    b["table_missing"] = md_table(["Group (domain A, WTMEC2YR)", "Denominator n", "Valid fasting glucose %", "Not assigned %",
                                   "Assigned, no blood %", "Fast outside window %", "No HbA1c %"], rows,
                                  ["l", "r", "r", "r", "r", "r", "r"])
    b["missing_flag_note"] = ("\u2021 Flagged for review under the NCHS standards (shown)." if len(flg) else "")
    rows = []
    for rel in rels:
        phf = paths.TABLES / rel / "posthoc.csv"
        if not phf.exists():
            continue
        lab = rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023")
        for _, x in pd.read_csv(phf).iterrows():
            comp = "" if pd.isna(x.left_estimate) else f"{100 * x.left_estimate:.1f} / {100 * x.right_estimate:.1f}"
            if x.analysis == "PH3_kappa":
                val = f"{x.estimate:.2f} ({x.ci_low:.2f} to {x.ci_high:.2f})"
            elif x.analysis.startswith("PH3"):
                val = f"{100 * x.estimate:.1f}% ({ci_pct(x.ci_low, x.ci_high)})"
            else:
                val = f"{signed(x.estimate)} ({ci_signed(x.ci_low, x.ci_high)})"
            rows.append([lab, x.analysis.replace("_", " "), x.label.replace(">=", "\u2265"), intc(x.n_unweighted), comp, val])
    b["table_posthoc"] = md_table(["Release", "ID", "Quantity", "Denominator n", "Left / right, %", "Estimate (95% CI)"], rows,
                                  ["l", "l", "l", "r", "r", "r"])
    rows = []
    for rel in rels:
        cc = json.loads((paths.TABLES / rel / "config_check.json").read_text())
        lab = rel.replace("2017-2020", "2017-Mar 2020").replace("2021-2023", "Aug 2021-Aug 2023")
        for ex in cc["refused_examples"]:
            req = ex["request"]
            what = req.get("contrast") or f"{req.get('phenotype')} in domain {req.get('domain')} with {req.get('weight')}" + \
                (" (imputed glucose)" if req.get("imputed_glucose") else "") + (" (pooled releases)" if req.get("pooled_releases") else "")
            rows.append([lab, what, "refused" if not ex["ok"] else "accepted", " ".join(ex["reasons"])])
    b["table_refusals"] = md_table(["Release", "Request", "Checker result", "Reason given"], rows)
    vs = pd.read_csv(paths.VALIDATION / "validation_summary.csv")
    rows = [[x.release, x.kind, x.check, x.status, x.detail] for _, x in vs.iterrows()]
    b["table_validation"] = md_table(["Release", "Kind", "Check", "Result", "Detail"], rows)
    return b


# ----------------------------------------------------------- figure legends
def figure_specs(v: dict[str, str]) -> list[tuple[str, str, str]]:
    """(file, title of 15 words or fewer, legend) in manuscript order of first citation."""
    return [
        ("fig4_fasting_status_by_group.png",
         "Fasting subsample status of adults by age, sex, and race and Hispanic origin",
         f"Domain A, August 2021 to August 2023 (n = {v['r21_n_A']}), weighted with the examination weight WTMEC2YR. "
         "Each bar splits adults into a valid fasting glucose, not assigned to the fasting subsample, assigned without a blood "
         "specimen, and assigned with a fast outside 8 to less than 24 hours. Hatched segments are suppressed under the NCHS "
         "presentation standards and are not interpreted. Cell estimates are in Additional file 1, Table S4."),
        ("fig1_paired_common_denominator.png",
         "HbA1c and fasting glucose threshold prevalence in the same adults with one weight",
         f"Domain P: n = {v['r21_n_P']} (August 2021 to August 2023, WTSAF2YR) and {v['r17_n_P']} (2017 to March 2020, WTSAFPRP). "
         "Left, weighted prevalence of HbA1c at or above 6.5% and fasting glucose at or above 126 mg/dL with 95% Korn-Graubard "
         "intervals. Right, paired difference (HbA1c minus glucose) with 95% t intervals using design degrees of freedom."),
        ("fig2_sample_and_definition_parts.png",
         "HbA1c prevalence by laboratory domain and decomposition of the naive difference",
         f"Left, HbA1c at or above 6.5% in domain H (WTPH2YR, n = {v['r21_n_H']}, in 2021 to 2023; WTMECPRP, n = {v['r17_n_H']}, "
         "in 2017 to March 2020) and in domain P (fasting subsample weight). Right, the naive difference (HbA1c in H minus "
         "glucose in P) equals the definition part (both in P) plus the sample and weight part (HbA1c in H minus HbA1c in P). "
         "The sample and weight part is a descriptive comparison. Lines are 95% intervals."),
        ("fig3_overlap_of_definitions.png",
         "Overlap of self-reported diagnosis, HbA1c, and fasting glucose classifications in domain P",
         f"August 2021 to August 2023, n = {v['r21_n_P']}, WTSAF2YR. Bars are weighted shares of all adults in domain P with 95% "
         f"Korn-Graubard intervals and unweighted counts. Adults with no diagnosis and both values below threshold "
         f"({v['r21_ov_dx0_a0_g0']}) are not drawn."),
        ("fig5_sensitivity_checks.png",
         "Estimates under the three prespecified sensitivity analyses, August 2021 to August 2023",
         f"S1, narrow fasting rule (P-narrow, n = {v['r21_n_Pn']}) compared with domain P; S2, single-biomarker domains H and F; "
         "S3, diagnosis, biochemical-only, and composite definitions in domain P. Weighted prevalence with 95% Korn-Graubard "
         "intervals."),
    ]


def figures_block(v: dict[str, str], embed: bool) -> str:
    out = []
    for i, (f, title, legend) in enumerate(figure_specs(v), start=1):
        if embed:
            out.append(f"![**Figure {i}. {title}.** {legend}]({f})")
        else:
            out.append(f"**Figure {i}. {title}.** {legend} (File: Figure{i}.png)")
    return "\n\n".join(out)
