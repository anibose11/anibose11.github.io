"""Denominator and weight compatibility checker.

Every analysis configuration (phenotype x domain x weight) and every contrast
is checked here before estimation. The same rules back the command line:

    python -m ddaudit check-config --phenotype FPG126 --domain H --weight WTPH2YR

which is refused, because fasting glucose needs the fasting subsample weight
in a fasting domain.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field

import yaml

from . import paths


def load_rules() -> dict:
    return yaml.safe_load((paths.CONFIG / "compatibility_rules.yaml").read_text())


def load_phenotypes() -> dict:
    return yaml.safe_load((paths.CONFIG / "phenotypes.yaml").read_text())


def load_configs() -> dict:
    return yaml.safe_load((paths.CONFIG / "analysis_configs.yaml").read_text())


@dataclass
class Verdict:
    ok: bool
    reasons: list[str] = field(default_factory=list)
    resolved: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {"ok": self.ok, "reasons": self.reasons, **self.resolved}


def weight_for_role(release: str, role: str, rules: dict | None = None) -> str:
    rules = rules or load_rules()
    for var, roles in rules["releases"][release]["weights"].items():
        if role in roles:
            return var
    raise KeyError(f"no {role} weight in release {release}")


def check_config(
    phenotype: str,
    domain: str,
    weight: str | None = None,
    weight_role: str | None = None,
    release: str = "2021-2023",
    min_age: int = 20,
    imputed_glucose: bool = False,
    pooled_releases: bool = False,
    rules: dict | None = None,
    phenos: dict | None = None,
) -> Verdict:
    rules = rules or load_rules()
    phenos = phenos or load_phenotypes()
    refuse = rules["refusals"]
    reasons: list[str] = []
    if release not in rules["releases"]:
        return Verdict(False, [f"Unknown release {release!r}."])
    rel = rules["releases"][release]
    if phenotype not in phenos["phenotypes"]:
        return Verdict(False, [f"Unknown phenotype {phenotype!r}. Known: {', '.join(phenos['phenotypes'])}."])
    if domain not in rules["domains"]:
        return Verdict(False, [f"Unknown domain {domain!r}. Known: {', '.join(rules['domains'])}."])
    dom = rules["domains"][domain]
    needs = phenos["phenotypes"][phenotype]["requires"]

    if weight is None and weight_role is None:
        return Verdict(False, ["Give a weight variable or a weight role."])
    if weight is not None:
        weight = weight.upper()
        if weight not in rel["weights"]:
            reasons.append(f"{weight}: {refuse['unknown_weight']}")
            role = None
        else:
            roles = rel["weights"][weight]
            allowed_here = dom["weight_roles"].get(release, [])
            role = next((r for r in roles if r in allowed_here), roles[0])
    else:
        role = weight_role
        try:
            weight = weight_for_role(release, role, rules)
        except KeyError:
            return Verdict(False, [f"Release {release} has no {role} weight."])

    if pooled_releases:
        reasons.append(refuse["pooled_releases"])
    if imputed_glucose:
        reasons.append(refuse["imputed_glucose"])
    if min_age < 20:
        reasons.append(refuse["age_below_20"])
    missing = [m for m in needs if m not in dom["measures"]]
    if missing:
        reasons.append(f"{phenotype} needs {', '.join(missing)} but domain {domain} does not guarantee it. {refuse['measure_not_in_domain']}")
    if "fpg" in needs and role != "fasting":
        reasons.append(refuse["fpg_without_fasting_weight"])
    allowed_roles = dom["weight_roles"].get(release, [])
    if role is not None and role not in allowed_roles:
        allowed = [v for v, rs in rel["weights"].items() if set(rs) & set(allowed_roles)]
        reasons.append(f"{weight} ({role}) used with domain {domain}. {refuse['weight_role_mismatch']} Allowed: {', '.join(allowed)}.")
    resolved = {"release": release, "phenotype": phenotype, "domain": domain, "weight": weight, "weight_role": role,
                "denominator": dom["label"]}
    return Verdict(not reasons, reasons, resolved)


def check_contrast(left: dict, right: dict, kind: str, rules: dict | None = None) -> Verdict:
    """Left and right are resolved configurations (phenotype, domain, weight)."""
    rules = rules or load_rules()
    same_sample = left["domain"] == right["domain"] and left["weight"] == right["weight"]
    same_pheno = left["phenotype"] == right["phenotype"]
    if kind == "paired_definition":
        if not same_sample:
            return Verdict(False, [rules["refusals"]["cross_domain_definition_contrast"]])
        if same_pheno:
            return Verdict(False, ["A definition contrast needs two different phenotypes."])
        return Verdict(True, [], {"interpretation": "difference in definitions on one denominator, paired covariance"})
    if kind == "selection_weighting":
        if not same_pheno:
            return Verdict(False, ["A selection and weighting comparison must hold the phenotype fixed."])
        if same_sample:
            return Verdict(False, ["The two sides use the same domain and weight; there is nothing to compare."])
        return Verdict(True, [], {"interpretation": "combined selection and weighting comparison, not causal"})
    if kind == "naive_cross_domain":
        return Verdict(True, ["Shown only with its decomposition into a definition part and a sample part."],
                       {"interpretation": "naive cross-domain difference; mixes definition and sample"})
    return Verdict(False, [f"Unknown contrast kind {kind!r}."])


def check_all(release: str = "2021-2023") -> dict:
    """Check every configured estimate and contrast; write results/config_check.json."""
    rules, phenos, cfg = load_rules(), load_phenotypes(), load_configs()
    resolved: dict[str, dict] = {}
    out = {"release": release, "configurations": [], "contrasts": [], "refused_examples": []}
    base = {c["id"]: c for c in cfg["configurations"] + cfg.get("auxiliary", [])}
    for c in cfg["configurations"] + cfg.get("auxiliary", []):
        v = check_config(c["phenotype"], c["domain"], weight_role=c["weight_role"], release=release, rules=rules, phenos=phenos)
        resolved[c["id"]] = {**v.resolved, "id": c["id"]}
        out["configurations"].append({"id": c["id"], "role": c["role"], **v.as_dict()})
    for s in cfg.get("sensitivity_variants", []):
        b = base[s["base"]]
        v = check_config(b["phenotype"], s["domain"], weight_role=b["weight_role"], release=release, rules=rules, phenos=phenos)
        resolved[s["id"]] = {**v.resolved, "id": s["id"]}
        out["configurations"].append({"id": s["id"], "role": s["role"], **v.as_dict()})
    for k in cfg["contrasts"]:
        v = check_contrast(resolved[k["left"]], resolved[k["right"]], k["kind"], rules)
        out["contrasts"].append({"id": k["id"], "left": k["left"], "right": k["right"], "kind": k["kind"], **v.as_dict()})
    # Demonstrations of refusals, kept with the results so readers can see the guardrails work.
    a1c_w = weight_for_role(release, "a1c_lab", rules)
    exam_w = weight_for_role(release, "exam", rules)
    fast_w = weight_for_role(release, "fasting", rules)
    examples = [
        dict(phenotype="FPG126", domain="H", weight=a1c_w),
        dict(phenotype="FPG126", domain="F", weight=exam_w),
        dict(phenotype="TOTAL_A1C_FPG", domain="H", weight=a1c_w),
        dict(phenotype="A1C65", domain="P", weight=fast_w, imputed_glucose=True),
        dict(phenotype="A1C65", domain="P", weight=fast_w, pooled_releases=True),
    ]
    if exam_w != a1c_w:
        # Only where the release documents a separate HbA1c laboratory weight.
        examples.insert(1, dict(phenotype="A1C65", domain="H", weight=exam_w))
    for ex in examples:
        v = check_config(release=release, rules=rules, phenos=phenos, **ex)
        out["refused_examples"].append({"request": ex, **v.as_dict()})
    naive = check_contrast(resolved["K3"], resolved["K2"], "paired_definition", rules)
    out["refused_examples"].append({"request": {"contrast": "K3 vs K2 labeled as a definition difference"}, **naive.as_dict()})
    out["all_configurations_ok"] = all(c["ok"] for c in out["configurations"])
    out["all_contrasts_ok"] = all(c["ok"] for c in out["contrasts"])
    out["all_examples_refused"] = all(not e["ok"] for e in out["refused_examples"])
    return out


def cli_check(args) -> int:
    rules, phenos = load_rules(), load_phenotypes()
    if args.list:
        print("Phenotypes:")
        for k, v in phenos["phenotypes"].items():
            print(f"  {k:14s} {v['label']} (needs {', '.join(v['requires'])})")
        print("Domains and allowed weights:")
        for d, v in rules["domains"].items():
            for rel, roles in v["weight_roles"].items():
                ws = [w for w, rs in rules["releases"][rel]["weights"].items() if set(rs) & set(roles)]
                print(f"  {d:9s} {rel}: {', '.join(ws):10s} {v['label']}")
        return 0
    requests = []
    if args.file:
        doc = yaml.safe_load(open(args.file))
        requests = doc if isinstance(doc, list) else doc.get("configurations", [doc])
    else:
        requests = [{"phenotype": args.phenotype, "domain": args.domain, "weight": args.weight, "release": args.release}]
    worst = 0
    for r in requests:
        r = {k: v for k, v in r.items() if k in {"phenotype", "domain", "weight", "weight_role", "release", "min_age", "imputed_glucose", "pooled_releases"}}
        v = check_config(rules=rules, phenos=phenos, **r)
        status = "ACCEPTED" if v.ok else "REFUSED"
        print(json.dumps({"status": status, **v.as_dict()}, indent=2))
        if not v.ok:
            worst = 2
    return worst
