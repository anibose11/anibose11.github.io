"""Render stage: figures, workbook, Tableau exports, claims ledger, documents.

Every number in the generated documents comes from values.collect(), which reads
the result tables. Documents are rendered with Quarto (bundled pandoc and typst);
the renderer and its version are recorded in results/run_manifest.json.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
from importlib import metadata
from pathlib import Path

import pandas as pd
import yaml

from . import __version__, paths
from .citations import number as number_citations
from .figures import make_figures
from .values import collect, figure_specs, figures_block, fill

QUARTO_CANDIDATES = [
    os.environ.get("QUARTO", ""),
    shutil.which("quarto") or "",
    "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto",
]


def quarto() -> str | None:
    for q in QUARTO_CANDIDATES:
        if q and Path(q).exists():
            return q
    return None


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def code_tree_sha256() -> str:
    h = hashlib.sha256()
    for d in ("src", "sql", "R", "config"):
        for p in sorted((paths.ROOT / d).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                h.update(p.relative_to(paths.ROOT).as_posix().encode())
                h.update(p.read_bytes())
    return h.hexdigest()


def versions() -> dict:
    out = {"python": platform.python_version(), "platform": platform.platform(), "ddaudit": __version__}
    for pkg in ("pandas", "numpy", "duckdb", "pyarrow", "matplotlib", "openpyxl", "PyYAML"):
        try:
            out[pkg] = metadata.version(pkg)
        except metadata.PackageNotFoundError:
            out[pkg] = "not installed"
    dc = paths.TABLES / "2021-2023" / "design_checks.json"
    if dc.exists():
        d = json.loads(dc.read_text())
        out["R"] = d["r_version"]
        out["survey (R)"] = d["survey_version"]
    q = quarto()
    if q:
        out["quarto"] = subprocess.run([q, "--version"], capture_output=True, text=True).stdout.strip()
        out["reporting_renderer"] = f"Quarto {out['quarto']} (bundled pandoc and typst)"
    else:
        out["reporting_renderer"] = "not available"
    return out


def write_run_manifest() -> dict:
    man = paths.RESULTS / "run_manifest.json"
    prev = json.loads(man.read_text()) if man.exists() else {}
    src = json.loads(paths.MANIFEST.read_text())
    data_hashes = {k: v["sha256"] for k, v in src["entries"].items() if v["kind"] == "data_xpt"}
    verified = {}
    for rel in ("2021-2023", "2017-2020"):
        bc = paths.VALIDATION / rel / "build_checks.json"
        if bc.exists():
            verified.update(json.loads(bc.read_text()).get("source_sha256_verified_against_manifest", {}))
    rm = {
        "run_id": prev.get("run_id") or dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        "analysis_started_utc": prev.get("analysis_started_utc"),
        "analysis_finished_utc": prev.get("analysis_finished_utc"),
        "render_finished_utc": _now(),
        "analysis_code_tree_sha256": prev.get("analysis_code_tree_sha256"),
        "render_code_tree_sha256": code_tree_sha256(),
        "source_sha256_recomputed_at_build": verified,
        "analysis_plan_frozen_sha256": (paths.DOCS / "analysis_plan_frozen_v1.sha256").read_text().split()[0],
        "phenotype_spec_version": yaml.safe_load((paths.CONFIG / "phenotypes.yaml").read_text())["spec_version"],
        "source_data_sha256_manifest": data_hashes,
        "versions": versions(),
        "numerical_tolerance_for_reruns": 1e-9,
    }
    man.write_text(json.dumps(rm, indent=2) + "\n")
    return rm


def p_display(p: float) -> str:
    """p-values for exports: never shown as 0."""
    return "<0.0001" if p < 0.0001 else f"{p:.4f}"


# ------------------------------------------------------------------ workbook
def write_workbook(releases: list[str]) -> str:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font
    from openpyxl.utils import get_column_letter

    phen = yaml.safe_load((paths.CONFIG / "phenotypes.yaml").read_text())
    rules = yaml.safe_load((paths.CONFIG / "compatibility_rules.yaml").read_text())
    cfg = yaml.safe_load((paths.CONFIG / "analysis_configs.yaml").read_text())
    rm = json.loads((paths.RESULTS / "run_manifest.json").read_text())
    sheets: dict[str, pd.DataFrame] = {}

    readme = [
        ("Title", "Diabetes estimates under different definitions and laboratory denominators: aggregate results"),
        ("Data", "NHANES August 2021-August 2023 (primary) and 2017-March 2020 pre-pandemic (separate replication), CDC NCHS public-use files"),
        ("Run ID", rm["run_id"]),
        ("Phenotype specification", f"version {phen['spec_version']}"),
        ("Units", "Columns named estimate, se, ci_low, ci_high (and their variants) are proportions from 0 to 1, and contrast "
                  "differences are differences of proportions. The NCHS_reconciliation sheet is the exception: every numeric "
                  "column whose name ends in _percent is a percentage from 0 to 100."),
        ("Suppressed rows", "Rows with nchs_status = suppressed do not meet the NCHS presentation standard. Their values are kept "
                            "for audit only and must not be displayed or interpreted."),
        ("Denominators", "Every table names its sample universe (domain), weight, and unweighted denominator n. Domain letters: "
                         "A adults 20+ examined, not pregnant, DIQ010 answered; H A with HbA1c; F A with valid fasting glucose; "
                         "P F with HbA1c (common paired domain); P_NARROW P meeting the narrow fasting rule."),
        ("Intervals", "Proportions: 95% Korn-Graubard intervals with the degrees-of-freedom adjustment (NCHS standard). "
                      "Contrasts: 95% t intervals with design degrees of freedom."),
        ("Suppression", "nchs_status follows the NCHS Data Presentation Standards for Proportions (Parker et al. 2017): "
                        "presented, flagged, or suppressed, with the reason."),
        ("Post hoc", "The Post_hoc_not_prespecified sheet holds analyses added after the planned analyses (analysis plan "
                     "amendment 8). They are exploratory and are not part of the prespecified configurations."),
        ("Person-level data", "None. This workbook contains aggregate results only."),
        ("Do not", "Do not sum, average, or re-weight estimates across rows. Each row is a separate survey estimate."),
    ]
    sheets["README"] = pd.DataFrame(readme, columns=["item", "description"])
    th = phen["thresholds"]
    defs = []
    for k, p in phen["phenotypes"].items():
        defs.append({"phenotype": k, "label": p["label"], "definition": p["definition"], "requires": ", ".join(p["requires"]),
                     "biochemical": p["biochemical"]})
    sheets["Definitions"] = pd.DataFrame(defs)
    sheets["Thresholds"] = pd.DataFrame([
        {"measure": "HbA1c", "variable": th["a1c"]["variable"], "unit": th["a1c"]["unit"], "operator": th["a1c"]["operator"],
         "threshold": th["a1c"]["value"], "boundary": "inclusive", "si_equivalent": th["a1c"]["si_equivalent"],
         "stored_precision": "1 decimal"},
        {"measure": "Fasting plasma glucose", "variable": th["fpg"]["variable"], "unit": th["fpg"]["unit"],
         "operator": th["fpg"]["operator"], "threshold": th["fpg"]["value"], "boundary": "inclusive",
         "si_equivalent": th["fpg"]["si_equivalent"], "stored_precision": "whole mg/dL",
         "fasting_rule": th["fpg"]["fasting_rule"]},
    ])
    drows = []
    for d, info in rules["domains"].items():
        for rel, roles in info["weight_roles"].items():
            ws = [w for w, rs in rules["releases"][rel]["weights"].items() if set(rs) & set(roles)]
            drows.append({"domain": d, "label": info["label"], "guaranteed_measures": ", ".join(info["measures"]),
                          "release": rel, "allowed_weight": ", ".join(ws)})
    sheets["Domains_and_weights"] = pd.DataFrame(drows)
    sheets["Configurations"] = pd.DataFrame(cfg["configurations"] + cfg.get("auxiliary", []) + cfg.get("sensitivity_variants", []))
    sheets["Contrast_definitions"] = pd.DataFrame(cfg["contrasts"])
    for name, fname in (("Participant_flow", "participant_flow.csv"), ("Estimates", "estimates.csv"),
                        ("Contrasts", "contrasts.csv"), ("Decomposition", "decomposition.csv"),
                        ("Agreement", "agreement.csv"), ("Overlap", "overlap.csv"),
                        ("Diagnosed_below_threshold", "s3_diagnosed_below_threshold.csv"),
                        ("Missingness_by_group", "missingness_by_group.csv"), ("Paired_by_group", "paired_by_group.csv"),
                        ("NCHS_reconciliation", "reference_reconciliation.csv"),
                        ("Post_hoc_not_prespecified", "posthoc.csv")):
        frames = [pd.read_csv(paths.TABLES / r / fname) for r in releases if (paths.TABLES / r / fname).exists()]
        if frames:
            sheets[name] = pd.concat(frames, ignore_index=True)
    refusals = []
    for r in releases:
        cc = json.loads((paths.TABLES / r / "config_check.json").read_text())
        for ex in cc["refused_examples"]:
            refusals.append({"release": r, "request": json.dumps(ex["request"]), "status": "refused" if not ex["ok"] else "accepted",
                             "reasons": " | ".join(ex["reasons"])})
    sheets["Checker_refusals"] = pd.DataFrame(refusals)
    sheets["Validation_summary"] = pd.read_csv(paths.VALIDATION / "validation_summary.csv")
    if "NCHS_reconciliation" in sheets:
        rec = sheets["NCHS_reconciliation"]
        sheets["NCHS_reconciliation"] = rec.rename(columns={c: f"{c}_percent" for c in rec.columns
                                                            if c.startswith(("published_percent", "our_percent", "published_ci", "our_ci",
                                                                             "published_se", "our_se")) and not c.endswith("_percent")})

    wb = Workbook()
    wb.remove(wb.active)
    for name, df in sheets.items():
        ws = wb.create_sheet(name[:31])
        ws.append(list(df.columns))
        for c in ws[1]:
            c.font = Font(bold=True)
        for row in df.itertuples(index=False):
            ws.append([None if (isinstance(x, float) and pd.isna(x)) else (x.item() if hasattr(x, "item") else x) for x in row])
        for i, col in enumerate(df.columns, start=1):
            width = min(60, max(10, len(str(col)) + 2, *(len(str(x)) for x in df[col].head(50))))
            ws.column_dimensions[get_column_letter(i)].width = width
        ws.freeze_panes = "A2"
        if name == "README":
            for row in ws.iter_rows(min_row=2):
                row[1].alignment = Alignment(wrap_text=True, vertical="top")
    out = paths.EXPORTS / "diabetes-definition-audit-results.xlsx"
    wb.save(out)
    return paths.rel(out)


# ------------------------------------------------------------- Tableau exports
def write_tableau_exports(releases: list[str]) -> list[str]:
    outs = []
    est = pd.concat([pd.read_csv(paths.TABLES / r / "estimates.csv") for r in releases], ignore_index=True)
    t = pd.DataFrame({
        "grain": "one row per release x configuration",
        "release": est.release, "config_id": est.config_id, "phenotype": est.phenotype, "phenotype_label": est.phenotype_label,
        "sample_universe": est.sample_universe, "weight": est.weight, "denominator_n_unweighted": est.n_unweighted,
        "numerator_n_unweighted": est.n_positive_unweighted, "estimate_percent": (100 * est.estimate).round(3),
        "ci_low_percent": (100 * est.ci_low).round(3), "ci_high_percent": (100 * est.ci_high).round(3),
        "se_percentage_points": (100 * est.se).round(3), "degrees_of_freedom": est.df_domain,
        "nchs_status": est.nchs_status, "suppressed": est.nchs_status == "suppressed", "units": "percent of the sample universe",
    })
    p = paths.EXPORTS / "tableau_estimates.csv"
    t.to_csv(p, index=False)
    outs.append(paths.rel(p))
    con = pd.concat([pd.read_csv(paths.TABLES / r / "contrasts.csv") for r in releases], ignore_index=True)
    status = {(r.release, r.config_id): r.nchs_status for r in est.itertuples()}
    comp_sup = [status.get((r.release, r.left)) == "suppressed" or status.get((r.release, r.right)) == "suppressed"
                for r in con.itertuples()]
    t = pd.DataFrame({
        "grain": "one row per release x contrast", "release": con.release, "contrast_id": con.contrast_id, "kind": con.kind,
        "label": con.label, "left_config": con.left, "left_phenotype": con.left_phenotype, "left_universe": con.left_universe,
        "left_weight": con.left_weight, "left_denominator_n_unweighted": con.left_n,
        "right_config": con.right, "right_phenotype": con.right_phenotype, "right_universe": con.right_universe,
        "right_weight": con.right_weight, "right_denominator_n_unweighted": con.right_n,
        "difference_percentage_points": (100 * con.estimate).round(3), "ci_low_pp": (100 * con.ci_low).round(3),
        "ci_high_pp": (100 * con.ci_high).round(3), "se_pp": (100 * con.se).round(3), "degrees_of_freedom": con.df,
        "p_value": [p_display(p) for p in con.p_value],
        "component_suppressed": comp_sup, "units": "percentage points",
    })
    p = paths.EXPORTS / "tableau_contrasts.csv"
    t.to_csv(p, index=False)
    outs.append(paths.rel(p))
    m = pd.concat([pd.read_csv(paths.TABLES / r / "missingness_by_group.csv") for r in releases], ignore_index=True)
    t = pd.DataFrame({
        "grain": "one row per release x group x laboratory status", "release": m.release, "group_variable": m.group_variable,
        "group": m.group, "status": m.status, "status_label": m.status_label, "sample_universe": m.sample_universe,
        "weight": m.weight, "denominator_n_unweighted": m.n_unweighted, "numerator_n_unweighted": m.n_positive_unweighted,
        "share_percent": (100 * m.estimate).round(3), "ci_low_percent": (100 * m.ci_low).round(3),
        "ci_high_percent": (100 * m.ci_high).round(3), "nchs_status": m.nchs_status,
        "suppressed": m.nchs_status == "suppressed", "units": "percent of the group in domain A",
    })
    p = paths.EXPORTS / "tableau_missingness.csv"
    t.to_csv(p, index=False)
    outs.append(paths.rel(p))
    g = pd.concat([pd.read_csv(paths.TABLES / r / "paired_by_group.csv") for r in releases], ignore_index=True)
    t = g.copy()
    for c in ("hba1c_estimate", "hba1c_ci_low", "hba1c_ci_high", "glucose_estimate", "glucose_ci_low", "glucose_ci_high"):
        t[c + "_percent"] = (100 * t[c]).round(3)
    for c in ("difference", "difference_ci_low", "difference_ci_high", "difference_se"):
        t[c + "_pp"] = (100 * t[c]).round(3)
    keep = ["release", "group_variable", "group", "sample_universe", "weight", "n_unweighted", "hba1c_estimate_percent",
            "hba1c_ci_low_percent", "hba1c_ci_high_percent", "hba1c_nchs_status", "glucose_estimate_percent",
            "glucose_ci_low_percent", "glucose_ci_high_percent", "glucose_nchs_status", "difference_pp",
            "difference_ci_low_pp", "difference_ci_high_pp", "difference_note", "df_domain"]
    t = t[keep]
    t.insert(0, "grain", "one row per release x group (domain P)")
    t["suppressed_component"] = (t.hba1c_nchs_status == "suppressed") | (t.glucose_nchs_status == "suppressed")
    t["units"] = "estimates: percent of the group in domain P; difference: percentage points"
    p = paths.EXPORTS / "tableau_paired_by_group.csv"
    t.to_csv(p, index=False)
    outs.append(paths.rel(p))
    return outs


# ------------------------------------------------------------ claims ledger
def write_claims(releases: list[str]) -> str:
    rm = json.loads((paths.RESULTS / "run_manifest.json").read_text())

    def hashes(release):
        rec = rm.get("source_sha256_recomputed_at_build", {})
        return {k.split("/")[-1]: v for k, v in rec.items() if k.startswith(f"{release}/data_xpt/")}

    claims = []

    def est_claim(cid, release, config, statement):
        e = pd.read_csv(paths.TABLES / release / "estimates.csv").set_index("config_id").loc[config]
        claims.append({
            "id": cid, "statement": statement, "value_percent": round(100 * e.estimate, 2),
            "ci95_percent": [round(100 * e.ci_low, 2), round(100 * e.ci_high, 2)],
            "numerator_unweighted": int(e.n_positive_unweighted), "denominator_unweighted": int(e.n_unweighted),
            "analysis_scope": {"release": release, "sample_universe": e.sample_universe, "weight": e.weight},
            "configuration": {"config_id": config, "phenotype": e.phenotype},
            "evidence": {"path": f"results/tables/{release}/estimates.csv", "row_key": {"config_id": config},
                         "columns": ["estimate", "ci_low", "ci_high", "n_unweighted", "n_positive_unweighted"]},
            "source_sha256": hashes(release), "run_id": rm["run_id"]})

    def con_claim(cid, release, contrast, statement):
        c = pd.read_csv(paths.TABLES / release / "contrasts.csv").set_index("contrast_id").loc[contrast]
        claims.append({
            "id": cid, "statement": statement, "value_percentage_points": round(100 * c.estimate, 3),
            "ci95_percentage_points": [round(100 * c.ci_low, 3), round(100 * c.ci_high, 3)], "p_value": p_display(float(c.p_value)),
            "analysis_scope": {"release": release, "left": f"{c.left} ({c.left_universe}, {c.left_weight})",
                               "right": f"{c.right} ({c.right_universe}, {c.right_weight})", "kind": c.kind},
            "configuration": {"contrast_id": contrast},
            "evidence": {"path": f"results/tables/{release}/contrasts.csv", "row_key": {"contrast_id": contrast},
                         "columns": ["estimate", "ci_low", "ci_high", "p_value"]},
            "source_sha256": hashes(release), "run_id": rm["run_id"]})

    r = "2021-2023"
    est_claim("hba1c_paired", r, "K1", "HbA1c at or above 6.5% in the common paired domain")
    est_claim("glucose_paired", r, "K2", "Fasting glucose at or above 126 mg/dL in the common paired domain")
    con_claim("definition_part", r, "C1", "Paired difference, HbA1c minus glucose threshold prevalence, same adults and weight")
    est_claim("hba1c_lab_domain", r, "K3", "HbA1c at or above 6.5% in the HbA1c laboratory domain with the phlebotomy weight")
    con_claim("sample_weight_part", r, "C2", "HbA1c in its laboratory domain minus HbA1c in the paired domain (selection and weighting comparison)")
    con_claim("naive_difference", r, "C3", "Naive cross-domain difference, HbA1c laboratory domain minus glucose paired domain")
    est_claim("total_composite", r, "K6", "Diagnosed, or HbA1c or glucose at or above threshold (surveillance composite)")
    est_claim("diagnosed", r, "K5", "Self-reported diagnosed diabetes in the paired domain")
    con_claim("undiagnosed_share", r, "C8", "Composite minus diagnosed: biochemical positivity without a reported diagnosis")
    con_claim("diagnosed_below_threshold_share_of_adults", r, "C9", "Composite minus biochemical only: diagnosed with both biomarkers below threshold")
    s3 = pd.read_csv(paths.TABLES / r / "s3_diagnosed_below_threshold.csv").set_index("group").loc["all diagnosed"]
    claims.append({"id": "diagnosed_below_threshold_share_of_diagnosed",
                   "statement": "Among adults with diagnosed diabetes in domain P, share with HbA1c below 6.5% and glucose below 126 mg/dL",
                   "value_percent": round(100 * s3.estimate, 2), "ci95_percent": [round(100 * s3.ci_low, 2), round(100 * s3.ci_high, 2)],
                   "numerator_unweighted": int(s3.n_positive_unweighted), "denominator_unweighted": int(s3.n_unweighted),
                   "analysis_scope": {"release": r, "sample_universe": s3.sample_universe, "weight": s3.weight},
                   "evidence": {"path": f"results/tables/{r}/s3_diagnosed_below_threshold.csv", "row_key": {"group": "all diagnosed"},
                                "columns": ["estimate", "ci_low", "ci_high"]},
                   "source_sha256": hashes(r), "run_id": rm["run_id"]})
    a = pd.read_csv(paths.TABLES / r / "agreement.csv").set_index("measure").loc["cohens_kappa"]
    claims.append({"id": "kappa", "statement": "Cohen's kappa for HbA1c and glucose threshold classifications in domain P (weighted)",
                   "value": round(float(a.estimate), 3), "ci95": [round(float(a.ci_low), 3), round(float(a.ci_high), 3)],
                   "denominator_unweighted": int(a.n_unweighted),
                   "analysis_scope": {"release": r, "sample_universe": a.sample_universe, "weight": a.weight},
                   "evidence": {"path": f"results/tables/{r}/agreement.csv", "row_key": {"measure": "cohens_kappa"},
                                "columns": ["estimate", "ci_low", "ci_high"]},
                   "source_sha256": hashes(r), "run_id": rm["run_id"]})
    agr = pd.read_csv(paths.TABLES / r / "agreement.csv").set_index("measure")
    for mid, meas, stmt in (("percent_agreement", "percent_agreement", "Percent agreement of HbA1c and glucose threshold classifications, domain P"),
                            ("hba1c_only_share", "share_of_either_positive_hba1c_only", "Share of adults above either threshold who were above the HbA1c threshold only"),
                            ("glucose_only_share", "share_of_either_positive_glucose_only", "Share of adults above either threshold who were above the glucose threshold only")):
        x = agr.loc[meas]
        cells = {c: int(agr.loc[f"cell {c}", "n_positive_unweighted"]) for c in ("c11", "c10", "c01")}
        counts = {"denominator_unweighted": int(x.n_unweighted)}
        universe = x.sample_universe
        if meas.startswith("share_of_either_positive"):
            # Ratio of weighted cells: the unweighted counts behind it are the either-positive adults.
            counts = {"numerator_unweighted": cells["c10"] if meas.endswith("hba1c_only") else cells["c01"],
                      "denominator_unweighted": sum(cells.values())}
            universe = f"{x.sample_universe}; adults above either threshold (cells c11 + c10 + c01)"
        claims.append({"id": mid, "statement": stmt, "value_percent": round(100 * float(x.estimate), 2),
                       "ci95_percent": [round(100 * float(x.ci_low), 2), round(100 * float(x.ci_high), 2)],
                       **counts,
                       "analysis_scope": {"release": r, "sample_universe": universe, "weight": x.weight},
                       "evidence": {"path": f"results/tables/{r}/agreement.csv", "row_key": {"measure": meas},
                                    "columns": ["estimate", "ci_low", "ci_high"]},
                       "source_sha256": hashes(r), "run_id": rm["run_id"]})
    dc = json.loads((paths.TABLES / r / "design_checks.json").read_text())
    claims.append({"id": "k1_k2_sampling_correlation", "statement": "Sampling correlation between the paired HbA1c and glucose estimates (K1, K2)",
                   "value": round(dc["k1_k2_sampling_correlation"], 3), "denominator_unweighted": int(
                       pd.read_csv(paths.TABLES / r / "estimates.csv").set_index("config_id").loc["K1", "n_unweighted"]),
                   "analysis_scope": {"release": r, "sample_universe": "P", "weight": "WTSAF2YR"},
                   "evidence": {"path": f"results/tables/{r}/design_checks.json", "keys": ["k1_k2_sampling_covariance", "k1_k2_sampling_correlation"]},
                   "source_sha256": hashes(r), "run_id": rm["run_id"]})
    claims.append({"id": "se_ratio_if_covariance_ignored", "statement": "Ratio of the standard error of the paired difference computed without the covariance to the paired standard error (illustration only)",
                   "value": round(dc["c1_se_if_covariance_ignored_illustration_only"] / dc["c1_se_paired"], 2),
                   "analysis_scope": {"release": r, "sample_universe": "P", "weight": "WTSAF2YR"},
                   "evidence": {"path": f"results/tables/{r}/design_checks.json", "keys": ["c1_se_paired", "c1_se_if_covariance_ignored_illustration_only"]},
                   "source_sha256": hashes(r), "run_id": rm["run_id"]})
    rec = pd.read_csv(paths.TABLES / r / "reference_reconciliation.csv")
    claims.append({"id": "nchs_reconciliation", "statement": "Published NCHS Data Brief 516 rows reproduced (sample size, percent, and SE, to rounding)",
                   "value": {"rows": len(rec), "n_match": int(rec.n_match.sum()), "percent_match": int(rec.percent_match.sum()),
                             "se_match": int(rec.se_match.sum()), "ci_match": int(rec.ci_match.sum()),
                             "ci_match_without_neff_cap": int(rec.ci_match_without_neff_cap.sum())},
                   "analysis_scope": {"release": r, "sample_universe": "P", "weight": "WTSAF2YR",
                                      "reference": "NCHS Data Brief 516, Tables 1 and 2 (crude estimates)"},
                   "evidence": {"path": f"results/tables/{r}/reference_reconciliation.csv"},
                   "source_sha256": hashes(r), "run_id": rm["run_id"]})
    r17 = "2017-2020"
    if r17 in releases:
        con_claim("replication_definition_part", r17, "C1", "Replication: paired HbA1c minus glucose difference, 2017-March 2020")
        con_claim("replication_sample_weight_part", r17, "C2", "Replication: HbA1c in the examination-weight domain minus the paired domain, 2017-March 2020")
    flows = {}
    for rel in releases:
        f = pd.read_csv(paths.TABLES / rel / "participant_flow.csv").set_index("step")
        flows[rel] = {"source_records_demographics": int(f.loc[1, "n"]), "domain_A": int(f.loc[6, "n"]),
                      "domain_H": int(f.loc[8, "n"]), "domain_F": int(f.loc[12, "n"]), "domain_P": int(f.loc[13, "n"]),
                      "domain_P_narrow": int(f.loc[14, "n"])}
    vs = json.loads((paths.VALIDATION / "validation_summary.json").read_text())
    ledger = {
        "schema": "ddaudit-claims/1", "run_id": rm["run_id"], "analysis_code_tree_sha256": rm["analysis_code_tree_sha256"],
        "counts_kept_separate": {
            "source_records_and_domains": flows,
            "predictive_model": "none; deterministic classification and design-based estimation, so there is no test set",
            "automated_checks": {"total": vs["checks"], "passed": vs["passed"], "failed": vs["failed"]},
        },
        "claims": claims,
    }
    out = paths.EVIDENCE / "claims.json"
    out.write_text(json.dumps(ledger, indent=2) + "\n")
    return paths.rel(out)


# --------------------------------------------------------------- documents
# The public copy relies on the title block for author and affiliation. The submission
# copy adds the title-page lines a journal needs (affiliation, correspondence, type).
CORRESPONDENCE_PUBLIC = ""


def correspondence_submission() -> str:
    """Title-page line for the journal submission copy.

    The corresponding author's e-mail address is read from .local/submission_contact.txt,
    which is private and never packaged; the public copies carry no e-mail address.
    """
    f = paths.CODE_ROOT / ".local" / "submission_contact.txt"
    email = f.read_text().strip() if f.exists() else ""
    line = "**Correspondence:** Animesh Bose, Norlowe Research."
    line = f"{line} Email: {email}" if email else line
    return ("**Author and affiliation:** Animesh Bose, Norlowe Research\n\n"
            f"{line}\n\n**Article type:** Research article")


def format_submission_docx(path: Path) -> None:
    """Format the submission without changing scientific text or table values."""
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn

    doc = Document(path)
    for name, size in (("Normal", 12), ("Body Text", 12), ("Title", 14),
                       ("Heading 1", 12), ("Heading 2", 12), ("Heading 3", 12)):
        if name not in doc.styles:
            continue
        style = doc.styles[name]
        style.font.name = "Times New Roman"
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.line_spacing = 2.0
        if name.startswith("Heading") or name == "Title":
            style.font.bold = True
            style.paragraph_format.keep_with_next = True
            style.paragraph_format.space_before = Pt(6)
            style.paragraph_format.space_after = Pt(0)
    for p in doc.paragraphs:
        p.paragraph_format.line_spacing = 2.0
        if p.style.name == "Title":
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in p.runs:
            run.font.name = "Times New Roman"
            run.font.color.rgb = RGBColor(0, 0, 0)
            if p.style.name == "Title":
                run.font.size = Pt(14)
                run.bold = True
    for table in doc.tables:
        header = OxmlElement("w:tblHeader")
        table.rows[0]._tr.get_or_add_trPr().append(header)
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing = 1.0
                    p.paragraph_format.space_before = Pt(0)
                    p.paragraph_format.space_after = Pt(2)
                    for run in p.runs:
                        run.font.name = "Times New Roman"
                        run.font.size = Pt(9)
    for section in doc.sections:
        for old in list(section._sectPr.findall(qn("w:lnNumType"))):
            section._sectPr.remove(old)
        ln = OxmlElement("w:lnNumType")
        ln.set(qn("w:countBy"), "1")
        ln.set(qn("w:restart"), "continuous")
        section._sectPr.append(ln)
        # Replace the existing footer rather than adding a second footer reference.
        refs = list(section._sectPr.findall(qn("w:footerReference")))
        for duplicate in refs[1:]:
            section._sectPr.remove(duplicate)
        footer = section.footer
        for child in list(footer._element):
            footer._element.remove(child)
        p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p._p.get_or_add_pPr().append(OxmlElement("w:suppressLineNumbers"))
        r = p.add_run()
        begin = OxmlElement("w:fldChar")
        begin.set(qn("w:fldCharType"), "begin")
        instruction = OxmlElement("w:instrText")
        instruction.set(qn("xml:space"), "preserve")
        instruction.text = " PAGE "
        end = OxmlElement("w:fldChar")
        end.set(qn("w:fldCharType"), "end")
        for element in (begin, instruction, end):
            r._r.append(element)
    doc.save(path)


def format_public_docx_tables(path: Path) -> None:
    """Keep the wide public-report tables legible and their rows intact."""
    from docx import Document
    from docx.shared import Pt
    from docx.oxml import OxmlElement
    doc = Document(path)
    for table in doc.tables:
        table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
        for row in table.rows:
            row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for cell in row.cells:
                for p in cell.paragraphs:
                    p.paragraph_format.line_spacing = 1.0
                    p.paragraph_format.space_after = Pt(2)
                    for run in p.runs:
                        run.font.size = Pt(9)
    doc.save(path)


def _quarto_render(q: str, workdir: Path, md_name: str, fmts: list[str]) -> None:
    for fmt in fmts:
        res = subprocess.run([q, "render", md_name, "--to", fmt], cwd=workdir, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"quarto render {md_name} --to {fmt} failed:\n{res.stderr[-3000:]}")


def render_documents() -> dict:
    values = collect()
    out = {}
    tmpl_dir = paths.ROOT / "manuscript"
    build = tmpl_dir / "build"
    sub = tmpl_dir / "submission"
    if sub.exists():
        shutil.rmtree(sub)
    for d in (build, sub):
        d.mkdir(parents=True, exist_ok=True)
    for f in paths.FIGURES.glob("*.png"):
        shutil.copy2(f, build / f.name)
    shutil.copy2(tmpl_dir / "report.css", build / "report.css")
    q = quarto()
    for tmpl in sorted(tmpl_dir.glob("*.md.tmpl")):
        stem = tmpl.name.replace(".md.tmpl", "")
        targets = [(build, stem, CORRESPONDENCE_PUBLIC)]
        if stem == "manuscript":
            targets.append((sub, "manuscript_submission", correspondence_submission()))
        raw = tmpl.read_text()
        if "[@" in raw:
            raw = number_citations(raw)
        for d, name, corr in targets:
            text = fill(raw, {**values, "correspondence_block": corr,
                                           "figures_block": figures_block(values, embed=(d is build))})
            md = d / f"{name}.md"
            md.write_text(text)
            out[name] = paths.rel(md)
            if q:
                fmts = ["html", "typst", "docx"] if d is build else ["docx"]
                _quarto_render(q, d, md.name, fmts)
                if d is sub:
                    format_submission_docx(d / f"{name}.docx")
                elif stem == "manuscript":
                    format_public_docx_tables(d / f"{name}.docx")
    # Figure files for upload, named in manuscript order.
    for i, (f, _, _) in enumerate(figure_specs(values), start=1):
        shutil.copy2(paths.FIGURES / f, sub / f"Figure{i}.png")
    # Private submission documents (cover letter): rendered only into manuscript/submission/.
    for tmpl in sorted((tmpl_dir / "submission_templates").glob("*.md.tmpl")):
        f = paths.CODE_ROOT / ".local" / "submission_contact.txt"
        email = f.read_text().strip() if f.exists() else ""
        text = fill(tmpl.read_text(), {**values, "submission_email": email})
        md = sub / tmpl.name.replace(".md.tmpl", ".md")
        md.write_text(text)
        out[md.stem] = paths.rel(md)
        if q:
            _quarto_render(q, sub, md.name, ["docx"])
    vals = paths.RESULTS / "document_values.json"
    vals.write_text(json.dumps({k: v for k, v in values.items() if not k.startswith("table_") and k != "plan_amendments"},
                               indent=1, sort_keys=True) + "\n")
    out["values"] = paths.rel(vals)
    return out


def render() -> dict:
    sources = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    releases = [r for r in sources["releases"] if (paths.TABLES / r / "estimates.csv").exists()]
    paths.EXPORTS.mkdir(parents=True, exist_ok=True)
    rm = write_run_manifest()
    figs = make_figures(releases)
    wb = write_workbook(releases)
    exports = write_tableau_exports(releases)
    claims = write_claims(releases)
    docs = render_documents()
    rm = write_run_manifest()
    return {"run_id": rm["run_id"], "figures": figs, "workbook": wb, "exports": exports, "claims": claims, "documents": docs,
            "renderer": rm["versions"]["reporting_renderer"]}
