"""Validate stage: gather every check into one summary with a pass/fail verdict.

Checks are labeled by kind so the report can keep them apart:
  software check            the code agrees with itself or with a second implementation
  source reconciliation     the data files agree with the NCHS documentation codebooks
  external reconciliation   our estimates agree with published NCHS aggregates
Independent expert validation of the scientific conclusions is a different thing;
no automated check stands in for it.
"""

from __future__ import annotations

import html
import json
import re

import pandas as pd
import yaml

from . import paths

TOL_ESTIMATE = 1e-9
TOL_SE_REL = 1e-6
TOL_ADDITIVITY = 1e-12


def _check(name: str, kind: str, ok: bool, detail: str, release: str) -> dict:
    return {"release": release, "check": name, "kind": kind, "status": "pass" if ok else "FAIL", "detail": detail}


def validate_release(release: str) -> list[dict]:
    t, v = paths.TABLES / release, paths.VALIDATION / release
    out = []
    b = json.loads((v / "build_checks.json").read_text())
    out.append(_check("join cardinality: unique SEQN, every component SEQN in DEMO", "software check", True,
                      b["join_checks"], release))
    out.append(_check("analytic frame rows equal DEMO rows", "software check", True, f"{b['rows_frame_equals_demo']} rows", release))
    for k in ("fasting_weight_outside_window", "domain_nesting_violations", "null_phenotype_inside_domain",
              "laboratory_weight_without_examination"):
        out.append(_check(k.replace("_", " "), "software check", b[k] == 0, f"count = {b[k]}", release))
    cb = pd.read_csv(v / "codebook_reconciliation.csv")
    out.append(_check("file counts equal published codebook frequencies", "source reconciliation",
                      bool(cb.match.all()), f"{int(cb.match.sum())} of {len(cb)} codebook rows match", release))
    zw = b["zero_fasting_weight_with_glucose"]
    src = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())["releases"][release]
    glu_doc = paths.DATA_RAW / release / "docs" / f"{src['build']['tables']['glu']}.htm"
    text = " ".join(re.sub(r"<[^>]+>", " ", html.unescape(glu_doc.read_text(encoding="utf-8", errors="replace"))).split())
    m = re.search(r"did not meet the 8 to less than 24 hour fasting criteria \(n=(\d+)\)", text)
    documented = int(m.group(1)) if m else None
    out.append(_check("glucose values with zero fasting weight equal the documented count", "source reconciliation",
                      documented == zw,
                      f"{zw} in the file, {documented} in the documentation; window breakdown <8 h, >=24 h, unknown, inside: "
                      f"{b['zero_fasting_weight_with_glucose_window']}", release))
    cc = json.loads((t / "config_check.json").read_text())
    n_conf = len(cc["configurations"])
    out.append(_check("all configurations and contrasts accepted by the checker", "software check",
                      cc["all_configurations_ok"] and cc["all_contrasts_ok"],
                      f"8 configurations plus {n_conf - 8} auxiliary or sensitivity estimates, {len(cc['contrasts'])} contrasts", release))
    out.append(_check("invalid requests refused by the checker", "software check", cc["all_examples_refused"],
                      f"{len(cc['refused_examples'])} refusal examples", release))
    d = pd.read_csv(v / "direct_vs_survey.csv")
    out.append(_check("direct weighted proportions equal R survey estimates", "software check",
                      float(d.abs_diff_estimate.max()) <= TOL_ESTIMATE,
                      f"max abs difference {d.abs_diff_estimate.max():.2e} over {len(d)} estimates and contrasts", release))
    out.append(_check("second implementation of linearized SE equals R survey SE", "software check",
                      float(d.rel_diff_se.max()) <= TOL_SE_REL, f"max relative difference {d.rel_diff_se.max():.2e}", release))
    x = pd.read_csv(v / "crosstab_vs_survey.csv")
    out.append(_check("direct weighted 2x2 cross-tab equals R cell estimates", "software check",
                      float(x.abs_diff.max()) <= TOL_ESTIMATE, f"max abs difference {x.abs_diff.max():.2e}", release))
    tv = v / "tables_vs_survey.csv"
    if tv.exists():
        tb = pd.read_csv(tv)
        nse = int(tb.r_se.notna().sum())
        out.append(_check("second implementation reproduces every other reported table", "software check",
                          float(tb.abs_diff_estimate.max()) <= TOL_ESTIMATE and float(tb.rel_diff_se.max()) <= TOL_SE_REL,
                          f"{len(tb)} point estimates (agreement, kappa and ratios, overlap, sensitivity 3, missingness, groups, post hoc, "
                          f"reconciliation), max abs difference {tb.abs_diff_estimate.max():.2e}; {nse} standard errors, "
                          f"max relative difference {tb.rel_diff_se.max():.2e}; kappa and ratio standard errors not recomputed",
                          release))
    dc = json.loads((t / "design_checks.json").read_text())
    out.append(_check("decompositions add up exactly", "software check",
                      dc["max_abs_decomposition_additivity_error"] <= TOL_ADDITIVITY,
                      f"max error {dc['max_abs_decomposition_additivity_error']:.1e}", release))
    out.append(_check("paired SE equals joint-totals SE for same-domain contrasts", "software check",
                      dc["max_abs_se_difference_paired_vs_totals"] <= 1e-12,
                      f"max difference {dc['max_abs_se_difference_paired_vs_totals']:.1e}", release))
    out.append(_check("no singleton strata in the full design or analysis domains", "software check",
                      dc["singleton_strata_full_design"] == 0 and all(x == 0 for x in dc["singleton_strata_by_domain"].values()),
                      f"design df {dc['df_full_design']}; domain df {dc['df_by_domain']}", release))
    rr = t / "reference_reconciliation.csv"
    if rr.exists():
        r = pd.read_csv(rr)
        out.append(_check("sample sizes equal NCHS Data Brief 516", "external reconciliation", bool(r.n_match.all()),
                          f"{int(r.n_match.sum())} of {len(r)}", release))
        pr = r.dropna(subset=["published_percent"])
        if len(pr):
            out.append(_check("percents round to NCHS Data Brief 516 values", "external reconciliation",
                              bool(pr.percent_match.astype(bool).all()), f"{int(pr.percent_match.astype(bool).sum())} of {len(pr)}", release))
            out.append(_check("standard errors round to NCHS Data Brief 516 values", "external reconciliation",
                              bool(pr.se_match.astype(bool).all()), f"{int(pr.se_match.astype(bool).sum())} of {len(pr)}", release))
            n_ci = int(pr.ci_match.astype(bool).sum())
            n_unc = int(pr.ci_match_without_neff_cap.astype(bool).sum())
            out.append(_check("Korn-Graubard intervals reconcile with NCHS Data Brief 516", "external reconciliation",
                              n_unc == len(pr),
                              f"{n_ci} of {len(pr)} match with the effective sample size capped at n as in the NCHS standard; "
                              f"{n_unc} of {len(pr)} match without the cap", release))
    return out


def validate() -> dict:
    sources = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    rows = []
    for release in sources["releases"]:
        if (paths.TABLES / release / "estimates.csv").exists():
            rows += validate_release(release)
    df = pd.DataFrame(rows)
    df.to_csv(paths.VALIDATION / "validation_summary.csv", index=False)
    failed = int((df.status != "pass").sum())
    summary = {"checks": len(df), "passed": int((df.status == "pass").sum()), "failed": failed,
               "kinds": df.groupby("kind").size().to_dict(),
               "independent_expert_validation": "not an automated check; see the manuscript's verification section"}
    (paths.VALIDATION / "validation_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary
