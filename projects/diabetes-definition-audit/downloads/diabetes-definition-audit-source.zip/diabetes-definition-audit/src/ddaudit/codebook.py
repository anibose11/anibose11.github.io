"""Parse NCHS documentation pages (stored snapshots) into codebook records.

Each variable section has an <h3 class="vartitle" id="VAR"> heading, a <dl>
with SAS label, English text and target universe, and a values table with
code or value range, description, and an unweighted count. The counts are
used to reconcile the downloaded data files with the published codebook.
"""

from __future__ import annotations

import html
import re
from pathlib import Path

SECTION_RE = re.compile(r'<h3 class="vartitle" id="([A-Z0-9_]+)">(.*?)</h3>(.*?)(?=<h3 class="vartitle"|\Z)', re.S)
DT_DD_RE = re.compile(r"<dt[^>]*>\s*(.*?)\s*</dt>\s*<dd[^>]*>(.*?)</dd>", re.S)
ROW_RE = re.compile(r"<tr>(.*?)</tr>", re.S)
TD_RE = re.compile(r"<td[^>]*>(.*?)</td>", re.S)
TAG_RE = re.compile(r"<[^>]+>")


def _clean(s: str) -> str:
    return " ".join(html.unescape(TAG_RE.sub(" ", s)).split())


def parse_doc(path: Path) -> dict[str, dict]:
    page = Path(path).read_text(encoding="utf-8", errors="replace")
    out: dict[str, dict] = {}
    for var, title, body in SECTION_RE.findall(page):
        info = {_clean(k).rstrip(":").strip(): _clean(v) for k, v in DT_DD_RE.findall(body)}
        values = []
        tbody = body.split("<tbody>", 1)[1] if "<tbody>" in body else ""
        for row in ROW_RE.findall(tbody):
            cells = [_clean(c) for c in TD_RE.findall(row)]
            if len(cells) >= 3:
                try:
                    count = int(cells[2].replace(",", ""))
                except ValueError:
                    continue
                values.append({"code": cells[0], "description": cells[1], "count": count,
                               "skip_to": cells[4] if len(cells) > 4 else ""})
        out[var] = {
            "variable": var,
            "title": _clean(title),
            "sas_label": info.get("SAS Label", ""),
            "english_text": info.get("English Text", ""),
            "target": info.get("Target", ""),
            "values": values,
        }
    return out


def parse_range(code: str) -> tuple[float, float] | None:
    m = re.fullmatch(r"(-?[\d.]+)\s+to\s+(-?[\d.]+)", code)
    return (float(m.group(1)), float(m.group(2))) if m else None
