"""Acquire stage: download NHANES files by following the official listing links.

For each release in config/sources.yaml the stage
  1. fetches the NCHS component listing page and stores it with a checksum,
  2. finds the row for each target file and reads its documentation link,
     XPT link, and "Date Published" cell,
  3. downloads the documentation page and the XPT file with bounded retries,
  4. rejects anything that is not a SAS transport file (for example an HTML
     error page served with status 200),
  5. records URLs, retrieval time, HTTP headers, sizes, and SHA-256 values in
     source_manifest.json.

Downloads are cached. A cached file is reused only when its SHA-256 matches
the manifest; a mismatch is an error, not a silent re-download.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import html
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path

import yaml

from . import paths

XPT_MAGIC = b"HEADER RECORD*******LIBRARY HEADER RECORD!!!!!!!"
MAX_TRIES = 3
TIMEOUT_S = 60


class AcquireError(RuntimeError):
    pass


def ssl_context() -> ssl.SSLContext:
    """Certificate-verifying context. Uses certifi when installed, else the system bundle."""
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        for cafile in ("/etc/ssl/cert.pem", "/etc/ssl/certs/ca-certificates.crt"):
            if Path(cafile).exists():
                return ssl.create_default_context(cafile=cafile)
        return ssl.create_default_context()


@dataclass
class ListingRow:
    file: str
    description: str
    doc_url: str
    data_url: str
    listed_size: str
    date_published: str


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def fetch(url: str, dest: Path, user_agent: str) -> tuple[Path, dict]:
    """Stream url to <dest>.part with bounded retries.

    Returns the temporary path and response metadata. The caller validates the
    temporary file and only then moves it over dest, so a failed or changed
    download never replaces the analyzed snapshot.
    """
    last_err: Exception | None = None
    tmp = dest.with_suffix(dest.suffix + ".part")
    for attempt in range(1, MAX_TRIES + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": user_agent})
            with urllib.request.urlopen(req, timeout=TIMEOUT_S, context=ssl_context()) as resp, open(tmp, "wb") as out:
                status = resp.status
                headers = {k.lower(): v for k, v in resp.headers.items()}
                while True:
                    chunk = resp.read(1 << 20)
                    if not chunk:
                        break
                    out.write(chunk)
            if status != 200:
                raise AcquireError(f"HTTP {status} for {url}")
            return tmp, {
                "http_status": status,
                "content_type": headers.get("content-type", ""),
                "last_modified": headers.get("last-modified", ""),
                "etag": headers.get("etag", ""),
                "attempts": attempt,
            }
        except (urllib.error.URLError, TimeoutError, AcquireError, ConnectionError) as err:
            last_err = err
            if tmp.exists():
                tmp.unlink()
            time.sleep(2 * attempt)
    raise AcquireError(f"failed after {MAX_TRIES} attempts: {url}: {last_err}")


ROW_RE = re.compile(r"<tr>(.*?)</tr>", re.S | re.I)
CELL_RE = re.compile(r"<td[^>]*>(.*?)</td>", re.S | re.I)
HREF_RE = re.compile(r'href="([^"]+)"', re.I)
TAG_RE = re.compile(r"<[^>]+>")


TH_RE = re.compile(r"<th[^>]*>(.*?)</th>", re.S | re.I)
HEADER_NAMES = {"name": "data file name", "doc": "doc file", "data": "data file", "date": "date published"}


def _column_index(page: str) -> dict[str, int]:
    """Locate columns from the table header; the 2017-2020 pages add a Years column."""
    heads = [" ".join(TAG_RE.sub("", h).split()).lower() for h in TH_RE.findall(page)]
    idx = {}
    for key, label in HEADER_NAMES.items():
        if label in heads:
            idx[key] = heads.index(label)
    if len(idx) == 4:
        return idx
    return {"name": 0, "doc": 1, "data": 2, "date": 3}


def parse_listing(page: str, base_url: str) -> dict[str, ListingRow]:
    """Parse the NCHS data listing table into rows keyed by file name."""
    col = _column_index(page)
    rows: dict[str, ListingRow] = {}
    for row_html in ROW_RE.findall(page):
        cells = CELL_RE.findall(row_html)
        if len(cells) <= max(col.values()):
            continue
        doc_hrefs = HREF_RE.findall(cells[col["doc"]])
        data_hrefs = HREF_RE.findall(cells[col["data"]])
        if not doc_hrefs or not data_hrefs:
            continue
        data_url = urllib.parse.urljoin(base_url, html.unescape(data_hrefs[0]))
        if not data_url.lower().endswith(".xpt"):
            continue
        name = Path(urllib.parse.urlparse(data_url).path).stem
        size_text = TAG_RE.sub("", cells[col["data"]])
        m = re.search(r"\[XPT\s*-\s*([^\]]+)\]", size_text)
        rows[name.upper()] = ListingRow(
            file=name.upper(),
            description=html.unescape(TAG_RE.sub("", cells[col["name"]])).strip(),
            doc_url=urllib.parse.urljoin(base_url, html.unescape(doc_hrefs[0])),
            data_url=data_url,
            listed_size=m.group(1).strip() if m else "",
            date_published=" ".join(TAG_RE.sub("", cells[col["date"]]).split()),
        )
    return rows


def check_xpt(path: Path) -> None:
    with open(path, "rb") as fh:
        head = fh.read(80)
    if not head.startswith(XPT_MAGIC):
        snippet = head[:40].decode("latin-1", "replace")
        raise AcquireError(f"{path.name} is not a SAS transport file (starts with {snippet!r})")
    if path.stat().st_size < 2048:
        raise AcquireError(f"{path.name} is implausibly small ({path.stat().st_size} bytes)")


def check_html(path: Path) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    if "<html" not in text.lower():
        raise AcquireError(f"{path.name} does not look like an HTML page")


def load_manifest() -> dict:
    if paths.MANIFEST.exists():
        return json.loads(paths.MANIFEST.read_text())
    return {"schema": "ddaudit-source-manifest/1", "entries": {}}


def acquire(refresh: bool = False, releases: list[str] | None = None) -> dict:
    cfg = yaml.safe_load((paths.CONFIG / "sources.yaml").read_text())
    ua = cfg["user_agent"]
    manifest = load_manifest()
    entries = manifest.setdefault("entries", {})
    manifest["permitted_use"] = cfg["permitted_use_note"].strip()
    manifest["data_use_url"] = cfg["data_use_url"]
    report = []
    for rel_id, rel in cfg["releases"].items():
        if releases and rel_id not in releases:
            continue
        rel_dir = paths.DATA_RAW / rel_id
        (rel_dir / "listings").mkdir(parents=True, exist_ok=True)
        (rel_dir / "docs").mkdir(parents=True, exist_ok=True)
        components = sorted(set(rel["files"].values()))
        listings: dict[str, ListingRow] = {}
        listing_meta = {}
        for comp in components:
            url = rel["listing_url"].format(component=comp)
            dest = rel_dir / "listings" / f"{comp}.html"
            key = f"{rel_id}/listing/{comp}"
            if dest.exists() and key in entries and not refresh:
                if sha256_file(dest) != entries[key]["sha256"]:
                    raise AcquireError(f"cached listing {dest} does not match manifest")
                report.append({"key": key, "status": "cache verified", "bytes": dest.stat().st_size})
            else:
                tmp, meta = fetch(url, dest, ua)
                try:
                    check_html(tmp)
                except AcquireError:
                    tmp.unlink()
                    raise
                tmp.replace(dest)
                report.append({"key": key, "status": "downloaded", "bytes": dest.stat().st_size})
                entries[key] = {
                    "kind": "listing_page", "release": rel_id, "component": comp, "url": url,
                    "local_path": paths.rel(dest), "retrieved_utc": _now(),
                    "bytes": dest.stat().st_size, "sha256": sha256_file(dest), **meta,
                }
            listing_meta[comp] = url
            listings.update(parse_listing(dest.read_text(encoding="utf-8", errors="replace"), url))
        for fname, comp in rel["files"].items():
            row = listings.get(fname.upper())
            if row is None:
                raise AcquireError(f"{fname} not listed on the {comp} page for {rel_id}")
            for kind, url, dest, checker in (
                ("documentation", row.doc_url, rel_dir / "docs" / f"{fname}.htm", check_html),
                ("data_xpt", row.data_url, rel_dir / f"{fname}.xpt", check_xpt),
            ):
                key = f"{rel_id}/{kind}/{fname}"
                cached = dest.exists() and key in entries and not refresh
                if cached:
                    got = sha256_file(dest)
                    if got != entries[key]["sha256"]:
                        raise AcquireError(f"cached {dest} hash {got} does not match manifest")
                    checker(dest)
                    status = "cache verified"
                else:
                    old = entries.get(key, {}).get("sha256")
                    tmp, meta = fetch(url, dest, ua)
                    try:
                        checker(tmp)
                    except AcquireError:
                        tmp.unlink()
                        raise
                    new = sha256_file(tmp)
                    if old is not None and new != old and not refresh and kind == "data_xpt":
                        tmp.unlink()
                        raise AcquireError(
                            f"{fname}: the file NCHS serves now (sha256 {new[:12]}) differs from the analyzed snapshot "
                            f"({old[:12]}). Results were computed from the snapshot; rerun with --refresh to accept the new file.")
                    tmp.replace(dest)
                    entries[key] = {
                        "kind": kind, "release": rel_id, "release_label": rel["label"],
                        "reference_period": rel["reference_period"], "component": comp,
                        "file": fname, "description": row.description,
                        "listing_url": listing_meta[comp], "url": url,
                        "date_published_on_listing": row.date_published,
                        "listed_size": row.listed_size if kind == "data_xpt" else "",
                        "local_path": paths.rel(dest), "retrieved_utc": _now(),
                        "bytes": dest.stat().st_size, "sha256": new, **meta,
                    }
                    status = "downloaded" if old is None else ("unchanged" if old == new else "CHANGED")
                report.append({"key": key, "status": status, "bytes": dest.stat().st_size})
    manifest["updated_utc"] = _now()
    paths.MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    return {"files": report}
