"""Command-line entry point: python -m ddaudit <stage> [options]."""

from __future__ import annotations

import argparse
import json
import sys

from . import paths


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="ddaudit", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("acquire", help="download or verify cached NHANES files")
    a.add_argument("--refresh", action="store_true", help="re-download and report changed hashes")
    a.add_argument("--release", action="append", help="limit to one release id (repeatable)")
    sub.add_parser("build", help="read XPT files, check joins, build the analytic frame and phenotypes")
    sub.add_parser("analyze", help="check configurations, run survey estimation in R, direct cross-tabs")
    sub.add_parser("validate", help="reconcile outputs with source aggregates and a second implementation")
    sub.add_parser("render", help="figures, workbook, exports, claims, report, manuscript")
    sub.add_parser("pipeline", help="build, analyze, validate, render from cached inputs")
    c = sub.add_parser("check-config", help="check a phenotype/domain/weight combination")
    c.add_argument("--phenotype")
    c.add_argument("--domain")
    c.add_argument("--weight")
    c.add_argument("--release", default="2021-2023")
    c.add_argument("--file", help="YAML file with one or more configurations")
    c.add_argument("--list", action="store_true", help="list phenotypes, domains, and allowed weights")
    sub.add_parser("demo", help="run the miniature synthetic fixture end to end (no download)")
    s = sub.add_parser("snapshot", help="copy substantive outputs to a directory for comparison")
    s.add_argument("dest")
    k = sub.add_parser("compare", help="compare two snapshots within the declared tolerance")
    k.add_argument("left")
    k.add_argument("right")
    k.add_argument("--tol", type=float, default=1e-9)
    args = ap.parse_args(argv)
    paths.ensure_dirs()

    if args.cmd == "acquire":
        from .acquire import acquire
        _print(acquire(refresh=args.refresh, releases=args.release))
    elif args.cmd == "build":
        from .build import build
        _print(build())
    elif args.cmd == "analyze":
        from .analyze import analyze
        _print(analyze())
    elif args.cmd == "validate":
        from .validate import validate
        res = validate()
        _print(res)
        return 0 if res.get("failed", 0) == 0 else 1
    elif args.cmd == "render":
        from .render import render
        _print(render())
    elif args.cmd == "pipeline":
        from .analyze import analyze
        from .build import build
        from .render import render
        from .validate import validate
        out = {"build": build(), "analyze": analyze(), "validate": validate(), "render": render()}
        _print({k: (v if k != "build" else {"rows": v.get("rows")}) for k, v in out.items()})
        return 0 if out["validate"].get("failed", 0) == 0 else 1
    elif args.cmd == "check-config":
        from .checker import cli_check
        return cli_check(args)
    elif args.cmd == "demo":
        from .demo import demo
        return demo()
    elif args.cmd == "snapshot":
        from .repro import snapshot
        _print(snapshot(args.dest))
    elif args.cmd == "compare":
        from .repro import compare
        res = compare(args.left, args.right, args.tol)
        _print(res)
        return 0 if res["identical_within_tolerance"] else 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
