"""Fast demo on the synthetic fixture (no download, no real data needed).

It copies the configuration and the labeled fixture into .demo/, runs the real
build SQL and the real R estimation there, checks the named boundary cases, runs
the configuration checker on refused requests, and then prints the saved
real-data headline results if they exist. The fixture run is not evidence that
the study ran; the real results come from `make pipeline`.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys

import pandas as pd

from . import paths

# SEQN: expected (in_a, in_p, a1c65, fpg126, dx, in_p_narrow, narrow_status, dx_treated); None = not checked
EXPECTED = {
    101: (True, True, 0, 0, None, True, "meets_narrow_rule", None),
    102: (True, True, 1, 1, None, True, "meets_narrow_rule", None),
    103: (True, True, 1, 0, None, True, "meets_narrow_rule", None),
    104: (True, True, 0, 1, None, True, "meets_narrow_rule", None),
    105: (False, False, None, None, None, False, None, None),
    106: (False, False, None, None, None, False, None, None),
    107: (True, None, None, None, None, None, None, None),
    108: (False, False, None, None, None, False, None, None),
    109: (True, None, None, None, 0, None, None, None),
    110: (True, False, None, None, None, False, None, None),
    111: (True, False, None, None, None, False, None, None),
    112: (True, False, None, None, None, False, None, None),
    113: (True, False, None, None, None, False, None, None),
    114: (True, False, None, None, None, False, None, None),
    115: (False, False, None, None, None, False, None, None),
    116: (False, False, None, None, None, False, None, None),
    117: (True, True, None, None, None, False, "intake_within_window", None),
    118: (True, True, 0, 0, 1, True, "meets_narrow_rule", 1),
    119: (True, True, None, None, None, False, "unknown", None),
    120: (True, None, None, None, 1, None, None, "unknown"),
    121: (True, None, None, None, 1, None, None, 0),
}


def demo() -> int:
    root = paths.CODE_ROOT / ".demo"
    if root.exists():
        shutil.rmtree(root)
    (root / "data" / "raw" / "2021-2023").mkdir(parents=True)
    shutil.copytree(paths.CODE_ROOT / "config", root / "config")
    (root / "docs").mkdir()
    shutil.copy2(paths.CODE_ROOT / "docs" / "analysis_plan.md", root / "docs" / "analysis_plan.md")
    for f in (paths.FIXTURES / "mini" / "2021-2023").glob("*.fixture.csv"):
        shutil.copy2(f, root / "data" / "raw" / "2021-2023" / f.name)
    env = {**os.environ, "DDAUDIT_ROOT": str(root), "PYTHONPATH": str(paths.CODE_ROOT / "src")}
    print("SYNTHETIC FIXTURE DEMO (invented values, not NHANES data)\n")
    for stage in ("build", "analyze"):
        res = subprocess.run([sys.executable, "-m", "ddaudit", stage], env=env, capture_output=True, text=True)
        if res.returncode != 0:
            print(res.stdout[-2000:], res.stderr[-4000:])
            return 1
        print(f"  stage {stage}: ok")
    a = pd.read_parquet(root / "data" / "interim" / "2021-2023" / "analytic.parquet").set_index("seqn")
    bad = []
    for seqn, exp in EXPECTED.items():
        r = a.loc[seqn]
        in_a, in_p, a1c, fpg, dx, narrow, nstatus, treated = exp
        tr = "unknown" if pd.isna(r.dx_treated) else int(r.dx_treated)
        got = (bool(r.in_a), bool(r.in_p) if in_p is not None else None,
               None if a1c is None or pd.isna(r.a1c65) else int(r.a1c65),
               None if fpg is None or pd.isna(r.fpg126) else int(r.fpg126),
               None if dx is None or pd.isna(r.dx) else int(r.dx),
               None if narrow is None else bool(r.in_p_narrow),
               None if nstatus is None else r.narrow_status,
               None if treated is None else tr)
        if got != exp:
            bad.append((seqn, exp, got))
    print(f"  boundary cases checked: {len(EXPECTED)}, mismatches: {len(bad)}")
    for b in bad:
        print("    MISMATCH", b)
    est = pd.read_csv(root / "results" / "tables" / "2021-2023" / "estimates.csv")
    print("\n  Fixture estimates (software check only; every row is suppressed or flagged because n < 30 or tiny):")
    print(est[["config_id", "phenotype", "domain", "weight", "n_unweighted", "estimate", "nchs_status"]].to_string(index=False))
    cc = json.loads((root / "results" / "tables" / "2021-2023" / "config_check.json").read_text())
    print(f"\n  Configuration checker: {len(cc['refused_examples'])} invalid requests, all refused: {cc['all_examples_refused']}")
    real = paths.CODE_ROOT / "results" / "tables" / "2021-2023" / "estimates.csv"
    if real.exists():
        e = pd.read_csv(real).set_index("config_id")
        c = pd.read_csv(paths.CODE_ROOT / "results" / "tables" / "2021-2023" / "contrasts.csv").set_index("contrast_id")
        print("\nSaved real-data results (from the full pipeline run, results/tables/2021-2023):")
        for k in ("K1", "K2", "K3", "K6"):
            x = e.loc[k]
            print(f"  {k} {x.phenotype:14s} {x.domain:2s} {x.weight:9s} n={x.n_unweighted:5d}  "
                  f"{100 * x.estimate:5.1f}% ({100 * x.ci_low:.1f} to {100 * x.ci_high:.1f})")
        for k in ("C1", "C2"):
            x = c.loc[k]
            print(f"  {k} {x.label}: {100 * x.estimate:+.2f} points ({100 * x.ci_low:+.2f} to {100 * x.ci_high:+.2f})")
    else:
        print("\nNo real-data results found. Run `make acquire` and `make pipeline` for the study results.")
    return 0 if not bad and cc["all_examples_refused"] else 1
