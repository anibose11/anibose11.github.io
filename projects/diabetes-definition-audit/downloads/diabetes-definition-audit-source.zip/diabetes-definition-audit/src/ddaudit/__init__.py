"""Diabetes definition audit: NHANES phenotype, denominator, and weight checks."""

__version__ = "1.0.0"
PHENOTYPE_SPEC_VERSION = "1.0.0"
