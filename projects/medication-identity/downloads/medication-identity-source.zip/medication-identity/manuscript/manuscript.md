# Version-aware medication identity from DailyMed labels to FHIR R4: attribute-level round-trip fidelity and the cost of common shortcuts

Animesh Bose

Norlowe Research

## Abstract

**Objectives:** To measure which identity and strength attributes of US prescription drug labels are preserved when the labels are converted to Fast Healthcare Interoperability Resources Release 4 (FHIR R4) Medication resources or handled with common shortcuts, how name-based matching agrees with a National Drug Code (NDC) crosswalk to RxNorm, and how often label versions change product identity.

**Materials and Methods:** All 1,475 current DailyMed prescription labels containing metformin, empagliflozin, dapagliflozin, semaglutide, liraglutide, one of seven insulins, atorvastatin or lisinopril were retrieved with the preceding version of 218 labels (2,803 product-version records). Labels were parsed into a lossless PostgreSQL layer, written as FHIR R4 resources with a schema-validated companion record, validated, and read back against a separate parse of the source XML on 1,036 held-out labels.

**Results:** FHIR plus the companion record preserved every applicable critical attribute for 1,965 of 1,965 held-out records. Read from FHIR core elements alone, 670 of 2,392 active ingredients (28.0%) took the wrong basis-of-strength substance. Padding NDCs without their segment pattern changed 91.2% of codes. DailyMed's packaging service gave the wrong ingredient count for 51.5% of products. Approximate name matching disagreed with the crosswalk for 15.4% of its answers, and 15.1% of 218 sampled label version pairs changed product identity.

**Discussion:** R4 Medication has no element for a label's set identifier, version number or basis of strength, and common shortcuts lose NDC segment patterns, label versions and per-product strengths.

**Conclusion:** A reversible R4 representation of drug labels needs a documented companion record for these attributes.

## Lay summary

Drug labels published by the US government describe each medicine's ingredients, strengths, forms and package codes. Research databases and drug dictionaries copy these details into other formats, often through shortcuts such as reformatting package codes or keeping only the newest label. This study took every current prescription label for a set of diabetes, cholesterol and blood-pressure medicines, converted them into a widely used health-data format (FHIR), converted them back, and checked each detail against the original label. When the conversion included a small companion record, every critical detail came back intact. Without it, the standard format could not say whether a stated strength refers to the salt form of a drug or to the active part of the molecule, which affected more than a quarter of active ingredients. Simple package-code padding changed nine in ten codes. Treating a label-level web service as a source of product-specific ingredients gave the wrong ingredient count for about half the products. About one in seven of the 218 labels checked changed product details between versions. These findings concern how the data are handled. They say nothing about the safety or effectiveness of any medicine, and no patient information was used.

## Background and significance

Research data managers and maintainers of medication dictionaries build product tables from the US Food and Drug Administration (FDA) Structured Product Labeling (SPL) documents, which the National Library of Medicine (NLM) publishes through DailyMed, and from RxNorm, NLM's normalized naming system for clinical drugs [1,2]. These tables feed analysis databases and Health Level Seven (HL7) Fast Healthcare Interoperability Resources (FHIR). Each step invites shortcuts: an 11-digit National Drug Code (NDC) built by stripping hyphens and padding with zeros, a product collapsed to one RxNorm concept, a label read only in its latest version, strengths parsed as binary floating-point numbers, or attributes dropped because the FHIR Release 4 (R4) Medication resource has no element for them [3].

Earlier work established high identifier linkage, but also showed that coverage and attribute agreement depend on how the lookup is done. Zhu, Jiang and Chute linked 97.0% of 36,568 DailyMed labels to RxNorm, mostly at the ingredient level [4]. Schadow found that SPL and RxNorm agreed on ingredient moieties for 91% of 7,083 SPL NDCs after converting NDCs to 11 digits [5]. Peters and Bodenreider built a dated NDC history from monthly RxNorm releases and showed that, in two historical medication datasets, current-release lookups left 22% and 33% of NDCs unknown, against 2.4% and 3.3% with the history. The work informed the design of RxNorm's NDC status function [6]. 

NLM's terminology status services map obsolete codes to current concepts [7], and RxNorm concept unique identifier (RxCUI) remapping, splits and NDC reuse are documented [8,9]. In e-prescribing, strength agreed exactly with RxNorm attributes reached through NDCs in 51.23% of pairs [10], and NDC and RxCUI disagreement has been measured [11,12]. Tools that map medication names to RxNorm have been compared [13], and normalization pipelines continue to appear [14,15]. 

For FHIR representation, HL7 maintains an unpublished SPL-to-FHIR R5 mapping guide with transforms in both directions [16], and a natural language processing pipeline into FHIR reported F scores for Medication elements and assigned a default strength denominator of 1 [17]. In the Observational Health Data Sciences and Informatics (OHDSI) Standardized Vocabularies, 68% of drug-domain mappings from source codes to standard concepts are many-to-one [18].

The studies reviewed did not report, attribute by attribute, which identity and strength attributes are preserved when a specific label version is carried into FHIR R4 and back, or what each common shortcut loses on the same records.

## Objective

This study measured which identity and strength attributes survive a round trip through FHIR R4 Medication resources, with and without a companion record. It included all current US prescription labels containing selected ingredients in six cardiometabolic groups. On the same records, it measured losses from common shortcuts, compared three matching approaches with an NDC-based RxNorm crosswalk, and assessed product-identity changes between label versions. It updates the SPL-to-RxNorm linkage literature on a 2026 snapshot and adds label versions, a measured FHIR R4 round trip and a reusable dictionary export.

## Materials and methods

### Study design and analysis plan

This was a secondary analysis of publicly available drug-labeling and terminology records. It used no patient or personal data and recruited no participants, so no ethics approval was required, and none was sought. The analysis plan, eligibility rules and outcome definitions were committed to the project's version history before the corpus was retrieved (docs/analysis_plan.md). The plan was not publicly registered. Label set IDs were assigned to development (30%) and held-out (70%) splits by a salted SHA-256 rule before any tuning. Matching rules were tuned on development products only and frozen before the held-out evaluation. Later changes to comparison code, FHIR display text, the version comparison and one parser rule are listed as amendments in the plan. None changed a matching rule, and the affected stages were rerun.

### Sources and scope

DailyMed web services were queried on October 7, 2026 [2]. The seed ingredients were metformin; the sodium-glucose cotransporter 2 (SGLT2) inhibitors empagliflozin and dapagliflozin; the glucagon-like peptide-1 (GLP-1) receptor agonists semaglutide and liraglutide; insulin glargine, lispro, aspart, degludec and detemir and regular and isophane human insulin; atorvastatin; and lisinopril. Candidate labels came from DailyMed's filter on active-moiety Unique Ingredient Identifiers (UNIIs) and from name searches, restricted to human prescription drug labels. The 20 UNIIs were taken from RxNorm for each seed ingredient and its precise forms and frozen before labels were read. A label was eligible when its own XML had document type 34391-3 and a product or kit part had an active ingredient whose substance or moiety UNII was in the frozen set. Combination products were kept whole. Of 1,482 candidates, 1,475 were eligible; 7 legacy-format labels from 2006 to 2008 had no product data section and could not meet the rule. Human regular, isophane and 70/30 insulins sold without a prescription are over-the-counter (OTC) labels, outside this scope.

For up to 40 labels per ingredient group, chosen by a salted hash among the 964 eligible labels listing two or more versions (from all 19 such GLP-1 labels to 40 of 343 metformin labels), the immediately preceding available version was downloaded from DailyMed's archive and checked for set ID and version number. Shares from this equal-allocation sample are unweighted. All 218 were retrieved; 180 were exactly one version older. RxNorm was queried through its public application programming interface (API; release of October 5, 2026) [19] at no more than 8 requests per second, under the limit of 20 in the RxNav terms of service [20]; every response was cached with its retrieval time and SHA-256.

### Canonical layer and NDC handling

The product data section of each label was parsed with every identity value kept as written: product and package NDCs with their hyphenation, ingredient UNIIs, the ingredient class code that states the basis of strength (ACTIB, the ingredient itself; ACTIM, its active moiety; ACTIR, a reference substance), strength numerator and denominator as decimal text with their units, dosage form, routes, the package tree with each level's quantity, marketing data and kit parts [21]. The layer was loaded into PostgreSQL 17 with checks on row counts, join cardinality and source file hashes; 13 of 13 checks passed. An NDC was converted to 11 digits only through its own segment pattern (4-4-2, 5-3-2 or 5-4-1) [22].

### Matching approaches

Approach A, the reference, looked up each package NDC with RxNorm's NDC status service and assigned the product the single RxCUI its ACTIVE packages shared. Approach A2 checked agreement with DailyMed's set-level SPL-to-RxNorm mapping file, which lists RxCUIs per label but not per product. Approach B compared the label's basis-of-strength substance names, normalized by fixed rules, and its strength, dose form, fill volume and brand with the structure RxNorm gives for each candidate concept. Approach C scored the label's name, strength and form text against all 28,724 current RxNorm clinical and branded drug and pack names with a token-sort ratio and abstained below a threshold of 74, chosen by a prespecified grid search on the development split. Agreement with approach A is agreement between terminologies. It says nothing about clinical interchangeability.

### FHIR representation

Each label version became one FHIR R4 (4.0.1) Bundle holding a product-level Medication per in-scope product, a package-level Medication per package NDC, and a Provenance resource naming the source document by its SPL document ID. Package NDCs went into Medication.code exactly as labeled, with an RxNorm coding added when approach A gave a single RxCUI. Product NDCs went into Medication.identifier, the dosage form into Medication.form with its NCI Thesaurus code, ingredients with their UNIIs and isActive flags, strengths as Ratios written with the label's exact decimal text, package contents (multiplied exactly through the package tree) into Medication.amount, and kit parts as contained Medications. 

Medication.manufacturer and Medication.status were left empty because the SPL labeler can be a repackager and SPL marketing status is not dictionary use status. Attributes with no R4 Medication element (set ID, version, basis-of-strength code and substance, routes, package hierarchy, marketing and application data) went into a companion record per Bundle (the "sidecar" in Table 2 and Figure 1), keyed by Medication.id and validated against a JSON Schema. The HL7 validator 7.0.0 [23] checked all Bundles with terminology checks off and a fixed sample of 60 against the public terminology server.

### Round trip and comparison representations

A reverse transform read the stored Bundles and companion records and reconstructed the critical attributes: set ID, document ID, version, product NDC, package NDCs, dosage form, number of active ingredients, and for each active ingredient its UNII, basis-of-strength code and substance and the strength numerator and denominator with units, plus kit part NDCs. The comparison target was a second, separately written reader of the source XML. Each field was classed as preserved, preserved after a documented normalization (the JSON number grammar and lowercase FHIR UUIDs), equal only after a documented conversion, held only in the companion record, unresolved, discordant, or inapplicable when the label does not state it. The same comparison was run for FHIR core elements alone, read the only way R4 Medication allows (a strength refers to the listed ingredient); for an RxCUI-only record re-derived from current RxNorm; for a flat export holding the set ID, package NDCs stripped of hyphens and left-padded to 11 digits, the dosage form as text and float strengths of the first active ingredient only; for DailyMed's packaging service; and, for preceding versions, for the latest version of the same label. Shares of identity and strength fields cover the critical attributes other than set ID, document ID and version.

### Outcomes and statistics

The primary outcome was the proportion of held-out product-version records for which every applicable critical attribute was preserved from FHIR plus the companion record. Results describe this finite corpus at the retrieval date. As an exploratory measure, 95% intervals came from a cluster bootstrap over set IDs (2,000 replicates). Prespecified sensitivity analyses repeated the primary outcome on the full corpus and without repackaged products, evaluated package-level attributes (package NDC, containing product NDC, package form, quantity, and marketing status and start date) at package-version grain, and moved approach C's threshold 5 points down and up. Results are also reported for version, kit and combination subgroups.

### Verification

Software checks comprised 60 automated tests on constructed edge cases, 13 database reconciliation checks, JSON Schema validation of every companion record, the HL7 validator, and a repeat of every deterministic stage from the cached inputs, which reproduced 3,430 of 3,430 output files exactly. I then checked the work by hand, separately from the software checks. For a stratified random sample of 30 held-out product records from 28 labels (five per ingredient group, drawn by a salted hash), I compared the recorded product and package NDCs, active ingredients, strengths, stated basis of strength and dosage form with the corresponding DailyMed label pages, recomputed the primary outcome, the FHIR-core basis-of-strength misreads and the NDC padding changes from the supplementary tables, checked the figures quoted from the cited sources, and reviewed the figures, tables and text. No discrepancies were found. A separately written script downloaded the 28 sampled labels again on October 7, 2026 and found none changed since retrieval.

## Results

### Corpus

The 1,475 eligible labels held 2,386 in-scope products in their current versions and 417 in the 218 preceding versions (Table 1). Of the 2,386 current products, 2,017 were marketed under abbreviated new drug applications (ANDAs), 205 under new drug applications (NDAs), 113 under biologics license applications (BLAs) and 46 as NDA authorized generics; 4 were marketed as unapproved drugs and 1 was listed as export only. Of 2,803 product records, 1,589 (56.7%) declared a source product, which marks repackaged or relabeled products, and 483 current products had two or more active ingredients. Of 3,384 active-ingredient records, 964 (28.5%) stated strength for the active moiety; none used a reference substance.

**Table 1.** Eligible labels and in-scope products in current versions, by primary ingredient group (a combination product is counted once, in the first of: insulin, GLP-1, SGLT2, atorvastatin, lisinopril, metformin).

| Primary ingredient group | Current labels | In-scope products (current) |
|---|---:|---:|
| Metformin | 541 | 808 |
| Atorvastatin | 405 | 668 |
| Lisinopril | 376 | 606 |
| Insulins (seven seed insulins) | 69 | 129 |
| SGLT2 inhibitors (empagliflozin, dapagliflozin) | 54 | 115 |
| GLP-1 receptor agonists (semaglutide, liraglutide) | 30 | 60 |
| Total | 1,475 | 2,386 |

*Abbreviations:* GLP-1, glucagon-like peptide-1; SGLT2, sodium-glucose cotransporter 2.

Insulin strengths stated in units of activity were coded in three different Unified Code for Units of Measure (UCUM) units across labels: 161 ingredient records used international units ([iU]), 35 used U, which UCUM defines as the unit of catalytic activity (1 µmol/min) [24], and 24 used arbitrary units ([arb'U]).

### Validation

The HL7 validator reported no errors in any of the 1,693 Bundles with terminology checks off. Its warnings concerned code systems it could not check offline and missing narrative text. Against the public terminology server, the 60 sampled Bundles produced 164 errors, all for NDCs absent from the server's NDC content, which is dated November 1, 2021, and 157 warnings for NDCs it lists as inactive; none of the 300 RxNorm, 4,401 UNII, 750 NCI Thesaurus or 1,507 UCUM codings was rejected. The sampled UCUM codings included [iU] and U but no [arb'U]. Passing validation shows structural conformance. It does not show that a code means what the label means.

### Round trip

FHIR plus the companion record reconstructed every applicable critical attribute for 1,965 of 1,965 held-out product-version records from 1,036 labels (100%; bootstrap interval degenerate at 100%), and for 2,803 of 2,803 across the whole corpus. One strength value needed the documented normalization because the label's XML attribute contained stray whitespace. The held-out result was the same for current and preceding versions, 11 kit records, 417 combination-product records and the 860 records that were not repackaged. At package-version grain, FHIR plus the companion record preserved every applicable package attribute for 5,130 of 5,130 held-out package records. FHIR core kept the package and product NDCs but not the package form, quantity or marketing data. Development-split runs and a constructed test document found faults in the reverse transform and the comparison code, all fixed before the held-out run. Two faults found after it were corrected, and the affected stages rerun, before results were reported: the FHIR writer put label substance names in UNII display text (found by the terminology-enabled validator), and both readers left the basis-of-strength substance empty for 10 atorvastatin ingredient records (6 held-out) whose labels list the same active moiety twice.

Without the companion record, FHIR core elements kept 87.6% of applicable identity and strength fields (Figure 1, Table 2). NDCs, dosage form, UNIIs and exact strength text all survived, and the Provenance resource carried the SPL document ID for every record. Every loss counted in Figure 1 concerned basis of strength. R4 Medication has no element for the basis-of-strength code, and reading a strength as referring to the listed ingredient gave the wrong substance for 670 of 2,392 held-out active ingredients (28.0%), all of them moiety-basis strengths such as atorvastatin calcium tablets labeled by their atorvastatin content. The set ID and version number, which these shares exclude, were also absent from FHIR core.

![Figure 1](../outputs/figures/fig1_representations.svg)

**Figure 1.** Share of applicable identity and strength fields (the critical attributes other than set ID, document ID and version) preserved by each representation, held-out records: 1,965 product-version records from 1,036 labels for FHIR with the sidecar, FHIR core and the flat export, the 1,662 current-version records for RxCUI only and the DailyMed packaging service, and the 303 preceding-version records for the latest version. Filled dots, preserved exactly; rings, preserved exactly or after a documented conversion. Abbreviations: FHIR, Fast Healthcare Interoperability Resources; RxCUI, RxNorm concept unique identifier.

**Table 2.** Share of applicable fields preserved exactly (or after the documented normalization), held-out product-version records, by representation. "conv." is the additional share equal only after a documented conversion; "sidecar" marks attributes that only the companion record holds. For the flat export, package NDCs are compared in 11-digit form.

| Attribute | FHIR + sidecar | FHIR core | RxCUI only | DailyMed packaging service | Flat export |
|---|---:|---:|---:|---:|---:|
| SPL set ID | 100.0% | 0.0% (sidecar) | 0.0% | 0.0% | 100.0% |
| SPL document ID | 100.0% | 100.0% | 0.0% | 0.0% | 0.0% |
| SPL version number | 100.0% | 0.0% (sidecar) | 0.0% | 0.0% | 0.0% |
| Product NDC as written | 100.0% | 100.0% | 0.0% | 99.9% | 0.0% |
| Package NDCs as written | 100.0% | 100.0% | 0.0% | 99.7% | 14.2% |
| Dosage form code | 100.0% | 100.0% | 0.0% | 0.0% | 0.0% (+100.0% conv.) |
| Number of active ingredients | 100.0% | 100.0% | 76.5% | 48.4% | 78.8% |
| Ingredient UNII | 100.0% | 100.0% | 0.0% | 0.0% | 0.0% |
| Basis-of-strength code | 100.0% | 0.0% (sidecar) | 0.0% (+73.4% conv.) | 0.0% | 0.0% |
| Basis-of-strength substance | 100.0% | 72.0% | 0.0% (+75.3% conv.) | 0.0% | 0.0% |
| Strength numerator value | 100.0% | 100.0% | 76.0% (+0.8% conv.) | 67.1% | 7.3% |
| Strength denominator value | 100.0% | 100.0% | 76.6% (+0.7% conv.) | 5.7% | 0.8% |

*Abbreviations:* FHIR, Fast Healthcare Interoperability Resources; NDC, National Drug Code; RxCUI, RxNorm concept unique identifier; SPL, Structured Product Labeling; UNII, Unique Ingredient Identifier; n/a, not applicable.

An RxCUI-only record kept 20.9% of fields exactly and 50.3% after documented conversion. Of 1,662 held-out current products, 377 had no unique RxCUI to start from. The record carried no package NDCs, dosage form codes or UNIIs, because a concept cannot say which of its NDCs belong to one label's product and UNIIs were not re-derived here. RxNorm named the same basis-of-strength substance as the label for 1,518 active ingredients and a different one for 41. An SPL class code derived from RxNorm's structure agreed with the label's for 1,479 and differed for 80, although the basis substance agreed in all 80. RxNorm and the label differ in whether the salt or the moiety is the active ingredient. Strength differed for 12: 11 premixed insulins that labels describe as one ingredient at 100 units/mL and RxNorm as two (for example 70 and 30 units/mL), and a semaglutide pen whose 1.7 mg per 0.75 mL RxNorm states as 2.27 mg/mL, a rounded value from which the label's ratio cannot be recovered.

The flat export kept 24.2% of fields exactly. Padding NDCs without their segment pattern changed 5,759 of 6,316 distinct package NDCs in current labels of both splits (91.2%), comprising every 5-3-2 and 5-4-1 code and no 4-4-2 code; none of the changed codes coincided with another NDC in the corpus. Keeping the first ingredient truncated 417 combination-product records. Float parsing kept every value it carried but rewrote the text of 1,790 of those 1,965 numerators (91.1%; 500 became 500.0); only 3 strengths in the corpus stated precision with trailing zeros, so lost precision was rare here.

DailyMed's packaging service kept 37.2% of fields. It attaches every strength in a label to every product of that label, so 856 of 1,662 held-out products (51.5%) had the wrong number of active ingredients and 661 of 2,015 active ingredients (32.8%) received another product's strength when read in the order given.

For preceding-version records, the latest version of the same label kept 98.6% of identity and strength fields, and all of them for 280 of 303 held-out records.

### Matching

Approach A found a unique RxCUI for 1,285 of 1,662 held-out current products (77.3%); for the other 377, RxNorm listed none of the product's package NDCs as active (Table 3). Repackaged products made up most of these misses: 306 of 1,002 held-out repackaged products had no active NDC, against 71 of 660 other products. In all, 707 package NDCs that their current label marks as actively marketed were obsolete in RxNorm. DailyMed's set-level file listed approach A's RxCUI for 1,269 of 1,270 checkable products and did not list the analyzed version of 10 held-out labels (26 products).

**Table 3.** Matching approaches on current-version products, by split.

| Measure | Development | Held-out |
|---|---:|---:|
| Current-version products | 724 | 1,662 |
| A: unique RxCUI from package NDCs | 576 | 1,285 |
| A: no package NDC active in RxNorm | 148 | 377 |
| A2: DailyMed set-level file agrees with A | 572 of 572 | 1,269 of 1,270 |
| B: answered (of A unique) | 492 | 1,104 |
| B: same RxCUI as A | 484 | 1,095 |
| B: different RxCUI | 8 | 9 |
| B: several candidates / none | 68 / 16 | 115 / 66 |
| C: answered (score 74 or more) | 222 | 565 |
| C: same RxCUI as A | 190 | 478 |
| C: different RxCUI | 32 | 87 |
| C top candidate without abstention, same as A | 240 | 570 |

*Notes:* A, package-NDC crosswalk through RxNorm's NDC status service; A2, DailyMed's set-level SPL-to-RxNorm mapping file; B, normalized basis-of-strength substance names with strength, dose form, fill volume and brand; C, approximate name matching (token-sort ratio). *Abbreviations:* NDC, National Drug Code; RxCUI, RxNorm concept unique identifier.

Among products with a unique approach-A RxCUI, approach B answered 1,104 of 1,285 (85.9%) and agreed for 1,095 of its answers (99.2%); 115 were ambiguous and 66 had no match (Figure 2). Most ambiguity came from attributes that labels do not state in structured form: 87 of the 115 ambiguous products were extended-release metformin, whose RxNorm concepts differ only in release mechanism, and insulin pens differ in dose increment or sensor connectivity. Approach B's dose-form rules also admitted vial concepts for some pen packages. Of the 66 products without a candidate, 37 were insulins and 7 were kits. Approach C answered 565 and disagreed with approach A for 87 (15.4%); taking its top candidate without abstention matched approach A for 570 of 1,285 (44.4%). Moving approach C's threshold 5 points down (69) or up (79) gave 799 answers with 263 disagreements (32.9%) or 214 answers with 27 (12.6%).

![Figure 2](../outputs/figures/fig2_matching.svg)

**Figure 2.** Name-based matching against the package-NDC crosswalk, the 1,285 held-out current products with a unique crosswalk RxCUI. Abbreviations: NDC, National Drug Code; RxCUI, RxNorm concept unique identifier.

### Label versions

Between the preceding and the latest version, 33 of 218 sampled label pairs (15.1%) changed at least one identity attribute (Table 4): 23 added package NDCs, 3 removed package NDCs from retained products, 5 added and 4 removed product NDCs, and 1 changed an active ingredient substance or its basis. No strength or dosage form changed. Weighted by each group's number of labels listing two or more versions, the share was 18.6%. Labeler names changed in 11 labels, 2 of them only in letter case or punctuation. Of the 13 package NDCs that disappeared from 6 labels (7 within retained products and the rest with removed products), RxNorm now lists 8 as obsolete, 4 as active and 1 as alien (held only in a source vocabulary other than RxNorm).

**Table 4.** Product-identity changes between the immediately preceding available version and the latest version, sampled labels.

| Change between preceding and latest version | Labels | Share |
|---|---:|---:|
| Any product-identity change | 33 | 15.1% |
| Package NDCs added | 23 | 10.6% |
| Package NDCs removed | 3 | 1.4% |
| Product NDCs added | 5 | 2.3% |
| Product NDCs removed | 4 | 1.8% |
| Active ingredient or basis of strength changed | 1 | 0.5% |
| Strength changed | 0 | 0.0% |
| Dosage form changed | 0 | 0.0% |
| Labeler name changed | 11 | 5.0% |
| Label pairs compared | 218 | |

*Notes:* Package NDCs removed counts removals within products present in both versions. *Abbreviation:* NDC, National Drug Code.

## Discussion

### Principal findings

A FHIR R4 representation of drug labels was fully reversible for these attributes when a companion record held what R4 Medication cannot express. An extension-based design was not tested. The two attributes with the largest consequences are label provenance and basis of strength. R4 Medication has no element for the SPL set ID or version number. The Provenance resource carried the SPL document ID, which identifies one label version, but linking and ordering the versions of a label needs the set ID and version number, which only the companion record held. A dictionary that cannot say which label version it came from cannot be audited when labels change, and about one in seven sampled labels changed product identity between consecutive versions. R4 Medication also has no element for basis of strength. More than a quarter of active ingredients in this corpus state strength for the active moiety, and a consumer reading the R4 resource as written would take the strength to refer to the salt. FHIR's regulated-product resources can state the basis: R4's MedicinalProductIngredient, at maturity level 0, has a strength expressed in terms of a reference substance [25], and FHIR R5's Ingredient resource has a strength basis "based on the ingredient substance as stated or on the substance base (when the ingredient is a salt)" [26]. The HL7 SPL mapping guide targets R5 [16]; US Core, the national US profile set, is built on R4 [27].

### Comparison with earlier work

The identifier crosswalk and DailyMed's own set-level mapping agreed almost completely where both applied (1,269 of 1,270), consistent with high SPL-to-RxNorm linkage reported earlier [4,5]. Coverage remained incomplete. About a fifth of current products, mostly repackaged ones, had no NDC that RxNorm considers active, although many of their labels mark the package as marketed. This mirrors Peters and Bodenreider's finding that current-only NDC lookups fail for a large share of codes [6]. Attribute matching that respects basis of strength agreed with the crosswalk for 99.2% of its answers, against 84.6% for approximate names. On a local medication terminology, RxNorm's approximate match reached a drug-name F1 score of 90% [13]. Approach B's ambiguous answers mostly involve attributes that SPL product data does not carry in structured form, such as release mechanism and pen dose increment. Its unmatched products, mostly insulins, reflect its rules or how RxNorm models them. Lester and colleagues found strength and dose form disagreement between prescription text and RxNorm [10]; this study shows that some disagreement arises before any text is written, in how labels and RxNorm structure the same product (premixed insulins, rounded per-mL strengths, unit codes).

### Implications for dictionary maintainers

The nine-in-ten error rate from naive padding supports keeping NDCs hyphenated and deriving the 11-digit form from the segment pattern. Segment-aware handling will also be needed for FDA's move to a uniform 12-digit NDC from 2033 [28]. A product row needs its label set ID and version, and each strength needs its basis code and substance. For labels containing multiple products, DailyMed's packaging service does not provide reliable per-product strengths. Insulin unit codes also need semantic checks: a syntactically valid UCUM unit can carry the wrong meaning.

### Limitations

The corpus is a census of labels for selected ingredients in six cardiometabolic groups at one retrieval date, and its findings may not carry over to other classes, OTC labels or biologics outside insulin. Only the latest and one preceding version were compared, for 218 labels sampled with equal allocation across groups, so the version change share is not a corpus rate, and 511 eligible labels list a single version. RxNorm was available only as its current release plus its dated NDC history. License-free monthly RxNorm archives would allow fuller historical checks. 

Approach A is a terminology reference with its own errors, and approaches B and C were tuned against it. I wrote both the second reader and the reverse transform. No external party has repeated this software cross-check, and a rule both readers share can hide an error, as the repeated moiety showed. The companion record was designed to hold the attributes the round trip measures, so its complete preservation is partly by construction. The informative results are the losses measured without it. 

The study treats the label's structured product data as the source of truth, while narrative and structured sections of a label can disagree, as in excipient inconsistencies reported for 39% of 100 audited formulations [29]. Nothing here bears on the clinical correctness of any label or mapping.

## Conclusion

For these labels, FHIR R4 Medication resources kept NDCs, dosage forms, ingredients and exact strengths, and the Provenance resource kept the SPL document ID, but neither kept the set ID, version number or basis of strength. A small, schema-validated companion record closed these gaps in every held-out record. Padding NDCs without their segment pattern, keeping only the latest label version or the first ingredient, and taking strengths from DailyMed's packaging service each changed or dropped identity attributes. The accompanying pipeline, companion schema and medication dictionary record provenance and reasons for review.

## Acknowledgments

This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or recommend this or any other product.

## Conflicts of interest

I own Norlowe Research and have no other conflicts of interest to declare.

## Funding

This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors. I used internal resources from Norlowe Research, which I own. These do not constitute external funding.

## Author contributions

Animesh Bose (sole author): conceptualization, methodology, software, validation, formal analysis, investigation, data curation, resources, visualization, project administration, writing (original draft), and writing (review and editing).

## Data availability

The data underlying this article are publicly available from the US National Library of Medicine: DailyMed Structured Product Labeling documents and the DailyMed SPL-to-RxNorm mapping file (https://dailymed.nlm.nih.gov/dailymed/, retrieved October 7, 2026) and the RxNorm API (https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html, release of October 5, 2026). The supplementary source archive contains the code that retrieves and processes these data, a manifest of every retrieved file with its URL, retrieval time and SHA-256 checksum, the derived analysis tables, the FHIR outputs, and the medication dictionary export. Because DailyMed and RxNorm serve current content, rerunning the retrieval reproduces the workflow on the content current at that time. The manifest identifies the exact files analyzed here.

## Software availability

The source code (Python 3.13 and PostgreSQL 17; MIT license), configuration, SQL, schemas, tests and an offline demonstration are provided as Supplementary Material S1 (medication-identity-source.zip).

## Supplementary material

Supplementary Material S1, source archive (medication-identity-source.zip); S2, results workbook with definitions (medication_identity_results.xlsx); S3, medication dictionary export (medication_dictionary.zip); S4, example FHIR Bundles and companion records (fhir_examples.zip).


## References

1. Nelson SJ, Zeng K, Kilbourne J, et al. Normalized names for clinical drugs: RxNorm at 6 years. J Am Med Inform Assoc. 2011;18(4):441-448. doi:10.1136/amiajnl-2011-000116
2. US National Library of Medicine. DailyMed web services. https://dailymed.nlm.nih.gov/dailymed/app-support-web-services.cfm. Accessed October 7, 2026.
3. HL7 International. FHIR Release 4 (v4.0.1): Medication. https://hl7.org/fhir/R4/medication.html. Accessed October 7, 2026.
4. Zhu Q, Jiang G, Chute CG. Profiling structured product labeling with NDF-RT and RxNorm. J Biomed Semantics. 2012;3(1):16. doi:10.1186/2041-1480-3-16
5. Schadow G. Assessing the impact of HL7/FDA Structured Product Label (SPL) content for medication knowledge management. AMIA Annu Symp Proc. 2007;2007:646-650. PMID: 18693916
6. Peters LB, Bodenreider O. Approaches to supporting the analysis of historical medication datasets with RxNorm. AMIA Annu Symp Proc. 2015;2015:1034-1041. PMID: 26958241
7. Peters L, Nguyen T, Bodenreider O. Terminology status APIs: mapping obsolete codes to current RxNorm, SNOMED CT, and LOINC concepts. Stud Health Technol Inform. 2017;245:1333. doi:10.3233/978-1-61499-830-3-1333
8. Bona JP, Brochhausen M, Hogan WR. Enhancing the drug ontology with semantically-rich representations of National Drug Codes and RxNorm unique concept identifiers. BMC Bioinformatics. 2019;20(Suppl 21):708. doi:10.1186/s12859-019-3192-8
9. Podchiyska T, Hernandez P, Ferris T, et al. Managing medical vocabulary updates in a clinical data warehouse: an RxNorm case study. AMIA Annu Symp Proc. 2010;2010:477-481. PMID: 21347024
10. Lester CA, Flynn AJ, Marshall VD, et al. Comparing the variability of ingredient, strength, and dose form information from electronic prescriptions with RxNorm drug product descriptions. J Am Med Inform Assoc. 2022;29(9):1471-1479. doi:10.1093/jamia/ocac096
11. Dhavle AA, Ward-Charlerie S, Rupp MT, et al. Analysis of National Drug Code identifiers in ambulatory e-prescribing. J Manag Care Spec Pharm. 2015;21(11):1025-1031. doi:10.18553/jmcp.2015.21.11.1025
12. Dhavle AA, Ward-Charlerie S, Rupp MT, et al. Evaluating the implementation of RxNorm in ambulatory electronic prescriptions. J Am Med Inform Assoc. 2016;23(e1):e99-e107. doi:10.1093/jamia/ocv131
13. Davidson L, Boland MR. Comparative analysis and evaluation of state-of-the-art medication mapping tools to transform a local medication terminology to RxNorm. AMIA Jt Summits Transl Sci Proc. 2020;2020:126-135. PMID: 32477631
14. Waters R, Malecki S, Lail S, et al. Automated identification of unstandardized medication data: a scalable and flexible data standardization pipeline using RxNorm on GEMINI multicenter hospital data. JAMIA Open. 2023;6(3):ooad062. doi:10.1093/jamiaopen/ooad062
15. Korpela E, Rubin LH, Dastgheyb RM, et al. RxMap: an LLM-assisted tool for medication normalization. JAMIA Open. 2026;9(3):ooag085. doi:10.1093/jamiaopen/ooag085
16. HL7 International, Biomedical Research and Regulation Work Group. SPL Mapping FHIR R5 Implementation Guide, continuous-integration build 0.2.8. https://build.fhir.org/ig/HL7/fhir-spl/. Accessed October 7, 2026.
17. Hong N, Wen A, Shen F, et al. Developing a scalable FHIR-based clinical data normalization pipeline for standardizing and integrating unstructured and structured electronic health record data. JAMIA Open. 2019;2(4):570-579. doi:10.1093/jamiaopen/ooz056
18. Reich C, Ostropolets A, Ryan P, et al. OHDSI Standardized Vocabularies: a large-scale centralized reference ontology for international data harmonization. J Am Med Inform Assoc. 2024;31(3):583-590. doi:10.1093/jamia/ocad247
19. US National Library of Medicine. RxNorm API. https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html. Accessed October 7, 2026.
20. US National Library of Medicine. RxNav terms of service. https://lhncbc.nlm.nih.gov/RxNav/TermsofService.html. Accessed October 7, 2026.
21. US Food and Drug Administration. Structured Product Labeling (SPL) Implementation Guide with Validation Procedures. Version 1, revision 202312080859; December 2023. https://www.fda.gov/media/84201/download. Accessed October 7, 2026.
22. US Food and Drug Administration. National Drug Code database background information. https://www.fda.gov/drugs/development-approval-process-drugs/national-drug-code-database-background-information. Accessed October 7, 2026.
23. HL7 International and contributors. FHIR validator (validator_cli.jar), release 7.0.0. https://github.com/hapifhir/org.hl7.fhir.core/releases/tag/7.0.0. Accessed October 7, 2026.
24. Schadow G, McDonald CJ. The Unified Code for Units of Measure. Version 2.2. Regenstrief Institute and the UCUM Organization; 2024. https://ucum.org/ucum. Accessed October 7, 2026.
25. HL7 International. FHIR Release 4 (v4.0.1): MedicinalProductIngredient. https://hl7.org/fhir/R4/medicinalproductingredient.html. Accessed October 7, 2026.
26. HL7 International. FHIR Release 5 (v5.0.0): Ingredient. https://hl7.org/fhir/R5/ingredient.html. Accessed October 7, 2026.
27. HL7 International. US Core Implementation Guide 9.0.0 (STU9): US Core Medication profile. https://hl7.org/fhir/us/core/STU9/StructureDefinition-us-core-medication.html. Accessed October 7, 2026.
28. US Food and Drug Administration. National Drug Code format. https://www.fda.gov/drugs/electronic-drug-registration-and-listing-system-edrls/national-drug-code-format. Accessed October 7, 2026.
29. Kinsella L, Brook J, Briest M, et al. Inconsistent excipient listings in DailyMed: implications for drug safety. Naunyn Schmiedebergs Arch Pharmacol. 2024;397(9):6851-6854. doi:10.1007/s00210-024-03067-x

