"""Fingerprint the deterministic outputs of a pipeline run, or compare two fingerprints.

  python scripts/rerun_check.py snapshot outputs/checks/run_a.json
  python scripts/rerun_check.py compare outputs/checks/run_a.json outputs/checks/run_b.json

Run logs, timestamps and archives (which embed the run log) are excluded; every
other listed output must be byte-identical (numerical tolerance zero).
"""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GLOBS = ["outputs/tables/*.csv", "outputs/figures/*", "outputs/matching/*", "outputs/roundtrip/*.csv",
         "outputs/dictionary/*.csv", "outputs/checks/build_checks.json", "outputs/checks/fhir_export.json",
         "outputs/fhir/bundles/*.json", "outputs/fhir/sidecars/*.json", "outputs/viewer/*.html",
         "manuscript/manuscript.md", "outputs/workbook/*.xlsx", "outputs/tableau/*.csv"]


def digest(p: Path) -> str:
    if p.suffix == ".xlsx":  # the file embeds a creation time; compare cell values instead
        from openpyxl import load_workbook
        wb = load_workbook(p, read_only=True)
        h = hashlib.sha256()
        for ws in wb.worksheets:
            h.update(ws.title.encode())
            for row in ws.iter_rows(values_only=True):
                h.update(repr(row).encode())
        return h.hexdigest()
    return hashlib.sha256(p.read_bytes()).hexdigest()


def snapshot(out: str) -> None:
    files = {}
    for g in GLOBS:
        for p in sorted(ROOT.glob(g)):
            if p.is_file():
                files[p.relative_to(ROOT).as_posix()] = digest(p)
    res = json.loads((ROOT / "outputs/analysis/results.json").read_text())
    files["outputs/analysis/results.json#content"] = hashlib.sha256(json.dumps(res, sort_keys=True).encode()).hexdigest()
    Path(out).write_text(json.dumps(files, indent=0))
    print(f"{len(files)} outputs fingerprinted -> {out}")


def compare(a: str, b: str) -> None:
    A, B = json.loads(Path(a).read_text()), json.loads(Path(b).read_text())
    changed = sorted(k for k in A.keys() & B.keys() if A[k] != B[k])
    only_a, only_b = sorted(A.keys() - B.keys()), sorted(B.keys() - A.keys())
    xlsx = [k for k in changed if k.endswith(".xlsx")]
    result = {"compared": len(A.keys() & B.keys()), "identical": len(A.keys() & B.keys()) - len(changed),
              "changed": changed, "only_in_first": only_a, "only_in_second": only_b,
              "note": "xlsx workbooks are compared by cell values because the file embeds its creation time"}
    print(json.dumps(result, indent=1))
    Path(ROOT / "outputs/checks/rerun_comparison.json").write_text(json.dumps(result, indent=1))


if __name__ == "__main__":
    {"snapshot": lambda: snapshot(sys.argv[2]), "compare": lambda: compare(sys.argv[2], sys.argv[3])}[sys.argv[1]]()
