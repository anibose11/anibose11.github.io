"""Reproduce the approach C tuning grid on the development split.

  python scripts/tune_approach_c.py [out.csv]

For every product in a development label with a unique approach A answer, the
matching stage stores approach C's top candidate and its top two scores
(match_result.detail). This script applies each (tau, delta) pair of the
prespecified grid to those scores and counts answers that agree or disagree
with approach A; the objective is agreements minus disagreements. The frozen
values (config/normalization.toml) are the grid optimum. Writes
outputs/matching/approach_c_tuning_development.csv by default.
"""
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from medid import db  # noqa: E402

TAUS = list(range(60, 101, 2))
DELTAS = [0, 1, 2, 3, 5, 8]


def main(out: Path) -> None:
    db.start()
    with db.connect() as conn:
        rows = conn.execute("""select a.rxcui, c.detail->>'top_rxcui', (c.detail->>'s1')::float, (c.detail->>'s2')::float
                               from medid.match_result a join medid.match_result c on c.product_key=a.product_key and c.approach='C'
                               join medid.spl_product p on p.product_key=a.product_key join medid.spl_document d using (document_id)
                               where a.approach='A' and a.outcome='unique' and d.split='development'""").fetchall()
    grid = []
    for tau in TAUS:
        for delta in DELTAS:
            ans = [(a, t) for a, t, s1, s2 in rows if t is not None and s1 >= tau and (s1 - (s2 or 0)) >= delta]
            agree = sum(1 for a, t in ans if a == t)
            grid.append({"tau": tau, "delta": delta, "answered": len(ans), "agree": agree, "disagree": len(ans) - agree,
                         "objective": agree - (len(ans) - agree), "a_unique": len(rows)})
    grid.sort(key=lambda r: (r["tau"], r["delta"]))
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(grid[0]))
        w.writeheader()
        w.writerows(grid)
    best = max(grid, key=lambda r: (r["objective"], -r["tau"], -r["delta"]))
    print(f"wrote {out}; optimum tau={best['tau']} delta={best['delta']} objective={best['objective']}")


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "outputs/matching/approach_c_tuning_development.csv")
