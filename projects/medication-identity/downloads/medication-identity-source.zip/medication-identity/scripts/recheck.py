"""Independent re-check of the review items, written separately from the pipeline.

1. Live labels: re-download the current SPL XML for the 30 review-sample set IDs
   (no cache), read them with the standard-library reader, and compare the
   sampled products with the analyzed version.
2. Headline numbers: recompute them from the released CSV tables with pandas
   and compare with evidence/claims.json.
3. References: confirm DOIs (Crossref) and PMIDs (PubMed) resolve to the cited
   titles, and that cited web pages answer.
4. Figure data: recompute Figure 1 shares from the field-status table.
Writes outputs/checks/independent_recheck.json.
"""
import csv
import json
import re
import sys
import time
from pathlib import Path

import httpx
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from medid.independent_read import read_critical  # noqa: E402
from medid.manuscript import REFERENCES  # noqa: E402

UA = {"User-Agent": "medid-research/1.0 (verification)"}


def live_labels(client):
    rows = list(csv.DictReader(open(ROOT / "docs/review_sample.csv")))
    man = json.loads((ROOT / "data/interim/label_manifest.json").read_text())
    by = {e["setid"]: e for e in man["labels"]}
    out = []
    for r in rows:
        time.sleep(0.3)
        doc_id, idx = r["product_key"].rsplit(":", 1)
        e = by[r["set_id"]]
        old = read_critical(ROOT / e["current_xml"]["path"])
        resp = client.get(f"https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{r['set_id']}.xml")
        new = read_critical(resp.content)
        rec = {"sample_id": r["sample_id"], "set_id": r["set_id"], "analyzed_version": old["version_number"],
               "live_version": new["version_number"], "http": resp.status_code}
        op = old["products"][int(idx)]
        match = [p for p in new["products"] if p["product_ndc"] == op["product_ndc"]]
        if new["version_number"] == old["version_number"]:
            rec["result"] = "identical" if match and match[0] == op else "differs"
        else:
            rec["result"] = ("new version; sampled product unchanged" if match and match[0] == op
                             else "new version; sampled product changed or removed")
        # the CSV row the reviewer saw must agree with the analyzed label
        acts = op["active"] + [a for p in op["parts"] for a in p["active"]]
        rec["csv_product_ndc_matches"] = r["product_ndc"] == op["product_ndc"]
        rec["csv_strengths_match"] = all(f" {a['num_value']} {a['num_unit']}" in " " + r["active_ingredients_and_strength"] for a in acts)
        out.append(rec)
    return out


def headline_numbers():
    T = ROOT / "outputs/tables"
    claims = {c["id"]: c for c in json.loads((ROOT / "evidence/claims.json").read_text())["claims"]}
    rec = pd.read_csv(T / "roundtrip_record_outcomes.csv")
    fs = pd.read_csv(T / "roundtrip_field_status.csv")
    nd = pd.read_csv(T / "shortcut_ndc_padding.csv")
    ag = pd.read_csv(T / "matching_agreement_with_A.csv")
    vc = pd.read_csv(T / "version_changes_by_set.csv")
    r1 = rec[(rec.representation == "R1_full") & (rec.split == "held_out")].iloc[0]
    k10 = fs[(fs.representation == "R_core") & (fs.attribute == "K10_boss_unii") & (fs.split == "held_out")].iloc[0]
    k7 = fs[(fs.representation == "S_api") & (fs.attribute == "K7_active_count") & (fs.split == "held_out")].iloc[0]
    b = ag[(ag.split == "held_out") & (ag.approach == "B")].iloc[0]
    cc = ag[(ag.split == "held_out") & (ag.approach == "C")].iloc[0]
    mine = {
        "primary_reversible_heldout": (int(r1.all_critical_ok), int(r1.records)),
        "core_boss_misread": (int(k10.discordant), int(k10.applicable)),
        "ndc_naive_padding": (int((nd.package_ndcs - nd.naive_equals_correct).sum()), int(nd.package_ndcs.sum())),
        "api_count_wrong": (int(k7.discordant), int(k7.applicable)),
        "b_agree": (int(b.agree_exact_rxcui), int(b.answered)),
        "c_wrong": (int(cc.disagree), int(cc.answered)),
        "versions_any_change": (int((vc.any_identity_change > 0).sum()), len(vc)),
    }
    return [{"claim": k, "recomputed": v, "claims_json": (claims[k]["numerator"], claims[k]["denominator"]),
             "agrees": tuple(v) == (claims[k]["numerator"], claims[k]["denominator"])} for k, v in mine.items()]


def references(client):
    out = []
    for key, ref in REFERENCES:
        rec = {"key": key}
        doi = re.search(r"doi:(\S+?)\.?$", ref)
        pmid = re.search(r"PMID: (\d+)", ref)
        url = re.search(r"(https?://\S+?)\.? Accessed", ref)
        title = ref.split(". ")[1] if ". " in ref else ""
        try:
            if doi:
                m = client.get(f"https://api.crossref.org/works/{doi.group(1)}").json()["message"]
                got = m.get("title", [""])[0]
                rec.update(kind="doi", ok=_same(title, got), found=got[:120])
            elif pmid:
                js = client.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
                                params={"db": "pubmed", "id": pmid.group(1), "retmode": "json"}).json()
                got = js["result"][pmid.group(1)]["title"]
                rec.update(kind="pmid", ok=_same(title, got), found=got[:120])
            elif url:
                r = client.get(url.group(1), follow_redirects=True)
                rec.update(kind="url", ok=r.status_code < 400, found=f"HTTP {r.status_code}")
        except Exception as e:  # network trouble is recorded, not hidden
            rec.update(ok=False, found=f"error: {e}")
        time.sleep(0.4)
        out.append(rec)
    return out


def _same(a, b):
    import html
    norm = lambda s: re.sub(r"[^a-z0-9]+", " ", html.unescape(html.unescape(s)).lower()).strip()  # noqa: E731
    a, b = norm(a), norm(b)
    return a[:60] == b[:60] or a in b or b in a


def figure_data():
    fs = pd.read_csv(ROOT / "outputs/tables/roundtrip_field_status.csv")
    f1 = pd.read_csv(ROOT / "outputs/figures/fig1_data.csv")
    idattrs = [a for a in fs.attribute.unique() if a not in ("K1_set_id", "K2_document_id", "K3_version")]
    out = []
    for r in f1.itertuples():
        sub = fs[(fs.representation == r.representation) & (fs.split == "held_out") & (fs.attribute.isin(idattrs))]
        ok = int(sub.preserved.sum() + sub.preserved_normalized.sum())
        out.append({"representation": r.representation, "figure": (int(r.preserved), int(r.applicable)),
                    "recomputed": (ok, int(sub.applicable.sum())),
                    "agrees": (int(r.preserved), int(r.applicable)) == (ok, int(sub.applicable.sum()))})
    return out


if __name__ == "__main__":
    with httpx.Client(headers=UA, timeout=60) as client:
        result = {"run_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                  "live_labels": live_labels(client), "headline_numbers": headline_numbers(),
                  "references": references(client), "figure1": figure_data()}
    summ = {
        "live_labels": {k: sum(1 for x in result["live_labels"] if x["result"] == k) for k in {x["result"] for x in result["live_labels"]}},
        "csv_rows_consistent": all(x["csv_product_ndc_matches"] and x["csv_strengths_match"] for x in result["live_labels"]),
        "headline_numbers_agree": all(x["agrees"] for x in result["headline_numbers"]),
        "references_ok": f"{sum(1 for x in result['references'] if x.get('ok'))} of {len(result['references'])}",
        "figure1_agrees": all(x["agrees"] for x in result["figure1"]),
    }
    result["summary"] = summ
    (ROOT / "outputs/checks/independent_recheck.json").write_text(json.dumps(result, indent=1))
    print(json.dumps(summ, indent=1))
    for x in result["references"]:
        if not x.get("ok"):
            print("REF CHECK:", x)
    for x in result["live_labels"]:
        if x["result"] != "identical" or not (x["csv_product_ndc_matches"] and x["csv_strengths_match"]):
            print("LABEL:", x)
