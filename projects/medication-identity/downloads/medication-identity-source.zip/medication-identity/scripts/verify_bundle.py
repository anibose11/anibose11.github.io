"""Verify an extracted project bundle.

  python scripts/verify_bundle.py <extracted-bundle-dir> <port>

Checks: top-level layout (site/ and handoff/ only, no enclosing folder); every
public file's size and SHA-256 against handoff/<slug>.json; every local href,
src and in-page anchor in the HTML pages resolves inside the project folder;
no remote resources are loaded; then serves site/ over HTTP and fetches every
public file, comparing bytes. Prints a JSON report.
"""
import hashlib
import http.server
import json
import re
import socketserver
import sys
import threading
import urllib.request
from html.parser import HTMLParser
from pathlib import Path

SLUG = "medication-identity"


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links, self.ids, self.remote = [], set(), []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.add(a["id"])
        for k in ("href", "src", "srcset"):
            v = a.get(k)
            if not v:
                continue
            if tag in ("link", "script", "img", "source") and v.startswith(("http://", "https://", "//")):
                self.remote.append(v)
            self.links.append((tag, k, v))


def main(root: str, port: int) -> None:
    root = Path(root)
    import time
    report = {"run_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "checks": []}

    def check(name, ok, detail=""):
        report["checks"].append({"name": name, "passed": bool(ok), "detail": detail})

    top = sorted(p.name for p in root.iterdir())
    check("top level holds only site/ and handoff/", top == ["handoff", "site"], str(top))
    proj = root / "site" / "projects" / SLUG
    hj = json.loads((root / "handoff" / f"{SLUG}.json").read_text())
    bad = []
    for f in hj["public_files"]:
        p = root / f["path"]
        if not p.exists() or p.stat().st_size != f["bytes"] or hashlib.sha256(p.read_bytes()).hexdigest() != f["sha256"]:
            bad.append(f["path"])
    on_disk = sorted(p.relative_to(root).as_posix() for p in (root / "site").rglob("*") if p.is_file())
    listed = sorted(f["path"] for f in hj["public_files"])
    check("public files match handoff sizes and SHA-256", not bad and on_disk == listed,
          f"{len(listed)} listed, {len(on_disk)} on disk, mismatches {bad}")
    broken, remote, anchors = [], [], 0
    pages = sorted(proj.glob("*.html"))
    ids = {}
    for page in pages:
        lp = Links()
        lp.feed(page.read_text())
        ids[page.name] = lp.ids
        remote += [(page.name, r) for r in lp.remote]
    for page in pages:
        lp = Links()
        lp.feed(page.read_text())
        for tag, attr, v in lp.links:
            for url in ([x.strip().split(" ")[0] for x in v.split(",")] if attr == "srcset" else [v]):
                if url.startswith(("http://", "https://", "mailto:")):
                    continue
                path, _, frag = url.partition("#")
                target = (page.parent / path).resolve() if path else page.resolve()
                if path and proj.resolve() not in target.parents and target != proj.resolve():
                    broken.append(f"{page.name}: {url} leaves the project folder")
                    continue
                if not target.exists():
                    broken.append(f"{page.name}: {url} missing")
                    continue
                if frag:
                    anchors += 1
                    if target.suffix == ".html" and frag not in ids.get(target.name, set()):
                        broken.append(f"{page.name}: #{frag} not found in {target.name}")
    check("local links, images and anchors resolve inside the project folder", not broken,
          f"{len(pages)} pages, {anchors} anchors checked; problems: {broken[:10]}")
    check("no remote scripts, styles or images", not remote, str(remote[:5]))
    text_bad = []
    pat = re.compile("|".join(["/" + "Users/", "/" + "private/tmp", "/" + "home/[a-z]+/"]))
    for p in proj.rglob("*"):
        if p.is_file() and p.suffix in (".html", ".css", ".svg", ".csv", ".json") and pat.search(p.read_text(errors="ignore")):
            text_bad.append(p.name)
    check("no local paths in public text files", not text_bad, str(text_bad))
    # Personal Gmail addresses must not appear in public pages or downloads.
    import zipfile
    priv = re.compile(r"\b[A-Z0-9._%+-]+@" + r"gmail\.com\b", re.I)
    leaks = []
    for p in proj.rglob("*"):
        if p.is_file() and p.suffix in (".html", ".css", ".svg", ".csv", ".json", ".txt", ".md") and priv.search(p.read_text(errors="ignore")):
            leaks.append(p.name)
        if p.is_file() and p.suffix == ".zip":
            with zipfile.ZipFile(p) as zf:
                leaks += [f"{p.name}:{n}" for n in zf.namelist() if priv.search(zf.read(n).decode("utf-8", "ignore"))]
    check("no personal Gmail addresses in public pages or downloads", not leaks, str(leaks[:10]))

    handler = lambda *a, **k: http.server.SimpleHTTPRequestHandler(*a, directory=str(root / "site"), **k)  # noqa: E731

    class Quiet(socketserver.TCPServer):
        allow_reuse_address = True

    http.server.SimpleHTTPRequestHandler.log_message = lambda *a: None
    with Quiet(("127.0.0.1", port), handler) as srv:
        t = threading.Thread(target=srv.serve_forever, daemon=True)
        t.start()
        fails, n = [], 0
        for f in hj["public_files"]:
            rel = f["path"][len("site/"):]
            url = f"http://127.0.0.1:{port}/{rel}"
            with urllib.request.urlopen(url) as r:
                body = r.read()
                n += 1
                if r.status != 200 or hashlib.sha256(body).hexdigest() != f["sha256"]:
                    fails.append(rel)
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/projects/{SLUG}/") as r:
            dir_ok = r.status == 200 and b"<h1>" in r.read()
        srv.shutdown()
    check("HTTP: every public file returns 200 with identical bytes", not fails, f"{n} URLs; failures {fails}")
    check("HTTP: /projects/medication-identity/ serves the project page", dir_ok)
    report["passed"] = all(c["passed"] for c in report["checks"])
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]))
