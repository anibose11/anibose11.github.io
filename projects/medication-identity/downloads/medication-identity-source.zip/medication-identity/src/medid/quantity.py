"""Exact decimal quantities and strength ratios.

Values are kept as the source's decimal text. Arithmetic (only needed for the
documented per-mL conversion used when building RxNorm-style strings) is done
with fractions, and a conversion that cannot be written as a terminating
decimal is reported as inexact instead of being rounded.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from fractions import Fraction

_DECIMAL = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")


def is_decimal_text(s: str | None) -> bool:
    return s is not None and bool(_DECIMAL.match(s.strip()))


def to_fraction(s: str) -> Fraction:
    try:
        return Fraction(Decimal(s.strip()))
    except (InvalidOperation, ValueError) as e:
        raise ValueError(f"not a decimal: {s!r}") from e


def fraction_to_decimal_text(f: Fraction, max_places: int = 12) -> str | None:
    """Exact terminating decimal text for f, or None if f does not terminate."""
    den = f.denominator
    twos = fives = 0
    while den % 2 == 0:
        den //= 2
        twos += 1
    while den % 5 == 0:
        den //= 5
        fives += 1
    if den != 1:
        return None
    places = max(twos, fives)
    if places > max_places:
        return None
    scaled = f * (10 ** places)
    assert scaled.denominator == 1
    n = scaled.numerator
    sign = "-" if n < 0 else ""
    digits = str(abs(n)).rjust(places + 1, "0")
    text = digits if places == 0 else f"{digits[:-places]}.{digits[-places:]}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return sign + text


def same_value(a: str | None, b: str | None) -> bool:
    """Numeric equality of two decimal strings (ignores trailing zeros)."""
    if a is None or b is None:
        return a is b
    return to_fraction(a) == to_fraction(b)


def same_text(a: str | None, b: str | None) -> bool:
    """Exact lexical equality, which also preserves stated precision ('0.50' vs '0.5')."""
    return a == b


def float_roundtrip_text(s: str) -> str:
    """What a pipeline that parses decimals as binary floats writes back as JSON.

    json.dumps(float('0.50')) is '0.5' and json.dumps(float('500')) is '500.0':
    the value survives but the stated precision does not.
    """
    return json.dumps(float(s))


@dataclass(frozen=True)
class Ratio:
    num_value: str | None
    num_unit: str | None
    den_value: str | None
    den_unit: str | None

    def per_unit_denominator(self) -> tuple[str | None, bool]:
        """Numerator divided by denominator value, as exact decimal text.

        Returns (text, exact). Used only for the documented per-mL conversion;
        the canonical record and FHIR output keep the source ratio unchanged.
        """
        if not (is_decimal_text(self.num_value) and is_decimal_text(self.den_value)):
            return None, False
        den = to_fraction(self.den_value)
        if den == 0:
            return None, False
        q = to_fraction(self.num_value) / den
        text = fraction_to_decimal_text(q)
        return (text, True) if text is not None else (None, False)
