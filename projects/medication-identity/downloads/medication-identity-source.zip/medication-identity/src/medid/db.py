"""Project-local PostgreSQL cluster.

The study uses its own cluster under .local/pgdata (Unix socket only, port
55435 by default), so it never touches another PostgreSQL installation on the
machine. Server binaries are found on PATH or through MEDID_PG_BIN.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

import psycopg

from .paths import LOCAL, SQL

PGDATA = Path(os.environ.get("MEDID_PGDATA", LOCAL / "pgdata"))
PGSOCK = Path(os.environ.get("MEDID_PGSOCK", LOCAL / "pgsock"))
PGPORT = int(os.environ.get("MEDID_PGPORT", "55435"))
PGUSER = "medid"
PGDB = os.environ.get("MEDID_PGDATABASE", "medid")


def _bin(name: str) -> str:
    base = os.environ.get("MEDID_PG_BIN")
    if base:
        return str(Path(base) / name)
    found = shutil.which(name)
    if not found:
        for cand in ("/opt/homebrew/bin", "/usr/local/bin", "/usr/lib/postgresql/17/bin",
                     "/usr/lib/postgresql/16/bin"):
            if (Path(cand) / name).exists():
                return str(Path(cand) / name)
        raise RuntimeError(f"PostgreSQL binary {name!r} not found; set MEDID_PG_BIN")
    return found


def _env() -> dict:
    env = dict(os.environ)
    env.setdefault("LC_ALL", "C")  # macOS postmaster refuses to start without a valid locale
    return env


def server_version() -> str:
    out = subprocess.run([_bin("postgres"), "--version"], capture_output=True, text=True, check=True)
    return out.stdout.strip()


def is_running() -> bool:
    r = subprocess.run([_bin("pg_ctl"), "-D", str(PGDATA), "status"], capture_output=True, text=True, env=_env())
    return r.returncode == 0


def init_cluster() -> None:
    if (PGDATA / "PG_VERSION").exists():
        return
    PGSOCK.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        _bin("initdb"), "-D", str(PGDATA), "-U", PGUSER, "--auth=trust", "--encoding=UTF8", "--locale=C",
        "-c", "listen_addresses=", "-c", f"unix_socket_directories={PGSOCK}", "-c", f"port={PGPORT}",
    ], check=True, capture_output=True, env=_env())


def start() -> None:
    init_cluster()
    if not is_running():
        subprocess.run([_bin("pg_ctl"), "-D", str(PGDATA), "-l", str(LOCAL / "postgres.log"), "-w",
                        "-o", f"-p {PGPORT} -k {PGSOCK}", "start"],
                       check=True, capture_output=True, env=_env())
    with psycopg.connect(host=str(PGSOCK), port=PGPORT, user=PGUSER, dbname="postgres", autocommit=True) as c:
        if not c.execute("select 1 from pg_database where datname=%s", (PGDB,)).fetchone():
            c.execute(f'create database "{PGDB}"')


def stop() -> None:
    if is_running():
        subprocess.run([_bin("pg_ctl"), "-D", str(PGDATA), "-m", "fast", "stop"], check=True,
                       capture_output=True, env=_env())


def connect(dbname: str | None = None) -> psycopg.Connection:
    return psycopg.connect(host=str(PGSOCK), port=PGPORT, user=PGUSER, dbname=dbname or PGDB)


def run_sql_file(conn: psycopg.Connection, name: str) -> None:
    conn.execute((SQL / name).read_text())
