"""JSON with exact decimal text.

FHIR treats the precision of a decimal as significant, so 0.50 and 0.5 are
different statements. Python's json module would turn a source value of
'0.50' into the float 0.5. Here, decimals are carried as JsonNumber objects
holding their text and written verbatim, and the reader returns number tokens
as text so the round-trip comparison sees exactly what was written.

Only one lexical normalization is ever applied, because JSON forbids some
forms that SPL allows: a leading '.' gets a zero ('.5' -> '0.5'), a trailing
'.' is dropped ('5.' -> '5') and redundant leading zeros are removed
('05' -> '5'). Each normalization is reported so it can be counted.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

_FHIR_DECIMAL = re.compile(r"^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$")


@dataclass(frozen=True)
class JsonNumber:
    text: str
    source_text: str

    @property
    def normalized(self) -> bool:
        return self.text != self.source_text


def number(source_text: str) -> JsonNumber:
    """Wrap a source decimal string, applying only the documented JSON fixes."""
    s = source_text.strip()
    t = s
    neg = t.startswith("-")
    if t[:1] in "+-":
        t = t[1:]
    if t.startswith("."):
        t = "0" + t
    if t.endswith("."):
        t = t[:-1]
    m = re.match(r"^(\d+)(.*)$", t)
    if m:
        intpart = m.group(1).lstrip("0") or "0"
        t = intpart + m.group(2)
    t = ("-" if neg else "") + t
    if not _FHIR_DECIMAL.match(t):
        raise ValueError(f"cannot express {source_text!r} as a FHIR decimal")
    return JsonNumber(t, source_text)


def dumps(obj, indent: int | None = 1) -> str:
    """Serialize obj; JsonNumber values are written as bare number tokens."""
    marks: dict[str, str] = {}

    def conv(o):
        if isinstance(o, JsonNumber):
            key = f"\u0000num{len(marks)}\u0000"
            marks[key] = o.text
            return key
        if isinstance(o, dict):
            return {k: conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, float):
            raise TypeError("floats are not allowed; use JsonNumber")
        return o

    text = json.dumps(conv(obj), indent=indent, ensure_ascii=False)
    for key, num in marks.items():
        text = text.replace(json.dumps(key), num)
    return text


def loads_exact(text: str):
    """Parse JSON keeping every number token as its exact text (str)."""
    return json.loads(text, parse_float=lambda s: s, parse_int=lambda s: s)
