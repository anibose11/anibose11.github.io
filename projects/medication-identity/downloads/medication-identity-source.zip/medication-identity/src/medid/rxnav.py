"""Public RxNorm API (RxNav) retrieval.

Terms observed 2026-10-07 (https://lhncbc.nlm.nih.gov/RxNav/TermsofService.html):
no more than 20 requests per second per IP address, caching for 12 to 24
hours recommended, no license needed for these endpoints. This client stays at
or below 10 requests per second and caches every response under data/raw/rxnav.

The API serves only the current release. Each cached response therefore
describes RxNorm as of its retrieval time, which is recorded with the response
and the /version answer; it is never treated as a statement about an earlier
date. The only dated history used is what RxNorm itself publishes
(ndcstatus ndcHistory start and end months, historystatus release dates).
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

from .http import Fetcher
from .paths import RAW

BASE = "https://rxnav.nlm.nih.gov/REST"
PRODUCT_TTYS = ("SCD", "SBD", "GPCK", "BPCK")


class RxNav:
    def __init__(self, rate: float = 8.0):
        self.f = Fetcher(RAW / "rxnav", rate=rate)

    def close(self):
        self.f.close()

    def get(self, path: str, refresh: bool = False):
        return self.f.get(f"{BASE}/{path}", expect="json", refresh=refresh)

    # --- release -----------------------------------------------------------------
    def version(self, refresh: bool = True):
        return self.get("version.json", refresh=refresh)

    # --- NDC ----------------------------------------------------------------------
    def ndcstatus(self, ndc11: str):
        """Current RxNorm status of an 11-digit NDC with its full RxCUI history."""
        return self.get(f"ndcstatus.json?ndc={ndc11}")

    def ndcproperties(self, ndc11: str):
        return self.get(f"ndcproperties.json?id={ndc11}&ndcstatus=ALL")

    # --- concepts -----------------------------------------------------------------
    def historystatus(self, rxcui: str):
        return self.get(f"rxcui/{rxcui}/historystatus.json")

    def allrelated(self, rxcui: str):
        return self.get(f"rxcui/{rxcui}/allrelated.json")

    def related(self, rxcui: str, ttys: tuple[str, ...]):
        return self.get(f"rxcui/{rxcui}/related.json?tty={'+'.join(ttys)}")

    def properties(self, rxcui: str):
        return self.get(f"rxcui/{rxcui}/properties.json")

    def allconcepts(self, ttys: tuple[str, ...] = PRODUCT_TTYS):
        return self.get(f"allconcepts.json?tty={'+'.join(ttys)}")

    def find_by_name(self, name: str, search: int = 0):
        return self.get(f"rxcui.json?name={quote(name)}&search={search}")

    def many(self, fn, keys, workers: int = 4):
        """Fetch many keys concurrently; the shared limiter keeps the global rate."""
        with ThreadPoolExecutor(max_workers=workers) as ex:
            return dict(zip(keys, ex.map(fn, keys)))


# --- response readers ------------------------------------------------------------

def ndc_status_record(js: dict) -> dict:
    s = js.get("ndcStatus") or {}
    hist = s.get("ndcHistory") or []
    return {
        "ndc11": s.get("ndc11"),
        "status": (s.get("status") or "").upper() or None,
        "rxcui": s.get("rxcui") or None,
        "concept_name": s.get("conceptName") or None,
        "concept_status": (s.get("conceptStatus") or "").upper() or None,
        "history": [{"active_rxcui": h.get("activeRxcui") or None,
                     "original_rxcui": h.get("originalRxcui") or None,
                     "start_yyyymm": h.get("startDate") or None,
                     "end_yyyymm": h.get("endDate") or None} for h in hist],
    }


def history_status_record(js: dict) -> dict:
    h = js.get("rxcuiStatusHistory") or {}
    meta = h.get("metaData") or {}
    attrs = h.get("attributes") or {}
    defs = h.get("definitionalFeatures") or {}
    derived = h.get("derivedConcepts") or {}
    qf = defs.get("quantityFactor") or {}
    strengths = []
    for s in defs.get("ingredientAndStrength") or []:
        strengths.append({k: s.get(k) for k in (
            "baseRxcui", "baseName", "bossRxcui", "bossName", "activeIngredientRxcui", "activeIngredientName",
            "moietyRxcui", "moietyName", "numeratorValue", "numeratorUnit", "denominatorValue", "denominatorUnit")})
    dfs = [{"rxcui": d.get("doseFormRxcui"), "name": d.get("doseFormName")} for d in defs.get("doseFormConcept") or []]
    remapped = [{"rxcui": r.get("remappedRxCui"), "name": r.get("remappedName"), "tty": r.get("remappedTTY"),
                 "active": r.get("remappedActive")} for r in derived.get("remappedConcept") or []]
    scd = derived.get("scdConcept") or {}
    packs = (h.get("pack") or {}).get("packConcept") or []
    return {
        "rxcui": attrs.get("rxcui"),
        "name": attrs.get("name"),
        "tty": attrs.get("tty"),
        "status": (meta.get("status") or "").capitalize() or None,
        "is_current": meta.get("isCurrent"),
        "release_start_mmyyyy": meta.get("releaseStartDate"),
        "release_end_mmyyyy": meta.get("releaseEndDate"),
        "active_start_mmyyyy": meta.get("activeStartDate"),
        "active_end_mmyyyy": meta.get("activeEndDate"),
        "remapped_date_mmyyyy": meta.get("remappedDate"),
        "is_branded": attrs.get("isBranded"),
        "is_multiple_ingredient": attrs.get("isMultipleIngredient"),
        "strengths": strengths,
        "dose_forms": dfs,
        "quantity_factor_value": qf.get("quantityFactorValue") or None,
        "quantity_factor_unit": qf.get("quantityFactorUnit") or None,
        "qualitative_distinction": defs.get("qualitativeDistinction") or None,
        "remapped_to": remapped,
        "scd_rxcui": scd.get("scdConceptRxcui") or scd.get("rxcui") or None,
        "scd_name": scd.get("scdConceptName") or scd.get("name") or None,
        "pack_components": [{"rxcui": p.get("packRxcui"), "name": p.get("packName"), "number": p.get("packNumber")}
                            for p in packs],
    }
