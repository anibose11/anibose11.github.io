"""Every number the report, manuscript, page and claims file cite, computed
from the stored outputs (outputs/analysis/results.json and the database).
Text is never written with hand-typed results."""
from __future__ import annotations

import json
import re
from datetime import timezone

import pandas as pd

from . import db
from .paths import INTERIM, OUTPUTS


def pct(n, d, digits=1):
    return "n/a" if not d else f"{100 * n / d:.{digits}f}%"


def fmt(n):
    return f"{n:,}"


def _q(conn, sql, params=None):
    cur = conn.execute(sql, params or ())
    return pd.DataFrame(cur.fetchall(), columns=[c.name for c in cur.description])


def numbers() -> dict:
    R = json.loads((OUTPUTS / "analysis" / "results.json").read_text())
    rxm = json.loads((INTERIM / "rxnorm_manifest.json").read_text())
    lab = json.loads((INTERIM / "label_manifest.json").read_text())
    N: dict = {"R": R}
    c = R["corpus"]
    N.update({
        "candidates": c["candidate_set_ids"], "eligible": c["eligible_set_ids"], "excluded_legacy": c["excluded_set_ids"],
        "dev_sets": c["development_set_ids"], "held_sets": c["held_out_set_ids"],
        "docs_current": c["documents_current"], "docs_preceding": c["documents_preceding"],
        "docs_total": c["documents_current"] + c["documents_preceding"],
        "prod_records": c["product_records_in_scope"], "prod_current": c["product_records_in_scope_current"],
        "prod_preceding": c["product_records_in_scope_preceding"], "kits": c["kit_product_records"],
        "repackaged": c["repackaged_product_records"], "combos_current": c["combination_product_records_current"],
        "active_records": c["active_ingredient_records"],
        "actib": c["active_ingredient_records_by_class"].get("ACTIB", 0),
        "actim": c["active_ingredient_records_by_class"].get("ACTIM", 0),
        "actir": c["active_ingredient_records_by_class"].get("ACTIR", 0),
        "pkg_records": c["package_records"], "pkg_442": c["package_ndc_patterns"].get("4-4-2", 0),
        "pkg_532": c["package_ndc_patterns"].get("5-3-2", 0), "pkg_541": c["package_ndc_patterns"].get("5-4-1", 0),
        "pkg_nondc": c["package_ndc_patterns"].get("(no NDC)", 0), "out_of_scope_products": c["products_out_of_scope_in_eligible_labels"],
        "version_subset": c["version_subset_set_ids"], "preceding_retrieved": c["preceding_versions_retrieved"],
        "rxnorm_release": rxm["rxnorm_version"]["version"], "rxnav_api": rxm["rxnorm_version"]["apiVersion"],
        "ndcstatus_calls": rxm["ndcstatus_count"], "historystatus_calls": rxm["historystatus_count"],
        "dailymed_db_date": None, "label_retrieval_start": lab["started_utc"], "label_retrieval_end": lab["finished_utc"],
        "mapping_file_bytes": lab["rxnorm_mapping_file"]["bytes"], "mapping_file_sha": lab["rxnorm_mapping_file"]["sha256"],
    })
    m = R["matching"]
    for split in ("held_out", "development"):
        s = "h" if split == "held_out" else "d"
        a = m[f"A_{split}"]
        tot = sum(v["numerator"] for v in a.values())
        N[f"{s}_products"] = tot
        N[f"{s}_a_unique"] = a.get("unique", {}).get("numerator", 0)
        N[f"{s}_a_notfound"] = a.get("not_found", {}).get("numerator", 0)
        N[f"{s}_a_ambiguous"] = a.get("ambiguous", {}).get("numerator", 0)
        a2 = m[f"A2_{split}"]
        N[f"{s}_a2_agree"] = a2["counts"].get("agree", 0)
        N[f"{s}_a2_disagree"] = a2["counts"].get("disagree", 0)
        N[f"{s}_a2_absent"] = a2["counts"].get("not_in_mapping_file", 0)
        N[f"{s}_a2_absent_sets"] = a2["not_in_mapping_file_labels"]
        for ap in ("B", "C"):
            x = m[f"{ap}_{split}"]
            N[f"{s}_{ap.lower()}_answered"] = x["answered"]["numerator"]
            N[f"{s}_{ap.lower()}_agree"] = x["agree_exact"]["numerator"]
            N[f"{s}_{ap.lower()}_wrong"] = x["wrong"]["numerator"]
            N[f"{s}_{ap.lower()}_clinical"] = x["agree_clinical"]["numerator"]
            for k, v in x["not_answered_by_outcome"].items():
                N[f"{s}_{ap.lower()}_{k}"] = v
        N[f"{s}_c_top1"] = m["C_top1_no_abstention"][split]["numerator"]
    sa4 = {(r["split"], r["tau"]): r for r in m["SA4_C_threshold"]}
    taus = sorted({r["tau"] for r in m["SA4_C_threshold"]})
    N["sa4"] = {"tau_low": taus[0], "tau": taus[1], "tau_high": taus[2],
                "low": sa4[("held_out", taus[0])], "mid": sa4[("held_out", taus[1])], "high": sa4[("held_out", taus[2])]}
    pl = {r["split"]: r for r in m["package_level"]}
    N.update({"h_pkg_a_active": pl["held_out"]["a_active"], "h_pkg_b_unique": pl["held_out"]["b_unique"],
              "h_pkg_b_agree": pl["held_out"]["b_agree"], "h_pkg_b_amb": pl["held_out"]["b_ambiguous"],
              "h_pkg_b_none": pl["held_out"]["b_none"]})
    rt = R["roundtrip"]
    N.update({
        "h_r1_ok": rt["R1_full_held_out"]["all_critical"]["numerator"], "h_r1_n": rt["R1_full_held_out"]["all_critical"]["denominator"],
        "h_r1_sets": rt["R1_full_held_out"]["set_ids"],
        "all_r1_ok": rt["R1_full_all"]["all_critical"]["numerator"], "all_r1_n": rt["R1_full_all"]["all_critical"]["denominator"],
        "d_r1_ok": rt["R1_full_development"]["all_critical"]["numerator"], "d_r1_n": rt["R1_full_development"]["all_critical"]["denominator"],
        "r1_normalized_fields": sum(rt["R1_normalized_fields"].values()),
        "h_latest_ok": rt["S_latest_held_out"]["identity_attributes"]["numerator"],
        "h_latest_n": rt["S_latest_held_out"]["identity_attributes"]["denominator"],
        "h_latest_ci": rt["S_latest_held_out"]["ci95_identity"],
        "all_latest_ok": rt["S_latest_all"]["identity_attributes"]["numerator"],
        "all_latest_n": rt["S_latest_all"]["identity_attributes"]["denominator"],
    })
    sens = {s["analysis"]: s for s in rt["sensitivity"]}
    N["sa2_ok"], N["sa2_n"] = sens["SA2 held-out excluding repackaged products"]["all_critical_ok"], sens["SA2 held-out excluding repackaged products"]["records"]
    N["h_kits_n"] = sens["held-out kits"]["records"]
    N["h_combo_n"] = sens["held-out combination products"]["records"]
    N["h_preceding_n"] = sens["held-out preceding versions"]["records"]
    sa3 = {r["representation"]: r for r in rt["SA3_package_grain"]}
    N["sa3"] = sa3
    N["sa3_r1_ok"], N["sa3_n"] = sa3["R1_full"]["all_package_attributes_ok"], sa3["R1_full"]["package_records"]
    N["sa3_core_ok"] = sa3["R_core"]["all_package_attributes_ok"]
    N["sa3_core_n"] = sa3["R_core"]["package_records"]
    N["sa3_products"], N["sa3_sets"] = sa3["R1_full"]["products"], sa3["R1_full"]["set_ids"]
    fs = pd.DataFrame(rt["field_status_held_out"])

    def f(rep, attr, *statuses):
        row = fs[(fs.representation == rep) & (fs.attribute == attr)]
        if row.empty:
            return 0
        return int(sum(row.iloc[0][s] for s in statuses))

    def applicable(rep, attr):
        row = fs[(fs.representation == rep) & (fs.attribute == attr)]
        return 0 if row.empty else int(row.iloc[0]["applicable"])

    N["fs"] = fs
    N.update({
        "h_active_n": applicable("R1_full", "K8_unii"),
        "h_core_boss_disc": f("R_core", "K10_boss_unii", "discordant"),
        "h_core_boss_n": applicable("R_core", "K10_boss_unii"),
        "h_flat_pkg_disc": f("S_flat", "K5_package_ndcs", "discordant"),
        "h_flat_pkg_n": applicable("S_flat", "K5_package_ndcs"),
        "h_flat_count_disc": f("S_flat", "K7_active_count", "discordant"),
        "h_flat_num_text": f("S_flat", "K11_num_value", "discordant"),
        "h_flat_num_n": applicable("S_flat", "K11_num_value"),
        "h_flat_num_carried": f("S_flat", "K11_num_value", "preserved", "preserved_normalized", "discordant"),
        "h_api_count_disc": f("S_api", "K7_active_count", "discordant"),
        "h_api_count_n": applicable("S_api", "K7_active_count"),
        "h_api_num_disc": f("S_api", "K11_num_value", "discordant"),
        "h_api_num_n": applicable("S_api", "K11_num_value"),
        "h_api_den_unres": f("S_api", "K12_den_value", "unresolved"),
        "h_rx_n": applicable("S_rx", "K7_active_count") ,
        "h_rx_unres_products": f("S_rx", "K7_active_count", "unresolved"),
        "h_rx_count_disc": f("S_rx", "K7_active_count", "discordant"),
        "h_rx_boss_conv": f("S_rx", "K10_boss_unii", "converted_equivalent"),
        "h_rx_boss_disc": f("S_rx", "K10_boss_unii", "discordant"),
        "h_rx_num_disc": f("S_rx", "K11_num_value", "discordant"),
        "h_rx_num_conv": f("S_rx", "K11_num_value", "converted_equivalent"),
        "h_rx_class_conv": f("S_rx", "K9_class_code", "converted_equivalent"),
        "h_rx_class_disc": f("S_rx", "K9_class_code", "discordant"),
    })
    sc = R["shortcuts"]["ndc_padding"]
    bycfg = {r["configuration"]: r for r in sc["by_configuration"]}
    N.update({"ndc_distinct": sc["packages"], "ndc_naive_wrong": sc["naive_wrong"]["numerator"],
              "ndc_442_distinct": bycfg["4-4-2"]["package_ndcs"], "ndc_532_distinct": bycfg["5-3-2"]["package_ndcs"],
              "ndc_541_distinct": bycfg["5-4-1"]["package_ndcs"], "ndc_collisions": sc["naive_collides_with_another_corpus_ndc"]})
    v = R["versions"]
    N.update({"v_pairs": v["pairs"], "v_any": v["any_identity_change"]["numerator"],
              "v_pkg_added": v["package_ndcs_added"]["numerator"], "v_pkg_removed": v["package_ndcs_removed"]["numerator"],
              "v_prod_added": v["product_ndcs_added"]["numerator"], "v_prod_removed": v["product_ndcs_removed"]["numerator"],
              "v_ing": v["active_ingredient_or_basis_changed"]["numerator"], "v_strength": v["strength_changed"]["numerator"],
              "v_form": v["form_changed"]["numerator"], "v_labeler": v["labeler_changed"]["numerator"],
              "v_gap1": v["version_gap_distribution"].get("1", 0), "v_removed_ndcs": v["removed_package_ndcs"],
              "v_removed_status": v["removed_package_ndc_rxnorm_status"],
              "v_removed_labels": v["removed_package_ndc_labels"],
              "v_removed_within": v["removed_package_ndcs_within_retained_products"],
              "v_labeler_case": v["labeler_changed_case_or_punctuation_only"],
              "v_weighted": v["sampling"]["any_change_weighted_by_group"],
              "v_multi_eligible": v["sampling"]["eligible_labels_with_two_or_more_versions"],
              "v_single": v["sampling"]["labels_with_one_listed_version"],
              "v_by_group": v["sampling"]["by_group"]})
    val = R["validation"]
    N.update({"val_files": val["offline_all"]["files"], "val_errors": val["offline_all"]["issues_by_severity"].get("error", 0),
              "val_warn": val["offline_all"]["issues_by_severity"].get("warning", 0),
              "val_files_err": val["offline_all"]["files_with_errors"],
              "tx_files": val["tx_sample"]["files"], "tx_errors": val["tx_sample"]["issues_by_severity"].get("error", 0),
              "tx_err_ndc": val["tx_sample"]["errors_by_code_system"].get("http://hl7.org/fhir/sid/ndc", 0),
              "tx_codings": val["tx_sample"]["codings_checked"]["codings_by_system"],
              "tx_ucum_codes": val["tx_sample"]["codings_checked"].get("ucum_codes", {}),
              "tx_inactive_warn": val["tx_sample"]["inactive_code_warnings"],
              "validator_sha": val["validator_sha256"], "java": val["java"]})
    dsum = json.loads((OUTPUTS / "dictionary" / "summary.json").read_text())
    N["dict_rows"] = dsum["rows"]
    N["dict_reasons"] = dsum["reason_counts"]
    fx = json.loads((OUTPUTS / "fhir_export_summary.json").read_text()) if (OUTPUTS / "fhir_export_summary.json").exists() else \
        json.loads((OUTPUTS / "checks" / "fhir_export.json").read_text())
    N["fhir_bundles"], N["fhir_meds"] = fx["bundles"], fx["medications"]
    from .paths import CONFIG
    import subprocess
    import sys as _sys
    col = subprocess.run([_sys.executable, "-m", "pytest", "--collect-only", "-q"], capture_output=True, text=True,
                         cwd=str(OUTPUTS.parent))
    per_file = [int(x) for x in re.findall(r"^\S+\.py: (\d+)$", col.stdout, flags=re.M)]
    m = re.search(r"(\d+) tests? collected", col.stdout)
    N["tests"] = sum(per_file) if per_file else (int(m.group(1)) if m else None)
    if not N["tests"]:
        raise SystemExit("could not count tests")
    rr = json.loads((OUTPUTS / "checks" / "rerun_comparison.json").read_text())
    N["rerun_identical"], N["rerun_total"] = rr["identical"], rr["compared"]
    rc = json.loads((OUTPUTS / "checks" / "independent_recheck.json").read_text())
    N["recheck_date"] = rc["run_utc"][:10]
    N["recheck_live_identical"] = sum(1 for x in rc["live_labels"] if x["result"] == "identical")
    sample = pd.read_csv(OUTPUTS.parent / "docs" / "review_sample.csv", dtype=str)
    N["sample_records"], N["sample_labels"] = len(sample), sample.set_id.nunique()
    from .paths import RAW
    N["raw_mb"] = int(round(sum(f.stat().st_size for f in RAW.rglob("*") if f.is_file() and not f.name.endswith(".meta.json")) / 1e6, -1))
    N["eligible_uniis"] = len(json.loads((CONFIG / "scope_frozen.json").read_text())["eligible_uniis"])
    bc = json.loads((OUTPUTS / "checks" / "build_checks.json").read_text())
    N["build_checks"], N["build_checks_passed"] = len(bc["checks"]), sum(1 for x in bc["checks"] if x["passed"])
    from .rxnav import RxNav
    _rx = RxNav()
    N["allconcepts_n"] = len(_rx.allconcepts().json()["minConceptGroup"]["minConcept"])
    _rx.close()
    db.start()
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        N["groups"] = _q(conn, """select d.primary_group, count(distinct d.set_id) labels, count(*) filter (where p.in_scope) products
                                  from medid.spl_document d join medid.spl_product p using (document_id)
                                  where d.version_kind='current' group by 1 order by 2 desc""")
        N["categories"] = _q(conn, """select coalesce(p.marketing_category_display,'(none)') category, count(*) products
                                      from medid.spl_product p join medid.spl_document d using (document_id)
                                      where d.version_kind='current' and p.in_scope group by 1 order by 2 desc""")
        st = _q(conn, """select s.status, coalesce(k.marketing_status,'(not stated)') ms, count(*) n from medid.spl_package k
                         join medid.spl_product p using (product_key) join medid.spl_document d using (document_id)
                         join medid.rx_ndc_status s on s.ndc11 = k.ndc11
                         where d.version_kind='current' and p.in_scope group by 1,2""")
        N["obsolete_but_active"] = int(st[(st.status == "OBSOLETE") & (st.ms == "active")].n.sum())
        N["obsolete_total"] = int(st[st.status == "OBSOLETE"].n.sum())
        N["pkg_status_total"] = int(st.n.sum())
        rp = _q(conn, """select (p.equivalent_ndc is not null) rep, m.outcome, count(*) n from medid.match_result m
                         join medid.spl_product p using (product_key) where m.approach='A' group by 1,2""")
        rph = _q(conn, """select (p.equivalent_ndc is not null) rep, m.outcome, count(*) n from medid.match_result m
                          join medid.spl_product p using (product_key) join medid.spl_document d using (document_id)
                          where m.approach='A' and d.split='held_out' group by 1,2""")
        N["h_rep_notfound"] = int(rph[(rph.rep) & (rph.outcome == "not_found")].n.sum())
        N["h_rep_total"] = int(rph[rph.rep].n.sum())
        N["h_nonrep_notfound"] = int(rph[(~rph.rep) & (rph.outcome == "not_found")].n.sum())
        N["h_nonrep_total"] = int(rph[~rph.rep].n.sum())
        bx = _q(conn, """select b.outcome, d.primary_group, p.is_kit, coalesce(p.form_display,'') form, count(*) n
                         from medid.match_result a join medid.match_result b on b.product_key=a.product_key and b.approach='B'
                         join medid.spl_product p on p.product_key=a.product_key join medid.spl_document d using (document_id)
                         where a.approach='A' and a.outcome='unique' and d.split='held_out' and b.outcome in ('ambiguous','none')
                         group by 1,2,3,4""")
        amb = bx[bx.outcome == "ambiguous"]
        N["h_b_amb_er_metformin"] = int(amb[(amb.primary_group == "metformin") & amb.form.str.contains("EXTENDED RELEASE")].n.sum())
        non = bx[bx.outcome == "none"]
        N["h_b_none_insulin"] = int(non[non.primary_group == "insulin"].n.sum())
        N["h_b_none_kits"] = int(non[non.is_kit].n.sum())
        rxs = _q(conn, """select d.primary_group, count(*) n from medid.roundtrip_field r join medid.spl_product p using (product_key)
                          join medid.spl_document d using (document_id)
                          where r.representation='S_rx' and r.attribute='K11_num_value' and r.status='discordant'
                            and d.split='held_out' group by 1""")
        N["h_rx_num_disc_insulin"] = int(rxs[rxs.primary_group == "insulin"].n.sum())
        cb = _q(conn, """select b.status, count(*) n from medid.roundtrip_field a join medid.roundtrip_field b
                           on b.product_key=a.product_key and b.item=a.item and b.representation='S_rx' and b.attribute='K10_boss_unii'
                         join medid.spl_product p on p.product_key=a.product_key join medid.spl_document d using (document_id)
                         where a.representation='S_rx' and a.attribute='K9_class_code' and a.status='discordant'
                           and d.split='held_out' group by 1""")
        N["h_rx_class_disc_boss_same"] = int(cb[cb.status == "converted_equivalent"].n.sum())
        N["rep_notfound"] = int(rp[(rp.rep) & (rp.outcome == "not_found")].n.sum())
        N["rep_total"] = int(rp[rp.rep].n.sum())
        N["nonrep_notfound"] = int(rp[(~rp.rep) & (rp.outcome == "not_found")].n.sum())
        N["nonrep_total"] = int(rp[~rp.rep].n.sum())
        units = _q(conn, """select i.num_unit, count(*) n from medid.spl_ingredient i join medid.spl_product p using (product_key)
                            where p.in_scope and i.is_active and i.num_unit in ('U','[iU]','[arb''U]') group by 1""")
        N["units_insulin"] = {r.num_unit: int(r.n) for r in units.itertuples()}
        tz = _q(conn, """select count(*) n from medid.spl_ingredient i join medid.spl_product p using (product_key)
                         where p.in_scope and i.is_active and (i.num_value ~ '\\.[0-9]*0$' or i.den_value ~ '\\.[0-9]*0$')""")
        N["trailing_zero_values"] = int(tz.n.iloc[0])
        multi = _q(conn, """select count(*) n from (select k.ndc_original from medid.spl_package k join medid.spl_product p using (product_key)
                           join medid.spl_document d using (document_id) where d.version_kind='current' and k.ndc_original is not null
                           group by 1 having count(distinct d.set_id) > 1) x""")
        N["ndc_multi_label"] = int(multi.n.iloc[0])
        N["source_files"] = int(_q(conn, "select count(*) n from medid.source_file").n.iloc[0])
        rt_ = _q(conn, """select kind, min(retrieved_utc) lo, max(retrieved_utc) hi, count(*) n from medid.source_file group by 1""")
        N["retrieval"] = {r.kind: (r.lo.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M"), r.hi.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M"), int(r.n)) for r in rt_.itertuples()}
        cats = N["categories"].assign(category=N["categories"].category.str.upper()).groupby("category", as_index=False).products.sum()
        N["categories"] = cats.sort_values("products", ascending=False)
    return N
