"""Build stage: load the canonical source layer into PostgreSQL and check it.

Checks written to outputs/checks/build_checks.json:
- row reconciliation: products, parts, ingredients and packages in the
  database equal the counts the parser produced;
- join cardinality: every product has exactly one document, every package and
  ingredient exactly one product, a package NDC never has two different package
  forms or quantities within one product tree,
  each analyzed set ID has exactly one current version;
- lineage: every document row points to a cached source file whose SHA-256
  matches the bytes on disk.
"""
from __future__ import annotations

import json
from pathlib import Path

from psycopg.types.json import Jsonb

from . import db
from . import ndc as ndc_mod
from .corpus import iter_documents, manifest
from .crosswalk import load_dailymed_mapping
from .http import sha256_file
from .paths import OUTPUTS, ROOT, ensure


def _ing_rows(product_key: str, part_key: str | None, ings) -> list[tuple]:
    rows = []
    for i in ings:
        bu, bn = i.strength_substance()
        key = f"{part_key or product_key}:ing:{i.index}"
        rows.append((key, product_key, part_key, i.index, i.class_code, i.is_active, i.basis_of_strength,
                     i.substance_code, i.substance_name, list(i.moiety_codes), [n or "" for n in i.moiety_names],
                     i.reference_code, i.reference_name, bu, bn, i.num_value, i.num_unit, i.den_value, i.den_unit))
    return rows


def _pkg_rows(product_key: str, part_key: str | None, pkgs) -> list[tuple]:
    rows = []
    for k in pkgs:
        parsed = ndc_mod.parse(k.ndc_original) if k.ndc_original else None
        rows.append((f"{part_key or product_key}:pkg:{k.path}", product_key, part_key, k.path, k.level,
                     k.ndc_original, k.ndc_configuration, parsed.to_11() if parsed else None,
                     ndc_mod.naive_pad_11(k.ndc_original) if k.ndc_original else None,
                     k.form_code, k.form_display, k.qty_num_value, k.qty_num_unit, k.qty_den_value, k.qty_den_unit,
                     k.total_amount_value, k.total_amount_unit, k.total_amount_status,
                     k.marketing_status, k.marketing_low, k.marketing_high, k.marketing_act_code,
                     k.combination_type_code))
    return rows


def build(log=print) -> dict:
    db.start()
    ensure(OUTPUTS / "checks")
    m = manifest()
    counts = {"documents": 0, "products": 0, "products_in_scope": 0, "parts": 0, "ingredients": 0, "packages": 0}
    with db.connect() as conn:
        db.run_sql_file(conn, "schema.sql")
        conn.execute("set search_path = medid")
        cur = conn.cursor()
        files = []
        mf = m["rxnorm_mapping_file"]
        files.append((mf["path"], "dm_mapping", mf["url"], mf["sha256"], mf["bytes"], mf["retrieved_utc"]))
        for e in m["labels"]:
            if e["status"] != "eligible":
                continue
            x = e["current_xml"]
            files.append((x["path"], "spl_current_xml", x["url"], x["sha256"], x["bytes"], x["retrieved_utc"]))
            if e.get("packaging"):
                pk = e["packaging"]
                files.append((pk["path"], "dm_packaging", pk["url"], pk["sha256"], pk["bytes"], pk["retrieved_utc"]))
        for p in m["preceding_versions"]:
            for a in p["attempts"]:
                if a["result"] == "ok":
                    z = a["zip"]
                    files.append((z["path"], "spl_version_zip", z["url"], z["sha256"], z["bytes"], z["retrieved_utc"]))
                    files.append((a["xml_path"], "spl_version_xml", z["url"] + "#" + a["xml_member"], a["xml_sha256"],
                                  (ROOT / a["xml_path"]).stat().st_size, z["retrieved_utc"]))
        cur.executemany("insert into source_file values (%s,%s,%s,%s,%s,%s) on conflict do nothing", files)

        for doc, meta in iter_documents():
            cur.execute("insert into spl_document values (" + ",".join(["%s"] * 14) + ")",
                        (doc.document_id, doc.set_id, int(doc.version_number), meta["version_kind"],
                         doc.effective_time, doc.doc_type_code, doc.title, doc.labeler_name, doc.labeler_id,
                         doc.labeler_id_root, meta["split"], meta["primary_group"], meta["groups"],
                         meta["source_path"]))
            counts["documents"] += 1
            ing_rows, pkg_rows, part_rows = [], [], []
            for p in doc.products:
                pk = f"{doc.document_id}:{p.index}"
                in_scope = p.index in meta["products_in_scope"]
                cur.execute("insert into spl_product values (" + ",".join(["%s"] * 20) + ")",
                            (pk, doc.document_id, p.index, in_scope, p.ndc_original, p.ndc_configuration,
                             p.proprietary_name, p.name_suffix, p.generic_name, p.form_code, p.form_display,
                             p.route_codes, p.approval_id, p.marketing_category_code, p.marketing_category_display,
                             p.marketing_status, p.marketing_low, p.marketing_high, p.equivalent_ndc, p.is_kit))
                counts["products"] += 1
                counts["products_in_scope"] += in_scope
                ing_rows += _ing_rows(pk, None, p.ingredients)
                pkg_rows += _pkg_rows(pk, None, p.packages)
                for part in p.parts:
                    prt = f"{pk}:part:{part.index}"
                    part_rows.append((prt, pk, part.index, part.ndc_original, part.name, part.form_code,
                                      part.form_display, part.qty_num_value, part.qty_num_unit,
                                      part.qty_den_value, part.qty_den_unit))
                    ing_rows += _ing_rows(pk, prt, part.ingredients)
                    pkg_rows += _pkg_rows(pk, prt, part.packages)
            cur.executemany("insert into spl_part values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", part_rows)
            cur.executemany("insert into spl_ingredient values (" + ",".join(["%s"] * 19) + ")", ing_rows)
            cur.executemany("insert into spl_package values (" + ",".join(["%s"] * 23) + ")", pkg_rows)
            counts["parts"] += len(part_rows)
            counts["ingredients"] += len(ing_rows)
            counts["packages"] += len(pkg_rows)

        eligible = {e["setid"] for e in m["labels"] if e["status"] == "eligible"}
        maprows = [(r["setid"], r["spl_version"], r["rxcui"], r["rxstring"], r["tty"])
                   for r in load_dailymed_mapping() if r["setid"] in eligible]
        cur.executemany("insert into dm_rxnorm_mapping values (%s,%s,%s,%s,%s)", maprows)
        counts["dm_mapping_rows"] = len(maprows)
        conn.commit()
        checks = run_checks(conn, counts)
    (OUTPUTS / "checks" / "build_checks.json").write_text(json.dumps(checks, indent=1))
    failed = [c for c in checks["checks"] if not c["passed"]]
    log(f"build: {counts}; checks failed: {len(failed)}")
    if failed:
        raise SystemExit(f"build checks failed: {[c['name'] for c in failed]}")
    return checks


def run_checks(conn, counts: dict) -> dict:
    q = lambda sql: conn.execute(sql).fetchone()[0]  # noqa: E731
    checks = []

    def check(name, observed, expected):
        checks.append({"name": name, "observed": observed, "expected": expected, "passed": observed == expected})

    check("documents loaded", q("select count(*) from spl_document"), counts["documents"])
    check("products loaded", q("select count(*) from spl_product"), counts["products"])
    check("in-scope products loaded", q("select count(*) from spl_product where in_scope"), counts["products_in_scope"])
    check("parts loaded", q("select count(*) from spl_part"), counts["parts"])
    check("ingredients loaded", q("select count(*) from spl_ingredient"), counts["ingredients"])
    check("packages loaded", q("select count(*) from spl_package"), counts["packages"])
    check("products without a document", q("select count(*) from spl_product p left join spl_document d using (document_id) where d.document_id is null"), 0)
    check("set IDs with other than one current version",
          q("select count(*) from (select set_id from spl_document group by set_id having count(*) filter (where version_kind='current') <> 1) x"), 0)
    check("package NDCs defined inconsistently within one product tree (different package form or quantity)",
          q("""select count(*) from (select k.product_key, k.ndc_original from spl_package k
               where k.ndc_original is not null group by 1,2
               having count(distinct (coalesce(k.form_code,''), coalesce(k.qty_num_value,''), coalesce(k.qty_num_unit,''))) > 1) x"""), 0)
    check("in-scope products with no active ingredient",
          q("""select count(*) from spl_product p where in_scope and not exists
               (select 1 from spl_ingredient i where i.product_key = p.product_key and i.is_active)"""), 0)
    check("eligible documents with wrong document type", q("select count(*) from spl_document where doc_type_code <> '34391-3'"), 0)
    check("development and held-out overlap by set ID",
          q("select count(*) from (select set_id from spl_document group by set_id having count(distinct split) > 1) x"), 0)
    bad_hash = 0
    for path, sha in conn.execute("select path, sha256 from source_file where kind in ('spl_current_xml','spl_version_xml')"):
        if sha256_file(ROOT / path) != sha:
            bad_hash += 1
    check("source files whose bytes no longer match their SHA-256", bad_hash, 0)
    summary = {k: q(f"select count(*) from {t}") for k, t in [
        ("source_files", "source_file"), ("documents", "spl_document"), ("products", "spl_product"),
        ("parts", "spl_part"), ("ingredients", "spl_ingredient"), ("packages", "spl_package"),
        ("dm_mapping_rows", "dm_rxnorm_mapping")]}
    cross_doc = q("""select count(*) from (select k.ndc_original from spl_package k join spl_product p using (product_key)
                     join spl_document d using (document_id) where d.version_kind='current' and k.ndc_original is not null
                     group by 1 having count(distinct d.set_id) > 1) x""")
    repeats = q("""select count(*) from (select k.product_key, k.ndc_original from spl_package k
                   where k.ndc_original is not null group by 1,2 having count(*) > 1) x""")
    return {"counts": counts, "table_rows": summary, "checks": checks,
            "notes": {"package NDCs listed in more than one current label": cross_doc,
                      "product trees listing the same inner package NDC under more than one outer package": repeats}}
