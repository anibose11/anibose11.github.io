"""National Drug Code handling that keeps the original segment pattern.

FDA lists 10-digit NDCs in three hyphenated segments (labeler-product-package)
in one of three configurations: 4-4-2, 5-3-2 or 5-4-1. The 11-digit 5-4-2 form
used in HIPAA billing transactions is made by left-padding whichever segment
is short. That conversion is only defined when the segment pattern is known;
removing hyphens and left-padding the whole string (the shortcut evaluated in
this study) produces a different code for 5-3-2 and 5-4-1 NDCs.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

PACKAGE_CONFIGS = {(4, 4, 2): "4-4-2", (5, 3, 2): "5-3-2", (5, 4, 1): "5-4-1"}
PRODUCT_CONFIGS = {(4, 4): "4-4", (5, 3): "5-3", (5, 4): "5-4"}

_SEGMENTED = re.compile(r"^\d+(-\d+){1,2}$")


@dataclass(frozen=True)
class ParsedNDC:
    original: str
    kind: str            # "package", "product" or "unrecognized"
    configuration: str   # e.g. "5-3-2", "4-4", or the observed pattern when unrecognized
    labeler: str | None
    product: str | None
    package: str | None

    @property
    def recognized(self) -> bool:
        return self.kind != "unrecognized"

    @property
    def product_code(self) -> str | None:
        """Labeler-product code with the original hyphenation (e.g. '0093-1048')."""
        if not self.recognized:
            return None
        return f"{self.labeler}-{self.product}"

    def to_11(self) -> str | None:
        """11-digit 5-4-2 code for a recognized package NDC, otherwise None."""
        if self.kind != "package":
            return None
        return self.labeler.zfill(5) + self.product.zfill(4) + self.package.zfill(2)

    def product_to_9(self) -> str | None:
        """9-digit 5-4 labeler-product code (RxNorm 'ndc9' style) for any recognized NDC."""
        if not self.recognized:
            return None
        return self.labeler.zfill(5) + self.product.zfill(4)


def parse(code: str) -> ParsedNDC:
    """Parse an NDC exactly as written in the source. Never guesses a pattern."""
    raw = code
    s = code.strip()
    if not _SEGMENTED.match(s):
        return ParsedNDC(raw, "unrecognized", _pattern(s), None, None, None)
    parts = s.split("-")
    lens = tuple(len(p) for p in parts)
    if len(parts) == 3 and lens in PACKAGE_CONFIGS:
        return ParsedNDC(raw, "package", PACKAGE_CONFIGS[lens], parts[0], parts[1], parts[2])
    if len(parts) == 2 and lens in PRODUCT_CONFIGS:
        return ParsedNDC(raw, "product", PRODUCT_CONFIGS[lens], parts[0], parts[1], None)
    return ParsedNDC(raw, "unrecognized", "-".join(str(n) for n in lens), None, None, None)


def _pattern(s: str) -> str:
    return re.sub(r"\d+", lambda m: str(len(m.group())), s) or "(empty)"


def naive_pad_11(code: str) -> str | None:
    """Shortcut baseline: strip non-digits and left-pad to 11 digits.

    This is what a pipeline does when it ignores the segment pattern. It is
    correct only for 4-4-2 codes.
    """
    digits = re.sub(r"\D", "", code)
    if not digits or len(digits) > 11:
        return None
    return digits.zfill(11)


def from_11(ndc11: str, configuration: str) -> str:
    """Rebuild the hyphenated 10-digit form from an 11-digit code and a known pattern."""
    if not re.fullmatch(r"\d{11}", ndc11):
        raise ValueError(f"not an 11-digit NDC: {ndc11!r}")
    lab, prod, pkg = ndc11[:5], ndc11[5:9], ndc11[9:]
    if configuration == "4-4-2":
        if lab[0] != "0":
            raise ValueError("4-4-2 requires a leading zero in the 5-digit labeler")
        return f"{lab[1:]}-{prod}-{pkg}"
    if configuration == "5-3-2":
        if prod[0] != "0":
            raise ValueError("5-3-2 requires a leading zero in the 4-digit product")
        return f"{lab}-{prod[1:]}-{pkg}"
    if configuration == "5-4-1":
        if pkg[0] != "0":
            raise ValueError("5-4-1 requires a leading zero in the 2-digit package")
        return f"{lab}-{prod}-{pkg[1:]}"
    raise ValueError(f"unknown configuration {configuration!r}")


def candidate_configurations_from_11(ndc11: str) -> list[str]:
    """All 10-digit patterns an 11-digit code could have come from.

    Shows why the 11-digit form alone is not reversible: a code with several
    padding zeros fits more than one pattern.
    """
    out = []
    for cfg in ("4-4-2", "5-3-2", "5-4-1"):
        try:
            from_11(ndc11, cfg)
            out.append(cfg)
        except ValueError:
            pass
    return out
