"""Manuscript (JAMIA Open, Research and Applications format), generated
from the computed numbers so that no result is typed by hand."""
from __future__ import annotations

import re

import markdown

from .numbers import fmt, pct
from .paths import ROOT, ensure

MS = ROOT / "manuscript"

AUTHOR = "Animesh Bose"
AFFILIATION = "Norlowe Research"
TITLE = ("Version-aware medication identity from DailyMed labels to FHIR R4: attribute-level round-trip fidelity "
         "and the cost of common shortcuts")
# Journal-only fields (disclosure statement, corresponding-author contact) are read from a private file that is
# not distributed with the source; without it only the public rendering is written.
PRIVATE = ROOT / ".local" / "journal_private.toml"


def _private() -> dict | None:
    import tomllib
    return tomllib.loads(PRIVATE.read_text()) if PRIVATE.exists() else None


KEYWORDS = ["RxNorm", "drug labeling", "Fast Healthcare Interoperability Resources", "National Drug Code",
            "controlled vocabulary"]


def p(n, d):
    return pct(n, d)


_NUM_WORD = {2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine", 10: "ten"}


def _long_date(s: str) -> str:
    """'2026-10-07' or '05-Oct-2026' -> 'October 7, 2026' (US style for running text)."""
    from datetime import datetime
    for f in ("%Y-%m-%d", "%d-%b-%Y"):
        try:
            d = datetime.strptime(s, f)
            return f"{d:%B} {d.day}, {d.year}"
        except ValueError:
            pass
    raise ValueError(s)


REFERENCES = [
    ("zhu2012", "Zhu Q, Jiang G, Chute CG. Profiling structured product labeling with NDF-RT and RxNorm. J Biomed Semantics. 2012;3(1):16. doi:10.1186/2041-1480-3-16"),
    ("schadow2007", "Schadow G. Assessing the impact of HL7/FDA Structured Product Label (SPL) content for medication knowledge management. AMIA Annu Symp Proc. 2007;2007:646-650. PMID: 18693916"),
    ("nelson2011", "Nelson SJ, Zeng K, Kilbourne J, et al. Normalized names for clinical drugs: RxNorm at 6 years. J Am Med Inform Assoc. 2011;18(4):441-448. doi:10.1136/amiajnl-2011-000116"),
    ("peters2015", "Peters LB, Bodenreider O. Approaches to supporting the analysis of historical medication datasets with RxNorm. AMIA Annu Symp Proc. 2015;2015:1034-1041. PMID: 26958241"),
    ("peters2017", "Peters L, Nguyen T, Bodenreider O. Terminology status APIs: mapping obsolete codes to current RxNorm, SNOMED CT, and LOINC concepts. Stud Health Technol Inform. 2017;245:1333. doi:10.3233/978-1-61499-830-3-1333"),
    ("bona2019", "Bona JP, Brochhausen M, Hogan WR. Enhancing the drug ontology with semantically-rich representations of National Drug Codes and RxNorm unique concept identifiers. BMC Bioinformatics. 2019;20(Suppl 21):708. doi:10.1186/s12859-019-3192-8"),
    ("podchiyska2010", "Podchiyska T, Hernandez P, Ferris T, et al. Managing medical vocabulary updates in a clinical data warehouse: an RxNorm case study. AMIA Annu Symp Proc. 2010;2010:477-481. PMID: 21347024"),
    ("lester2022", "Lester CA, Flynn AJ, Marshall VD, et al. Comparing the variability of ingredient, strength, and dose form information from electronic prescriptions with RxNorm drug product descriptions. J Am Med Inform Assoc. 2022;29(9):1471-1479. doi:10.1093/jamia/ocac096"),
    ("dhavle2015", "Dhavle AA, Ward-Charlerie S, Rupp MT, et al. Analysis of National Drug Code identifiers in ambulatory e-prescribing. J Manag Care Spec Pharm. 2015;21(11):1025-1031. doi:10.18553/jmcp.2015.21.11.1025"),
    ("dhavle2016", "Dhavle AA, Ward-Charlerie S, Rupp MT, et al. Evaluating the implementation of RxNorm in ambulatory electronic prescriptions. J Am Med Inform Assoc. 2016;23(e1):e99-e107. doi:10.1093/jamia/ocv131"),
    ("davidson2020", "Davidson L, Boland MR. Comparative analysis and evaluation of state-of-the-art medication mapping tools to transform a local medication terminology to RxNorm. AMIA Jt Summits Transl Sci Proc. 2020;2020:126-135. PMID: 32477631"),
    ("hong2019", "Hong N, Wen A, Shen F, et al. Developing a scalable FHIR-based clinical data normalization pipeline for standardizing and integrating unstructured and structured electronic health record data. JAMIA Open. 2019;2(4):570-579. doi:10.1093/jamiaopen/ooz056"),
    ("reich2024", "Reich C, Ostropolets A, Ryan P, et al. OHDSI Standardized Vocabularies: a large-scale centralized reference ontology for international data harmonization. J Am Med Inform Assoc. 2024;31(3):583-590. doi:10.1093/jamia/ocad247"),
    ("waters2023", "Waters R, Malecki S, Lail S, et al. Automated identification of unstandardized medication data: a scalable and flexible data standardization pipeline using RxNorm on GEMINI multicenter hospital data. JAMIA Open. 2023;6(3):ooad062. doi:10.1093/jamiaopen/ooad062"),
    ("korpela2026", "Korpela E, Rubin LH, Dastgheyb RM, et al. RxMap: an LLM-assisted tool for medication normalization. JAMIA Open. 2026;9(3):ooag085. doi:10.1093/jamiaopen/ooag085"),
    ("kinsella2024", "Kinsella L, Brook J, Briest M, et al. Inconsistent excipient listings in DailyMed: implications for drug safety. Naunyn Schmiedebergs Arch Pharmacol. 2024;397(9):6851-6854. doi:10.1007/s00210-024-03067-x"),
    ("splig", "US Food and Drug Administration. Structured Product Labeling (SPL) Implementation Guide with Validation Procedures. Version 1, revision 202312080859; December 2023. https://www.fda.gov/media/84201/download. Accessed October 7, 2026."),
    ("fdandcbg", "US Food and Drug Administration. National Drug Code database background information. https://www.fda.gov/drugs/development-approval-process-drugs/national-drug-code-database-background-information. Accessed October 7, 2026."),
    ("rxnavtos", "US National Library of Medicine. RxNav terms of service. https://lhncbc.nlm.nih.gov/RxNav/TermsofService.html. Accessed October 7, 2026."),
    ("ucum", "Schadow G, McDonald CJ. The Unified Code for Units of Measure. Version 2.2. Regenstrief Institute and the UCUM Organization; 2024. https://ucum.org/ucum. Accessed October 7, 2026."),
    ("fhirmpi", "HL7 International. FHIR Release 4 (v4.0.1): MedicinalProductIngredient. https://hl7.org/fhir/R4/medicinalproductingredient.html. Accessed October 7, 2026."),
    ("fdandc", "US Food and Drug Administration. National Drug Code format. https://www.fda.gov/drugs/electronic-drug-registration-and-listing-system-edrls/national-drug-code-format. Accessed October 7, 2026."),
    ("dailymedws", "US National Library of Medicine. DailyMed web services. https://dailymed.nlm.nih.gov/dailymed/app-support-web-services.cfm. Accessed October 7, 2026."),
    ("rxnav", "US National Library of Medicine. RxNorm API. https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html. Accessed October 7, 2026."),
    ("fhirmed", "HL7 International. FHIR Release 4 (v4.0.1): Medication. https://hl7.org/fhir/R4/medication.html. Accessed October 7, 2026."),
    ("splfhir", "HL7 International, Biomedical Research and Regulation Work Group. SPL Mapping FHIR R5 Implementation Guide, continuous-integration build 0.2.8. https://build.fhir.org/ig/HL7/fhir-spl/. Accessed October 7, 2026."),
    ("fhirr5ing", "HL7 International. FHIR Release 5 (v5.0.0): Ingredient. https://hl7.org/fhir/R5/ingredient.html. Accessed October 7, 2026."),
    ("uscore", "HL7 International. US Core Implementation Guide 9.0.0 (STU9): US Core Medication profile. https://hl7.org/fhir/us/core/STU9/StructureDefinition-us-core-medication.html. Accessed October 7, 2026."),
    ("validator", "HL7 International and contributors. FHIR validator (validator_cli.jar), release 7.0.0. https://github.com/hapifhir/org.hl7.fhir.core/releases/tag/7.0.0. Accessed October 7, 2026."),
]
REF_NUM = {k: i + 1 for i, (k, _) in enumerate(REFERENCES)}


def cite(*keys: str) -> str:
    """Placeholder resolved after assembly so that references are numbered by first citation."""
    for k in keys:
        if k not in REF_NUM:
            raise KeyError(k)
    return "[[ref:" + ",".join(keys) + "]]"


def number_citations(md: str) -> tuple[str, list[tuple[str, str]]]:
    order: list[str] = []
    for m in re.finditer(r"\[\[ref:([^\]]+)\]\]", md):
        for k in m.group(1).split(","):
            if k not in order:
                order.append(k)
    num = {k: i + 1 for i, k in enumerate(order)}
    out = re.sub(r"\[\[ref:([^\]]+)\]\]",
                 lambda m: "[" + ",".join(str(n) for n in sorted(num[k] for k in m.group(1).split(","))) + "]", md)
    refs = dict(REFERENCES)
    return out, [(k, refs[k]) for k in order]


def build_text(N: dict, fig: dict, version: str = "public") -> dict:
    c = cite
    rows = {r["representation"]: r for r in fig["fig1"]}
    core = rows["R_core"]
    rx = rows["S_rx"]
    api = rows["S_api"]
    flat = rows["S_flat"]
    latest = rows["S_latest"]
    cats = N["categories"]
    cat_anda = int(cats[cats.category == "ANDA"].products.sum())
    cat_nda = int(cats[cats.category == "NDA"].products.sum())
    cat_bla = int(cats[cats.category == "BLA"].products.sum())
    cat_ag = int(cats[cats.category == "NDA AUTHORIZED GENERIC"].products.sum())
    cat_un = int(cats[cats.category == "UNAPPROVED DRUG OTHER"].products.sum())
    g = {r.primary_group: (int(r.labels), int(r.products)) for r in N["groups"].itertuples()}
    T = {}

    cat_exp = int(cats[cats.category == "EXPORT ONLY"].products.sum())
    vg = N["v_by_group"]
    one_in = round(N["v_pairs"] / N["v_any"]) if N["v_any"] else None
    sa4 = N["sa4"]
    rx_other = N["h_rx_num_disc"] - N["h_rx_num_disc_insulin"]
    if rx_other != 1:
        raise SystemExit("the RxCUI strength sentence assumes exactly one non-insulin difference")
    if N["h_rx_class_disc_boss_same"] != N["h_rx_class_disc"]:
        raise SystemExit("the RxCUI class-code sentence assumes the basis substance agreed in every class-code difference")
    dup = N["R"]["corpus"]["active_records_moiety_listed_twice"]
    dup_all = sum(dup.values())
    if N["v_strength"]:
        ver_change = (f"{N['v_ing']} changed an active ingredient substance or its basis and {N['v_strength']} changed a strength; "
                      "no dosage form changed")
    else:
        ver_change = f"{N['v_ing']} changed an active ingredient substance or its basis. No strength or dosage form changed"
    rxrel = _long_date(N["rxnorm_release"])

    T["abstract"] = f"""**Objectives:** To measure which identity and strength attributes of US prescription drug labels are preserved when the labels are converted to Fast Healthcare Interoperability Resources Release 4 (FHIR R4) Medication resources or handled with common shortcuts, how name-based matching agrees with a National Drug Code (NDC) crosswalk to RxNorm, and how often label versions change product identity.

**Materials and Methods:** All {fmt(N['eligible'])} current DailyMed prescription labels containing metformin, empagliflozin, dapagliflozin, semaglutide, liraglutide, one of seven insulins, atorvastatin or lisinopril were retrieved with the preceding version of {N['preceding_retrieved']} labels ({fmt(N['prod_records'])} product-version records). Labels were parsed into a lossless PostgreSQL layer, written as FHIR R4 resources with a schema-validated companion record, validated, and read back against a separate parse of the source XML on {fmt(N['held_sets'])} held-out labels.

**Results:** FHIR plus the companion record preserved every applicable critical attribute for {fmt(N['h_r1_ok'])} of {fmt(N['h_r1_n'])} held-out records. Read from FHIR core elements alone, {fmt(N['h_core_boss_disc'])} of {fmt(N['h_core_boss_n'])} active ingredients ({p(N['h_core_boss_disc'], N['h_core_boss_n'])}) took the wrong basis-of-strength substance. Padding NDCs without their segment pattern changed {p(N['ndc_naive_wrong'], N['ndc_distinct'])} of codes. DailyMed's packaging service gave the wrong ingredient count for {p(N['h_api_count_disc'], N['h_api_count_n'])} of products. Approximate name matching disagreed with the crosswalk for {p(N['h_c_wrong'], N['h_c_answered'])} of its answers, and {p(N['v_any'], N['v_pairs'])} of {N['v_pairs']} sampled label version pairs changed product identity.

**Discussion:** R4 Medication has no element for a label's set identifier, version number or basis of strength, and common shortcuts lose NDC segment patterns, label versions and per-product strengths.

**Conclusion:** A reversible R4 representation of drug labels needs a documented companion record for these attributes."""

    T["lay"] = f"""Drug labels published by the US government describe each medicine's ingredients, strengths, forms and package codes. Research databases and drug dictionaries copy these details into other formats, often through shortcuts such as reformatting package codes or keeping only the newest label. This study took every current prescription label for a set of diabetes, cholesterol and blood-pressure medicines, converted them into a widely used health-data format (FHIR), converted them back, and checked each detail against the original label. When the conversion included a small companion record, every critical detail came back intact. Without it, the standard format could not say whether a stated strength refers to the salt form of a drug or to the active part of the molecule, which affected more than a quarter of active ingredients. Simple package-code padding changed nine in ten codes. Treating a label-level web service as a source of product-specific ingredients gave the wrong ingredient count for about half the products. About one in {_NUM_WORD[one_in]} of the {N['v_pairs']} labels checked changed product details between versions. These findings concern how the data are handled. They say nothing about the safety or effectiveness of any medicine, and no patient information was used."""

    T["intro"] = f"""Research data managers and maintainers of medication dictionaries build product tables from the US Food and Drug Administration (FDA) Structured Product Labeling (SPL) documents, which the National Library of Medicine (NLM) publishes through DailyMed, and from RxNorm, NLM's normalized naming system for clinical drugs {c('nelson2011', 'dailymedws')}. These tables feed analysis databases and Health Level Seven (HL7) Fast Healthcare Interoperability Resources (FHIR). Each step invites shortcuts: an 11-digit National Drug Code (NDC) built by stripping hyphens and padding with zeros, a product collapsed to one RxNorm concept, a label read only in its latest version, strengths parsed as binary floating-point numbers, or attributes dropped because the FHIR Release 4 (R4) Medication resource has no element for them {c('fhirmed')}.

Earlier work established high identifier linkage, but also showed that coverage and attribute agreement depend on how the lookup is done. Zhu, Jiang and Chute linked 97.0% of 36,568 DailyMed labels to RxNorm, mostly at the ingredient level {c('zhu2012')}. Schadow found that SPL and RxNorm agreed on ingredient moieties for 91% of 7,083 SPL NDCs after converting NDCs to 11 digits {c('schadow2007')}. Peters and Bodenreider built a dated NDC history from monthly RxNorm releases and showed that, in two historical medication datasets, current-release lookups left 22% and 33% of NDCs unknown, against 2.4% and 3.3% with the history. The work informed the design of RxNorm's NDC status function {c('peters2015')}. 

NLM's terminology status services map obsolete codes to current concepts {c('peters2017')}, and RxNorm concept unique identifier (RxCUI) remapping, splits and NDC reuse are documented {c('bona2019', 'podchiyska2010')}. In e-prescribing, strength agreed exactly with RxNorm attributes reached through NDCs in 51.23% of pairs {c('lester2022')}, and NDC and RxCUI disagreement has been measured {c('dhavle2015', 'dhavle2016')}. Tools that map medication names to RxNorm have been compared {c('davidson2020')}, and normalization pipelines continue to appear {c('waters2023', 'korpela2026')}. 

For FHIR representation, HL7 maintains an unpublished SPL-to-FHIR R5 mapping guide with transforms in both directions {c('splfhir')}, and a natural language processing pipeline into FHIR reported F scores for Medication elements and assigned a default strength denominator of 1 {c('hong2019')}. In the Observational Health Data Sciences and Informatics (OHDSI) Standardized Vocabularies, 68% of drug-domain mappings from source codes to standard concepts are many-to-one {c('reich2024')}.

The studies reviewed did not report, attribute by attribute, which identity and strength attributes are preserved when a specific label version is carried into FHIR R4 and back, or what each common shortcut loses on the same records."""

    T["objective"] = """This study measured which identity and strength attributes survive a round trip through FHIR R4 Medication resources, with and without a companion record. It included all current US prescription labels containing selected ingredients in six cardiometabolic groups. On the same records, it measured losses from common shortcuts, compared three matching approaches with an NDC-based RxNorm crosswalk, and assessed product-identity changes between label versions. It updates the SPL-to-RxNorm linkage literature on a 2026 snapshot and adds label versions, a measured FHIR R4 round trip and a reusable dictionary export."""

    T["methods"] = f"""### Study design and analysis plan

This was a secondary analysis of publicly available drug-labeling and terminology records. It used no patient or personal data and recruited no participants, so no ethics approval was required, and none was sought. The analysis plan, eligibility rules and outcome definitions were committed to the project's version history before the corpus was retrieved (docs/analysis_plan.md). The plan was not publicly registered. Label set IDs were assigned to development (30%) and held-out (70%) splits by a salted SHA-256 rule before any tuning. Matching rules were tuned on development products only and frozen before the held-out evaluation. Later changes to comparison code, FHIR display text, the version comparison and one parser rule are listed as amendments in the plan. None changed a matching rule, and the affected stages were rerun.

### Sources and scope

DailyMed web services were queried on {_long_date(N['recheck_date'])} {c('dailymedws')}. The seed ingredients were metformin; the sodium-glucose cotransporter 2 (SGLT2) inhibitors empagliflozin and dapagliflozin; the glucagon-like peptide-1 (GLP-1) receptor agonists semaglutide and liraglutide; insulin glargine, lispro, aspart, degludec and detemir and regular and isophane human insulin; atorvastatin; and lisinopril. Candidate labels came from DailyMed's filter on active-moiety Unique Ingredient Identifiers (UNIIs) and from name searches, restricted to human prescription drug labels; the {N['eligible_uniis']} UNIIs were taken from RxNorm for each seed ingredient and its precise forms and frozen before labels were read. A label was eligible when its own XML had document type 34391-3 and a product or kit part had an active ingredient whose substance or moiety UNII was in the frozen set. Combination products were kept whole. Of {fmt(N['candidates'])} candidates, {fmt(N['eligible'])} were eligible; {N['excluded_legacy']} legacy-format labels from 2006 to 2008 had no product data section and could not meet the rule. Human regular, isophane and 70/30 insulins sold without a prescription are over-the-counter (OTC) labels, outside this scope.

For up to 40 labels per ingredient group, chosen by a salted hash among the {N['v_multi_eligible']} eligible labels listing two or more versions (from all {vg['glp1']['multi_version_labels']} such GLP-1 labels to {vg['metformin']['pairs']} of {vg['metformin']['multi_version_labels']} metformin labels), the immediately preceding available version was downloaded from DailyMed's archive and checked for set ID and version number. Shares from this equal-allocation sample are unweighted. All {N['preceding_retrieved']} were retrieved; {N['v_gap1']} were exactly one version older. RxNorm was queried through its public application programming interface (API; release of {rxrel}) {c('rxnav')} at no more than 8 requests per second, under the limit of 20 in the RxNav terms of service {c('rxnavtos')}; every response was cached with its retrieval time and SHA-256.

### Canonical layer and NDC handling

The product data section of each label was parsed with every identity value kept as written: product and package NDCs with their hyphenation, ingredient UNIIs, the ingredient class code that states the basis of strength (ACTIB, the ingredient itself; ACTIM, its active moiety; ACTIR, a reference substance), strength numerator and denominator as decimal text with their units, dosage form, routes, the package tree with each level's quantity, marketing data and kit parts {c('splig')}. The layer was loaded into PostgreSQL 17 with checks on row counts, join cardinality and source file hashes; {N['build_checks_passed']} of {N['build_checks']} checks passed. An NDC was converted to 11 digits only through its own segment pattern (4-4-2, 5-3-2 or 5-4-1) {c('fdandcbg')}.

### Matching approaches

Approach A, the reference, looked up each package NDC with RxNorm's NDC status service and assigned the product the single RxCUI its ACTIVE packages shared. Approach A2 checked agreement with DailyMed's set-level SPL-to-RxNorm mapping file, which lists RxCUIs per label but not per product. Approach B compared the label's basis-of-strength substance names, normalized by fixed rules, and its strength, dose form, fill volume and brand with the structure RxNorm gives for each candidate concept. Approach C scored the label's name, strength and form text against all {fmt(N['allconcepts_n'])} current RxNorm clinical and branded drug and pack names with a token-sort ratio and abstained below a threshold of {sa4['tau']}, chosen by a prespecified grid search on the development split. Agreement with approach A is agreement between terminologies. It says nothing about clinical interchangeability.

### FHIR representation

Each label version became one FHIR R4 (4.0.1) Bundle holding a product-level Medication per in-scope product, a package-level Medication per package NDC, and a Provenance resource naming the source document by its SPL document ID. Package NDCs went into Medication.code exactly as labeled, with an RxNorm coding added when approach A gave a single RxCUI. Product NDCs went into Medication.identifier, the dosage form into Medication.form with its NCI Thesaurus code, ingredients with their UNIIs and isActive flags, strengths as Ratios written with the label's exact decimal text, package contents (multiplied exactly through the package tree) into Medication.amount, and kit parts as contained Medications. 

Medication.manufacturer and Medication.status were left empty because the SPL labeler can be a repackager and SPL marketing status is not dictionary use status. Attributes with no R4 Medication element (set ID, version, basis-of-strength code and substance, routes, package hierarchy, marketing and application data) went into a companion record per Bundle (the "sidecar" in Table 2 and Figure 1), keyed by Medication.id and validated against a JSON Schema. The HL7 validator 7.0.0 {c('validator')} checked all Bundles with terminology checks off and a fixed sample of 60 against the public terminology server.

### Round trip and comparison representations

A reverse transform read the stored Bundles and companion records and reconstructed the critical attributes: set ID, document ID, version, product NDC, package NDCs, dosage form, number of active ingredients, and for each active ingredient its UNII, basis-of-strength code and substance and the strength numerator and denominator with units, plus kit part NDCs. The comparison target was a second, separately written reader of the source XML. Each field was classed as preserved, preserved after a documented normalization (the JSON number grammar and lowercase FHIR UUIDs), equal only after a documented conversion, held only in the companion record, unresolved, discordant, or inapplicable when the label does not state it. The same comparison was run for FHIR core elements alone, read the only way R4 Medication allows (a strength refers to the listed ingredient); for an RxCUI-only record re-derived from current RxNorm; for a flat export holding the set ID, package NDCs stripped of hyphens and left-padded to 11 digits, the dosage form as text and float strengths of the first active ingredient only; for DailyMed's packaging service; and, for preceding versions, for the latest version of the same label. Shares of identity and strength fields cover the critical attributes other than set ID, document ID and version.

### Outcomes and statistics

The primary outcome was the proportion of held-out product-version records for which every applicable critical attribute was preserved from FHIR plus the companion record. Results describe this finite corpus at the retrieval date. As an exploratory measure, 95% intervals came from a cluster bootstrap over set IDs (2,000 replicates). Prespecified sensitivity analyses repeated the primary outcome on the full corpus and without repackaged products, evaluated package-level attributes (package NDC, containing product NDC, package form, quantity, and marketing status and start date) at package-version grain, and moved approach C's threshold 5 points down and up. Results are also reported for version, kit and combination subgroups.

### Verification

Software checks comprised {N['tests']} automated tests on constructed edge cases, {N['build_checks']} database reconciliation checks, JSON Schema validation of every companion record, the HL7 validator, and a repeat of every deterministic stage from the cached inputs, which reproduced {fmt(N['rerun_identical'])} of {fmt(N['rerun_total'])} output files exactly. I then checked the work by hand, separately from the software checks. For a stratified random sample of {N['sample_records']} held-out product records from {N['sample_labels']} labels (five per ingredient group, drawn by a salted hash), I compared the recorded product and package NDCs, active ingredients, strengths, stated basis of strength and dosage form with the corresponding DailyMed label pages, recomputed the primary outcome, the FHIR-core basis-of-strength misreads and the NDC padding changes from the supplementary tables, checked the figures quoted from the cited sources, and reviewed the figures, tables and text. No discrepancies were found. A separately written script downloaded the {N['sample_labels']} sampled labels again on {_long_date(N['recheck_date'])} and found none changed since retrieval."""

    rr = N['R']['roundtrip']
    T["results"] = f"""### Corpus

The {fmt(N['eligible'])} eligible labels held {fmt(N['prod_current'])} in-scope products in their current versions and {fmt(N['prod_preceding'])} in the {N['preceding_retrieved']} preceding versions (Table 1). Of the {fmt(N['prod_current'])} current products, {fmt(cat_anda)} were marketed under abbreviated new drug applications (ANDAs), {cat_nda} under new drug applications (NDAs), {cat_bla} under biologics license applications (BLAs) and {cat_ag} as NDA authorized generics; {cat_un} were marketed as unapproved drugs and {cat_exp} was listed as export only. Of {fmt(N['prod_records'])} product records, {fmt(N['repackaged'])} ({p(N['repackaged'], N['prod_records'])}) declared a source product, which marks repackaged or relabeled products, and {N['combos_current']} current products had two or more active ingredients. Of {fmt(N['active_records'])} active-ingredient records, {fmt(N['actim'])} ({p(N['actim'], N['active_records'])}) stated strength for the active moiety; none used a reference substance.

Insulin strengths stated in units of activity were coded in three different Unified Code for Units of Measure (UCUM) units across labels: {N['units_insulin'].get('[iU]', 0)} ingredient records used international units ([iU]), {N['units_insulin'].get('U', 0)} used U, which UCUM defines as the unit of catalytic activity (1 µmol/min) {c('ucum')}, and {N['units_insulin'].get("[arb'U]", 0)} used arbitrary units ([arb'U]).

### Validation

The HL7 validator reported no errors in any of the {fmt(N['val_files'])} Bundles with terminology checks off. Its warnings concerned code systems it could not check offline and missing narrative text. Against the public terminology server, the 60 sampled Bundles produced {N['tx_errors']} errors, all for NDCs absent from the server's NDC content, which is dated November 1, 2021, and {N['tx_inactive_warn']} warnings for NDCs it lists as inactive; none of the {fmt(N['tx_codings'].get('http://www.nlm.nih.gov/research/umls/rxnorm', 0))} RxNorm, {fmt(N['tx_codings'].get('http://fdasis.nlm.nih.gov', 0))} UNII, {fmt(N['tx_codings'].get('http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl', 0))} NCI Thesaurus or {fmt(N['tx_codings'].get('http://unitsofmeasure.org', 0))} UCUM codings was rejected. The sampled UCUM codings included [iU] and U but no [arb'U]. Passing validation shows structural conformance. It does not show that a code means what the label means.

### Round trip

FHIR plus the companion record reconstructed every applicable critical attribute for {fmt(N['h_r1_ok'])} of {fmt(N['h_r1_n'])} held-out product-version records from {fmt(N['h_r1_sets'])} labels (100%; bootstrap interval degenerate at 100%), and for {fmt(N['all_r1_ok'])} of {fmt(N['all_r1_n'])} across the whole corpus. One strength value needed the documented normalization because the label's XML attribute contained stray whitespace. The held-out result was the same for current and preceding versions, {N['h_kits_n']} kit records, {N['h_combo_n']} combination-product records and the {fmt(N['sa2_n'])} records that were not repackaged. At package-version grain, FHIR plus the companion record preserved every applicable package attribute for {fmt(N['sa3_r1_ok'])} of {fmt(N['sa3_n'])} held-out package records. FHIR core kept the package and product NDCs but not the package form, quantity or marketing data. Development-split runs and a constructed test document found faults in the reverse transform and the comparison code, all fixed before the held-out run. Two faults found after it were corrected, and the affected stages rerun, before results were reported: the FHIR writer put label substance names in UNII display text (found by the terminology-enabled validator), and both readers left the basis-of-strength substance empty for {dup_all} atorvastatin ingredient records ({dup.get('held_out', 0)} held-out) whose labels list the same active moiety twice.

Without the companion record, FHIR core elements kept {p(core['preserved'], core['applicable'])} of applicable identity and strength fields (Figure 1, Table 2). NDCs, dosage form, UNIIs and exact strength text all survived, and the Provenance resource carried the SPL document ID for every record. Every loss counted in Figure 1 concerned basis of strength. R4 Medication has no element for the basis-of-strength code, and reading a strength as referring to the listed ingredient gave the wrong substance for {fmt(N['h_core_boss_disc'])} of {fmt(N['h_core_boss_n'])} held-out active ingredients ({p(N['h_core_boss_disc'], N['h_core_boss_n'])}), all of them moiety-basis strengths such as atorvastatin calcium tablets labeled by their atorvastatin content. The set ID and version number, which these shares exclude, were also absent from FHIR core.

An RxCUI-only record kept {p(rx['preserved'], rx['applicable'])} of fields exactly and {p(rx['preserved'] + rx['converted'], rx['applicable'])} after documented conversion. Of {fmt(N['h_rx_n'])} held-out current products, {fmt(N['h_rx_unres_products'])} had no unique RxCUI to start from. The record carried no package NDCs, dosage form codes or UNIIs, because a concept cannot say which of its NDCs belong to one label's product and UNIIs were not re-derived here. RxNorm named the same basis-of-strength substance as the label for {fmt(N['h_rx_boss_conv'])} active ingredients and a different one for {N['h_rx_boss_disc']}. An SPL class code derived from RxNorm's structure agreed with the label's for {fmt(N['h_rx_class_conv'])} and differed for {N['h_rx_class_disc']}, although the basis substance agreed in all {N['h_rx_class_disc']}. RxNorm and the label differ in whether the salt or the moiety is the active ingredient. Strength differed for {N['h_rx_num_disc']}: {N['h_rx_num_disc_insulin']} premixed insulins that labels describe as one ingredient at 100 units/mL and RxNorm as two (for example 70 and 30 units/mL), and a semaglutide pen whose 1.7 mg per 0.75 mL RxNorm states as 2.27 mg/mL, a rounded value from which the label's ratio cannot be recovered.

The flat export kept {p(flat['preserved'], flat['applicable'])} of fields exactly. Padding NDCs without their segment pattern changed {fmt(N['ndc_naive_wrong'])} of {fmt(N['ndc_distinct'])} distinct package NDCs in current labels of both splits ({p(N['ndc_naive_wrong'], N['ndc_distinct'])}), comprising every 5-3-2 and 5-4-1 code and no 4-4-2 code; none of the changed codes coincided with another NDC in the corpus. Keeping the first ingredient truncated {N['h_flat_count_disc']} combination-product records. Float parsing kept every value it carried but rewrote the text of {fmt(N['h_flat_num_text'])} of those {fmt(N['h_flat_num_carried'])} numerators ({p(N['h_flat_num_text'], N['h_flat_num_carried'])}; 500 became 500.0); only {N['trailing_zero_values']} strengths in the corpus stated precision with trailing zeros, so lost precision was rare here.

DailyMed's packaging service kept {p(api['preserved'], api['applicable'])} of fields. It attaches every strength in a label to every product of that label, so {fmt(N['h_api_count_disc'])} of {fmt(N['h_api_count_n'])} held-out products ({p(N['h_api_count_disc'], N['h_api_count_n'])}) had the wrong number of active ingredients and {fmt(N['h_api_num_disc'])} of {fmt(N['h_api_num_n'])} active ingredients ({p(N['h_api_num_disc'], N['h_api_num_n'])}) received another product's strength when read in the order given.

For preceding-version records, the latest version of the same label kept {p(latest['preserved'], latest['applicable'])} of identity and strength fields, and all of them for {N['h_latest_ok']} of {N['h_latest_n']} held-out records.

### Matching

Approach A found a unique RxCUI for {fmt(N['h_a_unique'])} of {fmt(N['h_products'])} held-out current products ({p(N['h_a_unique'], N['h_products'])}); for the other {N['h_a_notfound']}, RxNorm listed none of the product's package NDCs as active (Table 3). Repackaged products made up most of these misses: {N['h_rep_notfound']} of {fmt(N['h_rep_total'])} held-out repackaged products had no active NDC, against {N['h_nonrep_notfound']} of {N['h_nonrep_total']} other products. In all, {N['obsolete_but_active']} package NDCs that their current label marks as actively marketed were obsolete in RxNorm. DailyMed's set-level file listed approach A's RxCUI for {fmt(N['h_a2_agree'])} of {fmt(N['h_a2_agree'] + N['h_a2_disagree'])} checkable products and did not list the analyzed version of {N['h_a2_absent_sets']} held-out labels ({N['h_a2_absent']} products).

Among products with a unique approach-A RxCUI, approach B answered {fmt(N['h_b_answered'])} of {fmt(N['h_a_unique'])} ({p(N['h_b_answered'], N['h_a_unique'])}) and agreed for {fmt(N['h_b_agree'])} of its answers ({p(N['h_b_agree'], N['h_b_answered'])}); {N.get('h_b_ambiguous', 0)} were ambiguous and {N.get('h_b_none', 0)} had no match (Figure 2). Most ambiguity came from attributes that labels do not state in structured form: {N['h_b_amb_er_metformin']} of the {N.get('h_b_ambiguous', 0)} ambiguous products were extended-release metformin, whose RxNorm concepts differ only in release mechanism, and insulin pens differ in dose increment or sensor connectivity. Approach B's dose-form rules also admitted vial concepts for some pen packages. Of the {N.get('h_b_none', 0)} products without a candidate, {N['h_b_none_insulin']} were insulins and {N['h_b_none_kits']} were kits. Approach C answered {N['h_c_answered']} and disagreed with approach A for {N['h_c_wrong']} ({p(N['h_c_wrong'], N['h_c_answered'])}); taking its top candidate without abstention matched approach A for {N['h_c_top1']} of {fmt(N['h_a_unique'])} ({p(N['h_c_top1'], N['h_a_unique'])}). Moving approach C's threshold 5 points down ({sa4['tau_low']}) or up ({sa4['tau_high']}) gave {sa4['low']['answered']} answers with {sa4['low']['disagree']} disagreements ({p(sa4['low']['disagree'], sa4['low']['answered'])}) or {sa4['high']['answered']} answers with {sa4['high']['disagree']} ({p(sa4['high']['disagree'], sa4['high']['answered'])}).

### Label versions

Between the preceding and the latest version, {N['v_any']} of {N['v_pairs']} sampled label pairs ({p(N['v_any'], N['v_pairs'])}) changed at least one identity attribute (Table 4): {N['v_pkg_added']} added package NDCs, {N['v_pkg_removed']} removed package NDCs from retained products, {N['v_prod_added']} added and {N['v_prod_removed']} removed product NDCs, and {ver_change}. Weighted by each group's number of labels listing two or more versions, the share was {100 * N['v_weighted']:.1f}%. Labeler names changed in {N['v_labeler']} labels, {N['v_labeler_case']} of them only in letter case or punctuation. Of the {N['v_removed_ndcs']} package NDCs that disappeared from {N['v_removed_labels']} labels ({N['v_removed_within']} within retained products and the rest with removed products), RxNorm now lists {N['v_removed_status'].get('OBSOLETE', 0)} as obsolete, {N['v_removed_status'].get('ACTIVE', 0)} as active and {N['v_removed_status'].get('ALIEN', 0)} as alien (held only in a source vocabulary other than RxNorm)."""

    T["discussion"] = f"""### Principal findings

A FHIR R4 representation of drug labels was fully reversible for these attributes when a companion record held what R4 Medication cannot express. An extension-based design was not tested. The two attributes with the largest consequences are label provenance and basis of strength. R4 Medication has no element for the SPL set ID or version number. The Provenance resource carried the SPL document ID, which identifies one label version, but linking and ordering the versions of a label needs the set ID and version number, which only the companion record held. A dictionary that cannot say which label version it came from cannot be audited when labels change, and about one in {_NUM_WORD[one_in]} sampled labels changed product identity between consecutive versions. R4 Medication also has no element for basis of strength. More than a quarter of active ingredients in this corpus state strength for the active moiety, and a consumer reading the R4 resource as written would take the strength to refer to the salt. FHIR's regulated-product resources can state the basis: R4's MedicinalProductIngredient, at maturity level 0, has a strength expressed in terms of a reference substance {c('fhirmpi')}, and FHIR R5's Ingredient resource has a strength basis "based on the ingredient substance as stated or on the substance base (when the ingredient is a salt)" {c('fhirr5ing')}. The HL7 SPL mapping guide targets R5 {c('splfhir')}; US Core, the national US profile set, is built on R4 {c('uscore')}.

### Comparison with earlier work

The identifier crosswalk and DailyMed's own set-level mapping agreed almost completely where both applied ({fmt(N['h_a2_agree'])} of {fmt(N['h_a2_agree'] + N['h_a2_disagree'])}), consistent with high SPL-to-RxNorm linkage reported earlier {c('zhu2012', 'schadow2007')}. Coverage remained incomplete. About a fifth of current products, mostly repackaged ones, had no NDC that RxNorm considers active, although many of their labels mark the package as marketed. This mirrors Peters and Bodenreider's finding that current-only NDC lookups fail for a large share of codes {c('peters2015')}. Attribute matching that respects basis of strength agreed with the crosswalk for {p(N['h_b_agree'], N['h_b_answered'])} of its answers, against {p(N['h_c_agree'], N['h_c_answered'])} for approximate names. On a local medication terminology, RxNorm's approximate match reached a drug-name F1 score of 90% {c('davidson2020')}. Approach B's ambiguous answers mostly involve attributes that SPL product data does not carry in structured form, such as release mechanism and pen dose increment. Its unmatched products, mostly insulins, reflect its rules or how RxNorm models them. Lester and colleagues found strength and dose form disagreement between prescription text and RxNorm {c('lester2022')}; this study shows that some disagreement arises before any text is written, in how labels and RxNorm structure the same product (premixed insulins, rounded per-mL strengths, unit codes).

### Implications for dictionary maintainers

The nine-in-ten error rate from naive padding supports keeping NDCs hyphenated and deriving the 11-digit form from the segment pattern. Segment-aware handling will also be needed for FDA's move to a uniform 12-digit NDC from 2033 {c('fdandc')}. A product row needs its label set ID and version, and each strength needs its basis code and substance. For labels containing multiple products, DailyMed's packaging service does not provide reliable per-product strengths. Insulin unit codes also need semantic checks: a syntactically valid UCUM unit can carry the wrong meaning.

### Limitations

The corpus is a census of labels for selected ingredients in six cardiometabolic groups at one retrieval date, and its findings may not carry over to other classes, OTC labels or biologics outside insulin. Only the latest and one preceding version were compared, for {N['preceding_retrieved']} labels sampled with equal allocation across groups, so the version change share is not a corpus rate, and {N['v_single']} eligible labels list a single version. RxNorm was available only as its current release plus its dated NDC history. License-free monthly RxNorm archives would allow fuller historical checks. 

Approach A is a terminology reference with its own errors, and approaches B and C were tuned against it. I wrote both the second reader and the reverse transform. No external party has repeated this software cross-check, and a rule both readers share can hide an error, as the repeated moiety showed. The companion record was designed to hold the attributes the round trip measures, so its complete preservation is partly by construction. The informative results are the losses measured without it. 

The study treats the label's structured product data as the source of truth, while narrative and structured sections of a label can disagree, as in excipient inconsistencies reported for 39% of 100 audited formulations {c('kinsella2024')}. Nothing here bears on the clinical correctness of any label or mapping."""

    T["conclusion"] = """For these labels, FHIR R4 Medication resources kept NDCs, dosage forms, ingredients and exact strengths, and the Provenance resource kept the SPL document ID, but neither kept the set ID, version number or basis of strength. A small, schema-validated companion record closed these gaps in every held-out record. Padding NDCs without their segment pattern, keeping only the latest label version or the first ingredient, and taking strengths from DailyMed's packaging service each changed or dropped identity attributes. The accompanying pipeline, companion schema and medication dictionary record provenance and reasons for review."""

    nlm = ("This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes "
           "of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse "
           "or recommend this or any other product.")
    T["acknowledgements"] = f"{_private()['ai_statement']} {nlm}" if version == "journal" else nlm
    T["contributions"] = ("Animesh Bose (sole author): conceptualization, methodology, software, validation, formal analysis, "
                          "investigation, data curation, resources, visualization, project administration, writing (original draft), "
                          "and writing (review and editing).")
    T["funding"] = ("This research received no specific grant from any funding agency in the public, commercial, or not-for-profit "
                    "sectors. I used internal resources from Norlowe Research, which I own; these do not constitute "
                    "external funding.")
    T["coi"] = "I own Norlowe Research and have no other conflicts of interest to declare."
    T["data"] = ("The data underlying this article are publicly available from the US National Library of Medicine: DailyMed "
                 "Structured Product Labeling documents and the DailyMed SPL-to-RxNorm mapping file "
                 "(https://dailymed.nlm.nih.gov/dailymed/, retrieved October 7, 2026) and the RxNorm API "
                 f"(https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html, release of {_long_date(N['rxnorm_release'])}). The supplementary source "
                 "archive contains the code that retrieves and processes these data, a manifest of every retrieved file with its "
                 "URL, retrieval time and SHA-256 checksum, the derived analysis tables, the FHIR outputs, and the medication "
                 "dictionary export. Because DailyMed and RxNorm serve current content, rerunning the retrieval reproduces the "
                 "workflow on the content current at that time. The manifest identifies the exact files analyzed here.")
    sfx = (lambda k, f: f"{k}_{f}") if version == "journal" else (lambda k, f: f)
    T["software"] = ("The source code (Python 3.13 and PostgreSQL 17; MIT license), configuration, SQL, schemas, tests and an offline "
                     f"demonstration are provided as Supplementary Material S1 ({sfx('S1', 'medication-identity-source.zip')}).")
    T["supplementary"] = (f"Supplementary Material S1, source archive ({sfx('S1', 'medication-identity-source.zip')}); S2, results "
                          f"workbook with definitions ({sfx('S2', 'medication_identity_results.xlsx')}); S3, medication dictionary "
                          f"export ({sfx('S3', 'medication_dictionary.zip')}); S4, example FHIR Bundles and companion records "
                          f"({sfx('S4', 'fhir_examples.zip')}).")
    T["bio"] = ""
    return T


def tables_md(N: dict, fig: dict) -> dict:
    import pandas as pd
    T = {}
    g = N["groups"]
    t1 = ["| Primary ingredient group | Current labels | In-scope products (current) |", "|---|---:|---:|"]
    for r in g.itertuples():
        name = {"metformin": "Metformin", "atorvastatin": "Atorvastatin", "lisinopril": "Lisinopril",
                "insulin": "Insulins (seven seed insulins)", "sglt2": "SGLT2 inhibitors (empagliflozin, dapagliflozin)",
                "glp1": "GLP-1 receptor agonists (semaglutide, liraglutide)"}[r.primary_group]
        t1.append(f"| {name} | {int(r.labels):,} | {int(r.products):,} |")
    t1.append(f"| Total | {int(g.labels.sum()):,} | {int(g.products.sum()):,} |")
    T["t1"] = "\n".join(t1) + "\n\n*Abbreviations:* GLP-1, glucagon-like peptide-1; SGLT2, sodium-glucose cotransporter 2."
    fs = N["fs"]
    reps = ["R1_full", "R_core", "S_rx", "S_api", "S_flat"]
    head = "| Attribute | " + " | ".join({"R1_full": "FHIR + sidecar", "R_core": "FHIR core", "S_rx": "RxCUI only",
                                           "S_api": "DailyMed packaging service", "S_flat": "Flat export"}[r] for r in reps) + " |"
    t2 = [head, "|---|" + "---:|" * len(reps)]
    from .render import ATTR_LABEL
    for attr in ["K1_set_id", "K2_document_id", "K3_version", "K4_product_ndc", "K5_package_ndcs", "K6_form_code", "K7_active_count",
                 "K8_unii", "K9_class_code", "K10_boss_unii", "K11_num_value", "K12_den_value"]:
        cells = []
        for rep in reps:
            row = fs[(fs.representation == rep) & (fs.attribute == attr)]
            if row.empty or not int(row.iloc[0].applicable):
                cells.append("n/a")
                continue
            r = row.iloc[0]
            ok = int(r.preserved + r.preserved_normalized)
            conv = int(r.converted_equivalent)
            side = int(r.omitted_in_sidecar)
            s = f"{100 * ok / r.applicable:.1f}%"
            if conv:
                s += f" (+{100 * conv / r.applicable:.1f}% conv.)"
            if side:
                s += " (sidecar)" if ok == 0 else ""
            cells.append(s)
        t2.append(f"| {ATTR_LABEL[attr]} | " + " | ".join(cells) + " |")
    T["t2"] = "\n".join(t2) + ("\n\n*Abbreviations:* FHIR, Fast Healthcare Interoperability Resources; NDC, National Drug Code; "
                                "RxCUI, RxNorm concept unique identifier; SPL, Structured Product Labeling; UNII, Unique Ingredient "
                                "Identifier; n/a, not applicable.")
    t3 = ["| Measure | Development | Held-out |", "|---|---:|---:|",
          f"| Current-version products | {N['d_products']:,} | {N['h_products']:,} |",
          f"| A: unique RxCUI from package NDCs | {N['d_a_unique']:,} | {N['h_a_unique']:,} |",
          f"| A: no package NDC active in RxNorm | {N['d_a_notfound']:,} | {N['h_a_notfound']:,} |",
          f"| A2: DailyMed set-level file agrees with A | {N['d_a2_agree']:,} of {N['d_a2_agree'] + N['d_a2_disagree']:,} | {N['h_a2_agree']:,} of {N['h_a2_agree'] + N['h_a2_disagree']:,} |",
          f"| B: answered (of A unique) | {N['d_b_answered']:,} | {N['h_b_answered']:,} |",
          f"| B: same RxCUI as A | {N['d_b_agree']:,} | {N['h_b_agree']:,} |",
          f"| B: different RxCUI | {N['d_b_wrong']:,} | {N['h_b_wrong']:,} |",
          f"| B: several candidates / none | {N.get('d_b_ambiguous', 0):,} / {N.get('d_b_none', 0):,} | {N.get('h_b_ambiguous', 0):,} / {N.get('h_b_none', 0):,} |",
          f"| C: answered (score 74 or more) | {N['d_c_answered']:,} | {N['h_c_answered']:,} |",
          f"| C: same RxCUI as A | {N['d_c_agree']:,} | {N['h_c_agree']:,} |",
          f"| C: different RxCUI | {N['d_c_wrong']:,} | {N['h_c_wrong']:,} |",
          f"| C top candidate without abstention, same as A | {N['d_c_top1']:,} | {N['h_c_top1']:,} |"]
    T["t3"] = "\n".join(t3) + ("\n\n*Notes:* A, package-NDC crosswalk through RxNorm's NDC status service; A2, DailyMed's set-level "
                                "SPL-to-RxNorm mapping file; B, normalized basis-of-strength substance names with strength, dose form, fill "
                                "volume and brand; C, approximate name matching (token-sort ratio). *Abbreviations:* NDC, National Drug Code; "
                                "RxCUI, RxNorm concept unique identifier.")
    v = N
    t4 = ["| Change between preceding and latest version | Labels | Share |", "|---|---:|---:|"]
    for lab, k in [("Any product-identity change", "v_any"), ("Package NDCs added", "v_pkg_added"), ("Package NDCs removed", "v_pkg_removed"),
                   ("Product NDCs added", "v_prod_added"), ("Product NDCs removed", "v_prod_removed"),
                   ("Active ingredient or basis of strength changed", "v_ing"), ("Strength changed", "v_strength"),
                   ("Dosage form changed", "v_form"), ("Labeler name changed", "v_labeler")]:
        t4.append(f"| {lab} | {v[k]} | {pct(v[k], v['v_pairs'])} |")
    t4.append(f"| Label pairs compared | {v['v_pairs']} | |")
    T["t4"] = "\n".join(t4) + ("\n\n*Notes:* Package NDCs removed counts removals within products present in both versions. "
                                "*Abbreviation:* NDC, National Drug Code.")
    return T


def title_block(N: dict, version: str, wc: dict | None) -> str:
    c = (_private() or {}).get("corresponding", {})
    if version != "journal":
        return f"""# {TITLE}

{AUTHOR}

{AFFILIATION}
"""
    words = "" if wc is None else (f"Word counts: abstract {wc['abstract']}, lay summary {wc['lay_summary']}, "
                                   f"main text {wc['main_text']:,}. Tables: 4. Figures: 2. References: {len(REFERENCES)}.")
    return f"""# {TITLE}

**Article type:** Research and Applications

**Author:** Animesh Bose, BS

**Affiliation:** {AFFILIATION}

**Corresponding author:** {c['name']}, {c['address']}. Email: {c['email']}. Telephone: {c.get('phone', '')}

**Keywords:** {"; ".join(KEYWORDS)}

{words}
"""


TABLE_CAPTIONS = {
    1: "**Table 1.** Eligible labels and in-scope products in current versions, by primary ingredient group (a combination product is counted once, in the first of: insulin, GLP-1, SGLT2, atorvastatin, lisinopril, metformin).",
    2: "**Table 2.** Share of applicable fields preserved exactly (or after the documented normalization), held-out product-version records, by representation. \"conv.\" is the additional share equal only after a documented conversion; \"sidecar\" marks attributes that only the companion record holds. For the flat export, package NDCs are compared in 11-digit form.",
    3: "**Table 3.** Matching approaches on current-version products, by split.",
    4: "**Table 4.** Product-identity changes between the immediately preceding available version and the latest version, sampled labels.",
}
def fig_captions(N: dict) -> dict:
    cur, prec = N["h_rx_n"], N["h_latest_n"]
    return {
        1: (f"**Figure 1.** Share of applicable identity and strength fields (the critical attributes other than set ID, document ID "
            f"and version) preserved by each representation, held-out records: {fmt(N['h_r1_n'])} product-version records from "
            f"{fmt(N['h_r1_sets'])} labels for FHIR with the sidecar, FHIR core and the flat export, the {fmt(cur)} current-version "
            f"records for RxCUI only and the DailyMed packaging service, and the {prec} preceding-version records for the latest "
            "version. Filled dots, preserved exactly; rings, preserved exactly or after a documented conversion. Abbreviations: FHIR, "
            "Fast Healthcare Interoperability Resources; RxCUI, RxNorm concept unique identifier."),
        2: (f"**Figure 2.** Name-based matching against the package-NDC crosswalk, the {fmt(N['h_a_unique'])} held-out current "
            "products with a unique crosswalk RxCUI. Abbreviations: NDC, National Drug Code; RxCUI, RxNorm concept unique identifier."),
    }


def alt_texts(fig: dict) -> dict:
    a1 = "Dot chart of the share of applicable identity and strength fields preserved, by representation: " + "; ".join(
        f"{r['label']} {r['value']:.1f}%" + (f" exactly and {r['value2']:.1f}% after documented conversion" if r['value2'] > r['value'] + 0.05 else "")
        for r in fig["fig1"]) + "."
    a2 = "Horizontal stacked bars comparing name-based matching with the NDC crosswalk: " + "; ".join(
        f"{r['label']}, {r['agree']:,} same RxCUI, {r['wrong']:,} different, {r['ambiguous']:,} several candidates, {r['none']:,} no match or abstained"
        for r in fig["fig2"]) + "."
    return {1: a1, 2: a2}


def _insert_after_first_mention(text: str, marker: str, block: str) -> str:
    paras = text.split("\n\n")
    for i, para in enumerate(paras):
        if marker in para and not para.startswith("**Table") and not para.startswith("**Figure"):
            paras.insert(i + 1, block)
            return "\n\n".join(paras)
    raise SystemExit(f"{marker} is never cited in the text")


def assemble(N: dict, fig: dict, fig_prefix: str = "../outputs/figures/", version: str = "public",
             wc: dict | None = None) -> str:
    T = build_text(N, fig, version)
    TB = tables_md(N, fig)
    results = T["results"]
    for k in (1, 2, 3, 4):
        results = _insert_after_first_mention(results, f"Table {k}", f"{TABLE_CAPTIONS[k]}\n\n{TB[f't{k}']}")
    alts = alt_texts(fig)
    FIG_CAPTIONS = fig_captions(N)
    legends = ""
    if version == "journal":
        legends = "\n\n## Figure legends\n\n" + "\n\n".join(
            f"{FIG_CAPTIONS[k]}\n\nAlt text: {alts[k]}" for k in (1, 2))
    else:
        files = {1: "fig1_representations.svg", 2: "fig2_matching.svg"}
        for k in (1, 2):
            results = _insert_after_first_mention(results, f"Figure {k}", f"![Figure {k}]({fig_prefix}{files[k]})\n\n{FIG_CAPTIONS[k]}")
    bio = ""  # the public copy carries no author biography
    return f"""{title_block(N, version, wc)}
## Abstract

{T['abstract']}

## Lay summary

{T['lay']}

## Background and significance

{T['intro']}

## Objective

{T['objective']}

## Materials and methods

{T['methods']}

## Results

{results}

## Discussion

{T['discussion']}

## Conclusion

{T['conclusion']}

## Acknowledgments

{T['acknowledgements']}

## Conflicts of interest

{T['coi']}

## Funding

{T['funding']}

## Author contributions

{T['contributions']}

## Data availability

{T['data']}

## Software availability

{T['software']}

## Supplementary material

{T['supplementary']}
{bio}
## References

[[REFLIST]]
{legends}
"""


def render_md(N: dict, fig: dict, version: str, fig_prefix: str = "../outputs/figures/") -> tuple[str, dict]:
    """Two passes: the first to count words, the second to print them on the title page."""
    md, used = number_citations(assemble(N, fig, fig_prefix, version))
    wc = word_count(md)
    md, used = number_citations(assemble(N, fig, fig_prefix, version, wc))
    md = md.replace("[[REFLIST]]", "\n".join(f"{i + 1}. {r}" for i, (_, r) in enumerate(used)))
    unused = [k for k, _ in REFERENCES if k not in dict(used)]
    if unused:
        raise SystemExit(f"references never cited: {unused}")
    if version == "journal":  # JAMIA Open: bracketed numbers placed after punctuation
        md = re.sub(r" (\[\d+(?:,\d+)*\])([.,;:])", r"\2\1", md)
        md = re.sub(r"(?<=\w|\)) (\[\d+(?:,\d+)*\])(?=\s)", r"\1", md)
    return md, wc


def word_count(md: str) -> dict:
    def body(sec_from, sec_to):
        a = md.index(sec_from)
        b = md.index(sec_to)
        return md[a:b]
    main = body("## Background and significance", "## Acknowledgments")
    main = re.sub(r"^\*\*(Table|Figure) \d\.\*\*.*$", "", main, flags=re.M)
    main = re.sub(r"^\|.*$", "", main, flags=re.M)
    main = re.sub(r"^\*(Abbreviations?|Notes):\*.*$", "", main, flags=re.M)
    main = re.sub(r"^!\[.*$", "", main, flags=re.M)
    abstract = body("## Abstract", "## Lay summary")
    lay = body("## Lay summary", "## Background")
    wc = lambda t: len(re.findall(r"[A-Za-z0-9][A-Za-z0-9.,%/'-]*", re.sub(r"[#*`]", "", t)))  # noqa: E731
    return {"main_text": wc(main), "abstract": wc(abstract) - 1, "lay_summary": wc(lay) - 2}


def write_manuscript(N: dict, fig: dict) -> dict:
    """Public rendering (portfolio, source archive) and journal rendering (private submission package)."""
    from .paths import HANDOFF
    ensure(MS)
    md, wc = render_md(N, fig, "public")
    (MS / "manuscript.md").write_text(md)
    (MS / "manuscript.html").write_text(_html_page(TITLE, markdown.markdown(md, extensions=["tables"])))
    (MS / "word_count.json").write_text(__import__("json").dumps(wc, indent=1))
    priv = _private()
    if priv is None:
        return {"manuscript": str(MS / "manuscript.md"), "word_count": wc, "journal_word_count": None, "submission": None}
    sub = HANDOFF / "submission"
    ensure(sub)
    jmd, jwc = render_md(N, fig, "journal", fig_prefix="figures/")
    (sub / "manuscript_jamia_open.md").write_text(jmd)
    cover = f"""Dear Editors,

Please consider the enclosed manuscript, "{TITLE}," for publication as a Research and Applications article in JAMIA Open.

The study measures, field by field, which identity and strength attributes of {fmt(N['eligible'])} current US prescription drug labels survive a round trip through FHIR R4 Medication resources, and which details common shortcuts lose on the same records. Without a companion record, FHIR core elements gave the wrong basis-of-strength substance for {p(N['h_core_boss_disc'], N['h_core_boss_n'])} of active ingredients; with a schema-validated companion record, every critical attribute of {fmt(N['h_r1_n'])} held-out product-version records was recovered. The study uses only publicly available drug-labeling and terminology data; no human participants or patient data were involved. The code, the file manifest and the derived tables are provided as supplementary material.

{priv['ai_statement']}

Supplementary Material S1 is an approximately 12 MB reproducibility archive containing the source code, manifests and derived outputs. I request an exception to the recommended 2 MB supplementary-file size so these materials can remain together. If a repository deposit is preferred, I will arrange it in consultation with the editorial office.

The manuscript has not been published and is not under consideration elsewhere. I own Norlowe Research and have no other conflicts of interest to declare.

Sincerely,

Animesh Bose
Norlowe Research
{priv['corresponding']['email']}
"""
    (sub / "cover_letter.md").write_text(cover)
    bio = build_text(N, fig, "journal")["bio"]
    (sub / "author_biography.md").write_text(f"# Author biography\n\n{bio}\n")
    old_cover = MS / "cover_letter.md"
    if old_cover.exists():
        old_cover.unlink()
    return {"manuscript": str(MS / "manuscript.md"), "word_count": wc, "journal_word_count": jwc,
            "submission": str(sub)}


def _html_page(title: str, body: str) -> str:
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{title}</title><style>
body{{margin:0;background:#fbfaf7;color:#1d1d1b;font:17px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}}
main{{max-width:760px;margin:0 auto;padding:24px 16px 80px}}h1{{font-size:1.6rem;line-height:1.25}}h2{{margin-top:2em;font-size:1.25rem}}h3{{font-size:1.05rem}}
table{{border-collapse:collapse;font-size:.9rem;width:100%;display:block;overflow-x:auto}}th,td{{border-bottom:1px solid #d9d6cc;padding:6px 8px;text-align:left}}
td{{font-variant-numeric:tabular-nums}}img{{max-width:100%;height:auto}}a{{color:#1f5f8b}}
</style></head><body><main>{body}</main></body></html>"""
