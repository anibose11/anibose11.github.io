"""Scope discovery and freezing (run before the corpus is acquired).

For each seed ingredient: the UNIIs RxNorm lists for the ingredient (IN) and
its precise forms (PIN), then the DailyMed set IDs returned by the unii_code
filter (which matches active-moiety UNIIs) and by drug_name, both restricted
to HUMAN PRESCRIPTION DRUG LABEL (34391-3). The output records counts only;
labels are not parsed here.
"""
from __future__ import annotations

import csv
import json
import tomllib

from .dailymed import RX_DOC_TYPE, DailyMed
from .http import utc_now
from .paths import CONFIG, DOCS
from .rxnav import RxNav


def _codes(js: dict, name: str) -> list[str]:
    out = []
    for p in (js.get("propConceptGroup") or {}).get("propConcept") or []:
        if p.get("propName") == name and p.get("propValue"):
            out.append(p["propValue"])
    return sorted(set(out))


def _related(js: dict, tty: str) -> list[dict]:
    for g in (js.get("allRelatedGroup") or {}).get("conceptGroup") or []:
        if g.get("tty") == tty:
            return g.get("conceptProperties") or []
    return []


def discover() -> dict:
    cfg = tomllib.loads((CONFIG / "study.toml").read_text())
    rx, dm = RxNav(cfg["http"]["rxnav_rate_per_second"]), DailyMed(cfg["http"]["dailymed_rate_per_second"])
    version = rx.version().json()
    groups, rows = [], []
    try:
        for ing in cfg["ingredient"]:
            g = {"group": ing["group"], "ingredients": [], "candidate_setids": set()}
            for rxcui in ing["rxnorm_in"]:
                props = rx.get(f"rxcui/{rxcui}/allProperties.json?prop=codes+names").json()
                name = next(iter(_codes(props, "RxNorm Name")), None)
                uniis = _codes(props, "UNII_CODE")
                pins = []
                for p in _related(rx.allrelated(rxcui).json(), "PIN"):
                    pp = rx.get(f"rxcui/{p['rxcui']}/allProperties.json?prop=codes").json()
                    pins.append({"rxcui": p["rxcui"], "name": p["name"], "uniis": _codes(pp, "UNII_CODE")})
                g["ingredients"].append({"rxnorm_in": rxcui, "name": name, "uniis": uniis, "pins": pins})
                for u in uniis + [u for p in pins for u in p["uniis"]]:
                    hits = dm.spls(unii_code=u, doctype=RX_DOC_TYPE)
                    g["candidate_setids"].update(h["setid"] for h in hits)
                    rows.append({"group": ing["group"], "rxnorm_in": rxcui, "query": f"unii_code={u}", "hits": len(hits)})
            for nm in ing["dailymed_names"]:
                hits = dm.spls(drug_name=nm, doctype=RX_DOC_TYPE)
                g["candidate_setids"].update(h["setid"] for h in hits)
                rows.append({"group": ing["group"], "rxnorm_in": "", "query": f"drug_name={nm}", "hits": len(hits)})
            groups.append(g)
    finally:
        rx.close()
        dm.close()
    all_ids = set().union(*(g["candidate_setids"] for g in groups))
    frozen_uniis = sorted({u for g in groups for i in g["ingredients"] for u in i["uniis"] + [x for p in i["pins"] for x in p["uniis"]]})
    out = {
        "frozen_utc": utc_now(),
        "rxnorm_version": version,
        "doc_type": RX_DOC_TYPE,
        "eligibility_rule": ("current DailyMed label; XML document type 34391-3; at least one product or kit part "
                             "with an active ingredient (classCode ACTI*) whose substance UNII or active-moiety UNII "
                             "is in eligible_uniis"),
        "eligible_uniis": frozen_uniis,
        "groups": [{"group": g["group"], "ingredients": g["ingredients"],
                    "candidate_setid_count": len(g["candidate_setids"])} for g in groups],
        "candidate_setids": sorted(all_ids),
    }
    (CONFIG / "scope_frozen.json").write_text(json.dumps(out, indent=1))
    with open(DOCS / "scope_discovery.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["group", "rxnorm_in", "query", "hits"])
        w.writeheader()
        w.writerows(rows)
    return out
