"""Run matching approaches A, A2, B and C on current-version in-scope products.

Package grain: A (ndcstatus RxCUI) and B (attribute signature) are computed for
every package NDC; the product result is the single RxCUI shared by its
packages, as in the analysis plan. C works on the product name only.
"""
from __future__ import annotations

import json

from psycopg.types.json import Jsonb

from . import db
from . import ndc as ndc_mod
from .corpus import iter_documents
from .crosswalk import approach_a, dailymed_rxcuis_by_set
from .matching import ApproxMatcher, c_query, candidate_signature, match_b, rules, spl_signature
from .paths import INTERIM, OUTPUTS, ensure
from .rxnav import RxNav, history_status_record


def _chain(pkgs, pkg):
    by = {p.path: p for p in pkgs}
    parts = pkg.path.split(".")
    return [by[".".join(parts[:i])] for i in range(1, len(parts) + 1)]


def load_candidates(rx: RxNav) -> list[dict]:
    m = json.loads((INTERIM / "rxnorm_manifest.json").read_text())
    out = []
    for rxcui in m["approach_b_candidates"]:
        rec = history_status_record(rx.historystatus(rxcui).json())
        if rec["status"] != "Active" or not rec["strengths"]:
            continue
        rec["sig"] = candidate_signature(rec)
        out.append(rec)
    return out


def load_allconcepts(rx: RxNav) -> list[dict]:
    js = rx.allconcepts().json()
    return (js.get("minConceptGroup") or {}).get("minConcept") or []


def run_matching(tau: float | None = None, delta: float | None = None, log=print) -> dict:
    rx = RxNav()
    cands = load_candidates(rx)
    approx = ApproxMatcher(load_allconcepts(rx))
    tau = rules()["approx"]["tau"] if tau is None else tau
    delta = rules()["approx"]["delta"] if delta is None else delta
    device_forms = set(rules().get("quantity_factor", {}).get("device_dose_forms", []))
    dm_sets = dailymed_rxcuis_by_set()
    rows, pkg_rows = [], []
    for doc, meta in iter_documents(include_preceding=False):
        for p in doc.products:
            if p.index not in meta["products_in_scope"]:
                continue
            key = f"{doc.document_id}:{p.index}"
            a = approach_a(p, rx)
            rows.append((key, "A", a["outcome"], a["rxcui"], a["candidates"], None,
                         {"packages": [{k: v for k, v in x.items() if k != "history"} for x in a["packages"]]}))
            dm = dm_sets.get((doc.set_id, doc.version_number))
            if dm is None:
                a2 = ("not_in_mapping_file", None)
            elif a["rxcui"] is None:
                a2 = ("a_not_unique", None)
            else:
                a2 = ("agree" if a["rxcui"] in dm else "disagree", a["rxcui"])
            rows.append((key, "A2", a2[0], a2[1], sorted(dm or []), None, {"dailymed_rxcuis": sorted(dm or [])}))
            # B at package grain
            b_pkg = []
            for k in p.packages:
                if not k.ndc_original:
                    continue
                chain = _chain(p.packages, k)
                sig = spl_signature(p, k, chain)
                res = match_b(sig, cands, use_qf=True, device_forms=device_forms)
                a_pkg = next((x for x in a["packages"] if x["ndc"] == k.ndc_original), None)
                b_pkg.append({"ndc": k.ndc_original, **res,
                              "a_rxcui": a_pkg["rxcui"] if a_pkg and a_pkg["status"] == "ACTIVE" else None,
                              "signature": {"ingredients": sig["ingredients"], "dose_forms": sorted(sig["dose_forms"]),
                                            "quantity_factor": sig["quantity_factor"], "branded": sig["branded"],
                                            "brand_names": sorted(sig["brand_names"])}})
                pkg_rows.append({"product_key": key, "split": meta["split"], "ndc": k.ndc_original,
                                 "a_rxcui": b_pkg[-1]["a_rxcui"], "b_outcome": res["outcome"], "b_rxcui": res["rxcui"],
                                 "b_candidates": res["candidates"]})
            uniq = {x["rxcui"] for x in b_pkg if x["outcome"] == "unique"}
            any_amb = any(x["outcome"] == "ambiguous" for x in b_pkg)
            if not b_pkg:
                b = ("no_package_ndc", None)
            elif len(uniq) == 1 and not any_amb and all(x["outcome"] == "unique" for x in b_pkg):
                b = ("unique", next(iter(uniq)))
            elif uniq or any_amb:
                b = ("ambiguous", None)
            else:
                b = ("none", None)
            rows.append((key, "B", b[0], b[1], sorted(uniq), None, {"packages": b_pkg}))
            q = c_query(p)
            r1, s1, s2 = approx.top2(q)
            c = approx.decide(r1, s1, s2, tau, delta)
            rows.append((key, "C", c["outcome"], c["rxcui"], [r1] if r1 else [], s1,
                         {"query": q, "top_rxcui": r1, "s1": s1, "s2": s2, "tau": tau, "delta": delta}))
    rx.close()
    db.start()
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        conn.execute("delete from match_result")
        conn.cursor().executemany("insert into match_result values (%s,%s,%s,%s,%s,%s,%s)",
                                  [(r[0], r[1], r[2], r[3], r[4], r[5], Jsonb(r[6])) for r in rows])
        conn.commit()
    ensure(OUTPUTS / "matching")
    (OUTPUTS / "matching" / "package_level_ab.json").write_text(json.dumps(pkg_rows, indent=0))
    out = {"product_rows": len(rows) // 4, "package_rows": len(pkg_rows), "tau": tau, "delta": delta,
           "b_candidates": len(cands)}
    log(f"matching: {out}")
    return out
