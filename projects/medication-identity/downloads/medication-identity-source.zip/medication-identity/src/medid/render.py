"""Render stage: figures, workbook, Tableau extracts, viewer pages, manuscript,
report and the project page. All numbers come from medid.numbers."""
from __future__ import annotations

import csv
import json
import shutil

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

from . import db
from .charts import ACCENT, CONTRAST, dot_chart, stacked_bars
from .numbers import numbers, pct
from .paths import OUTPUTS, ROOT, ensure
from .roundtrip import CRITICAL

FIG = OUTPUTS / "figures"
REP_LABEL = {"R1_full": "FHIR R4 + sidecar", "R_core": "FHIR R4 core only", "S_rx": "RxCUI only (current RxNorm)",
             "S_flat": "Flat export shortcut", "S_api": "DailyMed packaging service", "S_latest": "Latest label version only"}
REP_ORDER = ["R1_full", "R_core", "S_rx", "S_api", "S_flat", "S_latest"]
REP_SHORT = {"R1_full": "FHIR + sidecar", "R_core": "FHIR core only", "S_rx": "RxCUI only", "S_flat": "Flat export",
             "S_api": "DailyMed service", "S_latest": "Latest version"}
IDENTITY_ATTRS = [a for a in CRITICAL if a not in ("K1_set_id", "K2_document_id", "K3_version")]
ATTR_LABEL = {
    "K1_set_id": "SPL set ID", "K2_document_id": "SPL document ID", "K3_version": "SPL version number",
    "K4_product_ndc": "Product NDC as written", "K5_package_ndcs": "Package NDCs as written", "K6_form_code": "Dosage form code",
    "K7_active_count": "Number of active ingredients", "K8_unii": "Ingredient UNII", "K9_class_code": "Basis-of-strength code",
    "K10_boss_unii": "Basis-of-strength substance", "K11_num_value": "Strength numerator value",
    "K11_num_unit": "Strength numerator unit", "K12_den_value": "Strength denominator value",
    "K12_den_unit": "Strength denominator unit", "K13_part_ndcs": "Kit part NDCs",
}


def identity_shares(fs: pd.DataFrame) -> list[dict]:
    rows = []
    for rep in REP_ORDER:
        sub = fs[(fs.representation == rep) & (fs.attribute.isin(IDENTITY_ATTRS))]
        app = int(sub.applicable.sum())
        ok = int(sub.preserved.sum() + sub.preserved_normalized.sum())
        conv = int(sub.converted_equivalent.sum())
        rows.append({"representation": rep, "label": REP_LABEL[rep], "applicable": app, "preserved": ok, "converted": conv,
                     "value": 100 * ok / app if app else 0, "value2": 100 * (ok + conv) / app if app else 0})
    return rows


def figures(N: dict) -> dict:
    ensure(FIG)
    rows = identity_shares(N["fs"])
    dots = [{"label": r["label"], "short": REP_SHORT[r["representation"]], "value": r["value"], "value2": r["value2"],
             "tip": f"{r['label']}: {r['preserved']:,} of {r['applicable']:,} applicable identity and strength fields preserved exactly ({r['value']:.1f}%)",
             "tip2": f"{r['label']}: {r['preserved'] + r['converted']:,} of {r['applicable']:,} including fields equal only after a documented conversion ({r['value2']:.1f}%)"}
            for r in rows]
    title = "Which representation keeps the label's identity and strength"
    sub = (f"Held-out records ({N['h_r1_n']:,} product-version records, {N['h_r1_sets']:,} labels). Fields: product and package "
           "NDCs, dosage form, ingredient count, UNII, basis of strength, strength numerator and denominator, kit parts.")
    (FIG / "fig1_representations.svg").write_text(dot_chart(dots, title, sub))
    (FIG / "fig1_representations-narrow.svg").write_text(dot_chart(dots, title, sub, narrow=True))
    (FIG / "fig1_representations-print.svg").write_text(dot_chart(dots, title, sub, note=None, show_heading=False))
    cats = [("agree", "Same RxCUI as identifier crosswalk", ACCENT), ("wrong", "Different RxCUI", CONTRAST),
            ("ambiguous", "Several candidates", "#9c9a93"), ("none", "No match or abstained", "#d6d4cd")]
    mrows = [
        {"label": "B: names + attributes", "short": "B: names", "agree": N["h_b_agree"], "wrong": N["h_b_wrong"],
         "ambiguous": N.get("h_b_ambiguous", 0), "none": N.get("h_b_none", 0)},
        {"label": "C: approximate names", "short": "C: approximate", "agree": N["h_c_agree"], "wrong": N["h_c_wrong"], "ambiguous": 0,
         "none": N.get("h_c_abstain", 0)},
    ]
    t2 = "How name-based matching compares with the NDC crosswalk"
    s2 = f"Held-out products with a unique RxCUI from package NDCs (n = {N['h_a_unique']:,})."
    (FIG / "fig2_matching.svg").write_text(stacked_bars(mrows, cats, t2, s2))
    (FIG / "fig2_matching-narrow.svg").write_text(stacked_bars(mrows, cats, t2, s2, narrow=True))
    (FIG / "fig2_matching-print.svg").write_text(stacked_bars(mrows, cats, t2, s2, note=None, show_heading=False))
    with open(FIG / "fig1_data.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["representation", "label", "applicable", "preserved", "converted", "value", "value2"])
        w.writeheader()
        w.writerows(rows)
    with open(FIG / "fig2_data.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["label", "agree", "wrong", "ambiguous", "none"], extrasaction="ignore")
        w.writeheader()
        w.writerows(mrows)
    return {"fig1": rows, "fig2": mrows}


DEFINITIONS = [
    ("Product-version record", "One in-scope manufactured product in one SPL document version. Unit of the primary outcome."),
    ("Package-version record", "One package NDC within a product-version record."),
    ("Held-out / development", "Assignment of SPL set IDs by SHA-256 of 'medid-split-v1:' + set ID (development when the first 8 hex digits / 2^32 < 0.30), fixed before any tuning."),
    ("Applicable field", "A critical attribute that the source label states for the record. Fields the source does not state are 'inapplicable' and excluded from denominators."),
    ("preserved", "Reconstructed text equals the source text exactly."),
    ("preserved_normalized", "Equal after the documented JSON decimal fix (leading '.', trailing '.', redundant leading zeros, stray whitespace) or the FHIR lowercase urn:uuid rule."),
    ("converted_equivalent", "Equal only after a documented conversion (for example a per-mL strength, RxNorm unit names, a dose-form text lookup); the source text itself is not recoverable."),
    ("omitted_in_sidecar", "Not carried by FHIR R4 core elements; available in the sidecar."),
    ("unresolved", "Cannot be reconstructed from the representation without inference."),
    ("discordant", "Reconstructed, but different from the source."),
    ("Approach A", "Package NDCs (11-digit by segment pattern) looked up with RxNorm ndcstatus; product RxCUI when all ACTIVE packages share one."),
    ("Approach A2", "DailyMed set-level SPL-to-RxNorm mapping file; agreement means it lists approach A's RxCUI."),
    ("Approach B", "Normalized exact basis-of-strength names plus matched strength, dose form, fill volume and brand (rules config/normalization.toml v2)."),
    ("Approach C", "rapidfuzz token_sort_ratio against all current SCD/SBD/GPCK/BPCK names; answer when score >= 74 (development-tuned)."),
    ("Units", "Strength values are as labeled (UCUM units as written). Proportions are shares of the stated denominators, not percentages of all medicines."),
    ("Intervals", "Exploratory 95% percentile intervals from a cluster bootstrap over SPL set IDs (2,000 replicates, seed 20261007); this is a census of a defined corpus, not a random sample."),
    ("Sources", "DailyMed SPL (NLM) retrieved 2026-10-07; RxNorm API release 05-Oct-2026. This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or recommend this or any other product."),
]


def _sheet(wb, name, df: pd.DataFrame, note: str):
    ws = wb.create_sheet(name[:31])
    ws.append([note])
    ws["A1"].font = Font(italic=True)
    ws.append(list(df.columns))
    for c in ws[2]:
        c.font = Font(bold=True)
    for row in df.itertuples(index=False):
        ws.append([None if (isinstance(v, float) and pd.isna(v)) else v for v in row])
    for i, col in enumerate(df.columns, 1):
        width = max([len(str(col))] + [len(str(v)) for v in df[col].head(200)]) + 2
        ws.column_dimensions[get_column_letter(i)].width = min(60, width)
    ws.freeze_panes = "A3"


def workbook(N: dict, fig: dict) -> str:
    ensure(OUTPUTS / "workbook")
    wb = Workbook()
    ws = wb.active
    ws.title = "Definitions"
    ws.append(["Term", "Definition"])
    for c in ws[1]:
        c.font = Font(bold=True)
    for t, d in DEFINITIONS:
        ws.append([t, d])
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 120
    for r in ws.iter_rows(min_row=2):
        r[1].alignment = Alignment(wrap_text=True, vertical="top")
    T = OUTPUTS / "tables"
    _sheet(wb, "Corpus_eligibility", pd.read_csv(T / "corpus_label_eligibility.csv"), "Grain: label eligibility status; unit: SPL set IDs.")
    _sheet(wb, "Corpus_products", pd.read_csv(T / "corpus_products_by_group.csv"), "Grain: version kind x split x primary group; unit: product-version records.")
    _sheet(wb, "Corpus_NDC_patterns", pd.read_csv(T / "corpus_package_ndc_patterns.csv"), "Grain: NDC segment pattern x version kind; unit: package records.")
    _sheet(wb, "Matching_outcomes", pd.read_csv(T / "matching_outcomes.csv"), "Grain: split x approach x outcome; unit: current-version products.")
    _sheet(wb, "Matching_vs_A", pd.read_csv(T / "matching_agreement_with_A.csv"), "Denominator: products with a unique approach-A RxCUI.")
    _sheet(wb, "Roundtrip_records", pd.read_csv(T / "roundtrip_record_outcomes.csv"), "Grain: representation x split; unit: product-version records; intervals exploratory (cluster bootstrap by set ID).")
    _sheet(wb, "Roundtrip_fields", pd.read_csv(T / "roundtrip_field_status.csv"), "Grain: representation x attribute x split; unit: fields (record or ingredient level); 'applicable' excludes inapplicable and not-evaluated.")
    _sheet(wb, "Figure1_data", pd.DataFrame(fig["fig1"]), "Held-out identity and strength fields (K4 to K13) by representation; value columns are percentages.")
    _sheet(wb, "NDC_padding", pd.read_csv(T / "shortcut_ndc_padding.csv"), "Distinct package NDCs in current labels; naive = hyphens removed and left-padded to 11 digits.")
    _sheet(wb, "Version_changes", pd.read_csv(T / "version_changes_by_set.csv"), "Grain: SPL set ID with a retrieved preceding version; counts of changed products or packages.")
    _sheet(wb, "Removed_package_NDCs", pd.read_csv(T / "version_removed_package_ndcs_rxnorm.csv"), "Package NDCs present in the preceding version and absent from the latest, with current RxNorm status and dated history.")
    path = OUTPUTS / "workbook" / "medication_identity_results.xlsx"
    wb.save(path)
    return str(path)


def tableau_extracts() -> list[str]:
    """Flat extracts with explicit grain and denominators (see docs/tableau_spec.md)."""
    ensure(OUTPUTS / "tableau")
    T = OUTPUTS / "tables"
    out = []
    fs = pd.read_csv(T / "roundtrip_field_status.csv")
    long = fs.melt(id_vars=["representation", "attribute", "split", "applicable"], var_name="status", value_name="fields")
    long = long[long.status != "applicable"]
    long["share_of_applicable"] = long.apply(lambda r: (r.fields / r.applicable) if r.applicable and r.status not in ("inapplicable", "not_evaluated") else None, axis=1)
    long["suppressed"] = False
    long.to_csv(OUTPUTS / "tableau" / "roundtrip_fields_long.csv", index=False)
    out.append("roundtrip_fields_long.csv")
    shutil.copy2(T / "matching_outcomes.csv", OUTPUTS / "tableau" / "matching_outcomes.csv")
    shutil.copy2(T / "roundtrip_record_outcomes.csv", OUTPUTS / "tableau" / "roundtrip_record_outcomes.csv")
    shutil.copy2(T / "version_changes_by_set.csv", OUTPUTS / "tableau" / "version_changes_by_set.csv")
    out += ["matching_outcomes.csv", "roundtrip_record_outcomes.csv", "version_changes_by_set.csv"]
    return out


VIEWER_CASES = {
    "viewer-ambiguous.html": ("965b6bd6-37d4-451e-8c41-4df16df442d1:4",
                              "RxNorm maps this pen's package NDC to one concept ('Sensor' pen). Approach B "
                              "finds four candidates: three Lyumjev pens that differ only in dose increment and sensor connectivity, which "
                              "the label's structured product data does not state (the name suffix 'Tempo Pen' is the only hint), and the "
                              "vial concept, which its dose-form rule also admits. Approach C picks the plain pen."),
    "viewer-preserved.html": ("61bde692-38c6-42dc-aaac-503cc7e1d8f8:0",
                              "A two-ingredient tablet whose sitagliptin strength is stated for "
                              "the active moiety, sold in nested packages. FHIR plus the sidecar keeps every critical attribute; FHIR core "
                              "alone reads the sitagliptin strength as if it were the phosphate salt, the flat export keeps one "
                              "ingredient, and the DailyMed packaging response lists both strengths in the label for this product."),
}


def viewers() -> list[str]:
    from .viewer import write_view
    ensure(OUTPUTS / "viewer")
    out = []
    for name, (key, note) in VIEWER_CASES.items():
        out.append(str(write_view(key, str(OUTPUTS / "viewer" / name), title_note=note)))
    return out


def render_all() -> dict:
    N = numbers()
    fig = figures(N)
    wbp = workbook(N, fig)
    tab = tableau_extracts()
    vw = viewers()
    from .manuscript import write_manuscript
    from .site import write_site
    ms = write_manuscript(N, fig)
    site = write_site(N, fig)
    return {"figures": sorted(p.name for p in FIG.glob("*")), "workbook": wbp, "tableau": tab, "viewer": vw,
            "manuscript": ms, "site": site}
