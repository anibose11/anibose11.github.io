"""medid: version-aware medication identity reconciliation from DailyMed SPL and
RxNorm to FHIR R4 Medication resources, with round-trip fidelity checks."""

__version__ = "1.0.0"
