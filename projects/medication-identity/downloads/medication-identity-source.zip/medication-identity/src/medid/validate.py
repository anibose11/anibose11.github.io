"""Validation stage with the official HL7 FHIR validator (validator_cli 7.0.0).

Run 1 (all Bundles): -version 4.0.1 -tx n/a -no-http-access. Structure,
cardinality, invariants and the codes the loaded HL7 packages define; no
external terminology (RxNorm, NDC, UNII, NCIt are not checked).
Run 2 (deterministic sample): the default public terminology server
(tx.fhir.org) with a project-local terminology cache, so RxNorm, UNII, NCIt
and UCUM codes are checked against the versions that server holds. Its NDC
content was dated 2021-11-01 when checked, so NDC results there are reported
but not used as evidence of current NDC validity.
The package cache is kept inside the project with -Duser.home.
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
from collections import Counter
from pathlib import Path

from .paths import LOCAL, OUTPUTS, TOOLS, ensure

JAR = TOOLS / "validator-7.0.0" / "validator_cli.jar"
JAR_SHA256 = "0ec7285b0f23999c25979533c6e9105f5f01087889fcc113ac1dfc65560bcc69"
VHOME = LOCAL / "validator-home"
OUT = OUTPUTS / "validation"


def _java() -> str:
    j = shutil.which("java")
    if not j:
        raise SystemExit("java not found: validation stage blocked (install a Java 17+ runtime)")
    return j


def _run(src_dir: Path, out_json: Path, tx: str | None, log_path: Path) -> int:
    cmd = [_java(), f"-Duser.home={VHOME}", "-jar", str(JAR), str(src_dir), "-version", "4.0.1",
           "-output", str(out_json), "-output-style", "json"]
    if tx is None:
        cmd += ["-tx", "n/a", "-no-http-access"]
    else:
        cmd += ["-txCache", str(LOCAL / "validator-txcache")]
    with open(log_path, "w") as lf:
        rc = subprocess.run(cmd, stdout=lf, stderr=subprocess.STDOUT).returncode
    return rc


def summarize(out_json: Path) -> dict:
    b = json.loads(out_json.read_text())
    sev = Counter()
    kinds = Counter()
    files_with_errors = set()
    per_file = 0
    entries = b.get("entry", []) if b.get("resourceType") == "Bundle" else [{"resource": b}]
    for e in entries:
        oo = e["resource"]
        per_file += 1
        fname = next((x.get("valueString") for x in oo.get("extension", []) if "file" in x.get("url", "")), "?")
        for i in oo.get("issue", []):
            text = i.get("details", {}).get("text", "")
            # informational "all OK" messages carry no location
            sev[i["severity"]] += 1
            kinds[(i["severity"], re.sub(r"'[^']*'", "'…'", text)[:200])] += 1
            if i["severity"] in ("error", "fatal"):
                files_with_errors.add(fname)
    return {"files": per_file, "issues_by_severity": dict(sev),
            "files_with_errors": len(files_with_errors),
            "issue_types": [{"severity": s, "message": m, "count": n} for (s, m), n in kinds.most_common()]}


def run_validation(skip_tx: bool = False, sample_size: int = 60, log=print) -> dict:
    ensure(OUT)
    if not JAR.exists():
        raise SystemExit(f"validator jar missing at {JAR}; see README 'Validator' to download and verify it")
    digest = hashlib.sha256(JAR.read_bytes()).hexdigest()
    if digest != JAR_SHA256:
        raise SystemExit(f"validator jar SHA-256 mismatch: {digest}")
    bundles = OUTPUTS / "fhir" / "bundles"
    result = {"validator": "validator_cli.jar 7.0.0", "validator_sha256": digest,
              "java": subprocess.run([_java(), "-version"], capture_output=True, text=True).stderr.splitlines()[0]}
    rc = _run(bundles, OUT / "offline_all.json", None, OUT / "offline_all.log")
    result["offline_all"] = {"exit_code": rc, **summarize(OUT / "offline_all.json")}
    log(f"offline validation exit {rc}: {result['offline_all']['issues_by_severity']}")
    if not skip_tx:
        files = sorted(bundles.glob("*.json"), key=lambda p: hashlib.sha256(("medid-split-v1:tx:" + p.stem).encode()).hexdigest())
        sample = files[:sample_size]
        sdir = OUT / "tx_sample_input"
        if sdir.exists():
            shutil.rmtree(sdir)
        sdir.mkdir()
        for p in sample:
            shutil.copy2(p, sdir / p.name)
        rc2 = _run(sdir, OUT / "tx_sample.json", "default", OUT / "tx_sample.log")
        result["tx_sample"] = {"exit_code": rc2, "sample_files": [p.name for p in sample],
                               "terminology_server": "https://tx.fhir.org (validator default)",
                               **summarize(OUT / "tx_sample.json")}
        log_text = (OUT / "tx_sample.log").read_text()
        lines = set(re.findall(r"(?:tx\.fhir\.org[^\s]*|Terminology server[^\n]*)", log_text))
        result["tx_sample"]["server_versions_in_log"] = sorted({re.sub(r"\s*\(\d\d:\d\d\.\d+\)", "", x) for x in lines})[:10]
        shutil.rmtree(sdir)
    (OUT / "summary.json").write_text(json.dumps(result, indent=1))
    return result
