"""Command-line interface: medid <stage>.

Stages, in order (each is resumable; network responses are cached):
  scope      discover ingredient UNIIs and candidate labels, freeze the scope
  acquire    labels, history, preceding versions, packaging, RxNorm lookups
  build      canonical source layer in PostgreSQL with checks
  match      approaches A, A2, B, C
  fhir       FHIR R4 Bundles and sidecars
  validate   HL7 validator runs (offline, and terminology sample)
  roundtrip  reversible and core-only round trips plus shortcut baselines
  analyze    outcome tables, version analysis, bootstrap
  render     figures, report, manuscript, workbook, viewer, site pages
  package    source archive, handoff, outer bundle
  pipeline   build -> package from cached inputs
  demo       fast offline run on the bundled fixture labels
  view       write a source-versus-FHIR comparison page for one product
  db         start | stop | status of the project-local PostgreSQL cluster
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone

from .paths import LOCAL, OUTPUTS, ROOT, ensure


def code_fingerprint() -> str:
    h = hashlib.sha256()
    for p in sorted((ROOT / "src" / "medid").glob("*.py")) + sorted((ROOT / "config").glob("*.toml")) + \
             sorted((ROOT / "sql").glob("*.sql")) + sorted((ROOT / "schemas").glob("*.json")):
        h.update(p.name.encode())
        h.update(p.read_bytes())
    return h.hexdigest()[:12]


def _log_stage(stage: str, started: float, detail: dict) -> None:
    ensure(OUTPUTS / "runs")
    rec = {"stage": stage, "code_fingerprint": code_fingerprint(),
           "started_utc": datetime.fromtimestamp(started, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "seconds": round(time.time() - started, 1), "detail": detail}
    line = json.dumps(rec, default=str).replace(str(ROOT) + "/", "").replace(str(ROOT), ".")
    with open(OUTPUTS / "runs" / "stage_log.jsonl", "a") as f:
        f.write(line + "\n")
    ck = LOCAL / "CHECKPOINT.md"
    if ck.exists():
        with open(ck, "a") as f:
            f.write(f"- {rec['started_utc']}  medid {stage} ({rec['seconds']} s, code {rec['code_fingerprint']})\n")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="medid", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="stage", required=True)
    for name in ("scope", "acquire", "build", "match", "fhir", "roundtrip", "analyze", "render", "package",
                 "pipeline", "demo"):
        sub.add_parser(name)
    v = sub.add_parser("validate")
    v.add_argument("--skip-tx", action="store_true", help="only the offline (-tx n/a) run")
    vw = sub.add_parser("view")
    vw.add_argument("product_key", help="document_id:product_index")
    vw.add_argument("--out", default=None)
    d = sub.add_parser("db")
    d.add_argument("action", choices=["start", "stop", "status"])
    args = ap.parse_args(argv)
    started = time.time()

    if args.stage == "db":
        from . import db
        {"start": db.start, "stop": db.stop}.get(args.action, lambda: None)()
        print("running" if db.is_running() else "stopped")
        return 0
    if args.stage == "scope":
        from .scope import discover
        out = discover()
        detail = {"candidate_setids": len(out["candidate_setids"]), "eligible_uniis": len(out["eligible_uniis"])}
    elif args.stage == "acquire":
        from .acquire import acquire_labels, acquire_rxnorm
        m = acquire_labels()
        r = acquire_rxnorm()
        detail = {"eligible": sum(1 for e in m["labels"] if e["status"] == "eligible"),
                  "ndcstatus": r["ndcstatus_count"], "historystatus": r["historystatus_count"]}
    elif args.stage == "build":
        from .build import build
        from .rxload import load_rxnorm
        detail = build()["table_rows"]
        detail.update(load_rxnorm())
    elif args.stage == "match":
        from .match_run import run_matching
        detail = run_matching()
    elif args.stage == "fhir":
        from .fhir_export import export
        detail = export()
    elif args.stage == "validate":
        from .validate import run_validation
        detail = run_validation(skip_tx=args.skip_tx)
    elif args.stage == "roundtrip":
        from .roundtrip_run import run_roundtrip
        detail = run_roundtrip()
    elif args.stage == "analyze":
        from .analyze import analyze
        from .dictionary import export_dictionary
        detail = analyze()
        detail["dictionary"] = export_dictionary()["rows"]
    elif args.stage == "render":
        from .render import render_all
        detail = render_all()
    elif args.stage == "package":
        from .evidence import write_evidence
        from .package import package_all
        detail = {"evidence": write_evidence(), **package_all()}
    elif args.stage == "pipeline":
        for st in ("build", "match", "fhir", "validate", "roundtrip", "analyze", "render", "package"):
            rc = main([st])
            if rc:
                return rc
        return 0
    elif args.stage == "demo":
        from .demo import run_demo
        detail = run_demo()
    elif args.stage == "view":
        from .viewer import write_view
        detail = {"written": str(write_view(args.product_key, args.out))}
    else:  # pragma: no cover
        ap.error("unknown stage")
        return 2
    _log_stage(args.stage, started, detail)
    print(json.dumps(detail, indent=1, default=str))
    return 0


if __name__ == "__main__":
    sys.exit(main())
