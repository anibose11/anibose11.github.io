"""Approach A (source identifiers) and A2 (DailyMed set-level crosswalk).

A: each package NDC of a product, converted to 11 digits with its own segment
pattern, is looked up with RxNorm ndcstatus. The product's RxCUI is the single
RxCUI shared by its package NDCs that RxNorm reports as ACTIVE.

A2: the RxCUIs DailyMed's rxnorm_mappings file lists for the set ID and
version (product term types only). It has no product or NDC column, so it can
confirm agreement with A but cannot assign an RxCUI to a product on its own.
"""
from __future__ import annotations

import csv
import io
import json
import zipfile
from functools import lru_cache

from . import ndc as ndc_mod
from .paths import INTERIM, ROOT
from .rxnav import PRODUCT_TTYS, RxNav, ndc_status_record


@lru_cache(maxsize=1)
def load_dailymed_mapping() -> list[dict]:
    m = json.loads((INTERIM / "label_manifest.json").read_text())
    path = ROOT / m["rxnorm_mapping_file"]["path"]
    with zipfile.ZipFile(path) as zf:
        name = next(n for n in zf.namelist() if n.lower().endswith(".txt"))
        text = zf.read(name).decode("utf-8")
    rows = []
    reader = csv.DictReader(io.StringIO(text), delimiter="|")
    for r in reader:
        rows.append({"setid": r["SETID"], "spl_version": r["SPL_VERSION"], "rxcui": r["RXCUI"],
                     "rxstring": r["RXSTRING"], "tty": r["RXTTY"]})
    return rows


@lru_cache(maxsize=1)
def dailymed_rxcuis_by_set() -> dict[tuple[str, str], set[str]]:
    out: dict[tuple[str, str], set[str]] = {}
    for r in load_dailymed_mapping():
        if r["tty"] in PRODUCT_TTYS:
            out.setdefault((r["setid"], r["spl_version"]), set()).add(r["rxcui"])
    return out


def product_package_ndcs(product) -> list[str]:
    codes = [k.ndc_original for k in product.packages if k.ndc_original]
    for part in product.parts:
        codes += [k.ndc_original for k in part.packages if k.ndc_original]
    return codes


def approach_a(product, rx: RxNav) -> dict:
    """RxCUI for one product from its package NDCs (cached RxNav responses)."""
    per_pkg = []
    for code in product_package_ndcs(product):
        p = ndc_mod.parse(code)
        if p.kind != "package":
            per_pkg.append({"ndc": code, "ndc11": None, "status": "UNRECOGNIZED_PATTERN", "rxcui": None})
            continue
        rec = ndc_status_record(rx.ndcstatus(p.to_11()).json())
        per_pkg.append({"ndc": code, "ndc11": p.to_11(), "status": rec["status"], "rxcui": rec["rxcui"],
                        "concept_status": rec["concept_status"], "history": rec["history"]})
    active = {r["rxcui"] for r in per_pkg if r["status"] == "ACTIVE" and r["rxcui"]}
    if not per_pkg:
        outcome = "no_package_ndc"
    elif len(active) == 1:
        outcome = "unique"
    elif len(active) > 1:
        outcome = "ambiguous"
    else:
        outcome = "not_found"
    return {"outcome": outcome, "rxcui": next(iter(active)) if len(active) == 1 else None,
            "candidates": sorted(active), "packages": per_pkg}
