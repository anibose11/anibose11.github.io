"""FHIR export stage: one Bundle and one sidecar per analyzed SPL version.

RxNorm codings come from approach A only (package NDC -> ndcstatus, product
RxCUI when unique). Sidecars are validated against the local JSON Schema.
"""
from __future__ import annotations

import json

import jsonschema

from . import db
from .corpus import iter_documents
from .exact_json import dumps
from .fhir_build import build_bundle
from .paths import OUTPUTS, SCHEMAS, ensure

FHIR_DIR = OUTPUTS / "fhir"


def bundle_paths(document_id: str):
    return FHIR_DIR / "bundles" / f"{document_id}.json", FHIR_DIR / "sidecars" / f"{document_id}.sidecar.json"


def export(log=print) -> dict:
    ensure(FHIR_DIR / "bundles", FHIR_DIR / "sidecars")
    schema = json.loads((SCHEMAS / "medication_sidecar.schema.json").read_text())
    validator = jsonschema.Draft202012Validator(schema)
    db.start()
    n_bundles = n_meds = n_bad_side = 0
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        conn.execute("delete from fhir_medication")
        a_prod = {r[0]: (r[1], r[2]) for r in conn.execute(
            """select m.product_key, m.rxcui, c.name from match_result m left join rx_concept c using (rxcui)
               where m.approach='A' and m.outcome='unique'""")}
        a_pkg = {r[0]: (r[1], r[2]) for r in conn.execute(
            """select k.ndc_original, s.rxcui, c.name from spl_package k join rx_ndc_status s on s.ndc11 = k.ndc11
               left join rx_concept c on c.rxcui = s.rxcui where s.status = 'ACTIVE' and s.rxcui is not null""")}
        rows = []
        for doc, meta in iter_documents():
            prod_rx = {}
            for p in doc.products:
                key = f"{doc.document_id}:{p.index}"
                if key in a_prod:
                    prod_rx[p.index] = a_prod[key]
            pkg_rx = {}
            for p in doc.products:
                for k in p.packages:
                    if k.ndc_original in a_pkg:
                        pkg_rx[k.ndc_original] = a_pkg[k.ndc_original]
            source = {"version_kind": meta["version_kind"], "source_url": meta["source_url"],
                      "source_path": meta["source_path"], "source_sha256": meta["source_sha256"],
                      "source_zip_sha256": meta.get("source_zip_sha256"), "retrieved_utc": meta["retrieved_utc"]}
            bundle, side = build_bundle(doc, source, prod_rx, pkg_rx, products=meta["products_in_scope"])
            for mid, s in side["medications"].items():
                if s["resource_level"] == "product":
                    s["mapping"].update(method="A: package NDC -> RxNorm ndcstatus", outcome="unique" if s["mapping"]["product_rxcui"] else "not_unique")
                else:
                    s["mapping"]["ndc_status"] = "ACTIVE" if s["mapping"]["package_rxcui"] else None
            errors = list(validator.iter_errors(side))
            if errors:
                n_bad_side += 1
                log(f"sidecar schema error {doc.document_id}: {errors[0].message[:200]}")
            bp, sp = bundle_paths(doc.document_id)
            bp.write_text(dumps(bundle))
            sp.write_text(dumps(side))
            n_bundles += 1
            for mid, s in side["medications"].items():
                if s["resource_level"] == "product":
                    pk = f"{doc.document_id}:{s['product']['index']}"
                    rows.append((mid, doc.document_id, pk, None, "product", str(bp.relative_to(OUTPUTS.parent))))
                else:
                    pid = s["product_medication_id"]
                    prod = side["medications"][pid]["product"]["index"]
                    pk = f"{doc.document_id}:{prod}"
                    rows.append((mid, doc.document_id, pk, f"{pk}:pkg:{s['package']['path']}", "package",
                                 str(bp.relative_to(OUTPUTS.parent))))
                n_meds += 1
        conn.cursor().executemany("insert into fhir_medication values (%s,%s,%s,%s,%s,%s)", rows)
        conn.commit()
    out = {"bundles": n_bundles, "medications": n_meds, "sidecar_schema_failures": n_bad_side}
    (OUTPUTS / "checks").mkdir(parents=True, exist_ok=True)
    (OUTPUTS / "checks" / "fhir_export.json").write_text(json.dumps(out, indent=1))
    log(f"fhir export: {out}")
    return out
