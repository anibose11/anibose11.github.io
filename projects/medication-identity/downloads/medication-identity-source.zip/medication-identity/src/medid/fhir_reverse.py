"""Reverse transform: FHIR Bundle (+ sidecar) read from disk -> critical attributes.

Two modes:
- "full": FHIR R4 elements plus the sidecar (the reversible representation);
- "core": FHIR R4 elements only. Basis of strength is read the default way, as
  the ingredient substance listed in Medication.ingredient.item, because R4 has
  no element that says otherwise. Label set ID and version are not available.
Nothing is inferred from names. Number tokens are read as their exact text.
"""
from __future__ import annotations

from pathlib import Path

from .exact_json import loads_exact
from .fhir_build import SYS_NCIT, SYS_NDC, SYS_UNII, SYS_URI


def _coding(cc: dict | None, system: str) -> str | None:
    for c in (cc or {}).get("coding") or []:
        if c.get("system") == system:
            return c.get("code")
    return None


def _ratio(r: dict | None):
    if not r:
        return None, None, None, None
    n, d = r.get("numerator") or {}, r.get("denominator") or {}
    return n.get("value"), n.get("code"), d.get("value"), d.get("code")


def _actives(med: dict, contained: dict, side_ings: list | None, side_parts: list | None):
    """Active ingredients in source order; kit parts first (as written by the builder)."""
    out = []
    part_ndcs = []
    part_seq = 0
    own_seq = 0
    for ing in med.get("ingredient") or []:
        if "itemReference" in ing:
            ref = ing["itemReference"]["reference"].lstrip("#")
            part = contained.get(ref) or {}
            part_ndcs.append(next((i.get("value") for i in part.get("identifier") or [] if i.get("system") == SYS_NDC), None))
            pside = (side_parts or [])[part_seq]["ingredients"] if side_parts and part_seq < len(side_parts) else None
            for k, pi in enumerate(part.get("ingredient") or []):
                if pi.get("isActive"):
                    out.append(_one(pi, pside[k] if pside and k < len(pside) else None))
            part_seq += 1
            continue
        s = side_ings[own_seq] if side_ings and own_seq < len(side_ings) else None
        own_seq += 1
        if ing.get("isActive"):
            out.append(_one(ing, s))
    return out, part_ndcs


def _one(ing: dict, side: dict | None) -> dict:
    nv, nu, dv, du = _ratio(ing.get("strength"))
    unii = _coding(ing.get("itemCodeableConcept"), SYS_UNII)
    row = {"unii": unii, "num_value": nv, "num_unit": nu, "den_value": dv, "den_unit": du}
    if side is None:  # core mode: default reading
        row.update(class_code=None, moiety_uniis=None, reference_unii=None, boss_unii=unii, boss_source="default_reading")
    else:
        row.update(class_code=side["class_code"], moiety_uniis=tuple(sorted(m for m in side["moiety_uniis"] if m)),
                   reference_unii=side.get("reference_unii"), boss_unii=side["strength_substance_unii"],
                   boss_source="sidecar")
    return row


def reconstruct(bundle_path: Path, sidecar_path: Path | None, mode: str) -> dict:
    bundle = loads_exact(bundle_path.read_text())
    side = loads_exact(sidecar_path.read_text()) if (mode == "full" and sidecar_path) else None
    meds = [e["resource"] for e in bundle.get("entry", []) if e["resource"]["resourceType"] == "Medication"]
    prov = next((e["resource"] for e in bundle.get("entry", []) if e["resource"]["resourceType"] == "Provenance"), None)
    doc_id = None
    if prov:
        for ent in prov.get("entity") or []:
            ident = (ent.get("what") or {}).get("identifier") or {}
            if ident.get("system") == SYS_URI and str(ident.get("value", "")).startswith("urn:uuid:"):
                doc_id = ident["value"][len("urn:uuid:"):]
    out = {"set_id": None, "document_id": doc_id, "version_number": None, "products": {}}
    if side:
        out["set_id"] = side["source"]["set_id"]
        out["version_number"] = side["source"]["version_number"]
        out["document_id_sidecar"] = side["source"]["document_id"]

    def is_package(m):
        if side:
            return side["medications"][m["id"]]["resource_level"] == "package"
        return _coding(m.get("code"), SYS_NDC) is not None

    products = [m for m in meds if not is_package(m)]
    packages = [m for m in meds if is_package(m)]
    for m in products:
        ndc = next((i.get("value") for i in m.get("identifier") or [] if i.get("system") == SYS_NDC), None)
        contained = {c["id"]: c for c in m.get("contained") or []}
        s = side["medications"][m["id"]] if side else None
        actives, part_ndcs = _actives(m, contained, s["ingredients"] if s else None, s["kit_parts"] if s else None)
        if s:
            key = ("index", int(s["product"]["index"]))
            mine = [p for p in packages if side["medications"][p["id"]]["product_medication_id"] == m["id"]]
            pkg_ndcs = [p["code"]["coding"][0]["code"] for p in mine]
            routes = s["product"]["route_codes"]
        else:
            key = ("ndc", ndc)
            mine = [p for p in packages if ndc and any(i.get("value") == ndc for i in p.get("identifier") or [])]
            pkg_ndcs = [_coding(p.get("code"), SYS_NDC) for p in mine]
            routes = None
        pkg_detail = []
        for p in mine:
            d = {"ndc": _coding(p.get("code"), SYS_NDC),
                 "product_ndc": next((i.get("value") for i in p.get("identifier") or [] if i.get("system") == SYS_NDC), None),
                 "form_code": None, "qty_value": None, "qty_unit": None, "marketing_status": None, "marketing_start": None}
            if side:
                ps = side["medications"][p["id"]]["package"]
                own = next((c for c in ps["hierarchy"] if c["path"] == ps["path"]), {})
                d.update(form_code=own.get("form_code"), qty_value=own.get("qty_num_value"),
                         qty_unit=own.get("qty_num_unit"), marketing_status=ps.get("marketing_status"),
                         marketing_start=ps.get("marketing_low"))
            pkg_detail.append(d)
        out["products"][key] = {
            "product_ndc": ndc,
            "form_code": _coding(m.get("form"), SYS_NCIT),
            "active": actives,
            "package_ndcs": pkg_ndcs,
            "packages": pkg_detail,
            "part_ndcs": part_ndcs,
            "route_codes": routes,
            "medication_id": m["id"],
        }
    return out
