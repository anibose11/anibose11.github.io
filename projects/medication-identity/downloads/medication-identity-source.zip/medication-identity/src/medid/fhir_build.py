"""Build FHIR R4 (4.0.1) Medication resources and a companion sidecar from
canonical SPL records.

Element choices (see docs/methods.md, "FHIR representation"):
- Product level: Medication.identifier carries the labeler-product NDC
  (system http://hl7.org/fhir/sid/ndc, as in the HL7 SPL mapping guide);
  Medication.code carries an RxNorm coding only when the identifier crosswalk
  gave exactly one RxCUI, plus the labeled name as text.
- Package level: one Medication per package NDC. Medication.code carries the
  10-digit hyphenated package NDC exactly as labeled; Medication.amount is the
  number of product units (or volume) in that package, computed exactly through
  the SPL package hierarchy.
- Ingredients: itemCodeableConcept with the UNII of the substance as listed in
  the SPL, isActive, and strength as the source ratio with exact decimal text.
  R4 has no element for the basis of strength, so the class code (ACTIB/ACTIM/
  ACTIR) and the basis-of-strength substance are kept in the sidecar.
- Kits: part products are contained Medications referenced from ingredient.
- Medication.manufacturer is not populated: the SPL labeler may be a
  distributor or repackager, which R4 says this element does not represent.
- Medication.status is not populated: SPL marketing status describes FDA
  listing, not whether a record is in use in a drug database.
- One Provenance per SPL version links the resources to the source document.
Everything the R4 elements cannot hold goes in the sidecar, keyed by
Medication.id and validated against schemas/medication_sidecar.schema.json.
"""
from __future__ import annotations

import uuid

from . import ndc as ndc_mod
from .exact_json import number
from .spl import Ingredient, Package, Product, SplDocument

SYS_NDC = "http://hl7.org/fhir/sid/ndc"
SYS_RXNORM = "http://www.nlm.nih.gov/research/umls/rxnorm"
SYS_UNII = "http://fdasis.nlm.nih.gov"
SYS_NCIT = "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl"
SYS_UCUM = "http://unitsofmeasure.org"
SYS_URI = "urn:ietf:rfc:3986"
OID_TO_URI = {
    "2.16.840.1.113883.6.69": SYS_NDC,
    "2.16.840.1.113883.4.9": SYS_UNII,
    "2.16.840.1.113883.3.26.1.1": SYS_NCIT,
    "2.16.840.1.113883.6.88": SYS_RXNORM,
}
ID_NAMESPACE = uuid.UUID("6f1c9a52-2d8e-4c38-9a4b-0a5f2b8e7c11")


def stable_id(*parts: str) -> str:
    return str(uuid.uuid5(ID_NAMESPACE, "|".join(parts)))


def system_for(oid: str | None) -> str | None:
    if not oid:
        return None
    return OID_TO_URI.get(oid, f"urn:oid:{oid}")


def _quantity(value: str | None, unit: str | None, display: str | None = None):
    if value is None:
        return None, False
    n = number(value)
    q = {"value": n}
    if unit:
        q["unit"] = display or unit
        q["system"] = SYS_UCUM
        q["code"] = unit
    return q, n.normalized


def _strength(ing: Ingredient, unit_display: str | None):
    num, n1 = _quantity(ing.num_value, ing.num_unit)
    den_unit_display = unit_display if (ing.den_unit == "1") else None
    den, n2 = _quantity(ing.den_value, ing.den_unit, den_unit_display)
    if num is None or den is None:
        return None, False
    return {"numerator": num, "denominator": den}, (n1 or n2)


def _ingredient_entries(ings: list[Ingredient], form_display: str | None):
    entries, side = [], []
    for ing in ings:
        item = {}
        if ing.substance_code:
            # The label's substance name is not always the UNII preferred term, so it goes in
            # CodeableConcept.text and coding.display is left to the code system.
            item["coding"] = [{"system": system_for(ing.substance_code_system) or SYS_UNII,
                               "code": ing.substance_code}]
        if ing.substance_name:
            item["text"] = ing.substance_name
        if not item:
            item["text"] = "unnamed ingredient"
        e = {"itemCodeableConcept": item, "isActive": ing.is_active}
        strength, normalized = _strength(ing, form_display)
        if strength:
            e["strength"] = strength
        entries.append(e)
        bcode, bname = ing.strength_substance()
        side.append({
            "source_index": ing.index,
            "class_code": ing.class_code,
            "basis_of_strength": ing.basis_of_strength,
            "strength_substance_unii": bcode,
            "strength_substance_name": bname,
            "moiety_uniis": ing.moiety_codes,
            "moiety_names": ing.moiety_names,
            "reference_unii": ing.reference_code,
            "reference_name": ing.reference_name,
            "num_value_source_text": ing.num_value,
            "num_unit_source": ing.num_unit,
            "den_value_source_text": ing.den_value,
            "den_unit_source": ing.den_unit,
            "strength_in_fhir": strength is not None,
            "json_decimal_normalized": normalized,
        })
    return entries, side


def _form(product_or_part) -> dict | None:
    if not product_or_part.form_code:
        return None
    return {"coding": [{"system": SYS_NCIT, "code": product_or_part.form_code,
                        **({"display": product_or_part.form_display} if product_or_part.form_display else {})}],
            **({"text": product_or_part.form_display} if product_or_part.form_display else {})}


def _labeled_name(p: Product) -> str:
    name = p.proprietary_name or p.generic_name or "unnamed product"
    if p.name_suffix:
        name = f"{name} {p.name_suffix}"
    return name


def _package_chain(pkgs: list[Package], pkg: Package) -> list[Package]:
    by = {p.path: p for p in pkgs}
    parts = pkg.path.split(".")
    return [by[".".join(parts[:i])] for i in range(1, len(parts) + 1)]


def _package_side(pkgs: list[Package], pkg: Package) -> dict:
    parsed = ndc_mod.parse(pkg.ndc_original) if pkg.ndc_original else None
    return {
        "path": pkg.path,
        "level": pkg.level,
        "ndc_original": pkg.ndc_original,
        "ndc_configuration": pkg.ndc_configuration,
        "ndc11": parsed.to_11() if parsed else None,
        "total_amount_value": pkg.total_amount_value,
        "total_amount_unit": pkg.total_amount_unit,
        "total_amount_status": pkg.total_amount_status,
        "marketing_status": pkg.marketing_status,
        "marketing_low": pkg.marketing_low,
        "marketing_high": pkg.marketing_high,
        "marketing_act_code": pkg.marketing_act_code,
        "combination_type_code": pkg.combination_type_code,
        "hierarchy": [{
            "path": c.path, "ndc_original": c.ndc_original, "form_code": c.form_code, "form_display": c.form_display,
            "qty_num_value": c.qty_num_value, "qty_num_unit": c.qty_num_unit,
            "qty_den_value": c.qty_den_value, "qty_den_unit": c.qty_den_unit,
        } for c in _package_chain(pkgs, pkg)],
    }


def _amount(pkg: Package, product_form_display: str | None):
    if pkg.total_amount_status != "computed":
        return None
    unit = pkg.total_amount_unit or "1"
    num, _ = _quantity(pkg.total_amount_value, unit, product_form_display if unit == "1" else None)
    den = {"value": number("1")}
    if pkg.form_code:
        den.update({"unit": pkg.form_display or pkg.form_code, "system": SYS_NCIT, "code": pkg.form_code})
    return {"numerator": num, "denominator": den}


def build_bundle(doc: SplDocument, source: dict, product_rxcui: dict | None = None,
                 package_rxcui: dict | None = None, products: list[int] | None = None) -> tuple[dict, dict]:
    """Return (Bundle, sidecar) for one SPL version.

    product_rxcui maps product index -> (rxcui, display) from the identifier
    crosswalk when it is unique; package_rxcui maps package NDC -> (rxcui, display).
    products restricts output to the in-scope product indexes.
    """
    product_rxcui = product_rxcui or {}
    package_rxcui = package_rxcui or {}
    entries, side_entries, med_ids = [], {}, []
    src = {
        "set_id": doc.set_id, "document_id": doc.document_id, "version_number": doc.version_number,
        "effective_time": doc.effective_time, "doc_type_code": doc.doc_type_code,
        "doc_type_display": doc.doc_type_display, "labeler_name": doc.labeler_name,
        "labeler_id": doc.labeler_id, "labeler_id_root": doc.labeler_id_root, **source,
    }
    for p in doc.products:
        if products is not None and p.index not in products:
            continue
        pid = stable_id(doc.document_id or "", "product", str(p.index))
        med = {"resourceType": "Medication", "id": pid}
        if p.ndc_original:
            med["identifier"] = [{"system": SYS_NDC, "value": p.ndc_original}]
        code = {}
        rx = product_rxcui.get(p.index)
        if rx:
            code["coding"] = [{"system": SYS_RXNORM, "code": rx[0], **({"display": rx[1]} if rx[1] else {})}]
        code["text"] = _labeled_name(p)
        med["code"] = code
        form = _form(p)
        if form:
            med["form"] = form
        ing_side = []
        part_side = []
        if p.is_kit:
            contained = []
            kit_ings = []
            for part in p.parts:
                part_id = f"part-{part.index + 1}"
                pm = {"resourceType": "Medication", "id": part_id}
                if part.ndc_original:
                    pm["identifier"] = [{"system": SYS_NDC, "value": part.ndc_original}]
                pm["code"] = {"text": part.name or f"kit part {part.index + 1}"}
                pf = _form(part)
                if pf:
                    pm["form"] = pf
                pe, ps = _ingredient_entries(part.ingredients, part.form_display)
                if pe:
                    pm["ingredient"] = pe
                contained.append(pm)
                ke = {"itemReference": {"reference": f"#{part_id}"}, "isActive": any(i.is_active for i in part.ingredients)}
                pq, _ = _quantity(part.qty_num_value, part.qty_num_unit, part.form_display if part.qty_num_unit == "1" else None)
                if pq is not None:
                    ke["strength"] = {"numerator": pq, "denominator": {"value": number("1"), "unit": p.form_display or "KIT",
                                                                       "system": SYS_NCIT, "code": p.form_code or "C47916"}}
                kit_ings.append(ke)
                part_side.append({"part_index": part.index, "contained_id": part_id, "ndc_original": part.ndc_original,
                                  "qty_num_value": part.qty_num_value, "qty_num_unit": part.qty_num_unit,
                                  "route_codes": part.route_codes, "approval_id": part.approval_id,
                                  "marketing_category_code": part.marketing_category_code,
                                  "ingredients": ps,
                                  "package_ndcs": [k.ndc_original for k in part.packages if k.ndc_original]})
            med["contained"] = contained
            med["ingredient"] = kit_ings + _ingredient_entries(p.ingredients, p.form_display)[0]
            ing_side = _ingredient_entries(p.ingredients, p.form_display)[1]
        else:
            ie, ing_side = _ingredient_entries(p.ingredients, p.form_display)
            if ie:
                med["ingredient"] = ie
        product_side = {
            "index": p.index, "ndc_original": p.ndc_original, "ndc_configuration": p.ndc_configuration,
            "proprietary_name": p.proprietary_name, "name_suffix": p.name_suffix, "generic_name": p.generic_name,
            "form_code": p.form_code, "form_display": p.form_display,
            "route_codes": p.route_codes, "route_displays": p.route_displays,
            "approval_id": p.approval_id, "approval_id_root": p.approval_id_root,
            "marketing_category_code": p.marketing_category_code,
            "marketing_category_display": p.marketing_category_display,
            "marketing_status": p.marketing_status, "marketing_low": p.marketing_low,
            "marketing_high": p.marketing_high, "equivalent_ndc": p.equivalent_ndc,
            "equivalent_code": p.equivalent_code, "is_kit": p.is_kit,
        }
        side_entries[pid] = {"medication_id": pid, "resource_level": "product", "product": product_side,
                             "ingredients": ing_side, "kit_parts": part_side,
                             "ingredient_list_complete": True,
                             "mapping": {"product_rxcui": rx[0] if rx else None}}
        entries.append(med)
        med_ids.append(pid)

        for pkg in p.packages:
            if not pkg.ndc_original:
                continue
            kid = stable_id(doc.document_id or "", "package", str(p.index), pkg.path)
            pmed = {"resourceType": "Medication", "id": kid}
            if p.ndc_original:
                pmed["identifier"] = [{"system": SYS_NDC, "value": p.ndc_original}]
            coding = [{"system": SYS_NDC, "code": pkg.ndc_original}]
            prx = package_rxcui.get(pkg.ndc_original)
            if prx:
                coding.append({"system": SYS_RXNORM, "code": prx[0], **({"display": prx[1]} if prx[1] else {})})
            pmed["code"] = {"coding": coding, "text": f"{_labeled_name(p)}, {pkg.form_display or 'package'} {pkg.ndc_original}"}
            if form:
                pmed["form"] = form
            amount = _amount(pkg, p.form_display)
            if amount:
                pmed["amount"] = amount
            if not p.is_kit:
                ie, _ = _ingredient_entries(p.ingredients, p.form_display)
                if ie:
                    pmed["ingredient"] = ie
            entries.append(pmed)
            med_ids.append(kid)
            side_entries[kid] = {"medication_id": kid, "resource_level": "package", "product_medication_id": pid,
                                 "package": _package_side(p.packages, pkg),
                                 "mapping": {"package_rxcui": prx[0] if prx else None}}

    bundle_id = stable_id(doc.document_id or "", "bundle")
    prov = {
        "resourceType": "Provenance",
        "id": stable_id(doc.document_id or "", "provenance"),
        "target": [{"reference": f"urn:uuid:{m}"} for m in med_ids],
        "recorded": source.get("retrieved_utc_fhir") or source.get("retrieved_utc"),
        "agent": [{"type": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                                        "code": "assembler"}]},
                   "who": {"display": "medid 1.0.0 SPL to FHIR R4 transform"}}],
        "entity": [{"role": "source",
                    "what": {"identifier": {"system": SYS_URI, "value": f"urn:uuid:{(doc.document_id or '').lower()}"},
                             "display": f"DailyMed SPL document {doc.document_id} (set {doc.set_id}, version {doc.version_number})"}}],
    }
    bundle = {
        "resourceType": "Bundle",
        "id": bundle_id,
        "type": "collection",
        "entry": [{"fullUrl": f"urn:uuid:{e['id']}", "resource": e} for e in entries]
                 + [{"fullUrl": f"urn:uuid:{prov['id']}", "resource": prov}],
    }
    sidecar = {"sidecar_version": "1.0", "bundle_id": bundle_id, "source": src, "medications": side_entries}
    return bundle, sidecar
