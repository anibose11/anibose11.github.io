"""Round-trip stage: compare each representation with a separate read of the
source XML, field by field, for every in-scope product-version record.

Representations
  R1_full   FHIR R4 + sidecar (the reversible representation)
  R_core    FHIR R4 core elements only, default reading of strength basis
  S_rx      only the approach-A RxCUI; attributes re-derived from current RxNorm
  S_flat    flat table: set ID, naive 11-digit NDCs, first active ingredient,
            float strengths, dose-form text
  S_api     DailyMed packaging.json for the product code (current versions)
  S_latest  preceding-version records read from the latest version of the label
"""
from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from fractions import Fraction

from psycopg.types.json import Jsonb  # noqa: F401  (kept for parity with other stages)

from . import db
from . import ndc as ndc_mod
from .corpus import iter_documents, manifest
from .fhir_export import bundle_paths
from .fhir_reverse import reconstruct
from .independent_read import read_critical
from .matching import norm_name, rx_strength, spl_strength_rx
from .paths import OUTPUTS, ROOT, ensure
from .quantity import float_roundtrip_text
from .roundtrip import CRITICAL, compare, compare_packages, record_ok, source_actives, source_boss

IDENTITY = [a for a in CRITICAL if a not in ("K1_set_id", "K2_document_id", "K3_version")]


def _as_rec_active(a: dict) -> dict:
    return {"unii": a["unii"], "class_code": a["class_code"], "moiety_uniis": a["moiety_uniis"],
            "reference_unii": a["reference_unii"], "boss_unii": source_boss(a), "boss_source": "source",
            "num_value": a["num_value"], "num_unit": a["num_unit"], "den_value": a["den_value"], "den_unit": a["den_unit"]}


def _boss_name(a: dict) -> str | None:
    if a["class_code"] == "ACTIB":
        return a.get("name")
    if a["class_code"] == "ACTIM" and len(a.get("moiety_names") or ()) == 1:
        return a["moiety_names"][0]
    if a["class_code"] == "ACTIR":
        return a.get("reference_name")
    return None


# --- shortcut reconstructions -----------------------------------------------------

def s_flat(src_doc: dict, src_prod: dict, form_display: str | None) -> tuple[dict, dict, dict]:
    """Returns (rec_doc, rec_prod, src_prod_for_comparison). Package NDCs are
    compared in 11-digit space: the correct segment-aware form against naive padding."""
    acts = source_actives(src_prod)
    first = acts[:1]
    rec_act = []
    for a in first:
        rec_act.append({"unii": None, "class_code": None, "boss_unii": None, "boss_source": "flat",
                        "num_value": float_roundtrip_text(a["num_value"]) if a["num_value"] else None,
                        "num_unit": a["num_unit"],
                        "den_value": float_roundtrip_text(a["den_value"]) if a["den_value"] else None,
                        "den_unit": a["den_unit"]})
    src_cmp = dict(src_prod)
    src_cmp["package_ndcs"] = [ndc_mod.parse(c).to_11() or c for c in src_prod["package_ndcs"]]
    rec_prod = {"product_ndc": None, "form_code": None,
                "form_code_converted": "converted_equivalent" if form_display else None,
                "active": rec_act, "package_ndcs": [ndc_mod.naive_pad_11(c) for c in src_prod["package_ndcs"]],
                "part_ndcs": None}
    rec_doc = {"set_id": src_doc["set_id"], "document_id": None, "version_number": None}
    return rec_doc, rec_prod, src_cmp


def s_rx(src_prod: dict, rxcui: str | None, conn) -> dict | None:
    if not rxcui:
        return None
    strengths = conn.execute("""select boss_rxcui, boss_name, active_ingredient_rxcui, moiety_rxcui,
                                       num_value, num_unit, den_value, den_unit
                                from medid.rx_concept_strength where rxcui = %s order by seq""", (rxcui,)).fetchall()
    rx_rows = [{"boss_rxcui": r[0], "boss_name": r[1], "ai": r[2], "moiety": r[3], "numeratorValue": r[4],
                "numeratorUnit": r[5], "denominatorValue": r[6], "denominatorUnit": r[7]} for r in strengths]
    acts = source_actives(src_prod)
    used, out = set(), []
    for a in acts:
        want = norm_name(_boss_name(a))
        s_norm_a = spl_strength_rx(a["num_value"], a["num_unit"], a["den_value"], a["den_unit"])
        same_name = [k for k, r in enumerate(rx_rows) if k not in used and norm_name(r["boss_name"]) == want]
        # when several components share a name (pack parts of one ingredient), prefer the one with the same strength
        j = next((k for k in same_name if s_norm_a is not None and rx_strength(rx_rows[k]) == s_norm_a), None)
        if j is None:  # unit not convertible (for example [arb'U]): align on the numerator value alone
            j = next((k for k in same_name if rx_rows[k]["numeratorValue"] == a["num_value"]), same_name[0] if same_name else None)
        if j is None:  # no name match: prefer an unused component with the same numerator value
            unused = [k for k in range(len(rx_rows)) if k not in used]
            j = next((k for k in unused if rx_rows[k]["numeratorValue"] == a["num_value"]), unused[0] if unused else None)
        if j is None:
            break
        used.add(j)
        r = rx_rows[j]
        basis = "ACTIB" if r["boss_rxcui"] == r["ai"] else ("ACTIM" if r["boss_rxcui"] == r["moiety"] else None)
        conv = {}
        s_norm = spl_strength_rx(a["num_value"], a["num_unit"], a["den_value"], a["den_unit"])
        r_norm = rx_strength(r)
        if s_norm and r_norm and s_norm == r_norm:
            conv = {k: "converted_equivalent" for k in ("K11_num_value", "K11_num_unit", "K12_den_value", "K12_den_unit")}
        rec = {"unii": None, "class_code": basis, "boss_unii": None, "boss_source": "rxnorm",
               "num_value": r["numeratorValue"], "num_unit": r["numeratorUnit"], "den_value": r["denominatorValue"],
               "den_unit": r["denominatorUnit"], "converted": conv,
               "class_code_derived": True}  # RxNorm has no SPL class code; derived from its BoSS concepts
        if want and norm_name(r["boss_name"]) == want:
            rec["boss_converted"] = "converted_equivalent"
        elif r["boss_name"]:
            rec["boss_converted"] = "discordant"
        out.append(rec)
    rec_prod = {"product_ndc": None, "form_code": None, "active": out + [None] * 0, "package_ndcs": None,
                "part_ndcs": None}
    if len(rx_rows) != len(acts):
        rec_prod["active"] = out + [{"unii": None, "class_code": None, "boss_unii": None, "boss_source": "rxnorm",
                                     "num_value": None, "num_unit": None, "den_value": None, "den_unit": None}] * max(0, len(rx_rows) - len(out))
    return rec_prod


_STRENGTH = re.compile(r"^\s*([0-9.]+)\s+(\S+)(?:\s+in\s+([0-9.]+)\s*(\S*))?\s*$")


def s_api(src_prod: dict, packaging: dict | None, product_names: dict) -> dict | None:
    if not packaging:
        return None
    prods = (packaging.get("data") or {}).get("products") or []
    hit = [p for p in prods if p.get("product_code") == src_prod["product_ndc"]]
    if len(hit) != 1:
        return None
    p = hit[0]
    api = []
    for ai in p.get("active_ingredients") or []:
        m = _STRENGTH.match(ai.get("strength") or "")
        # "500 mg" states no denominator; it is left unresolved rather than assumed to be "per unit"
        nv, nu, dv, du = (m.group(1), m.group(2), m.group(3), m.group(4) or None) if m else (None, None, None, None)
        api.append({"name": norm_name(ai.get("name")), "num_value": nv, "num_unit": nu, "den_value": dv, "den_unit": du})
    acts = source_actives(src_prod)
    used, out = set(), []
    for a in acts:
        want = norm_name(a.get("name"))
        j = next((k for k, r in enumerate(api) if k not in used and r["name"] == want), None)
        if j is None:
            out.append(None)
            continue
        used.add(j)
        r = api[j]
        out.append({"unii": None, "class_code": None, "boss_unii": None, "boss_source": "api", **{k: r[k] for k in
                    ("num_value", "num_unit", "den_value", "den_unit")}})
    extra = [r for k, r in enumerate(api) if k not in used]
    active = [x for x in out]
    rec = {"product_ndc": p.get("product_code"), "form_code": None,
           "active": [x if x is not None else {"unii": None, "class_code": None, "boss_unii": None, "boss_source": "api",
                                               "num_value": None, "num_unit": None, "den_value": None, "den_unit": None}
                      for x in active] + [{"unii": None, "class_code": None, "boss_unii": None, "boss_source": "api",
                                           **{k: r[k] for k in ("num_value", "num_unit", "den_value", "den_unit")}} for r in extra],
           "package_ndcs": [pk.get("ndc") for pk in p.get("packaging") or [] if pk.get("ndc")],
           "part_ndcs": None}
    return rec


# --- driver ------------------------------------------------------------------------

def run_roundtrip(split: str | None = None, log=print) -> dict:
    """split='development' restricts the run while rules are being developed; the
    held-out evaluation runs with split=None after the rules are frozen."""
    db.start()
    m = manifest()
    labels = {e["setid"]: e for e in m["labels"] if e["status"] == "eligible"}
    rows, records, pkg_records = [], [], []
    current_src = {}
    preceding = []
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        a_rx = dict(conn.execute("select product_key, rxcui from match_result where approach='A' and outcome='unique'").fetchall())
        form_disp = dict(conn.execute("select product_key, form_display from spl_product").fetchall())
        for doc, meta in iter_documents(split=split):
            src = read_critical(ROOT / meta["source_path"])
            bp, sp = bundle_paths(doc.document_id)
            full = reconstruct(bp, sp, "full") if bp.exists() else None
            core = reconstruct(bp, None, "core") if bp.exists() else None
            if full and full.get("document_id") and full["document_id"] != src["document_id"] and \
                    full["document_id"].lower() == (src["document_id"] or "").lower():
                pass  # UUID lowercased in Provenance (FHIR rule); handled as documented normalization below
            packaging = None
            if meta["version_kind"] == "current" and labels[meta["setid"]].get("packaging"):
                packaging = json.loads((ROOT / labels[meta["setid"]]["packaging"]["path"]).read_text())
            if meta["version_kind"] == "current":
                current_src[meta["setid"]] = src
            ndc_counts = Counter(p["product_ndc"] for p in src["products"])
            for i in meta["products_in_scope"]:
                sp_ = src["products"][i]
                key = f"{doc.document_id}:{i}"
                reps = {}
                reps["R1_full"] = compare(src, sp_, full, (full or {}).get("products", {}).get(("index", i)), "R1_full")
                core_prod = None
                if core and sp_["product_ndc"] and ndc_counts[sp_["product_ndc"]] == 1:
                    core_prod = core["products"].get(("ndc", sp_["product_ndc"]))
                reps["R_core"] = compare(src, sp_, core, core_prod, "R_core", sidecar_available=True)
                rd, rp, sc = s_flat(src, sp_, form_disp.get(key))
                reps["S_flat"] = compare(src, sc, rd, rp, "S_flat")
                if meta["version_kind"] == "current":
                    reps["S_rx"] = compare(src, sp_, {"set_id": None, "document_id": None, "version_number": None},
                                           s_rx(sp_, a_rx.get(key), conn), "S_rx")
                    reps["S_api"] = compare(src, sp_, {"set_id": None, "document_id": None, "version_number": None},
                                            s_api(sp_, packaging, {}), "S_api")
                else:
                    preceding.append((key, doc, meta, src, sp_))
                for rep, rp_ in (("R1_full", (full or {}).get("products", {}).get(("index", i))), ("R_core", core_prod)):
                    for pk in compare_packages(sp_, rp_):
                        pkg_records.append({"product_key": key, "package_ndc": pk["package_ndc"], "representation": rep,
                                            "split": meta["split"], "version_kind": meta["version_kind"],
                                            "primary_group": meta["primary_group"], "set_id": doc.set_id,
                                            "all_package_ok": pk["ok"],
                                            **{r["attribute"]: r["status"] for r in pk["rows"]}})
                for rep, rr in reps.items():
                    _fix_uuid_case(rr)
                    for r in rr:
                        rows.append((key, rep, r["attribute"], r["item"], r["status"], r["source_value"],
                                     r["reconstructed_value"], r["value_equal"]))
                    records.append({"product_key": key, "representation": rep, "split": meta["split"],
                                    "version_kind": meta["version_kind"], "primary_group": meta["primary_group"],
                                    "set_id": doc.set_id, "all_critical_ok": record_ok(rr),
                                    "identity_ok": record_ok(rr, IDENTITY),
                                    "is_kit": bool(sp_["parts"]), "active_count": len(source_actives(sp_)),
                                    "equivalent_source": None})
        # S_latest for preceding-version records
        for key, doc, meta, src, sp_ in preceding:
            cur = current_src.get(meta["setid"])
            match = [p for p in (cur or {}).get("products", []) if sp_["product_ndc"] and p["product_ndc"] == sp_["product_ndc"]]
            rec_prod = None
            if len(match) == 1:
                q = match[0]
                rec_prod = {"product_ndc": q["product_ndc"], "form_code": q["form_code"],
                            "active": [_as_rec_active(a) for a in source_actives(q)],
                            "package_ndcs": q["package_ndcs"], "part_ndcs": [p["ndc"] for p in q["parts"]]}
            rr = compare(src, sp_, {"set_id": cur["set_id"] if cur else None, "document_id": cur["document_id"] if cur else None,
                                    "version_number": cur["version_number"] if cur else None}, rec_prod, "S_latest",
                         unii_alignment=True)
            for r in rr:
                rows.append((key, "S_latest", r["attribute"], r["item"], r["status"], r["source_value"],
                             r["reconstructed_value"], r["value_equal"]))
            records.append({"product_key": key, "representation": "S_latest", "split": meta["split"],
                            "version_kind": "preceding", "primary_group": meta["primary_group"], "set_id": doc.set_id,
                            "all_critical_ok": record_ok(rr), "identity_ok": record_ok(rr, IDENTITY),
                            "is_kit": bool(sp_["parts"]), "active_count": len(source_actives(sp_)),
                            "equivalent_source": None})
        eq = dict(conn.execute("select product_key, equivalent_ndc is not null from spl_product").fetchall())
        for r in records:
            r["equivalent_source"] = eq.get(r["product_key"])
        conn.execute("delete from roundtrip_field")
        conn.cursor().executemany("insert into roundtrip_field values (%s,%s,%s,%s,%s,%s,%s,%s)", rows)
        conn.commit()
    ensure(OUTPUTS / "roundtrip")
    with open(OUTPUTS / "roundtrip" / "records.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        w.writeheader()
        w.writerows(records)
    with open(OUTPUTS / "roundtrip" / "package_records.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(pkg_records[0].keys()))
        w.writeheader()
        w.writerows(pkg_records)
    summary = defaultdict(Counter)
    for r in rows:
        summary[(r[1], r[2])][r[4]] += 1
    with open(OUTPUTS / "roundtrip" / "field_status_counts.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["representation", "attribute", "status", "count"])
        for (rep, attr), c in sorted(summary.items()):
            for st, n in sorted(c.items()):
                w.writerow([rep, attr, st, n])
    out = {"field_rows": len(rows), "record_rows": len(records), "package_records": len(pkg_records)}
    log(f"roundtrip: {out}")
    return out


def _fix_uuid_case(rows: list[dict]) -> None:
    """Document IDs are written lowercase in FHIR urn:uuid values (R4 datatypes rule).
    A case-only difference is the documented normalization, not a discordance."""
    for r in rows:
        if r["attribute"] == "K2_document_id" and r["status"] == "discordant" and r["source_value"] and \
                r["reconstructed_value"] and r["source_value"].lower() == r["reconstructed_value"].lower():
            r["status"] = "preserved_normalized"
