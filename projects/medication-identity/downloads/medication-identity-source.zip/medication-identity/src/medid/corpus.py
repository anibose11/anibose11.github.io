"""Iterate over the analyzed SPL documents (eligible current versions and the
retrieved preceding versions) with their frozen split and group labels."""
from __future__ import annotations

import json
import tomllib
from functools import lru_cache

from .acquire import product_groups, unii_groups
from .paths import CONFIG, INTERIM, ROOT
from .spl import SplDocument, parse_spl


@lru_cache(maxsize=1)
def manifest() -> dict:
    return json.loads((INTERIM / "label_manifest.json").read_text())


@lru_cache(maxsize=1)
def scope() -> dict:
    return json.loads((CONFIG / "scope_frozen.json").read_text())


def config() -> dict:
    return tomllib.loads((CONFIG / "study.toml").read_text())


def iter_documents(include_preceding: bool = True, split: str | None = None):
    """Yield (SplDocument, meta). meta['products_in_scope'] lists product indexes."""
    m = manifest()
    ug = unii_groups(scope())
    labels = {e["setid"]: e for e in m["labels"] if e["status"] == "eligible"}
    for e in labels.values():
        if split and e["split"] != split:
            continue
        x = e["current_xml"]
        doc = parse_spl(ROOT / x["path"])
        yield doc, {
            "setid": e["setid"], "version_kind": "current", "split": e["split"],
            "primary_group": e["primary_group"], "groups": e["groups"],
            "products_in_scope": e["products_in_scope"], "source_url": x["url"],
            "source_path": x["path"], "source_sha256": x["sha256"], "retrieved_utc": x["retrieved_utc"],
        }
    if not include_preceding:
        return
    for p in m["preceding_versions"]:
        if p["preceding_version"] is None:
            continue
        e = labels[p["setid"]]
        if split and e["split"] != split:
            continue
        att = next(a for a in p["attempts"] if a["result"] == "ok")
        doc = parse_spl(ROOT / att["xml_path"])
        in_scope = [q.index for q in doc.products if product_groups(q, ug)]
        yield doc, {
            "setid": p["setid"], "version_kind": "preceding", "split": e["split"],
            "primary_group": e["primary_group"], "groups": e["groups"],
            "products_in_scope": in_scope, "source_url": att["zip"]["url"],
            "source_path": att["xml_path"], "source_sha256": att["xml_sha256"],
            "source_zip_sha256": att["zip"]["sha256"], "retrieved_utc": att["zip"]["retrieved_utc"],
        }


def load_document(path: str) -> SplDocument:
    return parse_spl(ROOT / path)
