"""Reusable medication dictionary export.

Grain: one row per package NDC in a current-version, in-scope product. Each
row carries the label provenance, the product and ingredient attributes as
labeled, RxNorm's view of the NDC, the crosswalk results, and review reasons
that tell a maintainer why a row deserves a second look. The file stands on
its own: a team can load it without the rest of the pipeline.
"""
from __future__ import annotations

import csv
import json
from collections import defaultdict

from . import db
from .paths import INTERIM, OUTPUTS, ensure

UNAPPROVED = {"C73627", "C73614", "C101533"}

COLUMNS = [
    "set_id", "spl_version", "document_id", "effective_time", "labeler_name",
    "product_ndc", "package_ndc", "package_ndc_configuration", "package_ndc11",
    "proprietary_name", "name_suffix", "generic_name", "dosage_form_code", "dosage_form",
    "route_codes", "active_ingredients", "basis_of_strength", "package_path", "package_form",
    "package_amount_value", "package_amount_unit", "package_marketing_status", "package_marketing_start",
    "package_marketing_end", "drug_sample_package", "marketing_category", "application_number", "is_kit",
    "repackaged_from_ndc",
    "rxnorm_ndc_status", "rxnorm_package_rxcui", "rxnorm_package_concept", "rxnorm_package_tty",
    "product_rxcui_identifier_crosswalk", "product_crosswalk_outcome", "dailymed_setlevel_agreement",
    "name_attribute_match_outcome", "name_attribute_match_rxcui",
    "review_reasons", "source_url", "source_sha256", "rxnorm_release", "retrieved_utc",
]


def export_dictionary(log=print) -> dict:
    ensure(OUTPUTS / "dictionary")
    rxv = json.loads((INTERIM / "rxnorm_manifest.json").read_text())["rxnorm_version"]
    db.start()
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        ings = defaultdict(list)
        for r in conn.execute("""select i.product_key, i.substance_name, i.substance_unii, i.class_code, i.basis_of_strength,
                                        i.strength_substance_name, i.num_value, i.num_unit, i.den_value, i.den_unit, i.part_key
                                 from spl_ingredient i where i.is_active order by i.product_key, i.part_key nulls first, i.ingredient_index"""):
            ings[r[0]].append(r[1:])
        multi_label = {r[0] for r in conn.execute("""select k.ndc_original from spl_package k join spl_product p using (product_key)
            join spl_document d using (document_id) where d.version_kind='current' and k.ndc_original is not null
            group by 1 having count(distinct d.set_id) > 1""")}
        match = defaultdict(dict)
        for pk, ap, out, rx in conn.execute("select product_key, approach, outcome, rxcui from match_result"):
            match[pk][ap] = (out, rx)
        src = {r[0]: r[1:] for r in conn.execute("select path, url, sha256, retrieved_utc from source_file")}
        rows = conn.execute("""
            select d.set_id, d.version_number, d.document_id, d.effective_time, d.labeler_name, p.product_key,
                   p.ndc_original, k.ndc_original, k.ndc_configuration, k.ndc11, p.proprietary_name, p.name_suffix,
                   p.generic_name, p.form_code, p.form_display, p.route_codes, k.path, k.form_display,
                   k.total_amount_value, k.total_amount_unit, k.marketing_status, k.marketing_low, k.marketing_high,
                   k.marketing_act_code, p.marketing_category_display, p.marketing_category_code, p.approval_id,
                   p.is_kit, p.equivalent_ndc, s.status, s.rxcui, c.name, c.tty, d.source_path
            from spl_package k join spl_product p using (product_key) join spl_document d using (document_id)
            left join rx_ndc_status s on s.ndc11 = k.ndc11 left join rx_concept c on c.rxcui = s.rxcui
            where d.version_kind = 'current' and p.in_scope and k.ndc_original is not null
            order by d.set_id, p.product_index, k.path""").fetchall()
    out = []
    for r in rows:
        (set_id, ver, doc, eff, lab, pk, pndc, kndc, kcfg, k11, pname, suffix, gname, fcode, fdisp, routes, path,
         kform, amt, amtu, kstat, klow, khigh, act, cat, catcode, appl, kit, equiv, rstat, rrx, rname, rtty, spath) = r
        actives = ings.get(pk, [])
        act_text = "; ".join(f"{a[0]} [{a[1]}] {a[5] or ''} {a[6] or ''}" + (f"/{a[7]} {a[8]}" if a[8] not in (None, "1") else "")
                             for a in actives).replace("  ", " ")
        basis = "; ".join(f"{a[0]}: strength stated as {a[4] or 'unspecified'}" for a in actives if a[2] != "ACTIB")
        m = match.get(pk, {})
        reasons = []
        if rstat is None or rstat == "UNKNOWN":
            reasons.append("package NDC not known to RxNorm")
        elif rstat != "ACTIVE":
            reasons.append(f"RxNorm NDC status {rstat}")
        if m.get("A", (None,))[0] == "ambiguous":
            reasons.append("packages of this product map to different RxCUIs")
        if m.get("A2", (None,))[0] == "disagree":
            reasons.append("DailyMed set-level mapping does not list the identifier-crosswalk RxCUI")
        if m.get("A2", (None,))[0] == "not_in_mapping_file":
            reasons.append("label absent from DailyMed RxNorm mapping file")
        b = m.get("B", (None, None))
        a = m.get("A", (None, None))
        if b[0] == "unique" and a[0] == "unique" and b[1] != a[1]:
            reasons.append("name-and-attribute match disagrees with identifier crosswalk")
        if kndc in multi_label:
            reasons.append("package NDC listed in more than one current label")
        if act == "C96974":
            reasons.append("drug sample package")
        if kstat == "completed":
            reasons.append("package marketing completed" + (f" (end {khigh})" if khigh else ""))
        if catcode in UNAPPROVED:
            reasons.append(f"marketing category: {cat}")
        if kit:
            reasons.append("kit: ingredients are in parts")
        if equiv:
            reasons.append("repackaged or relabeled product")
        if basis:
            reasons.append("strength basis is not the listed ingredient")
        if len(actives) >= 2:
            reasons.append("combination product")
        if amt is None:
            reasons.append("package amount could not be computed exactly from the package tree")
        url, sha, ret = src.get(spath, (None, None, None))
        out.append({
            "set_id": set_id, "spl_version": ver, "document_id": doc, "effective_time": eff, "labeler_name": lab,
            "product_ndc": pndc, "package_ndc": kndc, "package_ndc_configuration": kcfg, "package_ndc11": k11,
            "proprietary_name": pname, "name_suffix": suffix, "generic_name": gname, "dosage_form_code": fcode,
            "dosage_form": fdisp, "route_codes": ";".join(routes or []), "active_ingredients": act_text,
            "basis_of_strength": basis, "package_path": path, "package_form": kform, "package_amount_value": amt,
            "package_amount_unit": amtu, "package_marketing_status": kstat, "package_marketing_start": klow,
            "package_marketing_end": khigh, "drug_sample_package": act == "C96974", "marketing_category": cat,
            "application_number": appl, "is_kit": kit, "repackaged_from_ndc": equiv,
            "rxnorm_ndc_status": rstat or "not looked up", "rxnorm_package_rxcui": rrx, "rxnorm_package_concept": rname,
            "rxnorm_package_tty": rtty, "product_rxcui_identifier_crosswalk": a[1], "product_crosswalk_outcome": a[0],
            "dailymed_setlevel_agreement": m.get("A2", (None,))[0], "name_attribute_match_outcome": b[0],
            "name_attribute_match_rxcui": b[1], "review_reasons": "; ".join(x for x in reasons if x),
            "source_url": url, "source_sha256": sha, "rxnorm_release": rxv.get("version"), "retrieved_utc": ret,
        })
    path = OUTPUTS / "dictionary" / "medication_dictionary.csv"
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(out)
    reasons = defaultdict(int)
    for r in out:
        for x in filter(None, r["review_reasons"].split("; ")):
            reasons[x.split(" (end")[0].split(":")[0]] += 1
    summary = {"rows": len(out), "rows_with_review_reason": sum(1 for r in out if r["review_reasons"]),
               "reason_counts": dict(sorted(reasons.items(), key=lambda kv: -kv[1]))}
    (OUTPUTS / "dictionary" / "summary.json").write_text(json.dumps(summary, indent=1))
    log(f"dictionary: {summary['rows']} rows")
    return summary
