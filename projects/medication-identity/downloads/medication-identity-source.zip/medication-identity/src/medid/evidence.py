"""Evidence files: source manifest, claims and the private verified-results note.

claims.json maps each headline number to the output file and key it comes
from, with numerator, denominator, scope, code fingerprint, source hashes and
run identifier. verified_results.md (handoff/) lists only verified methods and
measured results with their evidence paths.
"""
from __future__ import annotations

import hashlib
import json

from . import db
from .cli import code_fingerprint
from .http import sha256_file
from .numbers import fmt, numbers, pct
from .paths import CONFIG, EVIDENCE, HANDOFF, INTERIM, OUTPUTS, ROOT, ensure

PERMITTED_USE = {
    "dailymed": ("DailyMed content from the U.S. National Library of Medicine; NLM web policy permits reuse of U.S. government "
                 "works with attribution. Manufacturer label text and images may carry their own rights and are not redistributed here."),
    "rxnav": ("RxNorm API responses; free of charge without a UMLS licence for these endpoints under the RxNav terms of service "
              "(20 requests per second per IP, caching recommended); attribution to NLM requested; content as of the named release."),
}


def source_manifest() -> dict:
    db.start()
    with db.connect() as conn:
        rows = conn.execute("select path, kind, url, sha256, bytes, retrieved_utc from medid.source_file order by kind, path").fetchall()
    rxm = json.loads((INTERIM / "rxnorm_manifest.json").read_text())
    lab = json.loads((INTERIM / "label_manifest.json").read_text())
    out = {
        "generated_by": "medid evidence (src/medid/evidence.py)",
        "reference_date": "2026-10-07",
        "sources": [
            {"name": "DailyMed web services v2 and label archive", "publisher": "U.S. National Library of Medicine",
             "endpoints": ["https://dailymed.nlm.nih.gov/dailymed/services/v2/spls.json",
                           "https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}.xml",
                           "https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}/history.json",
                           "https://dailymed.nlm.nih.gov/dailymed/services/v2/spls/{setid}/packaging.json",
                           "https://dailymed.nlm.nih.gov/dailymed/getFile.cfm?type=zip&setid={setid}&version={n}"],
             "reference_period": "labels current at retrieval (2026-10-07) and the immediately preceding available version for 218 labels",
             "permitted_use": PERMITTED_USE["dailymed"]},
            {"name": "DailyMed SPL-to-RxNorm mapping file", "url": lab["rxnorm_mapping_file"]["url"],
             "bytes": lab["rxnorm_mapping_file"]["bytes"], "sha256": lab["rxnorm_mapping_file"]["sha256"],
             "retrieved_utc": lab["rxnorm_mapping_file"]["retrieved_utc"], "reference_period": "current SPL versions at file date",
             "permitted_use": PERMITTED_USE["dailymed"]},
            {"name": "RxNorm API (RxNav)", "publisher": "U.S. National Library of Medicine", "url": "https://rxnav.nlm.nih.gov/REST/",
             "release": rxm["rxnorm_version"]["version"], "api_version": rxm["rxnorm_version"]["apiVersion"],
             "reference_period": "current release at retrieval; dated NDC history as published by RxNorm",
             "permitted_use": PERMITTED_USE["rxnav"]},
        ],
        "rebuild_limits": ("The DailyMed services and the RxNorm API serve only current content. A later rerun of acquisition "
                           "will retrieve whatever is current then; this manifest's SHA-256 values identify the exact bytes this "
                           "study used. Archived label versions are fixed by set ID and version number."),
        "files": [{"path": r[0], "kind": r[1], "url": r[2], "sha256": r[3], "bytes": int(r[4]),
                   "retrieved_utc": r[5].strftime("%Y-%m-%dT%H:%M:%SZ")} for r in rows],
    }
    (OUTPUTS / "source_manifest.json").write_text(json.dumps(out, indent=0))
    return out


def _run_id() -> str:
    log = (OUTPUTS / "runs" / "stage_log.jsonl").read_text().strip().splitlines()
    last = [json.loads(x) for x in log if json.loads(x)["stage"] == "analyze"][-1]
    return f"{last['started_utc']}-{last['code_fingerprint']}"


def claims() -> dict:
    N = numbers()
    run = _run_id()
    fp = code_fingerprint()
    src = {
        "label_manifest_sha256": sha256_file(INTERIM / "label_manifest.json"),
        "rxnorm_manifest_sha256": sha256_file(INTERIM / "rxnorm_manifest.json"),
        "dailymed_mapping_file_sha256": N["mapping_file_sha"],
        "rxnorm_release": N["rxnorm_release"],
        "scope_sha256": sha256_file(CONFIG / "scope_frozen.json"),
        "normalization_rules_sha256": sha256_file(CONFIG / "normalization.toml"),
    }
    res = "outputs/analysis/results.json"

    def c(cid, text, num, den, path, key, scope):
        return {"id": cid, "statement": text, "numerator": num, "denominator": den,
                "value": None if den in (None, 0) else round(num / den, 6), "output_path": path, "key": key,
                "scope": scope, "configuration": {"code_fingerprint": fp, "config": ["config/study.toml", "config/normalization.toml"]},
                "source_hashes": src, "run_id": run}

    L = [
        c("corpus_eligible_labels", "Eligible current DailyMed prescription labels in scope", N["eligible"], N["candidates"], res,
          "corpus.eligible_set_ids / corpus.candidate_set_ids", "candidate set IDs from DailyMed moiety-UNII and name searches"),
        c("corpus_documents", "SPL documents analyzed (current plus preceding)", N["docs_total"], None, res,
          "corpus.documents_current + corpus.documents_preceding", "all"),
        c("corpus_product_records", "In-scope product-version records", N["prod_records"], None, res, "corpus.product_records_in_scope", "all"),
        c("primary_reversible_heldout", "Held-out product-version records with every applicable critical attribute preserved from FHIR plus sidecar",
          N["h_r1_ok"], N["h_r1_n"], "outputs/tables/roundtrip_record_outcomes.csv", "representation=R1_full, split=held_out, all_critical_ok/records",
          f"held-out split, {N['h_r1_sets']} SPL set IDs"),
        c("reversible_all", "All product-version records preserved from FHIR plus sidecar", N["all_r1_ok"], N["all_r1_n"],
          "outputs/tables/roundtrip_record_outcomes.csv", "representation=R1_full, split=all", "development plus held-out"),
        c("core_boss_misread", "Held-out active ingredients whose basis-of-strength substance is misread from FHIR core alone",
          N["h_core_boss_disc"], N["h_core_boss_n"], "outputs/tables/roundtrip_field_status.csv",
          "representation=R_core, attribute=K10_boss_unii, split=held_out, discordant/applicable", "held-out active ingredients"),
        c("core_identity_share", "Held-out identity and strength fields preserved by FHIR core alone",
          next(r["preserved"] for r in _fig1() if r["representation"] == "R_core"),
          next(r["applicable"] for r in _fig1() if r["representation"] == "R_core"), "outputs/figures/fig1_data.csv",
          "representation=R_core, preserved/applicable", "held-out fields K4 to K13"),
        c("ndc_naive_padding", "Distinct current package NDCs changed by padding without the segment pattern", N["ndc_naive_wrong"],
          N["ndc_distinct"], "outputs/tables/shortcut_ndc_padding.csv", "sum(package_ndcs - naive_equals_correct)/sum(package_ndcs)",
          "distinct package NDCs in current in-scope products"),
        c("api_count_wrong", "Held-out products with the wrong active-ingredient count in DailyMed packaging.json", N["h_api_count_disc"],
          N["h_api_count_n"], "outputs/tables/roundtrip_field_status.csv", "representation=S_api, attribute=K7_active_count, split=held_out",
          "held-out current products"),
        c("api_strength_wrong", "Held-out active ingredients given another product's strength by DailyMed packaging.json (read in order)",
          N["h_api_num_disc"], N["h_api_num_n"], "outputs/tables/roundtrip_field_status.csv",
          "representation=S_api, attribute=K11_num_value, split=held_out", "held-out active ingredients"),
        c("crosswalk_a_unique", "Held-out current products with a unique RxCUI from package NDCs", N["h_a_unique"], N["h_products"],
          "outputs/tables/matching_outcomes.csv", "split=held_out, approach=A, outcome=unique", "held-out current products"),
        c("crosswalk_a2_agree", "Held-out products where the DailyMed set-level file lists the NDC-crosswalk RxCUI", N["h_a2_agree"],
          N["h_a2_agree"] + N["h_a2_disagree"], "outputs/tables/matching_outcomes.csv", "split=held_out, approach=A2, agree/(agree+disagree)",
          "held-out products with unique A RxCUI and a mapping-file entry"),
        c("b_agree", "Approach B answers agreeing with approach A", N["h_b_agree"], N["h_b_answered"],
          "outputs/tables/matching_agreement_with_A.csv", "split=held_out, approach=B, agree_exact_rxcui/answered", "held-out, A unique"),
        c("b_answered", "Approach B answered among products with a unique approach-A RxCUI", N["h_b_answered"], N["h_a_unique"],
          "outputs/tables/matching_agreement_with_A.csv", "split=held_out, approach=B, answered/a_unique", "held-out, A unique"),
        c("c_wrong", "Approach C answers disagreeing with approach A", N["h_c_wrong"], N["h_c_answered"],
          "outputs/tables/matching_agreement_with_A.csv", "split=held_out, approach=C, disagree/answered", "held-out, A unique"),
        c("c_top1", "Approach C top candidate (no abstention) equal to approach A", N["h_c_top1"], N["h_a_unique"], res,
          "matching.C_top1_no_abstention.held_out", "held-out, A unique"),
        c("versions_any_change", "Label version pairs with any product-identity change", N["v_any"], N["v_pairs"],
          "outputs/tables/version_changes_by_set.csv", "count(any_identity_change>0)/rows", "version subset with retrieved preceding version"),
        c("latest_only_heldout", "Held-out preceding-version records whose identity attributes are all recovered from the latest version",
          N["h_latest_ok"], N["h_latest_n"], "outputs/tables/roundtrip_record_outcomes.csv", "representation=S_latest, split=held_out, identity_ok/records",
          "held-out preceding-version records"),
        c("validation_offline_errors", "Validator errors across all Bundles with terminology off", N["val_errors"], N["val_files"],
          "outputs/validation/summary.json", "offline_all.issues_by_severity.error / offline_all.files", "all Bundles"),
        c("validation_tx_ndc_errors", "Terminology-sample errors that are NDC codes unknown to the server's 2021-11-01 NDC content",
          N["tx_err_ndc"], N["tx_errors"], res, "validation.tx_sample.errors_by_code_system", "60 sampled Bundles"),
        c("repackaged_notfound", "Repackaged products with no RxNorm-active package NDC", N["rep_notfound"], N["rep_total"], res,
          "database medid.match_result approach A by equivalent_ndc (numbers.rep_notfound)", "current products, both splits"),
        c("repackaged_notfound_heldout", "Held-out repackaged products with no RxNorm-active package NDC", N["h_rep_notfound"],
          N["h_rep_total"], res, "database medid.match_result approach A by equivalent_ndc (numbers.h_rep_notfound)",
          "held-out current products"),
        c("a2_not_listed_labels", "Held-out labels whose analyzed version is not in DailyMed's set-level mapping file",
          N["h_a2_absent_sets"], N["held_sets"], res, "matching.A2_held_out.not_in_mapping_file_labels", "held-out labels"),
        c("sa3_package_grain", "Held-out package-version records with every applicable package attribute preserved from FHIR plus sidecar",
          N["sa3_r1_ok"], N["sa3_n"], "outputs/tables/roundtrip_sa3_package_grain.csv", "representation=R1_full, all_package_attributes_ok/package_records",
          "held-out package-version records"),
        c("sa4_c_tau_low", "Approach C answers disagreeing with approach A with the threshold 5 points lower",
          N["sa4"]["low"]["disagree"], N["sa4"]["low"]["answered"], "outputs/tables/matching_sa4_approach_c_threshold.csv",
          f"split=held_out, tau={N['sa4']['tau_low']}", "held-out, A unique"),
        c("sa4_c_tau_high", "Approach C answers disagreeing with approach A with the threshold 5 points higher",
          N["sa4"]["high"]["disagree"], N["sa4"]["high"]["answered"], "outputs/tables/matching_sa4_approach_c_threshold.csv",
          f"split=held_out, tau={N['sa4']['tau_high']}", "held-out, A unique"),
        c("versions_weighted", "Version-change share weighted by each group's number of multi-version labels (proportion)",
          N["v_weighted"], 1, res, "versions.sampling.any_change_weighted_by_group", "eligible labels listing two or more versions"),
        c("obsolete_but_marketed", "Package NDCs marked actively marketed in the current label but obsolete in RxNorm", N["obsolete_but_active"],
          N["pkg_status_total"], "outputs/dictionary/medication_dictionary.csv", "package_marketing_status=active and rxnorm_ndc_status=OBSOLETE",
          "package NDCs of current in-scope products"),
    ]
    ensure(EVIDENCE)
    out = {"run_id": run, "code_fingerprint": fp, "claims": L,
           "counts_kept_separate": {"candidate_set_ids": N["candidates"], "eligible_set_ids": N["eligible"],
                                    "documents": N["docs_total"], "product_version_records": N["prod_records"],
                                    "held_out_records": N["h_r1_n"], "held_out_set_ids": N["held_sets"],
                                    "development_set_ids": N["dev_sets"], "package_records": N["pkg_records"],
                                    "dailymed_label_files": N["retrieval"]["spl_current_xml"][2],
                                    "rxnav_responses_loaded": N["retrieval"]["rxnav"][2],
                                    "model_calls": 0, "validator_issues_offline": N["val_warn"] + N["val_errors"]}}
    (EVIDENCE / "claims.json").write_text(json.dumps(out, indent=1))
    return out


def _fig1():
    import csv
    with open(OUTPUTS / "figures" / "fig1_data.csv") as f:
        return [{**r, "preserved": int(r["preserved"]), "applicable": int(r["applicable"])} for r in csv.DictReader(f)]


def verified_results(cl: dict) -> str:
    ensure(HANDOFF)
    lines = ["# Verified results (private handoff)", "",
             "Only verified methods and measured results, each with its evidence path. Run "
             f"`{cl['run_id']}`, code fingerprint `{cl['code_fingerprint']}`.", "",
             "## Methods that ran", "",
             "- Retrieved current DailyMed prescription labels for six cardiometabolic ingredient groups and the preceding version for a hashed subset; RxNorm API release 05-Oct-2026 (outputs/source_manifest.json).",
             "- Parsed labels into a PostgreSQL 17 canonical layer with 13 passing build checks (outputs/checks/build_checks.json).",
             "- Wrote FHIR R4 Bundles plus a JSON-Schema-validated sidecar; validated with HL7 validator 7.0.0 offline (all) and against tx.fhir.org (sample of 60) (outputs/validation/summary.json).",
             "- Round trip against a separately written XML reader; held-out split frozen before tuning (docs/analysis_plan.md).",
             "- Compared four matching approaches and five comparison representations (outputs/tables/).", "",
             "## Measured results", ""]
    for c in cl["claims"]:
        val = f"{c['numerator']:,}" + (f" of {c['denominator']:,} ({100 * c['value']:.1f}%)" if c["denominator"] else "")
        lines.append(f"- {c['statement']}: {val}. Scope: {c['scope']}. Evidence: `{c['output_path']}` ({c['key']}).")
    text = "\n".join(lines) + "\n"
    (HANDOFF / "verified_results.md").write_text(text)
    return text


def write_evidence() -> dict:
    sm = source_manifest()
    cl = claims()
    verified_results(cl)
    return {"source_files": len(sm["files"]), "claims": len(cl["claims"])}
