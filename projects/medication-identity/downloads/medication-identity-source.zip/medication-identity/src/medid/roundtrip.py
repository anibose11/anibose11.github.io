"""Field-level round-trip comparison against a separate read of the source XML.

Statuses (docs/analysis_plan.md, section 8):
  preserved             exact text
  preserved_normalized  equal after the documented JSON decimal normalization
  converted_equivalent  equal only after a documented unit conversion
  omitted_in_sidecar    not carried by FHIR core, available in the sidecar
  unresolved            cannot be reconstructed without inference
  discordant            reconstructed, but different
  inapplicable          absent in the source
  not_evaluated         input could not be read
"""
from __future__ import annotations

from .exact_json import number

CRITICAL = ["K1_set_id", "K2_document_id", "K3_version", "K4_product_ndc", "K5_package_ndcs", "K6_form_code",
            "K7_active_count", "K8_unii", "K9_class_code", "K10_boss_unii", "K11_num_value", "K11_num_unit",
            "K12_den_value", "K12_den_unit", "K13_part_ndcs"]
OK = {"preserved", "preserved_normalized"}


def source_boss(a: dict) -> str | None:
    cls = a["class_code"]
    if cls == "ACTIB":
        return a["unii"]
    if cls == "ACTIM":
        m = sorted(set(x for x in a["moiety_uniis"] if x))
        return m[0] if len(m) == 1 else None
    if cls == "ACTIR":
        return a["reference_unii"]
    return None


def source_actives(src_prod: dict) -> list[dict]:
    rows = []
    for part in src_prod["parts"]:
        rows += part["active"]
    rows += src_prod["active"]
    return rows


def _status_text(src, rec, numeric=False):
    if src is None:
        return ("inapplicable", None) if rec is None else ("discordant", None)
    if rec is None:
        return "unresolved", None
    if rec == src:
        return "preserved", True if numeric else None
    if numeric:
        try:
            if number(src).text == rec:
                return "preserved_normalized", True
        except ValueError:
            pass
        from .quantity import same_value
        try:
            return "discordant", same_value(src, rec)
        except ValueError:
            return "discordant", False
    return "discordant", None


def align_by_unii(s_act: list[dict], r_act: list[dict]) -> list[dict]:
    """Reorder reconstructed actives to the source order by UNII (used when the two
    sides come from different documents, where ingredient order is not meaningful)."""
    pool = list(r_act)
    out = []
    for a in s_act:
        j = next((k for k, r in enumerate(pool) if r and r.get("unii") and r["unii"] == a["unii"]), None)
        out.append(pool.pop(j) if j is not None else None)
    leftovers = iter(pool)
    out = [x if x is not None else next(leftovers, None) for x in out]
    return out + list(leftovers)


def compare(src_doc: dict, src_prod: dict | None, rec_doc: dict | None, rec_prod: dict | None,
            representation: str, sidecar_available: bool = False, unii_alignment: bool = False) -> list[dict]:
    """One row per (attribute, item). sidecar_available marks values that a core-only
    reader lacks but the sidecar holds (status omitted_in_sidecar). unii_alignment
    matches ingredients by UNII instead of position."""
    rows = []

    def add(attr, item, status, s, r, value_equal=None):
        rows.append({"attribute": attr, "item": item, "status": status, "source_value": None if s is None else str(s),
                     "reconstructed_value": None if r is None else str(r), "value_equal": value_equal})

    missing_file = rec_doc is None
    if rec_doc is None:
        rec_doc = {"set_id": None, "document_id": None, "version_number": None}
    if rec_prod is None:
        # nothing reconstructed for this product: score every field at its own grain
        # (record-level once, ingredient-level once per source active ingredient)
        rec_prod = {"product_ndc": None, "form_code": None, "active": None, "package_ndcs": None, "part_ndcs": None}

    for attr, s, r in (("K1_set_id", src_doc["set_id"], rec_doc.get("set_id")),
                       ("K2_document_id", src_doc["document_id"], rec_doc.get("document_id")),
                       ("K3_version", src_doc["version_number"], rec_doc.get("version_number"))):
        st, _ = _status_text(s, r)
        if st == "unresolved" and sidecar_available and attr in ("K1_set_id", "K3_version"):
            st = "omitted_in_sidecar"
        if st == "discordant" and attr == "K2_document_id" and s and r and s.lower() == r.lower():
            st = "preserved_normalized"  # FHIR writes urn:uuid values in lowercase (R4 datatypes)
        add(attr, "", st, s, r)

    st, _ = _status_text(src_prod["product_ndc"], rec_prod.get("product_ndc"))
    add("K4_product_ndc", "", st, src_prod["product_ndc"], rec_prod.get("product_ndc"))

    s_p = sorted(src_prod["package_ndcs"])
    r_p = rec_prod.get("package_ndcs")
    r_p = None if r_p is None else sorted(x for x in r_p if x is not None)
    if not s_p:
        add("K5_package_ndcs", "", "inapplicable" if not r_p else "discordant", None, "|".join(r_p or []) or None)
    elif r_p is None:
        add("K5_package_ndcs", "", "unresolved", "|".join(s_p), None)
    else:
        add("K5_package_ndcs", "", "preserved" if s_p == r_p else "discordant", "|".join(s_p), "|".join(r_p))

    st, _ = _status_text(src_prod["form_code"], rec_prod.get("form_code"))
    if st == "unresolved" and rec_prod.get("form_code_converted"):
        st = rec_prod["form_code_converted"]
    add("K6_form_code", "", st, src_prod["form_code"], rec_prod.get("form_code"))

    s_act = source_actives(src_prod)
    r_act = rec_prod.get("active")
    n_rec = None if r_act is None else len(r_act)
    if r_act is not None and unii_alignment:
        r_act = align_by_unii(s_act, r_act)
    if r_act is None:
        add("K7_active_count", "", "unresolved", len(s_act), None)
    else:
        add("K7_active_count", "", "preserved" if n_rec == len(s_act) else "discordant", len(s_act), n_rec)

    for k, a in enumerate(s_act):
        item = str(k)
        r = (r_act[k] if r_act is not None and k < len(r_act) else None)
        if r is None:
            for attr in ("K8_unii", "K9_class_code", "K10_boss_unii", "K11_num_value", "K11_num_unit",
                         "K12_den_value", "K12_den_unit"):
                add(attr, item, "unresolved", None, None)
            continue
        st, _ = _status_text(a["unii"], r.get("unii"))
        add("K8_unii", item, st, a["unii"], r.get("unii"))
        if r.get("class_code") is None and r.get("boss_source") == "default_reading":
            add("K9_class_code", item, "omitted_in_sidecar" if sidecar_available else "unresolved", a["class_code"], None)
        else:
            st, _ = _status_text(a["class_code"], r.get("class_code"))
            if r.get("class_code_derived") and st == "preserved":
                st = "converted_equivalent"
            elif r.get("class_code_derived") and r.get("class_code") is None:
                st = "unresolved"
            add("K9_class_code", item, st, a["class_code"], r.get("class_code"))
        sb = source_boss(a)
        st, _ = _status_text(sb, r.get("boss_unii"))
        if r.get("boss_converted"):
            st = r["boss_converted"]
        add("K10_boss_unii", item, st, sb, r.get("boss_unii"))
        for attr, sk, rk, numeric in (("K11_num_value", "num_value", "num_value", True),
                                      ("K11_num_unit", "num_unit", "num_unit", False),
                                      ("K12_den_value", "den_value", "den_value", True),
                                      ("K12_den_unit", "den_unit", "den_unit", False)):
            sv, rv = a[sk], r.get(rk)
            st, eq = _status_text(sv, rv, numeric=numeric)
            conv = (r.get("converted") or {}).get(attr)
            if conv and st not in OK:
                st, eq = conv, True
            add(attr, item, st, sv, rv, eq)

    if missing_file:
        for r in rows:
            if r["status"] == "unresolved":
                r["status"] = "not_evaluated"
    if src_prod["parts"]:
        s_parts = [p["ndc"] for p in src_prod["parts"]]
        r_parts = rec_prod.get("part_ndcs")
        add("K13_part_ndcs", "", "unresolved" if r_parts is None else ("preserved" if r_parts == s_parts else "discordant"),
            "|".join(x or "" for x in s_parts), None if r_parts is None else "|".join(x or "" for x in r_parts))
    else:
        add("K13_part_ndcs", "", "inapplicable", None, None)
    return rows


PACKAGE_ATTRS = ["P1_package_ndc", "P2_product_ndc", "P3_package_form", "P4_qty_value", "P4_qty_unit",
                 "P5_marketing_status", "P6_marketing_start"]


def compare_packages(src_prod: dict, rec_prod: dict | None) -> list[dict]:
    """Sensitivity analysis 3: one record per NDC-bearing package of the product,
    matched to the reconstruction by package NDC text."""
    out = []
    pool = list((rec_prod or {}).get("packages") or [])
    for sp in src_prod.get("packages") or []:
        j = next((k for k, r in enumerate(pool) if r["ndc"] == sp["ndc"]), None)
        r = pool.pop(j) if j is not None else None
        rows = []
        for attr, sv, rk in (("P1_package_ndc", sp["ndc"], "ndc"), ("P2_product_ndc", src_prod["product_ndc"], "product_ndc"),
                             ("P3_package_form", sp["form_code"], "form_code"), ("P4_qty_value", sp["qty_value"], "qty_value"),
                             ("P4_qty_unit", sp["qty_unit"], "qty_unit"),
                             ("P5_marketing_status", sp["marketing_status"], "marketing_status"),
                             ("P6_marketing_start", sp["marketing_start"], "marketing_start")):
            st, _ = _status_text(sv, None if r is None else r.get(rk), numeric=(attr == "P4_qty_value"))
            rows.append({"attribute": attr, "status": st})
        out.append({"package_ndc": sp["ndc"], "rows": rows, "ok": record_ok(rows, PACKAGE_ATTRS)})
    return out


def record_ok(rows: list[dict], attributes=CRITICAL) -> bool:
    """All applicable critical attributes preserved (exact or documented JSON normalization)."""
    relevant = [r for r in rows if r["attribute"] in attributes and r["status"] != "inapplicable"]
    return bool(relevant) and all(r["status"] in OK for r in relevant)
