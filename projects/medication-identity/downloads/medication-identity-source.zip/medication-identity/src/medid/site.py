"""Static project page and full report under site/projects/medication-identity/.

Everything the pages need sits inside the slug directory, so the folder can be
dropped into a combined site at /projects/medication-identity/. No scripts,
no remote fonts, no external requests.
"""
from __future__ import annotations

import html
import json
import re
import shutil
import zipfile

import markdown

from .manuscript import TITLE, _long_date, render_md
from .numbers import fmt, pct
from .paths import DOCS, OUTPUTS, ROOT, SCHEMAS, ensure

SLUG = "medication-identity"
SITE = ROOT / "site" / "projects" / SLUG

CSS = """:root{--bg:#fbfaf7;--fg:#1d1d1b;--muted:#55544f;--rule:#d9d6cc;--accent:#1f5f8b;--plate:#f1efe8}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--fg);font:17px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
.skip{position:absolute;left:-999px;top:0;background:var(--fg);color:var(--bg);padding:8px 12px;z-index:2}
.skip:focus{left:8px;top:8px}
header.top{border-bottom:1px solid var(--rule)}
header.top .inner,main,footer .inner{max-width:980px;margin:0 auto;padding-left:16px;padding-right:16px}
header.top .inner{display:flex;flex-wrap:wrap;gap:4px 16px;align-items:baseline;justify-content:space-between;padding-top:14px;padding-bottom:14px}
header.top a{color:var(--fg);text-decoration:none;font-weight:600}
header.top nav a{font-weight:400;color:var(--muted);margin-left:14px}
header.top nav a:first-child{margin-left:0}
main{padding-top:28px;padding-bottom:72px}
h1{font-size:clamp(1.55rem,4vw,2.1rem);line-height:1.2;margin:.1em 0 .4em;letter-spacing:-.01em;max-width:30ch}
h2{font-size:1.3rem;line-height:1.3;margin:2.2em 0 .5em;max-width:40ch}
h3{font-size:1.05rem;margin:1.6em 0 .4em}
p,li{max-width:68ch}.lede{font-size:1.12rem;color:var(--fg)}.muted{color:var(--muted)}.small{font-size:.9rem}
a{color:var(--accent);text-underline-offset:2px}a:hover{text-decoration-thickness:2px}
a:focus-visible,summary:focus-visible,[tabindex]:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:2px}
figure{margin:1.6em 0;max-width:820px}figure img{width:100%;height:auto;display:block;border:1px solid var(--rule)}
img{max-width:100%;height:auto}picture{display:block;max-width:100%}
p a,li a,p code,li code,td code{overflow-wrap:anywhere;word-break:break-word}
figcaption{font-size:.92rem;color:var(--muted);margin-top:.5em;max-width:68ch}
.facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px 24px;margin:1.4em 0;max-width:900px}
.facts div{border-top:1px solid var(--rule);padding-top:8px}.facts b{display:block;font-size:1.35rem;font-weight:600}
.facts span{font-size:.9rem;color:var(--muted)}
.tablewrap{overflow-x:auto;max-width:100%;margin:1em 0}
table{border-collapse:collapse;font-size:.92rem;min-width:520px}th,td{border-bottom:1px solid var(--rule);padding:6px 10px;text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600}td.num,th.num{text-align:right;font-variant-numeric:tabular-nums}
code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:.88em;background:var(--plate);padding:1px 4px}
pre{background:var(--plate);padding:12px;overflow-x:auto;max-width:100%;font:13px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
pre code{background:none;padding:0;white-space:pre}
ul.files{padding-left:1.1em}ul.files li{margin:.3em 0}
footer{border-top:1px solid var(--rule);margin-top:48px}footer .inner{padding-top:16px;padding-bottom:32px;font-size:.88rem;color:var(--muted)}
.toc{border-left:2px solid var(--rule);padding-left:14px;margin:1.2em 0}.toc a{display:inline-block;margin:2px 0}
.report main{max-width:820px}.report table{min-width:0}
@media (max-width:640px){body{font-size:16px}header.top nav a{margin-left:10px}}
@media print{header.top nav,.skip{display:none}a{color:inherit}}
"""


def _picture(name: str, alt: str) -> str:
    return (f'<picture><source media="(max-width: 640px)" srcset="assets/{name}-narrow.svg">'
            f'<img src="assets/{name}.svg" alt="{html.escape(alt)}" width="760" loading="lazy"></picture>')


def _head(title: str, desc: str) -> str:
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(desc)}"><link rel="stylesheet" href="assets/style.css"></head>"""


def _top(current: str) -> str:
    links = [("index.html", "Project"), ("report.html", "Full report"), ("viewer-preserved.html", "Comparison viewer"),
             ("downloads/medication-identity-source.zip", "Source")]
    nav = "".join(f'<a href="{h}"{" aria-current=\"page\"" if h == current else ""}>{t}</a>' for h, t in links)
    return f"""<a class="skip" href="#content">Skip to content</a>
<header class="top"><div class="inner"><a href="index.html">Medication identity</a><nav aria-label="Project">{nav}</nav></div></header>"""


FOOT = """<footer><div class="inner">Animesh Bose, Norlowe Research. Drug-label and terminology data from the U.S. National Library of
Medicine (DailyMed, RxNorm API), retrieved 2026-10-07; no patient records. This product uses publicly available data from the U.S. National Library of
Medicine (NLM), National Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or
recommend this or any other product.</div></footer>"""


def _downloads(N: dict) -> list[tuple[str, str, str]]:
    d = SITE / "downloads"
    ensure(d)
    items = []
    with zipfile.ZipFile(d / "medication_dictionary.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(OUTPUTS / "dictionary" / "medication_dictionary.csv", "medication_dictionary.csv")
        zf.writestr("README.txt", (
            "Medication dictionary export (one row per package NDC in a current-version, in-scope product).\n"
            "Columns are defined in the section medication_dictionary.csv of docs/data_dictionary.md in the source archive. Values are as labeled in DailyMed SPL\n"
            "(retrieved 2026-10-07) with RxNorm API release 05-Oct-2026. review_reasons lists why a row may need a second look.\n"
            "This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of\n"
            "Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or\n"
            "recommend this or any other product. RxNorm content is shown as of the release named; it may not reflect current NLM data.\n"))
    items.append(("medication_dictionary.zip", "Medication dictionary (CSV in ZIP)",
                  f"One row per package NDC in each current label ({N['dict_rows']:,} rows for {N['ndc_distinct']:,} distinct package NDCs), with label provenance, attributes as labeled, RxNorm status, crosswalk results and review reasons."))
    for name, label, desc in [
        ("roundtrip_field_status.csv", "Round-trip field statuses (CSV)", "Representation x attribute x split counts by status, with applicable denominators."),
        ("roundtrip_record_outcomes.csv", "Round-trip record outcomes (CSV)", "Records with all critical attributes preserved, by representation and split, with exploratory intervals."),
        ("matching_outcomes.csv", "Matching outcomes (CSV)", "Approaches A, A2, B and C by split and outcome."),
        ("version_changes_by_set.csv", "Label version changes (CSV)", "One row per label with a retrieved preceding version."),
    ]:
        shutil.copy2(OUTPUTS / "tables" / name, d / name)
        items.append((name, label, desc))
    shutil.copy2(OUTPUTS / "workbook" / "medication_identity_results.xlsx", d / "medication_identity_results.xlsx")
    items.append(("medication_identity_results.xlsx", "Results workbook (Excel)", "Summary tables, per-label version changes and removed package NDCs, with a definitions sheet."))
    shutil.copy2(SCHEMAS / "medication_sidecar.schema.json", d / "medication_sidecar.schema.json")
    items.append(("medication_sidecar.schema.json", "Companion record schema (JSON Schema)", "The local schema every sidecar validates against."))
    with zipfile.ZipFile(d / "fhir_examples.zip", "w", zipfile.ZIP_DEFLATED) as zf:
        for doc in ("61bde692-38c6-42dc-aaac-503cc7e1d8f8", "965b6bd6-37d4-451e-8c41-4df16df442d1"):
            zf.write(OUTPUTS / "fhir" / "bundles" / f"{doc}.json", f"{doc}.bundle.json")
            zf.write(OUTPUTS / "fhir" / "sidecars" / f"{doc}.sidecar.json", f"{doc}.sidecar.json")
    items.append(("fhir_examples.zip", "FHIR examples (ZIP)", "The two Bundles and sidecars shown in the comparison viewer."))
    return items


def _alt1(fig: dict) -> str:
    return "Dot chart of fields preserved: " + "; ".join(
        f"{r['label']} {r['value']:.1f}%" + (f" exact, {r['value2']:.1f}% with conversion" if r['value2'] > r['value'] + 0.05 else "")
        for r in fig['fig1']) + "."


def _alt2(fig: dict) -> str:
    return "Stacked bars of matching outcomes: " + "; ".join(
        f"{r['label']}: {r['agree']:,} same RxCUI, {r['wrong']:,} different, {r['ambiguous']:,} several candidates, "
        f"{r['none']:,} no match or abstained" for r in fig['fig2']) + "."


def write_index(N: dict, fig: dict, files: list) -> None:
    rows = {r["representation"]: r for r in fig["fig1"]}
    dl = "".join(f'<li><a href="downloads/{f}">{html.escape(l)}</a> <span class="muted small">{html.escape(d)}</span></li>' for f, l, d in files)
    page = f"""{_head("Medication identity from labels to FHIR", "Which drug-label identity and strength details survive FHIR R4 and common shortcuts, measured on 1,475 DailyMed prescription labels.")}
<body>{_top("index.html")}<main id="content">
<p class="muted small">This research project uses public drug-label and terminology data and no patient records.</p>
<h1>What survives when drug labels are turned into FHIR medication records?</h1>
<p class="lede">Research teams and drug-dictionary maintainers copy product identity from DailyMed labels and RxNorm into analysis tables and HL7 FHIR (Fast Healthcare Interoperability Resources) records. I measured, field by field, which identity and strength details survive that conversion for {fmt(N['eligible'])} current prescription labels for selected cardiometabolic drugs, and what common shortcuts lose.</p>
<figure>{_picture("fig1_representations", _alt1(fig))}
<figcaption>Figure 1. Share of applicable identity and strength fields preserved, held-out records: {fmt(N['h_r1_n'])} product-version records from {fmt(N['h_r1_sets'])} labels; {fmt(N['h_rx_n'])} current-version records for RxCUI only and the DailyMed packaging service; {N['h_latest_n']} preceding-version records for the latest version only. Values are listed in the table below.</figcaption></figure>
<div class="tablewrap" tabindex="0" role="region" aria-label="Figure 1 data"><table><thead><tr><th scope="col">Representation</th><th scope="col" class="num">Applicable fields</th><th scope="col" class="num">Preserved exactly</th><th scope="col" class="num">Including documented conversion</th></tr></thead><tbody>
{''.join(f"<tr><th scope='row'>{html.escape(r['label'])}</th><td class='num'>{r['applicable']:,}</td><td class='num'>{r['value']:.1f}%</td><td class='num'>{r['value2']:.1f}%</td></tr>" for r in fig['fig1'])}
</tbody></table></div>

<div class="facts">
<div><b>{fmt(N['h_r1_ok'])} of {fmt(N['h_r1_n'])}</b><span>held-out records with every critical attribute reconstructed from FHIR plus a companion record</span></div>
<div><b>{p_(N['h_core_boss_disc'], N['h_core_boss_n'])}</b><span>of active ingredients read with the wrong strength basis from FHIR core alone ({fmt(N['h_core_boss_disc'])} of {fmt(N['h_core_boss_n'])})</span></div>
<div><b>{p_(N['ndc_naive_wrong'], N['ndc_distinct'])}</b><span>of package National Drug Codes (NDCs) changed by padding without the segment pattern ({fmt(N['ndc_naive_wrong'])} of {fmt(N['ndc_distinct'])})</span></div>
<div><b>{N['v_any']} of {N['v_pairs']}</b><span>sampled label version pairs that changed product identity</span></div>
</div>

<h2>The data</h2>
<p>The corpus is every current DailyMed human prescription label whose products contain metformin, a sodium-glucose cotransporter 2 (SGLT2) inhibitor (empagliflozin or dapagliflozin), a glucagon-like peptide-1 (GLP-1) receptor agonist (semaglutide or liraglutide), one of seven insulins, atorvastatin or lisinopril, including combination products. It holds {fmt(N['eligible'])} labels with {fmt(N['prod_current'])} products, plus the preceding version of {N['preceding_retrieved']} labels. RxNorm came from the public RxNorm API, release of {_long_date(N['rxnorm_release'])}. Every response was cached with its URL, time and SHA-256. Human regular, NPH (isophane) and 70/30 insulins sold without a prescription are filed as over-the-counter (OTC) labels and are outside this scope; {N['excluded_legacy']} labels in the 2006 to 2008 format had no structured product section.</p>

<h2>How it was measured</h2>
<p>Each label was parsed into a lossless PostgreSQL layer that keeps NDCs with their hyphens, decimal strengths as written, and the class code that says whether a strength refers to the ingredient or its active moiety. Each label version became a FHIR R4 Bundle of Medication resources plus a companion record (a sidecar validated by a JSON Schema) for what R4 has no element for. The official HL7 validator checked every Bundle. A reverse transform read the files back and a second, separately written XML reader gave the comparison values. I split labels into development (30%) and held-out (70%) sets before tuning, and froze the matching rules before evaluating held-out labels. Later correctness fixes to comparison code, the FHIR export and one parser rule required reruns of the affected stages. The analysis plan records each change; no matching rule changed.</p>

<h2>Representing the label without changing its meaning</h2>
<h3>FHIR elements left empty where the source value does not fit</h3>
<p>R4 Medication has a manufacturer element, but the labeler named in a Structured Product Labeling (SPL) document is often a repackager or distributor, and R4 states that the element is not meant for distributors. R4 also has a status element, but SPL marketing status describes Food and Drug Administration (FDA) listing and does not say whether a dictionary record is in use. Both elements were left empty in FHIR, and the source values were kept in the sidecar. The same rule kept the basis of strength out of FHIR core, because R4 Medication has no element for it. Read from FHIR core alone, {fmt(N['h_core_boss_disc'])} active ingredients took the wrong basis-of-strength substance; the sidecar records the basis explicitly.</p>
<h3>Comparison against a separate read of the source XML</h3>
<p>The round trip was checked against a second XML reader written with a different parser and no shared code. On development labels this found faults in the reverse transform and comparison code. A repeated-moiety error found later affected both readers and required a documented correction. I wrote both readers, so this is a software cross-check.</p>

<h2>What the comparison found</h2>
<figure>{_picture("fig2_matching", _alt2(fig))}
<figcaption>Figure 2. Name-based matching against the package-NDC crosswalk, held-out products with a unique crosswalk RxCUI (n = {fmt(N['h_a_unique'])}).</figcaption></figure>
<ul>
<li>The package-NDC crosswalk gave a unique RxNorm concept unique identifier (RxCUI) for {p_(N['h_a_unique'], N['h_products'])} of held-out products; for the rest, RxNorm lists none of the product's NDCs as active, mostly for repackaged products. DailyMed's own set-level mapping agreed with it in {fmt(N['h_a2_agree'])} of {fmt(N['h_a2_agree'] + N['h_a2_disagree'])} checkable cases.</li>
<li>Matching normalized names plus strength, form, fill volume and brand agreed with the crosswalk for {p_(N['h_b_agree'], N['h_b_answered'])} of its answers. Approximate name matching disagreed with the crosswalk for {N['h_c_wrong']} of its {N['h_c_answered']} answers ({p_(N['h_c_wrong'], N['h_c_answered'])}).</li>
<li>DailyMed's packaging service lists every strength in a label against every product of that label: {fmt(N['h_api_count_disc'])} of {fmt(N['h_api_count_n'])} held-out products got the wrong ingredient count.</li>
<li>Insulin strengths are coded in three Unified Code for Units of Measure (UCUM) units across labels ([iU], U and [arb'U]). The validator accepted [iU] and U, the sampled terminology check contained no [arb'U] codes, and UCUM defines U as the unit of catalytic activity.</li>
</ul>
<p>Two worked cases show the detail: a <a href="viewer-preserved.html">combination tablet preserved in full</a> and an <a href="viewer-ambiguous.html">insulin pen that neither name-based approach matched to the crosswalk concept</a>.</p>

<h2>Limits</h2>
<p>The study covers six ingredient groups at one retrieval date, with one preceding version per label for {N['preceding_retrieved']} sampled labels, and RxNorm only as its current release plus the dated NDC history it publishes. The crosswalk is a terminology reference with its own errors. The companion record was designed to hold what the round trip measures, so its complete preservation is partly by construction; the informative numbers are the losses without it. None of this speaks to the clinical correctness of any label.</p>

<h2>Reproduce the analysis</h2>
<pre tabindex="0" role="region" aria-label="Reproduction commands"><code>unzip medication-identity-source.zip && cd medication-identity
python3 -m venv .venv && .venv/bin/pip install --require-hashes -r requirements.lock && .venv/bin/pip install --no-deps -e .
.venv/bin/medid demo          # offline, about a minute, fixture labels only
.venv/bin/medid scope && .venv/bin/medid acquire && .venv/bin/medid pipeline   # full study</code></pre>
<p class="small muted">Needs Python 3.11 or later, PostgreSQL 16 or 17 server binaries on PATH (the pipeline runs its own cluster), and Java 17 or later with the HL7 validator jar (see the README's validator section). The full run downloads about {N['raw_mb']} MB from DailyMed and RxNav.</p>

<h2>Files</h2>
<ul class="files"><li><a href="report.html">Full report</a> <span class="muted small">Methods, results and references.</span></li>
<li><a href="downloads/medication-identity-source.zip">Source archive (ZIP)</a> <span class="muted small">Code, SQL, schemas, configuration, tests, demo fixture, documentation and results tables.</span></li>
{dl}</ul>
</main>{FOOT}</body></html>"""
    (SITE / "index.html").write_text(page)


def p_(n, d):
    return pct(n, d)


def _md_table(path, cols=None, limit=None, label=None) -> str:
    import pandas as pd
    df = pd.read_csv(path)
    if cols:
        df = df[cols]
    if limit:
        df = df.head(limit)
    head = "".join(f'<th scope="col">{html.escape(str(c))}</th>' for c in df.columns)
    body = "".join("<tr>" + "".join(f"<td>{html.escape('' if (isinstance(v, float) and v != v) else str(v))}</td>" for v in r) + "</tr>"
                   for r in df.itertuples(index=False))
    return f'<div class="tablewrap" tabindex="0" role="region" aria-label="{html.escape(label or path.name)}"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'


def write_report(N: dict, fig: dict) -> None:
    md, _ = render_md(N, fig, "public", fig_prefix="assets/")
    body = markdown.markdown(md, extensions=["tables", "toc"])
    body = body.replace(" These do not constitute external funding.", "")
    body = body.replace('<img alt="Figure 1" src="assets/fig1_representations.svg" />', _picture("fig1_representations", _alt1(fig)))
    body = body.replace('<img alt="Figure 2" src="assets/fig2_matching.svg" />', _picture("fig2_matching", _alt2(fig)))
    body = re.sub(r"(<p><strong>(Table \d+)\.</strong>.*?</p>\s*)<table>",
                  lambda m: m.group(1) + f'<div class="tablewrap" tabindex="0" role="region" aria-label="{m.group(2)}"><table>',
                  body, flags=re.S)
    body = body.replace("</table>", "</table></div>").replace("<th>", '<th scope="col">').replace('<th style=', '<th scope="col" style=')
    body = re.sub(r"(https?://[^\s<]+?)([.,;)]?)(?=[\s<])", lambda m: f'<a href="{m.group(1)}">{m.group(1)}</a>{m.group(2)}', body)
    amend = (DOCS / "analysis_plan.md").read_text()
    amend = amend[amend.index("## Development phase and freeze record"):]
    rules = (ROOT / "config" / "normalization.toml").read_text()
    sup = f"""
<h2 id="supplements">Appendices</h2>
<h3 id="s1">Appendix 1. Development phase, freeze record and amendments</h3>
{markdown.markdown(amend.replace("## ", "#### "))}
<h3 id="s2">Appendix 2. Field-level round-trip statuses, all representations and splits</h3>
<p class="small muted">Counts of fields by status. "applicable" excludes inapplicable and not-evaluated fields.</p>
{_md_table(OUTPUTS / "tables" / "roundtrip_field_status.csv", label="Appendix 2 field-level round-trip statuses")}
<h3 id="s3">Appendix 3. Matching outcomes by split</h3>
{_md_table(OUTPUTS / "tables" / "matching_outcomes.csv", label="Appendix 3 matching outcomes")}
<h3 id="s4">Appendix 4. Package NDC padding by segment pattern</h3>
{_md_table(OUTPUTS / "tables" / "shortcut_ndc_padding.csv", label="Appendix 4 NDC padding")}
<h3 id="s5">Appendix 5. Package NDCs removed between versions and their current RxNorm status</h3>
{_md_table(OUTPUTS / "tables" / "version_removed_package_ndcs_rxnorm.csv", label="Appendix 5 removed package NDCs")}
<h3 id="s6">Appendix 6. Validation summary</h3>
<p>Validator 7.0.0 (SHA-256 <code>{N['validator_sha']}</code>) on {N['java']}. Offline run: {fmt(N['val_files'])} Bundles, {N['val_errors']} errors, {fmt(N['val_warn'])} warnings. Terminology sample: {N['tx_files']} Bundles, {N['tx_errors']} errors (all NDC codes unknown to the server's 2021-11-01 NDC content).</p>
<h3 id="s7">Appendix 7. Approach B normalization rules (frozen)</h3>
<pre tabindex="0" role="region" aria-label="Approach B normalization rules"><code>{html.escape(rules)}</code></pre>
<h3 id="s8">Appendix 8. Literature search and original planning comparison</h3>
<p>Forty-five recorded searches in PubMed and Europe PMC on 2026-10-07; the five closest items and the reasons for each inclusion are in <code>docs/prior_art.csv</code> and <code>docs/literature_search.md</code> of the source archive.</p>
{_md_table(DOCS / "prior_art.csv", cols=["rank", "verified_citation", "overlap_with_this_project", "what_this_project_adds"], label="Appendix 8 closest prior work")}
<h3 id="s9">Appendix 9. Data and run provenance</h3>
<p>Labels retrieved {N['retrieval']['spl_current_xml'][0]} to {N['retrieval']['spl_current_xml'][1]} UTC ({fmt(N['retrieval']['spl_current_xml'][2])} files); preceding versions {N['retrieval']['spl_version_zip'][0]} to {N['retrieval']['spl_version_zip'][1]} UTC; RxNorm API {N['retrieval']['rxnav'][0]} to {N['retrieval']['rxnav'][1]} UTC ({fmt(N['retrieval']['rxnav'][2])} responses, release {N['rxnorm_release']}, API {N['rxnav_api']}). DailyMed SPL-to-RxNorm mapping file: {fmt(N['mapping_file_bytes'])} bytes, SHA-256 <code>{N['mapping_file_sha']}</code>. Every file is listed with its URL, time, size and SHA-256 in <code>outputs/source_manifest.json</code> of the source archive.</p>
"""
    toc = """<nav class="toc" aria-label="Contents"><a href="#abstract">Abstract</a> | <a href="#materials-and-methods">Methods</a> | <a href="#results">Results</a> | <a href="#discussion">Discussion</a> | <a href="#references">References</a> | <a href="#supplements">Appendices</a></nav>"""
    body = body.replace("<h2", toc + "<h2", 1)
    page = f"""{_head("Medication identity: full report", TITLE)}<body class="report">{_top("report.html")}<main id="content">{body}{sup}</main>{FOOT}</body></html>"""
    (SITE / "report.html").write_text(page)


def write_site(N: dict, fig: dict) -> dict:
    if SITE.exists():
        keep = SITE / "downloads" / "medication-identity-source.zip"
        tmp = None
        if keep.exists():
            tmp = ROOT / ".local" / "source-zip.keep"
            shutil.copy2(keep, tmp)
        shutil.rmtree(SITE)
        ensure(SITE / "downloads")
        if tmp:
            shutil.copy2(tmp, keep)
    ensure(SITE / "assets", SITE / "downloads")
    (SITE / "assets" / "style.css").write_text(CSS)
    for f in ("fig1_representations", "fig2_matching"):
        for suffix in ("", "-narrow"):
            shutil.copy2(OUTPUTS / "figures" / f"{f}{suffix}.svg", SITE / "assets" / f"{f}{suffix}.svg")
    files = _downloads(N)
    write_index(N, fig, files)
    write_report(N, fig)
    for name in ("viewer-preserved.html", "viewer-ambiguous.html"):
        v = (OUTPUTS / "viewer" / name).read_text()
        v = v.replace("<style>", '<link rel="stylesheet" href="assets/style.css"><style>', 1)
        other = ("viewer-ambiguous.html", "insulin pen with ambiguous name matching") if name == "viewer-preserved.html" else \
            ("viewer-preserved.html", "combination tablet preserved in full")
        v = v.replace("<body><main>", f'<body>{_top(name)}<main id="content">', 1)
        v = v.replace("</main></body>", f'<p class="muted">Other case: <a href="{other[0]}">{other[1]}</a>.</p></main>{FOOT}</body>', 1)
        (SITE / name).write_text(v)
    return {"pages": sorted(p.name for p in SITE.glob("*.html")), "downloads": [f for f, _, _ in files]}
