"""Analysis stage: outcome tables and headline numbers.

Writes outputs/tables/*.csv and outputs/analysis/results.json. Every headline
number is stored with its numerator, denominator, scope and source table so
that evidence/claims.json can point at it. Proportions describe this finite
corpus; cluster-bootstrap intervals (resampling SPL set IDs) are exploratory.
"""
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict

import numpy as np
import pandas as pd

from . import db
from .corpus import config, manifest
from .paths import OUTPUTS, ensure
from .roundtrip import CRITICAL

TABLES = OUTPUTS / "tables"
REPS = ["R1_full", "R_core", "S_rx", "S_flat", "S_api", "S_latest"]
STATUSES = ["preserved", "preserved_normalized", "converted_equivalent", "omitted_in_sidecar", "unresolved",
            "discordant", "inapplicable", "not_evaluated"]


def prop(num: int, den: int) -> dict:
    return {"numerator": int(num), "denominator": int(den), "proportion": (num / den) if den else None}


def cluster_bootstrap(df: pd.DataFrame, col: str, reps: int, seed: int) -> tuple[float, float] | None:
    if df.empty:
        return None
    g = df.groupby("set_id")[col].agg(["sum", "count"])
    sums, counts = g["sum"].to_numpy(float), g["count"].to_numpy(float)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(g), size=(reps, len(g)))
    est = sums[idx].sum(1) / counts[idx].sum(1)
    lo, hi = np.percentile(est, [2.5, 97.5])
    return float(lo), float(hi)


def write_csv(name: str, rows: list[dict] | pd.DataFrame) -> None:
    ensure(TABLES)
    if isinstance(rows, pd.DataFrame):
        rows.to_csv(TABLES / name, index=False)
        return
    if not rows:
        (TABLES / name).write_text("")
        return
    with open(TABLES / name, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def q(conn, sql, params=None) -> pd.DataFrame:
    cur = conn.execute(sql, params or ())
    cols = [c.name for c in cur.description]
    return pd.DataFrame(cur.fetchall(), columns=cols)


# --- corpus -----------------------------------------------------------------------

def corpus_section(conn, R: dict) -> None:
    m = manifest()
    labels = m["labels"]
    status = Counter((e["status"], e.get("reason") if e["status"] != "eligible" else "") for e in labels)
    write_csv("corpus_label_eligibility.csv", [{"status": s, "reason": r or "", "set_ids": n} for (s, r), n in sorted(status.items())])
    elig = [e for e in labels if e["status"] == "eligible"]
    pv = m["preceding_versions"]
    R["corpus"] = {
        "candidate_set_ids": len(labels),
        "eligible_set_ids": len(elig),
        "excluded_set_ids": sum(1 for e in labels if e["status"] == "excluded"),
        "not_retrieved_set_ids": sum(1 for e in labels if e["status"] == "not_retrieved"),
        "version_subset_set_ids": len(m["version_subset"]),
        "preceding_versions_retrieved": sum(1 for p in pv if p["preceding_version"] is not None),
        "preceding_versions_not_archived_attempts": sum(1 for p in pv for a in p["attempts"] if a["result"] == "not_archived"),
        "preceding_versions_none_available": sum(1 for p in pv if p["preceding_version"] is None),
    }
    d = q(conn, """select version_kind, split, count(*) documents, count(distinct set_id) set_ids
                   from medid.spl_document group by 1,2 order by 1,2""")
    write_csv("corpus_documents.csv", d)
    pr = q(conn, """select d.version_kind, d.split, d.primary_group, count(*) filter (where p.in_scope) products_in_scope,
                           count(*) filter (where not p.in_scope) products_out_of_scope,
                           count(*) filter (where p.in_scope and p.is_kit) kits,
                           count(*) filter (where p.in_scope and p.equivalent_ndc is not null) repackaged
                    from medid.spl_product p join medid.spl_document d using (document_id) group by 1,2,3 order by 1,2,3""")
    write_csv("corpus_products_by_group.csv", pr)
    act = q(conn, """select p.product_key, d.version_kind, d.split, count(*) filter (where i.is_active) actives
                     from medid.spl_product p join medid.spl_document d using (document_id)
                     join medid.spl_ingredient i using (product_key) where p.in_scope group by 1,2,3""")
    cat = q(conn, """select coalesce(p.marketing_category_display, '(none stated)') category, d.version_kind,
                            count(*) products from medid.spl_product p join medid.spl_document d using (document_id)
                     where p.in_scope group by 1,2 order by 3 desc""")
    write_csv("corpus_marketing_category.csv", cat)
    cls = q(conn, """select coalesce(i.class_code,'(none)') class_code, d.version_kind, count(*) active_ingredients
                     from medid.spl_ingredient i join medid.spl_product p using (product_key)
                     join medid.spl_document d using (document_id) where p.in_scope and i.is_active group by 1,2 order by 3 desc""")
    write_csv("corpus_basis_of_strength.csv", cls)
    pk = q(conn, """select coalesce(k.ndc_configuration, case when k.ndc_original is null then '(no NDC)' else '(unrecognized)' end) cfg,
                           d.version_kind, count(*) packages
                    from medid.spl_package k join medid.spl_product p using (product_key)
                    join medid.spl_document d using (document_id) where p.in_scope group by 1,2 order by 3 desc""")
    write_csv("corpus_package_ndc_patterns.csv", pk)
    from .corpus import iter_documents
    rep = Counter()
    for doc, meta in iter_documents():
        for i in meta["products_in_scope"]:
            prod = doc.products[i]
            ings = prod.active_ingredients() + [x for part in prod.parts for x in part.ingredients if x.is_active]
            rep[meta["split"]] += sum(1 for x in ings if x.moiety_repeated)
    R["corpus"]["active_records_moiety_listed_twice"] = dict(rep)
    cur = act[act.version_kind == "current"]
    R["corpus"].update({
        "documents_current": int(d[d.version_kind == "current"].documents.sum()),
        "documents_preceding": int(d[d.version_kind == "preceding"].documents.sum()),
        "product_records_in_scope": int(pr.products_in_scope.sum()),
        "product_records_in_scope_current": int(pr[pr.version_kind == "current"].products_in_scope.sum()),
        "product_records_in_scope_preceding": int(pr[pr.version_kind == "preceding"].products_in_scope.sum()),
        "products_out_of_scope_in_eligible_labels": int(pr.products_out_of_scope.sum()),
        "kit_product_records": int(pr.kits.sum()),
        "repackaged_product_records": int(pr.repackaged.sum()),
        "combination_product_records_current": int((cur.actives >= 2).sum()),
        "active_ingredient_records": int(cls.active_ingredients.sum()),
        "active_ingredient_records_by_class": {r.class_code: int(r.active_ingredients) for r in
                                               cls.groupby("class_code", as_index=False).active_ingredients.sum().itertuples()},
        "package_records": int(pk.packages.sum()),
        "package_ndc_patterns": {r.cfg: int(r.packages) for r in pk.groupby("cfg", as_index=False).packages.sum().itertuples()},
        "development_set_ids": int(d[(d.version_kind == "current") & (d.split == "development")].set_ids.sum()),
        "held_out_set_ids": int(d[(d.version_kind == "current") & (d.split == "held_out")].set_ids.sum()),
    })


# --- matching ------------------------------------------------------------------------

def matching_section(conn, R: dict) -> None:
    mr = q(conn, """select m.product_key, m.approach, m.outcome, m.rxcui, d.split, d.set_id, d.primary_group,
                           c.scd_rxcui, c.tty
                    from medid.match_result m join medid.spl_product p using (product_key)
                    join medid.spl_document d using (document_id) left join medid.rx_concept c on c.rxcui = m.rxcui""")
    outc, rxv, scdv, ttyv = {}, {}, {}, {}
    meta = {}
    for r in mr.itertuples():
        outc[(r.product_key, r.approach)] = r.outcome
        rxv[(r.product_key, r.approach)] = r.rxcui if isinstance(r.rxcui, str) else None
        scdv[(r.product_key, r.approach)] = r.scd_rxcui if isinstance(r.scd_rxcui, str) else None
        ttyv[(r.product_key, r.approach)] = r.tty if isinstance(r.tty, str) else None
        meta[r.product_key] = (r.split, r.set_id, r.primary_group)
    keys = sorted(meta)
    rows = []
    for split in ("development", "held_out", "all"):
        sub = [k for k in keys if split == "all" or meta[k][0] == split]
        for ap in ("A", "A2", "B", "C"):
            c = Counter(outc.get((k, ap)) for k in sub)
            for o, n in sorted(c.items(), key=lambda kv: str(kv[0])):
                rows.append({"split": split, "approach": ap, "outcome": o, "products": n, "of": len(sub)})
    write_csv("matching_outcomes.csv", rows)

    def clinical(k, ap):
        r = rxv.get((k, ap))
        if r is None:
            return None
        return scdv.get((k, ap)) if ttyv.get((k, ap)) == "SBD" and scdv.get((k, ap)) else r

    agree, res = [], {}
    for split in ("development", "held_out", "all"):
        sub = [k for k in keys if split == "all" or meta[k][0] == split]
        a_unique = [k for k in sub if outc.get((k, "A")) == "unique"]
        for ap in ("B", "C"):
            answered = [k for k in a_unique if outc.get((k, ap)) == "unique"]
            exact = sum(1 for k in answered if rxv.get((k, ap)) == rxv.get((k, "A")))
            clin = sum(1 for k in answered if clinical(k, ap) is not None and clinical(k, ap) == clinical(k, "A"))
            not_ans = Counter(outc.get((k, ap)) for k in a_unique if outc.get((k, ap)) != "unique")
            agree.append({"split": split, "approach": ap, "a_unique": len(a_unique), "answered": len(answered),
                          "agree_exact_rxcui": exact, "agree_clinical_drug": clin, "disagree": len(answered) - exact,
                          "not_answered": len(a_unique) - len(answered), "not_answered_by_outcome": dict(not_ans)})
            res[f"{ap}_{split}"] = {"answered": prop(len(answered), len(a_unique)), "agree_exact": prop(exact, len(answered)),
                                    "agree_exact_of_a_unique": prop(exact, len(a_unique)),
                                    "agree_clinical": prop(clin, len(answered)), "wrong": prop(len(answered) - exact, len(answered)),
                                    "not_answered_by_outcome": dict(not_ans)}
        a2 = Counter(outc.get((k, "A2")) for k in sub)
        res[f"A2_{split}"] = {"agree": prop(a2.get("agree", 0), a2.get("agree", 0) + a2.get("disagree", 0)),
                              "not_in_mapping_file": prop(a2.get("not_in_mapping_file", 0), len(sub)),
                              "not_in_mapping_file_labels": len({meta[k][1] for k in sub if outc.get((k, "A2")) == "not_in_mapping_file"}),
                              "counts": dict(a2)}
        aout = Counter(outc.get((k, "A")) for k in sub)
        res[f"A_{split}"] = {o: prop(v, len(sub)) for o, v in aout.items()}
    write_csv("matching_agreement_with_A.csv", agree)
    R["matching"] = res
    # C without abstention (top candidate always taken), for context
    top1 = q(conn, """select d.split, count(*) n, count(*) filter (where (c.detail->>'top_rxcui') = a.rxcui) agree
                      from medid.match_result a join medid.match_result c on c.product_key=a.product_key and c.approach='C'
                      join medid.spl_product p on p.product_key=a.product_key join medid.spl_document d using (document_id)
                      where a.approach='A' and a.outcome='unique' group by 1""")
    res["C_top1_no_abstention"] = {r.split: prop(int(r.agree), int(r.n)) for r in top1.itertuples()}
    # SA4: approach C with tau moved 5 points down and up (delta unchanged), from the stored top-two scores
    from .matching import rules
    ap = rules()["approx"]
    cdet = q(conn, """select c.product_key, d.split, a.rxcui a_rxcui, c.detail->>'top_rxcui' top_rxcui,
                             (c.detail->>'s1')::float s1, (c.detail->>'s2')::float s2
                      from medid.match_result a join medid.match_result c on c.product_key=a.product_key and c.approach='C'
                      join medid.spl_product p on p.product_key=a.product_key join medid.spl_document d using (document_id)
                      where a.approach='A' and a.outcome='unique'""")
    sa4 = []
    for split in ("held_out", "development"):
        sub = cdet[cdet.split == split]
        for tau in (ap["tau"] - 5, ap["tau"], ap["tau"] + 5):
            ans = sub[sub.top_rxcui.notna() & (sub.s1 >= tau) & ((sub.s1 - sub.s2.fillna(0)) >= ap["delta"])]
            agree_n = int((ans.top_rxcui == ans.a_rxcui).sum())
            sa4.append({"split": split, "tau": tau, "delta": ap["delta"], "a_unique": len(sub), "answered": len(ans),
                        "agree": agree_n, "disagree": len(ans) - agree_n})
    write_csv("matching_sa4_approach_c_threshold.csv", sa4)
    res["SA4_C_threshold"] = sa4
    # package level A vs B
    pk = json.loads((OUTPUTS / "matching" / "package_level_ab.json").read_text())
    rows = []
    for split in ("development", "held_out", "all"):
        sub = [r for r in pk if split == "all" or r["split"] == split]
        with_a = [r for r in sub if r["a_rxcui"]]
        b_ans = [r for r in with_a if r["b_outcome"] == "unique"]
        rows.append({"split": split, "packages": len(sub), "a_active": len(with_a), "b_unique": len(b_ans),
                     "b_agree": sum(1 for r in b_ans if r["b_rxcui"] == r["a_rxcui"]),
                     "b_ambiguous": sum(1 for r in with_a if r["b_outcome"] == "ambiguous"),
                     "b_none": sum(1 for r in with_a if r["b_outcome"] == "none")})
    write_csv("matching_package_level_A_B.csv", rows)
    R["matching"]["package_level"] = rows
    # A at package level vs product level: injectables with package-dependent RxCUIs
    amb = q(conn, """select p.form_display, count(*) products from medid.match_result m join medid.spl_product p using (product_key)
                     where m.approach='A' and m.outcome='ambiguous' group by 1 order by 2 desc""")
    write_csv("matching_A_ambiguous_by_form.csv", amb)


# --- round trip -----------------------------------------------------------------------

def roundtrip_section(conn, R: dict) -> None:
    cfg = config()["study"]
    rec = pd.read_csv(OUTPUTS / "roundtrip" / "records.csv")
    for c in ("all_critical_ok", "identity_ok", "is_kit", "equivalent_source"):
        rec[c] = rec[c].astype(str).str.lower().eq("true")
    out = {}
    rows = []
    for rep in REPS:
        for split in ("held_out", "development", "all"):
            sub = rec[(rec.representation == rep) & ((rec.split == split) | (split == "all"))]
            if sub.empty:
                continue
            ci = cluster_bootstrap(sub.assign(ok=sub.all_critical_ok.astype(int)), "ok", cfg["bootstrap_replicates"], cfg["bootstrap_seed"])
            ci2 = cluster_bootstrap(sub.assign(ok=sub.identity_ok.astype(int)), "ok", cfg["bootstrap_replicates"], cfg["bootstrap_seed"])
            row = {"representation": rep, "split": split, "records": len(sub), "set_ids": sub.set_id.nunique(),
                   "all_critical_ok": int(sub.all_critical_ok.sum()), "identity_ok": int(sub.identity_ok.sum()),
                   "all_critical_ok_ci_low": ci[0] if ci else None, "all_critical_ok_ci_high": ci[1] if ci else None,
                   "identity_ok_ci_low": ci2[0] if ci2 else None, "identity_ok_ci_high": ci2[1] if ci2 else None}
            rows.append(row)
            out[f"{rep}_{split}"] = {"all_critical": prop(row["all_critical_ok"], row["records"]),
                                     "identity_attributes": prop(row["identity_ok"], row["records"]),
                                     "ci95_all_critical": ci, "ci95_identity": ci2, "set_ids": row["set_ids"]}
    write_csv("roundtrip_record_outcomes.csv", rows)
    # sensitivity: full corpus, excluding repackaged, by version kind
    sens = []
    base = rec[rec.representation == "R1_full"]
    for label, sub in (("SA1 full corpus", base),
                       ("SA2 held-out excluding repackaged products", base[(base.split == "held_out") & (~base.equivalent_source)]),
                       ("held-out current versions", base[(base.split == "held_out") & (base.version_kind == "current")]),
                       ("held-out preceding versions", base[(base.split == "held_out") & (base.version_kind == "preceding")]),
                       ("held-out kits", base[(base.split == "held_out") & (base.is_kit)]),
                       ("held-out combination products", base[(base.split == "held_out") & (base.active_count >= 2)])):
        sens.append({"analysis": label, "records": len(sub), "all_critical_ok": int(sub.all_critical_ok.sum())})
    write_csv("roundtrip_sensitivity.csv", sens)
    out["sensitivity"] = sens
    # SA3: package-level attributes at package-version grain
    pkr = pd.read_csv(OUTPUTS / "roundtrip" / "package_records.csv", dtype=str, keep_default_na=False)
    pkr["ok"] = pkr.all_package_ok.str.lower().eq("true")
    pattrs = [c for c in pkr.columns if c[:2] in ("P1", "P2", "P3", "P4", "P5", "P6")]
    sa3 = []
    for rep in ("R1_full", "R_core"):
        sub = pkr[(pkr.representation == rep) & (pkr.split == "held_out")]
        row = {"representation": rep, "package_records": len(sub), "products": sub.product_key.nunique(),
               "set_ids": sub.set_id.nunique(), "all_package_attributes_ok": int(sub.ok.sum())}
        for a in pattrs:
            app = sub[~sub[a].isin(["inapplicable", "not_evaluated"])]
            row[f"{a}_preserved"] = int(app[a].isin(["preserved", "preserved_normalized"]).sum())
            row[f"{a}_applicable"] = len(app)
        sa3.append(row)
    write_csv("roundtrip_sa3_package_grain.csv", sa3)
    out["SA3_package_grain"] = sa3
    # field-level status table
    f = q(conn, """select r.representation, r.attribute, d.split, r.status, count(*) n
                   from medid.roundtrip_field r join medid.spl_product p using (product_key)
                   join medid.spl_document d using (document_id) group by 1,2,3,4""")
    piv = []
    for (rep, attr, split), g in f.groupby(["representation", "attribute", "split"]):
        row = {"representation": rep, "attribute": attr, "split": split}
        for st in STATUSES:
            row[st] = int(g[g.status == st].n.sum())
        row["applicable"] = sum(row[s] for s in STATUSES if s not in ("inapplicable", "not_evaluated"))
        piv.append(row)
    piv.sort(key=lambda r: (REPS.index(r["representation"]) if r["representation"] in REPS else 9,
                            CRITICAL.index(r["attribute"]) if r["attribute"] in CRITICAL else 99, r["split"]))
    write_csv("roundtrip_field_status.csv", piv)
    out["field_status_held_out"] = [r for r in piv if r["split"] == "held_out"]
    # failures of the reversible representation, for inspection
    fails = q(conn, """select r.product_key, r.attribute, r.item, r.status, r.source_value, r.reconstructed_value, d.split
                       from medid.roundtrip_field r join medid.spl_product p using (product_key)
                       join medid.spl_document d using (document_id)
                       where r.representation='R1_full' and r.status not in ('preserved','preserved_normalized','inapplicable')
                       order by 1,2""")
    write_csv("roundtrip_R1_non_preserved_fields.csv", fails)
    out["R1_non_preserved_fields"] = len(fails)
    norm = q(conn, """select attribute, count(*) n from medid.roundtrip_field where representation='R1_full'
                      and status='preserved_normalized' group by 1""")
    out["R1_normalized_fields"] = {r.attribute: int(r.n) for r in norm.itertuples()}
    R["roundtrip"] = out


# --- shortcut specifics ----------------------------------------------------------------

def shortcut_section(conn, R: dict) -> None:
    out = {}
    pk = q(conn, """select k.ndc_original, k.ndc_configuration, k.ndc11, k.ndc11_naive, d.version_kind, d.split
                    from medid.spl_package k join medid.spl_product p using (product_key)
                    join medid.spl_document d using (document_id)
                    where p.in_scope and k.ndc_original is not null and k.ndc11 is not null""")
    cur = pk[pk.version_kind == "current"].drop_duplicates("ndc_original")
    rows = []
    for cfg_, g in cur.groupby("ndc_configuration"):
        rows.append({"configuration": cfg_, "package_ndcs": len(g), "naive_equals_correct": int((g.ndc11 == g.ndc11_naive).sum())})
    write_csv("shortcut_ndc_padding.csv", rows)
    wrong = cur[cur.ndc11 != cur.ndc11_naive]
    known = set(q(conn, "select ndc11 from medid.rx_ndc_status where status <> 'UNKNOWN'").ndc11)
    corpus11 = set(cur.ndc11)
    collide_corpus = int(wrong.ndc11_naive.isin(corpus11).sum())
    out["ndc_padding"] = {"packages": len(cur), "naive_wrong": prop(len(wrong), len(cur)),
                          "naive_collides_with_another_corpus_ndc": collide_corpus,
                          "by_configuration": rows}
    f = q(conn, """select attribute, status, value_equal, count(*) n from medid.roundtrip_field
                   where representation='S_flat' and attribute in ('K11_num_value','K12_den_value') group by 1,2,3""")
    out["float_text"] = [{"attribute": r.attribute, "status": r.status, "value_equal": r.value_equal, "n": int(r.n)} for r in f.itertuples()]
    api = q(conn, """select attribute, status, count(*) n from medid.roundtrip_field where representation='S_api'
                     and attribute in ('K7_active_count','K11_num_value','K12_den_value','K4_product_ndc','K5_package_ndcs') group by 1,2""")
    out["packaging_api"] = [{"attribute": r.attribute, "status": r.status, "n": int(r.n)} for r in api.itertuples()]
    rxs = q(conn, """select attribute, status, count(*) n from medid.roundtrip_field where representation='S_rx'
                     and attribute in ('K7_active_count','K9_class_code','K10_boss_unii','K11_num_value','K12_den_value') group by 1,2""")
    out["rxcui_only"] = [{"attribute": r.attribute, "status": r.status, "n": int(r.n)} for r in rxs.itertuples()]
    R["shortcuts"] = out


# --- version analysis --------------------------------------------------------------------

def _letters(x):
    return "".join(ch for ch in (x or "").lower() if ch.isalnum())


def _sort_key(t):
    return tuple("" if x is None else str(x) for x in t)


def _fp(conn, document_id):
    prods = q(conn, """select product_key, ndc_original, form_code, route_codes, marketing_category_code, approval_id
                       from medid.spl_product where document_id=%s and in_scope""", (document_id,))
    out = {}
    for p in prods.itertuples():
        ings = q(conn, """select class_code, substance_unii, strength_substance_unii, num_value, num_unit, den_value,
                                 coalesce(nullif(den_unit,'1'),'') den_unit
                          from medid.spl_ingredient where product_key=%s and is_active order by part_key nulls first, ingredient_index""",
                 (p.product_key,))
        pkgs = q(conn, "select ndc_original from medid.spl_package where product_key=%s and ndc_original is not null", (p.product_key,))
        out[p.ndc_original or p.product_key] = {
            "form": p.form_code, "routes": tuple(sorted(p.route_codes or [])), "category": p.marketing_category_code,
            "application": p.approval_id,
            # ingredient order is serialization, not identity: compare sorted multisets
            "actives": tuple(sorted(((r.substance_unii, r.class_code, r.strength_substance_unii) for r in ings.itertuples()), key=_sort_key)),
            # a strength is a quantity of its basis substance (the moiety for ACTIM), so a salt-form change with
            # the same amount of the same moiety is an ingredient change, not a strength change
            "strengths": tuple(sorted(((r.strength_substance_unii or r.substance_unii, r.num_value, r.num_unit, r.den_value,
                                        r.den_unit) for r in ings.itertuples()), key=_sort_key)),
            "packages": frozenset(pkgs.ndc_original)}
    return out


def version_section(conn, R: dict) -> None:
    pairs = q(conn, """select c.set_id, c.document_id cur_doc, p.document_id prev_doc, c.version_number cur_v,
                              p.version_number prev_v, c.labeler_name cur_lab, p.labeler_name prev_lab, c.split, c.primary_group
                       from medid.spl_document c join medid.spl_document p on p.set_id=c.set_id and p.version_kind='preceding'
                       where c.version_kind='current'""")
    rows = []
    for r in pairs.itertuples():
        a, b = _fp(conn, r.prev_doc), _fp(conn, r.cur_doc)
        common = set(a) & set(b)
        ch = {
            "set_id": r.set_id, "split": r.split, "primary_group": r.primary_group,
            "preceding_version": r.prev_v, "current_version": r.cur_v, "version_gap": r.cur_v - r.prev_v,
            "products_preceding": len(a), "products_current": len(b),
            "product_ndcs_removed": len(set(a) - set(b)), "product_ndcs_added": len(set(b) - set(a)),
            "package_ndcs_removed": sum(len(a[k]["packages"] - b[k]["packages"]) for k in common),
            "package_ndcs_added": sum(len(b[k]["packages"] - a[k]["packages"]) for k in common),
            "active_ingredient_or_basis_changed": sum(a[k]["actives"] != b[k]["actives"] for k in common),
            "strength_changed": sum(a[k]["strengths"] != b[k]["strengths"] for k in common),
            "form_changed": sum(a[k]["form"] != b[k]["form"] for k in common),
            "route_changed": sum(a[k]["routes"] != b[k]["routes"] for k in common),
            "marketing_category_changed": sum(a[k]["category"] != b[k]["category"] for k in common),
            "application_changed": sum(a[k]["application"] != b[k]["application"] for k in common),
            "labeler_changed": int((r.cur_lab or "") != (r.prev_lab or "")),
            "labeler_changed_case_or_punctuation_only": int((r.cur_lab or "") != (r.prev_lab or "") and
                                                            _letters(r.cur_lab) == _letters(r.prev_lab)),
        }
        ch["any_identity_change"] = int(any(ch[k] for k in ("product_ndcs_removed", "product_ndcs_added", "package_ndcs_removed",
                                                             "package_ndcs_added", "active_ingredient_or_basis_changed",
                                                             "strength_changed", "form_changed")))
        rows.append(ch)
    write_csv("version_changes_by_set.csv", rows)
    df = pd.DataFrame(rows)
    out = {"pairs": len(df)}
    if len(df):
        for k in ("any_identity_change", "product_ndcs_removed", "product_ndcs_added", "package_ndcs_removed",
                  "package_ndcs_added", "active_ingredient_or_basis_changed", "strength_changed", "form_changed",
                  "route_changed", "marketing_category_changed", "application_changed", "labeler_changed"):
            out[k] = prop(int((df[k] > 0).sum()), len(df))
        out["version_gap_distribution"] = {int(k): int(v) for k, v in df.version_gap.value_counts().sort_index().items()}
        out["labeler_changed_case_or_punctuation_only"] = int(df.labeler_changed_case_or_punctuation_only.sum())
        # the subset samples up to N labels per group among labels listing two or more versions;
        # weight each group's change share by its number of such labels for a corpus-level figure
        multi = Counter(e["primary_group"] for e in manifest()["labels"]
                        if e["status"] == "eligible" and len(e.get("history_versions") or []) >= 2)
        by_g = df.groupby("primary_group").any_identity_change.agg(lambda x: float((x > 0).mean()))
        w = sum(multi[g] for g in by_g.index)
        out["sampling"] = {"eligible_labels_with_two_or_more_versions": sum(multi.values()),
                           "by_group": {g: {"multi_version_labels": multi[g], "pairs": int((df.primary_group == g).sum()),
                                            "any_change_share": round(by_g[g], 4)} for g in sorted(by_g.index)},
                           "any_change_weighted_by_group": round(sum(by_g[g] * multi[g] for g in by_g.index) / w, 4) if w else None,
                           "labels_with_one_listed_version": sum(1 for e in manifest()["labels"] if e["status"] == "eligible"
                                                                 and len(e.get("history_versions") or []) < 2)}
    # removed package NDCs and what RxNorm says about them now
    gone = q(conn, """select distinct d.set_id, k.ndc_original, k.ndc11, s.status, s.rxcui,
                             (select string_agg(h.start_yyyymm||'-'||coalesce(h.end_yyyymm,''), ';' order by h.seq) from medid.rx_ndc_history h where h.ndc11=k.ndc11) history
                      from medid.spl_package k join medid.spl_product p using (product_key)
                      join medid.spl_document d using (document_id)
                      left join medid.rx_ndc_status s on s.ndc11=k.ndc11
                      where d.version_kind='preceding' and p.in_scope and k.ndc_original is not null
                        and k.ndc_original not in (select k2.ndc_original from medid.spl_package k2 join medid.spl_product p2 using (product_key)
                                                   join medid.spl_document d2 using (document_id)
                                                   where d2.version_kind='current' and d2.set_id=d.set_id and k2.ndc_original is not null)""")
    write_csv("version_removed_package_ndcs_rxnorm.csv", gone)
    out["removed_package_ndcs"] = len(gone)
    out["removed_package_ndc_labels"] = int(gone.set_id.nunique())
    out["removed_package_ndcs_within_retained_products"] = int(df.package_ndcs_removed.sum()) if len(df) else 0
    out["removed_package_ndc_rxnorm_status"] = {str(k): int(v) for k, v in Counter(gone.status.fillna("not looked up")).items()}
    R["versions"] = out


def _codings_by_system(paths) -> dict:
    from .exact_json import loads_exact
    c = Counter()
    units = Counter()

    def walk(o):
        if isinstance(o, dict):
            if "system" in o and ("code" in o) and isinstance(o.get("code"), str):
                c[o["system"]] += 1
                if o["system"] == "http://unitsofmeasure.org":
                    units[o["code"]] += 1
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            for v in o:
                walk(v)
    for p in paths:
        walk(loads_exact(p.read_text()))
    return {"codings_by_system": dict(c), "ucum_codes": dict(units)}


def validation_section(R: dict) -> None:
    p = OUTPUTS / "validation" / "summary.json"
    R["validation"] = json.loads(p.read_text()) if p.exists() else {"status": "not run"}
    if p.exists() and "tx_sample" in R["validation"]:
        files = [OUTPUTS / "fhir" / "bundles" / f for f in R["validation"]["tx_sample"]["sample_files"]]
        R["validation"]["tx_sample"]["codings_checked"] = _codings_by_system(files)
        errs = Counter()
        b = json.loads((OUTPUTS / "validation" / "tx_sample.json").read_text())
        for e in b.get("entry", []):
            for i in e["resource"].get("issue", []):
                if i["severity"] in ("error", "fatal"):
                    t = i.get("details", {}).get("text", "")
                    sysm = next((u for u in ("http://hl7.org/fhir/sid/ndc", "http://www.nlm.nih.gov/research/umls/rxnorm",
                                             "http://fdasis.nlm.nih.gov", "http://unitsofmeasure.org",
                                             "http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl") if u in t), "other")
                    errs[sysm] += 1
        R["validation"]["tx_sample"]["errors_by_code_system"] = dict(errs)
        R["validation"]["tx_sample"]["inactive_code_warnings"] = sum(
            t["count"] for t in R["validation"]["tx_sample"]["issue_types"]
            if t["severity"] == "warning" and "status of inactive" in t["message"])
    if p.exists():
        for k in ("offline_all", "tx_sample"):
            if k in R["validation"]:
                R["validation"][k] = {kk: vv for kk, vv in R["validation"][k].items() if kk != "issue_types"} | \
                    {"issue_types_top": R["validation"][k]["issue_types"][:25]}


def analyze(log=print) -> dict:
    ensure(OUTPUTS / "analysis", TABLES)
    R: dict = {}
    db.start()
    with db.connect() as conn:
        corpus_section(conn, R)
        matching_section(conn, R)
        roundtrip_section(conn, R)
        shortcut_section(conn, R)
        version_section(conn, R)
    validation_section(R)
    (OUTPUTS / "analysis" / "results.json").write_text(json.dumps(R, indent=1, default=str))
    log("analysis written")
    return {"sections": list(R)}
