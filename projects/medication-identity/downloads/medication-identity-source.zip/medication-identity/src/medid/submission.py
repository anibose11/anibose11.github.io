"""Journal submission package (private; kept in handoff/submission, never on the public site).

From handoff/submission/manuscript_jamia_open.md this writes:
- manuscript_jamia_open.docx: title page, abstract, lay summary, text, back
  matter, references, tables and figures (US Letter, double spaced, page and
  line numbers, citations as superscripts);
- manuscript_jamia_open.pdf: the same text printed from HTML with Chrome;
- cover_letter.docx;
- figures/Figure1.png, Figure2.png (rendered from the SVGs at 3x).
The supplementary files are copied next to them.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

import markdown

from .paths import HANDOFF, OUTPUTS, ROOT, ensure

SUB = HANDOFF / "submission"
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"


def _svg_size(svg: Path) -> tuple[int, int]:
    m = re.search(r'viewBox="0 0 (\d+(?:\.\d+)?) (\d+(?:\.\d+)?)"', svg.read_text())
    return int(float(m.group(1))), int(float(m.group(2)))


def figures_png() -> dict:
    ensure(SUB / "figures")
    out = {}
    for i, name in ((1, "fig1_representations"), (2, "fig2_matching")):
        svg = OUTPUTS / "figures" / f"{name}-print.svg"
        w, h = _svg_size(svg)
        page = SUB / "figures" / f"_fig{i}.html"
        page.write_text(f'<!doctype html><html><body style="margin:0;background:#fcfcfb">'
                        f'<img src="{svg.as_uri()}" width="{w}" height="{h}"></body></html>')
        png = SUB / "figures" / f"Figure{i}.png"
        subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--force-device-scale-factor=3",
                        f"--window-size={w},{h}", f"--screenshot={png}", "--allow-file-access-from-files", page.as_uri()],
                       check=True, capture_output=True)
        page.unlink()
        out[i] = (png, w, h)
    return out


def _runs(text: str) -> list[dict]:
    """Markdown inline: **bold**, *italic*, citation brackets [1,2] -> superscript."""
    parts = []
    for tok in re.split(r"(\*\*[^*]+\*\*|\*[^*\s][^*]*\*|\[\d+(?:,\d+)*\])", text):
        if not tok:
            continue
        if tok.startswith("**"):
            parts.append({"text": tok[2:-2], "bold": True})
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            parts.append({"text": tok[1:-1], "italic": True})
        elif re.fullmatch(r"\[\d+(?:,\d+)*\]", tok):
            if parts and parts[-1]["text"].endswith(" "):
                parts[-1]["text"] = parts[-1]["text"].rstrip()
            parts.append({"text": tok[1:-1], "superscript": True})
        else:
            parts.append({"text": tok})
    return parts


def blocks_from_md(md: str, figs: dict) -> list[dict]:
    blocks = []
    lines = md.splitlines()
    i = 0
    in_refs = False
    while i < len(lines):
        ln = lines[i]
        if not ln.strip():
            i += 1
            continue
        if ln.startswith("# "):
            blocks.append({"type": "title", "runs": _runs(ln[2:])})
        elif ln.startswith("## "):
            title = ln[3:]
            in_refs = title == "References"
            if title in ("Abstract", "Background and significance", "References", "Figure legends"):
                blocks.append({"type": "pagebreak"})
            blocks.append({"type": "h1", "runs": _runs(title.upper())})  # JAMIA Open: first-level headings in bold capitals
        elif ln.startswith("### "):
            blocks.append({"type": "h2", "runs": _runs(ln[4:])})
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            n = len(rows[0])
            first = 0.42 if n > 3 else 0.5
            widths = [first] + [(1 - first) / (n - 1)] * (n - 1)
            blocks.append({"type": "table", "rows": rows, "widths": widths, "numeric": True})
            continue
        elif ln.startswith("![Figure"):
            k = int(re.search(r"Figure (\d)", ln).group(1))
            png, w, h = figs[k]
            width = 600
            blocks.append({"type": "image", "path": str(png), "width": width, "height": int(width * h / w)})
        elif re.match(r"^\d+\. ", ln) and in_refs:
            blocks.append({"type": "ref", "runs": _runs(ln)})
        elif ln.startswith("**Table") or ln.startswith("**Figure") or ln.startswith("Alt text:"):
            blocks.append({"type": "caption", "runs": _runs(ln)})
        else:
            blocks.append({"type": "p", "runs": _runs(ln)})
        i += 1
    return blocks


def _docx(blocks: list[dict], out: Path, title: str, double: bool, line_numbers: bool) -> None:
    spec = {"title": title, "author": "Animesh Bose", "double_spaced": double, "line_numbers": line_numbers, "blocks": blocks}
    tmp = SUB / "_blocks.json"
    tmp.write_text(json.dumps(spec))
    subprocess.run(["node", str(ROOT / "scripts" / "build_docx.js"), str(tmp), str(out)], check=True, capture_output=True)
    tmp.unlink()


def _pdf(md: str, out: Path, title: str) -> None:
    body = markdown.markdown(md, extensions=["tables"])
    body = body.replace('src="figures/', f'src="{(SUB / "figures").as_uri()}/')
    body = re.sub(r'src="[^"]*fig1_representations\.svg"', f'src="{(SUB / "figures" / "Figure1.png").as_uri()}"', body)
    body = re.sub(r'src="[^"]*fig2_matching\.svg"', f'src="{(SUB / "figures" / "Figure2.png").as_uri()}"', body)
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>{title}</title><style>
@page{{size:Letter;margin:1in}}body{{font:12pt/1.6 "Times New Roman",serif;color:#000}}h1{{font-size:16pt}}h2{{font-size:13pt;margin-top:1.4em}}
h3{{font-size:12pt}}table{{border-collapse:collapse;font-size:10pt;margin:.5em 0 1em}}th,td{{border-top:1px solid #999;border-bottom:1px solid #999;padding:3px 6px;text-align:left}}
img{{max-width:100%}}</style></head><body>{body}</body></html>"""
    page = SUB / "_print.html"
    page.write_text(html)
    subprocess.run([CHROME, "--headless=new", "--disable-gpu", "--allow-file-access-from-files", "--no-pdf-header-footer",
                    f"--print-to-pdf={out}", page.as_uri()], check=True, capture_output=True)
    page.unlink()


def build_submission() -> dict:
    ensure(SUB)
    md = (SUB / "manuscript_jamia_open.md").read_text()
    title = md.splitlines()[0][2:]
    figs = figures_png()
    _docx(blocks_from_md(md, figs), SUB / "manuscript_jamia_open.docx", title, double=True, line_numbers=False)
    _pdf(md, SUB / "manuscript_jamia_open.pdf", title)
    cl = (SUB / "cover_letter.md").read_text()
    cl_blocks = []
    for para in cl.split("\n\n"):
        if not para.strip():
            continue
        # the signature block keeps one line per paragraph; other paragraphs are single lines already
        for line in (para.strip().splitlines() if para.startswith("Animesh Bose") else [para.strip()]):
            cl_blocks.append({"type": "p", "runs": [{"text": line}]})
    _docx(cl_blocks, SUB / "cover_letter.docx", "Cover letter", double=False, line_numbers=False)
    supp = SUB / "supplementary"
    ensure(supp)
    site_dl = ROOT / "site" / "projects" / "medication-identity" / "downloads"
    for name, new in (("medication-identity-source.zip", "S1_medication-identity-source.zip"),
                      ("medication_identity_results.xlsx", "S2_medication_identity_results.xlsx"),
                      ("medication_dictionary.zip", "S3_medication_dictionary.zip"),
                      ("fhir_examples.zip", "S4_fhir_examples.zip")):
        if (site_dl / name).exists():
            shutil.copy2(site_dl / name, supp / new)
    files = sorted(p.relative_to(SUB).as_posix() for p in SUB.rglob("*") if p.is_file())
    return {"files": files}
