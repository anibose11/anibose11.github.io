"""Canonical, lossless reader for the product data elements of an SPL document.

The reader keeps values as the source wrote them (NDC hyphenation, decimal
text, unit strings, code system OIDs) and records where each product,
ingredient and package came from. It does not decide what anything means
clinically; interpretation happens in later, separately tested steps.

Element paths follow the FDA SPL implementation guide (HL7 v3, namespace
urn:hl7-org:v3). Products sit at
  section[code=48780-1]/subject/manufacturedProduct (role)
    /manufacturedProduct (entity: code, name, formCode, ingredient*, asContent*, part*)
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from fractions import Fraction
from pathlib import Path

from lxml import etree

from . import ndc as ndc_mod
from .quantity import fraction_to_decimal_text, is_decimal_text, to_fraction

NS = {"v3": "urn:hl7-org:v3", "xsi": "http://www.w3.org/2001/XMLSchema-instance"}
OID_NDC = "2.16.840.1.113883.6.69"
OID_UNII = "2.16.840.1.113883.4.9"
OID_NCIT = "2.16.840.1.113883.3.26.1.1"
OID_LOINC = "2.16.840.1.113883.6.1"
OID_DUNS = "1.3.6.1.4.1.519.1"
PRODUCT_SECTION = "48780-1"



def _attr(el, name):
    return None if el is None else el.get(name)


def _first(el, path):
    if el is None:
        return None
    r = el.find(path, NS)
    return r


def _text(el) -> str | None:
    if el is None:
        return None
    t = " ".join("".join(el.itertext()).split())
    return t or None


@dataclass
class Ingredient:
    index: int
    class_code: str | None
    substance_code: str | None
    substance_code_system: str | None
    substance_name: str | None
    moiety_codes: list[str] = field(default_factory=list)
    moiety_names: list[str] = field(default_factory=list)
    reference_code: str | None = None
    reference_name: str | None = None
    num_value: str | None = None
    num_unit: str | None = None
    den_value: str | None = None
    den_unit: str | None = None
    moiety_repeated: bool = False   # the label lists the same active moiety more than once (kept once)

    @property
    def is_active(self) -> bool:
        return bool(self.class_code) and self.class_code.startswith("ACTI")

    @property
    def basis_of_strength(self) -> str:
        """Which substance the stated strength refers to, per the class code."""
        return {"ACTIB": "ingredient", "ACTIM": "active_moiety", "ACTIR": "reference_substance"}.get(
            self.class_code or "", "unspecified")

    def strength_substance(self) -> tuple[str | None, str | None]:
        """(UNII, name) of the basis-of-strength substance when the source states it."""
        if self.class_code == "ACTIB":
            return self.substance_code, self.substance_name
        if self.class_code == "ACTIM":
            if len(self.moiety_codes) == 1:
                return self.moiety_codes[0], self.moiety_names[0] if self.moiety_names else None
            return None, None  # several moieties: the source does not say which one the strength is for
        if self.class_code == "ACTIR":
            return self.reference_code, self.reference_name
        return None, None


@dataclass
class Package:
    path: str                    # e.g. "1", "1.1": nesting from the product outward
    level: int
    ndc_original: str | None
    ndc_configuration: str | None
    form_code: str | None
    form_display: str | None
    qty_num_value: str | None    # count of the inner item in this container
    qty_num_unit: str | None
    qty_den_value: str | None
    qty_den_unit: str | None
    marketing_status: str | None
    marketing_low: str | None
    marketing_high: str | None
    marketing_act_code: str | None
    combination_type_code: str | None
    combination_type_display: str | None
    total_amount_value: str | None = None   # product units in this container (exact)
    total_amount_unit: str | None = None
    total_amount_status: str = "not_evaluated"


@dataclass
class Part:
    index: int
    qty_num_value: str | None
    qty_num_unit: str | None
    qty_den_value: str | None
    qty_den_unit: str | None
    ndc_original: str | None
    name: str | None
    form_code: str | None
    form_display: str | None
    ingredients: list[Ingredient] = field(default_factory=list)
    packages: list[Package] = field(default_factory=list)
    route_codes: list[str] = field(default_factory=list)
    approval_id: str | None = None
    marketing_category_code: str | None = None


@dataclass
class Product:
    index: int
    ndc_original: str | None
    ndc_configuration: str | None
    ndc_code_system: str | None
    proprietary_name: str | None
    name_suffix: str | None
    generic_name: str | None
    form_code: str | None
    form_code_system: str | None
    form_display: str | None
    route_codes: list[str] = field(default_factory=list)
    route_displays: list[str] = field(default_factory=list)
    approval_id: str | None = None
    approval_id_root: str | None = None
    marketing_category_code: str | None = None
    marketing_category_display: str | None = None
    marketing_status: str | None = None
    marketing_low: str | None = None
    marketing_high: str | None = None
    equivalent_ndc: str | None = None          # source product for repackaged/relabeled products
    equivalent_code: str | None = None
    ingredients: list[Ingredient] = field(default_factory=list)
    packages: list[Package] = field(default_factory=list)
    parts: list[Part] = field(default_factory=list)

    @property
    def is_kit(self) -> bool:
        return bool(self.parts)

    def active_ingredients(self) -> list[Ingredient]:
        return [i for i in self.ingredients if i.is_active]


@dataclass
class SplDocument:
    document_id: str | None
    set_id: str | None
    version_number: str | None
    effective_time: str | None
    doc_type_code: str | None
    doc_type_display: str | None
    title: str | None
    labeler_name: str | None
    labeler_id: str | None
    labeler_id_root: str | None
    products: list[Product] = field(default_factory=list)
    parse_warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def _ratio(q_el):
    if q_el is None:
        return None, None, None, None
    n = _first(q_el, "v3:numerator")
    d = _first(q_el, "v3:denominator")
    return _attr(n, "value"), _attr(n, "unit"), _attr(d, "value"), _attr(d, "unit")


def _ingredients(entity) -> list[Ingredient]:
    out = []
    for i, ing in enumerate(entity.findall("v3:ingredient", NS)):
        sub = _first(ing, "v3:ingredientSubstance")
        code = _first(sub, "v3:code")
        nv, nu, dv, du = _ratio(_first(ing, "v3:quantity"))
        moiety_codes, moiety_names = [], []
        repeated = False
        for m in (sub.findall("v3:activeMoiety/v3:activeMoiety", NS) if sub is not None else []):
            mcode = _attr(_first(m, "v3:code"), "code")
            if mcode in moiety_codes:  # some labels list the same moiety twice
                repeated = True
                continue
            moiety_codes.append(mcode)
            moiety_names.append(_text(_first(m, "v3:name")))
        ref = _first(sub, "v3:asEquivalentSubstance/v3:definingSubstance")
        out.append(Ingredient(
            index=i,
            moiety_repeated=repeated,
            class_code=ing.get("classCode"),
            substance_code=_attr(code, "code"),
            substance_code_system=_attr(code, "codeSystem"),
            substance_name=_text(_first(sub, "v3:name")),
            moiety_codes=moiety_codes,
            moiety_names=moiety_names,
            reference_code=_attr(_first(ref, "v3:code"), "code"),
            reference_name=_text(_first(ref, "v3:name")),
            num_value=nv, num_unit=nu, den_value=dv, den_unit=du,
        ))
    return out


def _marketing(holder, with_code: bool = False):
    """marketingAct under holder/subjectOf (package or product role).

    The act code is C53292 for marketing and C96974 for drug samples."""
    for so in holder.findall("v3:subjectOf", NS):
        ma = _first(so, "v3:marketingAct")
        if ma is not None:
            et = _first(ma, "v3:effectiveTime")
            out = (_attr(_first(ma, "v3:statusCode"), "code"),
                   _attr(_first(et, "v3:low"), "value"),
                   _attr(_first(et, "v3:high"), "value"))
            return out + (_attr(_first(ma, "v3:code"), "code"),) if with_code else out
    return (None, None, None, None) if with_code else (None, None, None)


def _combination_type(holder):
    for so in holder.findall("v3:subjectOf", NS):
        ch = _first(so, "v3:characteristic")
        if ch is not None and _attr(_first(ch, "v3:code"), "code") == "SPLCMBPRDTP":
            v = _first(ch, "v3:value")
            return _attr(v, "code"), _attr(v, "displayName")
    return None, None


def _packages(entity, warnings: list[str]) -> list[Package]:
    """Walk asContent/containerPackagedProduct from the product outward."""
    out: list[Package] = []

    def walk(holder, prefix: str, level: int):
        for k, ac in enumerate(holder.findall("v3:asContent", NS), start=1):
            path = f"{prefix}.{k}" if prefix else str(k)
            nv, nu, dv, du = _ratio(_first(ac, "v3:quantity"))
            cpp = _first(ac, "v3:containerPackagedProduct")
            code = _attr(_first(cpp, "v3:code"), "code")
            form = _first(cpp, "v3:formCode")
            parsed = ndc_mod.parse(code) if code else None
            status, low, high, act_code = _marketing(ac, with_code=True)
            ctc, ctd = _combination_type(ac)
            out.append(Package(
                path=path, level=level,
                ndc_original=code or None,
                ndc_configuration=parsed.configuration if parsed else None,
                form_code=_attr(form, "code"), form_display=_attr(form, "displayName"),
                qty_num_value=nv, qty_num_unit=nu, qty_den_value=dv, qty_den_unit=du,
                marketing_status=status, marketing_low=low, marketing_high=high, marketing_act_code=act_code,
                combination_type_code=ctc, combination_type_display=ctd,
            ))
            if cpp is not None:
                walk(cpp, path, level + 1)

    walk(entity, "", 1)
    _total_amounts(out, warnings)
    return out


def _total_amounts(pkgs: list[Package], warnings: list[str]) -> None:
    """Product units per container: multiply counts from the product outward.

    Exactly one non-count unit (e.g. mL in a vial) may appear, at the innermost
    level; anything else is left unresolved instead of guessed.
    """
    by_path = {p.path: p for p in pkgs}
    for p in pkgs:
        chain = []
        parts = p.path.split(".")
        for i in range(1, len(parts) + 1):
            chain.append(by_path[".".join(parts[:i])])
        total = Fraction(1)
        unit = None
        ok = True
        for depth, c in enumerate(chain):
            if not is_decimal_text(c.qty_num_value) or (c.qty_den_value not in (None, "1")):
                ok = False
                break
            u = c.qty_num_unit or "1"
            if u != "1":
                if depth != 0 or unit is not None:
                    ok = False
                    break
                unit = u
            total *= to_fraction(c.qty_num_value)
        if ok:
            text = fraction_to_decimal_text(total)
            p.total_amount_value, p.total_amount_unit = text, unit or "1"
            p.total_amount_status = "computed" if text is not None else "inexact"
        else:
            p.total_amount_status = "unresolved"


def _product(entity, index: int, role, warnings: list[str]) -> Product:
    code = _first(entity, "v3:code")
    code_val = _attr(code, "code")
    parsed = ndc_mod.parse(code_val) if code_val else None
    name_el = _first(entity, "v3:name")
    suffix = _text(_first(name_el, "v3:suffix"))
    name = None
    if name_el is not None:
        name = " ".join((name_el.text or "").split()) or None
    form = _first(entity, "v3:formCode")
    equiv = _first(entity, "v3:asEquivalentEntity/v3:definingMaterialKind/v3:code")
    equiv_code = _attr(_first(entity, "v3:asEquivalentEntity/v3:code"), "code")
    p = Product(
        index=index,
        ndc_original=code_val,
        ndc_configuration=parsed.configuration if parsed else None,
        ndc_code_system=_attr(code, "codeSystem"),
        proprietary_name=name,
        name_suffix=suffix,
        generic_name=_text(_first(entity, "v3:asEntityWithGeneric/v3:genericMedicine/v3:name")),
        form_code=_attr(form, "code"),
        form_code_system=_attr(form, "codeSystem"),
        form_display=_attr(form, "displayName"),
        equivalent_ndc=_attr(equiv, "code"),
        equivalent_code=equiv_code,
        ingredients=_ingredients(entity),
        packages=_packages(entity, warnings),
    )
    for k, part in enumerate(entity.findall("v3:part", NS)):
        pp = _first(part, "v3:partProduct")
        nv, nu, dv, du = _ratio(_first(part, "v3:quantity"))
        pform = _first(pp, "v3:formCode")
        pname = _first(pp, "v3:name")
        p.parts.append(Part(
            index=k, qty_num_value=nv, qty_num_unit=nu, qty_den_value=dv, qty_den_unit=du,
            ndc_original=_attr(_first(pp, "v3:code"), "code"),
            name=" ".join((pname.text or "").split()) if pname is not None else None,
            form_code=_attr(pform, "code"), form_display=_attr(pform, "displayName"),
            ingredients=_ingredients(pp) if pp is not None else [],
            packages=_packages(pp, warnings) if pp is not None else [],
            route_codes=[r.get("code") for r in part.findall("v3:consumedIn/v3:substanceAdministration/v3:routeCode", NS)],
            approval_id=_attr(_first(part, "v3:subjectOf/v3:approval/v3:id"), "extension"),
            marketing_category_code=_attr(_first(part, "v3:subjectOf/v3:approval/v3:code"), "code"),
        ))
    if role is not None:
        for ca in role.findall("v3:consumedIn/v3:substanceAdministration/v3:routeCode", NS):
            p.route_codes.append(ca.get("code"))
            p.route_displays.append(ca.get("displayName"))
        appr = _first(role, "v3:subjectOf/v3:approval")
        if appr is not None:
            aid = _first(appr, "v3:id")
            acode = _first(appr, "v3:code")
            p.approval_id, p.approval_id_root = _attr(aid, "extension"), _attr(aid, "root")
            p.marketing_category_code, p.marketing_category_display = _attr(acode, "code"), _attr(acode, "displayName")
        p.marketing_status, p.marketing_low, p.marketing_high = _marketing(role)
    return p


def parse_spl(source: Path | bytes) -> SplDocument:
    data = source.read_bytes() if isinstance(source, Path) else source
    parser = etree.XMLParser(resolve_entities=False, no_network=True, huge_tree=False)
    root = etree.fromstring(data, parser)
    if etree.QName(root).localname != "document":
        raise ValueError("not an SPL document")
    warnings: list[str] = []
    org = _first(root, "v3:author/v3:assignedEntity/v3:representedOrganization")
    org_id = _first(org, "v3:id")
    doc_code = _first(root, "v3:code")
    doc = SplDocument(
        document_id=_attr(_first(root, "v3:id"), "root"),
        set_id=_attr(_first(root, "v3:setId"), "root"),
        version_number=_attr(_first(root, "v3:versionNumber"), "value"),
        effective_time=_attr(_first(root, "v3:effectiveTime"), "value"),
        doc_type_code=_attr(doc_code, "code"),
        doc_type_display=_attr(doc_code, "displayName"),
        title=_text(_first(root, "v3:title")),
        labeler_name=_text(_first(org, "v3:name")),
        labeler_id=_attr(org_id, "extension"),
        labeler_id_root=_attr(org_id, "root"),
        parse_warnings=warnings,
    )
    idx = 0
    for sec in root.iter("{urn:hl7-org:v3}section"):
        if _attr(_first(sec, "v3:code"), "code") != PRODUCT_SECTION:
            continue
        for role in sec.findall("v3:subject/v3:manufacturedProduct", NS):
            entity = _first(role, "v3:manufacturedProduct")
            if entity is None:
                warnings.append("product role without entity")
                continue
            doc.products.append(_product(entity, idx, role, warnings))
            idx += 1
    if not doc.products:
        warnings.append("no product data elements section")
    return doc
