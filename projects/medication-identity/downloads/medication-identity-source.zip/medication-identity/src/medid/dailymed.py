"""DailyMed web services v2 and label archive retrieval.

Observed 2026-10-07: the v2 services describe current labels only; /spls
returns one row per set ID with its current version; earlier versions are
downloadable as ZIP archives from getFile.cfm?type=zip&setid=&version=, which
answers 404 for versions DailyMed does not hold. No rate limit is published;
this client stays at or below 4 requests per second.
"""
from __future__ import annotations

import io
import zipfile
from urllib.parse import urlencode

from .http import Fetcher, FetchError
from .paths import RAW

API = "https://dailymed.nlm.nih.gov/dailymed/services/v2"
ARCHIVE = "https://dailymed.nlm.nih.gov/dailymed/getFile.cfm"
MAPPINGS = "https://dailymed-data.nlm.nih.gov/public-release-files/rxnorm_mappings.zip"
RX_DOC_TYPE = "34391-3"


class DailyMed:
    def __init__(self, rate: float = 4.0):
        self.f = Fetcher(RAW / "dailymed", rate=rate)

    def close(self):
        self.f.close()

    def spls(self, **params) -> list[dict]:
        """All pages of /spls.json for the given filters."""
        rows, page = [], 1
        while True:
            q = urlencode({**params, "pagesize": 100, "page": page})
            js = self.f.get(f"{API}/spls.json?{q}", expect="json").json()
            data = js.get("data") or []
            rows.extend(data)
            meta = js.get("metadata") or {}
            total_pages = int(meta.get("total_pages") or 0)
            if page >= total_pages or not data:
                break
            page += 1
        return rows

    def history(self, setid: str) -> list[dict]:
        rows, page = [], 1
        while True:
            js = self.f.get(f"{API}/spls/{setid}/history.json?pagesize=100&page={page}", expect="json").json()
            data = (js.get("data") or {}).get("history") or []
            rows.extend(data)
            meta = js.get("metadata") or {}
            if page >= int(meta.get("total_pages") or 0) or not data:
                break
            page += 1
        return rows

    def current_xml(self, setid: str):
        return self.f.get(f"{API}/spls/{setid}.xml", expect="xml")

    def packaging(self, setid: str):
        return self.f.get(f"{API}/spls/{setid}/packaging.json", expect="json")

    def version_zip(self, setid: str, version: int):
        """Archived SPL ZIP for one version, or None when DailyMed does not hold it."""
        url = f"{ARCHIVE}?type=zip&setid={setid}&version={version}"
        try:
            return self.f.get(url, expect="zip", allow_status=(200,))
        except FetchError as e:
            if "HTTP 404" in str(e):
                return None
            raise

    def mapping_file(self, refresh: bool = False):
        return self.f.get(MAPPINGS, expect="zip", refresh=refresh)


def xml_from_zip(data: bytes) -> tuple[str, bytes]:
    """The single SPL XML member of a label archive: (member name, bytes)."""
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        xmls = [i for i in zf.infolist() if i.filename.lower().endswith(".xml") and "/" not in i.filename]
        if len(xmls) != 1:
            raise FetchError(f"expected one XML member, found {[i.filename for i in xmls]}")
        return xmls[0].filename, zf.read(xmls[0])
