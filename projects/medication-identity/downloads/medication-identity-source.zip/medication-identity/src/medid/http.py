"""Cached, rate-limited HTTP retrieval with content validation.

Every response that the study uses is written once to data/raw/ together with a
metadata file (URL, retrieval time, status, content type, size, SHA-256). Later
runs read the cached bytes, so analysis is repeatable offline. Immutable
resources (versioned SPL archives) are never refetched. Mutable API responses
are refetched only when the caller passes refresh=True, and the old snapshot
is kept under a timestamped name so the change is auditable.
"""
from __future__ import annotations

import hashlib
import io
import json
import threading
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

USER_AGENT = "medid-research/1.0 (medication identity reconciliation study; python-httpx)"


class FetchError(RuntimeError):
    pass


class RateLimiter:
    """Simple shared limiter: at most `rate` request starts per second."""

    def __init__(self, rate: float):
        self.interval = 1.0 / rate
        self.lock = threading.Lock()
        self.next_time = 0.0

    def wait(self) -> None:
        with self.lock:
            now = time.monotonic()
            if now < self.next_time:
                time.sleep(self.next_time - now)
                now = self.next_time
            self.next_time = now + self.interval


@dataclass
class Fetched:
    url: str
    path: Path
    sha256: str
    size: int
    content_type: str
    retrieved_utc: str
    from_cache: bool

    def bytes(self) -> bytes:
        return self.path.read_bytes()

    def json(self) -> Any:
        return json.loads(self.path.read_bytes())

    def meta(self) -> dict:
        return {
            "url": self.url,
            "path": rel(self.path),
            "sha256": self.sha256,
            "bytes": self.size,
            "content_type": self.content_type,
            "retrieved_utc": self.retrieved_utc,
        }


def rel(path: Path) -> str:
    """Path relative to the project root when it lies inside it."""
    from .paths import ROOT
    try:
        return str(Path(path).resolve().relative_to(ROOT.resolve()))
    except ValueError:
        return str(path)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _looks_like_html(data: bytes) -> bool:
    head = data[:512].lstrip().lower()
    return head.startswith(b"<!doctype html") or head.startswith(b"<html")


def validate_payload(data: bytes, expect: str, content_type: str) -> None:
    """Reject error pages and truncated payloads that would otherwise be cached as data."""
    ct = content_type.lower()
    if expect == "json":
        if "json" not in ct:
            raise FetchError(f"expected JSON, got content type {content_type!r}")
        try:
            json.loads(data)
        except ValueError as e:
            raise FetchError(f"invalid JSON: {e}") from e
    elif expect == "xml":
        if _looks_like_html(data):
            raise FetchError("expected XML, got an HTML page")
        if not data.lstrip().startswith(b"<?xml") and not data.lstrip().startswith(b"<document"):
            raise FetchError("expected an XML document")
    elif expect == "zip":
        if _looks_like_html(data):
            raise FetchError("expected a ZIP archive, got an HTML page")
        if not data.startswith(b"PK"):
            raise FetchError("expected a ZIP archive (missing PK signature)")
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            bad = zf.testzip()
            if bad is not None:
                raise FetchError(f"corrupt ZIP member {bad}")
            for info in zf.infolist():
                check_member_name(info.filename)
    elif expect == "html":
        if not _looks_like_html(data):
            raise FetchError("expected an HTML page")
    elif expect == "any":
        pass
    else:
        raise ValueError(f"unknown expectation {expect}")


def check_member_name(name: str) -> None:
    """Refuse archive members that could escape an extraction directory."""
    p = Path(name)
    if name.startswith("/") or name.startswith("\\") or ".." in p.parts or ":" in name:
        raise FetchError(f"unsafe archive member name {name!r}")


def safe_extract(zip_path: Path, dest: Path, max_total_bytes: int = 500 * 1024 * 1024,
                 allowed_suffixes: tuple[str, ...] | None = None) -> list[Path]:
    """Extract a ZIP without path traversal and with a total size bound."""
    out: list[Path] = []
    dest.mkdir(parents=True, exist_ok=True)
    total = 0
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            check_member_name(info.filename)
            if allowed_suffixes and not info.filename.lower().endswith(allowed_suffixes):
                continue
            total += info.file_size
            if total > max_total_bytes:
                raise FetchError(f"archive {zip_path} exceeds extraction bound")
            target = dest / Path(info.filename).name
            with zf.open(info) as src, open(target, "wb") as dst:
                dst.write(src.read())
            out.append(target)
    return out


class Fetcher:
    """HTTP GET with an on-disk cache keyed by URL."""

    def __init__(self, cache_dir: Path, rate: float, retries: int = 4, timeout: float = 60.0):
        self.cache_dir = cache_dir
        self.limiter = RateLimiter(rate)
        self.retries = retries
        self.client = httpx.Client(
            timeout=timeout,
            headers={"User-Agent": USER_AGENT},
            follow_redirects=True,
        )
        self.log_lock = threading.Lock()
        cache_dir.mkdir(parents=True, exist_ok=True)

    def close(self) -> None:
        self.client.close()

    def _paths(self, url: str, suffix: str) -> tuple[Path, Path]:
        key = hashlib.sha256(url.encode()).hexdigest()
        sub = self.cache_dir / key[:2]
        return sub / f"{key}{suffix}", sub / f"{key}.meta.json"

    def get(self, url: str, expect: str, suffix: str | None = None, refresh: bool = False,
            allow_status: tuple[int, ...] = (200,)) -> Fetched:
        suffix = suffix or {"json": ".json", "xml": ".xml", "zip": ".zip", "html": ".html"}.get(expect, ".bin")
        body_path, meta_path = self._paths(url, suffix)
        if body_path.exists() and meta_path.exists() and not refresh:
            meta = json.loads(meta_path.read_text())
            data_hash = sha256_file(body_path)
            if data_hash != meta["sha256"]:
                raise FetchError(f"cached file changed on disk: {body_path}")
            return Fetched(url, body_path, meta["sha256"], meta["bytes"], meta["content_type"],
                           meta["retrieved_utc"], True)
        if body_path.exists() and refresh:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            body_path.rename(body_path.with_name(body_path.name + f".superseded-{stamp}"))
            meta_path.rename(meta_path.with_name(meta_path.name + f".superseded-{stamp}"))

        last_err: Exception | None = None
        for attempt in range(self.retries + 1):
            self.limiter.wait()
            try:
                r = self.client.get(url)
                if r.status_code in (429, 500, 502, 503, 504):
                    raise FetchError(f"HTTP {r.status_code}")
                if r.status_code not in allow_status:
                    raise FetchError(f"HTTP {r.status_code} for {url}")
                data = r.content
                ctype = r.headers.get("content-type", "")
                if r.status_code == 200:
                    validate_payload(data, expect, ctype)
                body_path.parent.mkdir(parents=True, exist_ok=True)
                tmp = body_path.with_suffix(body_path.suffix + ".part")
                tmp.write_bytes(data)
                tmp.replace(body_path)
                meta = {
                    "url": url,
                    "final_url": str(r.url),
                    "status": r.status_code,
                    "content_type": ctype,
                    "bytes": len(data),
                    "sha256": sha256_bytes(data),
                    "retrieved_utc": utc_now(),
                    "last_modified": r.headers.get("last-modified"),
                    "etag": r.headers.get("etag"),
                }
                meta_path.write_text(json.dumps(meta, indent=1))
                return Fetched(url, body_path, meta["sha256"], meta["bytes"], ctype,
                               meta["retrieved_utc"], False)
            except (httpx.HTTPError, FetchError) as e:
                last_err = e
                transient = isinstance(e, httpx.TransportError) or (
                    isinstance(e, FetchError) and (str(e).startswith("HTTP 5") or str(e) == "HTTP 429"))
                if not transient or attempt == self.retries:
                    break
                time.sleep(min(30.0, 1.5 * 2 ** attempt))
        raise FetchError(f"failed to fetch {url}: {last_err}")
