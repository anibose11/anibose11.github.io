"""Source-versus-FHIR comparison page for one product-version record.

Shows, side by side: the product's element in the source SPL XML, the FHIR
Medication resources built from it, its sidecar entries, the field-level
round-trip result for each representation, and the matching results.
Everything is read from the project's stored outputs.
"""
from __future__ import annotations

import html
import json
from pathlib import Path

from lxml import etree

from . import db
from .exact_json import dumps, loads_exact
from .fhir_export import bundle_paths
from .paths import OUTPUTS, ROOT

STATUS_LABEL = {
    "preserved": "preserved", "preserved_normalized": "preserved (documented normalization)",
    "converted_equivalent": "equal after documented conversion", "omitted_in_sidecar": "not in FHIR core; in sidecar",
    "unresolved": "unresolved", "discordant": "discordant", "inapplicable": "not applicable", "not_evaluated": "not evaluated",
}
ATTR_LABEL = {
    "K1_set_id": "SPL set ID", "K2_document_id": "SPL document ID", "K3_version": "SPL version",
    "K4_product_ndc": "Product NDC", "K5_package_ndcs": "Package NDCs", "K6_form_code": "Dosage form code",
    "K7_active_count": "Active ingredient count", "K8_unii": "Ingredient UNII", "K9_class_code": "Basis-of-strength code",
    "K10_boss_unii": "Basis-of-strength substance", "K11_num_value": "Strength numerator", "K11_num_unit": "Numerator unit",
    "K12_den_value": "Strength denominator", "K12_den_unit": "Denominator unit", "K13_part_ndcs": "Kit part NDCs",
}
REP_LABEL = {"R1_full": "FHIR + sidecar", "R_core": "FHIR core only", "S_rx": "RxCUI only", "S_flat": "Flat export",
             "S_api": "DailyMed packaging API", "S_latest": "Latest version only"}

CSS = """
:root{--bg:#fbfaf7;--fg:#1d1d1b;--muted:#5b5a55;--rule:#d9d6cc;--accent:#1f5f8b;--plate:#f1efe8;--bad:#8a2b1d;--ok:#2e5e2e}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:1180px;margin:0 auto;padding:24px 16px 64px}h1{font-size:1.5rem;margin:.2em 0}h2{font-size:1.15rem;margin:2em 0 .5em}
p{max-width:70ch}.muted{color:var(--muted)}a{color:var(--accent)}a:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(320px,100%),1fr));gap:16px}
pre{background:var(--plate);padding:12px;overflow:auto;max-height:520px;font:12.5px/1.45 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre}
.tablewrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{border-bottom:1px solid var(--rule);padding:6px 8px;text-align:left;vertical-align:top}
th{color:var(--muted);font-weight:600}td.st-discordant,td.st-unresolved{color:var(--bad)}td.st-preserved,td.st-preserved_normalized{color:var(--ok)}
code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.9em}
"""


def _product_xml(src_path: Path, index: int) -> str:
    root = etree.parse(str(src_path)).getroot()
    ns = {"v3": "urn:hl7-org:v3"}
    k = 0
    for sec in root.iter("{urn:hl7-org:v3}section"):
        code = sec.find("v3:code", ns)
        if code is None or code.get("code") != "48780-1":
            continue
        for role in sec.findall("v3:subject/v3:manufacturedProduct", ns):
            if k == index:
                return etree.tostring(role, pretty_print=True, encoding="unicode")
            k += 1
    return "(product element not found)"


def write_view(product_key: str, out: str | None = None, title_note: str | None = None) -> Path:
    document_id, index = product_key.rsplit(":", 1)
    index = int(index)
    db.start()
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        d = conn.execute("""select d.set_id, d.version_number, d.version_kind, d.source_path, p.proprietary_name,
                                   p.generic_name, p.ndc_original, d.labeler_name, d.split
                            from spl_document d join spl_product p using (document_id)
                            where p.product_key = %s""", (product_key,)).fetchone()
        if not d:
            raise SystemExit(f"unknown product {product_key}")
        rt = conn.execute("""select representation, attribute, item, status, source_value, reconstructed_value
                             from roundtrip_field where product_key = %s order by representation, attribute, item""",
                          (product_key,)).fetchall()
        mt = conn.execute("select approach, outcome, rxcui, candidates, score, detail from match_result where product_key=%s order by approach",
                          (product_key,)).fetchall()
        names = dict(conn.execute("select rxcui, name from rx_concept").fetchall())
    set_id, version, vkind, src_path, pname, gname, ndc, labeler, split = d
    bp, sp = bundle_paths(document_id)
    bundle = loads_exact(bp.read_text())
    side = loads_exact(sp.read_text())
    meds = {mid: s for mid, s in side["medications"].items()
            if (s["resource_level"] == "product" and int(s["product"]["index"]) == index)}
    pid = next(iter(meds))
    pkg_ids = [mid for mid, s in side["medications"].items() if s.get("product_medication_id") == pid]
    res = {e["resource"]["id"]: e["resource"] for e in bundle["entry"]}
    fhir_text = dumps([res[pid]] + [res[k] for k in pkg_ids[:3]])
    side_text = dumps({pid: side["medications"][pid], **{k: side["medications"][k] for k in pkg_ids[:3]}})
    more = f" (first 3 of {len(pkg_ids)} package resources shown)" if len(pkg_ids) > 3 else ""
    xml_text = _product_xml(ROOT / src_path, index)

    reps = sorted({r[0] for r in rt}, key=lambda x: list(REP_LABEL).index(x) if x in REP_LABEL else 99)
    by = {(r[0], r[1], r[2]): r for r in rt}
    keys = sorted({(r[1], r[2]) for r in rt}, key=lambda k: (list(ATTR_LABEL).index(k[0]) if k[0] in ATTR_LABEL else 99, k[1]))
    head = "".join(f"<th scope='col'>{html.escape(REP_LABEL.get(r, r))}</th>" for r in reps)
    body = []
    for attr, item in keys:
        src_val = next((by[(r, attr, item)][4] for r in reps if (r, attr, item) in by and by[(r, attr, item)][4]), None)
        cells = []
        for r in reps:
            row = by.get((r, attr, item))
            if not row:
                cells.append("<td class='muted'>not computed</td>")
                continue
            val = row[5] if row[5] is not None else ""
            cells.append(f"<td class='st-{row[3]}'>{html.escape(STATUS_LABEL[row[3]])}"
                         + (f"<br><code>{html.escape(val)}</code>" if val and row[3] not in ('preserved',) else "") + "</td>")
        label = ATTR_LABEL.get(attr, attr) + (f" (ingredient {int(item) + 1})" if item else "")
        body.append(f"<tr><th scope='row'>{html.escape(label)}<br><code>{html.escape(src_val or '')}</code></th>{''.join(cells)}</tr>")
    mrows = []
    for a, o, rx, cands, score, detail in mt:
        if a == "B" and not cands and detail and detail.get("packages"):
            cands = sorted({c for p in detail["packages"] for c in p.get("candidates", [])})
        cl = sorted(cands or [], key=lambda c: (c != rx, c))  # the answered RxCUI first
        shown = "; ".join(f"{c} {names.get(c, '')}".strip() for c in cl[:5]) + (f" (5 of {len(cl)} shown)" if len(cl) > 5 else "")
        extra = f"score {float(score):.0f}" if score is not None else ""
        mrows.append(f"<tr><th scope='row'>{a}</th><td>{html.escape(o)}</td><td>{html.escape(rx or '')} {html.escape(names.get(rx, '') if rx else '')}</td>"
                     f"<td>{html.escape(shown)}</td><td>{extra}</td></tr>")
    page = f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(pname or gname or 'Product')} source versus FHIR</title><style>{CSS}</style></head><body><main>
<p class="muted"><a href="index.html">Medication identity</a> / comparison viewer</p>
<h1>{html.escape(pname or '')} ({html.escape(gname or '')}), product NDC {html.escape(ndc or 'none')}</h1>
<p class="muted">{html.escape(labeler or '')}. SPL set <code>{set_id}</code>, version {version} ({vkind}), {split.replace('_', '-')} split. Drug-label and terminology data; no patient records.</p>
{f'<p>{html.escape(title_note)}</p>' if title_note else ''}
<h2>Field-level round trip against a separate read of the source XML</h2>
<p class="muted">Each column is one representation of the same record. The first column shows the source value.</p>
<div class="tablewrap" tabindex="0" role="region" aria-label="Round-trip results"><table><thead><tr><th scope="col">Attribute (source value)</th>{head}</tr></thead><tbody>{''.join(body)}</tbody></table></div>
<h2>Matching results</h2>
<div class="tablewrap" tabindex="0" role="region" aria-label="Matching results"><table><thead><tr><th scope="col">Approach</th><th scope="col">Outcome</th><th scope="col">RxCUI</th><th scope="col">Candidates</th><th scope="col">Score</th></tr></thead><tbody>{''.join(mrows)}</tbody></table></div>
<p class="muted">A: package NDC to RxNorm NDC status. A2: DailyMed set-level mapping file (agreement with A). B: normalized names with matched attributes. C: approximate name match with abstention. Agreement is terminology agreement, not clinical interchangeability.</p>
<div class="grid">
<section><h2>Source SPL product element</h2><pre tabindex="0">{html.escape(xml_text)}</pre></section>
<section><h2>FHIR R4 Medication resources{more}</h2><pre tabindex="0">{html.escape(fhir_text)}</pre></section>
<section><h2>Sidecar entries</h2><pre tabindex="0">{html.escape(side_text)}</pre></section>
</div></main></body></html>"""
    path = Path(out) if out else OUTPUTS / "viewer" / f"{document_id}-{index}.html"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(page)
    return path
