"""Fast offline demo on a small bundled fixture.

The fixture (fixtures/demo/) holds a few real development-split labels reduced
to their document header and product data elements section (the narrative
label text is removed), plus the cached RxNorm API responses those labels
need. It exercises parsing, the database load and checks, identifier
crosswalk, FHIR export, the round trip and the shortcut comparisons. It is a
software demonstration; its numbers are not study results.

`medid demo` copies the fixture into a scratch workspace and runs the stages
there with their own PostgreSQL cluster (port 55436), so it never touches the
study database.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from lxml import etree

from .paths import ROOT

FIXTURE = ROOT / "fixtures" / "demo"


def _strip_to_product_data(xml: bytes) -> bytes:
    """Keep the document header and the product data elements section only."""
    root = etree.fromstring(xml, etree.XMLParser(resolve_entities=False, no_network=True))
    ns = "{urn:hl7-org:v3}"
    body = root.find(f"{ns}component/{ns}structuredBody")
    if body is not None:
        for comp in list(body):
            sec = comp.find(f"{ns}section")
            code = None if sec is None else sec.find(f"{ns}code")
            if code is None or code.get("code") != "48780-1":
                body.remove(comp)
    title = root.find(f"{ns}title")
    if title is not None:
        for child in list(title):
            title.remove(child)
        title.text = (title.text or "").strip()[:200]
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8")


def build_fixture(setids: list[str]) -> dict:
    """Write fixtures/demo from the study cache (run in the project, not the demo)."""
    from .acquire import package_ndcs_of
    from .corpus import iter_documents, manifest
    from . import ndc as ndc_mod
    from .rxnav import RxNav
    if FIXTURE.exists():
        shutil.rmtree(FIXTURE)
    (FIXTURE / "data" / "raw").mkdir(parents=True)
    m = manifest()
    keep = set(setids)
    labels = [dict(e) for e in m["labels"] if e["setid"] in keep]
    prev = [dict(p) for p in m["preceding_versions"] if p["setid"] in keep]
    rx = RxNav()
    rx_paths = set()

    def copy_raw(rel: str) -> None:
        src = ROOT / rel
        dst = FIXTURE / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.suffix == ".xml" and "rxnav" not in rel:
            dst.write_bytes(_strip_to_product_data(src.read_bytes()))
        else:
            shutil.copy2(src, dst)
        meta = src.with_name(src.name.rsplit(".", 1)[0] + ".meta.json") if not src.name.endswith(".meta.json") else None
        if meta and meta.exists():
            mm = json.loads(meta.read_text())
            if dst.suffix == ".xml":
                import hashlib
                mm["sha256_original"] = mm["sha256"]
                mm["sha256"] = hashlib.sha256(dst.read_bytes()).hexdigest()
                mm["bytes_original"] = mm["bytes"]
                mm["bytes"] = dst.stat().st_size
                mm["note"] = "fixture: product data elements section only"
            (dst.with_name(meta.name)).write_text(json.dumps(mm, indent=1))

    for e in labels:
        copy_raw(e["current_xml"]["path"])
        if e.get("packaging"):
            copy_raw(e["packaging"]["path"])
        e["current_xml"] = dict(e["current_xml"], sha256=json.loads((FIXTURE / e["current_xml"]["path"]).with_name(
            Path(e["current_xml"]["path"]).name.rsplit(".", 1)[0] + ".meta.json").read_text())["sha256"])
    for p in prev:
        for a in p["attempts"]:
            if a["result"] == "ok":
                src = ROOT / a["xml_path"]
                dst = FIXTURE / a["xml_path"]
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(_strip_to_product_data(src.read_bytes()))
                import hashlib
                a["xml_sha256"] = hashlib.sha256(dst.read_bytes()).hexdigest()
                a["zip"] = dict(a["zip"], path=a["xml_path"], sha256=a["xml_sha256"], note="fixture keeps the extracted XML only")
    mf = m["rxnorm_mapping_file"]
    # the mapping file is reduced to the fixture's set IDs
    import io
    import zipfile
    with zipfile.ZipFile(ROOT / mf["path"]) as zf:
        name = next(n for n in zf.namelist() if n.endswith(".txt"))
        lines = zf.read(name).decode().splitlines()
    sub = [lines[0]] + [ln for ln in lines[1:] if ln.split("|", 1)[0] in keep]
    dst = FIXTURE / mf["path"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr(name, "\n".join(sub) + "\n")
    dst.write_bytes(buf.getvalue())
    man = dict(m, labels=labels, version_subset=[s for s in m["version_subset"] if s in keep], preceding_versions=prev,
               candidate_setids=len(labels), rxnorm_mapping_file=dict(mf, note="fixture: rows for fixture set IDs only"))
    (FIXTURE / "data" / "interim").mkdir(parents=True, exist_ok=True)
    (FIXTURE / "data" / "interim" / "label_manifest.json").write_text(json.dumps(man, indent=1))
    # RxNav responses needed by those labels
    rxm = json.loads((ROOT / "data" / "interim" / "rxnorm_manifest.json").read_text())
    ndc11 = {}
    for doc, meta in iter_documents():
        if meta["setid"] not in keep:
            continue
        for code in package_ndcs_of(doc, meta["products_in_scope"]):
            p = ndc_mod.parse(code)
            if p.kind == "package":
                ndc11[p.to_11()] = code
    rxcuis = set()
    for n in ndc11:
        f = rx.ndcstatus(n)
        rx_paths.add(f.meta()["path"])
        s = f.json().get("ndcStatus") or {}
        if s.get("rxcui"):
            rxcuis.add(s["rxcui"])
        for h in s.get("ndcHistory") or []:
            rxcuis |= {h.get("activeRxcui"), h.get("originalRxcui")} - {None, ""}
    rxcuis |= set(rxm["approach_b_candidates"])
    for c in sorted(rxcuis):
        rx_paths.add(rx.historystatus(c).meta()["path"])
    rx_paths.add(rx.allconcepts().meta()["path"])
    rx_paths.add(rx.version(refresh=False).meta()["path"])
    for pth in sorted(rx_paths):
        copy_raw(pth)
        mp = (ROOT / pth).with_name(Path(pth).name.rsplit(".", 1)[0] + ".meta.json")
        shutil.copy2(mp, FIXTURE / Path(pth).with_name(mp.name))
    rx.close()
    rxm_fix = dict(rxm, ndc11_to_original=ndc11, ndcstatus_count=len(ndc11), historystatus_count=len(rxcuis))
    (FIXTURE / "data" / "interim" / "rxnorm_manifest.json").write_text(json.dumps(rxm_fix, indent=1))
    (FIXTURE / "data" / "interim" / "rxnorm_historystatus_index.json").write_text(json.dumps(sorted(rxcuis)))
    for name in ("study.toml", "scope_frozen.json", "normalization.toml"):
        (FIXTURE / "config").mkdir(exist_ok=True)
        shutil.copy2(ROOT / "config" / name, FIXTURE / "config" / name)
    readme = ("Demo fixture: real DailyMed labels from the development split reduced to their header and product data "
              "elements section, with the RxNorm API responses they need (RxNorm release "
              f"{rxm['rxnorm_version'].get('version')}). Software demonstration only; not study data.\n"
              "Set IDs: " + ", ".join(sorted(keep)) + "\n"
              "This product uses publicly available data from the U.S. National Library of Medicine (NLM), National "
              "Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product "
              "and does not endorse or recommend this or any other product.\n")
    (FIXTURE / "README.txt").write_text(readme)
    return {"labels": len(labels), "preceding": len(prev), "rxnav_files": len(rx_paths)}


def run_demo() -> dict:
    """Copy the fixture to a scratch workspace and run the offline stages there."""
    if not FIXTURE.exists():
        raise SystemExit("fixtures/demo is missing")
    work = Path(tempfile.mkdtemp(prefix="medid-demo-"))
    shutil.copytree(FIXTURE, work, dirs_exist_ok=True)
    for name in ("src", "sql", "schemas"):
        shutil.copytree(ROOT / name, work / name, dirs_exist_ok=True)
    env = dict(os.environ, MEDID_ROOT=str(work), MEDID_PGPORT="55436", PYTHONPATH=str(work / "src"))
    code = (
        "from medid.build import build; from medid.rxload import load_rxnorm; from medid.match_run import run_matching;"
        "from medid.fhir_export import export; from medid.roundtrip_run import run_roundtrip;"
        "import json; out={}; out['build']=build()['table_rows']; out['rxnorm']=load_rxnorm();"
        "out['matching']=run_matching(); out['fhir']=export(); out['roundtrip']=run_roundtrip();"
        "import csv; rows=list(csv.DictReader(open('outputs/roundtrip/records.csv')));"
        "out['reversible_records_all_critical_ok']=sum(1 for r in rows if r['representation']=='R1_full' and r['all_critical_ok']=='True');"
        "out['reversible_records']=sum(1 for r in rows if r['representation']=='R1_full');"
        "from medid import db; db.stop(); print('DEMO_RESULT '+json.dumps(out))"
    )
    r = subprocess.run([sys.executable, "-c", code], cwd=work, env=env, capture_output=True, text=True)
    line = next((ln for ln in r.stdout.splitlines() if ln.startswith("DEMO_RESULT ")), None)
    if r.returncode != 0 or not line:
        raise SystemExit(f"demo failed (exit {r.returncode}):\n{r.stdout[-2000:]}\n{r.stderr[-3000:]}")
    result = json.loads(line[len("DEMO_RESULT "):])
    result["workspace"] = str(work)
    result["note"] = "Demo fixture only (software check); not evidence that the full study ran."
    if os.environ.get("MEDID_KEEP_DEMO") != "1":
        shutil.rmtree(work, ignore_errors=True)
        result["workspace"] = "(removed)"
    return result
