"""Static SVG charts for the report, manuscript and project page.

Hand-built SVG so every mark carries a <title> (a native hover tooltip), text
uses the neutral ink colors rather than series colors, gridlines are 1px and
light, and markers have a 2px ring in the background color. Palette (checked
with a palette validator, light mode): accent #2470cc, contrast #eb6834.
Series are also told apart by marker shape (filled and hollow circles), so
color is never the only channel. Each chart is written in a wide and a narrow layout.
"""
from __future__ import annotations

import html

SURFACE = "#fcfcfb"
INK = "#1d1d1b"
INK2 = "#52514e"
MUTED = "#6b6a65"
GRID = "#e4e2dc"
ACCENT = "#2470cc"
CONTRAST = "#eb6834"
FONT = "system-ui,-apple-system,'Segoe UI',Roboto,sans-serif"


def _t(x, y, s, size=13, color=INK, anchor="start", weight=400):
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" fill="{color}" text-anchor="{anchor}" '
            f'font-weight="{weight}" font-family="{FONT}">{html.escape(str(s))}</text>')


def _wrap(text: str, limit: int) -> list[str]:
    words, line, lines = text.split(), "", []
    for w in words:
        if line and len(line) + len(w) + 1 > limit:
            lines.append(line)
            line = w
        else:
            line = f"{line} {w}".strip()
    if line:
        lines.append(line)
    return lines


def dot_chart(rows: list[dict], title: str, subtitle: str, width: int = 760, narrow: bool = False,
              legend: tuple[str, str] = ("Preserved exactly", "Preserved exactly or after a documented conversion"),
              note: str | None = "Share of applicable critical fields.",
              show_heading: bool = True) -> str:
    """Horizontal dot chart on a 0-100% axis.

    rows: [{"label", "value", "value2" (optional, >= value), "tip", "tip2"}]
    value is drawn as a filled accent dot, value2 as a hollow ring joined by a
    thin line, so the gap between them reads as "only after conversion".
    """
    label_w = 120 if narrow else 230
    width = 360 if narrow else width
    tlines = _wrap(title, 40) if narrow else [title]
    slimit = 54 if narrow else 100
    slines = _wrap(subtitle, slimit)[:5 if narrow else 3]
    if not show_heading:  # print figures: the journal legend carries the title
        tlines, slines = [], []
    head = 24 + 18 * (len(tlines) - 1) + 15 * len(slines)
    top, row_h = head + (62 if narrow else 44), 34 if narrow else 30
    left, right = label_w + 12, width - 24
    h = top + row_h * len(rows) + 46
    plot_w = right - left
    sx = lambda v: left + plot_w * v / 100.0  # noqa: E731
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {h}" width="100%" role="img" '
           f'aria-labelledby="t d" style="max-width:{width}px;background:{SURFACE}">',
           f'<title id="t">{html.escape(title)}</title><desc id="d">{html.escape(subtitle)}</desc>',
           f'<rect width="{width}" height="{h}" fill="{SURFACE}"/>']
    for k, ln in enumerate(tlines):
        out.append(_t(12, 24 + 18 * k, ln, 15, INK, weight=600))
    y0 = 24 + 18 * (len(tlines) - 1) + 18
    for k, ln in enumerate(slines):
        out.append(_t(12, y0 + 15 * k, ln, 12, INK2))
    # legend
    ly = top - 12
    out.append(f'<circle cx="{left + 6}" cy="{ly - 4}" r="5" fill="{ACCENT}" stroke="{SURFACE}" stroke-width="2"/>')
    out.append(_t(left + 16, ly, legend[0], 12, INK2))
    lx2 = left + 16 + 7.2 * len(legend[0]) + 18
    if narrow:
        lx2 = 18
        ly2 = ly + 0
        out[-1] = _t(28, ly - 14, legend[0], 11, INK2)
        out[-2] = f'<circle cx="18" cy="{ly - 18}" r="5" fill="{ACCENT}" stroke="{SURFACE}" stroke-width="2"/>'
        out.append(f'<circle cx="{lx2}" cy="{ly2 - 4}" r="4.5" fill="{SURFACE}" stroke="{ACCENT}" stroke-width="2"/>')
        out.append(_t(lx2 + 10, ly2, legend[1], 11, INK2))
    else:
        out.append(f'<circle cx="{lx2}" cy="{ly - 4}" r="4.5" fill="{SURFACE}" stroke="{ACCENT}" stroke-width="2"/>')
        out.append(_t(lx2 + 10, ly, legend[1], 12, INK2))
    # grid
    for v in (0, 25, 50, 75, 100):
        x = sx(v)
        out.append(f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + row_h * len(rows)}" stroke="{GRID}" stroke-width="1"/>')
        out.append(_t(x, top + row_h * len(rows) + 18, f"{v}%", 11, MUTED, "middle"))
    for i, r in enumerate(rows):
        y = top + row_h * i + row_h / 2
        out.append(_t(left - 10, y + 4, r.get("short", r["label"]) if narrow else r["label"], 12 if narrow else 13, INK, "end"))
        v, v2 = r["value"], r.get("value2")
        if v2 is not None and v2 > v + 0.05:
            out.append(f'<line x1="{sx(v):.1f}" y1="{y}" x2="{sx(v2):.1f}" y2="{y}" stroke="{ACCENT}" stroke-width="2" opacity="0.45"/>')
            out.append(f'<g><title>{html.escape(r.get("tip2", ""))}</title><circle cx="{sx(v2):.1f}" cy="{y}" r="5" '
                       f'fill="{SURFACE}" stroke="{ACCENT}" stroke-width="2"/><circle cx="{sx(v2):.1f}" cy="{y}" r="11" fill="transparent"/></g>')
        out.append(f'<g><title>{html.escape(r.get("tip", ""))}</title><circle cx="{sx(v):.1f}" cy="{y}" r="6" fill="{ACCENT}" '
                   f'stroke="{SURFACE}" stroke-width="2"/><circle cx="{sx(v):.1f}" cy="{y}" r="12" fill="transparent"/></g>')
        f1 = lambda x: "100%" if x >= 99.95 else f"{x:.1f}%"  # noqa: E731
        lab = f1(v)
        if v2 is not None and v2 > v + 0.05:
            lab = f"{f1(v)} exact, {f1(v2)} with conversion" if not narrow else f"{f1(v)} / {f1(v2)}"
        tx = sx(max(v, v2 or 0)) + 10
        anchor = "start"
        if tx + 6.3 * len(lab) > width - 4:
            tx, anchor = sx(min(v, v2 if v2 is not None else v)) - 12, "end"
        out.append(_t(tx, y + 4, lab, 12, INK2, anchor))
    if note:
        out.append(_t(12, h - 8, note, 11, MUTED))
    out.append("</svg>")
    return "\n".join(out)


def stacked_bars(rows: list[dict], cats: list[tuple[str, str, str]], title: str, subtitle: str,
                 width: int = 760, narrow: bool = False, note: str | None = None,
                 show_heading: bool = True) -> str:
    """Horizontal 100% stacked bars. cats: [(key, label, color)]; rows: [{"label", key: count, ...}]."""
    width = 360 if narrow else width
    label_w = 100 if narrow else 200
    left, right = label_w + 12, width - 20
    tlines = _wrap(title, 40) if narrow else [title]
    slines = _wrap(subtitle, 54 if narrow else 100)
    if not show_heading:
        tlines, slines = [], []
    # legend layout with wrapping
    items, lx, ly0 = [], 12, 0
    rows_used = 1
    for key, lab, col in cats:
        w = 14 + 6.4 * len(lab) + 16
        if lx + w > width - 8:
            lx, rows_used = 12, rows_used + 1
        items.append((lx, rows_used - 1, lab, col))
        lx += w
    head = 24 + 18 * (len(tlines) - 1) + 15 * len(slines) + 8
    top, row_h, bar_h = head + 18 * rows_used + 16, 36, 20
    h = top + row_h * len(rows) + (40 if note else 8)
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {h}" width="100%" role="img" '
           f'aria-labelledby="t2 d2" style="max-width:{width}px;background:{SURFACE}">',
           f'<title id="t2">{html.escape(title)}</title><desc id="d2">{html.escape(subtitle)}</desc>',
           f'<rect width="{width}" height="{h}" fill="{SURFACE}"/>']
    for k, ln in enumerate(tlines):
        out.append(_t(12, 24 + 18 * k, ln, 15, INK, weight=600))
    y0 = 24 + 18 * (len(tlines) - 1) + 18
    for k, ln in enumerate(slines):
        out.append(_t(12, y0 + 15 * k, ln, 12, INK2))
    ly_base = head + 14
    for lx, row, lab, col in items:
        ly = ly_base + 18 * row
        out.append(f'<rect x="{lx:.1f}" y="{ly - 9}" width="10" height="10" rx="2" fill="{col}"/>')
        out.append(_t(lx + 14, ly, lab, 12, INK2))
    for i, r in enumerate(rows):
        y = top + row_h * i
        total = sum(r[c[0]] for c in cats) or 1
        out.append(_t(left - 10, y + bar_h / 2 + 4, r.get("short", r["label"]) if narrow else r["label"], 12, INK, "end"))
        x = left
        for key, lab, col in cats:
            w = (right - left) * r[key] / total
            if w <= 0:
                continue
            out.append(f'<g><title>{html.escape(r["label"])}: {html.escape(lab)} {r[key]:,} of {total:,} '
                       f'({100 * r[key] / total:.1f}%)</title><rect x="{x:.1f}" y="{y}" width="{max(w - 2, 0.5):.1f}" '
                       f'height="{bar_h}" rx="2" fill="{col}"/></g>')
            if w > 44:
                tc = "#ffffff" if col in (ACCENT, "#1c5cab") else INK
                out.append(_t(x + w / 2 - 1, y + bar_h / 2 + 4, f"{100 * r[key] / total:.0f}%", 11, tc, "middle"))
            x += w
    if note:
        out.append(_t(12, h - 10, note, 11, MUTED))
    out.append("</svg>")
    return "\n".join(out)
