"""Matching approaches B (normalized exact names plus matched attributes) and
C (approximate names with abstention).

Rules that were tuned on the development split live in config/normalization.toml
and are frozen before the held-out evaluation (docs/analysis_plan.md, section 4).
"""
from __future__ import annotations

import re
import tomllib
from fractions import Fraction
from functools import lru_cache

from rapidfuzz import fuzz, process

from .paths import CONFIG
from .quantity import fraction_to_decimal_text, is_decimal_text, to_fraction


@lru_cache(maxsize=1)
def rules() -> dict:
    return tomllib.loads((CONFIG / "normalization.toml").read_text())


def norm_name(s: str | None) -> str:
    s = (s or "").lower()
    s = re.sub(r"\s+", " ", s).strip()
    for a, b in rules()["names"]["replace"]:
        s = s.replace(a, b)
    return s.strip()


# --- strength ---------------------------------------------------------------------

def spl_strength_rx(num_value, num_unit, den_value, den_unit) -> tuple[Fraction, str, str] | None:
    """SPL strength in RxNorm conventions: (value per one denominator unit, num unit, den unit)."""
    if not (is_decimal_text(num_value) and num_unit):
        return None
    units = rules()["units"]
    if num_unit not in units:
        return None
    n_unit, n_factor = units[num_unit]
    value = to_fraction(num_value) * Fraction(n_factor)
    if den_unit in (None, "", "1"):
        if den_value not in (None, "1") and not (is_decimal_text(den_value) and to_fraction(den_value) == 1):
            return None
        return value, n_unit, "EACH"
    if den_unit not in units:
        return None
    d_unit, d_factor = units[den_unit]
    if not is_decimal_text(den_value):
        return None
    den = to_fraction(den_value) * Fraction(d_factor)
    if den == 0:
        return None
    return value / den, n_unit, d_unit


def rx_strength(s: dict) -> tuple[Fraction, str, str] | None:
    try:
        num = to_fraction(s["numeratorValue"])
        den = to_fraction(s["denominatorValue"] or "1")
    except (ValueError, TypeError, KeyError):
        return None
    if den == 0:
        return None
    return num / den, (s.get("numeratorUnit") or "").upper(), (s.get("denominatorUnit") or "EACH").upper()


def strength_text(t: tuple[Fraction, str, str] | None) -> str | None:
    if t is None:
        return None
    v = fraction_to_decimal_text(t[0])
    return None if v is None else (f"{v} {t[1]}" if t[2] == "EACH" else f"{v} {t[1]}/{t[2]}")


# --- dose form -----------------------------------------------------------------------

def rx_dose_forms(form_display: str | None, routes: list[str], package_forms: list[str]) -> set[str]:
    """RxNorm dose form names compatible with an SPL dosage form, route and packaging."""
    df = rules()["dose_forms"]
    key = (form_display or "").upper()
    out = set(df.get("by_form", {}).get(key, []))
    for rule in df.get("by_form_and_package", []):
        if rule["form"] == key and any(pf.upper() in rule["package_forms"] for pf in package_forms):
            out |= set(rule["rxnorm"])
    for rule in df.get("by_form_and_route", []):
        if rule["form"] == key and any(r in rule["routes"] for r in routes):
            out |= set(rule["rxnorm"])
    return out


# --- B: signature match -------------------------------------------------------------

def brand_of(rx_name: str) -> str | None:
    m = re.search(r"\[([^\]]+)\]\s*$", rx_name or "")
    return m.group(1) if m else None


def _tokens(s: str | None) -> set[str]:
    return set(re.findall(r"[a-z]+", (s or "").lower()))


def is_generic_label(proprietary: str | None, generic: str | None, ingredient_names: list[str] | None = None) -> bool:
    """A label is generic when its proprietary name says nothing beyond the generic
    and ingredient names and dose-form words (rule v1, tuned on the development split)."""
    p = norm_name(proprietary)
    if not p:
        return True
    allowed = _tokens(generic) | set(rules()["names"]["generic_stopwords"])
    for n in ingredient_names or []:
        allowed |= _tokens(n)
    return _tokens(p) <= allowed or p in rules()["names"]["generic_proprietary_names"]


_NAME_PIECE = re.compile(r"(?:^|(?<=\s))(?P<name>[a-z][^0-9]*?) (?P<val>\d+(?:\.\d+)?) "
                         r"(?P<unit>(?:MG|UNT|MEQ|ML|MCG|ACTUAT|BAU|CELLS)(?:/(?:ML|MG|ACTUAT|HR))?)\b")


def name_ingredients(rx_name: str) -> list[tuple[str, str]]:
    """(basis-of-strength substance, strength) pairs as written in an RxNorm name.

    RxNorm names put the basis-of-strength substance before each strength
    ("metformin hydrochloride 500 MG / sitagliptin 50 MG Oral Tablet"). Leading
    qualitative distinctions and quantity factors ("Osmotic 24 HR", "3 ML") and
    the bracketed brand are skipped."""
    base = re.sub(r"\s*\[[^\]]+\]\s*$", "", rx_name or "")
    out = []
    for piece in base.split(" / "):
        m = _NAME_PIECE.search(piece)
        if not m:
            return []
        val = fraction_to_decimal_text(to_fraction(m.group("val")))
        out.append((norm_name(m.group("name")), f"{val} {m.group('unit')}"))
    return out


def candidate_signature(c: dict) -> dict:
    ings = [(norm_name(s.get("bossName")), strength_text(rx_strength(s))) for s in c["strengths"]]
    named = name_ingredients(c["name"])
    return {
        "ingredients": tuple(sorted(ings)),
        "ingredients_by_name": tuple(sorted(named)) if len(named) == len(ings) else None,
        "dose_forms": {d["name"] for d in c["dose_forms"] if d.get("name")},
        "quantity_factor": (c["quantity_factor_value"], (c["quantity_factor_unit"] or "").upper()) if c.get("quantity_factor_value") else None,
        "brand": brand_of(c["name"]),
        "tty": c["tty"],
        "qualitative_distinction": c.get("qualitative_distinction"),
    }


_SUFFIX = re.compile(r"\b([a-z]+(?: [a-z]+)*)-([a-z]{4})\b")


def biosimilar_name(boss: str, generic_name: str | None) -> str:
    """'insulin glargine' + generic 'insulin glargine-yfgn' -> 'insulin glargine-yfgn'."""
    if not rules()["names"].get("biosimilar_suffix_from_generic_name"):
        return boss
    g = norm_name(generic_name)
    for m in _SUFFIX.finditer(g):
        if m.group(1).endswith(boss) or boss.endswith(m.group(1)):
            return f"{boss}-{m.group(2)}"
    return boss


def spl_signature(product, package=None, chain=None) -> dict:
    ings = []
    for i in product.active_ingredients():
        _, bname = i.strength_substance()
        ings.append((biosimilar_name(norm_name(bname), product.generic_name),
                     strength_text(spl_strength_rx(i.num_value, i.num_unit, i.den_value, i.den_unit))))
    qf = None
    package_forms = [p.form_display or "" for p in product.packages]
    if chain:
        inner = chain[0]
        if inner.qty_num_unit and inner.qty_num_unit not in ("1",) and is_decimal_text(inner.qty_num_value):
            u, f = rules()["units"].get(inner.qty_num_unit, (None, 1))
            if u:
                qf_val = fraction_to_decimal_text(to_fraction(inner.qty_num_value) * Fraction(f))
                qf = (qf_val, u)
        package_forms = [c.form_display or "" for c in chain]
    return {
        "ingredients": tuple(sorted(ings)),
        "dose_forms": rx_dose_forms(product.form_display, product.route_displays, package_forms),
        "quantity_factor": qf,
        "branded": not is_generic_label(product.proprietary_name, product.generic_name,
                                        [x for i in product.active_ingredients() for x in [i.substance_name, *i.moiety_names]]),
        "generic_name_tokens": _tokens(product.generic_name),
        "brand_names": brand_candidates(product),
    }


def brand_candidates(product) -> set[str]:
    p = norm_name(product.proprietary_name)
    s = norm_name(product.name_suffix)
    out = {p}
    if s:
        out.add(f"{p} {s}")
    for suffix in rules()["names"]["device_suffixes"]:
        if s.endswith(suffix) or s == suffix:
            out.add(p)
    return {x for x in out if x}


def match_b(sig: dict, candidates: list[dict], use_qf: bool, device_forms: set[str] | None = None) -> dict:
    """Candidates whose ingredients, strengths, dose form, quantity factor and brand all match.

    The quantity factor is compared only for device dose forms (pens, prefilled
    syringes, cartridges), where RxNorm puts the fill volume in the concept;
    vials and oral forms carry no quantity factor in RxNorm."""
    hits = []
    device_forms = device_forms or set()
    for c in candidates:
        cs = c["sig"]
        if any(v is None for _, v in sig["ingredients"]):
            continue
        if cs["ingredients"] != sig["ingredients"] and cs["ingredients_by_name"] != sig["ingredients"]:
            continue
        common = cs["dose_forms"] & sig["dose_forms"]
        if not common:
            continue
        cqf = cs["quantity_factor"] if cs["quantity_factor"] and cs["quantity_factor"][1] in rules()["quantity_factor"]["comparable_units"] else None
        if use_qf and (common & device_forms) and cqf != sig["quantity_factor"]:
            continue
        if use_qf and not (common & device_forms) and cqf is not None:
            continue
        if sig["branded"]:
            if cs["tty"] not in ("SBD", "BPCK") or norm_name(cs["brand"]) not in sig["brand_names"]:
                continue
        elif cs["tty"] not in ("SCD", "GPCK"):
            continue
        hits.append(c["rxcui"])
    hits = sorted(set(hits))
    if len(hits) > 1:
        by = {c["rxcui"]: c["sig"] for c in candidates}
        # tie-break 1: RxNorm's name states the basis-of-strength substance
        named = [h for h in hits if by[h]["ingredients_by_name"] == sig["ingredients"]]
        if named:
            hits = named
    if len(hits) > 1:
        # tie-break 2: precise ingredient words that only the SPL generic name carries (e.g. biosimilar suffixes)
        by = {c["rxcui"]: c for c in candidates}
        def extra(h):
            words = set()
            for n, _ in name_ingredients(by[h]["name"]):
                words |= set(re.findall(r"[a-z]+", n))
            return words
        scored = [h for h in hits if extra(h) <= (sig.get("generic_name_tokens", set()) | set(re.findall(r"[a-z]+", " ".join(n for n, _ in sig["ingredients"]))))]
        if scored and len(scored) < len(hits):
            hits = scored
    return {"outcome": "unique" if len(hits) == 1 else "ambiguous" if hits else "none",
            "rxcui": hits[0] if len(hits) == 1 else None, "candidates": hits}


# --- C: approximate names ---------------------------------------------------------------

def c_normalize(s: str) -> str:
    s = s.lower()
    s = re.sub(r"[^a-z0-9.%/ ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def c_query(product) -> str:
    parts = [product.proprietary_name or "", product.name_suffix or "", product.generic_name or ""]
    for i in product.active_ingredients():
        parts.append(f"{i.num_value or ''} {i.num_unit or ''}" + (f"/{i.den_value} {i.den_unit}" if i.den_unit not in (None, "1") else ""))
    parts.append(product.form_display or "")
    return c_normalize(" ".join(parts))


class ApproxMatcher:
    def __init__(self, concepts: list[dict]):
        self.rxcuis = [c["rxcui"] for c in concepts]
        self.names = [c_normalize(c["name"]) for c in concepts]

    def top2(self, query: str):
        res = process.extract(query, self.names, scorer=fuzz.token_sort_ratio, limit=2)
        s1 = res[0][1] if res else 0.0
        s2 = res[1][1] if len(res) > 1 else 0.0
        r1 = self.rxcuis[res[0][2]] if res else None
        return r1, s1, s2

    @staticmethod
    def decide(r1, s1, s2, tau: float, delta: float) -> dict:
        if r1 is None or s1 < tau or (s1 - s2) < delta:
            return {"outcome": "abstain", "rxcui": None}
        return {"outcome": "unique", "rxcui": r1}
