"""Second, separately written reader of the critical SPL attributes.

The round-trip check compares what comes back out of FHIR (plus sidecar)
against this reader's view of the immutable source XML, not against the
canonical objects that produced the FHIR. It uses the standard-library
ElementTree, shares no code with medid.spl, and extracts only the attributes
the primary outcome needs. It is a software cross-check by the same author,
not external validation.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

V3 = "{urn:hl7-org:v3}"
NDC_OID = "2.16.840.1.113883.6.69"


def _get(el, tag):
    return None if el is None else el.find(V3 + tag)


def _val(el, tag, attr):
    child = _get(el, tag)
    return None if child is None else child.get(attr)


def _active(entity):
    rows = []
    for ing in entity.findall(V3 + "ingredient"):
        cls = ing.get("classCode") or ""
        if not cls.startswith("ACTI"):
            continue
        q = _get(ing, "quantity")
        num = _get(q, "numerator")
        den = _get(q, "denominator")
        sub = _get(ing, "ingredientSubstance")
        moieties, moiety_names = [], []
        if sub is not None:
            for am in sub.findall(f"{V3}activeMoiety/{V3}activeMoiety"):
                c = am.find(V3 + "code")
                n = am.find(V3 + "name")
                if c is not None:
                    moieties.append(c.get("code"))
                    moiety_names.append(None if n is None else " ".join("".join(n.itertext()).split()))
        ref = ref_name = None
        if sub is not None:
            ds = sub.find(f"{V3}asEquivalentSubstance/{V3}definingSubstance/{V3}code")
            dn = sub.find(f"{V3}asEquivalentSubstance/{V3}definingSubstance/{V3}name")
            ref = None if ds is None else ds.get("code")
            ref_name = None if dn is None else " ".join("".join(dn.itertext()).split())
        name_el = None if sub is None else sub.find(V3 + "name")
        rows.append({
            "class_code": cls,
            "unii": _val(sub, "code", "code"),
            "name": None if name_el is None else " ".join("".join(name_el.itertext()).split()),
            "moiety_uniis": tuple(sorted(set(m for m in moieties if m))),
            "moiety_names": tuple(moiety_names),
            "reference_unii": ref,
            "reference_name": ref_name,
            "num_value": None if num is None else num.get("value"),
            "num_unit": None if num is None else num.get("unit"),
            "den_value": None if den is None else den.get("value"),
            "den_unit": None if den is None else den.get("unit"),
        })
    return rows


def _package_ndcs(entity):
    """Every NDC on a container reachable through asContent, in document order."""
    found = []

    def visit(holder):
        for ac in holder.findall(V3 + "asContent"):
            cpp = ac.find(V3 + "containerPackagedProduct")
            if cpp is None:
                continue
            code = cpp.find(V3 + "code")
            if code is not None and code.get("codeSystem") == NDC_OID and code.get("code"):
                found.append(code.get("code"))
            visit(cpp)

    visit(entity)
    return found


def _package_details(entity):
    """Package-level attributes of every NDC-bearing container, in document order
    (sensitivity analysis 3: package-version grain)."""
    found = []

    def visit(holder):
        for ac in holder.findall(V3 + "asContent"):
            cpp = ac.find(V3 + "containerPackagedProduct")
            if cpp is None:
                continue
            code = cpp.find(V3 + "code")
            if code is not None and code.get("codeSystem") == NDC_OID and code.get("code"):
                num = ac.find(f"{V3}quantity/{V3}numerator")
                act = None
                for so in ac.findall(V3 + "subjectOf"):
                    act = so.find(V3 + "marketingAct")
                    if act is not None:
                        break
                found.append({
                    "ndc": code.get("code"),
                    "form_code": _val(cpp, "formCode", "code"),
                    "qty_value": None if num is None else num.get("value"),
                    "qty_unit": None if num is None else num.get("unit"),
                    "marketing_status": _val(act, "statusCode", "code"),
                    "marketing_start": None if act is None else _val(act.find(V3 + "effectiveTime"), "low", "value"),
                })
            visit(cpp)

    visit(entity)
    return found


def read_critical(path: Path | bytes) -> dict:
    data = path.read_bytes() if isinstance(path, Path) else path
    root = ET.fromstring(data)
    doc = {
        "document_id": _val(root, "id", "root"),
        "set_id": _val(root, "setId", "root"),
        "version_number": _val(root, "versionNumber", "value"),
        "products": [],
    }
    for section in root.iter(V3 + "section"):
        if _val(section, "code", "code") != "48780-1":
            continue
        for subject in section.findall(V3 + "subject"):
            role = subject.find(V3 + "manufacturedProduct")
            if role is None:
                continue
            entity = role.find(V3 + "manufacturedProduct")
            if entity is None:
                continue
            code = entity.find(V3 + "code")
            parts = []
            for part in entity.findall(V3 + "part"):
                pp = part.find(V3 + "partProduct")
                if pp is None:
                    continue
                parts.append({
                    "ndc": _val(pp, "code", "code"),
                    "form_code": _val(pp, "formCode", "code"),
                    "active": _active(pp),
                    "package_ndcs": _package_ndcs(pp),
                })
            routes = [r.get("code") for r in role.findall(f"{V3}consumedIn/{V3}substanceAdministration/{V3}routeCode")]
            doc["products"].append({
                "product_ndc": None if code is None else code.get("code"),
                "form_code": _val(entity, "formCode", "code"),
                "active": _active(entity),
                "package_ndcs": _package_ndcs(entity),
                "packages": _package_details(entity),
                "parts": parts,
                "route_codes": routes,
            })
    return doc
