"""Project paths. Everything is resolved relative to the project root so the
pipeline runs from any checkout location."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(os.environ.get("MEDID_ROOT", Path(__file__).resolve().parents[2]))

CONFIG = ROOT / "config"
DATA = ROOT / "data"
RAW = DATA / "raw"
INTERIM = DATA / "interim"
OUTPUTS = ROOT / "outputs"
DOCS = ROOT / "docs"
SQL = ROOT / "sql"
SCHEMAS = ROOT / "schemas"
EVIDENCE = ROOT / "evidence"
HANDOFF = ROOT / "handoff"
LOCAL = ROOT / ".local"
TOOLS = LOCAL / "tools"


def ensure(*dirs: Path) -> None:
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
