"""Acquisition stage: label manifest, eligibility, version subset, preceding
versions and RxNorm lookups. Every network response goes through the cached
Fetcher, so rerunning this stage is cheap and offline once complete."""
from __future__ import annotations

import hashlib
import json
import tomllib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import ndc as ndc_mod
from .dailymed import RX_DOC_TYPE, DailyMed, xml_from_zip
from .http import rel, utc_now
from .paths import CONFIG, INTERIM, RAW, ROOT, ensure
from .rxnav import PRODUCT_TTYS, RxNav
from .spl import parse_spl

GROUP_ORDER = ["insulin", "glp1", "sglt2", "atorvastatin", "lisinopril", "metformin"]


def load_config():
    cfg = tomllib.loads((CONFIG / "study.toml").read_text())
    scope = json.loads((CONFIG / "scope_frozen.json").read_text())
    return cfg, scope


def h(salt: str, kind: str, setid: str) -> str:
    return hashlib.sha256(f"{salt}:{kind}:{setid}".encode()).hexdigest() if kind else \
        hashlib.sha256(f"{salt}:{setid}".encode()).hexdigest()


def split_of(setid: str, salt: str, dev_fraction: float) -> str:
    v = int(hashlib.sha256(f"{salt}:{setid}".encode()).hexdigest()[:8], 16) / 2 ** 32
    return "development" if v < dev_fraction else "held_out"


def unii_groups(scope: dict) -> dict[str, str]:
    out = {}
    for g in scope["groups"]:
        for ing in g["ingredients"]:
            for u in ing["uniis"] + [x for p in ing["pins"] for x in p["uniis"]]:
                out[u] = g["group"]
    return out


def product_groups(product, ugroups: dict) -> set[str]:
    found = set()
    ingredient_sets = [product.ingredients] + [p.ingredients for p in product.parts]
    for ings in ingredient_sets:
        for i in ings:
            if not i.is_active:
                continue
            for u in [i.substance_code] + list(i.moiety_codes):
                if u in ugroups:
                    found.add(ugroups[u])
    return found


def primary_group(groups: set[str]) -> str | None:
    for g in GROUP_ORDER:
        if g in groups:
            return g
    return None


def acquire_labels(log=print) -> dict:
    cfg, scope = load_config()
    ensure(INTERIM)
    dm = DailyMed(cfg["http"]["dailymed_rate_per_second"])
    ugroups = unii_groups(scope)
    salt = cfg["study"]["split_salt"]
    started = utc_now()
    mapping = dm.mapping_file()
    log(f"mapping file {mapping.size} bytes sha256 {mapping.sha256[:12]}")

    def fetch(setid):
        rec = {"setid": setid}
        try:
            x = dm.current_xml(setid)
            rec["current_xml"] = x.meta()
            rec["history"] = dm.history(setid)
            try:
                rec["packaging"] = dm.packaging(setid).meta()
            except Exception as e:  # packaging endpoint is a shortcut baseline only
                rec["packaging_error"] = str(e)
        except Exception as e:
            rec["error"] = str(e)
        return rec

    ids = scope["candidate_setids"]
    with ThreadPoolExecutor(max_workers=6) as ex:
        recs = []
        for k, r in enumerate(ex.map(fetch, ids), 1):
            recs.append(r)
            if k % 100 == 0:
                log(f"  labels fetched {k}/{len(ids)}")

    labels = []
    for r in recs:
        entry = {"setid": r["setid"], "status": None}
        if "error" in r:
            entry.update(status="not_retrieved", reason=r["error"])
            labels.append(entry)
            continue
        doc = parse_spl(ROOT / r["current_xml"]["path"])
        groups, in_scope = set(), []
        for p in doc.products:
            g = product_groups(p, ugroups)
            if g:
                in_scope.append(p.index)
                groups |= g
        versions = sorted({int(v["spl_version"]) for v in r["history"]}, reverse=True)
        entry.update({
            "document_id": doc.document_id, "version_number": doc.version_number,
            "effective_time": doc.effective_time, "doc_type_code": doc.doc_type_code,
            "title": (doc.title or "")[:300], "labeler_name": doc.labeler_name,
            "products_total": len(doc.products), "products_in_scope": in_scope,
            "groups": sorted(groups), "primary_group": primary_group(groups),
            "history_versions": versions,
            "history_published": {str(v["spl_version"]): v.get("published_date") for v in r["history"]},
            "current_xml": r["current_xml"], "packaging": r.get("packaging"),
            "packaging_error": r.get("packaging_error"),
            "split": split_of(r["setid"], salt, cfg["study"]["development_fraction"]),
        })
        if (doc.set_id or "").lower() != r["setid"].lower():
            entry.update(status="excluded", reason="XML setId differs from requested set ID")
        elif not doc.products and "no product data elements section" in doc.parse_warnings:
            entry.update(status="excluded", reason="legacy SPL format without a product data elements section")
        elif doc.doc_type_code != RX_DOC_TYPE:
            entry.update(status="excluded", reason=f"document type {doc.doc_type_code}")
        elif not in_scope:
            entry.update(status="excluded", reason="no in-scope active ingredient")
        else:
            entry["status"] = "eligible"
        labels.append(entry)

    eligible = [e for e in labels if e["status"] == "eligible"]
    per_group = cfg["study"]["version_subset_per_group"]
    subset = []
    for g in GROUP_ORDER:
        pool = [e for e in eligible if e["primary_group"] == g and len(e["history_versions"]) >= 2]
        pool.sort(key=lambda e: h(salt, "version", e["setid"]))
        subset += [e["setid"] for e in pool[:per_group]]
    ceiling = cfg["study"]["label_version_ceiling"]
    if len(eligible) + len(subset) > ceiling:
        raise SystemExit("ceiling exceeded: deterministic sampling rule must be applied (analysis plan section 2)")

    by_id = {e["setid"]: e for e in labels}
    previous = []

    def fetch_prev(setid):
        e = by_id[setid]
        cur = int(e["version_number"])
        tried = []
        for v in [x for x in e["history_versions"] if x < cur]:
            z = dm.version_zip(setid, v)
            if z is None:
                tried.append({"version": v, "result": "not_archived"})
                continue
            name, xml = xml_from_zip(z.bytes())
            out_path = RAW / "dailymed" / "versions" / setid / f"v{v}_{name}"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            if not out_path.exists():
                out_path.write_bytes(xml)
            d = parse_spl(xml)
            ok = (d.set_id or "").lower() == setid.lower() and d.version_number == str(v)
            tried.append({"version": v, "result": "ok" if ok else "mismatch",
                          "document_id": d.document_id, "zip": z.meta(), "xml_member": name,
                          "xml_path": rel(out_path), "xml_sha256": hashlib.sha256(xml).hexdigest()})
            if ok:
                return {"setid": setid, "current_version": cur, "preceding_version": v, "attempts": tried}
        return {"setid": setid, "current_version": cur, "preceding_version": None, "attempts": tried}

    with ThreadPoolExecutor(max_workers=4) as ex:
        previous = list(ex.map(fetch_prev, subset))
    dm.close()

    manifest = {
        "started_utc": started, "finished_utc": utc_now(),
        "rxnorm_mapping_file": mapping.meta(),
        "candidate_setids": len(ids),
        "labels": labels,
        "version_subset": subset,
        "preceding_versions": previous,
    }
    (INTERIM / "label_manifest.json").write_text(json.dumps(manifest, indent=1))
    log(f"eligible {len(eligible)} of {len(ids)}; version subset {len(subset)}; "
        f"preceding retrieved {sum(1 for p in previous if p['preceding_version'] is not None)}")
    return manifest


def package_ndcs_of(doc, products: list[int]) -> list[str]:
    out = []
    for p in doc.products:
        if p.index not in products:
            continue
        for k in p.packages:
            if k.ndc_original:
                out.append(k.ndc_original)
        for part in p.parts:
            for k in part.packages:
                if k.ndc_original:
                    out.append(k.ndc_original)
    return out


def acquire_rxnorm(log=print) -> dict:
    """NDC status for every in-scope package NDC, concept history for every
    RxCUI those lookups or the DailyMed crosswalk mention, and the candidate
    dictionaries for matching approaches B and C."""
    from .crosswalk import load_dailymed_mapping
    from .corpus import iter_documents

    cfg, scope = load_config()
    rx = RxNav(cfg["http"]["rxnav_rate_per_second"])
    version = rx.version().json()
    ndc11s, unrecognized = {}, []
    for doc, meta in iter_documents():
        for code in package_ndcs_of(doc, meta["products_in_scope"]):
            p = ndc_mod.parse(code)
            if p.kind == "package":
                ndc11s[p.to_11()] = code
            else:
                unrecognized.append(code)
    log(f"package NDCs {len(ndc11s)} (unrecognized pattern {len(unrecognized)})")
    status = rx.many(lambda n: rx.ndcstatus(n).json(), sorted(ndc11s), workers=14)
    rxcuis = set()
    for js in status.values():
        s = js.get("ndcStatus") or {}
        if s.get("rxcui"):
            rxcuis.add(s["rxcui"])
        for hrec in s.get("ndcHistory") or []:
            for k in ("activeRxcui", "originalRxcui"):
                if hrec.get(k):
                    rxcuis.add(hrec[k])
    mapping = load_dailymed_mapping()
    manifest = json.loads((INTERIM / "label_manifest.json").read_text())
    eligible_ids = {e["setid"] for e in manifest["labels"] if e["status"] == "eligible"}
    for row in mapping:
        if row["setid"] in eligible_ids and row["tty"] in PRODUCT_TTYS:
            rxcuis.add(row["rxcui"])
    # Candidate dictionary for approach B: products related to every ingredient
    # concept (IN, PIN, MIN) that appears in the seed ingredients' related graph.
    seeds = [r for g in scope["groups"] for i in g["ingredients"] for r in [i["rxnorm_in"]]]
    cand = set()
    for s in seeds:
        js = rx.related(s, PRODUCT_TTYS).json()
        for g in (js.get("relatedGroup") or {}).get("conceptGroup") or []:
            for c in g.get("conceptProperties") or []:
                cand.add(c["rxcui"])
    rxcuis |= cand
    log(f"RxCUIs for historystatus {len(rxcuis)} (approach B candidates {len(cand)})")
    (INTERIM / "rxnorm_historystatus_index.json").write_text(json.dumps(sorted(rxcuis)))
    hist = rx.many(lambda c: rx.historystatus(c).json(), sorted(rxcuis), workers=14)
    # second pass: remap targets and SCDs of branded concepts, so S-rx can follow them
    extra = set()
    for js in hist.values():
        h = js.get("rxcuiStatusHistory") or {}
        d = h.get("derivedConcepts") or {}
        for r in d.get("remappedConcept") or []:
            if r.get("remappedRxCui"):
                extra.add(r["remappedRxCui"])
        scd = d.get("scdConcept") or {}
        if scd.get("scdConceptRxcui"):
            extra.add(scd["scdConceptRxcui"])
    extra -= rxcuis
    if extra:
        hist.update(rx.many(lambda c: rx.historystatus(c).json(), sorted(extra), workers=14))
        rxcuis |= extra
        (INTERIM / "rxnorm_historystatus_index.json").write_text(json.dumps(sorted(rxcuis)))
    allc = rx.allconcepts().meta()
    rx.close()
    out = {
        "rxnorm_version": version, "retrieved_utc": utc_now(),
        "ndc11_to_original": ndc11s, "unrecognized_ndcs": unrecognized,
        "ndcstatus_count": len(status), "historystatus_count": len(hist),
        "approach_b_candidates": sorted(cand), "allconcepts": allc,
    }
    (INTERIM / "rxnorm_manifest.json").write_text(json.dumps(out, indent=1))
    return out
