"""Package stage: source archive (allowlist), site downloads, handoff files
and the outer bundle deliverables/05-medication-identity-PROJECT-BUNDLE.zip.

The source archive holds code, SQL, schemas, configuration, tests, the demo
fixture, documentation, analysis outputs and the FHIR outputs. It never holds
the virtual environment, the database cluster, raw downloads, validator jars,
caches, private notes or version-control data. Every text file is scanned for
local paths and credential-like strings before it is written.
"""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from .paths import HANDOFF, OUTPUTS, ROOT, ensure

SLUG = "medication-identity"
BUNDLE = ROOT / "deliverables" / "05-medication-identity-PROJECT-BUNDLE.zip"
SITE = ROOT / "site" / "projects" / SLUG
SOURCE_ZIP = SITE / "downloads" / f"{SLUG}-source.zip"

ALLOW = [
    "README.md", "LICENSE", "NOTICE", "CITATION.cff", "pyproject.toml", "requirements.in", "requirements.lock", ".gitignore",
    "src/medid/*.py", "sql/*.sql", "schemas/*.json", "config/*.toml", "config/scope_frozen.json", "scripts/*.py",
    "tests/*.py", "tests/fixtures/*", "fixtures/demo/**/*",
    "docs/*.md", "docs/*.csv", "docs/*.json",
    "data/interim/*.json",
    "outputs/tables/*.csv", "outputs/figures/*", "outputs/analysis/*.json", "outputs/checks/*.json",
    "outputs/matching/*", "outputs/roundtrip/*.csv", "outputs/dictionary/*", "outputs/workbook/*.xlsx",
    "outputs/tableau/*.csv", "outputs/validation/summary.json", "outputs/runs/stage_log.jsonl",
    "outputs/source_manifest.json", "outputs/viewer/*.html", "outputs/fhir/bundles/*.json", "outputs/fhir/sidecars/*.json",
    "manuscript/*", "evidence/*.json",
]
# anywhere: environments, caches, private notes, version control; at the project root only: raw downloads,
# deliverables, the built site and the saved third-party evidence pages
DENY = re.compile(r"(^|/)(\.venv|\.local|\.git|__pycache__|\.pytest_cache)(/|$)|\.egg-info|"
                  r"^(data/raw|deliverables|site|docs/source_verification|docs/author_review)(/|$)|"
                  r"^scripts/write_validation_md\.py$")
# assembled from parts so that this file does not match its own pattern
LOCAL_PATH = re.compile("|".join(["/" + "Users/[A-Za-z0-9_.-]+", "/" + "home/[A-Za-z0-9_.-]+/", "/" + "private/tmp/",
                                  "C:" + r"\\Users\\"]))
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*['\"][^'\"]{8,}", re.I)
# Personal Gmail addresses must not reach the public archive or site.
# Funding, conflict and AI assistance disclosures are allowed; the pattern is split to avoid matching itself.
PRIVATE_TEXT = re.compile(r"\b[A-Z0-9._%+-]+@" + r"gmail\.com\b", re.I)
TEXT_SUFFIXES = {".py", ".md", ".csv", ".json", ".toml", ".sql", ".txt", ".html", ".svg", ".cff", ".in", ".lock", ".xml", ".jsonl", ""}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def source_files() -> list[Path]:
    seen = set()
    out = []
    for pattern in ALLOW:
        for p in sorted(ROOT.glob(pattern)):
            rel = p.relative_to(ROOT).as_posix()
            if p.is_file() and rel not in seen and not DENY.search(rel):
                seen.add(rel)
                out.append(p)
    return out


def scan(paths: list[Path], public: bool = True) -> list[str]:
    problems = []
    for p in paths:
        if p.suffix.lower() not in TEXT_SUFFIXES or p.stat().st_size > 60_000_000:
            continue
        text = p.read_text(errors="ignore")
        if LOCAL_PATH.search(text):
            problems.append(f"local path in {p.relative_to(ROOT)}")
        if SECRET.search(text):
            problems.append(f"credential-like string in {p.relative_to(ROOT)}")
        if public and PRIVATE_TEXT.search(text):
            problems.append(f"personal Gmail address in {p.relative_to(ROOT)}")
    return problems


def write_zip(zpath: Path, members: list[tuple[str, Path]]) -> dict:
    zpath.parent.mkdir(parents=True, exist_ok=True)
    tmp = zpath.with_suffix(".zip.part")
    fixed = (2026, 10, 7, 0, 0, 0)
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for arc, src in sorted(members):
            info = zipfile.ZipInfo(arc, date_time=fixed)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            zf.writestr(info, src.read_bytes(), compresslevel=9)
    with zipfile.ZipFile(tmp) as zf:
        bad = zf.testzip()
        if bad:
            raise SystemExit(f"zip integrity failure at {bad}")
        n = len(zf.namelist())
    tmp.replace(zpath)
    return {"path": str(zpath.relative_to(ROOT)), "files": n, "bytes": zpath.stat().st_size, "sha256": sha256(zpath)}


def build_source_zip() -> dict:
    files = source_files()
    problems = scan(files)
    if problems:
        raise SystemExit("refusing to package:\n" + "\n".join(problems[:20]))
    members = [(f"{SLUG}/{p.relative_to(ROOT).as_posix()}", p) for p in files]
    info = write_zip(SOURCE_ZIP, members)
    info["uncompressed_bytes"] = sum(p.stat().st_size for p in files)
    return info


def public_files() -> list[dict]:
    out = []
    for p in sorted(SITE.rglob("*")):
        if p.is_file():
            out.append({"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": sha256(p)})
    return out


def handoff_json(src: dict) -> dict:
    from .numbers import numbers, pct
    N = numbers()
    stage_log = [json.loads(x) for x in (OUTPUTS / "runs" / "stage_log.jsonl").read_text().splitlines() if x.strip()]
    findings = [
        ("Held-out product-version records with every applicable critical attribute preserved from FHIR R4 plus the companion record",
         N["h_r1_ok"], N["h_r1_n"], "outputs/tables/roundtrip_record_outcomes.csv"),
        ("Held-out active ingredients whose strength basis is misread from FHIR R4 core alone", N["h_core_boss_disc"], N["h_core_boss_n"],
         "outputs/tables/roundtrip_field_status.csv"),
        ("Distinct package NDCs changed by padding without the segment pattern", N["ndc_naive_wrong"], N["ndc_distinct"],
         "outputs/tables/shortcut_ndc_padding.csv"),
        ("Held-out products with the wrong ingredient count in DailyMed packaging.json", N["h_api_count_disc"], N["h_api_count_n"],
         "outputs/tables/roundtrip_field_status.csv"),
        ("Approach B (normalized names plus attributes) answers agreeing with the NDC crosswalk", N["h_b_agree"], N["h_b_answered"],
         "outputs/tables/matching_agreement_with_A.csv"),
        ("Approach C (approximate names) answers disagreeing with the NDC crosswalk", N["h_c_wrong"], N["h_c_answered"],
         "outputs/tables/matching_agreement_with_A.csv"),
        ("Label version pairs with a product-identity change", N["v_any"], N["v_pairs"], "outputs/tables/version_changes_by_set.csv"),
    ]
    j = {
        "slug": SLUG,
        "title": "Medication identity from DailyMed labels to FHIR R4",
        "featured": False,
        "summary": (f"Drug-label and terminology data; no patient records. {N['eligible']:,} current DailyMed prescription labels for "
                    f"six cardiometabolic ingredient groups (plus {N['preceding_retrieved']} preceding versions) were parsed losslessly into "
                    f"PostgreSQL, written as FHIR R4 Medication resources with a schema-validated companion record, validated with the HL7 "
                    f"validator and read back against a separate parse of the source XML. FHIR plus the companion record preserved every "
                    f"critical attribute for {N['h_r1_ok']:,} of {N['h_r1_n']:,} held-out records; FHIR core alone misread the strength basis "
                    f"for {pct(N['h_core_boss_disc'], N['h_core_boss_n'])} of active ingredients, and unsegmented NDC padding changed "
                    f"{pct(N['ndc_naive_wrong'], N['ndc_distinct'])} of package NDCs."),
        "status": {
            "computational_completion": "complete",
            "manuscript": "complete; formatted for JAMIA Open (Research and Applications); not submitted",
            "unresolved_prerequisites": [],
            "full_validator": "ran (HL7 validator 7.0.0): all Bundles offline, 60-Bundle sample with terminology server",
        },
        "data_versions": {
            "dailymed_retrieval_utc": f"{N['retrieval']['spl_current_xml'][0]} to {N['retrieval']['spl_current_xml'][1]}",
            "dailymed_mapping_file_sha256": N["mapping_file_sha"],
            "rxnorm_release": N["rxnorm_release"], "rxnav_api_version": N["rxnav_api"],
            "fhir_version": "4.0.1", "validator": "validator_cli.jar 7.0.0 (" + N["validator_sha"] + ")",
        },
        "key_limitations": [
            "Census of six cardiometabolic ingredient groups at one retrieval date; not all medicines.",
            "One preceding version per label for 218 labels; RxNorm only as its current release plus its dated NDC history.",
            "The package-NDC crosswalk is a terminology reference with its own errors, not clinical ground truth.",
            "The companion record was designed to hold the measured attributes, so its complete preservation is partly by construction.",
            "The second XML reader is a software cross-check written by the same author.",
            "Terminology-server validation covered a 60-Bundle sample; the server's NDC content is dated 2021-11-01.",
        ],
        "entry_page": f"site/projects/{SLUG}/index.html",
        "report_page": f"site/projects/{SLUG}/report.html",
        "source_archive": f"site/projects/{SLUG}/downloads/{SLUG}-source.zip",
        "source_archive_bytes": src["bytes"], "source_archive_sha256": src["sha256"], "source_archive_files": src["files"],
        "executed_commands": sorted({f"medid {r['stage']}" for r in stage_log} | {"medid demo"}) + ["python -m pytest"],
        "stage_runs": [{"stage": r["stage"], "started_utc": r["started_utc"], "seconds": r["seconds"],
                        "code_fingerprint": r["code_fingerprint"]} for r in stage_log[-12:]],
        "measured_findings": [{"finding": f, "numerator": n, "denominator": d, "proportion": round(n / d, 6) if d else None,
                               "evidence": e} for f, n, d, e in findings],
        "public_files": public_files(),
    }
    ensure(HANDOFF)
    (HANDOFF / f"{SLUG}.json").write_text(json.dumps(j, indent=2))
    return j


def build_bundle() -> dict:
    members = [(p.relative_to(ROOT).as_posix(), p) for p in sorted(SITE.rglob("*")) if p.is_file()]
    for name in (f"{SLUG}.json", f"{SLUG}-validation.md", "verified_results.md"):
        p = HANDOFF / name
        if p.exists():
            members.append((f"handoff/{name}", p))
    sub = HANDOFF / "submission"
    for p in sorted(sub.rglob("*")) if sub.exists() else []:
        if p.is_file() and not p.name.startswith("_"):
            members.append((f"handoff/submission/{p.relative_to(sub).as_posix()}", p))
    binary = (".zip", ".docx", ".pdf", ".png", ".xlsx")
    problems = scan([p for a, p in members if p.suffix not in binary and a.startswith("site/")]) + \
        scan([p for a, p in members if p.suffix not in binary and not a.startswith("site/")], public=False)
    with zipfile.ZipFile(SOURCE_ZIP) as zf:  # the archive was scanned file by file; check the written bytes too
        for n in zf.namelist():
            if PRIVATE_TEXT.search(zf.read(n).decode("utf-8", "ignore")):
                problems.append(f"personal Gmail address in source archive member {n}")
    if problems:
        raise SystemExit("refusing to bundle:\n" + "\n".join(problems[:20]))
    info = write_zip(BUNDLE, members)
    return info


def package_all() -> dict:
    src = build_source_zip()
    s1 = HANDOFF / "submission" / "supplementary" / "S1_medication-identity-source.zip"
    if s1.parent.exists():  # the journal supplement is the same archive as the public download
        import shutil
        shutil.copy2(SOURCE_ZIP, s1)
    hj = handoff_json(src)
    b = build_bundle()
    return {"source_zip": src, "public_files": len(hj["public_files"]), "bundle": b,
            "built_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
