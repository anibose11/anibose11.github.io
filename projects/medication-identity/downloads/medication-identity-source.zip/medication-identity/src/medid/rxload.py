"""Load cached RxNav responses (ndcstatus, historystatus) into PostgreSQL."""
from __future__ import annotations

import json

from . import db
from .paths import INTERIM
from .rxnav import RxNav, history_status_record, ndc_status_record


def load_rxnorm(log=print) -> dict:
    m = json.loads((INTERIM / "rxnorm_manifest.json").read_text())
    rx = RxNav()
    files, st_rows, hist_rows, c_rows, s_rows = [], [], [], [], []
    rxcuis = set()
    for ndc11 in sorted(m["ndc11_to_original"]):
        f = rx.ndcstatus(ndc11)
        files.append((f.meta()["path"], "rxnav", f.url, f.sha256, f.size, f.retrieved_utc))
        rec = ndc_status_record(f.json())
        st_rows.append((ndc11, rec["status"], rec["rxcui"], rec["concept_name"], rec["concept_status"], f.meta()["path"]))
        for k, hrec in enumerate(rec["history"]):
            hist_rows.append((ndc11, k, hrec["active_rxcui"], hrec["original_rxcui"], hrec["start_yyyymm"], hrec["end_yyyymm"]))
    hist_index = json.loads((INTERIM / "rxnorm_historystatus_index.json").read_text())
    for rxcui in sorted(hist_index):
        f = rx.historystatus(rxcui)
        files.append((f.meta()["path"], "rxnav", f.url, f.sha256, f.size, f.retrieved_utc))
        rec = history_status_record(f.json())
        if not rec["rxcui"]:
            rec["rxcui"] = rxcui
        rxcuis.add(rxcui)
        c_rows.append((rxcui, rec["name"], rec["tty"], rec["status"], rec["is_current"], rec["active_start_mmyyyy"],
                       rec["active_end_mmyyyy"], rec["remapped_date_mmyyyy"], rec["quantity_factor_value"],
                       rec["quantity_factor_unit"], rec["qualitative_distinction"], rec["scd_rxcui"],
                       [r["rxcui"] for r in rec["remapped_to"] if r["rxcui"]],
                       [d["name"] for d in rec["dose_forms"] if d["name"]], f.meta()["path"]))
        for k, s in enumerate(rec["strengths"]):
            s_rows.append((rxcui, k, s["baseRxcui"], s["baseName"], s["bossRxcui"], s["bossName"],
                           s["activeIngredientRxcui"], s["activeIngredientName"], s["moietyRxcui"], s["moietyName"],
                           s["numeratorValue"], s["numeratorUnit"], s["denominatorValue"], s["denominatorUnit"]))
    rx.close()
    with db.connect() as conn:
        conn.execute("set search_path = medid")
        cur = conn.cursor()
        cur.executemany("insert into source_file values (%s,%s,%s,%s,%s,%s) on conflict do nothing", files)
        cur.executemany("insert into rx_ndc_status values (%s,%s,%s,%s,%s,%s)", st_rows)
        cur.executemany("insert into rx_ndc_history values (%s,%s,%s,%s,%s,%s)", hist_rows)
        cur.executemany("insert into rx_concept values (" + ",".join(["%s"] * 15) + ")", c_rows)
        cur.executemany("insert into rx_concept_strength values (" + ",".join(["%s"] * 14) + ")", s_rows)
        conn.commit()
    out = {"rx_ndc_status": len(st_rows), "rx_ndc_history": len(hist_rows), "rx_concept": len(c_rows),
           "rx_concept_strength": len(s_rows)}
    log(f"rxnorm load: {out}")
    return out
