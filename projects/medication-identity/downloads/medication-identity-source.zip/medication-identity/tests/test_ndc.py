"""Controlled fixtures for NDC parsing. These are software tests, not study data:
the codes are constructed to exercise each segment pattern."""
import pytest

from medid import ndc


@pytest.mark.parametrize("code,cfg,eleven", [
    ("1234-5678-90", "4-4-2", "01234567890"),
    ("12345-678-90", "5-3-2", "12345067890"),
    ("12345-6789-0", "5-4-1", "12345678900"),
])
def test_package_patterns_convert_with_segment_padding(code, cfg, eleven):
    p = ndc.parse(code)
    assert p.kind == "package"
    assert p.configuration == cfg
    assert p.to_11() == eleven
    assert ndc.from_11(eleven, cfg) == code


@pytest.mark.parametrize("code,naive,correct", [
    ("1234-5678-90", "01234567890", True),
    ("12345-678-90", "01234567890", False),
    ("12345-6789-0", "01234567890", False),
])
def test_naive_padding_is_only_right_for_4_4_2(code, naive, correct):
    assert ndc.naive_pad_11(code) == naive
    assert (ndc.naive_pad_11(code) == ndc.parse(code).to_11()) is correct


def test_three_different_ndcs_collide_under_naive_padding():
    codes = ["1234-5678-90", "12345-678-90", "12345-6789-0"]
    assert len({ndc.naive_pad_11(c) for c in codes}) == 1
    assert len({ndc.parse(c).to_11() for c in codes}) == 3


def test_product_codes():
    p = ndc.parse("0093-1048")
    assert p.kind == "product" and p.configuration == "4-4"
    assert p.product_code == "0093-1048"
    assert p.product_to_9() == "000931048"
    assert p.to_11() is None


@pytest.mark.parametrize("code", ["", "12345678901", "123-4567-89", "123456-7890-12", "12a4-5678-90", "1234--90"])
def test_unrecognized_patterns_are_not_guessed(code):
    p = ndc.parse(code)
    assert p.kind == "unrecognized"
    assert p.to_11() is None


def test_eleven_digit_form_alone_is_ambiguous():
    # 0123406789X style codes with several padding zeros fit more than one pattern
    assert ndc.candidate_configurations_from_11("01234067890") == ["4-4-2", "5-3-2"]
    assert ndc.candidate_configurations_from_11("12345678911") == []
    assert ndc.candidate_configurations_from_11("12345678901") == ["5-4-1"]
