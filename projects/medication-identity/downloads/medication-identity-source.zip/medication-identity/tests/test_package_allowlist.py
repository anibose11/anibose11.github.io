"""The source archive allowlist must include the demo fixture and exclude private and bulky material."""
from medid.package import DENY, LOCAL_PATH, source_files
from medid.paths import ROOT


def test_deny_rules_are_anchored_correctly():
    assert DENY.search("data/raw/dailymed/ab/x.xml")
    assert not DENY.search("fixtures/demo/data/raw/dailymed/ab/x.xml")
    assert DENY.search(".local/CHECKPOINT.md") and DENY.search("src/medid/__pycache__/x.pyc")
    assert DENY.search("site/projects/x/index.html") and not DENY.search("docs/site_notes.md")
    assert DENY.search("docs/source_verification/dailymed/x.html") and not DENY.search("docs/source_verification.md")


def test_local_path_pattern():
    assert LOCAL_PATH.search("/" + "Users/someone/project") and not LOCAL_PATH.search("users of the API")


def test_allowlist_contains_demo_fixture_when_present():
    rels = [p.relative_to(ROOT).as_posix() for p in source_files()]
    if (ROOT / "fixtures" / "demo" / "data" / "raw").exists():
        assert any(r.startswith("fixtures/demo/data/raw/") for r in rels)
    assert not any(r.startswith((".venv/", ".local/", "data/raw/", "deliverables/")) for r in rels)
