"""Software tests on a constructed SPL fixture (tests/fixtures/constructed_spl.xml).

These check the parser, FHIR builder, reverse transform and comparator on edge
cases. The fixture is invented; nothing here is a study observation.
"""
from pathlib import Path

import pytest

from medid.exact_json import dumps, loads_exact
from medid.fhir_build import SYS_NDC, build_bundle
from medid.fhir_reverse import reconstruct
from medid.independent_read import read_critical
from medid.roundtrip import compare, record_ok
from medid.spl import parse_spl

FIX = Path(__file__).parent / "fixtures" / "constructed_spl.xml"
SOURCE = {"source_url": "fixture", "source_path": "tests/fixtures/constructed_spl.xml",
          "source_sha256": "0" * 64, "retrieved_utc": "2026-10-07T00:00:00Z", "version_kind": "current"}


@pytest.fixture(scope="module")
def built(tmp_path_factory):
    doc = parse_spl(FIX)
    bundle, side = build_bundle(doc, SOURCE)
    d = tmp_path_factory.mktemp("fhir")
    bp, sp = d / "b.json", d / "s.json"
    bp.write_text(dumps(bundle))
    sp.write_text(dumps(side))
    return doc, bp, sp


def test_parser_reads_basis_of_strength_and_packages():
    doc = parse_spl(FIX)
    p0, kit = doc.products
    a, b = p0.active_ingredients()
    assert (a.class_code, a.strength_substance()) == ("ACTIM", ("MOIETY0001", "ALPHAMINE"))
    assert (b.class_code, b.strength_substance()[0]) == ("ACTIB", "BETAZOLE01")
    assert a.num_value == "0.50" and b.num_value == ".5"
    carton = next(k for k in p0.packages if k.ndc_original == "12345-678-90")
    assert (carton.ndc_configuration, carton.total_amount_value, carton.total_amount_status) == ("5-3-2", "28", "computed")
    assert kit.is_kit and len(kit.parts) == 2
    gamma = kit.parts[0].ingredients[0]
    assert gamma.strength_substance() == ("GAMMASALT1", "GAMMACIL SODIUM")
    delta = kit.parts[1].ingredients[0]
    assert delta.strength_substance() == (None, None)  # two moieties: the label does not say which
    assert kit.parts[0].packages[0].ndc_configuration == "5-4-1"


def test_decimal_text_survives_and_only_documented_fix_applies(built):
    _, bp, sp = built
    bundle = loads_exact(bp.read_text())
    prod = next(e["resource"] for e in bundle["entry"] if e["resource"].get("identifier", [{}])[0].get("value") == "12345-678"
                and "amount" not in e["resource"])
    values = [i["strength"]["numerator"]["value"] for i in prod["ingredient"] if "strength" in i]
    assert values == ["0.50", "0.5"]  # source 0.50 kept; source .5 gets the one JSON-grammar fix
    side = loads_exact(sp.read_text())
    flags = [i["json_decimal_normalized"] for m in side["medications"].values() if m["resource_level"] == "product"
             for i in m["ingredients"]]
    assert flags.count(True) == 1


def test_full_round_trip_preserves_every_critical_attribute(built):
    doc, bp, sp = built
    src = read_critical(FIX)
    full = reconstruct(bp, sp, "full")
    for i, sp_ in enumerate(src["products"]):
        rows = compare(src, sp_, full, full["products"][("index", i)], "R1_full")
        bad = [r for r in rows if r["status"] not in ("preserved", "preserved_normalized", "inapplicable")]
        assert not bad, bad
        assert record_ok(rows)


def test_core_only_misreads_moiety_and_reference_basis(built):
    _, bp, _ = built
    src = read_critical(FIX)
    core = reconstruct(bp, None, "core")
    rows = compare(src, src["products"][0], core, core["products"][("ndc", "12345-678")], "R_core", sidecar_available=True)
    boss = {r["item"]: r["status"] for r in rows if r["attribute"] == "K10_boss_unii"}
    assert boss == {"0": "discordant", "1": "preserved"}  # ACTIM misread, ACTIB right by default
    assert {r["status"] for r in rows if r["attribute"] in ("K1_set_id", "K3_version")} == {"omitted_in_sidecar"}
    assert not record_ok(rows)


def test_package_amount_and_ndc_codes_in_fhir(built):
    _, bp, _ = built
    bundle = loads_exact(bp.read_text())
    meds = [e["resource"] for e in bundle["entry"] if e["resource"]["resourceType"] == "Medication"]
    carton = next(m for m in meds if any(c.get("code") == "12345-678-90" for c in m.get("code", {}).get("coding", [])))
    assert carton["amount"]["numerator"]["value"] == "28"
    assert carton["amount"]["denominator"]["code"] == "C43182"
    kit = next(m for m in meds if any(i.get("value") == "5432-1098" and i["system"] == SYS_NDC for i in m.get("identifier", [])))
    assert [c["id"] for c in kit["contained"]] == ["part-1", "part-2"]
    prov = next(e["resource"] for e in bundle["entry"] if e["resource"]["resourceType"] == "Provenance")
    assert prov["entity"][0]["what"]["identifier"]["value"] == "urn:uuid:aaaaaaaa-0000-4000-8000-000000000001"


def test_narrative_sections_are_ignored():
    doc = parse_spl(FIX)
    assert len(doc.products) == 2 and not doc.parse_warnings
