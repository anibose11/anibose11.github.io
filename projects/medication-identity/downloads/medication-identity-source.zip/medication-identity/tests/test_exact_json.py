"""Controlled fixtures for exact decimal JSON (software tests)."""
import json

import pytest

from medid.exact_json import JsonNumber, dumps, loads_exact, number


@pytest.mark.parametrize("src,out,normalized", [
    ("0.50", "0.50", False),
    ("500", "500", False),
    ("12.5", "12.5", False),
    (".5", "0.5", True),
    ("5.", "5", True),
    ("05", "5", True),
    ("100.000", "100.000", False),
    ("1E3", "1E3", False),
])
def test_number_keeps_text_and_flags_normalization(src, out, normalized):
    n = number(src)
    assert n.text == out
    assert n.normalized is normalized


def test_dumps_writes_exact_tokens_and_loads_returns_them():
    doc = {"strength": {"numerator": {"value": number("0.50"), "unit": "mg"},
                        "denominator": {"value": number("1"), "unit": "mL"}},
           "list": [number("100.000"), "text"]}
    text = dumps(doc)
    assert '"value": 0.50' in text
    assert "100.000" in text
    back = loads_exact(text)
    assert back["strength"]["numerator"]["value"] == "0.50"
    assert back["list"][0] == "100.000"
    # still valid JSON for any consumer
    assert json.loads(text)["strength"]["numerator"]["value"] == 0.5


def test_floats_are_refused():
    with pytest.raises(TypeError):
        dumps({"x": 0.5})


@pytest.mark.parametrize("bad", ["abc", "1/2", "", "1,5"])
def test_non_decimals_are_refused(bad):
    with pytest.raises(ValueError):
        number(bad)


def test_marker_cannot_collide_with_text():
    text = dumps({"a": "num0", "b": number("2")})
    assert loads_exact(text) == {"a": "num0", "b": "2"}
    assert isinstance(number("2"), JsonNumber)
