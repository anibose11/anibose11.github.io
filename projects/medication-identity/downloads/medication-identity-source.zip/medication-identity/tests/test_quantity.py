"""Controlled fixtures for exact decimal and ratio arithmetic (software tests)."""
from fractions import Fraction

import pytest

from medid.quantity import (Ratio, float_roundtrip_text, fraction_to_decimal_text,
                            is_decimal_text, same_text, same_value, to_fraction)


@pytest.mark.parametrize("num,den,expected", [
    ("500", "5", "100"),
    ("2", "3", None),          # 0.666... does not terminate: must not be rounded
    ("1", "1", "1"),
    ("0.25", "0.5", "0.5"),
    ("100", "1", "100"),
    ("8", "3", None),
    ("2", "1.5", None),
    ("1.34", "1", "1.34"),
    ("12.5", "5", "2.5"),
])
def test_per_unit_denominator_is_exact_or_refused(num, den, expected):
    text, exact = Ratio(num, "mg", den, "mL").per_unit_denominator()
    assert text == expected
    assert exact is (expected is not None)


def test_zero_or_missing_denominator():
    assert Ratio("1", "mg", "0", "mL").per_unit_denominator() == (None, False)
    assert Ratio("1", "mg", None, "1").per_unit_denominator() == (None, False)


def test_fraction_to_decimal_text():
    assert fraction_to_decimal_text(Fraction(1, 8)) == "0.125"
    assert fraction_to_decimal_text(Fraction(1, 3)) is None
    assert fraction_to_decimal_text(Fraction(-5, 2)) == "-2.5"
    assert fraction_to_decimal_text(Fraction(200)) == "200"


def test_value_versus_text_equality():
    assert same_value("0.50", "0.5")
    assert not same_text("0.50", "0.5")
    assert same_value("500", "500.0")


def test_float_shortcut_changes_text_but_not_value():
    assert float_roundtrip_text("0.50") == "0.5"
    assert float_roundtrip_text("500") == "500.0"
    assert to_fraction(float_roundtrip_text("0.1")) == to_fraction("0.1")


@pytest.mark.parametrize("s,ok", [("1", True), ("0.5", True), (".5", True), ("1e3", True),
                                  ("", False), ("1/2", False), ("abc", False), (None, False)])
def test_is_decimal_text(s, ok):
    assert is_decimal_text(s) is ok
