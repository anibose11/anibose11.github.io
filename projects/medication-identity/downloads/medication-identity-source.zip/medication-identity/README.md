# medication-identity

Version-aware medication identity reconciliation from DailyMed Structured Product Labels and the public RxNorm API to FHIR R4 Medication resources, with an attribute-level round-trip evaluation and a reusable medication dictionary export.

The study asks which identity, strength, ingredient, dose-form, package and version details of real prescription drug labels survive representation in FHIR R4 and common matching and formatting shortcuts. It uses public drug-label and terminology data only; there are no patient records.

- Analysis plan and amendments: `docs/analysis_plan.md`
- Why this study, and what it adds: `docs/contribution_decision.md`, `docs/prior_art.csv`, `docs/literature_search.md`
- How each stage works: `docs/methods.md`; tables and columns: `docs/data_dictionary.md`
- Sources and their verified behavior: `docs/source_verification.md`
- Tableau import specification: `docs/tableau_spec.md`; the review sample of 30 held-out records: `docs/review_sample.csv`
- Every headline number with its source table, numerator and denominator: `evidence/claims.json`
- Checks: `scripts/tune_approach_c.py` (reproduces the approach C tuning grid), `scripts/rerun_check.py` (deterministic rerun comparison), `scripts/recheck.py` (fresh download of the review sample, recomputed headline numbers, reference resolution), `scripts/verify_bundle.py` (checks an unpacked delivery)

## Requirements

- Python 3.11 or later (developed on CPython 3.13.5, macOS 27 on arm64)
- PostgreSQL 16 or 17 server binaries (`initdb`, `pg_ctl`, `postgres`) on `PATH`, or set `MEDID_PG_BIN`. The pipeline creates and runs its own cluster under `.local/pgdata` (Unix socket only, port 55435), so no existing database is touched.
- Java 17 or later for the HL7 FHIR validator (developed with Temurin 21)
- Network access to dailymed.nlm.nih.gov, dailymed-data.nlm.nih.gov, rxnav.nlm.nih.gov, github.com, packages.fhir.org and tx.fhir.org (terminology sample only) for a full run; the demo runs offline

## Setup

```bash
python3 -m venv .venv
.venv/bin/pip install --require-hashes -r requirements.lock
.venv/bin/pip install --no-deps -e .
.venv/bin/python -m pytest
```

`requirements.lock` pins every package with SHA-256 hashes from PyPI.

## Fast demo (offline)

```bash
.venv/bin/medid demo
```

Runs build, RxNorm load, matching, FHIR export and the round trip on a bundled fixture of real development-split labels (reduced to their product data section) in a temporary workspace with its own PostgreSQL cluster on port 55436. It is a software demonstration; its numbers are not study results.

## Full study

```bash
.venv/bin/medid scope        # ingredient UNIIs and candidate labels (frozen in config/scope_frozen.json)
.venv/bin/medid acquire      # labels, history, preceding versions, packaging, RxNorm lookups (cached under data/raw)
.venv/bin/medid pipeline     # build, match, fhir, validate, roundtrip, analyze, render, package
```

Stages can also be run one at a time: `medid build`, `medid match`, `medid fhir`, `medid validate`, `medid roundtrip`, `medid analyze`, `medid render`, `medid package`. Network responses are cached once, so stages after `acquire` run offline. A full acquisition downloads about 530 MB (most of it archived label ZIPs with images) at no more than 4 requests per second to DailyMed and 8 per second to RxNav.

`src/medid/render.py` was edited on 17 October 2026, after the recorded runs, so that it reads the NDC columns of the results workbook as text and keeps their leading zeros. No estimate changes. Comments in a few other source files were tidied the same day. `src/medid/manuscript.py` was also repaired: this public copy had lost two lines, which stopped `medid render`.

`medid view <document_id>:<product_index>` writes a source-versus-FHIR comparison page for any product; `medid db start|stop|status` manages the local cluster.

### Validator

`medid validate` expects the official HL7 validator at `.local/tools/validator-7.0.0/validator_cli.jar`:

```bash
mkdir -p .local/tools/validator-7.0.0
curl -L -o .local/tools/validator-7.0.0/validator_cli.jar https://github.com/hapifhir/org.hl7.fhir.core/releases/download/7.0.0/validator_cli.jar
shasum -a 256 .local/tools/validator-7.0.0/validator_cli.jar   # 0ec7285b0f23999c25979533c6e9105f5f01087889fcc113ac1dfc65560bcc69
```

The stage refuses a jar with a different SHA-256. Its package cache is kept in `.local/validator-home`.

## Layout

```
src/medid/        pipeline code (CLI: medid)
sql/schema.sql    canonical layer and result tables
schemas/          JSON Schema for the FHIR companion record
config/           study settings, frozen scope, frozen normalization rules
tests/            software tests (constructed fixtures; not study data)
fixtures/demo/    demo fixture (real labels reduced to product data, cached RxNorm responses)
docs/             plan, methods, sources, literature, dictionary
outputs/          analysis tables, figures, workbook, dictionary export, validation and run logs
evidence/         claims.json
```

## License and data

Code: MIT license (`LICENSE`). Data and third-party notices: `NOTICE`. RxNorm content is shown as of release 05-Oct-2026 and may not reflect current NLM data. This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or recommend this or any other product.
