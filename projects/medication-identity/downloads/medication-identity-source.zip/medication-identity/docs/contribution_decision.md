# Contribution decision

Written 2026-10-07, before the study corpus was acquired and before any matching, FHIR export or round-trip result existed. Inputs at this point: the source verification notes (docs/source_verification.md), the literature search (docs/literature_search.md) and about a dozen labels inspected to learn the SPL structure.

## Who would use the output

Two groups maintain medication identity tables outside of any single EHR vendor:

- research data managers who load drug exposures into analysis databases (OMOP, PCORnet, registry warehouses) from NDC-coded sources and need to know what an NDC or RxCUI actually stood for when a record was made;
- maintainers of local medication dictionaries who build product tables from DailyMed labels and RxNorm and publish them as FHIR resources or flat files.

Both groups routinely take shortcuts: they pad NDCs to 11 digits without the segment pattern, keep only the current label version, match on names when identifiers are missing, collapse products to an ingredient or clinical-drug concept, or keep only what fits in the FHIR R4 core elements.

## Decision supported

Whether a given shortcut is safe for a given attribute. The output tells a dictionary maintainer, attribute by attribute, which identity and strength details survive (a) each matching approach and (b) each representation (FHIR R4 core alone, FHIR R4 with a documented companion record, an RxNorm-concept-only record, a typical flat export), measured on real labels.

## What is already established

- SPL labels can be linked to RxNorm at scale, mostly at ingredient level (Zhu, Jiang and Chute 2012; 97.0% of 36,568 SPLs linked).
- SPL and RxNorm agree on ingredient moieties for most SPL NDCs (Schadow 2007; 91% of 7,083).
- Historical NDC-to-RxCUI resolution is possible with RxNorm NDC history, and current-only lookups miss many historical NDCs (Peters and Bodenreider 2015, the basis of getNDCStatus).
- Free-text descriptions disagree with RxNorm attributes often (Lester et al. 2022).
- HL7 has an unpublished continuous-integration SPL-to-FHIR R5 mapping guide with two-way transforms.

So this project is not the first SPL-to-RxNorm mapping, not the first version-aware NDC mapping and not the first SPL-to-FHIR mapping. None of those works measures, field by field, what survives a round trip from a specific SPL version to FHIR R4 and back, or what each common shortcut costs on the same records.

## The narrow unresolved question

For a defined, current set of real cardiometabolic prescription labels, what fraction of product-version records can have all prespecified critical identity and strength attributes reconstructed, without unsupported inference, from (i) a reversible FHIR R4 representation with a documented sidecar, (ii) FHIR R4 core elements alone, and (iii) common shortcut representations? Which attributes are lost, and how often do matching shortcuts and version changes alter identity?

## Comparators

- Matching: source identifiers (package NDC to RxCUI through RxNorm NDC status) as the reference; normalized exact names with explicitly matched attributes; a reproducible approximate-name matcher with abstention. The DailyMed set-level SPL-to-RxNorm mapping file is a second, independent crosswalk for agreement.
- Representation: the reversible FHIR + sidecar representation against FHIR core alone, an RxCUI-only record, a flat export with naive NDC padding and float strengths, DailyMed's packaging endpoint, and a latest-version-only table.

## Estimand

Within the frozen held-out set of SPL set IDs, the proportion of in-scope product-version records for which every applicable critical attribute (set ID, document ID, version, product NDC, package NDCs, dosage form, active-ingredient count, and for each active ingredient its UNII, basis-of-strength code and substance, and exact strength numerator and denominator with units) is reconstructed exactly, compared against a separate read of the source XML. This describes a finite corpus at a retrieval date; it is not an estimate for all medicines.

## What would count as a useful negative result

- FHIR R4 core plus a sidecar still failing to reconstruct some attributes (for example kit parts or nested packages) would show where a reversible design needs more than R4 provides.
- The shortcut baselines losing little would show that common practice is adequate for these products, which is worth knowing.
- Identifier and name approaches agreeing almost everywhere would show that the extra machinery is not needed for this ingredient set.
- Version changes being rare would bound how much version awareness matters for product identity in these labels.

## Framing

An updated, attribute-level replication of the SPL-to-RxNorm linkage literature on a 2026 snapshot, extended with label-version awareness and a FHIR R4 round-trip benchmark, released as a reusable tool and dictionary export. Not "first", and not a clinical validation: a high preservation score means the data model kept what the label said, not that the label or the mapping is clinically right.
