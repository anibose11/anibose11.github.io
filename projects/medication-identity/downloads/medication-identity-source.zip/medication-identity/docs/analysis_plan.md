# Analysis plan

**Status.** Written 2026-10-07 between about 05:50 and 06:05 EDT (09:50 to 10:05 UTC) and committed to the project's local git history before the study corpus was acquired. This is an internal timestamped plan, not a formal preregistration in a public registry. Later changes are listed under "Amendments" with their date and reason.

**Prior exposure.** Before writing this plan I had inspected the structure of about a dozen SPL documents (Farxiga, Synjardy versions 1, 22 and 23, a VistaPharm metformin oral solution versions 8 and 9, Lipitor, Zestril, Lantus SoloStar, Humalog, Humulin N, Cerebyx, an Amphastar glucagon kit, an Appformin kit), DailyMed and RxNav API responses for those products, and the label counts returned by DailyMed name searches. No matching, FHIR export, validation or round-trip result had been computed. Three of the inspected labels are in scope; they are treated like any other label.

## 1. Sources and retrieval

- DailyMed web services v2 (`/spls.json`, `/spls/{setid}/history.json`, `/spls/{setid}.xml`, `/spls/{setid}/packaging.json`) and versioned label archives (`/dailymed/getFile.cfm?type=zip&setid=…&version=…`). Retrieval date 2026-10-07 (and 2026-10-08 if retrieval runs past midnight UTC; the exact time of every response is recorded).
- DailyMed SPL-to-RxNorm mapping file `rxnorm_mappings.zip` (set-ID level, current versions only), one snapshot.
- Public RxNorm API (RxNav), release reported by `/version` at retrieval (05-Oct-2026 at plan time). No licensed RxNorm files and no UMLS account.
- HL7 FHIR R4 4.0.1 with the official HL7 validator (validator_cli 7.0.0, SHA-256 verified).
Each response is cached once with its URL, time, size and SHA-256 (`source_manifest.json`).

## 2. Scope and eligibility (frozen before acquisition of the corpus)

**Ingredient groups.** metformin; SGLT2 inhibitors (empagliflozin, dapagliflozin); GLP-1 receptor agonists (semaglutide, liraglutide); insulins (glargine, lispro, aspart, degludec, detemir, human insulin including isophane); atorvastatin; lisinopril. The active-moiety UNIIs used for eligibility are taken from the labels and RxNorm by `medid scope` and written to `config/scope_frozen.json`, which is committed before the corpus is downloaded.

**Label eligibility.** An SPL set ID is eligible when, at retrieval, (a) DailyMed lists it as a current label, (b) its document type is LOINC 34391-3 HUMAN PRESCRIPTION DRUG LABEL, read from the XML itself, and (c) at least one manufactured product (or kit part) has an active ingredient (classCode beginning ACTI) whose active-moiety UNII is in the frozen set. Candidate set IDs come from DailyMed's `unii_code` filter (which matches active-moiety UNIIs) together with `drug_name` searches for each ingredient, so selection does not depend on RxNorm.

Consequences stated in advance: human regular, isophane and 70/30 insulins sold without a prescription are filed as OTC labels (34390-5) and fall outside this scope. Unapproved marketing categories, repackager and relabeler labels, kits and combination products are kept and flagged.

**Product scope.** Within an eligible label, a product is in scope when it (or one of its kit parts) contains a frozen-moiety active ingredient. Combination products are always kept whole: every active ingredient is analyzed, including partner ingredients outside the seed list. Other products in the same label (for example a diluent) are counted and excluded.

**Ceiling.** At most 2,000 SPL documents (current versions plus retrieved preceding versions). If eligible current set IDs plus the version subset would exceed it, current set IDs are sampled deterministically within ingredient group by ascending SHA-256 of `medid-split-v1:sample:{setid}` before any matching is run. The number of eligible set IDs and the number analyzed are both reported.

**Primary group.** For stratification each set ID gets one primary group, the first that applies in the order insulin, GLP-1, SGLT2, atorvastatin, lisinopril, metformin (rarer groups first so combinations land in them). Group-level tables count a product in every group it contains.

## 3. Version subset

For each primary group, the first 40 eligible set IDs (all, if fewer) in ascending SHA-256 of `medid-split-v1:version:{setid}` among those whose DailyMed history lists at least two versions. For each, the immediately preceding available version is the highest version number below the current one that DailyMed's archive returns as a valid SPL ZIP whose XML reports the same set ID and that version number. Versions that return 404 are recorded as unavailable and the next lower listed version is tried. No version is ever reconstructed or assumed.

RxNorm at a past date is not available from the public API. For preceding versions, RxNorm information is limited to what RxNorm itself publishes with dates: the NDC history months in `ndcstatus` and concept history in `historystatus`. Current RxNorm answers are never presented as historical.

## 4. Development and held-out split

Set IDs are assigned before any tuning: development when `int(sha256("medid-split-v1:" + setid)[:8], 16) / 2**32 < 0.30`, held-out otherwise. A set ID's current and preceding versions stay together. Normalization rules (approach B dose-form, unit and name rules; approach C threshold and margin) and any FHIR mapping fixes are developed on the development set only. They are frozen, recorded with a code fingerprint, and the held-out set is evaluated once. Fixes to unrelated packaging or reporting code after that point do not change frozen rules; if a correctness bug in the round-trip or parser is found after freezing, it is fixed, the held-out evaluation is rerun once, and the change is logged as an amendment.

Controlled fixtures (constructed NDCs, ratios and JSON numbers in `tests/`) test software only and never enter study tables.

## 5. Unit of analysis and denominators

- **Product-version record:** one in-scope manufactured product (identified by its position and product NDC) in one SPL document version. This is the unit of the primary outcome.
- **Package-version record:** one package NDC in one product-version record (secondary grain).
- **Active-ingredient record:** one active ingredient of a product or kit part.
- **Cluster:** SPL set ID. Versions, products and packages of one label are not treated as independent.

Counts are kept separate and reported separately: DailyMed candidate set IDs; eligible set IDs; SPL documents analyzed (current, preceding); product-version records; package-version records; active-ingredient records; development and held-out set IDs; RxNav and DailyMed calls; validator issues.

## 6. Matching approaches (secondary outcomes)

Evaluated on current-version product records, where current RxNorm is time-aligned with the label.

- **A. Source identifiers.** Each package NDC (converted to 11 digits using its own segment pattern) is looked up with RxNorm `ndcstatus`. A product's RxCUI is the single RxCUI shared by its package NDCs whose RxNorm status is ACTIVE. Outcomes: unique; ambiguous (packages disagree); not found (no package NDC known to RxNorm, or only OBSOLETE/ALIEN/UNKNOWN).
- **A2. DailyMed set-level crosswalk.** The RxCUIs that `rxnorm_mappings` lists for the set ID and version (SCD, SBD, GPCK, BPCK rows). Agreement: A's RxCUI is in A2's set.
- **B. Normalized exact names plus matched attributes.** For each active ingredient, the basis-of-strength substance name (from the classCode rule) is normalized and compared exactly with RxNorm basis-of-strength names; strength is converted to RxNorm conventions (per unit, or per mL for liquids, with exact arithmetic) and must match exactly; the SPL dosage form and route must map to the candidate's RxNorm dose form; a branded product must match the candidate's brand. Candidates are the current SCD, SBD, GPCK and BPCK concepts related to the ingredient RxCUIs, with structure from `historystatus`. Outcomes: unique, ambiguous, none.
- **C. Approximate names with abstention.** Query string: proprietary name, suffix, generic name, each active strength as labeled, and dosage form, lowercased with punctuation removed. Candidates: all current SCD, SBD, GPCK and BPCK names (`allconcepts`), normalized the same way. Score: `rapidfuzz.fuzz.token_sort_ratio`. The top candidate is accepted when its score is at least τ and exceeds the second by at least δ, otherwise the matcher abstains. τ ∈ {60, 62, …, 100} and δ ∈ {0, 1, 2, 3, 5, 8} are chosen on the development set to maximize (agreements with A minus disagreements with A); ties go to the larger τ, then the larger δ.

Reported for each approach: unique / ambiguous / none (or abstain); agreement with A at exact RxCUI and at clinical-drug (SCD) level; and, for disagreements, which attribute differs (ingredient set, strength, dose form, brand, quantity factor). Agreement with A is terminology agreement. It is not clinical interchangeability or prescribing equivalence.

## 7. FHIR representation and validation

R4 Medication resources (product level and package level) and one Provenance per SPL version, in one Bundle (type collection) per SPL version, plus a sidecar JSON per Bundle validated against `schemas/medication_sidecar.schema.json`. Element choices are fixed in `src/medid/fhir_build.py` and docs/methods.md. Validation: HL7 validator 7.0.0, `-version 4.0.1`, (i) all Bundles with `-tx n/a` (structure, cardinality, invariants, no terminology), and (ii) a deterministic sample of Bundles with the public terminology server tx.fhir.org, recording the code system versions it reports. Outcome: counts of errors, warnings and information messages by type. Passing validation is reported as structural conformance only; it is not evidence that codes or mappings are semantically right.

## 8. Round-trip fidelity (primary outcome)

The FHIR Bundles and sidecars are read back from disk by a separate reverse transform and compared with a separate read of the immutable source XML (`src/medid/independent_read.py`, standard-library parser, no shared code with the canonical parser). The intermediate objects that produced the FHIR are not used as the comparison target.

**Critical attributes (prespecified).** Per product-version record: K1 set ID; K2 document ID; K3 version number; K4 product NDC as written; K5 the set of package NDCs as written; K6 dosage form code; K7 number of active ingredients (kits: across parts); and for each active ingredient K8 substance UNII, K9 basis-of-strength class code, K10 basis-of-strength substance UNII, K11 strength numerator value (exact decimal text) and unit, K12 strength denominator value and unit. For kits additionally K13 the part NDCs.

**Field categories.** preserved (exact); preserved after the documented JSON decimal normalization (`.5` to `0.5`, counted separately); omitted from FHIR core but preserved in the sidecar; unresolved (cannot be reconstructed without inference); discordant (reconstructed but different); inapplicable (absent in the source); not evaluated (input could not be read). Exact numeric text preservation and documented unit conversions are tested and reported separately.

**Primary outcome.** Among held-out product-version records, the proportion for which every applicable critical attribute is preserved (exact, or after the documented JSON normalization) from FHIR plus sidecar. Records whose source lacks an attribute are not counted as failures for that attribute; their number is reported.

**Secondary representations, same records and same comparison.**
- R-core: FHIR core elements only, read with the default interpretation that a strength refers to the listed ingredient substance.
- S-rx: only the RxCUI from approach A, with attributes re-derived from current RxNorm (`historystatus`).
- S-flat: a flat export with NDCs padded to 11 digits by stripping hyphens and left-padding, strengths parsed as binary floats, and only the first active ingredient.
- S-api: strengths taken from DailyMed's `packaging.json` for the product's NDC.
- S-latest: for preceding-version records only, the attributes of the same product in the latest version.
Inapplicable fields are excluded from denominators, so a large number of inapplicable fields cannot inflate a preservation rate.

## 9. Version analysis (secondary)

For each version-subset set ID with a retrieved preceding version: changes between preceding and latest in product NDCs, package NDCs, active ingredients, basis of strength, strength, dosage form, route, marketing category, labeler and product count, using a canonical product fingerprint that ignores serialization differences (attribute order, an optional unit "1"). For package NDCs present only in the preceding version: RxNorm current status and the dated `ndcstatus` history. Reported as counts and proportions of set IDs.

## 10. Uncertainty

Results are a census of the defined corpus at the retrieval date and are described as finite-corpus proportions. As an exploratory measure of instability, 95% percentile intervals come from a cluster bootstrap that resamples set IDs with replacement (2,000 replicates, seed 20261007). These intervals are not inference to all medicines or all labels.

## 11. Sensitivity analyses (fixed set)

1. Primary outcome on the full corpus (development plus held-out).
2. Primary outcome excluding repackaged or relabeled products (products whose SPL names an equivalent source product).
3. Package-level attributes at package-version grain.
4. Approach C with τ moved 5 points down and up from the tuned value.

## 12. Missing data and statuses

Absent in source, inapplicable, not retrieved (HTTP 404 or not archived), not found in RxNorm, unresolved and not evaluated are kept as distinct values in every table. Zero is used only for measured zero counts.

## 13. What will not be claimed

Clinical validity of labels or mappings, interchangeability, FHIR terminology conformance beyond what the terminology-enabled validator run shows, historical RxNorm content beyond RxNorm's dated history fields, generalization beyond the corpus, uptake, endorsement or deployment.

## Development phase and freeze record

Work on the development split (439 set IDs) between 10:24 and 10:46 UTC on 2026-10-07, before any held-out result was computed:

- Approach B normalization rules went from v0 to v2 (`config/normalization.toml`, change log at the end of that file). Development agreement with approach A moved from 464 to 481 of 576 products with a unique A RxCUI; the remaining misses are kept as findings (release mechanism not stated in SPL product data, weight-management liraglutide, premixed insulins, kits).
- Approach C: τ = 74, δ = 0 from the prespecified grid (`outputs/matching/approach_c_tuning_development.csv`).
- Faults found by the development round trip and fixed: the reverse transform compared a product index read as text with an integer; document IDs written lowercase in FHIR `urn:uuid` values were compared case-sensitively (now a documented normalization); DailyMed packaging strengths without a denominator were not parsed; ingredients from two different documents were aligned by position instead of by UNII; one build check treated an inner package NDC listed under two outer packages as an error.
- Seven candidate labels in the legacy SPL format of 2006 to 2008 have no product data elements section and were excluded under the eligibility rule (section 2).

Frozen at 10:46 UTC with code fingerprint `95031b6a3dfc` (SHA-256 over `src/medid/*.py`, `config/*.toml`, `sql/*.sql`, `schemas/*.json`). The held-out evaluation runs once from this state.

## Amendments

1. 2026-10-07, after the held-out run, before any result was reported: in the S-rx comparison the SPL class code reconstructed from RxNorm's basis-of-strength concepts had been labelled "preserved" when equal. RxNorm does not carry the SPL class code, so equality is now labelled "converted_equivalent", and a basis RxNorm cannot classify (reference-substance basis) is "unresolved". Comparison labelling only; no frozen matching or mapping rule changed.
2. 2026-10-07, after the terminology-enabled validator sample: the label's substance name had been written as the UNII `coding.display`, which the validator flagged (30 errors) where the UNII preferred term differs. The name now goes only in `CodeableConcept.text`. FHIR export, validation, round trip and analysis were rerun; no round-trip attribute uses the display, and no matching rule changed.
3. 2026-10-07, while checking the draft against the data: in the S-rx comparison, RxNorm components that share an ingredient name (the 4-unit and 8-unit cartridges of an inhaled-insulin pack) were aligned with the label's kit parts by name only, which could swap them. Components are now aligned by name, then by strength, then by numerator value. Comparison code only; rerun of the round trip and analysis.
4. 2026-10-07, during the final review, before any result was reported: in the comparison, a product for which a representation reconstructed nothing had been scored with one row per critical attribute. It is now scored at each attribute's own grain, as for every other record: record-level attributes once, ingredient-level attributes once per source active ingredient, and kit part NDCs only for kits (inapplicable otherwise). This changes denominators for the shortcut representations only (RxCUI only, DailyMed packaging service, latest version); the primary outcome is unaffected. Comparison code only.
5. 2026-10-07, during the final review: ten active-ingredient records (six held-out), all atorvastatin calcium trihydrate, list the same active moiety twice. Both the parser and the second reader treated this as two moieties and left the basis-of-strength substance empty, so the round trip classed that field as inapplicable for them. A repeated moiety is now kept once in both readers (the parser records that it was repeated). This is a correctness fix to the parser under section 4; the canonical layer, matching, FHIR export, validation, round trip and analysis were rerun. No matching rule changed.
6. 2026-10-07, during the final review: the version comparison (section 9) compared ordered ingredient lists, so a label that only reordered its ingredients counted as an ingredient and strength change. Ingredients are now compared as unordered sets, and a strength is compared as a quantity of its basis-of-strength substance, so a salt-form change with the same moiety amount counts as an ingredient change only. Analysis code only.
7. 2026-10-07, clarification of section 2 to match the frozen rule: eligibility as implemented (config/scope_frozen.json, frozen before acquisition) matches a label ingredient's substance UNII or active-moiety UNII against 20 UNIIs taken from RxNorm ingredient and precise-ingredient concepts for the seed ingredients. The plan text had said active-moiety UNIIs "taken from the labels and RxNorm". No code changed.

Sensitivity analyses 3 and 4 (section 11) were computed in the final analysis run: `outputs/tables/roundtrip_sa3_package_grain.csv` and `outputs/tables/matching_sa4_approach_c_threshold.csv`. The approach C grid search that set τ and δ is reproduced by `scripts/tune_approach_c.py`.
