# Data dictionary

Database: project-local PostgreSQL 17, schema `medid` (`sql/schema.sql`). Text columns hold source values exactly as written; derived columns are named for what derives them. `NULL` means the source did not state the value; it never stands for zero.

## Value conventions

| Value | Meaning |
|---|---|
| `NULL` in a source column | absent in the source document |
| `inapplicable` (round trip) | the attribute does not exist for this record (for example package NDCs for a product with no NDC-coded package) |
| `unresolved` | the representation cannot give the value without inference |
| `not_retrieved` (manifest) | DailyMed did not return the document |
| `not_archived` (manifest) | DailyMed's archive returned 404 for that version |
| `UNKNOWN` (RxNorm NDC status) | RxNorm has no record of the NDC |
| `0` | a measured count of zero |

## Source and lineage

**source_file**: one row per cached file used by the study. `path` (project-relative), `kind` (spl_current_xml, spl_version_zip, spl_version_xml, dm_packaging, dm_mapping, rxnav), `url`, `sha256`, `bytes`, `retrieved_utc`.

**spl_document**: one row per analyzed SPL version. `document_id` (SPL `id/@root`), `set_id`, `version_number`, `version_kind` (current or preceding), `effective_time` (SPL effectiveTime, YYYYMMDD; not the DailyMed published date), `doc_type_code` (always 34391-3 here), `title`, `labeler_name`, `labeler_id` and `labeler_id_root` (DUNS when the root is 1.3.6.1.4.1.519.1), `split` (development or held_out, by set ID), `primary_group`, `groups`, `source_path`.

## Canonical product layer

**spl_product**: one row per manufactured product in a document. Key `document_id:product_index`. `in_scope` (contains a frozen-scope active ingredient), `ndc_original` (labeler-product code as written), `ndc_configuration` (4-4, 5-3, 5-4), `proprietary_name`, `name_suffix`, `generic_name`, `form_code` and `form_display` (NCI Thesaurus), `route_codes`, `approval_id` (application number), `marketing_category_code` and `_display`, `marketing_status`, `marketing_low`, `marketing_high` (YYYYMMDD; a completed status may carry a future end date), `equivalent_ndc` (source product declared by a repackaged or relabeled product), `is_kit`.

**spl_part**: kit parts. `part_key`, `product_key`, `part_index`, `ndc_original` (may belong to another labeler, or be absent), `name`, `form_code`, `form_display`, part quantity (`qty_num_value`, `qty_num_unit`, `qty_den_value`, `qty_den_unit`).

**spl_ingredient**: every ingredient of a product or part, active and inactive. `class_code` (ACTIB, ACTIM, ACTIR, IACT, ADJV, CNTM), `is_active` (class code begins ACTI), `basis_of_strength` (ingredient, active_moiety, reference_substance, unspecified), `substance_unii` and `substance_name`, `moiety_uniis` and `moiety_names` (one or two), `reference_unii` and `reference_name` (ACTIR), `strength_substance_unii` and `strength_substance_name` (derived from the class code rule; empty when an ACTIM ingredient has two moieties), strength `num_value`, `num_unit`, `den_value`, `den_unit` (decimal text and UCUM unit as written; `den_unit` `1` means "each").

**spl_package**: every container in the package tree. `path` (`1`, `1.1`, …; the product's immediate container is level 1, each enclosing container one level higher), `ndc_original` (as written, or `NULL` for uncoded inner containers), `ndc_configuration` (4-4-2, 5-3-2, 5-4-1), `ndc11` (11-digit form padded by segment pattern), `ndc11_naive` (shortcut: hyphens removed and the whole string left-padded), `form_code`, `form_display`, container quantity, `total_amount_value` and `total_amount_unit` (product units or volume in this container, multiplied exactly along the path), `total_amount_status` (computed, inexact, unresolved), package `marketing_status`, `marketing_low`, `marketing_high`, `marketing_act_code` (C53292 marketing, C96974 drug sample), `combination_type_code`.

## RxNorm (as of the retrieval release)

**rx_ndc_status**: `ndc11`, `status` (ACTIVE, OBSOLETE, ALIEN, UNKNOWN; RxNorm linkage, not FDA marketing status), `rxcui`, `concept_name`, `concept_status`, `response_path`.

**rx_ndc_history**: `ndc11`, `seq`, `active_rxcui`, `original_rxcui`, `start_yyyymm`, `end_yyyymm` (first and last RxNorm release months in which the NDC was linked to that RxCUI).

**rx_concept**: `rxcui`, `name`, `tty`, `status` (Active, Remapped, Obsolete, Quantified, Notcurrent), `is_current`, active start and end (MMYYYY), `remapped_date_mmyyyy`, `quantity_factor_value` and `_unit`, `qualitative_distinction`, `scd_rxcui` (for branded concepts), `remapped_to`, `dose_form_names`, `response_path` (the cached RxNav response).

**rx_concept_strength**: per ingredient of a concept: base, basis-of-strength (BoSS), active ingredient and moiety RxCUIs and names, numerator and denominator value and unit.

**dm_rxnorm_mapping**: DailyMed's set-level SPL-to-RxNorm file, restricted to eligible set IDs: `set_id`, `spl_version`, `rxcui`, `rxstring`, `tty`.

## Results

**match_result**: one row per product and approach (A, A2, B, C). `outcome` (A: unique, ambiguous, not_found, no_package_ndc; A2: agree, disagree, a_not_unique, not_in_mapping_file; B: unique, ambiguous, none, no_package_ndc; C: unique, abstain), `rxcui`, `candidates`, `score` (C only), `detail` (JSON with package-level results and signatures).

**fhir_medication**: one row per generated Medication: `medication_id`, `document_id`, `product_key`, `package_key`, `level` (product or package), `bundle_path`.

**roundtrip_field**: one row per product-version record, representation, attribute and ingredient position. `representation` (R1_full, R_core, S_rx, S_flat, S_api, S_latest), `attribute` (K1 to K13, see docs/analysis_plan.md section 8), `item` (ingredient position, or empty), `status` (preserved, preserved_normalized, converted_equivalent, omitted_in_sidecar, unresolved, discordant, inapplicable, not_evaluated), `source_value`, `reconstructed_value`, `value_equal` (numeric equality for numeric attributes, so a precision-only change such as `0.50` to `0.5` can be told apart from a different value).

**run_log**: reserved and not populated in this release; stage runs are recorded in `outputs/runs/stage_log.jsonl`.

## Files

- `outputs/fhir/bundles/{document_id}.json`: FHIR R4 Bundle (collection) per SPL version.
- `outputs/fhir/sidecars/{document_id}.sidecar.json`: companion record (schema `schemas/medication_sidecar.schema.json`).
- `outputs/tables/*.csv`: analysis tables; each has a header row and one row per stated grain.
- `outputs/dictionary/medication_dictionary.csv`: reusable product dictionary; columns are defined in the next section.

## medication_dictionary.csv

Grain: one row per package NDC of a current-version, in-scope product. A package NDC that appears in more than one label, or twice in one label's package tree, has one row per occurrence. Values are as labeled unless stated.

| Column | Meaning |
|---|---|
| `set_id`, `spl_version`, `document_id`, `effective_time`, `labeler_name` | Label provenance: SPL set ID, version number, document ID, effective time (YYYYMMDD) and labeler. |
| `product_ndc`, `package_ndc` | Product and package NDCs exactly as written, with hyphens. |
| `package_ndc_configuration` | Segment pattern of the package NDC: 4-4-2, 5-3-2 or 5-4-1. |
| `package_ndc11` | 11-digit form, padded through the segment pattern. |
| `proprietary_name`, `name_suffix`, `generic_name` | Product names as labeled. |
| `dosage_form_code`, `dosage_form` | NCI Thesaurus code and display of the product dosage form. |
| `route_codes` | NCI Thesaurus route codes, semicolon-separated. |
| `active_ingredients` | Each active ingredient as `name [UNII] strength unit`, with `/denominator unit` when the denominator is not 1; semicolon-separated. |
| `basis_of_strength` | Active ingredients whose class code is not ACTIB, with the substance their strength refers to. Empty when every strength refers to the ingredient itself. |
| `package_path` | Position in the package tree, from the product outward (for example 1.1). |
| `package_form` | Container form display (for example BOTTLE, CARTON). |
| `package_amount_value`, `package_amount_unit` | Product units in the package, multiplied exactly along the package path; empty when the path cannot be multiplied without assumptions. |
| `package_marketing_status`, `package_marketing_start`, `package_marketing_end` | Package marketing act status and dates (YYYYMMDD). |
| `drug_sample_package` | True when the package marketing act code is C96974 (drug sample). |
| `marketing_category`, `application_number`, `is_kit` | Product marketing category, application number and kit flag. |
| `repackaged_from_ndc` | Source product NDC stated by repackaged or relabeled products. |
| `rxnorm_ndc_status` | RxNorm NDC status (ACTIVE, OBSOLETE, ALIEN, UNKNOWN) or `not looked up`. |
| `rxnorm_package_rxcui`, `rxnorm_package_concept`, `rxnorm_package_tty` | RxNorm concept for the package NDC from the NDC status service, its name and term type. |
| `product_rxcui_identifier_crosswalk`, `product_crosswalk_outcome` | Approach A: the product's RxCUI from its ACTIVE package NDCs, and the outcome (unique, ambiguous, not_found). |
| `dailymed_setlevel_agreement` | Approach A2 outcome against DailyMed's set-level mapping file (agree, disagree, not_in_mapping_file, a_not_unique). |
| `name_attribute_match_outcome`, `name_attribute_match_rxcui` | Approach B outcome and RxCUI. |
| `review_reasons` | Semicolon-separated reasons a maintainer may want to check the row; counts are in `outputs/dictionary/summary.json`. |
| `source_url`, `source_sha256`, `retrieved_utc` | The cached label XML the row came from. |
| `rxnorm_release` | RxNorm release used for the RxNorm columns. |
