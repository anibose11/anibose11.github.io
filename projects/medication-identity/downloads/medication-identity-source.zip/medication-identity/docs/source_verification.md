# Source verification

All checks were made on 2026-10-07 (UTC times below) with live requests, then repeated by a second, independent pass between 09:55 and 10:09 UTC. The raw pages and responses saved during these checks are kept locally under `docs/source_verification/` for provenance; they are third-party content and are not redistributed. Their paths, sizes and SHA-256 values are listed in `docs/source_verification_index.csv`.

## DailyMed (U.S. National Library of Medicine)

- Web services v2, https://dailymed.nlm.nih.gov/dailymed/app-support-web-services.cfm (09:31Z). The services describe current SPL information. `/spls.json` returns one row per set ID with its current version; page size is capped at 100. The `doctype=34391-3` filter restricts to HUMAN PRESCRIPTION DRUG LABEL; `unii_code` matches active-moiety UNIIs, not salt UNIIs.
- `/spls/{setid}.xml` returns only the current version and ignores a version parameter. `/spls/{setid}/history.json` lists versions with DailyMed published dates (not SPL effective times) and may not start at version 1.
- Earlier versions: `https://dailymed.nlm.nih.gov/dailymed/getFile.cfm?type=zip&setid={setid}&version={n}` returns the archived label ZIP (byte-identical to the archive links on the label history page) and HTTP 404 for versions DailyMed does not hold. Tested on two labels for 9 versions.
- `/spls/{setid}/packaging.json` attaches every active-ingredient strength found in a label to every product of that label (seen on Synjardy, whose four products have different strengths), and flattens package nesting. `/spls/{setid}/ndcs.json` is a flat list mixing inner and outer package NDCs, including drug-sample packages.
- SPL-to-RxNorm mapping file: https://dailymed-data.nlm.nih.gov/public-release-files/rxnorm_mappings.zip, pipe-delimited `SETID|SPL_VERSION|RXCUI|RXSTRING|RXTTY`, current versions only, no product or NDC column (09:43Z; 7,128,999 bytes, last modified 2026-10-07 00:01 GMT).
- No published rate limit was found. This project stayed at or below 4 requests per second.
- DailyMed states that labels may differ from FDA-approved labeling, are not reviewed by NLM before publication, and include unapproved products; marketing category must be read from each label.
- Human regular, isophane and 70/30 insulins sold without a prescription are filed as HUMAN OTC DRUG LABEL (34390-5), so a prescription-label scope excludes them.

## FDA SPL semantics

- FDA SPL Implementation Guide (Version 1 Revision 202312080859, December 2023), sections 3.2.3 to 3.2.6: the active-ingredient classCode states the basis of strength: ACTIB the ingredient substance, ACTIM the active moiety, ACTIR a reference substance named in `asEquivalentSubstance/definingSubstance`; IACT marks inactive ingredients. Kits (form C47916) carry ingredients under `part/partProduct`. Package nesting runs from the product outward through `asContent/containerPackagedProduct`, and the outermost package carries the NDC.
- FDA NDC description: 10-digit NDCs are in one of three segment configurations, 4-4-2, 5-3-2 or 5-4-1; the 11-digit HIPAA form pads the short segment. FDA's final rule adopts a uniform 12-digit NDC from 2033-03-07.

## RxNorm API (RxNav)

- https://lhncbc.nlm.nih.gov/RxNav/APIs/RxNormAPIs.html and the RxNav terms of service (09:31Z): no more than 20 requests per second per IP address; caching for 12 to 24 hours recommended; no license needed for the endpoints used here; attribution requested. This project stayed at or below 8 requests per second.
- Release at retrieval: `/version` reported 05-Oct-2026 (API 3.1.356).
- `ndcstatus` returns the current RxNorm status of an 11-digit NDC (ACTIVE, OBSOLETE, ALIEN, UNKNOWN) and its history of RxCUIs with first and last release months (YYYYMM). A 10-digit NDC without hyphens returns UNKNOWN.
- `historystatus` returns concept status (Active, Remapped, Obsolete, Quantified, NotCurrent), remap targets and the definitional structure: for each ingredient the basis-of-strength concept, active ingredient, moiety, and numerator and denominator values with units; dose form; quantity factor.
- The public API serves the current release only. License-free monthly RxNorm Prescribable Content archives exist back to August 2011 and could support fuller historical checks; this study uses RxNorm's own dated NDC history instead.

## HL7 FHIR R4 and the validator

- FHIR R4 is version 4.0.1 (Technical Correction 1, 2019-10-30); https://hl7.org/fhir/R4/medication.html. Medication has identifier, code, status, manufacturer, form, amount (package amount), ingredient (item, isActive, strength as Ratio) and batch. There is no element for the basis of strength, route, label version, package hierarchy or marketing data.
- Decimal precision is significant and must be preserved (https://hl7.org/fhir/R4/datatypes.html#decimal).
- Code systems, from HL7 Terminology (THO 7.4.0): RxNorm `http://www.nlm.nih.gov/research/umls/rxnorm`; NDC `http://hl7.org/fhir/sid/ndc` (10-digit with hyphens in the correct position); UNII `http://fdasis.nlm.nih.gov`; NCI Thesaurus `http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl`; UCUM `http://unitsofmeasure.org`. THO defines no identifier system for SPL set or document IDs; the HL7 SPL mapping guide uses `urn:ietf:rfc:3986` with `urn:uuid:` values.
- HL7 SPL Mapping FHIR R5 Implementation Guide: continuous-integration build 0.2.8 (2025-07-25), not published.
- Official validator: `validator_cli.jar` release 7.0.0 of https://github.com/hapifhir/org.hl7.fhir.core (published 2026-10-06), 203,940,581 bytes, SHA-256 `0ec7285b0f23999c25979533c6e9105f5f01087889fcc113ac1dfc65560bcc69` (matched after download). Requires Java 17 or later; run here on Temurin 21.0.12.1.
- tx.fhir.org reported RxNorm 03022026, UNII 2024-06-22, UCUM 2.2 and NDC 2021-11-01; its NDC content is stale, so NDC results from it are not used as evidence of current status.

## Added during the final review (2026-10-07, 21:20 to 21:25 UTC; saved under docs/source_verification/final_review/)

- FDA, National Drug Code database background information (https://www.fda.gov/drugs/development-approval-process-drugs/national-drug-code-database-background-information, content current as of 03/20/2017): "The NDC will be in one of the following configurations: 4-4-2, 5-3-2, or 5-4-1." This page, not the NDC format page, is cited for the segment patterns; the NDC format page is cited for the 12-digit rule.
- RxNav terms of service (https://lhncbc.nlm.nih.gov/RxNav/TermsofService.html): users of the APIs must "send no more than 20 requests per second per IP address".
- UCUM specification, version 2.2, 2024-06-17 (https://ucum.org/ucum; Schadow and McDonald, Regenstrief Institute and the UCUM Organization): U is the unit of catalytic activity (1 umol/min); [iU] is the international unit and [arb'U] the arbitrary unit, both arbitrary units whose meaning depends on the assay.
- FHIR R4 MedicinalProductIngredient (https://hl7.org/fhir/R4/medicinalproductingredient.html; maturity level 0, Trial Use): `specifiedSubstance.strength.referenceStrength` is "Strength expressed in terms of a reference substance", with a reference substance and a strength Ratio. R4 Medication itself has no such element.
- Crossref record for Peters, Nguyen and Bodenreider 2017 (doi:10.3233/978-1-61499-830-3-1333), Stud Health Technol Inform vol. 245 (MEDINFO 2017).
