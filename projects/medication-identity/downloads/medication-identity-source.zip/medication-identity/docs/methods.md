# Technical methods

This file records how each stage works and why the main representation choices were made. The analysis plan (docs/analysis_plan.md) defines the outcomes; this file describes the machinery.

## Canonical source layer

`src/medid/spl.py` reads the product data elements section (LOINC 48780-1) of each SPL document with lxml, with entity resolution and network access disabled. For every manufactured product it keeps:

- the product NDC exactly as written, with its segment pattern (4-4, 5-3, 5-4);
- proprietary name, name suffix and generic name as separate fields;
- dosage form code and display (NCI Thesaurus), every route of administration;
- each ingredient with its classCode, substance UNII and name, one or two active moieties, the reference substance for ACTIR, and the strength numerator and denominator as decimal text with their unit strings;
- kit parts with their own ingredients, packages, routes and marketing categories;
- the package tree from the product outward, with each level's NDC (or none), package form, quantity, marketing act (status, dates, and whether it is a marketing or a drug-sample act) and combination-product type;
- application number, marketing category, product marketing status and dates, and the equivalent source NDC that repackaged products declare.

The number of product units in each package is computed exactly by multiplying the counts along the package path. One non-count unit (a volume such as 3 mL) is allowed at the innermost level; anything else is recorded as unresolved, not guessed.

The basis-of-strength substance follows the classCode: the ingredient itself for ACTIB, the single active moiety for ACTIM, and the reference substance for ACTIR. When an ACTIM ingredient has two different moieties the source does not say which one the strength refers to, and the value is left empty. A moiety listed twice with the same UNII (10 atorvastatin ingredient records) counts once (analysis plan, amendment 5).

`src/medid/build.py` loads this layer into PostgreSQL 17 (`sql/schema.sql`) with keys `document_id`, `document_id:product_index`, and suffixes for parts, ingredients and packages. It then checks row counts against the parser, join cardinality (one document per product, one current version per set ID, no duplicate package NDC within a product tree), split integrity, document type, and that each source file still matches its recorded SHA-256 (`outputs/checks/build_checks.json`).

## NDC handling

`src/medid/ndc.py` parses an NDC only from its hyphenated form and never guesses a pattern. The 11-digit form is made by left-padding the short segment (4-4-2 to 0+4-4-2, 5-3-2 to 5-0+3-2, 5-4-1 to 5-4-0+1). The shortcut it is compared with removes hyphens and left-pads the whole string, which gives the same answer only for 4-4-2 codes. An 11-digit code with several padding zeros can come from more than one 10-digit pattern, so the 11-digit form alone is not reversible; the hyphenated source form is the canonical value.

## FHIR R4 representation

One Bundle (type collection) per SPL version holds one product-level Medication per in-scope product, one package-level Medication per package NDC, and one Provenance. Element choices:

| SPL attribute | FHIR R4 element | Notes |
|---|---|---|
| Product NDC (labeler-product) | `Medication.identifier` (system `http://hl7.org/fhir/sid/ndc`) | as in the HL7 SPL mapping guide; R4 text describes only package codes for `code` |
| Package NDC | `Medication.code.coding` (system NDC) on the package-level resource | 10-digit hyphenated, exactly as labeled |
| RxCUI from approach A | `Medication.code.coding` (system RxNorm) | only when the identifier crosswalk gave one RxCUI |
| Dosage form | `Medication.form` (NCI Thesaurus) | binding strength is example, so NCIt is allowed |
| Ingredient substance | `ingredient.itemCodeableConcept` (UNII) | substance as listed, active and inactive, with `isActive` |
| Strength | `ingredient.strength` (Ratio, UCUM) | exact decimal text; unit `1` for "each" |
| Package contents | `Medication.amount` (Ratio) | product units or volume per package, computed exactly |
| Kit parts | contained Medications referenced from `ingredient.itemReference` | part quantity as the strength |
| Source document | `Provenance.entity.what.identifier` (`urn:ietf:rfc:3986`, lowercase `urn:uuid:`) | |

`Medication.manufacturer` is left empty because the SPL labeler may be a distributor or repackager, which R4 says this element does not represent. `Medication.status` is left empty because SPL marketing status describes FDA listing, not whether a dictionary record is in use. The basis-of-strength class code and substance, set ID, version, routes, package hierarchy, marketing data and application numbers have no R4 Medication element and are kept in the sidecar.

Decimals are written as JSON number tokens with the source's exact text (`src/medid/exact_json.py`). The only rewrite applied is the one JSON grammar forces (a leading `.` gets a zero, a trailing `.` and redundant leading zeros are dropped); each case is flagged in the sidecar and counted.

## Sidecar

One JSON file per Bundle, keyed by `Medication.id`, validated against `schemas/medication_sidecar.schema.json` (JSON Schema 2020-12). It holds label provenance (set ID, document ID, version, effective time, source URL and SHA-256), the basis-of-strength fields for every ingredient in FHIR order, the product's routes, marketing and application data, the full package path for each package-level resource, and the mapping provenance of each RxNorm coding.

## Validation

The HL7 validator 7.0.0 runs on all Bundles with `-version 4.0.1 -tx n/a -no-http-access` (structure, cardinality, invariants, codes defined in loaded HL7 packages), and on a deterministic sample of 60 Bundles against the public terminology server. Its package cache is kept in the project (`-Duser.home`). See `src/medid/validate.py`.

## Round trip

The reverse transform (`src/medid/fhir_reverse.py`) reads the stored Bundle and sidecar files from disk, in two modes: full (FHIR plus sidecar) and core (FHIR elements only, reading each strength as referring to the listed ingredient, which is the only reading R4 supports). The comparison target is a second reader of the immutable source XML (`src/medid/independent_read.py`), written with the standard-library parser and sharing no code with the canonical reader. Shortcut representations are built from the same records and compared by the same function (`src/medid/roundtrip.py`, `src/medid/roundtrip_run.py`). Every field is scored at its own grain: record-level attributes once per product-version record, ingredient-level attributes once per source active ingredient, and kit part NDCs only for kits, also when a representation reconstructed nothing for a product. Package-level attributes (package NDC, containing product NDC, package form, quantity, marketing status and start date) are compared at package-version grain for the sensitivity analysis (`outputs/roundtrip/package_records.csv`). I wrote the second reader as a software cross-check. It does not provide external validation.

## Reproducibility

- Every network response is cached once under `data/raw/` with URL, time, size and SHA-256, and later stages read only the cache.
- Development and held-out set IDs are assigned by a salted SHA-256 rule before any tuning (`config/study.toml`).
- Normalization rules for approach B and the approach C threshold are in `config/normalization.toml`, with their change log; `scripts/tune_approach_c.py` reproduces the development grid search that set the threshold.
- Each stage records the code fingerprint (SHA-256 over source, configuration, SQL and schemas) in `outputs/runs/stage_log.jsonl`.
- Deterministic stages are rerun from the cache and their outputs compared (`outputs/checks/rerun_comparison.json`).
