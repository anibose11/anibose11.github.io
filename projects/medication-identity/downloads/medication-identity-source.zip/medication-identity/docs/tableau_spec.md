# Tableau import specification

No Tableau workbook was built or tested. These extracts in `outputs/tableau/` are ready for import, and this file states how they may be used. Three extracts are aggregate counts from a finite corpus; version_changes_by_set.csv has one row per SPL set ID. None holds data about people.

## roundtrip_fields_long.csv

- **Grain:** one row per representation × attribute × split × status.
- **Columns:** `representation` (R1_full, R_core, S_rx, S_api, S_flat, S_latest), `attribute` (K1 to K13, defined in docs/analysis_plan.md section 8), `split` (development, held_out), `applicable` (fields the source states, the denominator), `status`, `fields` (count), `share_of_applicable` (fields / applicable; empty for inapplicable and not_evaluated), `suppressed` (always false: no small-cell suppression is needed for label data).
- **Units:** counts of fields (record-level attributes once per product-version record; ingredient-level attributes once per active ingredient).
- **Allowed:** filter by representation, attribute, split and status; sum `fields` within one representation × attribute × split; recompute shares only as SUM(fields) / MAX(applicable) within one representation × attribute × split.
- **Not allowed:** summing `applicable` across statuses (it repeats on every status row), pooling shares across attributes of different grain (record vs ingredient), or adding development and held-out shares without weighting by their own denominators.

## roundtrip_record_outcomes.csv

- **Grain:** one row per representation × split. `split` is development, held_out or all; `all` is the sum of the other two, so filter to one split before summing.
- **Columns:** `records`, `set_ids` (clusters), `all_critical_ok`, `identity_ok`, and 95% interval bounds (`*_ci_low`, `*_ci_high`, proportions) from a cluster bootstrap by SPL set ID.
- **Use:** show proportions as `all_critical_ok / records`; show the interval as given. Intervals are exploratory; the corpus is a census, not a random sample. Do not recompute intervals in Tableau.

## matching_outcomes.csv

- **Grain:** split × approach × outcome; `products` and `of` (the split's current-version product count). `split` is development, held_out or all; `all` is the sum of the other two, so filter to one split before summing.
- **Use:** shares as `products / of`. Approach B and C agreement with approach A must use the denominator of products with a unique approach-A RxCUI (`outputs/tables/matching_agreement_with_A.csv`), not `of`.

## version_changes_by_set.csv

- **Grain:** one row per SPL set ID with a retrieved preceding version; change columns count products or packages.
- **Use:** count set IDs with a change (`> 0`) over all rows (218). Do not sum change counts across columns as if they were labels. `any_identity_change` counts product or package NDC, ingredient or basis, strength and dosage form changes; it excludes `labeler_changed`, `route_changed`, `marketing_category_changed` and `application_changed`. The 218 labels are an equal-allocation sample of up to 40 per ingredient group, so unweighted shares are not corpus rates.

## Interactions

A filter control for split (held-out by default), a representation selector and an attribute selector are the intended interactions. No filter should recompute a proportion from rows of different grain.
