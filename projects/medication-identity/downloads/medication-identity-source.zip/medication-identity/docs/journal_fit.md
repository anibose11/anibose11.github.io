# Journal fit

Checked 2026-10-07 from each journal's current pages (09:31 to 09:50 UTC), then re-checked independently (09:47 to 10:09 UTC). Nothing here predicts acceptance, reviewer interest or timelines, and no impact factors are quoted.

## Primary target: JAMIA Open (Oxford University Press for AMIA)

- **Scope.** A gold open-access, single-anonymous peer-reviewed journal for "novel research and insights in the major areas of informatics for biomedicine and health", including clinical research informatics and clinical informatics (About page).
- **Article type.** Research and Applications: "original work in the formulation, implementation, or evaluation of informatics-based studies and investigations"; up to 4,000 words, a structured abstract of up to 250 words (Objectives, Materials and Methods, Results, Discussion, Conclusion), 4 tables and 6 figures. A lay summary of up to 200 words is required at revision. Application Note (2,000 words, public code repository required) is the fallback if the tool is the main claim.
- **Charges.** The publisher's charge calculator showed 3,625 USD with a 20% AMIA member discount; DOAJ lists 3,582 USD. The exact amount should be confirmed on the submission system. Licenses in use: CC BY and CC BY-NC.
- **Declarations.** Ethics statement (or a statement that none was required), funding (or none), competing interests per author, CRediT contribution roles at submission, data and software availability sections as in recently published articles.
- **References.** Numbered, Vancouver-like; up to 3 authors listed, otherwise the first 3 and "et al."
- **Closest published comparisons in the journal.** Korpela et al., "RxMap: an LLM-assisted tool for medication normalization", JAMIA Open 2026;9(3):ooag085, doi:10.1093/jamiaopen/ooag085; Waters et al., "Automated identification of unstandardized medication data: a scalable and flexible data standardization pipeline using RxNorm on GEMINI multicenter hospital data", JAMIA Open 2023;6(3):ooad062, doi:10.1093/jamiaopen/ooad062. Both normalize medication data to RxNorm; neither evaluates label-version-aware attribute preservation through FHIR.

**Fit.** Good on scope and article type: the study is an evaluation of a data pipeline that research data managers use, with a released tool.

## Runner-up: Journal of Biomedical Semantics (BMC, Springer Nature)

- **Scope.** "semantic enrichment and semantic processing in the biomedical and clinical domain", including "semantic interoperability" and "semantic resources and repositories". Single-anonymous peer review; mandatory research data sharing.
- **Article type.** Research article (Background, Methods, Results, Discussion, Conclusions); abstract up to 350 words with Background, Results, Conclusions; 3 to 10 keywords; no main-text word limit stated.
- **Charges.** Verified on the journal page: 1,690 USD (1,340 GBP; 1,440 EUR); waivers considered case by case if requested at submission.
- **Declarations.** A full Declarations section (ethics approval and consent, consent for publication, availability of data and materials, competing interests, funding, authors' contributions, acknowledgements), using "Not applicable" where relevant. CRediT is not required.
- **Closest published comparisons in the journal.** Zhu, Jiang and Chute, "Profiling structured product labeling with NDF-RT and RxNorm", J Biomed Semantics 2012;3:16, doi:10.1186/2041-1480-3-16 (the study this work updates); Hanna et al., "Building a drug ontology based on RxNorm and other sources", J Biomed Semantics 2013;4:44, doi:10.1186/2041-1480-4-44.

**Fit.** Strong on topic lineage (the closest prior study appeared here) and lower cost. Choose it as primary if the charge matters more than the venue's clinical-informatics readership.

## Other venues considered

- Applied Clinical Informatics (Thieme): scope stresses clinical deployment; requires a clinical relevance statement and multiple-choice questions; hybrid open access at 3,620 USD. Less suitable for a terminology and data-model study without a clinical deployment.
- JMIR Medical Informatics: in scope ("clinical and health data pipelines from acquisition to reuse"), 2,750 USD.
- Journal of Open Source Software: not eligible now. Its submission rules require that "The repository must have been public for more than six months prior to submission, with active development spanning that period." This repository is new and not public.

## Scientific objections to expect and how the manuscript answers them

1. *The reversible representation reaching complete preservation is true by construction.* Partly: the sidecar was designed to hold what R4 cannot. The measured value is in what fails without it (FHIR core, shortcuts), in the independent re-read of the source XML catching parser or writer faults, and in the held-out split guarding against tuning. The manuscript says this directly.
2. *The second reader is not independent validation.* Agreed and stated: it is a separately written software check by the same author. The author's manual review of a sample of records against DailyMed is reported as a separate step.
3. *A cardiometabolic ingredient set does not represent all medicines.* Agreed; results are described as a census of a defined corpus, and the ingredient choice and exclusions (OTC human insulins, legacy-format labels) are stated.
4. *RxNorm agreement is not ground truth.* Agreed; agreement with the identifier crosswalk is terminology agreement, not clinical interchangeability.
5. *Only the latest and one preceding version per label, and RxNorm only as of one release.* Stated as a limitation, with the license-free monthly RxNorm archives named as the route to fuller historical checks.
