-- Canonical source layer and analysis tables for the medication identity study.
-- Values are stored as the source wrote them (text for NDCs and decimals);
-- derived values sit in clearly named columns next to them.

drop schema if exists medid cascade;
create schema medid;
set search_path = medid;

create table source_file (
    path            text primary key,          -- project-relative path of the cached bytes
    kind            text not null,             -- spl_current_xml | spl_version_xml | spl_version_zip | dm_packaging | dm_mapping | rxnav
    url             text not null,
    sha256          text not null check (length(sha256) = 64),
    bytes           bigint not null check (bytes > 0),
    retrieved_utc   timestamptz not null
);

create table spl_document (
    document_id     text primary key,
    set_id          text not null,
    version_number  integer not null,
    version_kind    text not null check (version_kind in ('current', 'preceding')),
    effective_time  text,
    doc_type_code   text not null,
    title           text,
    labeler_name    text,
    labeler_id      text,
    labeler_id_root text,
    split           text not null check (split in ('development', 'held_out')),
    primary_group   text not null,
    groups          text[] not null,
    source_path     text not null references source_file(path),
    unique (set_id, version_number)
);

create table spl_product (
    product_key             text primary key,   -- document_id:index
    document_id             text not null references spl_document(document_id),
    product_index           integer not null,
    in_scope                boolean not null,
    ndc_original            text,
    ndc_configuration       text,
    proprietary_name        text,
    name_suffix             text,
    generic_name            text,
    form_code               text,
    form_display            text,
    route_codes             text[] not null,
    approval_id             text,
    marketing_category_code text,
    marketing_category_display text,
    marketing_status        text,
    marketing_low           text,
    marketing_high          text,
    equivalent_ndc          text,
    is_kit                  boolean not null,
    unique (document_id, product_index)
);

create table spl_part (
    part_key        text primary key,           -- product_key:part:index
    product_key     text not null references spl_product(product_key),
    part_index      integer not null,
    ndc_original    text,
    name            text,
    form_code       text,
    form_display    text,
    qty_num_value   text,
    qty_num_unit    text,
    qty_den_value   text,
    qty_den_unit    text
);

create table spl_ingredient (
    ingredient_key  text primary key,           -- product_key[:part:k]:ing:index
    product_key     text not null references spl_product(product_key),
    part_key        text references spl_part(part_key),
    ingredient_index integer not null,
    class_code      text,
    is_active       boolean not null,
    basis_of_strength text not null,
    substance_unii  text,
    substance_name  text,
    moiety_uniis    text[] not null,
    moiety_names    text[] not null,
    reference_unii  text,
    reference_name  text,
    strength_substance_unii text,               -- derived from class_code (ACTIB/ACTIM/ACTIR rule)
    strength_substance_name text,
    num_value       text,
    num_unit        text,
    den_value       text,
    den_unit        text
);

create table spl_package (
    package_key     text primary key,           -- product_key[:part:k]:pkg:path
    product_key     text not null references spl_product(product_key),
    part_key        text references spl_part(part_key),
    path            text not null,
    level           integer not null,
    ndc_original    text,
    ndc_configuration text,
    ndc11           text,                       -- derived with the segment pattern; null when not a package NDC
    ndc11_naive     text,                       -- shortcut baseline: hyphens removed, left-padded
    form_code       text,
    form_display    text,
    qty_num_value   text,
    qty_num_unit    text,
    qty_den_value   text,
    qty_den_unit    text,
    total_amount_value text,
    total_amount_unit  text,
    total_amount_status text not null,
    marketing_status text,
    marketing_low   text,
    marketing_high  text,
    marketing_act_code text,
    combination_type_code text
);

create table rx_ndc_status (
    ndc11           text primary key,
    status          text,
    rxcui           text,
    concept_name    text,
    concept_status  text,
    response_path   text not null references source_file(path)
);

create table rx_ndc_history (
    ndc11           text not null references rx_ndc_status(ndc11),
    seq             integer not null,
    active_rxcui    text,
    original_rxcui  text,
    start_yyyymm    text,
    end_yyyymm      text,
    primary key (ndc11, seq)
);

create table rx_concept (
    rxcui           text primary key,
    name            text,
    tty             text,
    status          text,
    is_current      text,
    active_start_mmyyyy text,
    active_end_mmyyyy text,
    remapped_date_mmyyyy text,
    quantity_factor_value text,
    quantity_factor_unit text,
    qualitative_distinction text,
    scd_rxcui       text,
    remapped_to     text[] not null,
    dose_form_names text[] not null,
    response_path   text not null references source_file(path)
);

create table rx_concept_strength (
    rxcui           text not null references rx_concept(rxcui),
    seq             integer not null,
    base_rxcui      text, base_name text,
    boss_rxcui      text, boss_name text,
    active_ingredient_rxcui text, active_ingredient_name text,
    moiety_rxcui    text, moiety_name text,
    num_value       text, num_unit text,
    den_value       text, den_unit text,
    primary key (rxcui, seq)
);

create table dm_rxnorm_mapping (
    set_id          text not null,
    spl_version     text not null,
    rxcui           text not null,
    rxstring        text,
    tty             text not null
);
create index on dm_rxnorm_mapping (set_id, spl_version);

create table match_result (
    product_key     text not null references spl_product(product_key),
    approach        text not null check (approach in ('A', 'A2', 'B', 'C')),
    outcome         text not null,
    rxcui           text,
    candidates      text[] not null,
    score           numeric,
    detail          jsonb not null,
    primary key (product_key, approach)
);

create table fhir_medication (
    medication_id   text primary key,
    document_id     text not null references spl_document(document_id),
    product_key     text not null references spl_product(product_key),
    package_key     text references spl_package(package_key),
    level           text not null check (level in ('product', 'package')),
    bundle_path     text not null
);

create table roundtrip_field (
    product_key     text not null references spl_product(product_key),
    representation  text not null,
    attribute       text not null,
    item            text not null,              -- '' for record-level attributes, ingredient position otherwise
    status          text not null check (status in ('preserved', 'preserved_normalized', 'converted_equivalent',
                                                     'omitted_in_sidecar', 'unresolved', 'discordant', 'inapplicable',
                                                     'not_evaluated')),
    source_value    text,
    reconstructed_value text,
    value_equal     boolean,
    primary key (product_key, representation, attribute, item)
);

create table run_log (
    run_id          text not null,
    stage           text not null,
    started_utc     timestamptz not null,
    finished_utc    timestamptz,
    code_fingerprint text not null,
    detail          jsonb not null,
    primary key (run_id, stage)
);
