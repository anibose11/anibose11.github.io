Medication dictionary export (one row per package NDC in a current-version, in-scope product).
Columns are defined in the section medication_dictionary.csv of docs/data_dictionary.md in the source archive. Values are as labeled in DailyMed SPL
(retrieved 2026-10-07) with RxNorm API release 05-Oct-2026. review_reasons lists why a row may need a second look.
This product uses publicly available data from the U.S. National Library of Medicine (NLM), National Institutes of
Health, Department of Health and Human Services; NLM is not responsible for the product and does not endorse or
recommend this or any other product. RxNorm content is shown as of the release named; it may not reflect current NLM data.
