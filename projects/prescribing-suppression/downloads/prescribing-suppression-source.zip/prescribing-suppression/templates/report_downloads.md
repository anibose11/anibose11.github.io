## Downloads and supplementary material

Tables follow the public output rule described in Methods: residuals that could reveal one or two suppressed rows are withheld.

- [Reconciliation workbook (XLSX)](downloads/prescribing_suppression_reconciliation_2024.xlsx): definitions, sources and every result table for 2024, plus replication tables.
- [Match and exception ledger, 2024 (CSV)](downloads/reconciliation_ledger_2024.csv) and [JSON Lines](downloads/reconciliation_ledger_2024.jsonl): every national and state cell with source keys, status, bound check and reason.
- [National reconciliation by label, 2024 (CSV)](downloads/national_reconciliation_2024.csv)
- [State summary, 2024 (CSV)](downloads/state_summary_2024.csv)
- [Group shares and state orderings, 2024 (CSV)](downloads/group_shares_2024.csv) and [rank agreement (CSV)](downloads/rank_shifts_2024.csv)
- [Scope decisions for every label, 2024 (CSV)](downloads/mapping_decisions_2024.csv)
- [Replication by group and year (CSV)](downloads/replication_group_by_year.csv)
- [Analysis plan with amendments (Markdown)](downloads/analysis_plan.md)
- [Source manifest with checksums (JSON)](downloads/source_manifest.json)
- [Evidence register for every reported number (JSON)](downloads/claims.json)
- [Source code and documentation (ZIP)](downloads/prescribing-suppression-source.zip)
