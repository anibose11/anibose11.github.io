# Summed public detail versus published totals in Medicare Part D prescriber data: a reconciliation study of cardiometabolic drugs, 2022 to 2024

{{include:journal_front}}
## Abstract

**Background.** Studies often sum the public Medicare Part D Prescribers by Provider and Drug file to compare drugs and states. That file leaves out every prescriber-drug row with 10 or fewer claims. Earlier studies measured the overall shortfall, but not how it varies by drug label and state or whether it changes comparisons.

**Methods.** For {{primary_year}}, published claim totals in the Geography and Drug file, which the Centers for Medicare & Medicaid Services builds from all claims, were compared with summed Provider and Drug rows for the same drug label and prescriber state. Scope was fixed in advance as all labels in Anatomical Therapeutic Chemical groups A10, C09 and C10. The primary measure was the retained fraction (detail sum over published total). Each cell was tested against the range the 10-claim rule implies, using published prescriber counts. Secondary measures were group shares of class claims and agreement of state orderings (Kendall's tau-b). Data years {{rep_years}} were analyzed separately; a second implementation recomputed every cell.

**Results.** Public detail held {{nat_R}} of {{nat_A}} published in-scope claims and {{nat_Rcost}} of gross drug cost. The median label retained {{label_R_median}} (interquartile range {{label_R_q1}} to {{label_R_q3}}); labels with at least 1,000,000 claims together retained {{vol_top_R}}, and labels with fewer than 10,000 together retained {{vol_low_R}}. Across states and the District of Columbia, the claim-weighted fraction ranged from {{state_R_min}} to {{state_R_max}}. All {{bound_cells}} national and state cells were consistent with the 10-claim rule. Insulins retained {{group_R_A10A}}; their share of diabetes-drug claims was {{ins_share_pub}} from published totals and {{ins_share_det}} from detail, and {{ins_shift5}} of 51 jurisdictions moved five or more places in the state ordering (tau-b {{ins_tau}}). Orderings for metformin, statins and the other large groups changed little. Results for {{rep_years}} were similar ({{R_2023}} and {{R_2022}} retained).

**Conclusions.** Summed public detail holds most cardiometabolic claims but misses large shares for low-volume labels, insulins and combination products, enough to reorder states by insulin share. Drug and state totals should come from the Geography and Drug file, with the retained fraction reported when detail is used. An open audit tool runs these checks on any release pair.

**Keywords:** Medicare Part D; public use files; small-cell suppression; data quality; administrative data; prescribing; cardiometabolic drugs; reconciliation

## Background

The Centers for Medicare & Medicaid Services (CMS) publishes three linked public files on Medicare Part D prescribing each year: a detail file with one row per prescriber, brand name and generic name, and two summary files, one by prescriber and one by geography and drug [{{ref:cms_method}}, {{ref:cms_pd}}, {{ref:cms_geo}}, {{ref:cms_prov}}]. The detail file is the one most often used in research because it ties claims to prescribers and their specialties. To protect beneficiaries, it leaves out any prescriber-drug combination with 10 or fewer claims and any prescriber with fewer than 11 claims in total. CMS states plainly that summing the detail file "will underestimate the true Part D totals" [{{ref:cms_method}}].

The summary files are built differently. CMS aggregates them from all Part D prescription drug event records rather than from the redacted detail [{{ref:cms_method}}]. The Geography and Drug file therefore gives, for each drug label, a national claim total and a state total, keyed by the state of the prescriber's address, which can serve as a reference for the detail file.

Published work has used the public prescriber files to compare drugs, specialties and places, with varying attention to what the detail file omits. Arizpe and colleagues compared antibiotic claims per enrollee across states from the 2013 prescriber public use file without describing how small rows were handled [{{ref:arizpe}}]. Sangha and colleagues described SGLT2 inhibitor prescribing relative to other glucose-lowering drugs and assigned a value of 5 to suppressed beneficiary counts [{{ref:sangha}}]. Karpinski and colleagues built county statin measures only from rows with unredacted counts [{{ref:karpinski}}]. Toth and colleagues used the detail file for provider trends [{{ref:toth}}], and Gouin and colleagues used the By Provider file to identify higher-volume antibiotic prescribers [{{ref:gouin}}].

A few studies have measured the shortfall. De Lott and colleagues reported that the 2013 detail file held 86.8% of all Part D claims and 78.1% of payments [{{ref:delott}}], and Ziakas and colleagues found that it understated anticoagulant claims by 9.0% and costs by 16.6% in 2015 [{{ref:ziakas}}]. Beshearse and colleagues found that oral antibiotic claims for adults aged 65 and older in the 2018 Provider and Drug file were about 69% of the Geography and Drug national total [{{ref:beshearse}}]. Ma and colleagues reported that 7.6% of fills for substitutable cardiovascular drugs were missing from the clinician-level file and that the missing fills had a lower generic share [{{ref:ma}}]. Gronbeck and Feng found the same kind of gap for dermatology services in the Part B provider-level files: 94.3% overall, but much lower for some service categories [{{ref:gronbeck}}]. Outside Medicare, small-count suppression has been shown to bias local mortality rates unevenly across places [{{ref:tiwari}}] and to distort trends in national prescription open data [{{ref:abe}}]. Imputation methods have been proposed for suppressed counts [{{ref:kao}}, {{ref:erdman}}], but they rely on modeling assumptions that a same-source published total does not need.

The literature reviewed did not report how the shortfall varies by drug label and state, whether each cell's gap is consistent with the 10-claim rule, and how much it changes therapeutic-group shares and state orderings. This study measured all three for a prespecified set of cardiometabolic medicines in {{primary_year}}, replicated the analysis in {{rep_years}}, and packaged the checks as a reusable audit.

## Methods

### Design and data

This is a cross-sectional reconciliation of two CMS public files for the same data year. The primary year was {{primary_year}}, the newest year with both files in the CMS catalog at the time of analysis (2026 release). Data years 2023 and 2022 were analyzed separately as replications. The inputs were Medicare Part D Prescribers by Provider and Drug [{{ref:cms_pd}}], Medicare Part D Prescribers by Geography and Drug [{{ref:cms_geo}}], and, for a supplementary check in {{primary_year}}, Medicare Part D Prescribers by Provider [{{ref:cms_prov}}]. Files were downloaded on 7 October 2026 from the distribution addresses listed in the CMS catalog, checked against the size and type reported by the server and against the documented column headers, and stored with Secure Hash Algorithm 256-bit (SHA-256) checksums (Additional file 1). The {{primary_year}} detail file had {{detail_rows}} rows covering {{detail_npis}} prescribers and {{detail_labels}} drug labels. The {{primary_year}} Geography and Drug file had {{geo_rows}} rows and {{ref_labels}} national drug labels.

An analysis plan was written and locked with a checksum and timestamp before any detail sum was compared with a published total (Additional file 2). It is an internal protocol, not a registered one. Ten dated amendments are recorded in it. Four were made before outcomes were computed: the bound check, the first public output rule, Kendall's tau-b, and the handling of a state row without a geography code. Six were made after the primary results were seen: an exploratory post hoc analysis, three revisions of the public output rule that changed no result, the exclusion of one insulin pen device that had been mapped to insulins by mistake, and a record of two implementation details that were in the code from the start but missing from the plan text (matching a component by its first word, and the top-10 overlap measure).

### Drug scope

Scope was every published label mapped to Anatomical Therapeutic Chemical (ATC) group A10 (drugs used in diabetes), C09 (agents acting on the renin-angiotensin system) or C10 (lipid modifying agents). Ingredients came from the National Library of Medicine RxClass service (ATC source, RxNav data version {{rxnav_version}}) [{{ref:rxclass}}]: {{ingredients}} ingredients ({{ingredients_A10}} in A10, {{ingredients_C09}} in C09, {{ingredients_C10}} in C10). A label was in scope when at least one component of its published generic name matched an in-scope ingredient. Components were split on "/" and stripped of salt and release-form words. A component matched an ingredient exactly, by its first word, or as an unambiguous prefix of at least five letters, because CMS truncates long generic names (for example "Dapaglifloz Propaned"). Any component beginning with the word insulin mapped to ATC A10A, which covers all insulins, except insulin delivery devices (pump cartridges and a reusable pen listed as administration supplies). One label written by its active moiety ("Fenofibric Acid (Choline)") was mapped to choline fenofibrate by a documented override, following the World Health Organization ATC note for C10AB11 [{{ref:who_atc}}]. In {{primary_year}}, {{scope_labels}} labels were in scope ({{scope_labels_A10}} A10, {{scope_labels_C09}} C09, {{scope_labels_C10}} C10), of which {{scope_combos_noninsulin}} were non-insulin fixed-dose combination products; premixed insulins and insulin combinations with a GLP-1 receptor agonist were grouped with insulins (ATC A10A). Combination products were kept as single labels and never split into ingredient totals. Each label's mapping, method and reason are listed in Additional file 3.

### Matching the two files

Labels were joined on the exact published brand and generic names. Geography was joined on the state code that both files share: Federal Information Processing Standards (FIPS) codes for the states, the District of Columbia and four territories, plus codes for Armed Forces areas, "Unknown" and "Foreign Country". In both files this is the location of the prescriber in the National Plan and Provider Enumeration System (NPPES), not the beneficiary's residence. Key uniqueness was asserted in both files before any join, and each join was checked for cardinality. In every year each detail label matched a national reference label exactly ({{unmatched_all_years_text}} unmatched), so no label needed normalization.

### Measures

For each analysis cell (label, geography, year) with a published total A, the detail sum D was the sum of claims over detail rows with that label and geography. The national detail sum included every detail row of the label, whatever its state code. The retained fraction was R = D / A and the gap G = A minus D. When A was published and no detail row existed, R was 0. Cells with detail but no published total, and cells where D exceeded A, were to be kept and listed as exceptions, never set to zero or truncated. Claims, 30-day fills and gross drug cost were summed. Beneficiary counts were never summed, because one beneficiary can appear under several prescribers and drugs, and blank cells were never filled with zero, 5 or any other value.

The Geography and Drug file reports the number of prescribers behind each total, and the detail file has one row per prescriber per label. The number of prescribers whose rows are absent is therefore m = published prescribers minus detail rows. If the 10-claim rule is the only reason for the gap, each absent row holds 1 to 10 claims, so m ≤ G ≤ 10m. Every national and state cell was tested against this range. A gap inside the range is necessary but not sufficient for the rule to be the only cause: the upper limit can be exceeded only when the published total is more than ten times m, and the lower limit only when detail rows exist and at least one prescriber row is absent. The test uses only cell totals and does not infer any individual row.

Secondary measures were the share of class claims in each therapeutic group (ATC level 4 for single-ingredient labels, A10A for all insulins, and a combination group per class), computed once from published totals and once from detail sums with the same labels. For each group, the 50 states and the District of Columbia were ranked by share both ways, among jurisdictions with a published total. Agreement was summarized by Spearman's correlation, Kendall's tau-b, the largest rank change, the number of jurisdictions moving five or more places, and the overlap of the two top-10 lists. Gross drug cost retained fractions and prescriber coverage (detail rows divided by published prescribers) were also reported.

A state was treated as well matched when none of its in-scope cells had a negative gap or detail without a published total. Territories, Armed Forces areas, "Unknown" and "Foreign Country" were reported separately. In {{primary_year}} a supplementary all-drug reconciliation compared per-prescriber totals in the By Provider file with the sum of each prescriber's detail rows, which splits the national gap into claims in omitted rows of prescribers who appear in the detail file, claims of prescribers with no detail row, and claims outside the By Provider file.

One exploratory post hoc analysis compared each label's published claims per published prescriber with its retained fraction.

These files are administrative totals for the Medicare Part D population, not samples, and the gap between two totals is deterministic. No sampling confidence intervals were computed. Uncertainty is described as coverage, suppression, attribution and definitional uncertainty in the Discussion.

### Verification

A second implementation, written with the Python standard library only, streamed the raw files and, using the primary run's list of in-scope labels, recomputed for every national and state cell the detail claims, rows, cost and fills, re-read the published claims and prescriber counts, and recomputed the status, retained fraction and bound check. It agreed with the primary DuckDB pipeline on all {{second_values}} compared values across the three years ({{second_mismatches}} mismatches), and both read the same number of detail rows. Shares and rank statistics were not recomputed independently. A clean rebuild from the cached raw files reproduced {{repro_values}} values in {{repro_files}} result files within a tolerance of 1e-9 absolute plus 1e-9 relative to the value; the largest difference, {{repro_maxdiff_text}} in {{repro_maxdiff_where}}, came from floating-point summation order. Automated tests cover duplicate reference rows, zero totals, missing cells, combination names, unknown states, non-additive beneficiary fields and the public output rule. These are software and source checks, not clinical validation.

I also checked results by hand, outside the code. For three label-state cells covering an insulin, an SGLT2 inhibitor and an ACE inhibitor in small jurisdictions (Lantus Solostar in Wyoming, Jardiance in Vermont, and lisinopril in the District of Columbia), the provider-drug rows were retrieved through the public data.cms.gov query service and summed, and the published totals and prescriber counts were read from the Geography and Drug file. Each detail sum, published total and bound check matched the pipeline output. I also reviewed the scope decision for every in-scope label, checked each reference against its PubMed or publisher record, and traced every number in the abstract, tables and figures to the evidence register.

### Disclosure safeguards

Every value in this study can be computed from the two public CMS files, but a gap for a cell missing only one or two prescriber rows, or a gap at either end of the allowed range, would state the value of suppressed rows directly. Public tables provided with this study therefore report label-by-state cells only by status, published total and a banded retained fraction, and round every other detail sum to the nearest 10 claims. Rows whose residual involves 1 or 2 absent prescriber rows, 1 to 10 claims, or a gap equal to m or 10m are withheld. In {{primary_year}} this applied to {{withheld_state}} of {{state_cells_all}} state-level cells ({{withheld_state_share}}), {{withheld_national}} and {{withheld_group_state}} group-by-state rows. An interval audit of every published sum, band and the 10-claim floor, run on the full data and again on the public files alone, showed that no withheld value can be pinned to a single claim count from the published tables. Cells with no public detail were not withheld, because their residual equals the published total. All results reported here were computed on the full, unrounded data. The public tables are in Additional files 4 and 5.

### Software

The pipeline used Python 3.13.5, DuckDB 1.5.6 [{{ref:duckdb}}], pandas 3.0.6, openpyxl 3.1.5 and matplotlib 3.11.2 on macOS (arm64), with locked dependencies. A command-line tool runs each stage (acquire, build, analyze, validate, render, package) and an `audit` command that accepts any compatible pair of Provider and Drug and Geography and Drug files (Additional file 6).

{{include:journal_ai}}
## Results

### Completeness of cardiometabolic claims, {{primary_year}}

Public detail contained {{nat_D}} of the {{nat_A}} claims published for in-scope labels, a retained fraction of {{nat_R}} and a gap of {{nat_gap}} claims. Gross drug cost was less complete ({{nat_Rcost}}). The claim-weighted fraction was {{class_R_A10}} for diabetes drugs, {{class_R_C09}} for renin-angiotensin agents and {{class_R_C10}} for lipid modifying agents.

The weighted figure hides how uneven the loss is across labels (Fig. 1). The median label retained {{label_R_median}} of its published claims (interquartile range {{label_R_q1}} to {{label_R_q3}}). Of {{scope_labels}} labels, {{labels_lt50}} ({{labels_lt50_share}}) retained under half, {{labels_R0}} had no public detail row at all, and only {{labels_ge95}} retained 95% or more. Completeness rose with volume. The {{vol_top_labels}} labels with at least 1,000,000 published claims, which account for {{vol_top_share_of_A}} of in-scope claims, retained {{vol_top_R}}, while the {{vol_low_labels}} labels with fewer than 10,000 claims retained {{vol_low_R}}. The median label had public detail rows for only {{presc_cov_median}} of its published prescribers.

{{figure:1}}

By therapeutic group (Table 1), statins ({{group_R_C10AA}}), metformin ({{group_R_A10BA}}), angiotensin-converting enzyme (ACE) inhibitors ({{group_R_C09AA}}) and angiotensin II receptor blockers (ARBs) ({{group_R_C09CA}}) were nearly complete. Insulins retained {{group_R_A10A}}, diabetes combination products {{group_R_A10_FDC}}, renin-angiotensin combinations {{group_R_C09_FDC}} and fibrates {{group_R_C10AB}}. Sodium-glucose cotransporter-2 (SGLT2) inhibitors ({{group_R_A10BK}}) and glucagon-like peptide-1 (GLP-1) receptor agonists ({{group_R_A10BJ}}) sat between these.

{{table:groups}}

### Every gap is consistent with the 10-claim rule

All {{bound_cells}} national and state-level cells in {{primary_year}} had a gap between the number of absent prescriber rows and ten times that number, as the 10-claim rule requires. The test could have failed in many but not all cells: the upper limit could have been exceeded in {{bound_upper_testable}} cells ({{bound_upper_testable_share}}) and the lower limit in {{bound_lower_testable}}, the cells with detail rows and at least one absent prescriber row. No cell had a negative gap or detail without a published total, and no state failed the well-matched check, so all {{well_matched_n}} jurisdictions entered the state analysis. The 2023 and 2022 files gave the same result, with {{rep_outside_text}} outside the range. The reference itself omits state rows below 11 claims: national totals exceeded the sum of published state rows by {{ref_state_supp}} claims across {{ref_state_supp_labels}} labels, a negligible amount.

### States

Across the 50 states and the District of Columbia, the share of published in-scope claims present in detail ranged from {{state_R_min}} to {{state_R_max}} (median {{state_R_median}}) (Fig. 2). The lowest were {{state_low1_name}} ({{state_low1_R}}), {{state_low2_name}} ({{state_low2_R}}) and {{state_low3_name}} ({{state_low3_R}}), and the highest was {{state_high_name}} ({{state_high_R}}). For diabetes drugs alone the range was {{state_A10_min}} to {{state_A10_max}}. Of the {{state_cells}} label-state cells, {{state_cells_nodetail}} ({{state_cells_nodetail_share}}) had a published total but no public detail, and the median cell retained {{state_cell_R_median}}.

{{figure:2}}

### Shares and state orderings

Because completeness differs by group, shares computed from detail shift toward the more complete groups (Table 2). Insulins made up {{ins_share_pub}} of diabetes-drug claims in published totals but {{ins_share_det}} in detail, while metformin rose from {{met_share_pub}} to {{met_share_det}}. In every state the insulin share from detail was lower, by {{ins_state_diff_min}} to {{ins_state_diff_max}} percentage points. Renin-angiotensin combinations were understated by {{c09fdc_share_diff}} percentage points nationally and statins overstated by {{statin_share_diff}}.

{{table:shares}}

State orderings followed the same pattern (Fig. 3). Among groups with at least {{big_group_threshold}} of their class's claims, insulins had the least stable ordering: Kendall's tau-b between the two orderings was {{ins_tau}} (Spearman {{ins_rho}}), {{ins_shift5}} of 51 jurisdictions moved five or more places, the largest move was {{ins_maxshift}} places, and only {{ins_top10}} states appeared in both top-10 lists (Fig. 4). Orderings for SGLT2 inhibitors (tau-b {{sglt2_tau}}, {{sglt2_shift5}} jurisdictions moving five or more places), statins ({{statin_tau}}, {{statin_shift5}}) and metformin ({{met_tau}}, {{met_shift5}}) changed little. Of {{groups_ranked}} groups, {{groups_stable}} had two or fewer jurisdictions moving five or more places. Two very small groups, renin inhibitors and other RAS agents, reordered more than insulins (tau-b {{c09xa_tau}} and {{c09xx_tau}}), but each accounts for under 0.1% of its class's claims.

{{figure:3}}

{{figure:4}}

### Where the missing claims sit

Across all drugs in {{primary_year}}, the detail file held {{all_detail}} of {{all_geo}} published national claims ({{all_R}}). Of the gap, {{decomp_rows_share}} was in omitted rows of prescribers who do appear in the detail file, {{decomp_npis_share}} belonged to {{npis_no_detail}} prescribers ({{npis_no_detail_share}} of those in the By Provider file) with no detail row at all, and {{decomp_outside_share}} lay outside the By Provider file. The loss is mostly the tail of low-volume drugs within each prescriber's list rather than whole prescribers. All detail claims belonged to individual prescribers; the By Provider file listed only {{org_npis}} organizational National Provider Identifiers (NPIs), with {{org_claims}} claims and no detail rows.

In the exploratory post hoc analysis, claims per published prescriber tracked label completeness more closely than total volume did (Spearman {{ex_rho_cpp}} against {{ex_rho_volume}}). Insulin labels averaged {{ins_cpp}} published claims per prescriber of each label, compared with {{met_cpp}} for metformin and {{statin_cpp}} for statin labels. This association is partly expected, because under the 10-claim rule the retained fraction cannot fall below 1 minus 10 divided by the claims per prescriber, so the analysis describes the mechanism rather than testing it.

### Replication years

The 2023 and 2022 files, each analyzed with its own label mapping, gave similar results (Table 3). The national retained fraction was {{R_2023}} in 2023 and {{R_2022}} in 2022, and the ordering of class fractions was the same in every year. Gross cost completeness rose from {{Rcost_2022}} in 2022 to {{Rcost_2023}} in 2023 and {{Rcost_2024}} in 2024. Among groups with at least {{big_group_threshold}} of their class's claims, the insulin state ordering was again the least stable (tau-b {{ins_tau_2023}} and {{ins_tau_2022}}). Of the in-scope labels, {{labels_all_years}} were present in all three years, and their retained fractions were strongly correlated between years (Spearman {{rep_rho_min}} to {{rep_rho_max}}). Another {{labels_changed}} labels appeared in only one or two years and were not forced into a series.

{{table:replication}}

## Discussion

Summed public detail captured {{nat_R}} of published cardiometabolic claims in {{primary_year}}, and in every national and state cell the shortfall was consistent with the 10-claim rule. High-volume generics account for much of that aggregate figure. Individual labels differed substantially: the median label retained about a third of its claims, insulins lost enough to lower their share of diabetes-drug claims by about {{ins_share_diff_round}} percentage points and to reorder states, and renin-angiotensin combinations lost enough to lower their share by about {{c09fdc_share_diff_round}} points. Claim completeness and its pattern across groups were similar in all three years, while gross cost completeness rose.

### Comparison with earlier work

Table 4 sets these findings beside published studies that used the public files.

{{table:prior}}

Across all drugs the {{primary_year}} detail file held {{all_R}} of published claims, almost the same as the 86.8% De Lott and colleagues reported for 2013 [{{ref:delott}}], showing a similar overall omission in these two years, despite their different drug mixes. The cardiometabolic gap of {{nat_missing_share}} is close to the 9.0% understatement of anticoagulant claims reported by Ziakas and colleagues [{{ref:ziakas}}], and, as in both earlier studies [{{ref:delott}}, {{ref:ziakas}}], cost was less complete than claims. The cardiometabolic figure is higher than the 69% that Beshearse and colleagues reported for oral antibiotics in older adults in 2018 [{{ref:beshearse}}]. One possible explanation is that short antibiotic courses are spread across many prescribers, whereas cardiometabolic volume is concentrated in a few chronic generics that are refilled monthly. This study did not test that explanation. 

The result is consistent with the 7.6% of missing fills that Ma and colleagues found for substitutable cardiovascular drugs [{{ref:ma}}]. Their finding that missing fills had a lower generic share is compatible with the low retention of many brand and combination labels here, although generic share was not analyzed. Gronbeck and Feng found 94.3% concordance for dermatology services in the Part B files, with much lower values for some service categories [{{ref:gronbeck}}], the same pattern of a high average over uneven categories.

For applied studies the implication depends on the comparison. This study did not re-analyze earlier work, which used older data, other geographic units and in some cases other files. State-level SGLT2 inhibitor and statin shares and orderings changed little in 2022 to 2024, but county-level measures, specialty comparisons and ratios between drug groups were not assessed. Comparisons involving insulin, combination products, fibrates, low-volume brands or gross cost are more exposed, as are rates that divide summed detail by full enrollment. Assigning 5 to suppressed beneficiary cells, as some studies have done [{{ref:sangha}}], does not address the omitted rows at all. CMS also counter-suppresses some subgroup cells to protect a neighboring small value, so a blank cell does not always stand for a count between 1 and 10 [{{ref:cms_method}}]. The variation across states, with the lowest completeness in the District of Columbia, Alaska and Wyoming, fits the wider finding that suppression bias is uneven across places [{{ref:tiwari}}].

### Why the loss is uneven

A prescriber-drug row disappears when that prescriber has 10 or fewer claims of that label in the year, so completeness depends on how claims are spread across prescribers rather than on total volume alone. The exploratory analysis is consistent with this: claims per prescriber tracked label completeness closely. Insulins are split across many pen, vial and concentration products, each with few claims per prescriber, while statins and metformin are refilled monthly by many patients of each prescriber and pass the threshold easily. Combination products and many brands are also prescribed thinly. Gross cost completeness was lower than claim completeness. The analysis did not separate the contribution of each product characteristic to that difference.

### What analysts can do

When the question is a drug or state total, the published Geography and Drug file answers it directly and needs no imputation. When prescriber attributes are needed, the retained fraction for the same label and geography should be reported beside the estimate, and the bound check can flag gaps that the 10-claim rule cannot produce. Beneficiary counts should not be summed. Shares and rankings built from detail should be checked against the same quantities from published totals before they are interpreted. The accompanying audit tool computes all of these for any compatible release pair.

### Limitations

The reference is built from the same prescription drug event records, prescriber attribution and drug exclusions (for example over-the-counter and unmatched products) as the detail file, so retained fractions measure agreement between two CMS products, not completeness against all prescribing. Errors common to both files, and fills outside Part D, cannot be detected.

The bound check is a consistency test: a gap inside the range does not prove that the 10-claim rule is its only cause, and in cells with a small published total relative to the prescriber count the upper limit could not have been exceeded.

The scope covers three ATC groups and depends on the RxClass ATC membership and on matching truncated generic names; RxClass does not list omega-3 fatty acid esters or icosapent ethyl, so those lipid products were outside scope, and one device label was removed after review. Geography is the prescriber's NPPES address, not where patients live. The reference itself omits state rows below 11 claims, which removed {{ref_state_supp}} in-scope claims from state totals. The analysis cannot say which prescribers or patients lie behind the omitted rows.

Gross drug cost excludes rebates and is not out-of-pocket cost. CMS revises files after release and the catalog lists later modification dates for some years, so results apply to the file versions and checksums recorded here. The rank comparisons are descriptive and use fixed cutoffs (five places, top 10). They show how much an ordering depends on the data source, not how reliably states can be ranked.

The findings apply to Medicare Part D. Other public files that suppress small cells can be audited the same way only if a same-source complete total and a count of contributing units are published.

## Conclusions

For cardiometabolic drugs in Medicare Part D, summed public detail is close to complete for high-volume generics and far from complete for many individual labels, insulins and combination products. In every cell the gap is consistent with the 10-claim rule, and it is large enough to bias some drug shares and to reorder states by insulin share. Published Geography and Drug totals should be used where they answer the question, and retained fractions should be reported when detail is used.

## List of abbreviations

ACE: angiotensin-converting enzyme; ARB: angiotensin II receptor blocker; ATC: Anatomical Therapeutic Chemical classification; CMS: Centers for Medicare & Medicaid Services; DC: District of Columbia; DPP-4: dipeptidyl peptidase-4; FIPS: Federal Information Processing Standards; GLP-1: glucagon-like peptide-1; NPI: National Provider Identifier; NPPES: National Plan and Provider Enumeration System; RAS: renin-angiotensin system; SGLT2: sodium-glucose cotransporter-2; SHA-256: Secure Hash Algorithm 256-bit.

{{include:journal_declarations}}
## References

{{references}}

{{include:journal_additional_files}}
