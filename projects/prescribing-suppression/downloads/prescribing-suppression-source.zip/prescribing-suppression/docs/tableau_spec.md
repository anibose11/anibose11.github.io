# Tableau import and interaction specification

No Tableau workbook is included. These instructions describe how to build one from the verified exports without creating invalid statistics.

## Files

| File | Grain | Rows describe |
|---|---|---|
| `exports/tableau/tableau_state_label_cells.csv` | data year x state-level geography code x drug label | published claims and gross cost, status, bound check, banded retained fraction, withheld flag |
| `exports/tableau/tableau_group_shares.csv` | data year x geography (National or state) x therapeutic group | group and class claims from both sources, the two shares, their difference, and state ranks |

## Field types

- Dimensions: `data_year` (discrete), `geo_code`, `geo_desc`, `geo_category`, `atc_class`, `group`, `brnd_name`, `gnrc_name`, `status`, `retained_band`, `values_withheld`, `bound_ok`.
- Measures: `a_clms` (claims), `a_cost` (US dollars, gross) in the cell file; `a_clms`, `d_clms`, `class_a_clms`, `class_d_clms` (claims), `share_published`, `share_detail` (fractions), `share_difference_pp` (percentage points), `rank_published`, `rank_detail` (ranks) in the group-share file.

## Allowed aggregations

- Published claims and gross cost may be summed across labels and states within one data year.
- The cell file has no exact detail sums, so retained fractions cannot be re-aggregated from it; use the bands as categories only. Group and class retained fractions come from the group-share file: SUM(`d_clms`) / SUM(`a_clms`) over the same rows, never an average of fractions.
- Rows where `values_withheld` is true have blank detail values; leave them blank and do not infer them from totals.
- Shares and ranks are precomputed for whole classes and the 50 states and DC. Filtering labels does not recompute them; do not re-rank after filtering.
- Never combine data years in one total. Labels differ by year.
- There are no beneficiary fields in these exports. Beneficiary counts are not additive and must not be added.

## Suggested views

1. Completeness bands by state: count of labels by `retained_band` for each `geo_desc`, filtered by `atc_class`.
2. State completeness: SUM(`d_clms`)/SUM(`a_clms`) by `geo_desc`, with a filter on `atc_class`.
3. Group shares: `share_published` and `share_detail` by `geo_desc` for one `group`.

## Units and suppression

Claims count original prescriptions and refills. Gross cost includes ingredient cost, dispensing fee, sales tax and vaccine administration fees paid by plans, beneficiaries and others, before rebates. Geography is the prescriber's NPPES address. Detail sums exclude prescriber-drug rows with 10 or fewer claims; published totals exclude state rows under 11 claims.
