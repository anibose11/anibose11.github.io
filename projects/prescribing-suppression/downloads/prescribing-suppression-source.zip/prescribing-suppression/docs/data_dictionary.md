# Source-to-analysis dictionary

Every analysis field, the CMS source column it comes from, and how it is transformed. CMS column definitions are quoted from the data dictionaries saved under `data/raw/docs/` (retrieved through the CMS site API on 2026-10-07).

## Inputs

| File | Grain | Key used here | Notes |
|---|---|---|---|
| Medicare Part D Prescribers by Provider and Drug (`*_NPIBN.csv`) | one row per prescriber NPI, brand name, generic name | (`Prscrbr_NPI`, `Brnd_Name`, `Gnrc_Name`), asserted unique | "Aggregated records based on Tot_Clms fewer than 11 are not included in the data file." Providers with fewer than 11 total claims are also absent. |
| Medicare Part D Prescribers by Geography and Drug (`*_Geo.csv`) | one row per geography level, geography code, brand name, generic name | (`Prscrbr_Geo_Lvl`, `Prscrbr_Geo_Cd`, `Brnd_Name`, `Gnrc_Name`), asserted unique | Built by CMS from all Part D prescription drug events. Rows with fewer than 11 claims are not included. |
| Medicare Part D Prescribers by Provider (`*_npi.csv`, 2024 only) | one row per prescriber NPI | `Prscrbr_NPI`, asserted unique | Supplementary all-drug reconciliation only. |
| RxClass ATC class members (`data/raw/rxclass/*.json`) | one member concept per class | RxNorm concept name and RXCUI | Ingredients (IN, PIN) define scope; multi-ingredient concepts are informational. |

## Warehouse tables (`data/warehouse/dy<year>/*.parquet`)

### provider_drug

| Field | Source | Transformation |
|---|---|---|
| npi | Prscrbr_NPI | trimmed; must be 10 digits |
| state_abbr | Prscrbr_State_Abrvtn | trimmed |
| state_code | Prscrbr_State_FIPS | trimmed; blank becomes `BLANK` |
| prscrbr_type, prscrbr_type_src | Prscrbr_Type, Prscrbr_Type_Src | unchanged |
| brnd_name, gnrc_name | Brnd_Name, Gnrc_Name | leading and trailing spaces trimmed; otherwise exactly as published |
| tot_clms | Tot_Clms | must be a whole number; additive |
| tot_30day_fills | Tot_30day_Fills | additive |
| tot_day_suply | Tot_Day_Suply | additive (not used in results) |
| tot_drug_cst | Tot_Drug_Cst | gross cost in US dollars; additive |
| tot_benes | Tot_Benes | unique beneficiaries; blank when suppressed; never summed |
| ge65_* | GE65_* | kept for reference; never summed or imputed |

Prescriber name and city columns are not carried into the warehouse.

### geography_drug

| Field | Source | Transformation |
|---|---|---|
| geo_level | Prscrbr_Geo_Lvl | `National` or `State` |
| geo_code | Prscrbr_Geo_Cd | `National` for national rows; blank state-level code becomes `BLANK` |
| geo_desc | Prscrbr_Geo_Desc | unchanged |
| brnd_name, gnrc_name | Brnd_Name, Gnrc_Name | trimmed only |
| tot_prscrbrs | Tot_Prscrbrs | unique prescribers for the cell |
| tot_clms, tot_30day_fills, tot_drug_cst | same names | published totals (reference) |
| tot_benes | Tot_Benes | reported as published; never summed |

## Result fields (`results/dy<year>/*.csv`)

| Field | Definition | Unit |
|---|---|---|
| a_clms | published `Tot_Clms` for the label and geography | claims |
| d_clms | sum of detail `Tot_Clms` for the label and geography (all state codes for National) | claims |
| gap_clms | a_clms minus d_clms; negative values would be kept and flagged | claims |
| retained_clms | d_clms / a_clms; empty when no published total | fraction |
| a_cost, d_cost, retained_cost | the same for gross drug cost | US dollars, fraction |
| a_fills, d_fills, retained_fills | the same for 30-day fills | fills, fraction |
| a_prscrbrs | published `Tot_Prscrbrs` | prescribers |
| d_rows | detail rows (one per NPI per label) | rows |
| missing_prescriber_rows | a_prscrbrs minus d_rows | rows |
| bound_ok | missing_prescriber_rows ≤ gap_clms ≤ 10 × missing_prescriber_rows (both zero also passes) | true/false |
| status | matched; no public detail; negative gap; detail without reference; zero published total | category |
| geo_category | state or DC; territory; armed forces; unknown; foreign country; blank or unrecognized | category |
| atc_class, group | scope class and therapeutic group from `mapping_decisions.csv` | category |
| share_published, share_detail | group claims / class claims in the same geography, from published totals or detail sums with the same labels | fraction |
| rank_published, rank_detail | rank of the jurisdiction among the 50 states and DC by group share (1 = highest; ties averaged) | rank |

## Public exports (`exports/public/`)

- Label-by-geography cells (`state_reconciliation.csv`, `reconciliation_ledger.*`): keys, `status`, `bound_ok`, the published `a_clms`, `a_cost` and `a_benes_published`, and `retained_band` (0%, under 50%, 50% to under 90%, 90% to under 95%, 95% to 100%). Exact detail sums, gaps and fractions are not published at this level. The band is withheld (`values_withheld` true) when the residual involves 1 or 2 unpublished prescriber rows, 1 to 10 claims, or a gap equal to the number of unpublished rows or ten times that number.
- National label table and aggregate tables (`national_reconciliation.csv`, `national_by_group.csv`, `national_by_volume_band.csv`, `group_shares.csv`, `state_summary.csv`, `other_geography_summary.csv`, `rank_shifts.csv`): detail sums rounded to the nearest 10 claims, with gaps and fractions recomputed from the rounded sums; rows with a sensitive residual are withheld (`values_withheld`, `withheld_reason`). Per-row counts of detail rows and unpublished rows are not published. The national total of all in-scope detail claims is exact.
- `disclosure_report.json` records how many cells and rows were withheld each year; `public_audit.json` records the interval audit run on the public files.
