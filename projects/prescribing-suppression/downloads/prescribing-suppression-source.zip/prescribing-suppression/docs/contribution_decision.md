# Contribution decision

Written 2026-10-07, after the literature search (`docs/literature_searches.csv`, `docs/prior_art.csv`) and before any detail sum was compared with a published total.

## Who uses the output and what decision it supports

Researchers and analysts who build state or drug comparisons from the CMS Medicare Part D Prescribers by Provider and Drug file. The decision is whether a sum of public provider-drug rows can stand in for a Medicare Part D total in a given comparison, or whether the analysis should use the published Geography and Drug totals (or report the shortfall beside its estimate).

## What is already known

- CMS documents that provider-drug rows with 10 or fewer claims are left out of the detail file and that summing the detail "will underestimate the true Part D totals" (methodology, April 2026, section 4.3). Suppression itself is not a finding.
- Beshearse et al. (2023) compared the 2018 public files for antibiotics and found the Provider and Drug total at about 69% of the Geography and Drug national total.
- Ma et al. (2021) reported that 7.6% of fills for substitutable cardiovascular drugs were missing from the clinician-level file, and that the missing fills had a different generic share, so the omission is not random.
- Gronbeck and Feng (2023) measured the same kind of shortfall in the Part B provider-level files (94.3% overall, much lower for some service categories).
- Tiwari et al. (2014) showed that small-count suppression biases local mortality rates unevenly across places.
- Cardiometabolic studies built from the detail file (Sangha et al. 2021; Karpinski et al. 2019) and state comparisons of other drug groups (Arizpe et al. 2016) treat summed detail as the quantity of interest, with varying acknowledgement of the omission.

## The narrow unresolved question

For a fixed, source-defined set of cardiometabolic medicines, how unevenly is the published claim total represented in the public detail across drug labels and states, and does that unevenness change the drug-group shares and state orderings an analyst would report?

No published work found gives per-label, per-state retained fractions for Part D, checks that the shortfall is consistent with the 10-claim rule cell by cell, or tests whether state orderings change.

## Comparator

The published Geography and Drug claim total for the same label, geography and year, which CMS builds from all Part D prescription drug event records. The analyst's naive alternative, the sum of public detail rows, is the quantity being evaluated.

## Estimand

Retained fraction R = D / A and gap G = A minus D for additive claim counts in matched (label, geography, year) cells, as specified in `docs/analysis_plan.md`.

## How the work is framed

This is an independent measurement and a reusable audit tool, not a discovery of suppression. It updates and extends Beshearse et al. (one drug group, one year, national only) and Ma et al. (one pooled share) to per-label and per-state fractions for cardiometabolic drugs in 2024, with two replication years. It does not claim to be first, does not recover any suppressed cell, and does not claim that earlier studies were done improperly.

## What would count as a useful negative result

Retained fractions close to 1 for nearly all labels and states, with no meaningful change in group shares or state orderings. That would tell analysts that, for this scope, summed detail is an acceptable substitute, with a measured margin. It would be reported as such.

## Addendum (2026-10-07, after the primary results)

Two studies in the screened literature were left out of the summary above and are now included in `docs/prior_art.csv`. De Lott et al. (2016) reported that the 2013 detail file held 86.8% of all Part D claims and 78.1% of payments. Ziakas et al. (2018) reported that the detail file understated anticoagulant claims by 9.0% and costs by 16.6% in 2015. Both are national, single-figure measurements. They strengthen the framing above (an update and extension, not a discovery) and do not change the question, scope or estimand.
