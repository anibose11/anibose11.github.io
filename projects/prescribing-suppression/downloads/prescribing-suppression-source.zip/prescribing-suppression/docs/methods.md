# Methods (technical summary)

The full methods are in the manuscript and report. This file lists the operational details that a rerun needs.

## Stages

| Stage | Command | Reads | Writes |
|---|---|---|---|
| acquire | `python -m psaudit acquire` | `config/sources.toml`, `config/scope.toml` | `data/raw/`, `data/manifest/source_manifest.json` |
| build | `python -m psaudit build` | raw CSV files listed in the manifest | `data/warehouse/dy<year>/*.parquet`, `build_summary.json` |
| analyze | `python -m psaudit analyze` | warehouse tables, `config/analysis.toml` | `results/dy<year>/`, `results/replication/` |
| validate | `python -m psaudit validate` | raw CSV files, results | `second_implementation_check.json`, `results/repro_check.json`, `results/test_summary.json` |
| render | `python -m psaudit render` | results, templates | `exports/`, `results/figures/`, `evidence/claims.json`, `manuscript/`, `report/` |
| package | `python -m psaudit package` | everything above | `deliverables/` |

Every stage can be rerun. Downloads are skipped when the cached file still matches its recorded SHA-256; a changed cached file stops the run. The build is skipped when the source checksums are unchanged (use `--force` to rebuild).

## Acquisition

URLs come from the CMS catalog (`https://data.cms.gov/data.json`), never from editing an older URL. Each download streams to a `.part` file with up to four attempts and HTTP range resume. A file is accepted only if it is not an HTML page, its size matches `Content-Length` (for identity-encoded responses), and its header carries the documented columns. Data dictionaries are saved through the CMS site API, because the dictionary pages are rendered in the browser. RxClass responses are saved with the RxNav version.

## Build checks

Declared header order; strict CSV parsing (a short or long row stops the build); whole-number claim and beneficiary counts; 10-digit NPIs; no missing drug key or claim count; unique (NPI, brand, generic) in the detail file; unique (level, code, brand, generic) in the geography file; unique NPI in the provider file. A state-level geography row without a code is kept under `BLANK`.

## Scope mapping

See `config/scope.toml`, `config/scope_overrides.csv` and `src/psaudit/scope.py`. Each year's decisions are written to `results/dy<year>/mapping_decisions.csv` with the component, matched ingredient, method (exact, token, prefix, insulin rule, override) and ATC codes.

## Reconciliation

National cells sum every detail row of a label. State cells join on the shared state code. Status rules, the bound check (amendment 1) and secondary measures follow `docs/analysis_plan.md`. Exceptions are written to `exception_ledger.csv` and `.jsonl`; the public ledger of every cell is in `exports/public/dy<year>/reconciliation_ledger.*`.

## Public output rule

`src/psaudit/public.py` builds every public table (analysis plan amendments 2, 6, 8 and 10). Label-by-state cells are published as bands; all other detail sums are rounded to the nearest 10 claims, except the exact national total. A row is withheld when its residual involves 1 or 2 unpublished prescriber rows, 1 to 10 claims, or a gap at either end of the range the 10-claim rule allows. An interval audit then propagates every published sum, band, rounding interval and the 10-claim floor through all additive relations (labels to groups, classes, volume bands and the total; cells to labels, group-by-state rows, class-by-state rows, state totals and other geographies) and requires that no withheld value is pinned to a single claim count; a further value would be withheld if needed. `public.public_audit()` repeats the audit from the public files alone and is written to `exports/public/public_audit.json`.

## Verification

- `validate` recomputes all compared values with the Python standard library (`csv`, `decimal`) directly from the raw files.
- The rerun check rebuilds the warehouse and results into `.local/rerun/` and compares every CSV and JSON value with an absolute and relative tolerance of 1e-9 (timestamps and run IDs excepted).
- The second implementation also recomputes each cell's status, retained fraction and bound check, and re-reads published prescriber counts. It uses the primary run's list of in-scope labels and does not recompute shares or rank statistics.
- `pytest` covers scope mapping, status rules, the bound check, build guards, the public output rule (row rule, bands, complementary withholding), the second implementation and the comparison tool, using the synthetic fixture in `tests/fixtures/`.
