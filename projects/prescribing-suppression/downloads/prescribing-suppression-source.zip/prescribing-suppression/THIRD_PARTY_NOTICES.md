# Third-party data and notices

The MIT license in `LICENSE` covers the code and documentation written for this project only. It does not cover the data below.

## Centers for Medicare & Medicaid Services

Medicare Part D Prescribers by Provider and Drug, by Geography and Drug, and by Provider (data years 2022 to 2024), their data dictionaries and the April 2026 methodology are published by CMS on data.cms.gov for public use. They are not redistributed in the source archive (they total about 12.5 GB); `python -m psaudit acquire` downloads them from the URLs in `config/sources.toml` and verifies them against the checksums in `data/manifest/source_manifest.json`. Derived aggregate tables in `results/` and `exports/` are computed from these files.

## National Library of Medicine RxNav / RxClass

ATC class membership was retrieved from the RxClass API (RxNav data version 05-Oct-2026) and is included as frozen JSON responses in `data/raw/rxclass/`. RxNav is provided by the U.S. National Library of Medicine. RxClass draws on sources that carry their own terms; see https://lhncbc.nlm.nih.gov/RxNav/TermsofService.html. The ATC classification is maintained by the WHO Collaborating Centre for Drug Statistics Methodology (https://atcddd.fhi.no/).

## Python packages

Runtime dependencies are listed with versions and hashes in `requirements.lock`. Each package keeps its own license (DuckDB: MIT; pandas, NumPy: BSD-3-Clause; PyArrow: Apache-2.0; openpyxl: MIT; matplotlib: PSF-based matplotlib license; requests: Apache-2.0; Python-Markdown: BSD-3-Clause; python-docx: MIT; pytest: MIT).
