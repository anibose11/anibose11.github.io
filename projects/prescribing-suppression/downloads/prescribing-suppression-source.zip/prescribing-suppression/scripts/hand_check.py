"""Independent spot check of three label-state cells through the public data.cms.gov query
service (not the downloaded files and not the pipeline code). Writes handoff/hand_check_2024.json."""

import csv
import io
import json
import sys
import time
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
DETAIL = "https://data.cms.gov/data-api/v1/dataset/9552739e-3d05-4c1b-8eff-ecabf391e2e5/data.csv"
GEO = "https://data.cms.gov/data-api/v1/dataset/c8ea3f8e-3a09-4fea-86f2-8902fb4b0920/data"
CELLS = [("WY", "56", "Lantus Solostar"), ("VT", "50", "Jardiance"), ("DC", "11", "Lisinopril")]


def main() -> int:
    sys.path.insert(0, str(ROOT / "src"))
    import pandas as pd
    st = pd.read_csv(ROOT / "results" / "dy2024" / "state_reconciliation.csv", dtype={"geo_code": str})
    out = {"checked_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "cells": []}
    ok_all = True
    for abbr, code, brand in CELLS:
        r = requests.get(DETAIL, params={"filter[Prscrbr_State_Abrvtn]": abbr, "filter[Brnd_Name]": brand, "size": 5000},
                         timeout=60)
        rows = list(csv.DictReader(io.StringIO(r.text)))
        d = sum(int(x["Tot_Clms"]) for x in rows)
        g = requests.get(GEO, params={"filter[Prscrbr_Geo_Cd]": code, "filter[Brnd_Name]": brand}, timeout=60).json()[0]
        a, p = int(g["Tot_Clms"]), int(g["Tot_Prscrbrs"])
        m, gap = p - len(rows), a - d
        bound = m <= gap <= 10 * m
        pipe = st[(st.geo_code == code) & (st.brnd_name == brand)].iloc[0]
        match = (d == pipe.d_clms and len(rows) == pipe.d_rows and a == pipe.a_clms and p == pipe.a_prscrbrs
                 and str(bound) == str(pipe.bound_ok))
        ok_all &= match
        out["cells"].append({"state": abbr, "brand": brand, "generic": rows[0]["Gnrc_Name"], "detail_rows": len(rows),
                             "detail_claims": d, "published_claims": a, "published_prescribers": p,
                             "missing_rows": m, "gap": gap, "bound_ok": bound, "retained": round(d / a, 4),
                             "matches_pipeline": bool(match)})
    out["all_match"] = bool(ok_all)
    (ROOT / "handoff" / "hand_check_2024.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=1))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
