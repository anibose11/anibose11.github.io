"""Write handoff/prescribing-suppression-validation.md from the verification records.

Inputs: handoff/prescribing-suppression-validation.json (scripts/verify_bundle.py),
handoff/browser_checks.json (observations from the in-app browser), and the pipeline's
verification files in results/.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLUG = "prescribing-suppression"


def _lum(hex_color: str) -> float:
    h = hex_color.lstrip("#")
    rgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    lin = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in rgb]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def contrast(a: str, b: str) -> float:
    la, lb = sorted((_lum(a), _lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def main() -> None:
    v = json.loads((ROOT / "handoff" / f"{SLUG}-validation.json").read_text())
    b = json.loads((ROOT / "handoff" / "browser_checks.json").read_text())
    second = [json.loads((ROOT / "results" / f"dy{y}" / "second_implementation_check.json").read_text())
              for y in (2024, 2023, 2022)]
    rerun = json.loads((ROOT / "results" / "repro_check.json").read_text())
    tests = json.loads((ROOT / "results" / "test_summary.json").read_text())
    css = (ROOT / "report" / "assets" / "page.css").read_text()
    var = dict(re.findall(r"--([a-z0-9-]+):(#[0-9a-fA-F]{6})", css))
    bg = var["bg"]
    pairs = [("body text", var["ink"]), ("secondary text", var["ink2"]), ("muted text", var["muted"]),
             ("links", var["accent"])]

    L = [f"# {SLUG}: verification of the delivered files", ""]
    L.append(f"Checked {v['started_at_utc']} to {v['finished_at_utc']} by `scripts/verify_bundle.py` on the bundle as packaged.")
    L.append("")
    L.append(f"Bundle checked: `{v['bundle']}`, {v['bundle_bytes']:,} bytes, SHA-256 {v['bundle_sha256']}.")
    L.append("This report was added to `handoff/` after the check, so the final archive checksum differs from the one "
             "above; the website files are unchanged and are listed with their own SHA-256 values in "
             f"`handoff/{SLUG}.json`.")
    sa = v["source_archive"]
    L.append(f"Website: {v['website_files']} files, {v['website_bytes']:,} bytes. Source archive: {sa['files']} files, "
             f"{sa['bytes']:,} bytes, SHA-256 {sa['sha256']}.")
    L.append("")
    L.append(f"Automated checks: {v['checks_passed']} passed, {v['checks_failed']} failed.")
    for c in v["checks"]:
        L.append(f"- [{'pass' if c['passed'] else 'FAIL'}] {c['check']}" + (f" ({c['detail']})" if c["detail"] and not c["passed"] else ""))
    L.append("")
    L.append("Commands run in a clean extraction of the source archive:")
    for r in v["clean_extraction_runs"]:
        L.append(f"- [{'ok' if r['exit_code'] == 0 else 'failed'}] {r['step']}: `{r['command']}` ({r['seconds']} s); "
                 f"last line: {r['output_tail'][-1] if r['output_tail'] else ''}")
    L.append("")
    L.append("Pipeline verification on the full CMS files (project folder):")
    L.append(f"- Second implementation (Python standard library, raw CSV): "
             + "; ".join(f"{s['data_year']}: {s['values_compared']:,} values, {s['mismatches']} mismatches, "
                         f"{s['raw_detail_rows']:,} rows read (matches build: {s['row_counts_agree']})" for s in second))
    L.append(f"- Clean rebuild from cached raw files: {rerun['files_compared']} files, {rerun['values_compared']:,} values, "
             f"{rerun['differences']} differences beyond tolerance (absolute and relative 1e-9); largest absolute "
             f"difference {rerun['max_abs_numeric_difference']:.3g}, in "
             f"{rerun.get('largest_difference_location', {}).get('file', 'n/a')} "
             f"({rerun.get('largest_difference_location', {}).get('column', '')}), from floating-point summation order.")
    L.append(f"- Test suite: {tests['summary']} (exit code {tests['exit_code']}).")
    L.append("")
    L.append("Browser checks of the served bundle (in-app Chromium browser; screenshots inspected, not an automated test):")
    for item in b["observations"]:
        L.append(f"- {item}")
    L.append("- Text contrast on the page background " + bg + ", computed with the WCAG formula: " +
             ", ".join(f"{name} {contrast(col, bg):.1f}:1" for name, col in pairs) + ".")
    for item in b.get("not_possible", []):
        L.append(f"  Not possible: {item}")
    L.append("")
    blocked = v.get("external_links_blocked_by_bot_protection", {})
    L.append(f"External links in the report were requested over the network at check time: {len(v['external_links'])} "
             f"checked, {sum(1 for s in v['external_links'].values() if s == 200)} returned HTTP 200, {len(blocked)} "
             "returned 403 from publisher bot protection after the doi.org redirect, and each of those DOIs was confirmed "
             "as registered through the doi.org handle API. Availability can change later.")
    L.append("All checks ran locally; no remote CI was run.")
    text = re.sub(r"/(private/)?var/folders/[^\s`]+?/psaudit_verify_[^/\s`]+", "<temp>", "\n".join(L) + "\n")
    (ROOT / "handoff" / f"{SLUG}-validation.md").write_text(text)
    print("\n".join(L[:6]))


if __name__ == "__main__":
    main()
