"""Verify the delivered bundle: archive structure, the static site served over HTTP,
downloads, external citation links, page numbers against the evidence register, and a
clean extraction of the source archive (setup, tests, demo).

Usage: .venv/bin/python scripts/verify_bundle.py [--skip-source-run]
Writes handoff/prescribing-suppression-validation.json; the Markdown report is written
from it by the caller.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import http.server
import io
import json
import re
import shutil
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLUG = "prescribing-suppression"
BUNDLE = ROOT / "deliverables" / "06-prescribing-suppression-PROJECT-BUNDLE.zip"
SITE_PREFIX = f"site/projects/{SLUG}/"
REQUIRED = [f"{SITE_PREFIX}index.html", f"{SITE_PREFIX}report.html", f"{SITE_PREFIX}downloads/{SLUG}-source.zip",
            f"handoff/{SLUG}.json", "handoff/verified_results.md", "handoff/submission/upload/Manuscript.docx",
            "handoff/submission/upload/Cover_letter.docx", "handoff/submission/upload/Figure_1.png",
            "handoff/submission/upload/Additional_file_6_source_code.zip"]
MAX_BYTES = 28 * 1024 * 1024


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs, self.ids, self.external, self.text = [], set(), [], []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if "id" in a:
            self.ids.add(a["id"])
        for key in ("href", "src"):
            v = a.get(key)
            if not v:
                continue
            if v.startswith(("http://", "https://", "//")):
                if tag in ("script", "link", "img", "iframe") or (tag == "link" and a.get("rel") == "stylesheet"):
                    self.external.append((tag, v))
                continue
            if v.startswith(("mailto:", "data:")):
                continue
            self.refs.append((tag, v))

    def handle_data(self, data):
        self.text.append(data)


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check(results: list, name: str, ok: bool, detail: str = "") -> bool:
    results.append({"check": name, "passed": bool(ok), "detail": detail})
    return ok


def serve(directory: Path):
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=str(directory), **k)

        def log_message(self, *a):
            pass
    httpd = socketserver.TCPServer(("127.0.0.1", 0), Quiet)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, httpd.server_address[1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-source-run", action="store_true")
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--require-validation-md", action="store_true",
                    help="also require handoff/prescribing-suppression-validation.md in the bundle (final pass)")
    args = ap.parse_args()
    res: list[dict] = []
    started = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    work = Path(tempfile.mkdtemp(prefix="psaudit_verify_"))
    out = {"bundle": str(BUNDLE.relative_to(ROOT)), "bundle_bytes": BUNDLE.stat().st_size, "bundle_sha256": sha256(BUNDLE),
           "started_at_utc": started}

    # --- archive structure ------------------------------------------------------------------
    with zipfile.ZipFile(BUNDLE) as z:
        check(res, "outer archive integrity (testzip)", z.testzip() is None)
        names = z.namelist()
        tops = {n.split("/")[0] for n in names}
        check(res, "outer archive opens directly to site/ and handoff/", tops == {"site", "handoff"}, str(sorted(tops)))
        check(res, "required paths present", all(r in names for r in REQUIRED),
              ", ".join(r for r in REQUIRED if r not in names))
        check(res, "no directory entries", not any(n.endswith("/") for n in names))
        if args.require_validation_md:
            check(res, "handoff validation report present", f"handoff/{SLUG}-validation.md" in names)
        outside = [n for n in names if not (n.startswith(SITE_PREFIX) or n.startswith("handoff/"))]
        check(res, f"nothing outside {SITE_PREFIX} and handoff/", not outside, ", ".join(outside[:5]))
        site_names = [n for n in names if n.startswith("site/")]
        check(res, "website file count under 200", len(site_names) < 200, str(len(site_names)))
        big = [n for n in names if z.getinfo(n).file_size > 20 * 1024 * 1024]
        check(res, "every file under 20 MiB", not big, ", ".join(big))
        check(res, "outer archive under 28 MiB", BUNDLE.stat().st_size < MAX_BYTES, f"{BUNDLE.stat().st_size:,} bytes")
        z.extractall(work / "outer")
    site = work / "outer" / "site"
    proj = site / "projects" / SLUG
    out["website_files"] = len(site_names)
    out["website_bytes"] = sum(p.stat().st_size for p in proj.rglob("*") if p.is_file())

    # --- pages ---------------------------------------------------------------------------------
    claims = json.loads((proj / "downloads" / "claims.json").read_text())["claims"]
    claim_texts = {str(c["text"]) for c in claims.values()}
    used_assets = set()
    for page in ("index.html", "report.html"):
        html = (proj / page).read_text(encoding="utf-8")
        p = Links()
        p.feed(html)
        missing = []
        for tag, ref in p.refs:
            target, _, frag = ref.partition("#")
            if not target:
                if frag and frag not in p.ids:
                    missing.append(ref)
                continue
            f = (proj / target).resolve()
            if not f.exists():
                missing.append(ref)
            else:
                used_assets.add(f)
        check(res, f"{page}: every local link, image and anchor resolves", not missing, ", ".join(missing[:5]))
        check(res, f"{page}: no external scripts, styles, fonts or images", not p.external, str(p.external[:3]))
        check(res, f"{page}: no unfilled placeholders", "{{" not in html and "}}" not in html)
        check(res, f"{page}: no em dashes", "—" not in html and "&mdash;" not in html)
        check(res, f"{page}: has lang, viewport and skip link",
              '<html lang="en">' in html and 'name="viewport"' in html and 'class="skip"' in html)
        if page == "index.html":
            check(res, "index.html: links to the report and the source archive",
                  'href="report.html"' in html and f'downloads/{SLUG}-source.zip' in html)
            text = " ".join(p.text)
            body_text = text.split("Reproduce it")[0]
            nums = set(re.findall(r"\d+(?:,\d{3})*(?:\.\d+)?%?", body_text))
            allowed = {"10", "11", "1", "2", "3", "5", "50", "51", "1,000,000", "10,000", "100,000", "2022", "2023",
                       "2024", "2026", "7", "1.0", "13", "3.13", "06", "4", "12", "A10", "C09", "C10"}
            unregistered = sorted(n for n in nums if n not in claim_texts and n.rstrip("%") not in allowed
                                  and n not in allowed and not any(n in t for t in claim_texts))
            check(res, "index.html: every number is a registered claim or a fixed rule/constant", not unregistered,
                  ", ".join(unregistered))
    assets = [f.resolve() for f in (proj / "assets").iterdir()]
    unused = [a.name for a in assets if a not in used_assets]
    check(res, "every asset is used by a page", not unused, ", ".join(unused))
    downloads = [f.resolve() for f in (proj / "downloads").iterdir()]
    unlinked = [d.name for d in downloads if d not in used_assets]
    check(res, "every download is linked from a page", not unlinked, ", ".join(unlinked))

    # --- serve over HTTP at /projects/<slug>/ ------------------------------------------------------
    httpd, port = serve(site)
    try:
        base = f"http://127.0.0.1:{port}/projects/{SLUG}/"
        bad = []
        n = 0
        for f in sorted(proj.rglob("*")):
            if f.is_file():
                url = base + f.relative_to(proj).as_posix()
                with urllib.request.urlopen(url, timeout=30) as r:
                    n += 1
                    if r.status != 200 or len(r.read()) != f.stat().st_size:
                        bad.append(url)
        with urllib.request.urlopen(base, timeout=30) as r:
            dir_ok = r.status == 200 and b"What summed Medicare Part D detail" in r.read()
        check(res, f"served over HTTP at /projects/{SLUG}/ (all {n} files return 200 with full length)", not bad and dir_ok,
              ", ".join(bad[:3]))
    finally:
        httpd.shutdown()

    # --- downloads parse ----------------------------------------------------------------------
    parse_errors = []
    for f in sorted((proj / "downloads").iterdir()):
        try:
            if f.suffix == ".csv":
                with open(f, newline="", encoding="utf-8") as fh:
                    rows = list(csv.reader(fh))
                assert len(rows) > 1 and len({len(r) for r in rows}) == 1
            elif f.suffix == ".json":
                json.loads(f.read_text())
            elif f.suffix == ".jsonl":
                [json.loads(x) for x in f.read_text().splitlines()]
            elif f.suffix == ".xlsx":
                from openpyxl import load_workbook
                wb = load_workbook(f, read_only=True)
                assert "Definitions" in wb.sheetnames and "National" in wb.sheetnames
            elif f.suffix == ".zip":
                with zipfile.ZipFile(f) as z:
                    assert z.testzip() is None
            elif f.suffix == ".md":
                f.read_text(encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            parse_errors.append(f"{f.name}: {exc}")
    check(res, "every download opens and parses (CSV, JSON, JSONL, XLSX, ZIP, Markdown)", not parse_errors,
          "; ".join(parse_errors))

    # --- external citation links ---------------------------------------------------------------
    report_html = (proj / "report.html").read_text(encoding="utf-8")
    urls = sorted(set(re.findall(r"https?://[^\s<\"')]+", report_html)))
    urls = [u.rstrip(".,") for u in urls]
    dois = sorted(set(re.findall(r"doi:(10\.[^\s<]+?)\.?(?=\s|<)", report_html)))
    statuses = {}
    import requests

    for u in urls + [f"https://doi.org/{d}" for d in dois]:
        try:
            r = requests.get(u, headers={"User-Agent": "Mozilla/5.0 (citation link check)"}, timeout=40,
                             allow_redirects=True, stream=True)
            statuses[u] = r.status_code
            r.close()
        except Exception as e:  # noqa: BLE001
            statuses[u] = f"error: {type(e).__name__}"
    # Publishers often answer automated requests with 403 after doi.org redirects. For those,
    # confirm that the DOI itself is registered through the doi.org handle API.
    handle_ok = {}
    for u, s_ in list(statuses.items()):
        if u.startswith("https://doi.org/") and s_ in (403, 429):
            doi = u.split("https://doi.org/", 1)[1]
            try:
                h = requests.get(f"https://doi.org/api/handles/{doi}", timeout=30).json()
                handle_ok[u] = h.get("responseCode") == 1
            except Exception:  # noqa: BLE001
                handle_ok[u] = False
    out["doi_handles_registered"] = handle_ok
    check(res, f"DOIs blocked by publisher bot protection are registered at doi.org ({len(handle_ok)})",
          all(handle_ok.values()), json.dumps({k: v for k, v in handle_ok.items() if not v}))
    blocked = {u: s for u, s in statuses.items() if s in (403, 429)}
    failing = {u: s for u, s in statuses.items() if s not in (200, 403, 429)}
    check(res, f"external citation links resolve ({len(statuses)} checked; 403/429 from bot protection noted)",
          not failing, json.dumps(failing))
    out["external_links"] = statuses
    out["external_links_blocked_by_bot_protection"] = blocked

    # --- source archive ------------------------------------------------------------------------
    src_zip = proj / "downloads" / f"{SLUG}-source.zip"
    with zipfile.ZipFile(src_zip) as z:
        sn = z.namelist()
        check(res, "source archive has a single project folder", {n.split("/")[0] for n in sn} == {SLUG})
        check(res, "source archive has no nested archives", not any(n.endswith(".zip") for n in sn))
        check(res, "source archive includes the synthetic fixture and acquisition config",
              f"{SLUG}/tests/fixtures/synthetic_detail.csv" in sn and f"{SLUG}/config/sources.toml" in sn)
        forbidden = [n for n in sn if any(x in n for x in (".venv/", ".local/", "data/raw/dy", "warehouse", "logs/",
                                                              "handoff/", "manuscript/", "__pycache__"))]
        check(res, "source archive excludes environments, raw CMS files, warehouse, logs and private notes", not forbidden,
              ", ".join(forbidden[:5]))
        z.extractall(work / "src")
    out["source_archive"] = {"files": len(sn), "bytes": src_zip.stat().st_size, "sha256": sha256(src_zip)}

    runs = []
    if not args.skip_source_run:
        cwd = work / "src" / SLUG
        for step, cmd in (("documented setup", f"make setup PYTHON={args.python}"), ("tests", "make test"),
                          ("fast demo", "make demo")):
            t0 = time.time()
            p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
            tail = (p.stdout + p.stderr).strip().splitlines()[-4:]
            runs.append({"step": step, "command": cmd.replace(args.python, "<python 3.13>"), "exit_code": p.returncode,
                         "seconds": round(time.time() - t0, 1), "output_tail": tail})
        ok = all(r["exit_code"] == 0 for r in runs)
        check(res, "source archive: documented setup, tests and demo succeed in a clean extraction", ok,
              "; ".join(f"{r['step']}={r['exit_code']}" for r in runs))
    out["clean_extraction_runs"] = runs

    out["checks"] = res
    out["checks_passed"] = sum(r["passed"] for r in res)
    out["checks_failed"] = sum(not r["passed"] for r in res)
    out["finished_at_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (ROOT / "handoff").mkdir(exist_ok=True)
    name = f"{SLUG}-validation{'-final' if args.require_validation_md else ''}.json"
    (ROOT / "handoff" / name).write_text(json.dumps(out, indent=2) + "\n")
    out["work_dir"] = str(work)
    print(json.dumps({k: out[k] for k in ("checks_passed", "checks_failed")}, indent=1))
    for r in res:
        print(("PASS " if r["passed"] else "FAIL ") + r["check"] + (f"  [{r['detail']}]" if r["detail"] and not r["passed"] else ""))
    print("extracted site at", site)
    return 0 if out["checks_failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
