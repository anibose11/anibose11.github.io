"""Check every DOI reference against Crossref and PubMed; check every web reference loads.
Writes handoff/reference_check.json."""

import json
import re
import sys
import time
import unicodedata
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from psaudit.documents import REFERENCES  # noqa: E402

UA = {"User-Agent": "psaudit reference check (mailto not provided)"}


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def main() -> int:
    out = []
    for key, ref in REFERENCES.items():
        rec = {"key": key, "reference": ref}
        m = re.search(r"doi:(10\.\S+?)\.?$", ref)
        if m:
            doi = m.group(1)
            cr = requests.get(f"https://api.crossref.org/works/{doi}", headers=UA, timeout=40).json()["message"]
            title = (cr.get("title") or [""])[0]
            year = (cr.get("published-print") or cr.get("published-online") or cr.get("issued"))["date-parts"][0][0]
            first = (cr.get("author") or [{}])[0].get("family", "")
            rec.update({"doi": doi, "crossref_title": title, "crossref_year": year, "crossref_volume": cr.get("volume"),
                        "crossref_issue": cr.get("issue"), "crossref_pages": cr.get("page") or cr.get("article-number"),
                        "crossref_first_author": first})
            rec["title_match"] = norm(title)[:60] in norm(ref) or norm(ref).find(norm(title)[:40]) >= 0
            rec["year_match"] = str(year) in ref
            rec["first_author_match"] = norm(first) in norm(ref.split(".")[0])
            vol = cr.get("volume")
            rec["volume_match"] = (vol is None) or (f";{vol}(" in ref or f";{vol}:" in ref or f" {vol}" in ref)
            es = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
                              params={"db": "pubmed", "term": f"{doi}[doi]", "retmode": "json"}, timeout=40).json()
            ids = es["esearchresult"]["idlist"]
            rec["pmid"] = ids[0] if ids else None
            if ids:
                sm = requests.get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi",
                                  params={"db": "pubmed", "id": ids[0], "retmode": "json"}, timeout=40).json()["result"][ids[0]]
                rec["pubmed_source"] = sm.get("source")
                rec["pubmed_pages"] = sm.get("pages")
                rec["pubmed_authors"] = [a["name"] for a in sm.get("authors", [])][:7]
                rec["pubmed_journal_match"] = norm(sm.get("source", "")) in norm(ref)
            time.sleep(0.4)
        else:
            url = re.search(r"https?://\S+?(?=\.?\s|$)", ref)
            if url:
                u = url.group(0).rstrip(".")
                try:
                    r = requests.get(u, headers={"User-Agent": "Mozilla/5.0"}, timeout=40, stream=True)
                    rec["url_status"] = r.status_code
                    r.close()
                except Exception as e:  # noqa: BLE001
                    rec["url_status"] = f"error {type(e).__name__}"
        out.append(rec)
    (ROOT / "handoff" / "reference_check.json").write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
    for r in out:
        flags = {k: v for k, v in r.items() if k.endswith("_match") and v is False}
        print(r["key"], r.get("pmid") or r.get("url_status"), "OK" if not flags else flags,
              r.get("pubmed_source", ""), r.get("crossref_pages", ""), "|", r.get("pubmed_pages", ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
