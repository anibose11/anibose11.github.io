# Synthetic test fixture

Every row in these files is invented for software testing. The NPIs start with 9, which no
real NPI does, and the claim counts are chosen to exercise edge cases. Nothing here is CMS
data and no result from these files appears in the study.

- `synthetic_detail.csv`: Provider and Drug layout (22 columns).
- `synthetic_geography.csv`: Geography and Drug layout (22 columns).

Engineered cases: one clean state (37), a combination label, an insulin delivery device that must stay out of
scope, blank (suppressed) beneficiary counts, an Unknown (9D) state code, a state-level
reference row without a code, a published total with no public detail, public detail with
no published total, and a detail sum larger than its published total (negative gap).
