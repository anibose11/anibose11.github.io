"""Scope mapping: truncated names, combinations, insulin devices and overrides."""

import pytest

from psaudit import scope


@pytest.fixture(scope="module")
def ingredients():
    return scope.load_ingredients()


def m(ingredients, brnd, gnrc):
    return scope.map_label(brnd, gnrc, ingredients)


def test_truncated_combination_maps_by_unique_prefix(ingredients):
    d = m(ingredients, "Xigduo Xr", "Dapaglifloz Propaned/Metformin")
    assert d.in_scope and d.combination
    assert d.group == "A10 fixed-dose combination"
    assert {x["ingredient"] for x in d.matches} == {"dapagliflozin", "metformin"}


def test_combination_is_one_label_not_two_totals(ingredients):
    d = m(ingredients, "Janumet", "Sitagliptin Phos/Metformin Hcl")
    assert d.combination and d.group.endswith("fixed-dose combination")
    assert d.atc_class == "A10"


def test_cross_class_partner_outside_scope(ingredients):
    d = m(ingredients, "Caduet", "Amlodipine/Atorvastatin")
    assert d.in_scope and d.atc_class == "C10" and "Amlodipine" in d.note


def test_insulin_device_is_not_insulin(ingredients):
    assert not m(ingredients, "Omnipod Go Pods", "Insulin Pump Cart,30 Units/Day").in_scope
    assert not m(ingredients, "Insulin Syringe", "Syring-Needl,disp,insul,0.3 Ml").in_scope
    assert not m(ingredients, "Novopen Echo", "Insulin Admin. Supplies").in_scope
    assert m(ingredients, "Fiasp Pumpcart", "Insulin Aspart/B3/Pump Cart").in_scope


def test_premixed_insulin_is_insulin_group(ingredients):
    d = m(ingredients, "Humalog Mix 75-25", "Insulin Lispro Protamin/Lispro")
    assert d.in_scope and d.group == "A10A"


def test_salt_words_do_not_block_a_match(ingredients):
    d = m(ingredients, "Azor", "Amlodipine Bes/Olmesartan Med")
    assert d.in_scope and d.atc_class == "C09"


def test_override_for_moiety_name(ingredients):
    d = m(ingredients, "Trilipix", "Fenofibric Acid (Choline)")
    assert d.in_scope and d.group == "C10AB"
    assert d.matches[0]["method"] == "override"


def test_out_of_scope_label(ingredients):
    assert not m(ingredients, "Trazodone Hcl", "Trazodone Hcl").in_scope
    assert not m(ingredients, "Primaxin", "Imipenem/Cilastatin Sodium").in_scope
