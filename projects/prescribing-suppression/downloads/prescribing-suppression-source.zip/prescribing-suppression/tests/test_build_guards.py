"""Build-stage guards: duplicate dimension rows, header drift, malformed rows."""

import shutil

import pytest

from conftest import FIXTURES
from psaudit.build import BuildError, build_pair


def _copy(tmp_path):
    d = tmp_path / "detail.csv"
    g = tmp_path / "geo.csv"
    shutil.copy(FIXTURES / "synthetic_detail.csv", d)
    shutil.copy(FIXTURES / "synthetic_geography.csv", g)
    return d, g


def test_duplicate_reference_rows_stop_the_build(tmp_path):
    d, g = _copy(tmp_path)
    lines = g.read_text().splitlines()
    g.write_text("\n".join(lines + [lines[1]]) + "\n")          # repeat a National row
    with pytest.raises(BuildError, match="duplicate keys"):
        build_pair(str(d), str(g), tmp_path / "wh")


def test_duplicate_detail_keys_stop_the_build(tmp_path):
    d, g = _copy(tmp_path)
    lines = d.read_text().splitlines()
    d.write_text("\n".join(lines + [lines[1]]) + "\n")
    with pytest.raises(BuildError, match="duplicate keys"):
        build_pair(str(d), str(g), tmp_path / "wh")


def test_header_drift_is_rejected(tmp_path):
    d, g = _copy(tmp_path)
    text = d.read_text().replace("Tot_Clms", "Total_Claims", 1)
    d.write_text(text)
    with pytest.raises(BuildError, match="header differs"):
        build_pair(str(d), str(g), tmp_path / "wh")


def test_short_row_is_rejected(tmp_path):
    d, g = _copy(tmp_path)
    d.write_text(d.read_text() + "9000000009,Synthetic,Z,Town,MD,24\n")
    with pytest.raises(Exception):
        build_pair(str(d), str(g), tmp_path / "wh")


def test_blank_state_reference_row_is_kept_as_blank(tmp_path):
    d, g = _copy(tmp_path)
    s = build_pair(str(d), str(g), tmp_path / "wh")
    assert s["geography"]["state_rows_without_code"] == 1
