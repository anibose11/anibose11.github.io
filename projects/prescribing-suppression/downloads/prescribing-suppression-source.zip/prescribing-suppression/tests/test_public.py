"""Public output rule: row-level sensitivity, bands, rounding and the interval audit."""

from psaudit.public import Audit, band, rnd, sensitive


def test_row_rule():
    assert sensitive(1, 5, 10)            # one unpublished row
    assert sensitive(4, 8, 50)            # residual of 1 to 10 claims
    assert sensitive(3, 3, 50)            # gap at the lower bound: every unpublished row holds 1 claim
    assert sensitive(3, 30, 50)           # gap at the upper bound: every unpublished row holds 10 claims
    assert not sensitive(5, 20, 100)
    assert not sensitive(1, 15, 0)        # no public detail: residual equals the published total


def test_band_has_no_exact_values():
    assert band(0) == "0% (no public detail)"
    assert band(0.42) == "under 50%"
    assert band(0.93) == "90% to under 95%"
    assert band(1.0) == "95% to 100%"


def test_rounding_to_ten():
    assert rnd(14) == 10 and rnd(16) == 20 and rnd(0) == 0


def test_exact_sum_pins_a_withheld_value_and_gets_a_complement():
    a = Audit()
    a.add("P", 30, (22, 40), "exact")
    a.add("x", 12, (11, 20), "exact", is_sensitive=True)
    a.add("y", 18, (11, 20), "exact")
    a.eq("P", ["x", "y"])
    b, _ = a.propagate()
    assert b["x"] == (12, 12)                     # recoverable by subtraction
    w = a.protect()
    assert w["x"] == "rule" and len(w) == 2       # one complement added
    b, _ = a.propagate()
    assert b["x"][1] - b["x"][0] >= 1


def test_rounded_sums_leave_a_withheld_value_uncertain():
    a = Audit()
    a.add("P", 30, (22, 40), "rounded")
    a.add("x", 12, (11, 20), "rounded", is_sensitive=True)
    a.add("y", 18, (11, 20), "rounded")
    a.eq("P", ["x", "y"])
    assert a.protect() == {"x": "rule"}           # no complement needed
    b, _ = a.propagate()
    assert b["x"][1] - b["x"][0] >= 1
