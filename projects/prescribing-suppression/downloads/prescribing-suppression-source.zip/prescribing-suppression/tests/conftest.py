import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
FIXTURES = ROOT / "tests" / "fixtures"


@pytest.fixture()
def project(tmp_path):
    """A throwaway project root with the real configuration, the frozen RxClass
    responses and the synthetic fixture registered as data year 2099."""
    root = tmp_path / "proj"
    shutil.copytree(ROOT / "config", root / "config")
    shutil.copytree(ROOT / "data" / "raw" / "rxclass", root / "data" / "raw" / "rxclass")
    cfg = (root / "config" / "analysis.toml").read_text()
    cfg = cfg.replace("primary_year = 2024", "primary_year = 2099").replace(
        "replication_years = [2023, 2022]", "replication_years = []").replace(
        "supplementary_provider_year = 2024", "supplementary_provider_year = 0")
    (root / "config" / "analysis.toml").write_text(cfg)
    raw = root / "data" / "raw" / "dy2099"
    raw.mkdir(parents=True)
    shutil.copy(FIXTURES / "synthetic_detail.csv", raw / "detail.csv")
    shutil.copy(FIXTURES / "synthetic_geography.csv", raw / "geo.csv")
    import hashlib
    import json

    files = []
    for kind, name in (("provider_drug", "detail.csv"), ("geography_drug", "geo.csv")):
        p = raw / name
        files.append({"kind": kind, "data_year": 2099, "local_path": f"data/raw/dy2099/{name}",
                      "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "bytes": p.stat().st_size})
    (root / "data" / "manifest").mkdir(parents=True)
    (root / "data" / "manifest" / "source_manifest.json").write_text(json.dumps({"files": files}))
    return root


def run_cli(root: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    env = {**os.environ, "PSAUDIT_ROOT": str(root), "PYTHONPATH": str(ROOT / "src")}
    env.pop("PSAUDIT_WAREHOUSE", None)
    env.pop("PSAUDIT_RESULTS", None)
    return subprocess.run([sys.executable, "-m", "psaudit", *args], cwd=root, env=env, check=check,
                          capture_output=True, text=True)
