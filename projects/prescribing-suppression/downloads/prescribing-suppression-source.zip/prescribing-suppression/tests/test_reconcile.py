"""Reconciliation rules on the synthetic fixture (software tests, not study data)."""

import csv
import json
import math

import pandas as pd
import pytest

from conftest import run_cli
from psaudit import analyze


def test_status_rules():
    assert analyze._status(100, 80) == analyze.STATUS_MATCHED
    assert analyze._status(100, 0) == analyze.STATUS_NO_DETAIL
    assert analyze._status(100, None) == analyze.STATUS_NO_DETAIL
    assert analyze._status(100, 120) == analyze.STATUS_NEGATIVE
    assert analyze._status(None, 12) == analyze.STATUS_NO_REFERENCE
    assert analyze._status(float("nan"), 12) == analyze.STATUS_NO_REFERENCE
    assert analyze._status(0, 0) == analyze.STATUS_ZERO_REFERENCE


def test_zero_and_missing_totals_give_undefined_fraction():
    assert analyze._fraction(5, 0) is None
    assert analyze._fraction(5, None) is None
    assert analyze._fraction(None, 10) == 0


@pytest.fixture(scope="module")
def fixture_run(tmp_path_factory):
    from conftest import ROOT
    import shutil
    root = tmp_path_factory.mktemp("run") / "proj"
    # reuse the project() fixture logic without function scope
    from conftest import project as _p  # noqa: F401
    shutil.copytree(ROOT / "config", root / "config")
    shutil.copytree(ROOT / "data" / "raw" / "rxclass", root / "data" / "raw" / "rxclass")
    cfg = (root / "config" / "analysis.toml").read_text()
    cfg = cfg.replace("primary_year = 2024", "primary_year = 2099").replace(
        "replication_years = [2023, 2022]", "replication_years = []").replace(
        "supplementary_provider_year = 2024", "supplementary_provider_year = 0")
    (root / "config" / "analysis.toml").write_text(cfg)
    raw = root / "data" / "raw" / "dy2099"
    raw.mkdir(parents=True)
    from conftest import FIXTURES
    import hashlib
    shutil.copy(FIXTURES / "synthetic_detail.csv", raw / "detail.csv")
    shutil.copy(FIXTURES / "synthetic_geography.csv", raw / "geo.csv")
    files = [{"kind": k, "data_year": 2099, "local_path": f"data/raw/dy2099/{n}",
              "sha256": hashlib.sha256((raw / n).read_bytes()).hexdigest()}
             for k, n in (("provider_drug", "detail.csv"), ("geography_drug", "geo.csv"))]
    (root / "data" / "manifest").mkdir(parents=True)
    (root / "data" / "manifest" / "source_manifest.json").write_text(json.dumps({"files": files}))
    run_cli(root, "build")
    run_cli(root, "analyze")
    run_cli(root, "validate", "--skip-rerun")
    return root / "results" / "dy2099"


def _read(path):
    return pd.read_csv(path, dtype={"geo_code": str})


def test_national_sums(fixture_run):
    nat = _read(fixture_run / "national_reconciliation.csv").set_index("brnd_name")
    assert nat.loc["Metformin Hcl", "d_clms"] == 100 + 30 + 80 + 11 + 40   # includes the Unknown (9D) prescriber
    assert nat.loc["Metformin Hcl", "a_clms"] == 305
    assert math.isclose(nat.loc["Metformin Hcl", "retained_clms"], 261 / 305)
    assert "Omnipod Go Pods" not in nat.index                        # device stays out of scope
    assert "Trazodone Hcl" not in nat.index


def test_negative_gap_is_kept_and_flagged(fixture_run):
    st = _read(fixture_run / "state_reconciliation.csv")
    row = st[(st.geo_code == "51") & (st.brnd_name == "Atorvastatin Calcium")].iloc[0]
    assert row.status == "negative gap" and row.gap_clms == -10 and row.retained_clms == pytest.approx(1.2)
    summary = json.loads((fixture_run / "summary.json").read_text())
    assert "51" in summary["states"]["failing_codes"]                 # VA is not well matched
    assert "51" not in summary["states"]["well_matched_codes"]


def test_detail_without_reference_goes_to_ledger_not_zero(fixture_run):
    led = _read(fixture_run / "exception_ledger.csv")
    hit = led[(led.geo_code == "24") & (led.brnd_name == "Lantus")]
    assert len(hit) == 1 and hit.iloc[0].status == "detail without reference"
    st = _read(fixture_run / "state_reconciliation.csv")
    cell = st[(st.geo_code == "24") & (st.brnd_name == "Lantus")].iloc[0]
    assert pd.isna(cell.retained_clms) and pd.isna(cell.a_clms)


def test_no_public_detail_is_zero_fraction(fixture_run):
    st = _read(fixture_run / "state_reconciliation.csv")
    cell = st[(st.geo_code == "24") & (st.brnd_name == "Janumet")].iloc[0]
    assert cell.status == "matched" and cell.d_clms == 12
    nat = _read(fixture_run / "national_reconciliation.csv").set_index("brnd_name")
    assert nat.loc["Lantus", "d_clms"] == 39


def test_unknown_and_blank_codes_are_not_states(fixture_run):
    st = _read(fixture_run / "state_reconciliation.csv")
    cats = dict(zip(st.geo_code.astype(str), st.geo_category))
    assert cats["9D"] == "unknown"
    summary = json.loads((fixture_run / "summary.json").read_text())
    assert "9D" not in summary["states"]["well_matched_codes"]
    assert summary["states"]["well_matched_codes"] == ["37"]


def test_beneficiary_counts_never_summed(fixture_run):
    for name in ("national_reconciliation.csv", "state_reconciliation.csv"):
        cols = set(_read(fixture_run / name).columns)
        assert not any(c.startswith("d_") and "bene" in c for c in cols)
        assert "a_benes_published" in cols
    st = _read(fixture_run / "state_reconciliation.csv")
    va = st[(st.geo_code == "51") & (st.brnd_name == "Lisinopril")].iloc[0]
    assert pd.isna(va.a_benes_published)                             # suppressed blank stays blank


def test_second_implementation_agrees(fixture_run):
    res = json.loads((fixture_run / "second_implementation_check.json").read_text())
    assert res["mismatches"] == 0 and res["values_compared"] > 0
    assert res["row_counts_agree"] is True and res["row_width_errors"] == 0


def test_group_shares_use_same_labels(fixture_run):
    sh = _read(fixture_run / "group_shares.csv")
    nat = sh[sh.geo_code == "National"]
    for cls, g in nat.groupby("atc_class"):
        assert g.share_published.sum() == pytest.approx(1.0)
        assert g.share_detail.sum() == pytest.approx(1.0)


def test_suppression_bound_flags_impossible_gap(fixture_run):
    st = _read(fixture_run / "state_reconciliation.csv")
    cell = st[(st.geo_code == "24") & (st.brnd_name == "Janumet")].iloc[0]
    # one missing prescriber row cannot hold 23 claims under a 10-claim rule
    assert cell.missing_prescriber_rows == 1 and cell.gap_clms == 23 and cell.bound_ok == False  # noqa: E712
    led = _read(fixture_run / "exception_ledger.csv")
    assert ((led.geo_code == "24") & (led.brnd_name == "Janumet") & (led.status == "outside suppression bounds")).any()
    nc = st[(st.geo_code == "37") & (st.brnd_name == "Metformin Hcl")].iloc[0]
    assert nc.missing_prescriber_rows == 1 and nc.gap_clms == 5 and nc.bound_ok == True  # noqa: E712
