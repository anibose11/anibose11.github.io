from psaudit.validate import compare_dirs


def test_compare_detects_difference_and_tolerance(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    a.mkdir(); b.mkdir()
    (a / "t.csv").write_text("x,y\n1,0.5\n")
    (b / "t.csv").write_text("x,y\n1,0.5000000000001\n")
    assert compare_dirs(a, b)["identical_within_tolerance"]
    (b / "t.csv").write_text("x,y\n1,0.6\n")
    res = compare_dirs(a, b)
    assert not res["identical_within_tolerance"] and res["differences"] == 1
