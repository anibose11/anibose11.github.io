"""Evidence register: every headline number with its output path, selector,
numerator, denominator, scope, configuration, source hashes and run ID.

Documents are rendered from this register, so no number in the report, page or
manuscript is typed by hand.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

from psaudit.common import CONFIG, EVIDENCE, RESULTS, ROOT, load_toml, read_json, rel, utc_now, write_json


def _pct(x: float, d: int = 1) -> str:
    return f"{100 * x:.{d}f}%"


def _int(x: float) -> str:
    return f"{int(round(x)):,}"


def _pp(x: float, d: int = 1) -> str:
    return f"{abs(x):.{d}f}"


def _cfg_hash() -> str:
    h = hashlib.sha256()
    for name in ("analysis.toml", "scope.toml", "scope_overrides.csv", "sources.toml"):
        h.update((CONFIG / name).read_bytes())
    return h.hexdigest()


class Register:
    def __init__(self, run_id: str, cfg_hash: str):
        self.items: dict[str, dict] = {}
        self.run_id = run_id
        self.cfg_hash = cfg_hash

    def add(self, cid: str, value, text: str, path: Path, selector: str, scope: str, numerator=None,
            denominator=None, source_sha256=None, note: str | None = None):
        if cid in self.items:
            raise KeyError(f"duplicate claim id {cid}")
        self.items[cid] = {
            "id": cid, "value": value, "text": text, "output_path": rel(path), "selector": selector,
            "numerator": numerator, "denominator": denominator, "scope": scope, "config_sha256": self.cfg_hash,
            "source_sha256": source_sha256, "run_id": self.run_id, **({"note": note} if note else {}),
        }


def build_claims(cfg: dict) -> dict:
    y = cfg["primary_year"]
    reps = cfg["replication_years"]
    d = RESULTS / f"dy{y}"
    s = read_json(d / "summary.json")
    build = read_json(ROOT / "data" / "warehouse" / f"dy{y}" / "build_summary.json")
    src = s["source_sha256"]
    R = Register(s["run_id"], _cfg_hash())
    sp = d / "summary.json"
    bp = ROOT / "data" / "warehouse" / f"dy{y}" / "build_summary.json"

    R.add("run_id_text", s["run_id"], s["run_id"], sp, "run_id", "analysis run ID")

    # Data and scope.
    R.add("primary_year", y, str(y), CONFIG / "analysis.toml", "primary_year", "configuration")
    R.add("rep_years", reps, " and ".join(str(r) for r in reps), CONFIG / "analysis.toml", "replication_years", "configuration")
    R.add("detail_rows", build["detail"]["rows"], _int(build["detail"]["rows"]), bp, "detail.rows",
          f"all rows of the {y} Provider and Drug file", source_sha256=src)
    R.add("detail_npis", build["detail"]["distinct_npi"], _int(build["detail"]["distinct_npi"]), bp, "detail.distinct_npi",
          f"distinct prescriber NPIs in the {y} Provider and Drug file", source_sha256=src)
    R.add("detail_labels", build["detail"]["distinct_labels"], _int(build["detail"]["distinct_labels"]), bp,
          "detail.distinct_labels", "distinct (brand, generic) labels in the detail file", source_sha256=src)
    R.add("geo_rows", build["geography"]["rows_read"], _int(build["geography"]["rows_read"]), bp, "geography.rows_read",
          f"all rows of the {y} Geography and Drug file", source_sha256=src)
    R.add("ref_labels", s["key_coverage"]["reference_national_labels"], _int(s["key_coverage"]["reference_national_labels"]),
          sp, "key_coverage.reference_national_labels", "national drug labels in the Geography and Drug file", source_sha256=src)
    R.add("ref_labels_without_detail", s["key_coverage"]["reference_labels_without_detail"],
          _int(s["key_coverage"]["reference_labels_without_detail"]), sp, "key_coverage.reference_labels_without_detail",
          "national labels (all drugs) with no row in the detail file", source_sha256=src)
    R.add("detail_labels_missing_ref", s["key_coverage"]["detail_labels_missing_from_reference"],
          _int(s["key_coverage"]["detail_labels_missing_from_reference"]), sp,
          "key_coverage.detail_labels_missing_from_reference", "detail labels absent from the national reference")
    R.add("scope_labels", s["scope"]["labels_in_scope"], _int(s["scope"]["labels_in_scope"]), sp, "scope.labels_in_scope",
          "labels mapped to ATC A10, C09 or C10", source_sha256=src)
    for c, n in s["scope"]["in_scope_by_class"].items():
        R.add(f"scope_labels_{c}", n, _int(n), sp, f"scope.in_scope_by_class.{c}", f"in-scope labels in {c}")

    from collections import Counter
    import re

    from psaudit import scope as _scope

    ings = _scope.load_ingredients()
    ic = Counter(i.atc_class for i in ings)
    rxp = ROOT / "data" / "raw" / "rxclass" / "rxclass_version.json"
    R.add("ingredients", len(ings), _int(len(ings)), ROOT / "data" / "raw" / "rxclass", "IN and PIN members of A10, C09, C10",
          "RxClass ATC ingredients defining scope")
    for c in ("A10", "C09", "C10"):
        R.add(f"ingredients_{c}", ic[c], _int(ic[c]), ROOT / "data" / "raw" / "rxclass", f"members of {c}", f"ingredients in {c}")
    rxv = read_json(rxp)
    R.add("rxnav_version", rxv["version"], rxv["version"], rxp, "version", "RxNav data version at retrieval")
    mp = d / "mapping_decisions.csv"
    md = pd.read_csv(mp)
    ins_ = md[md.in_scope]
    R.add("scope_combos", int(ins_.combination.sum()), _int(ins_.combination.sum()), mp, "in_scope & combination",
          "in-scope labels whose generic name has more than one component")
    nonins = ins_[ins_.combination & (ins_.group != "A10A")]
    R.add("scope_combos_noninsulin", int(len(nonins)), _int(len(nonins)), mp, "in_scope & combination & group != A10A",
          "in-scope non-insulin fixed-dose combination labels")
    meth = Counter()
    for txt in ins_.matched_ingredients:
        for part in str(txt).split(" | "):
            mm = re.search(r"\((exact|token|prefix|insulin rule|override),", part)
            if mm:
                meth[mm.group(1)] += 1
    for k in ("exact", "token", "prefix", "insulin rule", "override"):
        R.add(f"map_{k.replace(' ', '_')}", meth[k], _int(meth[k]), mp, f"matched_ingredients method={k}",
              f"component matches by {k}")
    R.add("ref_state_supp_labels", s["national"]["labels_with_reference_state_suppression"],
          _int(s["national"]["labels_with_reference_state_suppression"]), sp,
          "national.labels_with_reference_state_suppression", "labels whose state rows sum below the national total")

    # National.
    n = s["national"]
    R.add("nat_A", n["a_clms"], _int(n["a_clms"]), sp, "national.a_clms", "sum of published national claims, in-scope labels",
          source_sha256=src)
    R.add("nat_D", n["d_clms"], _int(n["d_clms"]), sp, "national.d_clms", "sum of public detail claims, in-scope labels",
          source_sha256=src)
    R.add("nat_gap", n["gap_clms"], _int(n["gap_clms"]), sp, "national.gap_clms", "published minus detail claims, in-scope")
    R.add("nat_R", n["weighted_retained"], _pct(n["weighted_retained"]), sp, "national.weighted_retained",
          "claim-weighted retained fraction, in-scope labels, national", numerator="national.d_clms",
          denominator="national.a_clms", source_sha256=src)
    R.add("nat_missing_share", 1 - n["weighted_retained"], _pct(1 - n["weighted_retained"]), sp,
          "1 - national.weighted_retained", "share of published in-scope claims absent from public detail")
    R.add("nat_Rcost", n["weighted_retained_cost"], _pct(n["weighted_retained_cost"]), sp, "national.weighted_retained_cost",
          "gross drug cost retained fraction, in-scope labels, national", numerator="sum d_cost", denominator="sum a_cost")
    q = n["label_retained_distribution"]
    for k in ("median", "q1", "q3"):
        R.add(f"label_R_{k}", q[k], _pct(q[k]), sp, f"national.label_retained_distribution.{k}",
              "distribution of label-level retained fractions (unweighted), national", denominator=f"{q['n']} labels")
    b = n["label_retained_bands"]
    R.add("labels_R0", b["equal_0"], _int(b["equal_0"]), sp, "national.label_retained_bands.equal_0",
          "in-scope labels with a published national total and no public detail row")
    lt50 = b["equal_0"] + b["0_to_0.5"]
    R.add("labels_lt50", lt50, _int(lt50), sp, "national.label_retained_bands.equal_0 + 0_to_0.5",
          "in-scope labels retaining under half of their published claims")
    R.add("labels_lt50_share", lt50 / q["n"], _pct(lt50 / q["n"], 0), sp, "(equal_0 + 0_to_0.5) / n", "share of in-scope labels",
          numerator=lt50, denominator=q["n"])
    R.add("labels_ge95", b["ge_0.95"], _int(b["ge_0.95"]), sp, "national.label_retained_bands.ge_0.95",
          "in-scope labels retaining at least 95%")
    pc = n["prescriber_coverage_distribution"]
    R.add("presc_cov_median", pc["median"], _pct(pc["median"]), sp, "national.prescriber_coverage_distribution.median",
          "median over labels of detail rows / published prescribers")
    R.add("ref_state_supp", n["reference_state_suppression_clms"], _int(n["reference_state_suppression_clms"]), sp,
          "national.reference_state_suppression_clms", "national total minus sum of published state rows, in-scope")
    for c in n["by_class"]:
        R.add(f"class_R_{c['atc_class']}", c["weighted_retained"], _pct(c["weighted_retained"]), sp,
              f"national.by_class[atc_class={c['atc_class']}].weighted_retained", f"claim-weighted retained, {c['atc_class']}",
              numerator=c["d_clms"], denominator=c["a_clms"])
        R.add(f"class_Rcost_{c['atc_class']}", c["weighted_retained_cost"], _pct(c["weighted_retained_cost"]), sp,
              f"national.by_class[atc_class={c['atc_class']}].weighted_retained_cost", f"cost retained, {c['atc_class']}")
        R.add(f"class_median_{c['atc_class']}", c["median_label_retained"], _pct(c["median_label_retained"]), sp,
              f"national.by_class[atc_class={c['atc_class']}].median_label_retained", f"median label retained, {c['atc_class']}")

    gp = d / "national_by_group.csv"
    groups = pd.read_csv(gp)
    for r in groups.itertuples(index=False):
        key = r.group.replace(" fixed-dose combination", "_FDC").replace(" ", "_")
        R.add(f"group_R_{key}", r.weighted_retained, _pct(r.weighted_retained), gp,
              f"group={r.group}: weighted_retained", f"claim-weighted retained, {r.group}, national",
              numerator=r.d_clms, denominator=r.a_clms)
        R.add(f"group_labels_{key}", r.labels, _int(r.labels), gp, f"group={r.group}: labels", f"labels in {r.group}")
    vp = d / "national_by_volume_band.csv"
    vb = pd.read_csv(vp)
    top = vb.iloc[-1]
    R.add("vol_top_band", top.volume_band, top.volume_band, vp, "last row: volume_band", "highest claim-volume band")
    R.add("vol_top_labels", top.labels, _int(top.labels), vp, "last row: labels", "labels in the highest volume band")
    R.add("vol_top_R", top.weighted_retained, _pct(top.weighted_retained), vp, "last row: weighted_retained",
          "weighted retained, labels with at least 1,000,000 published claims")
    R.add("vol_top_share_of_A", top.a_clms / vb.a_clms.sum(), _pct(top.a_clms / vb.a_clms.sum()), vp,
          "last row a_clms / sum a_clms", "share of in-scope published claims in the highest band",
          numerator=float(top.a_clms), denominator=float(vb.a_clms.sum()))
    low = vb[vb.volume_band.isin(["11 to 99", "100 to 999", "1,000 to 9,999"])]
    R.add("vol_low_labels", low.labels.sum(), _int(low.labels.sum()), vp, "bands below 10,000: labels",
          "labels with fewer than 10,000 published claims")
    R.add("vol_low_R", low.d_clms.sum() / low.a_clms.sum(), _pct(low.d_clms.sum() / low.a_clms.sum()), vp,
          "bands below 10,000: sum d / sum a", "weighted retained, labels under 10,000 claims")

    # States.
    st = s["states"]
    R.add("well_matched_n", len(st["well_matched_codes"]), _int(len(st["well_matched_codes"])), sp,
          "states.well_matched_codes", "50 states and DC passing the well-matched check")
    R.add("state_cells", st["cells"], _int(st["cells"]), sp, "states.cells", "evaluable label-state cells, 50 states and DC")
    nd = st["status_counts"].get("no public detail", 0)
    R.add("state_cells_nodetail", nd, _int(nd), sp, "states.status_counts['no public detail']",
          "label-state cells with a published total and no public detail")
    R.add("state_cells_nodetail_share", nd / st["cells"], _pct(nd / st["cells"]), sp, "no public detail / cells",
          "share of label-state cells", numerator=nd, denominator=st["cells"])
    R.add("state_cell_R_median", st["cell_retained_distribution"]["median"], _pct(st["cell_retained_distribution"]["median"]),
          sp, "states.cell_retained_distribution.median", "median label-state retained fraction")
    sw = st["state_weighted_retained_distribution"]
    R.add("state_R_min", sw["min"], _pct(sw["min"]), sp, "states.state_weighted_retained_distribution.min",
          "lowest state-level weighted retained fraction (all in-scope claims)")
    R.add("state_R_max", sw["max"], _pct(sw["max"]), sp, "states.state_weighted_retained_distribution.max",
          "highest state-level weighted retained fraction")
    R.add("state_R_median", sw["median"], _pct(sw["median"]), sp, "states.state_weighted_retained_distribution.median",
          "median state-level weighted retained fraction")
    ssp = d / "state_summary.csv"
    ss = pd.read_csv(ssp, dtype={"geo_code": str}).sort_values("weighted_retained")
    R.add("state_low_names", list(ss.geo_desc.head(3)), ", ".join(ss.geo_desc.head(3)), ssp,
          "three lowest weighted_retained", "jurisdictions with the lowest retained fraction")
    R.add("state_high_name", ss.geo_desc.iloc[-1], ss.geo_desc.iloc[-1], ssp, "highest weighted_retained", "highest jurisdiction")
    for rank_, (_, row) in enumerate(ss.iterrows()):
        if rank_ < 3:
            nm = ("the " if row.geo_desc == "District of Columbia" else "") + row.geo_desc
            R.add(f"state_low{rank_ + 1}_name", nm, nm, ssp, f"rank {rank_ + 1} lowest weighted_retained: geo_desc",
                  "jurisdiction with low retained fraction")
            R.add(f"state_low{rank_ + 1}_R", row.weighted_retained, _pct(row.weighted_retained), ssp,
                  f"rank {rank_ + 1} lowest weighted_retained", "its weighted retained fraction")
    top = ss.iloc[-1]
    R.add("state_high_R", top.weighted_retained, _pct(top.weighted_retained), ssp, "highest weighted_retained",
          "highest state weighted retained fraction")
    a10 = ss["weighted_retained_A10"]
    R.add("state_A10_min", a10.min(), _pct(a10.min()), ssp, "min weighted_retained_A10", "lowest state diabetes-class fraction")
    R.add("state_A10_max", a10.max(), _pct(a10.max()), ssp, "max weighted_retained_A10", "highest state diabetes-class fraction")

    bc = s["suppression_bound_check"]
    tot = bc["national"]["cells_checked"] + bc["all_state_level"]["cells_checked"]
    within = bc["national"]["within_bounds"] + bc["all_state_level"]["within_bounds"]
    R.add("bound_cells", tot, _int(tot), sp, "suppression_bound_check national + all_state_level cells_checked",
          "national and state-level cells tested against m <= G <= 10m")
    R.add("bound_within", within, _int(within), sp, "suppression_bound_check within_bounds (national + state)",
          "cells within the bound", numerator=within, denominator=tot)
    R.add("bound_state_cells", bc["all_state_level"]["cells_checked"], _int(bc["all_state_level"]["cells_checked"]), sp,
          "suppression_bound_check.all_state_level.cells_checked", "state-level cells (all geographies) tested")
    upper = bc["national"]["upper_bound_could_fail"] + bc["all_state_level"]["upper_bound_could_fail"]
    lower = bc["national"]["lower_bound_could_fail"] + bc["all_state_level"]["lower_bound_could_fail"]
    R.add("bound_upper_testable", upper, _int(upper), sp, "upper_bound_could_fail (national + state)",
          "cells whose published total exceeds ten times the missing rows, so the upper bound could fail")
    R.add("bound_upper_testable_share", upper / tot, _pct(upper / tot), sp, "upper_bound_could_fail / cells_checked",
          "share of cells", numerator=upper, denominator=tot)
    R.add("bound_lower_testable", lower, _int(lower), sp, "lower_bound_could_fail (national + state)",
          "cells with detail rows and missing rows, where the lower bound could fail")

    # Shares and ranks.
    shp = d / "group_shares.csv"
    sh = pd.read_csv(shp, dtype={"geo_code": str})
    rkp = d / "rank_shifts.csv"
    rk = pd.read_csv(rkp)
    flag = cfg["rank_shift_flag"]
    # Groups with any withheld row in the public group-share table get no state-level min/max or
    # largest-move claims, since those could point to a withheld value. Insulins must stay unrestricted
    # because the text reports them.
    pub_gs = pd.read_csv(ROOT / "exports" / "public" / f"dy{y}" / "group_shares.csv", dtype={"geo_code": str})
    restricted = set(pub_gs[pub_gs.values_withheld.astype(str).eq("True")].group)
    if "A10A" in restricted:
        raise RuntimeError("insulin group has withheld state rows; the text's state range would reveal them")
    for grp, key in (("A10A", "ins"), ("A10BA", "met"), ("A10BK", "sglt2"), ("A10BJ", "glp1"), ("C10AA", "statin"),
                     ("C09 fixed-dose combination", "c09fdc")):
        nat_row = sh[(sh.geo_code == "National") & (sh.group == grp)].iloc[0]
        R.add(f"{key}_share_pub", nat_row.share_published, _pct(nat_row.share_published), shp,
              f"geo_code=National, group={grp}: share_published", f"{grp} share of class claims, published totals")
        R.add(f"{key}_share_det", nat_row.share_detail, _pct(nat_row.share_detail), shp,
              f"geo_code=National, group={grp}: share_detail", f"{grp} share of class claims, detail sums")
        R.add(f"{key}_share_diff", nat_row.share_difference_pp, _pp(nat_row.share_difference_pp), shp,
              f"geo_code=National, group={grp}: share_difference_pp", f"{grp} share difference, percentage points (abs)")
        if grp not in restricted:
            stv = sh[(sh.geo_code != "National") & (sh.group == grp)].share_difference_pp.abs()
            R.add(f"{key}_state_diff_min", stv.min(), _pp(stv.min()), shp, f"group={grp}, states: min |share_difference_pp|",
                  f"smallest absolute state share difference, {grp}")
            R.add(f"{key}_state_diff_max", stv.max(), _pp(stv.max()), shp, f"group={grp}, states: max |share_difference_pp|",
                  f"largest absolute state share difference, {grp}")
        rr = rk[rk.group == grp].iloc[0]
        R.add(f"{key}_tau", rr.kendall_tau_b, f"{rr.kendall_tau_b:.2f}", rkp, f"group={grp}: kendall_tau_b",
              f"Kendall tau-b, state order of {grp} share")
        R.add(f"{key}_rho", rr.spearman, f"{rr.spearman:.2f}", rkp, f"group={grp}: spearman", f"Spearman, {grp}")
        R.add(f"{key}_shift5", rr[f"jurisdictions_shift_ge_{flag}"], _int(rr[f"jurisdictions_shift_ge_{flag}"]), rkp,
              f"group={grp}: jurisdictions_shift_ge_{flag}", f"jurisdictions moving {flag}+ places, {grp}")
        if grp not in restricted:
            R.add(f"{key}_maxshift", rr.max_abs_rank_shift, _int(rr.max_abs_rank_shift), rkp, f"group={grp}: max_abs_rank_shift",
                  f"largest rank change, {grp}")
        R.add(f"{key}_top10", rr.top10_overlap, _int(rr.top10_overlap), rkp, f"group={grp}: top10_overlap",
              f"states in both top-10 lists, {grp}")
    for yy in [y, *reps]:
        shy = pd.read_csv(RESULTS / f"dy{yy}" / "group_shares.csv", dtype={"geo_code": str})
        rky = pd.read_csv(RESULTS / f"dy{yy}" / "rank_shifts.csv")
        big_groups = set(shy[(shy.geo_code == "National") & (shy.share_published >= 0.01)].group)
        sub = rky[rky.group.isin(big_groups)].sort_values("kendall_tau_b")
        lowest = sub.iloc[0].group
        R.add(f"ins_lowest_big_{yy}", lowest == "A10A", "yes" if lowest == "A10A" else "no", RESULTS / f"dy{yy}" / "rank_shifts.csv",
              "group with lowest kendall_tau_b among groups with national share_published >= 1%",
              f"insulin ordering least stable among groups with at least 1% of class claims, {yy}")
        if lowest != "A10A":
            raise RuntimeError(f"insulin is not the least stable large group in {yy}; text must change")
    R.add("big_group_threshold", 0.01, "1%", rkp, "share_published >= 0.01", "threshold for 'large' groups")
    for grp, key in (("C09XA", "c09xa"), ("C09XX", "c09xx")):
        rr = rk[rk.group == grp].iloc[0]
        R.add(f"{key}_tau", rr.kendall_tau_b, f"{rr.kendall_tau_b:.2f}", rkp, f"group={grp}: kendall_tau_b",
              f"Kendall tau-b, state order of {grp} share")
    for key in ("ins", "c09fdc"):
        v = R.items[f"{key}_share_diff"]["value"]
        R.add(f"{key}_share_diff_round", round(abs(v)), f"{round(abs(v))}", shp, f"round(|{key}_share_diff|)",
              "share difference rounded to whole points")
    big = rk[rk.jurisdictions == 51]
    stable = big[big[f"jurisdictions_shift_ge_{flag}"] <= 2]
    R.add("groups_ranked", len(rk), _int(len(rk)), rkp, "rows", "groups with state orderings")
    R.add("groups_stable", len(stable), _int(len(stable)), rkp, f"groups with 51 jurisdictions and <= 2 moving {flag}+",
          "groups whose state ordering is essentially unchanged")

    # Supplementary provider reconciliation.
    pp_ = d / "provider_reconciliation.json"
    pr = read_json(pp_)
    if pr:
        gap_all = pr["geography_national_claims_all_labels"] - pr["detail_file_claims"]
        R.add("all_geo", pr["geography_national_claims_all_labels"], _int(pr["geography_national_claims_all_labels"]), pp_,
              "geography_national_claims_all_labels", "published national claims, all labels")
        R.add("all_prov", pr["provider_file_claims"], _int(pr["provider_file_claims"]), pp_, "provider_file_claims",
              "By Provider claims, all NPIs")
        R.add("all_detail", pr["detail_file_claims"], _int(pr["detail_file_claims"]), pp_, "detail_file_claims",
              "Provider and Drug claims, all rows")
        R.add("all_R", pr["detail_file_claims"] / pr["geography_national_claims_all_labels"],
              _pct(pr["detail_file_claims"] / pr["geography_national_claims_all_labels"]), pp_,
              "detail_file_claims / geography_national_claims_all_labels", "all drugs, national retained fraction")
        R.add("all_gap", gap_all, _int(gap_all), pp_, "geography - detail", "all drugs, national gap")
        for k, cid in (("claims_in_unpublished_rows_of_npis_with_detail", "decomp_rows"),
                       ("claims_of_npis_without_detail_rows", "decomp_npis"),
                       ("geography_minus_provider_file_claims", "decomp_outside")):
            R.add(cid, pr[k], _int(pr[k]), pp_, k, "component of the all-drug national gap")
            R.add(cid + "_share", pr[k] / gap_all, _pct(pr[k] / gap_all), pp_, f"{k} / all_gap", "share of the all-drug gap",
                  numerator=pr[k], denominator=gap_all)
        R.add("npis_no_detail", pr["npis_provider_only"], _int(pr["npis_provider_only"]), pp_, "npis_provider_only",
              "NPIs in By Provider with no Provider and Drug row")
        ent = {e["entity_code"]: e for e in pr["by_entity_code"]}
        o = ent.get("O", {"npis": 0, "p_clms": 0, "d_clms": 0})
        R.add("org_npis", o["npis"], _int(o["npis"]), pp_, "by_entity_code[O].npis", "organizational NPIs in By Provider")
        R.add("org_claims", o["p_clms"], _int(o["p_clms"]), pp_, "by_entity_code[O].p_clms", "their claims")
        R.add("org_detail_claims", o["d_clms"], _int(o["d_clms"]), pp_, "by_entity_code[O].d_clms", "their detail claims")
        R.add("npis_no_detail_share", pr["npis_provider_only"] / pr["npis_in_provider_file"],
              _pct(pr["npis_provider_only"] / pr["npis_in_provider_file"]), pp_, "npis_provider_only / npis_in_provider_file",
              "share of By Provider NPIs")

    ex = read_json(d / "exploratory_claims_per_prescriber.json")
    if ex:
        exp_ = d / "exploratory_claims_per_prescriber.json"
        R.add("ex_rho_cpp", ex["spearman_label_claims_per_prescriber_vs_retained"],
              f"{ex['spearman_label_claims_per_prescriber_vs_retained']:.2f}", exp_,
              "spearman_label_claims_per_prescriber_vs_retained", "post hoc: label-level rank correlation")
        R.add("ex_rho_volume", ex["spearman_label_total_claims_vs_retained"],
              f"{ex['spearman_label_total_claims_vs_retained']:.2f}", exp_, "spearman_label_total_claims_vs_retained",
              "post hoc: label-level rank correlation with total claims")
        egp = d / "exploratory_claims_per_prescriber.csv"
        eg = pd.read_csv(egp).set_index("group")
        for grp, key in (("A10A", "ins"), ("C10AA", "statin"), ("A10BA", "met")):
            v = eg.loc[grp, "claims_per_prescriber"]
            R.add(f"{key}_cpp", v, f"{v:.1f}", egp, f"group={grp}: claims_per_prescriber",
                  f"post hoc: published claims per published prescriber, {grp}")
    miss = [read_json(RESULTS / f"dy{yy}" / "summary.json")["key_coverage"]["detail_labels_missing_from_reference"]
            for yy in [y, *reps]]
    R.add("unmatched_all_years_text", sum(miss), "none" if sum(miss) == 0 else " + ".join(map(str, miss)),
          RESULTS / f"dy{y}" / "summary.json", "key_coverage.detail_labels_missing_from_reference, all years",
          "detail labels without an exact national reference label, all years")
    outs = []
    for yy in reps:
        bcy = read_json(RESULTS / f"dy{yy}" / "summary.json")["suppression_bound_check"]
        outs.append(bcy["national"]["outside_bounds"] + bcy["all_state_level"]["outside_bounds"])
    R.add("rep_outside_text", sum(outs), "no cell" if sum(outs) == 0 else f"{sum(outs)} cells",
          RESULTS / "replication", "outside_bounds in replication years", "cells outside the bound in 2023 and 2022")
    for yy in [y, *reps]:
        sy = read_json(RESULTS / f"dy{yy}" / "summary.json")
        R.add(f"detail_labels_missing_ref_{yy}", sy["key_coverage"]["detail_labels_missing_from_reference"],
              _int(sy["key_coverage"]["detail_labels_missing_from_reference"]), RESULTS / f"dy{yy}" / "summary.json",
              "key_coverage.detail_labels_missing_from_reference", f"unmatched detail labels, {yy}")

    # Replication.
    rp = RESULTS / "replication" / "replication_summary.json"
    rep = read_json(rp)
    if rep:
        for py in rep["per_year"]:
            yy = py["data_year"]
            R.add(f"R_{yy}", py["weighted_retained"], _pct(py["weighted_retained"]), rp,
                  f"per_year[data_year={yy}].weighted_retained", f"national weighted retained, {yy}")
            for c in ("A10", "C09", "C10"):
                R.add(f"R_{yy}_{c}", py[f"weighted_retained_{c}"], _pct(py[f"weighted_retained_{c}"]), rp,
                      f"per_year[data_year={yy}].weighted_retained_{c}", f"{c} weighted retained, {yy}")
            sy = read_json(RESULTS / f"dy{yy}" / "summary.json")
            R.add(f"Rcost_{yy}", sy["national"]["weighted_retained_cost"], _pct(sy["national"]["weighted_retained_cost"]),
                  RESULTS / f"dy{yy}" / "summary.json", "national.weighted_retained_cost", f"cost retained, {yy}")
            R.add(f"labels_{yy}", sy["scope"]["labels_in_scope"], _int(sy["scope"]["labels_in_scope"]),
                  RESULTS / f"dy{yy}" / "summary.json", "scope.labels_in_scope", f"in-scope labels, {yy}")
            bcy = sy["suppression_bound_check"]
            R.add(f"bound_ok_{yy}", bcy["all_state_level"]["outside_bounds"] + bcy["national"]["outside_bounds"],
                  _int(bcy["all_state_level"]["outside_bounds"] + bcy["national"]["outside_bounds"]),
                  RESULTS / f"dy{yy}" / "summary.json", "outside_bounds (national + state)", f"cells outside bounds, {yy}")
            rky = pd.read_csv(RESULTS / f"dy{yy}" / "rank_shifts.csv")
            ins = rky[rky.group == "A10A"].iloc[0]
            R.add(f"ins_tau_{yy}", ins.kendall_tau_b, f"{ins.kendall_tau_b:.2f}", RESULTS / f"dy{yy}" / "rank_shifts.csv",
                  "group=A10A: kendall_tau_b", f"insulin state-order tau, {yy}")
            R.add(f"ins_shift5_{yy}", ins[f"jurisdictions_shift_ge_{flag}"], _int(ins[f"jurisdictions_shift_ge_{flag}"]),
                  RESULTS / f"dy{yy}" / "rank_shifts.csv", f"group=A10A: jurisdictions_shift_ge_{flag}",
                  f"insulin jurisdictions moving {flag}+, {yy}")
        R.add("labels_all_years", rep["labels_in_all_years"], _int(rep["labels_in_all_years"]), rp, "labels_in_all_years",
              "in-scope labels present in all three years")
        cors = rep["spearman_label_retained_between_years"].values()
        R.add("rep_rho_min", min(cors), f"{min(cors):.2f}", rp, "min spearman_label_retained_between_years",
              "lowest between-year rank correlation of label retained fractions")
        R.add("rep_rho_max", max(cors), f"{max(cors):.2f}", rp, "max spearman_label_retained_between_years",
              "highest between-year rank correlation")
        R.add("labels_changed", sum(v for k, v in rep["labels_by_presence"].items() if k != ";".join(map(str, rep["years"]))),
              _int(sum(v for k, v in rep["labels_by_presence"].items() if k != ";".join(map(str, rep["years"])))), rp,
              "labels_by_presence excluding all-year labels", "in-scope labels not present in every year")

    # Software checks and disclosure.
    vals, mism = 0, 0
    for yy in [y, *reps]:
        c = read_json(RESULTS / f"dy{yy}" / "second_implementation_check.json")
        vals += c["values_compared"]
        mism += c["mismatches"]
    R.add("second_values", vals, _int(vals), RESULTS / f"dy{y}" / "second_implementation_check.json",
          "values_compared summed over years", "values compared by the second implementation")
    R.add("second_mismatches", mism, _int(mism), RESULTS / f"dy{y}" / "second_implementation_check.json",
          "mismatches summed over years", "mismatches")
    rc = read_json(RESULTS / "repro_check.json")
    if rc:
        R.add("repro_files", rc["files_compared"], _int(rc["files_compared"]), RESULTS / "repro_check.json", "files_compared",
              "result files compared in the clean rerun")
        R.add("repro_values", rc["values_compared"], _int(rc["values_compared"]), RESULTS / "repro_check.json",
              "values_compared", "values compared in the clean rerun")
        R.add("repro_maxdiff", rc["max_abs_numeric_difference"], f"{rc['max_abs_numeric_difference']:g}",
              RESULTS / "repro_check.json", "max_abs_numeric_difference", "largest absolute difference")
        md = rc["max_abs_numeric_difference"]
        col = (rc.get("largest_difference_location") or {}).get("column", "")
        where = ("a retained fraction" if col.startswith(("retained", "weighted")) else "a gross cost sum" if "cost" in col
                 else "a group share" if "share" in col else "a 30-day fill sum" if "fills" in col else "a derived value")
        R.add("repro_maxdiff_where", col, where, RESULTS / "repro_check.json", "largest_difference_location.column",
              "where the largest rerun difference occurred")
        R.add("repro_maxdiff_text", md, "0" if md == 0 else f"{md:.5f}".rstrip("0") if md >= 1e-5 else f"{md:.1e}",
              RESULTS / "repro_check.json", "max_abs_numeric_difference (formatted)", "largest absolute difference")
    disc = read_json(ROOT / "exports" / "public" / "disclosure_report.json")
    if disc:
        dp = ROOT / "exports" / "public" / "disclosure_report.json"
        dy = disc["years"][str(y)] if str(y) in disc["years"] else disc["years"][y]
        R.add("withheld_state", dy["state_cells_band_withheld"], _int(dy["state_cells_band_withheld"]), dp,
              f"years.{y}.state_cells_band_withheld", "label-state cells whose retained band is withheld")
        R.add("withheld_state_share", dy["state_cells_band_withheld"] / dy["state_cells"],
              _pct(dy["state_cells_band_withheld"] / dy["state_cells"]), dp, "band withheld / state cells", "share")
        R.add("state_cells_all", dy["state_cells"], _int(dy["state_cells"]), dp, f"years.{y}.state_cells",
              "state-level cells, all geographies")
        au = read_json(ROOT / "exports" / "public" / "public_audit.json")
        if au:
            a0 = [a for a in au["years"] if a["data_year"] == y][0]
            R.add("audit_withheld_checked", a0["withheld_values_checked"], _int(a0["withheld_values_checked"]),
                  ROOT / "exports" / "public" / "public_audit.json", "withheld_values_checked",
                  "withheld values checked by the public-file interval audit")
        nw = dy["national_labels_withheld"]
        R.add("withheld_national", nw, f"{nw} national label row" + ("" if nw == 1 else "s"), dp,
              f"years.{y}.national_labels_withheld", "national label rows withheld (rule and complement)")
        R.add("withheld_group_state", dy["group_state_rows_withheld"], _int(dy["group_state_rows_withheld"]), dp,
              f"years.{y}.group_state_rows_withheld", "group-by-state rows withheld (rule and complement)")
        R.add("withheld_other_agg", dy["other_aggregate_rows_withheld"],
              "no" if dy["other_aggregate_rows_withheld"] == 0 else _int(dy["other_aggregate_rows_withheld"]), dp,
              f"years.{y}.other_aggregate_rows_withheld", "other aggregate rows withheld")
    tests = read_json(RESULTS / "test_summary.json")
    if tests:
        R.add("tests_passed", tests["passed"], _int(tests["passed"]), RESULTS / "test_summary.json", "passed", "pytest tests passed")

    _guard_order_statistics(y)
    out = {"generated_at_utc": utc_now(), "run_id": s["run_id"], "config_sha256": R.cfg_hash,
           "source_sha256": src, "claims": R.items}
    write_json(EVIDENCE / "claims.json", out)
    # Public copy: the full-precision value of each claim is replaced by its published text, so the
    # register cannot be used to recover anything finer than what the paper prints.
    pub = {**out, "claims": {k: {kk: vv for kk, vv in v.items() if kk != "value"} for k, v in R.items.items()},
           "note": "Values are given as printed in the paper; full-precision values are regenerated by the pipeline."}
    write_json(EVIDENCE / "claims_public.json", pub)
    return out


def _guard_order_statistics(year: int) -> None:
    """Stop if a reported median or quartile is interpolated from a withheld label or cell."""
    import numpy as np

    nat = pd.read_csv(RESULTS / f"dy{year}" / "national_reconciliation.csv")
    pub = pd.read_csv(ROOT / "exports" / "public" / f"dy{year}" / "national_reconciliation.csv")
    st = pd.read_csv(RESULTS / f"dy{year}" / "state_reconciliation.csv", dtype={"geo_code": str})
    pst = pd.read_csv(ROOT / "exports" / "public" / f"dy{year}" / "state_reconciliation.csv", dtype={"geo_code": str})
    ev = ["matched", "no public detail", "negative gap"]
    wl = pd.Series(pub.values_withheld.astype(str).eq("True").values, index=nat.index)
    wc = pd.Series(pst.values_withheld.astype(str).eq("True").values, index=st.index)
    well = read_json(RESULTS / f"dy{year}" / "summary.json")["states"]["well_matched_codes"]

    def check(frame, col, mask, qs, what):
        s_ = frame[col].dropna().sort_values()
        for q in qs:
            pos = q * (len(s_) - 1)
            for i in {int(np.floor(pos)), int(np.ceil(pos))}:
                if mask.loc[s_.index[i]]:
                    raise RuntimeError(f"{what} quantile {q} uses a withheld value; report it differently")

    n = nat[nat.status.isin(ev)]
    check(n, "retained_clms", wl, (0.25, 0.5, 0.75), "label retained")
    check(n, "prescriber_coverage", wl, (0.5,), "prescriber coverage")
    sw = st[st.geo_code.isin(well) & st.status.isin(ev)]
    check(sw, "retained_clms", wc, (0.5,), "cell retained")
