"""Download and cache the official CMS files listed in config/sources.toml.

Downloads stream to a temporary .part file with bounded retries and HTTP range
resume. A file is accepted only if the response is not an HTML error page, the
size matches Content-Length, and (for data files) the header row carries the
columns the data dictionary documents. Accepted files are immutable: a later
run re-hashes the cached copy and refuses to overwrite a file whose checksum
no longer matches the manifest.
"""

from __future__ import annotations

import contextlib
import csv
import fcntl
import io
import json
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

from psaudit.common import MANIFEST_DIR, RAW, load_toml, read_json, rel, sha256_file, utc_now, write_json

MANIFEST = MANIFEST_DIR / "source_manifest.json"
USER_AGENT = "psaudit/1.0 (research reproducibility; contact via project repository)"

# Columns each file type must carry. Taken from the CMS data dictionaries.
REQUIRED_COLUMNS = {
    "provider_drug": {
        "Prscrbr_NPI", "Prscrbr_State_Abrvtn", "Prscrbr_State_FIPS", "Prscrbr_Type",
        "Prscrbr_Type_Src", "Brnd_Name", "Gnrc_Name", "Tot_Clms", "Tot_30day_Fills",
        "Tot_Day_Suply", "Tot_Drug_Cst", "Tot_Benes", "GE65_Sprsn_Flag", "GE65_Tot_Clms",
        "GE65_Bene_Sprsn_Flag", "GE65_Tot_Benes",
    },
    "geography_drug": {
        "Prscrbr_Geo_Lvl", "Prscrbr_Geo_Cd", "Prscrbr_Geo_Desc", "Brnd_Name", "Gnrc_Name",
        "Tot_Prscrbrs", "Tot_Clms", "Tot_30day_Fills", "Tot_Drug_Cst", "Tot_Benes",
    },
    "provider": {"PRSCRBR_NPI", "Prscrbr_State_Abrvtn", "Tot_Clms", "Tot_Drug_Cst", "Tot_Benes"},
}

ACCEPTED_DATA_TYPES = ("text/csv", "application/csv", "application/octet-stream", "text/plain")


class AcquisitionError(RuntimeError):
    pass


def _filename(url: str) -> str:
    return Path(urlparse(url).path).name


def _looks_like_html(head: bytes) -> bool:
    probe = head[:512].lstrip().lower()
    return probe.startswith(b"<!doctype") or probe.startswith(b"<html") or b"<head" in probe[:200]


def _check_header(path: Path, kind: str) -> list[str]:
    with open(path, "rb") as fh:
        head = fh.read(1 << 16)
    if _looks_like_html(head):
        raise AcquisitionError(f"{path.name}: body is an HTML page, not data")
    text = head.decode("utf-8-sig", errors="strict")
    header = next(csv.reader(io.StringIO(text.splitlines()[0])))
    required = REQUIRED_COLUMNS.get(kind, set())
    # The provider summary capitalises its NPI column differently across releases.
    present = {h.strip() for h in header}
    lower = {h.lower() for h in present}
    missing = sorted(c for c in required if c not in present and c.lower() not in lower)
    if missing:
        raise AcquisitionError(f"{path.name}: header lacks documented columns {missing}")
    return header


def _download(url: str, dest: Path, retries: int = 4, timeout: int = 120) -> dict:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    session = requests.Session()
    session.headers["User-Agent"] = USER_AGENT
    last_error = None
    meta: dict = {}
    for attempt in range(1, retries + 1):
        have = part.stat().st_size if part.exists() else 0
        headers = {"Range": f"bytes={have}-"} if have else {}
        try:
            with session.get(url, stream=True, timeout=timeout, headers=headers, allow_redirects=True) as r:
                if r.status_code == 416:
                    break
                if r.status_code not in (200, 206):
                    raise AcquisitionError(f"HTTP {r.status_code} for {url}")
                if have and r.status_code == 200:
                    have = 0  # server ignored the range request; start over
                ctype = r.headers.get("Content-Type", "").split(";")[0].strip().lower()
                total = r.headers.get("Content-Length")
                # A compressed transfer reports the encoded length; requests
                # decodes the body, so the length check only applies to
                # identity-encoded responses (all of the CSV files).
                if r.headers.get("Content-Encoding", "identity").lower() not in ("", "identity"):
                    total = None
                total = int(total) + have if total else None
                meta = {
                    "resolved_url": r.url,
                    "http_status": r.status_code,
                    "content_type": ctype,
                    "content_length": total,
                    "last_modified": r.headers.get("Last-Modified"),
                    "etag": r.headers.get("ETag"),
                }
                mode = "ab" if have else "wb"
                with open(part, mode) as fh:
                    for chunk in r.iter_content(chunk_size=8 << 20):
                        fh.write(chunk)
            size = part.stat().st_size
            if meta.get("content_length") and size != meta["content_length"]:
                raise AcquisitionError(f"short read: {size} of {meta['content_length']} bytes")
            break
        except (requests.RequestException, AcquisitionError) as exc:
            last_error = exc
            wait = min(60, 5 * 2 ** (attempt - 1))
            print(f"  attempt {attempt} failed ({exc}); retrying in {wait}s", flush=True)
            time.sleep(wait)
    else:
        raise AcquisitionError(f"download failed after {retries} attempts: {last_error}")
    part.replace(dest)
    return meta


def _entry_for(kind: str, url: str, dest: Path, meta: dict, extra: dict) -> dict:
    entry = {
        "kind": kind,
        "url": url,
        **meta,
        "local_path": rel(dest),
        "bytes": dest.stat().st_size,
        "sha256": sha256_file(dest),
        "accessed_at_utc": utc_now(),
        **extra,
    }
    return entry


def acquire(only_years: list[int] | None = None, include_docs: bool = True) -> dict:
    cfg = load_toml("sources.toml")
    manifest = read_json(MANIFEST, default={"generated_by": "psaudit acquire", "files": []})
    by_path = {f["local_path"]: f for f in manifest["files"]}

    jobs: list[tuple[str, str, Path, dict]] = []
    if include_docs:
        doc = cfg["documentation"]
        jobs.append(("methodology_pdf", doc["methodology_pdf"], RAW / "docs" / _filename(doc["methodology_pdf"]), {}))
    for rel_cfg in cfg["release"]:
        year = rel_cfg["data_year"]
        if only_years and year not in only_years:
            continue
        for kind in ("geography_drug", "provider", "provider_drug"):
            if kind not in rel_cfg:
                continue
            src = rel_cfg[kind]
            dest = RAW / f"dy{year}" / _filename(src["url"])
            extra = {
                "data_year": year,
                "release_year": rel_cfg["release_year"],
                "role": rel_cfg["role"],
                "dataset_uuid": src["dataset_uuid"],
                "catalog_modified": src["catalog_modified"],
                "reference_period": f"{year}-01-01 to {year}-12-31",
                "permitted_use": "CMS public use file; U.S. Government work published on data.cms.gov for public use",
            }
            jobs.append((kind, src["url"], dest, extra))

    for kind, url, dest, extra in jobs:
        key = rel(dest)
        prior = by_path.get(key)
        if dest.exists() and prior:
            digest = sha256_file(dest)
            if digest != prior["sha256"]:
                raise AcquisitionError(f"cached file {key} changed on disk (sha256 {digest} != manifest {prior['sha256']})")
            print(f"cached  {key}  sha256 ok", flush=True)
            continue
        print(f"fetch   {url}", flush=True)
        t0 = time.time()
        meta = _download(url, dest)
        is_doc = kind == "methodology_pdf"
        if is_doc:
            with open(dest, "rb") as fh:
                head = fh.read(8)
            if kind == "methodology_pdf" and not head.startswith(b"%PDF"):
                dest.unlink()
                raise AcquisitionError(f"{url} did not return a PDF")
        else:
            if meta.get("content_type") and meta["content_type"] not in ACCEPTED_DATA_TYPES:
                dest.unlink()
                raise AcquisitionError(f"{url} returned content type {meta['content_type']}")
            header = _check_header(dest, kind)
            extra = {**extra, "header": header}
        entry = _entry_for(kind, url, dest, meta, extra)
        entry["download_seconds"] = round(time.time() - t0, 1)
        if prior and prior.get("sha256"):
            # A fresh download of a file already in the shipped manifest: compare, and keep the
            # recorded value. CMS revises files, so a mismatch is reported rather than fatal.
            entry["sha256_recorded"] = prior["sha256"]
            entry["matches_recorded"] = entry["sha256"] == prior["sha256"]
            if not entry["matches_recorded"]:
                print(f"WARNING {key}: checksum differs from the recorded value; CMS may have revised the file. "
                      "Results may not reproduce exactly.", flush=True)
        with _manifest_lock():
            # Several acquire processes may run at once (one per data year), so
            # merge into the manifest as it is on disk now.
            manifest = read_json(MANIFEST, default={"generated_by": "psaudit acquire", "files": []})
            current = {f["local_path"]: f for f in manifest["files"]}
            current[key] = entry
            manifest["files"] = sorted(current.values(), key=lambda f: f["local_path"])
            manifest["updated_at_utc"] = utc_now()
            write_json(MANIFEST, manifest)
        by_path[key] = entry
        print(f"stored  {key}  {entry['bytes']:,} bytes  sha256 {entry['sha256'][:16]}", flush=True)
    if include_docs:
        fetch_dictionaries()
    return read_json(MANIFEST)


@contextlib.contextmanager
def _manifest_lock():
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    with open(MANIFEST.with_suffix(".lock"), "w") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


DICTIONARY_SLUGS = {
    "provider_drug": "medicare-part-d-prescribers-by-provider-and-drug-data-dictionary",
    "geography_drug": "medicare-part-d-prescribers-by-geography-and-drug-data-dictionary",
    "provider": "medicare-part-d-prescribers-by-provider-data-dictionary",
}


def _plain(value) -> str:
    import html as _html
    import re as _re

    if isinstance(value, dict):
        value = value.get("value") or value.get("processed") or ""
    if isinstance(value, list):
        return " | ".join(_plain(v) for v in value)
    text = _html.unescape(_re.sub(r"<[^>]+>", " ", str(value or "")))
    return _re.sub(r"\s+", " ", text).strip()


def fetch_dictionaries() -> list[dict]:
    """Save the CMS data dictionaries through the site's JSON API.

    The dictionary web pages are rendered in the browser from this API, so a
    plain page download only returns an empty application shell.
    """
    session = requests.Session()
    session.headers["User-Agent"] = USER_AGENT
    out_dir = RAW / "docs"
    out_dir.mkdir(parents=True, exist_ok=True)
    entries = []
    for kind, slug in DICTIONARY_SLUGS.items():
        meta = session.get("https://data.cms.gov/data-api/v1/slug", params={"path": f"/resources/{slug}"}, timeout=60)
        meta.raise_for_status()
        node = meta.json()["data"]
        url = "https://data.cms.gov/jsonapi/paragraph/dictionary_term"
        params = {"filter[parent_id]": node["drupal_id"], "include": "field_dictionary_term_table,field_dict_term_opt_items"}
        r = session.get(url, params=params, timeout=60)
        r.raise_for_status()
        data = r.json()
        if not data.get("data"):
            raise AcquisitionError(f"dictionary {slug} returned no terms")
        dest = out_dir / f"dictionary_{kind}.json"
        dest.write_text(json.dumps({"page": node, "terms": data}, indent=1, sort_keys=True) + "\n")
        included = {i["id"]: i for i in data.get("included", [])}
        lines = [f"# {node['name']}", f"Source: https://data.cms.gov/resources/{slug}",
                 f"Page last modified (CMS): {node.get('last_modified_date')}", f"Retrieved: {utc_now()}", ""]
        for t in data["data"]:
            a = t["attributes"]
            lines.append(f"{_plain(a.get('field_dictionary_term_short_name'))}: {_plain(a.get('field_dictionary_term_full_name'))}")
            lines.append(f"  {_plain(a.get('field_dictionary_term_definition'))}")
            foot = _plain(a.get("field_dictionary_term_footnote"))
            if foot and foot != "None":
                lines.append(f"  Note: {foot}")
            for rel_name, rel_val in t.get("relationships", {}).items():
                items = rel_val.get("data") or []
                items = items if isinstance(items, list) else [items]
                for it in items:
                    inc = included.get(it["id"])
                    if inc and inc["attributes"].get("field_wysiwyg_table"):
                        lines.append(f"  {_plain(inc['attributes']['field_wysiwyg_table'])}")
            lines.append("")
        txt = out_dir / f"dictionary_{kind}.txt"
        txt.write_text("\n".join(lines) + "\n")
        for p, k in ((dest, "data_dictionary_json"), (txt, "data_dictionary_text")):
            entries.append({"kind": k, "dictionary_for": kind, "url": r.url, "local_path": rel(p), "bytes": p.stat().st_size,
                            "sha256": sha256_file(p), "accessed_at_utc": utc_now(),
                            "cms_page_last_modified": node.get("last_modified_date"),
                            "note": "Mutable web resource; the saved copy is the version used."})
    with _manifest_lock():
        manifest = read_json(MANIFEST, default={"generated_by": "psaudit acquire", "files": []})
        files = {f["local_path"]: f for f in manifest["files"] if not f["kind"].startswith("dictionary_")}
        for e in entries:
            files[e["local_path"]] = e
        manifest["files"] = sorted(files.values(), key=lambda f: f["local_path"])
        manifest["updated_at_utc"] = utc_now()
        write_json(MANIFEST, manifest)
    return entries
