"""Build typed tables from the cached raw files.

The national detail file is read once, in a streaming DuckDB scan with declared
column types and strict CSV parsing, and written to Parquet. Prescriber names
and cities are not carried into the warehouse because no analysis needs them.
Each typed table is checked for key uniqueness before anything joins it.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import duckdb

from psaudit.common import MANIFEST_DIR, WAREHOUSE, load_toml, read_json, rel, utc_now, write_json

DETAIL_TYPES = {
    "Prscrbr_NPI": "VARCHAR", "Prscrbr_Last_Org_Name": "VARCHAR", "Prscrbr_First_Name": "VARCHAR",
    "Prscrbr_City": "VARCHAR", "Prscrbr_State_Abrvtn": "VARCHAR", "Prscrbr_State_FIPS": "VARCHAR",
    "Prscrbr_Type": "VARCHAR", "Prscrbr_Type_Src": "VARCHAR", "Brnd_Name": "VARCHAR", "Gnrc_Name": "VARCHAR",
    "Tot_Clms": "DOUBLE", "Tot_30day_Fills": "DOUBLE", "Tot_Day_Suply": "DOUBLE", "Tot_Drug_Cst": "DOUBLE",
    "Tot_Benes": "DOUBLE", "GE65_Sprsn_Flag": "VARCHAR", "GE65_Tot_Clms": "DOUBLE",
    "GE65_Tot_30day_Fills": "DOUBLE", "GE65_Tot_Drug_Cst": "DOUBLE", "GE65_Tot_Day_Suply": "DOUBLE",
    "GE65_Bene_Sprsn_Flag": "VARCHAR", "GE65_Tot_Benes": "DOUBLE",
}

GEO_TYPES = {
    "Prscrbr_Geo_Lvl": "VARCHAR", "Prscrbr_Geo_Cd": "VARCHAR", "Prscrbr_Geo_Desc": "VARCHAR",
    "Brnd_Name": "VARCHAR", "Gnrc_Name": "VARCHAR", "Tot_Prscrbrs": "DOUBLE", "Tot_Clms": "DOUBLE",
    "Tot_30day_Fills": "DOUBLE", "Tot_Drug_Cst": "DOUBLE", "Tot_Benes": "DOUBLE", "GE65_Sprsn_Flag": "VARCHAR",
    "GE65_Tot_Clms": "DOUBLE", "GE65_Tot_30day_Fills": "DOUBLE", "GE65_Tot_Drug_Cst": "DOUBLE",
    "GE65_Bene_Sprsn_Flag": "VARCHAR", "GE65_Tot_Benes": "DOUBLE", "LIS_Bene_Cst_Shr": "DOUBLE",
    "NonLIS_Bene_Cst_Shr": "DOUBLE", "Opioid_Drug_Flag": "VARCHAR", "Opioid_LA_Drug_Flag": "VARCHAR",
    "Antbtc_Drug_Flag": "VARCHAR", "Antpsyct_Drug_Flag": "VARCHAR",
}

# Provider summary columns used by the supplementary reconciliation.
PROVIDER_KEEP = ["Prscrbr_NPI", "Prscrbr_Ent_Cd", "Prscrbr_State_Abrvtn", "Prscrbr_State_FIPS", "Prscrbr_Cntry",
                 "Prscrbr_Type", "Tot_Clms", "Tot_30day_Fills", "Tot_Drug_Cst", "Tot_Benes",
                 "Brnd_Sprsn_Flag", "Brnd_Tot_Clms", "Gnrc_Sprsn_Flag", "Gnrc_Tot_Clms", "Othr_Sprsn_Flag",
                 "Othr_Tot_Clms"]


class BuildError(RuntimeError):
    pass


def connect(db_path: Path | None = None) -> duckdb.DuckDBPyConnection:
    cfg = load_toml("analysis.toml")["duckdb"]
    WAREHOUSE.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(db_path) if db_path else ":memory:")
    con.execute(f"SET memory_limit='{cfg['memory_limit']}'")
    con.execute(f"SET threads={int(cfg['threads'])}")
    con.execute("SET preserve_insertion_order=false")
    return con


def _source_files(year: int) -> dict[str, dict]:
    manifest = read_json(MANIFEST_DIR / "source_manifest.json")
    if not manifest:
        raise BuildError("no source manifest; run `psaudit acquire` first")
    out = {f["kind"]: f for f in manifest["files"] if f.get("data_year") == year}
    for kind in ("provider_drug", "geography_drug"):
        if kind not in out:
            raise BuildError(f"data year {year}: {kind} not acquired")
    return out


def _types_sql(types: dict[str, str]) -> str:
    return "{" + ", ".join(f"'{k}': '{v}'" for k, v in types.items()) + "}"


def _read_csv_sql(path: str, types: dict[str, str]) -> str:
    return (f"read_csv('{path}', header=true, delim=',', quote='\"', escape='\"', columns={_types_sql(types)}, "
            "auto_detect=false, strict_mode=true, ignore_errors=false, null_padding=false, nullstr='')")


def _assert_integral(con, table: str, cols: list[str]) -> None:
    for c in cols:
        bad = con.execute(f"SELECT count(*) FROM {table} WHERE {c} IS NOT NULL AND {c} <> round({c})").fetchone()[0]
        if bad:
            raise BuildError(f"{table}.{c}: {bad} non-integer values in an integer count column")


def _assert_unique(con, table: str, keys: list[str]) -> int:
    k = ", ".join(keys)
    dups = con.execute(f"SELECT count(*) FROM (SELECT {k}, count(*) n FROM {table} GROUP BY ALL HAVING n > 1)").fetchone()[0]
    if dups:
        raise BuildError(f"{table}: {dups} duplicate keys on ({k})")
    return 0


def _header(path: str | Path) -> list[str]:
    with open(path, encoding="utf-8-sig", newline="") as fh:
        return next(csv.reader(fh))


def build_year(year: int, force: bool = False) -> dict:
    files = _source_files(year)
    out_dir = WAREHOUSE / f"dy{year}"
    expected = {k: v["sha256"] for k, v in files.items()}
    prior = read_json(out_dir / "build_summary.json")
    if (prior and not force and prior.get("source_sha256") == expected
            and (out_dir / "provider_drug.parquet").exists() and (out_dir / "geography_drug.parquet").exists()):
        print(f"dy{year}: build is current (source checksums unchanged)")
        return prior
    return build_pair(
        detail_src=_abs(files["provider_drug"]["local_path"]),
        geo_src=_abs(files["geography_drug"]["local_path"]),
        out_dir=out_dir,
        provider_src=_abs(files["provider"]["local_path"]) if "provider" in files else None,
        label=f"dy{year}",
        extra={"data_year": year, "source_sha256": expected},
    )


def _abs(local_path: str) -> str:
    from psaudit.common import ROOT
    p = Path(local_path)
    return str(p if p.is_absolute() else ROOT / p)


def build_pair(detail_src: str, geo_src: str, out_dir: Path, provider_src: str | None = None, label: str = "pair",
               extra: dict | None = None) -> dict:
    """Ingest one official release pair (detail + geography summary) into typed Parquet tables."""
    out_dir.mkdir(parents=True, exist_ok=True)
    detail_pq = out_dir / "provider_drug.parquet"
    geo_pq = out_dir / "geography_drug.parquet"
    summary_path = out_dir / "build_summary.json"
    con = connect()
    t0 = utc_now()

    # Header must match the declared schema exactly, in order.
    header = _header(detail_src)
    if header != list(DETAIL_TYPES):
        raise BuildError(f"{label} detail header differs from the declared schema: {header}")
    gheader = _header(geo_src)
    if gheader != list(GEO_TYPES):
        raise BuildError(f"{label} geography header differs from the declared schema: {gheader}")

    print(f"{label}: scanning detail file {detail_src}", flush=True)
    con.execute(f"""
        CREATE TABLE detail AS
        SELECT trim(Prscrbr_NPI) AS npi,
               trim(Prscrbr_State_Abrvtn) AS state_abbr,
               coalesce(nullif(trim(Prscrbr_State_FIPS), ''), 'BLANK') AS state_code,
               Prscrbr_Type AS prscrbr_type,
               Prscrbr_Type_Src AS prscrbr_type_src,
               trim(Brnd_Name) AS brnd_name,
               trim(Gnrc_Name) AS gnrc_name,
               Tot_Clms AS tot_clms, Tot_30day_Fills AS tot_30day_fills, Tot_Day_Suply AS tot_day_suply,
               Tot_Drug_Cst AS tot_drug_cst, Tot_Benes AS tot_benes,
               GE65_Sprsn_Flag AS ge65_sprsn_flag, GE65_Tot_Clms AS ge65_tot_clms,
               GE65_Bene_Sprsn_Flag AS ge65_bene_sprsn_flag, GE65_Tot_Benes AS ge65_tot_benes
        FROM {_read_csv_sql(detail_src, DETAIL_TYPES)}
    """)
    n_detail = con.execute("SELECT count(*) FROM detail").fetchone()[0]
    _assert_integral(con, "detail", ["tot_clms", "tot_benes", "ge65_tot_clms", "ge65_tot_benes"])
    bad_npi = con.execute("SELECT count(*) FROM detail WHERE NOT regexp_full_match(npi, '[0-9]{10}')").fetchone()[0]
    if bad_npi:
        raise BuildError(f"{label}: {bad_npi} detail rows with a malformed NPI")
    null_keys = con.execute("SELECT count(*) FROM detail WHERE brnd_name IS NULL OR gnrc_name IS NULL OR tot_clms IS NULL").fetchone()[0]
    if null_keys:
        raise BuildError(f"{label}: {null_keys} detail rows missing a drug key or claim count")
    _assert_unique(con, "detail", ["npi", "brnd_name", "gnrc_name"])
    detail_stats = con.execute("""
        SELECT min(tot_clms), max(tot_clms), count(DISTINCT npi), count(DISTINCT (brnd_name, gnrc_name)),
               count(*) FILTER (WHERE tot_benes IS NULL), count(DISTINCT state_code)
        FROM detail""").fetchone()
    con.execute(f"COPY detail TO '{detail_pq}' (FORMAT parquet, COMPRESSION zstd)")

    print(f"{label}: reading geography file {geo_src}", flush=True)
    con.execute(f"""
        CREATE TABLE geo AS
        SELECT Prscrbr_Geo_Lvl AS geo_level,
               CASE WHEN Prscrbr_Geo_Lvl = 'National' THEN 'National'
                    ELSE coalesce(trim(Prscrbr_Geo_Cd), 'BLANK') END AS geo_code,
               Prscrbr_Geo_Desc AS geo_desc,
               trim(Brnd_Name) AS brnd_name, trim(Gnrc_Name) AS gnrc_name,
               Tot_Prscrbrs AS tot_prscrbrs, Tot_Clms AS tot_clms, Tot_30day_Fills AS tot_30day_fills,
               Tot_Drug_Cst AS tot_drug_cst, Tot_Benes AS tot_benes,
               GE65_Sprsn_Flag AS ge65_sprsn_flag, GE65_Tot_Clms AS ge65_tot_clms,
               GE65_Bene_Sprsn_Flag AS ge65_bene_sprsn_flag, GE65_Tot_Benes AS ge65_tot_benes
        FROM {_read_csv_sql(geo_src, GEO_TYPES)}
    """)
    n_geo_raw = con.execute("SELECT count(*) FROM geo").fetchone()[0]
    # Rows with no geography level and no drug key are not data records.
    blank_rows = con.execute(
        "SELECT count(*) FROM geo WHERE geo_level IS NULL AND brnd_name IS NULL AND gnrc_name IS NULL").fetchone()[0]
    con.execute("DELETE FROM geo WHERE geo_level IS NULL AND brnd_name IS NULL AND gnrc_name IS NULL")
    odd = con.execute("SELECT count(*) FROM geo WHERE geo_level NOT IN ('National', 'State') OR geo_level IS NULL "
                      "OR geo_code IS NULL OR brnd_name IS NULL OR gnrc_name IS NULL").fetchone()[0]
    if odd:
        rows = con.execute("SELECT * FROM geo WHERE geo_level NOT IN ('National', 'State') OR geo_level IS NULL "
                           "OR geo_code IS NULL OR brnd_name IS NULL OR gnrc_name IS NULL LIMIT 5").fetchall()
        raise BuildError(f"{label}: {odd} geography rows with an unexpected level or missing key, e.g. {rows}")
    # A state-level row can arrive without a geography code (one in 2024 and
    # 2023). It is kept under the code BLANK and reported, never assigned a state.
    blank_code_rows = con.execute("SELECT count(*) FROM geo WHERE geo_code = 'BLANK'").fetchone()[0]
    _assert_integral(con, "geo", ["tot_clms", "tot_prscrbrs", "tot_benes"])
    _assert_unique(con, "geo", ["geo_level", "geo_code", "brnd_name", "gnrc_name"])
    geo_stats = con.execute("""
        SELECT count(*) FILTER (WHERE geo_level = 'National'), count(*) FILTER (WHERE geo_level = 'State'),
               count(DISTINCT geo_code) FILTER (WHERE geo_level = 'State'), min(tot_clms),
               count(*) FILTER (WHERE tot_clms IS NULL)
        FROM geo""").fetchone()
    con.execute(f"COPY geo TO '{geo_pq}' (FORMAT parquet, COMPRESSION zstd)")

    provider = None
    if provider_src:
        prov_src = provider_src
        print(f"{label}: reading provider summary {prov_src}", flush=True)
        prov_pq = out_dir / "provider.parquet"
        pheader = _header(prov_src)
        missing = [c for c in PROVIDER_KEEP if c not in pheader]
        if missing:
            raise BuildError(f"{label} provider summary lacks columns {missing}")
        cols = ", ".join(f"\"{c}\"" for c in PROVIDER_KEEP)
        con.execute(f"""
            CREATE TABLE provider AS
            SELECT {cols} FROM {_read_csv_sql(prov_src, {c: "VARCHAR" for c in pheader})}
        """)
        con.execute("""
            CREATE TABLE provider_typed AS
            SELECT trim(Prscrbr_NPI) AS npi, Prscrbr_Ent_Cd AS entity_code, trim(Prscrbr_State_FIPS) AS state_code,
                   Prscrbr_Cntry AS country, Prscrbr_Type AS prscrbr_type,
                   CAST(Tot_Clms AS DOUBLE) AS tot_clms, CAST(Tot_30day_Fills AS DOUBLE) AS tot_30day_fills,
                   CAST(Tot_Drug_Cst AS DOUBLE) AS tot_drug_cst, CAST(Tot_Benes AS DOUBLE) AS tot_benes,
                   Brnd_Sprsn_Flag AS brnd_sprsn_flag, CAST(Brnd_Tot_Clms AS DOUBLE) AS brnd_tot_clms,
                   Gnrc_Sprsn_Flag AS gnrc_sprsn_flag, CAST(Gnrc_Tot_Clms AS DOUBLE) AS gnrc_tot_clms,
                   Othr_Sprsn_Flag AS othr_sprsn_flag, CAST(Othr_Tot_Clms AS DOUBLE) AS othr_tot_clms
            FROM provider
        """)
        _assert_integral(con, "provider_typed", ["tot_clms"])
        _assert_unique(con, "provider_typed", ["npi"])
        n_prov = con.execute("SELECT count(*) FROM provider_typed").fetchone()[0]
        con.execute(f"COPY provider_typed TO '{prov_pq}' (FORMAT parquet, COMPRESSION zstd)")
        provider = {"rows": n_prov, "parquet": rel(prov_pq)}

    summary = {
        **(extra or {}),
        "label": label,
        "built_at_utc": utc_now(),
        "started_at_utc": t0,
        "detail": {
            "rows": n_detail, "parquet": rel(detail_pq), "min_tot_clms": detail_stats[0], "max_tot_clms": detail_stats[1],
            "distinct_npi": detail_stats[2], "distinct_labels": detail_stats[3], "blank_tot_benes": detail_stats[4],
            "distinct_state_codes": detail_stats[5],
            "columns_dropped": ["Prscrbr_Last_Org_Name", "Prscrbr_First_Name", "Prscrbr_City", "GE65 fills, cost and day supply"],
        },
        "geography": {
            "rows_read": n_geo_raw, "blank_non_data_rows_removed": blank_rows,
            "state_rows_without_code": blank_code_rows, "national_rows": geo_stats[0],
            "state_rows": geo_stats[1], "state_codes": geo_stats[2], "min_tot_clms": geo_stats[3],
            "blank_tot_clms": geo_stats[4], "parquet": rel(geo_pq),
        },
        "provider": provider,
        "checks": ["declared header order", "strict CSV row width", "integer claim and beneficiary counts",
                   "10-digit NPI", "no missing drug key or claim count", "unique (NPI, brand, generic)",
                   "unique (level, code, brand, generic)", "unique provider NPI"],
    }
    write_json(summary_path, summary)
    print(json.dumps(summary, indent=1))
    return summary
