"""Independent recomputation and rerun comparison.

second_implementation() re-derives the detail sums and the published totals from
the raw CSV files with the Python standard library only (csv + decimal), without
DuckDB, Parquet or pandas, and compares them with the primary results.

compare_dirs() compares two results folders value by value within the declared
tolerance. It is used for the clean rerun from cached inputs.
"""

from __future__ import annotations

import csv
import json
import math
import os
import shutil
import subprocess
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

from psaudit.common import MANIFEST_DIR, RESULTS, ROOT, WAREHOUSE, load_toml, read_json, rel, utc_now, write_json

VOLATILE_KEYS = {"generated_at_utc", "finished_at_utc", "run_id", "built_at_utc", "started_at_utc", "outputs", "parquet", "compared_at_utc"}


def _raw_path(year: int, kind: str) -> Path:
    manifest = read_json(MANIFEST_DIR / "source_manifest.json")
    for f in manifest["files"]:
        if f.get("data_year") == year and f["kind"] == kind:
            p = Path(f["local_path"])
            return p if p.is_absolute() else ROOT / p
    raise FileNotFoundError(f"{kind} for {year} not in manifest")


def _dec(text: str) -> Decimal | None:
    text = text.strip()
    return Decimal(text) if text else None


def _same(primary, second, tol) -> bool:
    if tol is None:
        return str(primary) == str(second)
    if primary is None or second is None:
        return primary is None and second is None
    return abs(primary - second) <= tol


def _derived(r: dict, a, p, d_clms: int, d_rows: int) -> list:
    """Status, retained fraction and bound check recomputed from the second implementation's own sums."""
    if a is None:
        status = "detail without reference"
    elif a == 0:
        status = "zero published total"
    elif d_clms == 0:
        status = "no public detail"
    elif d_clms > a:
        status = "negative gap"
    else:
        status = "matched"
    out = [("status", r["status"], status, None)]
    if a:
        out.append(("retained_clms", float(r["retained_clms"]), d_clms / a, 1e-12))
        m, g = p - d_rows, a - d_clms
        ok = (m == 0 and g == 0) or (m >= 1 and m <= g <= 10 * m)
        out.append(("bound_ok", r["bound_ok"], str(ok), None))
    return out


def second_implementation(year: int) -> dict:
    out = RESULTS / f"dy{year}"
    scope_rows = list(csv.DictReader(open(out / "mapping_decisions.csv", encoding="utf-8", newline="")))
    in_scope = {(r["brnd_name"], r["gnrc_name"]) for r in scope_rows if r["in_scope"] == "True"}

    nat = defaultdict(lambda: [0, 0, Decimal(0), Decimal(0)])      # claims, rows, cost, fills
    sta = defaultdict(lambda: [0, 0, Decimal(0), Decimal(0)])
    rows_total = 0
    claims_total = 0
    width_errors = 0
    with open(_raw_path(year, "provider_drug"), encoding="utf-8-sig", newline="") as fh:
        reader = csv.reader(fh)
        header = next(reader)
        ix = {name: i for i, name in enumerate(header)}
        n_cols = len(header)
        for row in reader:
            rows_total += 1
            if len(row) != n_cols:
                width_errors += 1
                continue
            clm = _dec(row[ix["Tot_Clms"]])
            if clm != clm.to_integral_value():
                raise ValueError(f"non-integer Tot_Clms in row {rows_total}")
            clm = int(clm)
            claims_total += clm
            key = (row[ix["Brnd_Name"]].strip(), row[ix["Gnrc_Name"]].strip())
            if key not in in_scope:
                continue
            cost = _dec(row[ix["Tot_Drug_Cst"]]) or Decimal(0)
            fills = _dec(row[ix["Tot_30day_Fills"]]) or Decimal(0)
            state = row[ix["Prscrbr_State_FIPS"]].strip() or "BLANK"
            for acc in (nat[key], sta[(key, state)]):
                acc[0] += clm
                acc[1] += 1
                acc[2] += cost
                acc[3] += fills

    ref_nat, ref_sta = {}, {}
    with open(_raw_path(year, "geography_drug"), encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            if not r["Prscrbr_Geo_Lvl"]:
                continue
            key = (r["Brnd_Name"].strip(), r["Gnrc_Name"].strip())
            if key not in in_scope:
                continue
            val = (int(Decimal(r["Tot_Clms"])), int(Decimal(r["Tot_Prscrbrs"])))
            if r["Prscrbr_Geo_Lvl"] == "National":
                ref_nat[key] = val
            else:
                ref_sta[(key, (r["Prscrbr_Geo_Cd"] or "").strip() or "BLANK")] = val

    tol = load_toml("analysis.toml")["decimal_field_tolerance"]
    mismatches = []
    compared = 0
    with open(out / "national_reconciliation.csv", encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            key = (r["brnd_name"], r["gnrc_name"])
            d = nat.get(key, [0, 0, Decimal(0), Decimal(0)])
            a, p = ref_nat.get(key, (None, None))
            checks = [("d_clms", float(r["d_clms"] or 0), d[0], 0), ("d_rows", float(r["d_rows"] or 0), d[1], 0),
                      ("d_cost", float(r["d_cost"] or 0), float(d[2]), tol),
                      ("d_fills", float(r["d_fills"] or 0), float(d[3]), tol),
                      ("a_clms", float(r["a_clms"]) if r["a_clms"] else None, a, 0),
                      ("a_prscrbrs", float(r["a_prscrbrs"]) if r["a_prscrbrs"] else None, p, 0)]
            checks += _derived(r, a, p, d[0], d[1])
            for name, primary, second, t in checks:
                compared += 1
                if not _same(primary, second, t):
                    mismatches.append({"level": "National", "key": key, "field": name, "primary": primary, "second": second})
    with open(out / "state_reconciliation.csv", encoding="utf-8", newline="") as fh:
        for r in csv.DictReader(fh):
            key = ((r["brnd_name"], r["gnrc_name"]), r["geo_code"])
            d = sta.get(key, [0, 0, Decimal(0), Decimal(0)])
            a, p = ref_sta.get(key, (None, None))
            checks = [("d_clms", float(r["d_clms"] or 0), d[0], 0), ("d_rows", float(r["d_rows"] or 0), d[1], 0),
                      ("d_cost", float(r["d_cost"] or 0), float(d[2]), tol),
                      ("d_fills", float(r["d_fills"] or 0), float(d[3]), tol),
                      ("a_clms", float(r["a_clms"]) if r["a_clms"] else None, a, 0),
                      ("a_prscrbrs", float(r["a_prscrbrs"]) if r["a_prscrbrs"] else None, p, 0)]
            checks += _derived(r, a, p, d[0], d[1])
            for name, primary, second, t in checks:
                compared += 1
                if not _same(primary, second, t):
                    mismatches.append({"level": "State", "key": key, "field": name, "primary": primary, "second": second})
    # Every second-implementation cell must appear in the primary output too.
    primary_state_keys = {((r["brnd_name"], r["gnrc_name"]), r["geo_code"])
                          for r in csv.DictReader(open(out / "state_reconciliation.csv", encoding="utf-8", newline=""))}
    missing_in_primary = [k for k in set(sta) | set(ref_sta) if k not in primary_state_keys]

    build = read_json(WAREHOUSE / f"dy{year}" / "build_summary.json") or {}
    res = {
        "data_year": year,
        "implementation": "Python standard library csv + decimal streaming over the raw CMS files (no DuckDB, Parquet or pandas)",
        "scope": "uses the primary run's in-scope label list (mapping_decisions.csv); recomputes detail claims, rows, cost "
                 "and fills, published claims and prescribers, status, retained fraction and the bound check for every "
                 "national and state cell; shares and rank statistics are not recomputed",
        "compared_at_utc": utc_now(),
        "raw_detail_rows": rows_total,
        "primary_build_detail_rows": build.get("detail", {}).get("rows"),
        "row_counts_agree": build.get("detail", {}).get("rows") == rows_total if build else None,
        "row_width_errors": width_errors,
        "raw_detail_claims_all_labels": claims_total,
        "in_scope_labels": len(in_scope),
        "values_compared": compared,
        "mismatches": len(mismatches),
        "mismatch_examples": [{**m, "key": str(m["key"])} for m in mismatches[:20]],
        "cells_missing_from_primary_output": len(missing_in_primary),
        "tolerance": {"integer_fields": 0, "decimal_fields": tol},
    }
    write_json(out / "second_implementation_check.json", res)
    return res


def _flatten(obj, prefix=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in VOLATILE_KEYS:
                continue
            yield from _flatten(v, f"{prefix}.{k}" if prefix else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _flatten(v, f"{prefix}[{i}]")
    else:
        yield prefix, obj


def _close(a, b, atol, rtol) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        if math.isnan(a) and math.isnan(b):
            return True
        return abs(a - b) <= atol + rtol * abs(b)
    return a == b


def _num(text: str):
    try:
        return float(text)
    except ValueError:
        return text


def compare_dirs(a: Path, b: Path) -> dict:
    cfg = load_toml("analysis.toml")
    atol, rtol = cfg["abs_tolerance"], cfg["rel_tolerance"]
    files_a = {p.relative_to(a) for p in a.rglob("*") if p.is_file() and p.suffix in (".csv", ".json", ".jsonl")}
    files_b = {p.relative_to(b) for p in b.rglob("*") if p.is_file() and p.suffix in (".csv", ".json", ".jsonl")}
    skip = {Path("repro_check.json"), Path("render_summary.json"), Path("test_summary.json")} | {
        p for p in files_a | files_b if p.name == "second_implementation_check.json"} | {
        p for p in files_a | files_b if p.parts[0] == "figures"}
    common = sorted((files_a & files_b) - skip, key=str)
    diffs, values, max_abs, where = [], 0, 0.0, {}
    for f in common:
        if f.suffix == ".csv":
            ra = list(csv.reader(open(a / f, encoding="utf-8", newline="")))
            rb = list(csv.reader(open(b / f, encoding="utf-8", newline="")))
            if len(ra) != len(rb) or (ra and ra[0] != rb[0]):
                diffs.append({"file": str(f), "issue": "shape or header differs"})
                continue
            for i, (x, y) in enumerate(zip(ra[1:], rb[1:]), start=2):
                for j, (u, v) in enumerate(zip(x, y)):
                    values += 1
                    nu, nv = _num(u), _num(v)
                    if isinstance(nu, float) and isinstance(nv, float):
                        if not math.isnan(nu) and abs(nu - nv) > max_abs:
                            max_abs = abs(nu - nv)
                            where = {"file": str(f), "row": i, "column": ra[0][j], "first": u, "second": v}
                    if not _close(nu, nv, atol, rtol):
                        diffs.append({"file": str(f), "row": i, "column": ra[0][j], "a": u, "b": v})
        elif f.suffix == ".json":
            fa = dict(_flatten(json.loads((a / f).read_text())))
            fb = dict(_flatten(json.loads((b / f).read_text())))
            for k in sorted(set(fa) | set(fb)):
                values += 1
                if k not in fa or k not in fb or not _close(fa[k], fb[k], atol, rtol):
                    diffs.append({"file": str(f), "key": k, "a": fa.get(k), "b": fb.get(k)})
        else:
            la = [json.loads(x) for x in (a / f).read_text().splitlines()]
            lb = [json.loads(x) for x in (b / f).read_text().splitlines()]
            values += len(la)
            if la != lb:
                diffs.append({"file": str(f), "issue": "jsonl records differ"})
    return {
        "compared_at_utc": utc_now(),
        "files_compared": len(common),
        "only_in_first": sorted(str(x) for x in files_a - files_b - skip),
        "only_in_second": sorted(str(x) for x in files_b - files_a - skip),
        "values_compared": values,
        "differences": len(diffs),
        "difference_examples": diffs[:20],
        "max_abs_numeric_difference": max_abs,
        "largest_difference_location": where,
        "tolerance": {"absolute": atol, "relative": rtol},
        "identical_within_tolerance": not diffs and not (files_a - files_b - skip) and not (files_b - files_a - skip),
    }


def repro_check(years: list[int]) -> dict:
    """Rebuild and reanalyze from the cached raw files into a scratch folder, then compare."""
    scratch = ROOT / ".local" / "rerun"
    if scratch.exists():
        shutil.rmtree(scratch)
    env = {**os.environ, "PSAUDIT_WAREHOUSE": str(scratch / "warehouse"), "PSAUDIT_RESULTS": str(scratch / "results"),
           "PYTHONPATH": str(ROOT / "src")}
    cmds = [[sys.executable, "-m", "psaudit", "build", "--force", "--years", *map(str, years)],
            [sys.executable, "-m", "psaudit", "analyze", "--years", *map(str, years), "--skip-second"]]
    for cmd in cmds:
        print("rerun:", " ".join(cmd[1:]), flush=True)
        subprocess.run(cmd, check=True, env=env, cwd=ROOT)
    res = compare_dirs(RESULTS, scratch / "results")
    res["first"] = "results/ (primary run)"
    res["second"] = ".local/rerun/results (rebuild from cached raw files)"
    res["commands"] = [" ".join(["python"] + c[1:]) for c in cmds]
    write_json(RESULTS / "repro_check.json", res)
    print(json.dumps({k: res[k] for k in ("files_compared", "values_compared", "differences",
                                          "max_abs_numeric_difference", "identical_within_tolerance")}, indent=1))
    return res
