from psaudit.cli import main

raise SystemExit(main())
