"""Render the manuscript, the scientific report and the project page from templates.

Numbers come only from evidence/claims.json ({{claim_id}}), references are
numbered in order of first citation ({{ref:key}}), and tables are built from the
result files. A template placeholder without a matching claim stops the render.
"""

from __future__ import annotations

import html
import re
import shutil
from pathlib import Path

import markdown
import pandas as pd

from psaudit.common import RESULTS, ROOT, read_json, utc_now
from psaudit.figures import GROUP_NAMES

RENDERER = "Python-Markdown 3.11 and python-docx 1.2.0 (Quarto was not installed on the build machine)"
TEMPLATES = ROOT / "templates"
MANUSCRIPT = ROOT / "manuscript"
REPORT = ROOT / "report"
SITE = ROOT / "site" / "projects" / "prescribing-suppression"
ACCESSED = "Accessed 7 Oct 2026."

REFERENCES = {
    "cms_method": "Centers for Medicare & Medicaid Services. Medicare Part D Prescribers datasets: a methodological overview. "
                  "Baltimore (MD): CMS Office of Enterprise Data and Analytics; April 2026. "
                  "https://data.cms.gov/sites/default/files/2026-05/MUP_DPR_RY26_20260421_Methodology_508.pdf. " + ACCESSED,
    "cms_pd": "Centers for Medicare & Medicaid Services. Medicare Part D Prescribers - by Provider and Drug, data years 2022 "
              "to 2024 [dataset]. https://data.cms.gov/provider-summary-by-type-of-service/medicare-part-d-prescribers/"
              "medicare-part-d-prescribers-by-provider-and-drug. " + ACCESSED,
    "cms_geo": "Centers for Medicare & Medicaid Services. Medicare Part D Prescribers - by Geography and Drug, data years "
               "2022 to 2024 [dataset]. https://data.cms.gov/provider-summary-by-type-of-service/medicare-part-d-prescribers/"
               "medicare-part-d-prescribers-by-geography-and-drug. " + ACCESSED,
    "cms_prov": "Centers for Medicare & Medicaid Services. Medicare Part D Prescribers - by Provider, data year 2024 "
                "[dataset]. https://data.cms.gov/provider-summary-by-type-of-service/medicare-part-d-prescribers/"
                "medicare-part-d-prescribers-by-provider. " + ACCESSED,
    "arizpe": "Arizpe A, Reveles KR, Aitken SL. Regional variation in antibiotic prescribing among Medicare Part D "
              "enrollees, 2013. BMC Infect Dis. 2016;16(1):744. doi:10.1186/s12879-016-2091-0.",
    "sangha": "Sangha V, Lipska K, Lin Z, Inzucchi SE, McGuire DK, Krumholz HM, et al. Patterns of prescribing "
              "sodium-glucose cotransporter-2 inhibitors for Medicare beneficiaries in the United States. Circ Cardiovasc "
              "Qual Outcomes. 2021;14(12):e008381. doi:10.1161/CIRCOUTCOMES.121.008381.",
    "karpinski": "Karpinski SA, Look KA, Vanness DJ. Factors associated with county-level variation in the prescription "
                 "of statins. J Manag Care Spec Pharm. 2019;25(12):1358-65. doi:10.18553/jmcp.2019.25.12.1358.",
    "toth": "Toth JM, Jadhav S, Holmes HM, Sharma M. Prescribing trends of proton pump inhibitors, antipsychotics and "
            "benzodiazepines of Medicare Part D providers. BMC Geriatr. 2022;22(1):306. doi:10.1186/s12877-022-02971-2.",
    "gouin": "Gouin KA, Fleming-Dutra KE, Tsay S, Bizune D, Hicks LA, Kabbani S. Identifying higher-volume antibiotic "
             "outpatient prescribers using publicly available Medicare Part D data - United States, 2019. MMWR Morb "
             "Mortal Wkly Rep. 2022;71(6):202-5. doi:10.15585/mmwr.mm7106a3.",
    "delott": "De Lott LB, Burke JF, Kerber KA, Skolarus LE, Callaghan BC. Medicare Part D payments for "
              "neurologist-prescribed drugs. Neurology. 2016;86(16):1491-8. doi:10.1212/WNL.0000000000002589.",
    "ziakas": "Ziakas PD, Kourbeti IS, Poulou LS, Vlachogeorgos GS, Mylonakis E. Medicare Part D prescribing for direct "
              "oral anticoagulants in the United States: cost, use and the \"rubber effect\". PLoS One. "
              "2018;13(6):e0198674. doi:10.1371/journal.pone.0198674.",
    "beshearse": "Beshearse EM, Gouin KA, Fleming-Dutra KE, Tsay S, Hicks LA, Kabbani S. Comparison of outpatient "
                 "antibiotic prescriptions among older adults in IQVIA Xponent and publicly available Medicare Part D "
                 "data, 2018. Antimicrob Steward Healthc Epidemiol. 2023;3(1):e32. doi:10.1017/ash.2022.332.",
    "ma": "Ma I, Tisdale RL, Vail D, Heidenreich PA, Sandhu AT. Utilization of generic cardiovascular drugs in Medicare's "
          "Part D program. Circ Cardiovasc Qual Outcomes. 2021;14(12):e007559. doi:10.1161/CIRCOUTCOMES.120.007559.",
    "gronbeck": "Gronbeck C, Feng H. Assessment of comprehensiveness of Medicare Part B provider-level data sets within "
                "dermatology. Arch Dermatol Res. 2023;315(6):1805-7. doi:10.1007/s00403-023-02530-8.",
    "tiwari": "Tiwari C, Beyer K, Rushton G. The impact of data suppression on local mortality rates: the case of CDC "
              "WONDER. Am J Public Health. 2014;104(8):1386-8. doi:10.2105/AJPH.2014.301900.",
    "abe": "Abe K, Sugiyama M, Miyazaki K, Sako A, Igarashi T, Nakanishi M, et al. Small-count suppression substantially "
           "distorts estimates of pediatric opioid utilization in Japan. J Pain Symptom Manage. 2026;72(5):e419-24. "
           "doi:10.1016/j.jpainsymman.2026.07.015.",
    "kao": "Kao SZ, Tutwiler MS, Ekwueme DU, Truman BI. Better data for decision-making through Bayesian imputation of "
           "suppressed provisional COVID-19 death counts. PLoS One. 2023;18(8):e0288961. doi:10.1371/journal.pone.0288961.",
    "erdman": "Erdman EA, Young LD, Bernson DL, Bauer C, Chui K, Stopka TJ. A novel imputation approach for sharing "
              "protected public health data. Am J Public Health. 2021;111(10):1830-8. doi:10.2105/AJPH.2021.306432.",
    "rxclass": "National Library of Medicine. RxClass API, classMembers with ATC source; RxNav data version 05-Oct-2026. "
               "https://lhncbc.nlm.nih.gov/RxNav/APIs/RxClassAPIs.html. " + ACCESSED,
    "who_atc": "WHO Collaborating Centre for Drug Statistics Methodology. ATC/DDD Index: C10AB fibrates. "
               "https://atcddd.fhi.no/atc_ddd_index/?code=C10AB. " + ACCESSED,
    "duckdb": "Raasveldt M, M\u00fchleisen H. DuckDB: an embeddable analytical database. In: Proceedings of the 2019 "
              "International Conference on Management of Data. New York: ACM; 2019. p. 1981-4. "
              "doi:10.1145/3299869.3320212.",
    "cfr": "Protection of Human Subjects, Definitions, 45 C.F.R. Sect. 46.102. https://www.ecfr.gov/current/title-45/"
           "subtitle-A/subchapter-A/part-46/subpart-A/section-46.102. " + ACCESSED,
}

PRIOR_ROWS = [
    ("Arizpe et al. 2016 [{{ref:arizpe}}]", "2013 Part D Prescriber public use file; antibiotics",
     "Claims and cost per enrollee by state and region", "Not discussed"),
    ("De Lott et al. 2016 [{{ref:delott}}]", "2013 detail and summary files; neurologist-prescribed drugs",
     "Payments by drug and specialty", "Reported that detail held 86.8% of claims and 78.1% of payments; used summary files for totals"),
    ("Ziakas et al. 2018 [{{ref:ziakas}}]", "2013 to 2015 detail file and national summary; anticoagulants",
     "Use and cost trends", "Measured a 9.0% claim and 16.6% cost understatement in 2015; modeled the omission as left truncation"),
    ("Karpinski et al. 2019 [{{ref:karpinski}}]", "2013 provider and detail files; statins",
     "County statin measures", "Noted redaction; used only rows with unredacted counts"),
    ("Sangha et al. 2021 [{{ref:sangha}}]", "2014 to 2018 detail file; SGLT2 inhibitors",
     "Specialty and regional patterns; ratios to sulfonylureas", "Assigned 5 to beneficiary cells under 11 and noted the uncertainty"),
    ("Ma et al. 2021 [{{ref:ma}}]", "2017 national, state and clinician files; cardiovascular drugs",
     "Generic substitution and savings", "Measured 7.6% of fills missing for substitutable drugs, with a lower generic share"),
    ("Toth et al. 2022 [{{ref:toth}}]", "2013 to 2019 summary and detail files; three drug groups",
     "Prevalence and provider trends", "Used summary files for totals; noted that provider-level counts are lower"),
    ("Gouin et al. 2022 [{{ref:gouin}}]", "2019 by-provider file; antibiotics",
     "Higher-volume prescribers", "Excluded prescribers under 11 antibiotic claims; imputed 10 for suppressed beneficiary counts"),
    ("Beshearse et al. 2023 [{{ref:beshearse}}]", "2018 detail and summary files; oral antibiotics, adults 65 and older; IQVIA",
     "Validity of public files", "Measured detail at about 69% of the national total"),
    ("This study", "2022 to 2024 detail and Geography and Drug files; cardiometabolic drugs",
     "Reconciliation by label and state", "Measured per cell; tested against the 10-claim bound; assessed shares and state orderings"),
]

FIGURES = {
    1: ("fig1_retained_vs_volume_2024", "Retained fraction by published national claim volume, 2024",
        "Each point is one in-scope drug label (brand and generic name as published by CMS). The horizontal axis is the "
        "label's national claim total in the Geography and Drug file; the vertical axis is the share of that total found "
        "by summing Provider and Drug rows. The horizontal line is the claim-weighted fraction for all in-scope labels. "
        "Marker shape and color show the ATC class. Labels whose values are withheld under the public output rule are "
        "not plotted.",
        "Scatter plot: labels with more published claims keep a larger share in the public detail file; most small labels keep under half."),
    2: ("fig2_state_retained_2024", "Retained fraction by state and drug class, 2024",
        "For each of the 50 states and the District of Columbia, the share of published in-scope claims present in summed "
        "public detail, overall (vertical tick) and by ATC class (markers). Jurisdictions are sorted by the overall "
        "fraction. Geography is the prescriber's address.",
        "Dot plot of 51 jurisdictions: overall retained fractions range from about 84 to 92 percent, with diabetes drugs lowest in every state."),
    3: ("fig3_rank_agreement_2024", "Agreement of state orderings, published totals versus detail sums, 2024",
        "Left: Kendall's tau-b between two orderings of the 50 states and the District of Columbia by a group's share "
        "of class claims, one from "
        "published totals and one from detail sums. Right: number of jurisdictions whose rank changed by five or more "
        "places. Numbers in parentheses give the count of jurisdictions with a published total when fewer than 51.",
        "Paired charts: most groups keep nearly the same state order; insulins and a few very small groups reorder substantially."),
    4: ("fig4_a10a_share_2024", "Insulin share of diabetes-drug claims by state, 2024",
        "Filled points use published Geography and Drug totals; open points use summed Provider and Drug rows for the "
        "same labels. Insulins are shown because they had the largest change in state ordering among groups with at "
        "least 1% of their class's claims; Fig. 3 shows every group.",
        "Dumbbell chart: in every state the insulin share computed from public detail is 3 to 6 points lower than from published totals."),
}


ADDITIONAL_TO_DOWNLOADS = {
    1: "the source manifest in the downloads", 2: "the analysis plan in the downloads",
    3: "the scope decisions table in the downloads", 4: "the reconciliation workbook in the downloads",
    5: "the reconciliation ledger in the downloads", 6: "the source archive in the downloads",
}


class RenderError(RuntimeError):
    pass


def _fmt_int(x) -> str:
    return f"{int(round(x)):,}"


def _fmt_pct(x) -> str:
    return f"{100 * x:.1f}%"


def _fmt_share(x) -> str:
    return "<0.1%" if 0 < x < 0.0005 else _fmt_pct(x)


def build_tables(cfg: dict) -> dict[str, str]:
    y = cfg["primary_year"]
    d = RESULTS / f"dy{y}"
    # Table 1 is built from the public table: detail claims rounded to the nearest 10, and label
    # medians omitted where a group contains a withheld label.
    g = pd.read_csv(ROOT / "exports" / "public" / f"dy{y}" / "national_by_group.csv")
    order = {c: i for i, c in enumerate(["A10", "C09", "C10"])}
    g = g.sort_values(["atc_class", "a_clms"], key=lambda s: s.map(order) if s.name == "atc_class" else -s)
    rows = ["| Group | ATC | Labels | Published claims | Claims in detail | Retained | Median label retained |",
            "|---|---|--:|--:|--:|--:|--:|"]
    dashed = False
    for r in g.itertuples(index=False):
        med = "-" if pd.isna(r.median_label_retained) else _fmt_pct(r.median_label_retained)
        dashed |= med == "-"
        rows.append(f"| {GROUP_NAMES.get(r.group, r.group)} | {r.group if 'fixed' not in r.group else r.atc_class} | "
                    f"{r.labels} | {_fmt_int(r.a_clms)} | {_fmt_int(r.d_clms)} | {_fmt_pct(r.weighted_retained)} | "
                    f"{med} |")
    t1 = (f"**Table 1.** Retained fraction by therapeutic group, national, {y}\n\n" + "\n".join(rows) +
          "\n\nRetained: claims in summed Provider and Drug rows divided by published Geography and Drug claims for the "
          "same labels, with detail claims rounded to the nearest 10. Median label retained is unweighted across the "
          "group's labels" + ("; a dash marks a group that contains a label withheld under the public output rule "
                              "(Methods)" if dashed else "") +
          ". RAS: renin-angiotensin system; DPP-4: dipeptidyl peptidase-4.")

    sh = pd.read_csv(d / "group_shares.csv", dtype={"geo_code": str})
    rk = pd.read_csv(d / "rank_shifts.csv")
    flag = cfg["rank_shift_flag"]
    nat = sh[sh.geo_code == "National"].merge(rk, on=["atc_class", "group"], how="left")
    nat = nat.sort_values(["atc_class", "a_clms"], key=lambda s: s.map(order) if s.name == "atc_class" else -s)
    rows = ["| Group | Share, published | Share, detail | Difference (points) | Kendall's tau-b | "
            f"Jurisdictions moving {flag}+ places | Top-10 overlap |", "|---|--:|--:|--:|--:|--:|--:|"]
    for r in nat.itertuples(index=False):
        jur = "" if pd.isna(r.jurisdictions) or r.jurisdictions == 51 else f" ({int(r.jurisdictions)})"
        diff = "0.0" if abs(r.share_difference_pp) < 0.05 else f"{r.share_difference_pp:+.1f}"
        rows.append(f"| {GROUP_NAMES.get(r.group, r.group)}{jur} | {_fmt_share(r.share_published)} | "
                    f"{_fmt_share(r.share_detail)} | {diff} | {r.kendall_tau_b:.2f} | "
                    f"{int(getattr(r, f'jurisdictions_shift_ge_{flag}'))} | {int(r.top10_overlap)} |")
    t2 = (f"**Table 2.** Group shares of class claims and agreement of state orderings, {y}\n\n" + "\n".join(rows) +
          "\n\nShares are national. Orderings rank the 50 states and the District of Columbia (DC) by each group's share "
          "of class claims; numbers in "
          "parentheses give jurisdictions with a published total when fewer than 51. Difference is detail share minus "
          "published share, computed from unrounded shares, so it can differ by 0.1 from the difference of the rounded "
          "shares shown.")

    rep = read_json(RESULTS / "replication" / "replication_summary.json")
    rows = ["| Data year | In-scope labels | Retained, all | Diabetes (A10) | RAS (C09) | Lipid (C10) | Gross cost retained | "
            "Insulin ordering tau-b | Cells outside 10-claim bound |", "|---|--:|--:|--:|--:|--:|--:|--:|--:|"]
    for py in sorted(rep["per_year"], key=lambda p: -p["data_year"]):
        yy = py["data_year"]
        s = read_json(RESULTS / f"dy{yy}" / "summary.json")
        rky = pd.read_csv(RESULTS / f"dy{yy}" / "rank_shifts.csv")
        tau = rky[rky.group == "A10A"].kendall_tau_b.iloc[0]
        bc = s["suppression_bound_check"]
        out_b = bc["national"]["outside_bounds"] + bc["all_state_level"]["outside_bounds"]
        cells = bc["national"]["cells_checked"] + bc["all_state_level"]["cells_checked"]
        rows.append(f"| {yy} | {s['scope']['labels_in_scope']} | {_fmt_pct(py['weighted_retained'])} | "
                    f"{_fmt_pct(py['weighted_retained_A10'])} | {_fmt_pct(py['weighted_retained_C09'])} | "
                    f"{_fmt_pct(py['weighted_retained_C10'])} | {_fmt_pct(s['national']['weighted_retained_cost'])} | "
                    f"{tau:.2f} | {out_b} of {cells:,} |")
    t3 = ("**Table 3.** Primary and replication years, each analyzed separately\n\n" + "\n".join(rows) +
          "\n\nRetained fractions are claim-weighted and national. Each year uses its own release and label mapping.")

    rows = ["| Study | Data | Use of the public files | How the omitted rows were handled or measured |", "|---|---|---|---|"]
    for r in PRIOR_ROWS:
        rows.append("| " + " | ".join(r) + " |")
    t4 = "**Table 4.** How published studies of the Part D prescriber files handled the omitted detail\n\n" + "\n".join(rows)
    return {"groups": t1, "shares": t2, "replication": t3, "prior": t4}


def _strip_blocks(text: str, variant: str) -> str:
    drop = "report" if variant == "journal" else "journal"
    text = re.sub(rf"<!-- {drop} -->.*?<!-- /{drop} -->\n?", "", text, flags=re.S)
    return re.sub(r"<!-- /?(journal|report) -->\n?", "", text)


def fill(template: str, claims: dict, tables: dict, variant: str, fig_dir: str, fig_ext: str) -> tuple[str, list[str]]:
    text = _strip_blocks(template, variant)

    def include(m):
        # Journal-only sections (title page, declarations, tool-use statement) live with the
        # manuscript, not in the shared template.
        if variant != "journal":
            return ""
        return (MANUSCRIPT / "src" / f"{m.group(1)}.md").read_text(encoding="utf-8")
    text = re.sub(r"\{\{include:([a-z_]+)\}\}\n?", include, text)
    for name, t in tables.items():
        text = text.replace("{{table:%s}}" % name, t)

    def fig(m):
        n = int(m.group(1))
        stem, title, legend, alt = FIGURES[n]
        return (f"![{alt}]({fig_dir}/{stem}.{fig_ext})\n\n**Fig. {n}.** {title}. {legend}")
    text = re.sub(r"\{\{figure:(\d+)\}\}", fig, text)

    order: list[str] = []

    def ref(m):
        key = m.group(1)
        if key not in REFERENCES:
            raise RenderError(f"unknown reference {key}")
        if key not in order:
            order.append(key)
        return str(order.index(key) + 1)
    text = re.sub(r"\{\{ref:([a-z_]+)\}\}", ref, text)
    text = re.sub(r"\[(\d+(?:, \d+)+)\]",
                  lambda m: "[" + ", ".join(str(n) for n in sorted({int(x) for x in m.group(1).split(", ")})) + "]", text)
    text = text.replace("{{references}}", "\n".join(f"{i}. {REFERENCES[k]}" for i, k in enumerate(order, 1)))
    if variant == "report":
        text = text.replace("Additional files 4 and 5",
                            "the reconciliation workbook and the reconciliation ledger in the downloads")
        for n, name in ADDITIONAL_TO_DOWNLOADS.items():
            text = text.replace(f"Additional file {n}", name)

    def claim(m):
        cid = m.group(1)
        if cid not in claims:
            raise RenderError(f"placeholder {{{{{cid}}}}} has no claim in evidence/claims.json")
        return str(claims[cid]["text"])
    text = re.sub(r"\{\{([A-Za-z0-9_]+)\}\}", claim, text)
    left = re.findall(r"\{\{[^}]+\}\}", text)
    if left:
        raise RenderError(f"unrendered placeholders: {left[:5]}")
    if "—" in text:
        raise RenderError("em dash in rendered prose")
    return text, order


CSS = """
:root{--bg:#fbfaf7;--surface:#ffffff;--ink:#1d1d1b;--ink2:#4a4945;--muted:#6b6a65;--rule:#dedcd5;--accent:#1f5f8b;--accent-ink:#174a6c;
--code:#f1efe9;--measure:44rem;--wide:60rem}
*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:17px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
a{color:var(--accent);text-underline-offset:2px}a:hover{color:var(--accent-ink)}
a:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:2px}
.skip{position:absolute;left:-999px;top:0;background:var(--surface);padding:8px 12px}.skip:focus{left:8px;top:8px;z-index:9}
header.site,main,footer.site{max-width:var(--wide);margin:0 auto;padding:0 20px}
header.site{padding-top:28px;padding-bottom:8px;border-bottom:1px solid var(--rule)}
header.site p{margin:0;color:var(--muted);font-size:15px}
main{padding-top:8px;padding-bottom:48px}
main>*{max-width:var(--measure)}
main>figure,main>.table-wrap,main>.wide{max-width:var(--wide)}
h1{font-size:clamp(1.6rem,3.6vw,2.3rem);line-height:1.2;letter-spacing:-0.01em;margin:28px 0 12px}
h2{font-size:1.35rem;line-height:1.3;margin:40px 0 10px;padding-top:12px;border-top:1px solid var(--rule)}
h3{font-size:1.08rem;margin:26px 0 6px}
p,li{color:var(--ink)}.lede{font-size:1.12rem;color:var(--ink2)}
figure{margin:24px 0}figure img,main img{max-width:100%;height:auto;display:block;background:#fcfcfb;border:1px solid var(--rule)}figure img{width:100%}
figcaption{font-size:15px;color:var(--ink2);margin-top:8px}
.table-wrap{overflow-x:auto;margin:20px 0;border:1px solid var(--rule);background:var(--surface)}
.table-wrap:focus-visible{outline:2px solid var(--accent)}
table{border-collapse:collapse;width:100%;font-size:14.5px;font-variant-numeric:tabular-nums}
th,td{padding:7px 10px;border-bottom:1px solid var(--rule);text-align:left;vertical-align:top}
th{font-weight:600;color:var(--ink2);background:#f6f5f1}
td.num,th.num{text-align:right;white-space:nowrap}
.caption{font-size:15px;color:var(--ink2)}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(11rem,1fr));gap:12px;max-width:var(--wide);margin:20px 0}
.stat{background:var(--surface);border:1px solid var(--rule);padding:12px 14px}
.stat b{display:block;font-size:1.5rem;line-height:1.2}.stat span{font-size:14px;color:var(--ink2)}
.note{background:var(--surface);border-left:3px solid var(--accent);padding:10px 14px;margin:18px 0}
code{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:.88em;background:var(--code);padding:1px 4px}
pre{background:var(--code);padding:12px;overflow-x:auto;font-size:14px}pre code{background:none;padding:0}
li,p,figcaption{overflow-wrap:anywhere}main ol li{margin-bottom:6px}
ul.files li{margin-bottom:6px}
nav.toc{font-size:15px}nav.toc ol{padding-left:20px}
footer.site{border-top:1px solid var(--rule);padding-top:14px;padding-bottom:40px;color:var(--muted);font-size:14px}
@media (max-width:640px){body{font-size:16px}th,td{padding:6px 8px}}
@media (prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}
"""


def _md_to_html(md_text: str) -> str:
    body = markdown.markdown(md_text, extensions=["tables", "attr_list", "sane_lists"], output_format="html5")
    # Tables: wrap for horizontal scroll, mark numeric columns.
    body = re.sub(r"<table>", '<div class="table-wrap" tabindex="0" role="region" aria-label="Table"><table>', body)
    body = body.replace("</table>", "</table></div>")
    body = re.sub(r'(<p><strong>Table (\d+)\.</strong> ([^<]*)</p>\s*<div class="table-wrap" tabindex="0" role="region" )'
                  r'aria-label="Table"',
                  lambda m: m.group(1) + f'aria-label="Table {m.group(2)}: {html.escape(m.group(3).strip())}"', body)
    body = re.sub(r'<(td|th) style="text-align: right;">', r'<\1 class="num">', body)
    # Figures: image followed by its caption paragraph.
    body = re.sub(r'<p><img alt="([^"]*)" src="([^"]+)"\s*/?></p>\s*<p><strong>(Fig\. \d+\.)</strong>(.*?)</p>',
                  r'<figure><img src="\2" alt="\1" loading="eager"><figcaption><strong>\3</strong>\4</figcaption></figure>',
                  body, flags=re.S)
    return body


def _page(title: str, body: str, description: str, breadcrumb: str, css_href: str | None = None) -> str:
    style = f'<link rel="stylesheet" href="{css_href}">' if css_href else f"<style>{CSS}</style>"
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(title)}</title>
<meta name="description" content="{html.escape(description)}">
{style}
</head>
<body>
<a class="skip" href="#content">Skip to content</a>
<header class="site"><p>{breadcrumb}</p></header>
<main id="content">
{body}
</main>
<footer class="site"><p>Data: Centers for Medicare &amp; Medicaid Services, Medicare Part D Prescribers public files, data years 2022 to 2024, retrieved 7 October 2026. Drug classes: National Library of Medicine RxClass (ATC).</p></footer>
</body>
</html>
"""


def _docx(md_text: str, path: Path, fig_src: Path, embed_figures: bool = False,
          title: str = "Summed public detail versus published totals in Medicare Part D prescriber data",
          manuscript: bool = True) -> None:
    """Journal Word file: Times 12 pt, double spaced, continuous line numbers, page numbers.
    Figures are supplied as separate files (BMC), so only their titles and legends appear here."""
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Inches, Pt, RGBColor

    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.paragraph_format.line_spacing = 2.0 if manuscript else 1.15
    st.paragraph_format.space_after = Pt(0 if manuscript else 6)
    for style_name, size in (("Title", 14), ("Heading 1", 12), ("Heading 2", 12)):
        style = doc.styles[style_name]
        style.font.name = "Times New Roman"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.paragraph_format.line_spacing = 2.0 if manuscript else 1.15
        style.paragraph_format.space_after = Pt(0)
        for border in list(style.element.xpath("./w:pPr/w:pBdr")):
            border.getparent().remove(border)
    sect = doc.sections[0]
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    if manuscript:
        sect._sectPr.append(ln)
    footer = sect.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer.add_run()
    for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = text
        run._r.append(el)

    def add_runs(par, text):
        for part in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
            if not part:
                continue
            if part.startswith("**") and part.endswith("**"):
                par.add_run(part[2:-2]).bold = True
            elif part.startswith("`") and part.endswith("`"):
                par.add_run(part[1:-1]).font.name = "Courier New"
            else:
                par.add_run(part)

    lines = md_text.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=0)
        elif line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=1)
        elif line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=2)
        elif line.startswith("!["):
            if embed_figures:
                m = re.match(r"!\[[^\]]*\]\(([^)]+)\)", line)
                img = fig_src / Path(m.group(1)).name.replace(".svg", ".png")
                doc.add_picture(str(img), width=Inches(6.0))
        elif line.startswith("|"):
            block = []
            while i < len(lines) and lines[i].startswith("|"):
                block.append(lines[i])
                i += 1
            cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in block if not re.match(r"^\|[-:| ]+\|$", r)]
            table = doc.add_table(rows=len(cells), cols=len(cells[0]))
            table.style = "Table Grid"
            table.rows[0]._tr.get_or_add_trPr().append(OxmlElement("w:tblHeader"))
            for row in table.rows:
                row._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
            for ri, row in enumerate(cells):
                for ci, val in enumerate(row):
                    cell = table.cell(ri, ci)
                    cell.text = ""
                    p = cell.paragraphs[0]
                    p.paragraph_format.line_spacing = 1.0
                    r = p.add_run(val.replace("**", ""))
                    r.font.size = Pt(9)
                    r.bold = ri == 0
            continue
        elif re.match(r"^\d+\. ", line):
            p = doc.add_paragraph(style="List Number")
            add_runs(p, re.sub(r"^\d+\. ", "", line))
        else:
            p = doc.add_paragraph()
            add_runs(p, line)
        i += 1
    import datetime as _dt

    cp = doc.core_properties
    cp.title = title
    cp.author = "Animesh Bose"
    cp.last_modified_by = "Animesh Bose"
    cp.comments = ""
    cp.subject = ""
    cp.keywords = ""
    cp.revision = 1
    cp.created = _dt.datetime(2026, 10, 7, 12, 0, 0)
    cp.modified = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None)
    doc.save(path)


def render_documents(cfg: dict, claims_doc: dict) -> dict:
    claims = claims_doc["claims"]
    tables = build_tables(cfg)
    template = (TEMPLATES / "manuscript.md").read_text(encoding="utf-8")
    fig_src = RESULTS / "figures"
    out = {}

    # Journal manuscript (Markdown, HTML, DOCX) with PNG figures beside it. Rendered only where the
    # journal sections are present (they are not part of the public source archive).
    if (MANUSCRIPT / "src" / "journal_front.md").exists():
        out.update(_render_manuscript(template, claims, tables, fig_src))
    else:
        out["manuscript"] = "skipped: manuscript/src not present"
    return _render_site_docs(template, claims, tables, out)


def _render_manuscript(template: str, claims: dict, tables: dict, fig_src: Path) -> dict:
    out = {}
    MANUSCRIPT.mkdir(parents=True, exist_ok=True)
    (MANUSCRIPT / "figures").mkdir(exist_ok=True)
    for n, (stem, *_rest) in FIGURES.items():
        for ext in ("png", "svg"):
            shutil.copy(fig_src / f"{stem}.{ext}", MANUSCRIPT / "figures" / f"{stem}.{ext}")
    md_j, refs_j = fill(template, claims, tables, "journal", "figures", "png")
    (MANUSCRIPT / "manuscript.md").write_text(md_j, encoding="utf-8")
    body = _md_to_html(md_j)
    (MANUSCRIPT / "manuscript.html").write_text(
        _page("Manuscript: summed public detail versus published totals", body,
              "Manuscript draft for BMC Medical Research Methodology", "Manuscript draft"), encoding="utf-8")
    _docx(md_j, MANUSCRIPT / "manuscript.docx", fig_src)
    cover = (MANUSCRIPT / "src" / "cover_letter.md").read_text(encoding="utf-8")
    _docx(cover, MANUSCRIPT / "cover_letter.docx", fig_src, title="Cover letter", manuscript=False)
    out["manuscript"] = ["manuscript/manuscript.md", "manuscript/manuscript.html", "manuscript/manuscript.docx",
                         "manuscript/cover_letter.docx"]
    out["manuscript_references"] = len(refs_j)
    out["abstract_words"] = len(md_j.split("## Abstract")[1].split("**Keywords")[0].split())
    return out


def _render_site_docs(template: str, claims: dict, tables: dict, out: dict) -> dict:
    # Scientific report for the website: same source, journal-only sections left out.
    md_r, _ = fill(template, claims, tables, "report", "assets", "svg")
    downloads = (TEMPLATES / "report_downloads.md").read_text(encoding="utf-8")
    md_r = md_r.replace("## References", downloads + "\n\n## References")
    body = _md_to_html(md_r)
    toc = "<nav class=\"toc\" aria-label=\"Contents\"><ol>" + "".join(
        f'<li><a href="#{re.sub(r"[^a-z0-9]+", "-", h.lower()).strip("-")}">{h}</a></li>'
        for h in re.findall(r"<h2>(.*?)</h2>", body)) + "</ol></nav>"
    body = re.sub(r"<h2>(.*?)</h2>", lambda m: f'<h2 id="{re.sub(r"[^a-z0-9]+", "-", m.group(1).lower()).strip("-")}">{m.group(1)}</h2>', body)
    body = body.replace("<h2 id=\"abstract\">", toc + "\n<h2 id=\"abstract\">", 1)
    REPORT.mkdir(parents=True, exist_ok=True)
    page = _page("Medicare Part D suppression audit: full report", body,
                 "Reconciliation of public Medicare Part D Provider and Drug rows against published Geography and Drug "
                 "totals for cardiometabolic drugs, 2022 to 2024.",
                 '<a href="./">Project page</a> / Full report', css_href="assets/page.css")
    (REPORT / "assets").mkdir(parents=True, exist_ok=True)
    (REPORT / "assets" / "page.css").write_text(CSS.strip() + "\n", encoding="utf-8")
    for stem, *_rest in FIGURES.values():
        shutil.copy(RESULTS / "figures" / f"{stem}.svg", REPORT / "assets" / f"{stem}.svg")
    (REPORT / "report.html").write_text(page, encoding="utf-8")
    out["report"] = "report/report.html"

    # Project page.
    page_t = (TEMPLATES / "page.html").read_text(encoding="utf-8")
    page_md, _ = fill(page_t, claims, {}, "report", "assets", "svg")
    (REPORT / "index.html").write_text(page_md, encoding="utf-8")
    out["page"] = "report/index.html"

    # Private handoff summary of verified results. Rendered only where its template is present
    # (it is not part of the public source archive).
    if (TEMPLATES / "verified_results.md").exists():
        vr = (TEMPLATES / "verified_results.md").read_text(encoding="utf-8")
        vr_md, _ = fill(vr, claims, {}, "report", "assets", "svg")
        (ROOT / "handoff").mkdir(exist_ok=True)
        (ROOT / "handoff" / "verified_results.md").write_text(vr_md, encoding="utf-8")
        out["verified_results"] = "handoff/verified_results.md"
    else:
        out["verified_results"] = "skipped: templates/verified_results.md not present"
    out["rendered_at_utc"] = utc_now()
    return out
