"""Fast demo on the bundled synthetic fixture.

This checks that the software runs end to end. The fixture is invented; its
numbers are not study results and say nothing about Medicare data.
"""

from __future__ import annotations

import json
import shutil

from psaudit.analyze import analyze_dir
from psaudit.build import build_pair
from psaudit.common import ROOT


def run_demo() -> dict:
    fx = ROOT / "tests" / "fixtures"
    out = ROOT / ".local" / "demo"
    if out.exists():
        shutil.rmtree(out)
    build_pair(str(fx / "synthetic_detail.csv"), str(fx / "synthetic_geography.csv"), out / "warehouse", label="fixture")
    summary = analyze_dir(out / "warehouse", out / "results", "fixture", "demo")
    print("SYNTHETIC FIXTURE (software check only, not study data)")
    print(json.dumps({"national_status": summary["national"]["status_counts"],
                      "state_status": summary["states"]["all_state_level_status_counts"],
                      "well_matched_codes": summary["states"]["well_matched_codes"],
                      "failing_codes": summary["states"]["failing_codes"]}, indent=1))
    print(f"outputs in {out / 'results'}")
    return summary
