"""Figures for the report, manuscript and project page (SVG and PNG).

Three classes use the first three slots of a palette checked for color-vision
deficiency (all pairs), and each class also has its own marker shape, so color
is never the only cue. Text stays in neutral ink.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.ticker import FuncFormatter, MultipleLocator, PercentFormatter  # noqa: E402

SURFACE = "#fcfcfb"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"
CLASS_STYLE = {
    "A10": {"color": "#2a78d6", "marker": "o", "label": "Diabetes (A10)"},
    "C09": {"color": "#eb6834", "marker": "s", "label": "Renin-angiotensin (C09)"},
    "C10": {"color": "#1baf7a", "marker": "^", "label": "Lipid modifying (C10)"},
}
GROUP_NAMES = {
    "A10A": "Insulins", "A10BA": "Biguanides (metformin)", "A10BB": "Sulfonylureas", "A10BF": "Alpha-glucosidase inhibitors",
    "A10BG": "Thiazolidinediones", "A10BH": "DPP-4 inhibitors", "A10BJ": "GLP-1 receptor agonists",
    "A10BK": "SGLT2 inhibitors", "A10BX": "Other glucose-lowering", "A10 fixed-dose combination": "Diabetes combinations",
    "C09AA": "ACE inhibitors", "C09CA": "Angiotensin II receptor blockers", "C09XA": "Renin inhibitors",
    "C09XX": "Other RAS agents", "C09 fixed-dose combination": "RAS combinations", "C10AA": "Statins",
    "C10AB": "Fibrates", "C10AC": "Bile acid sequestrants", "C10AD": "Nicotinic acid derivatives",
    "C10AX": "Other lipid modifying", "C10 fixed-dose combination": "Lipid combinations",
}

plt.rcParams.update({
    "font.family": ["Helvetica Neue", "Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.facecolor": SURFACE, "figure.facecolor": SURFACE, "savefig.facecolor": SURFACE, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "grid.linestyle": "-", "axes.spines.top": False,
    "axes.spines.right": False, "svg.fonttype": "none", "legend.frameon": False,
})


def _save(fig, out: Path, name: str) -> list[Path]:
    out.mkdir(parents=True, exist_ok=True)
    paths = [out / f"{name}.svg", out / f"{name}.png", out / f"{name}.pdf"]
    fig.savefig(paths[0], bbox_inches="tight", metadata={"Date": None})
    fig.savefig(paths[1], bbox_inches="tight", dpi=300, metadata={"Software": None})
    fig.savefig(paths[2], bbox_inches="tight", metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)
    return paths


def fig_retained_vs_volume(nat: pd.DataFrame, out: Path, year: int, weighted: float) -> list[Path]:
    """nat is the public national table: labels withheld under the output rule have no retained
    fraction and are not plotted. The reference line is the all-label weighted fraction."""
    ev = nat[nat.status.isin(["matched", "no public detail", "negative gap"]) & nat.retained_clms.notna()]
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    for cls, st in CLASS_STYLE.items():
        g = ev[ev.atc_class == cls]
        ax.scatter(g.a_clms, g.retained_clms, s=30, marker=st["marker"], color=st["color"], edgecolor=SURFACE,
                   linewidth=0.8, label=f"{st['label']}, {len(g)} labels", zorder=3)
    w = weighted
    ax.axhline(w, color=INK2, linewidth=1, zorder=2)
    ax.text(ev.a_clms.min() * 1.1, w + 0.025, f"All in-scope claims: {w:.1%} retained", color=INK2, fontsize=9)
    ax.set_xscale("log")
    short = {1e1: "10", 1e2: "100", 1e3: "1k", 1e4: "10k", 1e5: "100k", 1e6: "1M", 1e7: "10M", 1e8: "100M", 1e9: "1B"}
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: short.get(v, f"{v:,.0f}")))
    ax.yaxis.set_major_formatter(PercentFormatter(1.0))
    ax.set_ylim(-0.03, 1.05)
    ax.set_xlabel(f"Published national claims for the drug label, {year} (log scale; k = thousand, M = million)")
    ax.set_ylabel("Share of published claims in public detail")
    ax.legend(loc="lower right", fontsize=9, handletextpad=0.3)
    return _save(fig, out, f"fig1_retained_vs_volume_{year}")


def fig_state_retained(states: pd.DataFrame, out: Path, year: int) -> list[Path]:
    s = states.sort_values("weighted_retained").reset_index(drop=True)
    fig, ax = plt.subplots(figsize=(7.2, 9.6))
    y = np.arange(len(s))
    ax.hlines(y, s[[f"weighted_retained_{c}" for c in CLASS_STYLE]].min(axis=1),
              s[[f"weighted_retained_{c}" for c in CLASS_STYLE]].max(axis=1), color=GRID, linewidth=2, zorder=1)
    for cls, st in CLASS_STYLE.items():
        ax.scatter(s[f"weighted_retained_{cls}"], y, marker=st["marker"], s=26, color=st["color"], edgecolor=SURFACE,
                   linewidth=0.8, label=st["label"], zorder=3)
    ax.scatter(s.weighted_retained, y, marker="|", s=90, color=INK, linewidth=1.6, label="All three classes", zorder=4)
    ax.set_yticks(y)
    ax.set_yticklabels(s.geo_desc, fontsize=8)
    ax.grid(axis="y", visible=False)
    ax.xaxis.set_major_locator(MultipleLocator(0.02))
    ax.xaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    ax.set_xlabel(f"Share of published state claims in public detail, {year}")
    ax.set_ylim(-0.8, len(s) - 0.2)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.04), ncol=4, fontsize=8, handletextpad=0.2, columnspacing=1)
    return _save(fig, out, f"fig2_state_retained_{year}")


def fig_rank_agreement(ranks: pd.DataFrame, out: Path, year: int, flag: int) -> list[Path]:
    r = ranks.copy()
    r["name"] = r.group.map(lambda g: GROUP_NAMES.get(g, g))
    order = {c: i for i, c in enumerate(CLASS_STYLE)}
    r = r.sort_values(["atc_class", "kendall_tau_b"], key=lambda s: s.map(order) if s.name == "atc_class" else s,
                      ascending=[True, False]).reset_index(drop=True)
    y = np.arange(len(r))[::-1]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.6, 6.0), sharey=True, gridspec_kw={"width_ratios": [1.2, 1]})
    for cls, st in CLASS_STYLE.items():
        m = (r.atc_class == cls).to_numpy()
        a1.scatter(r.kendall_tau_b[m], y[m], marker=st["marker"], color=st["color"], s=30, edgecolor=SURFACE,
                   linewidth=0.8, label=st["label"], zorder=3)
        a2.barh(y[m], r[f"jurisdictions_shift_ge_{flag}"][m], height=0.55, color=st["color"], zorder=3)
    for yy, v in zip(y, r[f"jurisdictions_shift_ge_{flag}"]):
        a2.text(v + 0.6, yy, f"{int(v)}", va="center", fontsize=8, color=INK2)
    a1.set_yticks(y)
    a1.set_yticklabels([f"{n} ({int(j)})" if j < 51 else n for n, j in zip(r.name, r.jurisdictions)], fontsize=8)
    a1.set_xlim(0.5, 1.01)
    a1.set_xlabel("Kendall's tau-b, state order by share:\npublished totals vs detail sums")
    a2.set_xlabel(f"Jurisdictions moving {flag} or more places\n(of 50 states and DC)")
    a2.set_xlim(0, 51)
    for a in (a1, a2):
        a.grid(axis="y", visible=False)
    fig.legend(*a1.get_legend_handles_labels(), loc="lower center", bbox_to_anchor=(0.5, -0.04), ncol=3, fontsize=8,
               handletextpad=0.2)
    fig.tight_layout(rect=(0, 0.04, 1, 1))
    return _save(fig, out, f"fig3_rank_agreement_{year}")


def fig_group_dumbbell(shares: pd.DataFrame, group: str, out: Path, year: int) -> list[Path]:
    g = shares[(shares.group == group) & (shares.geo_code != "National")].dropna(subset=["share_published"])
    g = g.sort_values("share_published").reset_index(drop=True)
    names = g.geo_desc if "geo_desc" in g.columns else g.geo_code
    fig, ax = plt.subplots(figsize=(7.2, 9.6))
    y = np.arange(len(g))
    ax.hlines(y, g.share_detail, g.share_published, color=GRID, linewidth=2, zorder=1)
    ax.scatter(g.share_published, y, color=INK, s=24, label="From published totals", zorder=3, edgecolor=SURFACE)
    ax.scatter(g.share_detail, y, facecolor=SURFACE, edgecolor=INK2, s=24, linewidth=1.2,
               label="From summed public detail", zorder=3)
    ax.set_yticks(y)
    ax.set_yticklabels(names, fontsize=8)
    ax.grid(axis="y", visible=False)
    ax.xaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    ax.set_xlabel(f"{GROUP_NAMES.get(group, group)} as a share of diabetes-drug claims, {year}")
    ax.set_ylim(-0.8, len(g) - 0.2)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.04), ncol=2, fontsize=8)
    return _save(fig, out, f"fig4_{group.lower().replace(' ', '_')}_share_{year}")


def fig_replication(per_year: pd.DataFrame, out: Path) -> list[Path]:
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    years = per_year.data_year.astype(int).tolist()
    for cls, st in CLASS_STYLE.items():
        vals = per_year[f"weighted_retained_{cls}"]
        ax.plot(years, vals, color=st["color"], linewidth=2, marker=st["marker"], markersize=6,
                markeredgecolor=SURFACE, label=st["label"])
        ax.text(years[-1] + 0.08, vals.iloc[-1], f"{vals.iloc[-1]:.1%}", va="center", fontsize=8, color=INK2)
    ax.set_xticks(years)
    ax.set_xlim(years[0] - 0.2, years[-1] + 0.45)
    ax.yaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
    ax.set_ylabel("Share of published claims\nin public detail")
    ax.set_xlabel("Data year (each analyzed separately)")
    ax.legend(fontsize=8, loc="lower left")
    return _save(fig, out, "fig5_replication_by_class")
