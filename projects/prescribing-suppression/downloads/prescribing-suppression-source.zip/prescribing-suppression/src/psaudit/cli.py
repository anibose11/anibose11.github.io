"""Command-line entry point: python -m psaudit <stage>.

Stages, in order: acquire, build, analyze, validate, render, package.
`audit` runs build + analyze on any compatible official release pair.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _years(args) -> list[int]:
    from psaudit.common import load_toml

    cfg = load_toml("analysis.toml")
    return args.years or [cfg["primary_year"], *cfg["replication_years"]]


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="psaudit", description="Medicare Part D suppression completeness audit")
    sub = p.add_subparsers(dest="stage", required=True)

    a = sub.add_parser("acquire", help="download and checksum the official CMS and RxClass inputs")
    a.add_argument("--years", type=int, nargs="*")
    a.add_argument("--no-docs", action="store_true")

    b = sub.add_parser("build", help="stream the raw files into typed Parquet tables")
    b.add_argument("--years", type=int, nargs="*")
    b.add_argument("--force", action="store_true", help="rebuild even if source checksums are unchanged")

    z = sub.add_parser("analyze", help="reconcile detail sums with published totals")
    z.add_argument("--years", type=int, nargs="*")
    z.add_argument("--skip-second", action="store_true", help="internal: used by the rerun check")

    v = sub.add_parser("validate", help="second implementation, rerun comparison and tests")
    v.add_argument("--years", type=int, nargs="*")
    v.add_argument("--skip-rerun", action="store_true")

    sub.add_parser("render", help="figures, workbook, exports, report and project page")
    sub.add_parser("package", help="source archive, handoff files and the outer bundle")

    au = sub.add_parser("audit", help="completeness audit of any compatible release pair")
    au.add_argument("--detail", required=True, help="Medicare Part D Prescribers by Provider and Drug CSV")
    au.add_argument("--geography", required=True, help="matching Medicare Part D Prescribers by Geography and Drug CSV")
    au.add_argument("--out", required=True, help="output folder")
    au.add_argument("--scope", choices=["cardiometabolic", "all"], default="cardiometabolic")
    au.add_argument("--label", default="release")
    au.add_argument("--workbook", action="store_true", help="also write an Excel reconciliation workbook")

    sub.add_parser("demo", help="run the audit on the bundled synthetic fixture (software check only)")
    sub.add_parser("compare", help="compare two results folders").add_argument("dirs", nargs=2)

    args = p.parse_args(argv)
    from psaudit.common import run_id

    if args.stage == "acquire":
        from psaudit.acquire import acquire
        from psaudit.scope import fetch_rxclass

        acquire(only_years=args.years, include_docs=not args.no_docs)
        fetch_rxclass()
    elif args.stage == "build":
        from psaudit.build import build_year

        for y in _years(args):
            build_year(y, force=args.force)
    elif args.stage == "analyze":
        from psaudit.analyze import analyze_year, exploratory_claims_per_prescriber, provider_reconciliation, replication
        from psaudit.common import load_toml

        rid = run_id()
        years = _years(args)
        for y in years:
            analyze_year(y, rid)
        cfg = load_toml("analysis.toml")
        if cfg["supplementary_provider_year"] in years:
            provider_reconciliation(cfg["supplementary_provider_year"], rid)
        replication(years, rid)
        exploratory_claims_per_prescriber(cfg["primary_year"], rid)
        _record_run(rid, years)
    elif args.stage == "validate":
        from psaudit.validate import repro_check, second_implementation

        years = _years(args)
        for y in years:
            r = second_implementation(y)
            print(f"dy{y}: second implementation compared {r['values_compared']} values, {r['mismatches']} mismatches")
        if not args.skip_rerun:
            repro_check(years)
        _run_tests()
    elif args.stage == "render":
        from psaudit.render import render_all

        render_all()
    elif args.stage == "package":
        from psaudit.package import package_all

        package_all()
    elif args.stage == "audit":
        from psaudit.analyze import analyze_dir
        from psaudit.build import build_pair

        out = Path(args.out)
        build_pair(args.detail, args.geography, out / "warehouse", label=args.label)
        summary = analyze_dir(out / "warehouse", out / "results", args.label, run_id(), scope_mode=args.scope)
        if args.workbook:
            from psaudit.workbook import write_workbook

            write_workbook(out / "results", out / "results" / f"reconciliation_{args.label}.xlsx")
        print(json.dumps(summary["national"]["status_counts"], indent=1))
    elif args.stage == "demo":
        from psaudit.demo import run_demo

        run_demo()
    elif args.stage == "compare":
        from psaudit.validate import compare_dirs

        res = compare_dirs(Path(args.dirs[0]), Path(args.dirs[1]))
        print(json.dumps(res, indent=1))
        return 0 if res["identical_within_tolerance"] else 1
    return 0


def _run_tests() -> dict:
    import re
    import subprocess

    from psaudit.common import RESULTS, ROOT, utc_now, write_json

    proc = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"], cwd=ROOT,
                          capture_output=True, text=True, env={**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")})
    tail = proc.stdout.strip().splitlines()[-1] if proc.stdout.strip() else ""
    m = re.search(r"(\d+) passed", tail)
    f = re.search(r"(\d+) failed", tail)
    res = {"ran_at_utc": utc_now(), "command": "python -m pytest -q", "exit_code": proc.returncode, "summary": tail,
           "passed": int(m.group(1)) if m else 0, "failed": int(f.group(1)) if f else 0}
    write_json(RESULTS / "test_summary.json", res)
    print("tests:", tail)
    return res


def _record_run(rid: str, years: list[int]) -> None:
    import platform

    import duckdb
    import pandas

    from psaudit.common import RESULTS, utc_now, write_json

    write_json(RESULTS / "run_metadata.json", {
        "run_id": rid, "finished_at_utc": utc_now(), "years": years,
        "python": platform.python_version(), "platform": platform.platform(),
        "duckdb": duckdb.__version__, "pandas": pandas.__version__,
    })


if __name__ == "__main__":
    sys.exit(main())
