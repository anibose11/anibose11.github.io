"""Public versions of the result tables (analysis plan, amendments 2, 6, 8 and 10).

What is published:
- label-by-geography cells: status, published total and a banded retained fraction only;
- national label rows and aggregate tables: detail sums rounded to the nearest 10 claims;
  the national total of all in-scope detail claims is exact.

A row is sensitive when its residual involves 1 or 2 unpublished prescriber rows or 1 to 10
claims, or equals the smallest or largest value the 10-claim rule allows. Sensitive rows are
withheld. An interval audit then treats every published value as an attacker would: exact
values are fixed, bands, rounding intervals and the 10-claim floor
(every published detail row holds at least 11 claims) give ranges, and
every published sum is an equation. Complementary withholding is
added if any sensitive value could be pinned to a single claim count. A second, independent
audit then rebuilds the same system from the public files alone and must reach the same
conclusion. Results in the paper were computed on all cells before this step.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

import pandas as pd

from psaudit.common import RESULTS, ROOT, utc_now, write_json

PUBLIC = ROOT / "exports" / "public"
EVAL = ["matched", "no public detail", "negative gap"]
RULE = ("withheld: the residual involves 1 or 2 unpublished prescriber rows or 1 to 10 claims, or equals the smallest "
        "or largest value the 10-claim rule allows, so publishing it could reveal suppressed values")
COMPLEMENT = "withheld so that a value withheld elsewhere cannot be recovered or narrowed from published totals"
BANDS = [(0.5, "under 50%"), (0.9, "50% to under 90%"), (0.95, "90% to under 95%"), (1.000001, "95% to 100%")]
BAND_RANGE = {"0% (no public detail)": (0.0, 0.0), "under 50%": (0.0, 0.5), "50% to under 90%": (0.5, 0.9),
              "90% to under 95%": (0.9, 0.95), "95% to 100%": (0.95, 1.0)}
MIN_RANGE = 1.0    # a withheld value must keep at least two possible claim counts
BASE = 10          # published detail sums are rounded to the nearest BASE claims
EPS = 1e-6


def rnd(x: float) -> float:
    """Round a detail sum to the nearest BASE claims (zero stays zero)."""
    if pd.isna(x):
        return x
    return float(BASE * round(float(x) / BASE))


def sensitive(m: float, g: float, d: float) -> bool:
    """Row-level rule. Residuals of cells with no public detail equal the published total, so
    they reveal nothing new and are never sensitive."""
    if pd.isna(m) or pd.isna(g) or pd.isna(d) or d <= 0:
        return False
    return (1 <= m <= 2) or (1 <= g <= 10) or (m >= 1 and (g == m or g == 10 * m))


def band(r: float) -> str:
    if pd.isna(r):
        return ""
    if r == 0:
        return "0% (no public detail)"
    for hi, label in BANDS:
        if r < hi:
            return label
    return BANDS[-1][1]


def _leaf_interval(status: str, a: float) -> tuple[float, float]:
    """What anyone knows about a label's detail sum from its published total and status."""
    if status == "no public detail":
        return (0.0, 0.0)
    return (11.0, float(a))


class Audit:
    """Interval constraint propagation over published values and sums."""

    def __init__(self):
        self.d: dict = {}
        self.intr: dict = {}
        self.kind: dict = {}
        self.band_iv: dict = {}
        self.sens: set = set()
        self.withheld: dict = {}
        self.eqs: list = []
        self._member: dict = {}

    def add(self, key, d, intrinsic, kind, band_iv=None, is_sensitive=False):
        self.d[key] = float(d)
        self.intr[key] = (float(intrinsic[0]), float(intrinsic[1]))
        self.kind[key] = kind
        if band_iv is not None:
            self.band_iv[key] = band_iv
        if is_sensitive:
            self.sens.add(key)
            self.withheld[key] = "rule"

    def eq(self, parent, children):
        if children:
            self.eqs.append((parent, list(children)))
            for k in [parent, *children]:
                self._member.setdefault(k, []).append(len(self.eqs) - 1)

    def _bounds(self) -> dict:
        b = {}
        for k, kind in self.kind.items():
            lo, hi = self.intr[k]
            if k in self.withheld or kind == "hidden":
                b[k] = (lo, hi)
            elif kind == "exact":
                b[k] = (self.d[k], self.d[k])
            elif kind == "rounded":
                v = rnd(self.d[k])
                b[k] = (lo, hi) if lo == hi else (max(lo, v - BASE / 2), min(hi, v + BASE / 2))
            else:
                blo, bhi = self.band_iv[k]
                b[k] = (max(lo, blo), min(hi, bhi))
        return b

    def propagate(self) -> tuple[dict, dict]:
        b = self._bounds()
        cause: dict = {}
        for _ in range(300):
            changed = False
            for ei, (p, ch) in enumerate(self.eqs):
                snap = {k: b[k] for k in [p, *ch]}
                lo_sum = sum(snap[c][0] for c in ch)
                hi_sum = sum(snap[c][1] for c in ch)
                plo, phi = snap[p]
                nlo, nhi = max(plo, lo_sum), min(phi, hi_sum)
                if nlo > plo + EPS or nhi < phi - EPS:
                    b[p] = (nlo, nhi)
                    cause[p] = ei
                    changed = True
                plo, phi = b[p]
                for c in ch:
                    clo, chi = snap[c]
                    olo, ohi = lo_sum - clo, hi_sum - chi
                    nlo, nhi = max(clo, plo - ohi), min(chi, phi - olo)
                    if nlo > clo + EPS or nhi < chi - EPS:
                        b[c] = (nlo, nhi)
                        cause[c] = ei
                        changed = True
            if not changed:
                break
        return b, cause

    def _candidate(self, k, b, cause, seen, depth):
        """A published value to withhold so that k is no longer pinned. Look first in the equation
        that last narrowed k; if every other member there is already withheld but still narrow,
        follow the equation that narrowed that member."""
        if depth > 8 or k in seen:
            return None
        seen.add(k)
        order = ([cause[k]] if k in cause else []) + [i for i in self._member.get(k, []) if i != cause.get(k)]
        for ei in order:
            p, ch = self.eqs[ei]
            cand = [x for x in [*ch, p] if x not in self.withheld and self.kind[x] in ("exact", "rounded", "band")
                    and self.intr[x][1] - self.intr[x][0] > 0]
            if cand:
                return max(cand, key=lambda x: (self.intr[x][1] - self.intr[x][0], str(x)))
        for ei in order:
            p, ch = self.eqs[ei]
            for x in [*ch, p]:
                if x != k and x in self.withheld and (b[x][1] - b[x][0]) < (self.intr[x][1] - self.intr[x][0]) - EPS:
                    found = self._candidate(x, b, cause, seen, depth + 1)
                    if found is not None:
                        return found
        return None

    def violations(self, b: dict, keys) -> list:
        """A withheld value is exposed when the published tables pin it to a single claim count."""
        out = []
        for k in keys:
            ilo, ihi = self.intr[k]
            if ihi - ilo >= MIN_RANGE and (b[k][1] - b[k][0]) < MIN_RANGE - EPS:
                out.append(k)
        return out

    def protect(self, max_rounds: int = 2000) -> dict:
        for _ in range(max_rounds):
            b, cause = self.propagate()
            bad = self.violations(b, self.sens)
            if not bad:
                return self.withheld
            best = self._candidate(bad[0], b, cause, set(), 0)
            if best is None:
                raise RuntimeError(f"cannot protect {bad[0]}: no candidate complement")
            self.withheld[best] = "complement"
        raise RuntimeError("complementary withholding did not converge")


def _build_system(nat: pd.DataFrame, st: pd.DataFrame, well: list[str]) -> Audit:
    A = Audit()
    ne = nat[nat.status.isin(EVAL)]
    se = st[st.status.isin(EVAL)]
    # Leaves: national labels (rounded) and state-level cells (banded).
    for r in ne.itertuples(index=False):
        A.add(("L", r.brnd_name, r.gnrc_name), r.d_clms, _leaf_interval(r.status, r.a_clms), "rounded",
              is_sensitive=sensitive(r.missing_prescriber_rows, r.gap_clms, r.d_clms))
    for r in se.itertuples(index=False):
        lo, hi = BAND_RANGE[band(r.retained_clms)]
        A.add(("c", r.geo_code, r.brnd_name, r.gnrc_name), r.d_clms, _leaf_interval(r.status, r.a_clms), "band",
              band_iv=(lo * r.a_clms, hi * r.a_clms),
              is_sensitive=sensitive(r.missing_prescriber_rows, r.gap_clms, r.d_clms))

    def agg(key, frame, kind="rounded"):
        matched = frame.status == "matched"
        lo = 11.0 * matched.sum()
        A.add(key, frame.d_clms.sum(), (lo, frame[matched].a_clms.sum()), kind,
              is_sensitive=sensitive(frame.missing_prescriber_rows.sum(), frame.gap_clms.sum(), frame.d_clms.sum()))

    lab = lambda f: [("L", b, g) for b, g in zip(f.brnd_name, f.gnrc_name)]  # noqa: E731
    cel = lambda f: [("c", c, b, g) for c, b, g in zip(f.geo_code, f.brnd_name, f.gnrc_name)]  # noqa: E731
    for (cls, grp), g in ne.groupby(["atc_class", "group"]):
        agg(("G", cls, grp), g)
        A.eq(("G", cls, grp), lab(g))
    for (vb,), g in ne.groupby(["volume_band"]):
        agg(("B", vb), g)
        A.eq(("B", vb), lab(g))
    for (cls,), g in ne.groupby(["atc_class"]):
        agg(("C", cls), g)
        A.eq(("C", cls), [("G", cls, grp) for grp in sorted(set(g.group))])
    agg(("T",), ne, kind="exact")
    A.eq(("T",), [("C", c) for c in sorted(set(ne.atc_class))])
    A.eq(("T",), [("B", b) for b in sorted(set(ne.volume_band))])
    # Each national label equals the sum of its state-level cells over every geography.
    for (b_, g_), g in se.groupby(["brnd_name", "gnrc_name"]):
        if ("L", b_, g_) in A.kind:
            A.eq(("L", b_, g_), cel(g))
    ws = se[se.geo_code.isin(well)]
    other = se[~se.geo_code.isin(well)]
    for (code, cls, grp), g in ws.groupby(["geo_code", "atc_class", "group"]):
        agg(("S", code, cls, grp), g)
        A.eq(("S", code, cls, grp), cel(g))
    for (code, cls), g in ws.groupby(["geo_code", "atc_class"]):
        agg(("K", code, cls), g)
        A.eq(("K", code, cls), [("S", code, cls, grp) for grp in sorted(set(g.group))])
    for (code,), g in ws.groupby(["geo_code"]):
        agg(("U", code), g)
        A.eq(("U", code), [("K", code, c) for c in sorted(set(g.atc_class))])
    for (code,), g in other.groupby(["geo_code"]):
        agg(("O", code), g)
        A.eq(("O", code), cel(g))
    A.eq(("T",), [("U", c) for c in sorted(set(ws.geo_code))] + [("O", c) for c in sorted(set(other.geo_code))])
    for (cls, grp), g in ne.groupby(["atc_class", "group"]):
        states = sorted(set(ws[(ws.atc_class == cls) & (ws.group == grp)].geo_code))
        rest = other[(other.atc_class == cls) & (other.group == grp)]
        A.eq(("G", cls, grp), [("S", c, cls, grp) for c in states] + cel(rest))
    for cls in sorted(set(ne.atc_class)):
        states = sorted(set(ws[ws.atc_class == cls].geo_code))
        A.eq(("C", cls), [("K", c, cls) for c in states] + cel(other[other.atc_class == cls]))
    return A


def _round_frame(df: pd.DataFrame, d_col: str = "d_clms", a_col: str = "a_clms", r_col: str | None = None,
                 gap_col: str | None = None) -> None:
    """Publish a detail sum rounded to the nearest BASE claims, with the fraction and gap
    recomputed from the rounded value."""
    if d_col not in df.columns:
        return
    df[d_col] = df[d_col].map(rnd)
    if r_col and r_col in df.columns:
        df[r_col] = df[d_col] / df[a_col]
    if gap_col and gap_col in df.columns:
        df[gap_col] = df[a_col] - df[d_col]


def _blank(df: pd.DataFrame, mask: pd.Series, cols: list[str]) -> None:
    for c in cols:
        if c in df.columns:
            df[c] = df[c].astype("float64")
            df.loc[mask, c] = float("nan")


def _reason(kind: str | None) -> str:
    return {"rule": RULE, "complement": COMPLEMENT}.get(kind or "", "")


def _write(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False, lineterminator="\n", float_format="%.15g")


REASONS = {
    "matched": "published total and public detail both present; detail sum does not exceed the total",
    "no public detail": "published total present; no public provider-drug row for this label and geography",
    "negative gap": "detail sum exceeds the published total",
    "detail without reference": "public detail present but no published total",
    "zero published total": "published total is zero",
}
CELL_COLS = ["data_year", "geo_level", "geo_code", "geo_desc", "geo_category", "brnd_name", "gnrc_name", "atc_class",
             "group", "combination", "status", "bound_ok", "a_clms", "a_cost", "a_benes_published", "retained_band",
             "values_withheld", "withheld_reason"]


def _cell_table(frame: pd.DataFrame, level: str, kinds: list) -> pd.DataFrame:
    out = frame.copy()
    out["geo_level"] = level
    out["retained_band"] = [("" if k else band(r)) for k, r in zip(kinds, out.retained_clms)]
    out["values_withheld"] = [k is not None for k in kinds]
    out["withheld_reason"] = [_reason(k) for k in kinds]
    for c in CELL_COLS:
        if c not in out.columns:
            out[c] = ""
    return out[CELL_COLS]


def _round_json(obj, nd=4):
    if isinstance(obj, float):
        return round(obj, nd)
    if isinstance(obj, dict):
        return {k: _round_json(v, nd) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_round_json(v, nd) for v in obj]
    return obj


def _public_summary(summary: dict) -> dict:
    """Summary with class detail sums rounded to the nearest BASE claims, ratios to four decimals,
    detail cost totals removed, and cell-level order statistics left out."""
    s = json.loads(json.dumps(summary))
    for c in s.get("national", {}).get("by_class", []):
        c.pop("d_cost", None)
        c.pop("a_cost", None)
        c["d_clms"] = rnd(c["d_clms"])
        c["weighted_retained"] = c["d_clms"] / c["a_clms"]
    st_ = s.get("states", {})
    for k in ("cell_retained_distribution",):
        st_.pop(k, None)
    return _round_json(s)


def build_public(years: list[int]) -> dict:
    report = {"generated_at_utc": utc_now(), "rule": RULE, "complement": COMPLEMENT, "rounding_base": BASE,
              "audit": "no withheld value may be pinned to a single claim count by the published tables", "years": {}}
    withheld_by_year: dict[int, dict] = {}
    for y in years:
        src = RESULTS / f"dy{y}"
        dst = PUBLIC / f"dy{y}"
        dst.mkdir(parents=True, exist_ok=True)
        nat = pd.read_csv(src / "national_reconciliation.csv", dtype={"geo_code": str})
        st = pd.read_csv(src / "state_reconciliation.csv", dtype={"geo_code": str})
        summary = json.loads((src / "summary.json").read_text())
        A = _build_system(nat, st, summary["states"]["well_matched_codes"])
        withheld = A.protect()
        withheld_by_year[y] = withheld

        # 1. Label-by-state cells and the full ledger (banded; withheld cells blank).
        ck = [withheld.get(("c", c, b, g)) for c, b, g in zip(st.geo_code, st.brnd_name, st.gnrc_name)]
        cells = _cell_table(st, "State", ck)
        _write(cells, dst / "state_reconciliation.csv")
        lk = [withheld.get(("L", b, g)) for b, g in zip(nat.brnd_name, nat.gnrc_name)]
        natc = nat.assign(geo_category="national", geo_desc="National")
        ledger = pd.concat([_cell_table(natc, "National", lk), cells], ignore_index=True)
        ledger["reason"] = ledger.status.map(REASONS)
        ledger["source_reference"] = "Medicare Part D Prescribers by Geography and Drug, Tot_Clms"
        ledger["source_detail"] = "Medicare Part D Prescribers by Provider and Drug, sum of Tot_Clms"
        _write(ledger, dst / "reconciliation_ledger.csv")
        with open(dst / "reconciliation_ledger.jsonl", "w", encoding="utf-8") as fh:
            for rec in ledger.to_dict(orient="records"):
                fh.write(json.dumps({k: (None if isinstance(v, float) and pd.isna(v) else v) for k, v in rec.items()},
                                    default=str) + "\n")

        # 2. National label table (rounded, with withholding).
        pn = nat.copy()
        _round_frame(pn, r_col="retained_clms", gap_col="gap_clms")
        mask = pd.Series([k is not None for k in lk], index=pn.index)
        _blank(pn, mask, ["d_clms", "gap_clms", "retained_clms", "d_cost", "retained_cost", "d_fills", "retained_fills"])
        pn["values_withheld"] = mask
        pn["withheld_reason"] = [_reason(k) for k in lk]
        pn = pn.drop(columns=["d_rows", "prescriber_coverage", "missing_prescriber_rows", "a_prscrbrs"])
        _write(pn, dst / "national_reconciliation.csv")

        # 3. National group and volume-band tables; label order statistics hidden where a withheld label sits.
        nbg = pd.read_csv(src / "national_by_group.csv")
        _round_frame(nbg, r_col="weighted_retained")
        mk = pd.Series([("G", c, g) in withheld for c, g in zip(nbg.atc_class, nbg.group)], index=nbg.index)
        _blank(nbg, mk, ["d_clms", "weighted_retained"])
        hidden_lab_groups = set(zip(nat[mask].atc_class, nat[mask].group))
        _blank(nbg, mk | pd.Series([(c, g) in hidden_lab_groups for c, g in zip(nbg.atc_class, nbg.group)],
                                   index=nbg.index), ["median_label_retained", "min_label_retained", "max_label_retained"])
        _write(nbg, dst / "national_by_group.csv")
        vb = pd.read_csv(src / "national_by_volume_band.csv")
        _round_frame(vb, r_col="weighted_retained")
        mk = pd.Series([("B", b) in withheld for b in vb.volume_band], index=vb.index)
        _blank(vb, mk, ["d_clms", "weighted_retained"])
        hidden_bands = set(nat[mask].volume_band)
        _blank(vb, mk | pd.Series([b in hidden_bands for b in vb.volume_band], index=vb.index), ["median_label_retained"])
        _write(vb, dst / "national_by_volume_band.csv")

        # 4. Group shares by state, with class totals; rank summaries.
        gs = pd.read_csv(src / "group_shares.csv", dtype={"geo_code": str})
        gs["d_clms"] = gs.d_clms.map(rnd)
        gs["class_d_clms"] = gs.class_d_clms.map(rnd)
        gs["share_detail"] = gs.d_clms / gs.class_d_clms
        gs["share_difference_pp"] = 100 * (gs.share_detail - gs.share_published)
        s_mask = pd.Series([("S", g, c, grp) in withheld for g, c, grp in zip(gs.geo_code, gs.atc_class, gs.group)],
                           index=gs.index)
        k_mask = pd.Series([("K", g, c) in withheld or (g == "National" and ("C", c) in withheld)
                            for g, c in zip(gs.geo_code, gs.atc_class)], index=gs.index)
        n_mask = pd.Series([(g == "National") and (("G", c, grp) in withheld)
                            for g, c, grp in zip(gs.geo_code, gs.atc_class, gs.group)], index=gs.index)
        any_mask = s_mask | k_mask | n_mask
        _blank(gs, any_mask, ["d_clms", "share_detail", "share_difference_pp", "rank_detail"])
        _blank(gs, k_mask, ["class_d_clms"])
        gs["values_withheld"] = any_mask
        _write(gs, dst / "group_shares.csv")
        rk = pd.read_csv(src / "rank_shifts.csv", dtype={"largest_shift_geo_code": str})
        hidden_groups = set(zip(gs[any_mask].atc_class, gs[any_mask].group))
        rmask = pd.Series([(c, g) in hidden_groups for c, g in zip(rk.atc_class, rk.group)], index=rk.index)
        _blank(rk, rmask, ["max_abs_share_difference_pp", "median_abs_share_difference_pp", "largest_shift_rank_detail",
                           "largest_shift_rank_published", "max_abs_rank_shift"])
        rk["largest_shift_geo_code"] = rk.largest_shift_geo_code.astype(str).where(~rmask, "")
        rk["summary_restricted"] = rmask
        _write(rk, dst / "rank_shifts.csv")

        # 5. State summary and other geographies.
        ss = pd.read_csv(src / "state_summary.csv", dtype={"geo_code": str})
        _round_frame(ss, r_col="weighted_retained")
        # Cell medians are single cells' exact fractions; they are not published.
        ss = ss.drop(columns=[c for c in ("median_cell_retained",) if c in ss.columns])
        sev = st[st.status.isin(EVAL)]
        for cl in ("A10", "C09", "C10"):
            col = f"weighted_retained_{cl}"
            if col in ss.columns:
                kk = sev[sev.atc_class == cl].groupby("geo_code").agg(d=("d_clms", "sum"), a=("a_clms", "sum"))
                ss[col] = [rnd(kk.loc[g, "d"]) / kk.loc[g, "a"] if g in kk.index else float("nan") for g in ss.geo_code]
                _blank(ss, pd.Series([("K", g, cl) in withheld for g in ss.geo_code], index=ss.index), [col])
        _blank(ss, pd.Series([("U", g) in withheld for g in ss.geo_code], index=ss.index), ["d_clms", "weighted_retained"])
        _write(ss, dst / "state_summary.csv")
        og = pd.read_csv(src / "other_geography_summary.csv", dtype={"geo_code": str})
        _round_frame(og, r_col="weighted_retained")
        if len(og):
            mk = pd.Series([("O", g) in withheld for g in og.geo_code], index=og.index)
            _blank(og, mk, ["d_clms", "weighted_retained"])
            og["values_withheld"] = mk
        _write(og, dst / "other_geography_summary.csv")

        (dst / "mapping_decisions.csv").write_bytes((src / "mapping_decisions.csv").read_bytes())
        write_json(dst / "summary.json", _public_summary(summary))

        counts = defaultdict(int)
        for k, kind in withheld.items():
            counts[f"{k[0]}_{kind}"] += 1
        report["years"][y] = {
            "state_cells": int(len(st)),
            "state_cells_band_withheld": int(cells.values_withheld.sum()),
            "state_cells_band_withheld_rule": counts.get("c_rule", 0),
            "national_labels": int(len(nat)),
            "national_labels_withheld": sum(1 for k in withheld if k[0] == "L"),
            "national_labels_withheld_rule": counts.get("L_rule", 0),
            "group_state_rows_withheld": sum(1 for k in withheld if k[0] == "S"),
            "other_aggregate_rows_withheld": sum(1 for k in withheld if k[0] not in ("L", "S", "c")),
            "withheld_by_kind": dict(sorted(counts.items())),
        }

    # Replication tables: mask each year's withheld national labels and groups.
    rep = RESULTS / "replication"
    if rep.exists():
        (PUBLIC / "replication").mkdir(parents=True, exist_ok=True)
        lc = pd.read_csv(rep / "label_continuity.csv")
        for y in years:
            col = f"retained_{y}"
            if col in lc.columns:
                pn_y = pd.read_csv(PUBLIC / f"dy{y}" / "national_reconciliation.csv")
                pub = dict(zip(zip(pn_y.brnd_name, pn_y.gnrc_name), pn_y.retained_clms))
                lc[col] = [pub.get((b, g), float("nan")) if not pd.isna(v) else v
                           for b, g, v in zip(lc.brnd_name, lc.gnrc_name, lc[col])]
        _write(lc, PUBLIC / "replication" / "label_continuity.csv")
        gy = pd.read_csv(rep / "group_by_year.csv")
        _round_frame(gy, r_col="weighted_retained")
        gmask = pd.Series([("G", c, g) in withheld_by_year.get(int(y), {})
                           for y, c, g in zip(gy.data_year, gy.atc_class, gy.group)], index=gy.index)
        _blank(gy, gmask, ["d_clms", "weighted_retained"])
        _write(gy, PUBLIC / "replication" / "group_by_year.csv")
        write_json(PUBLIC / "replication" / "replication_summary.json",
                   _round_json(json.loads((rep / "replication_summary.json").read_text())))
    write_json(PUBLIC / "disclosure_report.json", report)
    return report


def public_audit(year: int) -> dict:
    """Attacker's view: rebuild the interval system from the public files alone and confirm that
    no withheld value is pinned to a single claim count."""
    d = PUBLIC / f"dy{year}"
    nat = pd.read_csv(d / "national_reconciliation.csv")
    cells = pd.read_csv(d / "state_reconciliation.csv", dtype={"geo_code": str}, keep_default_na=False,
                        na_values=[""])
    summ = json.loads((d / "summary.json").read_text())
    well = summ["states"]["well_matched_codes"]
    A = Audit()
    ne = nat[nat.status.isin(EVAL)]
    ce = cells[cells.status.isin(EVAL)]
    withheld_keys = []
    for r in ne.itertuples(index=False):
        key = ("L", r.brnd_name, r.gnrc_name)
        hidden = bool(r.values_withheld)
        A.add(key, 0 if hidden else r.d_clms, _leaf_interval(r.status, r.a_clms), "hidden" if hidden else "rounded")
        if hidden:
            withheld_keys.append(key)
    for r in ce.itertuples(index=False):
        key = ("c", r.geo_code, r.brnd_name, r.gnrc_name)
        b = r.retained_band if isinstance(r.retained_band, str) else ""
        if b:
            lo, hi = BAND_RANGE[b]
            A.add(key, 0, _leaf_interval(r.status, r.a_clms), "band", band_iv=(lo * r.a_clms, hi * r.a_clms))
        else:
            A.add(key, 0, _leaf_interval(r.status, r.a_clms), "hidden")
            withheld_keys.append(key)

    def agg(key, frame, value, kind="rounded"):
        matched = frame.status == "matched"
        lo, hi = 11.0 * matched.sum(), frame[matched].a_clms.sum()
        if pd.isna(value):
            A.add(key, 0, (lo, hi), "hidden")
            withheld_keys.append(key)
        else:
            A.add(key, value, (lo, hi), kind)

    lab = lambda f: [("L", b, g) for b, g in zip(f.brnd_name, f.gnrc_name)]  # noqa: E731
    cel = lambda f: [("c", c, b, g) for c, b, g in zip(f.geo_code, f.brnd_name, f.gnrc_name)]  # noqa: E731
    nbg = pd.read_csv(d / "national_by_group.csv").set_index(["atc_class", "group"])
    vb = pd.read_csv(d / "national_by_volume_band.csv").set_index("volume_band")
    for (cls, grp), g in ne.groupby(["atc_class", "group"]):
        agg(("G", cls, grp), g, nbg.loc[(cls, grp), "d_clms"])
        A.eq(("G", cls, grp), lab(g))
    for (band_,), g in ne.groupby(["volume_band"]):
        agg(("B", band_), g, vb.loc[band_, "d_clms"])
        A.eq(("B", band_), lab(g))
    by_class = {c["atc_class"]: c.get("d_clms") for c in summ["national"]["by_class"]}
    for (cls,), g in ne.groupby(["atc_class"]):
        agg(("C", cls), g, by_class.get(cls, float("nan")))
        A.eq(("C", cls), [("G", cls, grp) for grp in sorted(set(g.group))])
    agg(("T",), ne, summ["national"]["d_clms"], kind="exact")
    A.eq(("T",), [("C", c) for c in sorted(set(ne.atc_class))])
    A.eq(("T",), [("B", b) for b in sorted(set(ne.volume_band))])
    for (b_, g_), g in ce.groupby(["brnd_name", "gnrc_name"]):
        if ("L", b_, g_) in A.kind:
            A.eq(("L", b_, g_), cel(g))
    gs = pd.read_csv(d / "group_shares.csv", dtype={"geo_code": str})
    ss = pd.read_csv(d / "state_summary.csv", dtype={"geo_code": str}).set_index("geo_code")
    og = pd.read_csv(d / "other_geography_summary.csv", dtype={"geo_code": str})
    og = og.set_index("geo_code") if len(og) else og
    ws = ce[ce.geo_code.isin(well)]
    other = ce[~ce.geo_code.isin(well)]
    gsi = gs.set_index(["geo_code", "atc_class", "group"])
    for (code, cls, grp), g in ws.groupby(["geo_code", "atc_class", "group"]):
        val = gsi.loc[(code, cls, grp), "d_clms"] if (code, cls, grp) in gsi.index else float("nan")
        agg(("S", code, cls, grp), g, val)
        A.eq(("S", code, cls, grp), cel(g))
    for (code, cls), g in ws.groupby(["geo_code", "atc_class"]):
        rows = gs[(gs.geo_code == code) & (gs.atc_class == cls)]
        val = rows.class_d_clms.iloc[0] if len(rows) else float("nan")
        agg(("K", code, cls), g, val)
        A.eq(("K", code, cls), [("S", code, cls, grp) for grp in sorted(set(g.group))])
    for (code,), g in ws.groupby(["geo_code"]):
        agg(("U", code), g, ss.loc[code, "d_clms"] if code in ss.index else float("nan"))
        A.eq(("U", code), [("K", code, c) for c in sorted(set(g.atc_class))])
    for (code,), g in other.groupby(["geo_code"]):
        val = og.loc[code, "d_clms"] if len(og) and code in og.index else float("nan")
        agg(("O", code), g, val)
        A.eq(("O", code), cel(g))
    A.eq(("T",), [("U", c) for c in sorted(set(ws.geo_code))] + [("O", c) for c in sorted(set(other.geo_code))])
    for (cls, grp), g in ne.groupby(["atc_class", "group"]):
        states = sorted(set(ws[(ws.atc_class == cls) & (ws.group == grp)].geo_code))
        rest = other[(other.atc_class == cls) & (other.group == grp)]
        A.eq(("G", cls, grp), [("S", c, cls, grp) for c in states] + cel(rest))
    for cls in sorted(set(ne.atc_class)):
        states = sorted(set(ws[ws.atc_class == cls].geo_code))
        A.eq(("C", cls), [("K", c, cls) for c in states] + cel(other[other.atc_class == cls]))
    b, _ = A.propagate()
    bad = A.violations(b, withheld_keys)
    return {"data_year": year, "withheld_values_checked": len(withheld_keys), "narrowed_below_protection": len(bad),
            "examples": [str(k) for k in bad[:10]], "narrowest_range_claims": min(
                (b[k][1] - b[k][0] for k in withheld_keys if A.intr[k][1] > A.intr[k][0]), default=None),
            "withheld_values_narrowed_at_all": sum(1 for k in withheld_keys if (b[k][1] - b[k][0]) <
                                                    (A.intr[k][1] - A.intr[k][0]) - EPS)}
