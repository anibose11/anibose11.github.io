"""Excel reconciliation workbook: one sheet per result table plus definitions and sources.

The workbook holds aggregate published totals and aggregate detail sums only. It
contains no prescriber names and no person-level data.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter

DEFINITIONS = [
    ("data_year", "Calendar year of the prescription drug events (not the release year).", ""),
    ("geo_code", "'National', or the state-level code shared by both files: FIPS for states, DC and territories; "
                 "9A to 9C Armed Forces; 9D Unknown; 9E Foreign Country; BLANK when the published row carried no code.", ""),
    ("geo_category", "state or DC (well-matched geography), territory, armed forces, unknown, foreign country, "
                     "blank or unrecognized.", ""),
    ("brnd_name, gnrc_name", "Drug label exactly as published by CMS. Combination products are one label.", ""),
    ("atc_class", "Scope class from the NLM RxClass ATC membership: A10 diabetes, C09 renin-angiotensin, C10 lipid "
                  "modifying.", ""),
    ("group", "ATC level-4 group of a single-ingredient label (A10A for every insulin), or the class's fixed-dose "
              "combination group.", ""),
    ("a_clms", "Published total claims (Tot_Clms) in Medicare Part D Prescribers by Geography and Drug. Built by CMS "
               "from all Part D prescription drug events.", "claims"),
    ("d_clms", "Sum of Tot_Clms over the public Provider and Drug rows for the same label and geography. Rows with "
               "10 or fewer claims are absent from that file.", "claims"),
    ("gap_clms", "a_clms minus d_clms. A negative value is kept as observed and flagged.", "claims"),
    ("retained_clms", "d_clms divided by a_clms. Empty when no published total exists.", "fraction 0 to 1"),
    ("a_cost, d_cost", "Gross drug cost (Tot_Drug_Cst): ingredient cost, dispensing fee, sales tax and vaccine "
                       "administration fee paid by plans, beneficiaries and third parties. Not net of rebates.", "US dollars"),
    ("retained_cost", "d_cost divided by a_cost.", "fraction"),
    ("a_fills, d_fills", "30-day standardized fills.", "fills"),
    ("a_prscrbrs", "Published number of prescribers (Tot_Prscrbrs) for the label and geography.", "prescribers"),
    ("d_rows", "Number of public detail rows; one row per NPI per label.", "rows"),
    ("prescriber_coverage", "d_rows divided by a_prscrbrs.", "fraction"),
    ("a_benes_published", "Published beneficiary count, reported as published. Beneficiary counts are not additive "
                          "and are never summed across prescribers or drugs. Blank means suppressed.", "beneficiaries"),
    ("status", "matched; no public detail (published total, no detail row); negative gap (detail sum above the "
               "published total); detail without reference (detail rows, no published total).", ""),
    ("retained_band", "Label-by-state cells only: retained fraction reported in bands (0%, under 50%, 50% to under 90%, "
                      "90% to under 95%, 95% to 100%). Exact detail sums are not published at this level.", "band"),
    ("values_withheld, withheld_reason", "True where the value is withheld under the public output rule: the residual "
                                         "involves 1 or 2 unpublished prescriber rows or 1 to 10 claims, equals the "
                                         "smallest or largest value the 10-claim rule allows, or would let a withheld "
                                         "value be recovered by subtraction.", ""),
    ("bound_ok", "True when the gap lies between the number of unpublished prescriber rows and ten times that number.", ""),
    ("share_published, share_detail", "Group claims divided by class claims in the same geography, from published "
                                      "totals or from detail sums, using the same labels.", "fraction"),
    ("rank_published, rank_detail", "Rank of a jurisdiction among the 50 states and DC by group share (1 = highest; "
                                    "ties averaged). Descriptive only.", "rank"),
]

SHEETS = [
    ("National", "dy{y}/national_reconciliation.csv"),
    ("National by group", "dy{y}/national_by_group.csv"),
    ("By claim volume", "dy{y}/national_by_volume_band.csv"),
    ("States summary", "dy{y}/state_summary.csv"),
    ("State cells", "dy{y}/state_reconciliation.csv"),
    ("Other geography", "dy{y}/other_geography_summary.csv"),
    ("Group shares", "dy{y}/group_shares.csv"),
    ("Rank shifts", "dy{y}/rank_shifts.csv"),
    ("Exceptions", "dy{y}/exception_ledger.csv"),
    ("Mapping", "dy{y}/mapping_decisions.csv"),
]


def _sheet_from_df(wb: Workbook, title: str, df: pd.DataFrame) -> None:
    ws = wb.create_sheet(title[:31])
    ws.append(list(df.columns))
    for c in ws[1]:
        c.font = Font(bold=True)
    for row in df.itertuples(index=False):
        ws.append([None if (isinstance(v, float) and pd.isna(v)) else (v.item() if hasattr(v, "item") else v) for v in row])
    ws.freeze_panes = "A2"
    for i, col in enumerate(df.columns, start=1):
        width = min(48, max(10, len(str(col)) + 2,
                            *(len(str(v)) + 1 for v in df[col].head(200).tolist() if v is not None)))
        ws.column_dimensions[get_column_letter(i)].width = width
        if col.startswith(("retained", "share_", "prescriber_coverage", "weighted_retained", "median_", "min_", "max_", "spearman")):
            for cell in ws[get_column_letter(i)][1:]:
                cell.number_format = "0.0000"
        elif col.endswith(("_clms", "_rows", "prscrbrs", "cells", "labels")) or col in ("a_benes_published",):
            for cell in ws[get_column_letter(i)][1:]:
                cell.number_format = "#,##0"
        elif "cost" in col:
            for cell in ws[get_column_letter(i)][1:]:
                cell.number_format = "#,##0.00"
    ws.auto_filter.ref = ws.dimensions


def write_workbook(results_dir: Path, path: Path, year=None, sources: list[dict] | None = None,
                   replication_dir: Path | None = None) -> Path:
    results_dir = Path(results_dir)
    wb = Workbook()
    ws = wb.active
    ws.title = "Read me"
    lines = [
        "Medicare Part D suppression completeness audit: reconciliation workbook",
        "",
        "Each published Medicare Part D Prescribers by Geography and Drug claim total (a_clms) is compared with the sum "
        "of the public Provider and Drug rows for the same drug label and geography (d_clms).",
        "The detail file omits provider-drug rows with 10 or fewer claims, so d_clms is at most a_clms when both files "
        "describe the same scope. The retained fraction is d_clms / a_clms.",
        "Totals here are administrative counts for the stated Medicare Part D population, not samples; no confidence "
        "intervals apply. Beneficiary counts are never summed. Blank cells were not replaced with any value.",
        "Gross drug cost is not net of rebates and is not out-of-pocket cost.",
        "Geography is the prescriber's address in NPPES, not where the beneficiary lives.",
        "",
        "Sheets: Definitions, Sources, then one sheet per result table. Filters may subset rows; do not re-sum "
        "retained fractions or shares, which are ratios.",
    ]
    for line in lines:
        ws.append([line])
    ws.column_dimensions["A"].width = 140
    for row in ws.iter_rows():
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws["A1"].font = Font(bold=True, size=13)

    d = wb.create_sheet("Definitions")
    d.append(["field", "definition", "unit"])
    for c in d[1]:
        c.font = Font(bold=True)
    for f in DEFINITIONS:
        d.append(list(f))
    d.column_dimensions["A"].width = 32
    d.column_dimensions["B"].width = 120
    d.column_dimensions["C"].width = 16
    for row in d.iter_rows(min_row=2):
        row[1].alignment = Alignment(wrap_text=True, vertical="top")

    if sources:
        s = wb.create_sheet("Sources")
        keys = ["kind", "data_year", "url", "bytes", "sha256", "accessed_at_utc", "last_modified", "dataset_uuid"]
        s.append(keys)
        for c in s[1]:
            c.font = Font(bold=True)
        for f in sources:
            s.append([f.get(k) for k in keys])
        s.column_dimensions["C"].width = 100
        s.column_dimensions["E"].width = 66

    years = [year] if year is not None else [None]
    for title, pattern in SHEETS:
        rel_path = pattern.format(y=year) if year is not None else pattern.split("/", 1)[1]
        p = results_dir / rel_path
        if p.exists():
            _sheet_from_df(wb, title, pd.read_csv(p, dtype={"geo_code": str, "largest_shift_geo_code": str}))
    if replication_dir and (replication_dir / "label_continuity.csv").exists():
        _sheet_from_df(wb, "Replication labels", pd.read_csv(replication_dir / "label_continuity.csv"))
        _sheet_from_df(wb, "Replication groups", pd.read_csv(replication_dir / "group_by_year.csv"))
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path
