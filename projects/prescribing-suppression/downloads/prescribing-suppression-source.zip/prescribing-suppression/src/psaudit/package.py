"""Package the static project page, the source archive and the handoff files.

The source archive is built from an allowlist. It carries code, configuration,
documentation, frozen small reference inputs, public result tables and
verification records. It leaves out the CMS raw files, the Parquet warehouse,
environments, logs, private notes and cell-level tables that hold unpublished
residuals.
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

from psaudit.common import RESULTS, ROOT, load_toml, read_json, rel, sha256_file, utc_now, write_json

SLUG = "prescribing-suppression"
BUNDLE_NAME = "06-prescribing-suppression-PROJECT-BUNDLE.zip"
STAGE = ROOT / "deliverables" / "stage"
SITE_DIR = STAGE / "site" / "projects" / SLUG
SOURCE_ZIP_NAME = f"{SLUG}-source.zip"
FIXED_TIME = (2026, 10, 7, 0, 0, 0)

ALLOW = [
    "README.md", "LICENSE", "THIRD_PARTY_NOTICES.md", "CITATION.cff", "Makefile", "pyproject.toml", "requirements.in",
    "requirements.lock", ".gitignore",
    "config/*", "src/psaudit/*.py", "scripts/*.py", "templates/*", "tests/*.py", "tests/fixtures/*",
    "docs/*.md", "docs/*.csv", "docs/*.json",
    "data/manifest/source_manifest.json", "data/catalog/partd_prescribers_catalog_entries.json",
    "data/raw/rxclass/*.json", "data/raw/docs/dictionary_*", "data/raw/docs/*.pdf",
    # Only summaries and verification records from results/; every table with exact detail
    # sums is shipped in its public form from exports/public/.
    "results/run_metadata.json", "results/repro_check.json", "results/test_summary.json",
    "results/replication/replication_summary.json", "results/figures/*",
    "results/dy*/summary.json", "results/dy*/mapping_decisions.csv", "results/dy*/provider_reconciliation.json",
    "results/dy*/second_implementation_check.json", "results/dy*/exploratory_claims_per_prescriber.json",
    "exports/public/*", "exports/public/dy*/*", "exports/public/replication/*", "exports/tableau/*", "exports/*.xlsx",
    "evidence/claims_public.json",
]
# Machine-specific paths and secrets must never reach the archive. Extra private literals
# (for example personal contact details) can be listed in .local/scan_extra.txt.
# Submission notes and private handoff templates stay out of the public source archive.
DENY = {"docs/journal_fit.md", "templates/verified_results.md", "evidence/claims.json"}
DENY_PATTERNS = [
    re.compile(r"/Users/[A-Za-z0-9._-]+/"),
    re.compile(r"/home/[A-Za-z0-9._-]+/"),
    re.compile(r"[A-Z]:\\Users\\"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\b(sk|pk|ghp|xox[bp])[-_][A-Za-z0-9]{20,}"),
    re.compile(r"(?i)(api[_-]?key|secret|password)\s*[:=]\s*['\"][^'\"]{12,}"),
]
TEXT_SUFFIXES = {".md", ".py", ".toml", ".csv", ".json", ".jsonl", ".txt", ".cff", ".in", ".lock", ".html", ".css", ""}


def _allowed() -> list[Path]:
    files = []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        r = p.relative_to(ROOT).as_posix()
        if any(part in r.split("/") for part in (".venv", ".local", "__pycache__", "deliverables", "logs", "handoff",
                                                   "manuscript", "warehouse")):
            continue
        if any(fnmatch.fnmatch(r, pat) for pat in ALLOW) and r not in DENY:
            files.append(p)
    return files


def _extra_literals() -> list[str]:
    p = ROOT / ".local" / "scan_extra.txt"
    return [x.strip() for x in p.read_text().splitlines() if x.strip()] if p.exists() else []


def _scan(path: Path, arcname: str) -> list[str]:
    problems = []
    if path.suffix.lower() in TEXT_SUFFIXES and path.stat().st_size < 50_000_000:
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pat in DENY_PATTERNS:
            if pat.search(text):
                problems.append(f"{arcname}: matches {pat.pattern}")
        for lit in _extra_literals():
            if lit in text:
                problems.append(f"{arcname}: contains a private literal")
    return problems


def _zip(files: list[tuple[Path, str]], dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src, arc in sorted(files, key=lambda x: x[1]):
            info = zipfile.ZipInfo(arc, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, src.read_bytes())


def build_source_zip(dest: Path) -> dict:
    files = _allowed()
    problems = []
    pairs = []
    for f in files:
        arc = f"{SLUG}/{f.relative_to(ROOT).as_posix()}"
        problems += _scan(f, arc)
        pairs.append((f, arc))
    if problems:
        raise RuntimeError("source archive scan failed:\n" + "\n".join(problems))
    _zip(pairs, dest)
    return {"files": len(pairs), "bytes": dest.stat().st_size, "sha256": sha256_file(dest)}


DOWNLOADS = {
    "prescribing_suppression_reconciliation_2024.xlsx": "exports/prescribing_suppression_reconciliation_2024.xlsx",
    "reconciliation_ledger_2024.csv": "exports/public/dy2024/reconciliation_ledger.csv",
    "reconciliation_ledger_2024.jsonl": "exports/public/dy2024/reconciliation_ledger.jsonl",
    "national_reconciliation_2024.csv": "exports/public/dy2024/national_reconciliation.csv",
    "state_summary_2024.csv": "exports/public/dy2024/state_summary.csv",
    "group_shares_2024.csv": "exports/public/dy2024/group_shares.csv",
    "rank_shifts_2024.csv": "exports/public/dy2024/rank_shifts.csv",
    "mapping_decisions_2024.csv": "exports/public/dy2024/mapping_decisions.csv",
    "replication_group_by_year.csv": "exports/public/replication/group_by_year.csv",
    "analysis_plan.md": "docs/analysis_plan.md",
    "source_manifest.json": "data/manifest/source_manifest.json",
    "claims.json": "evidence/claims_public.json",
}
ASSETS = ["fig1_retained_vs_volume_2024.svg", "fig2_state_retained_2024.svg", "fig3_rank_agreement_2024.svg",
          "fig4_a10a_share_2024.svg"]


def build_site() -> list[Path]:
    if SITE_DIR.exists():
        shutil.rmtree(SITE_DIR)
    (SITE_DIR / "assets").mkdir(parents=True)
    (SITE_DIR / "downloads").mkdir()
    shutil.copy(ROOT / "report" / "index.html", SITE_DIR / "index.html")
    shutil.copy(ROOT / "report" / "report.html", SITE_DIR / "report.html")
    shutil.copy(ROOT / "report" / "assets" / "page.css", SITE_DIR / "assets" / "page.css")
    for a in ASSETS:
        shutil.copy(RESULTS / "figures" / a, SITE_DIR / "assets" / a)
    for name, src in DOWNLOADS.items():
        shutil.copy(ROOT / src, SITE_DIR / "downloads" / name)
    build_source_zip(SITE_DIR / "downloads" / SOURCE_ZIP_NAME)
    return sorted(p for p in SITE_DIR.rglob("*") if p.is_file())


def handoff_json(site_files: list[Path], validation: dict | None) -> dict:
    cfg = load_toml("analysis.toml")
    claims = read_json(ROOT / "evidence" / "claims.json")
    c = claims["claims"]
    manifest = read_json(ROOT / "data" / "manifest" / "source_manifest.json")
    src_zip = SITE_DIR / "downloads" / SOURCE_ZIP_NAME
    with zipfile.ZipFile(src_zip) as z:
        n_src = len(z.namelist())

    def finding(cid, statement, evidence):
        return {"id": cid, "statement": statement, "value": c[cid]["text"], "evidence": evidence,
                "evidence_selector": c[cid]["selector"], "claim_register": "site/projects/prescribing-suppression/downloads/claims.json"}

    findings = [
        finding("nat_R", "Share of published 2024 in-scope (ATC A10, C09, C10) claims represented by summed public detail, national",
                f"{SITE_DIR.relative_to(STAGE).as_posix()}/downloads/claims.json"),
        finding("nat_Rcost", "Same, gross drug cost", "results/dy2024/summary.json"),
        finding("label_R_median", "Median retained fraction across in-scope labels, national, 2024", "results/dy2024/summary.json"),
        finding("vol_low_R", "Retained fraction for labels with fewer than 10,000 published claims, 2024", "exports/public/dy2024/national_by_volume_band.csv"),
        finding("group_R_A10A", "Retained fraction for insulins (ATC A10A), national, 2024", "exports/public/dy2024/national_by_group.csv"),
        finding("state_R_min", "Lowest state-level retained fraction among the 50 states and DC, 2024", "exports/public/dy2024/state_summary.csv"),
        finding("state_R_max", "Highest state-level retained fraction, 2024", "exports/public/dy2024/state_summary.csv"),
        finding("bound_within", "National and state cells whose gap lies within the 10-claim bound (of bound_cells)", "results/dy2024/summary.json"),
        finding("ins_shift5", "Jurisdictions (of 51) moving five or more places in the state ordering by insulin share", "exports/public/dy2024/rank_shifts.csv"),
        finding("ins_tau", "Kendall tau-b between state orderings of insulin share, published vs detail", "exports/public/dy2024/rank_shifts.csv"),
        finding("all_R", "All drugs: share of published national claims in the detail file, 2024", "results/dy2024/provider_reconciliation.json"),
        finding("R_2023", "Replication: national in-scope retained fraction, 2023", "results/replication/replication_summary.json"),
        finding("R_2022", "Replication: national in-scope retained fraction, 2022", "results/replication/replication_summary.json"),
    ]
    data_versions = []
    for f in manifest["files"]:
        if f.get("data_year"):
            data_versions.append({k: f.get(k) for k in ("kind", "data_year", "release_year", "role", "dataset_uuid",
                                                        "catalog_modified", "url", "last_modified", "bytes", "sha256",
                                                        "accessed_at_utc")})
    out = {
        "slug": SLUG,
        "title": "What Suppression Hides in Medicare Part D Prescribing Data",
        "featured": False,
        "summary": ("Reconciles summed CMS Medicare Part D Provider and Drug rows against the published Geography and Drug "
                    f"totals for {c['scope_labels']['text']} cardiometabolic drug labels (ATC A10, C09, C10), nationally and by prescriber state, "
                    "for 2024 with 2023 and 2022 replications; tests every cell against the 10-claim suppression bound and "
                    "measures changes in group shares and state orderings."),
        "computational_completion_status": "complete: acquisition, build, analysis, second implementation, clean rerun, "
                                           "tests, render and packaging all ran on the full public files",
        "manuscript_status": read_json(ROOT / "handoff" / "status.json", {}).get(
            "manuscript_status", "complete draft for BMC Medical Research Methodology (Research article); author review "
                                 "and approval not yet recorded; not submitted"),
        "unresolved_prerequisites": [],
        "entry_page": f"site/projects/{SLUG}/index.html",
        "report": f"site/projects/{SLUG}/report.html",
        "source_archive": {"path": f"site/projects/{SLUG}/downloads/{SOURCE_ZIP_NAME}", "files": n_src,
                           "bytes": src_zip.stat().st_size, "sha256": sha256_file(src_zip)},
        "data_versions": data_versions,
        "rxclass": {"rxnav_version": c["rxnav_version"]["text"], "ingredients": c["ingredients"]["value"]},
        "run_provenance": {"run_id": claims["run_id"], "config_sha256": claims["config_sha256"],
                           "run_metadata": read_json(RESULTS / "run_metadata.json"),
                           "repro_check": {k: read_json(RESULTS / "repro_check.json").get(k) for k in
                                           ("files_compared", "values_compared", "differences",
                                            "max_abs_numeric_difference", "identical_within_tolerance", "tolerance")},
                           "second_implementation": {"values_compared": c["second_values"]["value"],
                                                     "mismatches": c["second_mismatches"]["value"]},
                           "tests": read_json(RESULTS / "test_summary.json")},
        "commands_executed": [
            "make setup", "python -m psaudit acquire", "python -m psaudit build", "python -m psaudit analyze",
            "python -m psaudit validate", "python -m psaudit render", "python -m psaudit package",
            "python scripts/verify_bundle.py",
        ],
        "measured_findings": findings,
        "key_limitations": [
            "Scope limited to ATC A10, C09 and C10 as listed by RxClass; omega-3 esters and icosapent ethyl are not listed and were excluded.",
            "Geography is the prescriber's NPPES address, not beneficiary residence.",
            "The Geography and Drug reference omits state rows under 11 claims.",
            "Full administrative totals: no sampling intervals; rank changes are descriptive.",
            "Results apply to the CMS file versions and checksums in the source manifest; CMS revises files.",
            "Public tables withhold residuals for cells with one or two missing prescriber rows or a residual of 1 to 10 claims.",
        ],
        "public_files": [{"path": f.relative_to(STAGE).as_posix(), "bytes": f.stat().st_size, "sha256": sha256_file(f)}
                         for f in site_files],
        "verification": validation,
        "generated_at_utc": utc_now(),
    }
    return out


def assemble_bundle(handoff_files: dict[str, Path]) -> Path:
    out = ROOT / "deliverables" / BUNDLE_NAME
    pairs = [(p, p.relative_to(STAGE).as_posix()) for p in sorted((STAGE / "site").rglob("*")) if p.is_file()]
    for arc, src in handoff_files.items():
        pairs.append((src, arc))
    _zip(pairs, out)
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
        if bad:
            raise RuntimeError(f"zip integrity failure at {bad}")
    return out


def package_all(validation: dict | None = None) -> dict:
    site_files = build_site()
    hj = handoff_json(site_files, validation)
    hdir = ROOT / "handoff"
    hdir.mkdir(exist_ok=True)
    write_json(hdir / f"{SLUG}.json", hj)
    handoff = {f"handoff/{SLUG}.json": hdir / f"{SLUG}.json", "handoff/verified_results.md": hdir / "verified_results.md"}
    vpath = hdir / f"{SLUG}-validation.md"
    if vpath.exists():
        handoff[f"handoff/{SLUG}-validation.md"] = vpath
    # Journal submission package (not submitted): additional files first, so the source archive
    # copy inside it is the one just built, then the folder and its own zip.
    from psaudit.additional import build_additional_files, build_submission_package

    build_additional_files([load_toml("analysis.toml")["primary_year"], *load_toml("analysis.toml")["replication_years"]])
    submission = build_submission_package()
    for f in sorted((ROOT / "manuscript" / "submission").iterdir()):
        handoff[f"handoff/submission/upload/{f.name}"] = f
    handoff["handoff/submission/not_for_upload/Submission_checklist.md"] = ROOT / "manuscript" / "submission_checklist.md"
    bundle = assemble_bundle(handoff)
    res = {"bundle": rel(bundle), "bytes": bundle.stat().st_size, "sha256": sha256_file(bundle),
           "site_files": len(site_files), "source_archive": hj["source_archive"], "submission": submission}
    print(json.dumps(res, indent=1))
    return res
