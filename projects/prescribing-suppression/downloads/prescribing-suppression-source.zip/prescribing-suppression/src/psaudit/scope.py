"""Prespecified cardiometabolic scope: ATC ingredient list and generic-label mapping.

The ingredient list is the NLM RxClass ATC membership of each configured class.
A published generic label is in scope when at least one "/"-separated component
maps to an in-scope ingredient. Combination labels stay single labels; they are
never split into per-ingredient claim totals.
"""

from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

import requests

from psaudit.acquire import USER_AGENT, _manifest_lock
from psaudit.common import CONFIG, MANIFEST_DIR, RAW, load_toml, read_json, rel, sha256_file, utc_now, write_json

RXCLASS_DIR = RAW / "rxclass"
SOURCE_MANIFEST = MANIFEST_DIR / "source_manifest.json"


@dataclass(frozen=True)
class Ingredient:
    name: str          # RxNorm name as published by RxClass
    norm: str          # normalized for matching
    tty: str
    rxcui: str
    atc5: tuple[str, ...]
    atc_class: str     # A10, C09 or C10

    @property
    def atc4(self) -> str:
        return sorted(self.atc5)[0][:5] if self.atc5 else self.atc_class


# ATC A10A covers every insulin and analogue; RxClass lists only some insulin
# ingredients, so any component naming insulin maps to the group itself.
INSULIN_GROUP = Ingredient(name="insulins and analogues", norm="insulin", tty="ATC group", rxcui="",
                           atc5=("A10A",), atc_class="A10")


DEVICE_WORDS = {"pump", "pmp", "syringe", "syring", "needle", "needl", "pen", "cart", "admin", "supplies", "supply"}


@dataclass
class LabelDecision:
    brnd_name: str
    gnrc_name: str
    components: list[str]
    matches: list[dict] = field(default_factory=list)
    in_scope: bool = False
    atc_class: str = ""
    group: str = ""
    combination: bool = False
    note: str = ""


def _strip_words() -> set[str]:
    return set(load_toml("scope.toml")["matching"]["strip_words"])


def normalize(text: str, strip: set[str] | None = None) -> str:
    strip = _strip_words() if strip is None else strip
    t = text.lower()
    t = re.sub(r"[,.()\-\[\]]", " ", t)
    tokens = [tok for tok in t.split() if tok not in strip]
    return " ".join(tokens)


def fetch_rxclass(force: bool = False) -> dict:
    """Download RxClass ATC members for each configured class (cached, checksummed)."""
    cfg = load_toml("scope.toml")
    RXCLASS_DIR.mkdir(parents=True, exist_ok=True)
    headers = {"User-Agent": USER_AGENT}
    out = {}
    targets = [("version", cfg["rxnav_version_endpoint"], {})]
    for c in cfg["class"]:
        targets.append((c["atc"], cfg["rxclass_endpoint"], {"classId": c["atc"], "relaSource": "ATC"}))
    for key, url, params in targets:
        dest = RXCLASS_DIR / f"rxclass_{key}.json"
        if dest.exists() and not force:
            out[key] = json.loads(dest.read_text())
            continue
        r = requests.get(url, params=params, headers=headers, timeout=60)
        r.raise_for_status()
        if "json" not in r.headers.get("Content-Type", ""):
            raise RuntimeError(f"RxClass returned {r.headers.get('Content-Type')} for {key}")
        data = r.json()
        dest.write_text(json.dumps(data, indent=1, sort_keys=True) + "\n")
        out[key] = data
        entry = {
            "kind": "rxclass_atc_members" if key != "version" else "rxnav_version",
            "url": r.url,
            "http_status": r.status_code,
            "content_type": r.headers.get("Content-Type"),
            "local_path": rel(dest),
            "bytes": dest.stat().st_size,
            "sha256": sha256_file(dest),
            "accessed_at_utc": utc_now(),
            "permitted_use": "NLM RxNav APIs are free public services; RxClass ATC data are redistributed from RxNorm sources",
            "note": "Mutable API: the cached response is the frozen input; a later request may differ.",
        }
        with _manifest_lock():
            manifest = read_json(SOURCE_MANIFEST, default={"generated_by": "psaudit acquire", "files": []})
            files = {f["local_path"]: f for f in manifest["files"]}
            files[entry["local_path"]] = entry
            manifest["files"] = sorted(files.values(), key=lambda f: f["local_path"])
            manifest["updated_at_utc"] = utc_now()
            write_json(SOURCE_MANIFEST, manifest)
    return out


def load_ingredients() -> list[Ingredient]:
    cfg = load_toml("scope.toml")
    strip = _strip_words()
    found: dict[tuple[str, str], dict] = {}
    for c in cfg["class"]:
        path = RXCLASS_DIR / f"rxclass_{c['atc']}.json"
        data = json.loads(path.read_text())
        for m in data.get("drugMemberGroup", {}).get("drugMember", []):
            concept = m["minConcept"]
            if concept["tty"] not in ("IN", "PIN"):
                continue  # multi-ingredient concepts are informational only
            codes = [a["attrValue"] for a in m.get("nodeAttr", []) if a["attrName"] == "SourceId"]
            key = (concept["name"], c["atc"])
            rec = found.setdefault(key, {"tty": concept["tty"], "rxcui": concept["rxcui"], "atc5": set()})
            rec["atc5"].update(x for x in codes if x.startswith(c["atc"]))
    ingredients = []
    for (name, atc_class), rec in sorted(found.items()):
        ingredients.append(Ingredient(name=name, norm=normalize(name, strip), tty=rec["tty"], rxcui=rec["rxcui"],
                                      atc5=tuple(sorted(rec["atc5"])), atc_class=atc_class))
    return ingredients


def load_overrides() -> dict[str, str]:
    path = CONFIG / "scope_overrides.csv"
    if not path.exists():
        return {}
    with open(path, newline="", encoding="utf-8") as fh:
        return {row["gnrc_component"].strip().lower(): row["ingredient"].strip() for row in csv.DictReader(fh)}


def _match_component(comp: str, ingredients: list[Ingredient], overrides: dict[str, str], strip: set[str],
                     min_prefix: int) -> list[tuple[Ingredient, str]]:
    raw = comp.strip().lower()
    if raw in overrides:
        target = overrides[raw]
        return [(i, "override") for i in ingredients if i.name == target]
    norm = normalize(comp, strip)
    if not norm:
        return []
    tokens = norm.split()
    if tokens[0] == "insulin":
        # "Insulin Pump Cart", "Insulin Pmp Cart" (pods) and "Insulin Admin.
        # Supplies" (a reusable pen) are delivery devices, not insulin.
        # Syringe labels never start with "insulin".
        if len(tokens) > 1 and tokens[1] in DEVICE_WORDS:
            return []
        return [(INSULIN_GROUP, "insulin rule")]
    exact = [i for i in ingredients if i.norm == norm]
    if exact:
        return [(i, "exact") for i in exact]
    token = [i for i in ingredients
             if (len(i.norm.split()) == 1 and tokens[0] == i.norm)
             or (len(i.norm.split()) > 1 and norm.startswith(i.norm))]
    if token:
        return [(i, "token") for i in token]
    first = tokens[0]
    if len(first) >= min_prefix:
        pref = [i for i in ingredients if len(i.norm.split()) == 1 and i.norm.startswith(first) and i.norm != first]
        names = {i.norm for i in pref}
        if len(names) == 1:
            return [(i, "prefix") for i in pref]
    return []


def map_label(brnd: str, gnrc: str, ingredients: list[Ingredient], overrides: dict[str, str] | None = None,
              strip: set[str] | None = None, min_prefix: int | None = None) -> LabelDecision:
    cfg = load_toml("scope.toml")
    strip = _strip_words() if strip is None else strip
    overrides = load_overrides() if overrides is None else overrides
    min_prefix = cfg["matching"]["min_prefix_letters"] if min_prefix is None else min_prefix
    comps = [c.strip() for c in gnrc.split("/") if c.strip()]
    d = LabelDecision(brnd_name=brnd, gnrc_name=gnrc, components=comps, combination=len(comps) > 1)
    classes = set()
    groups = set()
    for comp in comps:
        hits = _match_component(comp, ingredients, overrides, strip, min_prefix)
        for ing, method in hits:
            d.matches.append({"component": comp, "ingredient": ing.name, "rxcui": ing.rxcui, "atc_class": ing.atc_class,
                              "atc5": ";".join(ing.atc5), "method": method})
            classes.add(ing.atc_class)
            groups.add(cfg["matching"]["insulin_group"] if method == "insulin rule" else ing.atc4)
    d.in_scope = bool(d.matches)
    if not d.in_scope:
        return d
    d.atc_class = "+".join(sorted(classes))
    insulin = any(m["method"] == "insulin rule" for m in d.matches)
    unmatched = [c for c in comps if c not in {m["component"] for m in d.matches}]
    if insulin:
        # Premixed insulins and insulin/GLP-1 combinations sit in ATC A10A.
        d.group = cfg["matching"]["insulin_group"]
        if unmatched:
            d.note = "insulin product; other components name the same insulin or its form: " + ", ".join(unmatched)
        return d
    if d.combination:
        d.group = f"{d.atc_class} fixed-dose combination"
    else:
        d.group = sorted(groups)[0]
    if len(classes) > 1:
        d.note = "components map to more than one scope class"
    if unmatched:
        d.note = (d.note + "; " if d.note else "") + "components outside scope: " + ", ".join(unmatched)
    return d


def decisions_table(labels: list[tuple[str, str]]) -> list[dict]:
    ingredients = load_ingredients()
    overrides = load_overrides()
    rows = []
    for brnd, gnrc in sorted(set(labels)):
        d = map_label(brnd, gnrc, ingredients, overrides)
        rows.append({
            "brnd_name": d.brnd_name,
            "gnrc_name": d.gnrc_name,
            "in_scope": d.in_scope,
            "atc_class": d.atc_class,
            "group": d.group,
            "combination": d.combination,
            "components": " | ".join(d.components),
            "matched_ingredients": " | ".join(f"{m['component']} -> {m['ingredient']} ({m['method']}, {m['atc5'] or m['atc_class']})"
                                              for m in d.matches),
            "note": d.note,
        })
    return rows
