"""Reconcile summed public detail against published Geography and Drug totals.

Implements the primary estimand and secondary outputs in docs/analysis_plan.md.
Every cell keeps its source keys. Cells that cannot be evaluated are written to
the exception ledger with a reason; none of them becomes a zero.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pandas as pd

from psaudit import scope
from psaudit.build import connect
from psaudit.common import RESULTS, WAREHOUSE, load_toml, read_json, rel, utc_now, write_json

STATUS_MATCHED = "matched"
STATUS_NO_DETAIL = "no public detail"
STATUS_NEGATIVE = "negative gap"
STATUS_NO_REFERENCE = "detail without reference"
STATUS_ZERO_REFERENCE = "zero published total"


def _geo_category(code: str, cfg: dict) -> str:
    if code == "National":
        return "national"
    if code in cfg["well_matched_codes"]:
        return "state or DC"
    if code in cfg["territory_codes"]:
        return "territory"
    if code in cfg["other_codes"]:
        return {"9A": "armed forces", "9B": "armed forces", "9C": "armed forces", "9D": "unknown",
                "9E": "foreign country"}[code]
    return "blank or unrecognized"


def _status(a, d) -> str:
    a_present = a is not None and not pd.isna(a)
    d_val = 0 if d is None or pd.isna(d) else d
    if not a_present:
        return STATUS_NO_REFERENCE
    if a == 0:
        return STATUS_ZERO_REFERENCE
    if d_val == 0:
        return STATUS_NO_DETAIL
    if d_val > a:
        return STATUS_NEGATIVE
    return STATUS_MATCHED


def _fraction(num, den):
    if den is None or pd.isna(den) or den == 0:
        return None
    return (0 if num is None or pd.isna(num) else num) / den


ROUND = {"a_cost": 2, "d_cost": 2, "a_fills": 4, "d_fills": 4}


def _write_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Sums of decimal source values carry floating-point noise; write them at source precision.
    df = df.copy()
    for c, n in ROUND.items():
        if c in df.columns:
            df[c] = df[c].round(n)
    df.to_csv(path, index=False, lineterminator="\n", float_format="%.15g")


def _quantiles(s: pd.Series) -> dict:
    s = s.dropna()
    if s.empty:
        return {"n": 0}
    return {"n": int(s.size), "min": float(s.min()), "q1": float(s.quantile(0.25)), "median": float(s.median()),
            "q3": float(s.quantile(0.75)), "max": float(s.max())}


def _bands(s: pd.Series, thresholds: list[float]) -> dict:
    """Counts of fractions equal to 0, in (0, t1), [t1, t2), ..., and at or above the last threshold."""
    s = s.dropna()
    out = {"equal_0": int((s == 0).sum())}
    edges = [0.0] + list(thresholds)
    for lo, hi in zip(edges[:-1], edges[1:]):
        mask = (s > lo) & (s < hi) if lo == 0 else (s >= lo) & (s < hi)
        out[f"{lo:g}_to_{hi:g}"] = int(mask.sum())
    out[f"ge_{edges[-1]:g}"] = int((s >= edges[-1]).sum())
    return out


VOLUME_BANDS = [(11, 100), (100, 1_000), (1_000, 10_000), (10_000, 100_000), (100_000, 1_000_000), (1_000_000, None)]


def _volume_band(a: float) -> str:
    for lo, hi in VOLUME_BANDS:
        if a >= lo and (hi is None or a < hi):
            return f"{lo:,} to {hi - 1:,}" if hi else f"{lo:,} or more"
    return "below 11"


def _add_bound_check(df: pd.DataFrame) -> None:
    """Amendment 1: m <= G <= 10 m, where m = published prescribers minus detail rows."""
    m = df.a_prscrbrs - df.d_rows
    g = df.gap_clms
    df["missing_prescriber_rows"] = m
    ok = ((m == 0) & (g == 0)) | ((m >= 1) & (g >= m) & (g <= 10 * m))
    df["bound_ok"] = ok.where(df.a_clms.notna() & df.a_prscrbrs.notna())


def _kendall_tau_b(x: list[float], y: list[float]) -> float:
    n = len(x)
    conc = disc = tx = ty = 0
    for i in range(n):
        for j in range(i + 1, n):
            dx, dy = x[i] - x[j], y[i] - y[j]
            if dx == 0 and dy == 0:
                continue
            if dx == 0:
                tx += 1
            elif dy == 0:
                ty += 1
            elif (dx > 0) == (dy > 0):
                conc += 1
            else:
                disc += 1
    denom = ((conc + disc + tx) * (conc + disc + ty)) ** 0.5
    return (conc - disc) / denom if denom else float("nan")


def analyze_year(year: int, run_id: str) -> dict:
    return analyze_dir(WAREHOUSE / f"dy{year}", RESULTS / f"dy{year}", year, run_id)


def analyze_dir(wdir: Path, out: Path, year, run_id: str, scope_mode: str = "cardiometabolic") -> dict:
    """Reconcile one built release pair. scope_mode 'all' audits every published label."""
    cfg = load_toml("analysis.toml")
    build = read_json(wdir / "build_summary.json")
    if not build:
        raise RuntimeError(f"{wdir}: no build summary; run the build stage first")
    out.mkdir(parents=True, exist_ok=True)
    con = connect()
    con.execute(f"CREATE VIEW detail AS SELECT * FROM read_parquet('{wdir / 'provider_drug.parquet'}')")
    con.execute(f"CREATE VIEW geo AS SELECT * FROM read_parquet('{wdir / 'geography_drug.parquet'}')")

    # Scope mapping on every published label of the year.
    labels = con.execute("""
        SELECT brnd_name, gnrc_name FROM geo WHERE geo_level = 'National'
        UNION SELECT DISTINCT brnd_name, gnrc_name FROM detail
    """).fetchall()
    if scope_mode == "all":
        decisions = pd.DataFrame([{"brnd_name": b, "gnrc_name": g, "in_scope": True, "atc_class": "all",
                                   "group": "all", "combination": "/" in g, "components": g,
                                   "matched_ingredients": "", "note": "scope 'all'"} for b, g in sorted(set(labels))])
    else:
        decisions = pd.DataFrame(scope.decisions_table(labels))
    decisions.insert(0, "data_year", year)
    _write_csv(decisions, out / "mapping_decisions.csv")
    con.register("scope_df", decisions[["brnd_name", "gnrc_name", "in_scope", "atc_class", "group", "combination"]])
    con.execute("CREATE TABLE scope AS SELECT * FROM scope_df")
    n_scope = int(decisions["in_scope"].sum())

    # Exact-key coverage between files.
    key_cov = con.execute("""
        WITH dl AS (SELECT DISTINCT brnd_name, gnrc_name FROM detail),
             gl AS (SELECT brnd_name, gnrc_name FROM geo WHERE geo_level = 'National')
        SELECT (SELECT count(*) FROM dl), (SELECT count(*) FROM gl),
               (SELECT count(*) FROM dl ANTI JOIN gl USING (brnd_name, gnrc_name)),
               (SELECT count(*) FROM gl ANTI JOIN dl USING (brnd_name, gnrc_name))
    """).fetchone()
    # Labels present in detail but absent from the national reference: try a
    # cosmetic normalization only to diagnose the cause; never merge on it.
    norm_diag = con.execute("""
        WITH dl AS (SELECT DISTINCT brnd_name, gnrc_name FROM detail),
             gl AS (SELECT brnd_name, gnrc_name FROM geo WHERE geo_level = 'National'),
             miss AS (SELECT * FROM dl ANTI JOIN gl USING (brnd_name, gnrc_name))
        SELECT m.brnd_name, m.gnrc_name, g.brnd_name AS ref_brnd_name, g.gnrc_name AS ref_gnrc_name
        FROM miss m LEFT JOIN gl g
          ON lower(regexp_replace(m.brnd_name, '\\s+', ' ', 'g')) = lower(regexp_replace(g.brnd_name, '\\s+', ' ', 'g'))
         AND lower(regexp_replace(m.gnrc_name, '\\s+', ' ', 'g')) = lower(regexp_replace(g.gnrc_name, '\\s+', ' ', 'g'))
    """).df()

    # National reconciliation (check 1).
    nat = con.execute("""
        WITH d AS (
            SELECT brnd_name, gnrc_name, sum(tot_clms) AS d_clms, sum(tot_30day_fills) AS d_fills,
                   sum(tot_drug_cst) AS d_cost, count(*) AS d_rows
            FROM detail GROUP BY ALL),
        a AS (
            SELECT brnd_name, gnrc_name, tot_clms AS a_clms, tot_30day_fills AS a_fills, tot_drug_cst AS a_cost,
                   tot_prscrbrs AS a_prscrbrs, tot_benes AS a_benes_published
            FROM geo WHERE geo_level = 'National'),
        s AS (
            SELECT brnd_name, gnrc_name, sum(tot_clms) AS a_state_rows_sum, count(*) AS n_state_rows
            FROM geo WHERE geo_level = 'State' GROUP BY ALL)
        SELECT sc.atc_class, sc."group", sc.combination, sc.brnd_name, sc.gnrc_name,
               a.a_clms, d.d_clms, a.a_fills, d.d_fills, a.a_cost, d.d_cost, a.a_prscrbrs, d.d_rows,
               a.a_benes_published, s.a_state_rows_sum, s.n_state_rows
        FROM scope sc
        LEFT JOIN a USING (brnd_name, gnrc_name)
        LEFT JOIN d USING (brnd_name, gnrc_name)
        LEFT JOIN s USING (brnd_name, gnrc_name)
        WHERE sc.in_scope AND (a.a_clms IS NOT NULL OR d.d_clms IS NOT NULL)
        ORDER BY sc.atc_class, sc."group", sc.brnd_name, sc.gnrc_name
    """).df()
    nat.insert(0, "geo_code", "National")
    nat.insert(0, "data_year", year)
    nat["status"] = [_status(a, d) for a, d in zip(nat.a_clms, nat.d_clms)]
    nat["d_clms"] = nat["d_clms"].fillna(0)
    nat["d_rows"] = nat["d_rows"].fillna(0)
    nat["gap_clms"] = nat.a_clms - nat.d_clms
    nat["retained_clms"] = [_fraction(d, a) for a, d in zip(nat.a_clms, nat.d_clms)]
    nat["retained_cost"] = [_fraction(d, a) for a, d in zip(nat.a_cost, nat.d_cost)]
    nat["retained_fills"] = [_fraction(d, a) for a, d in zip(nat.a_fills, nat.d_fills)]
    nat["prescriber_coverage"] = [_fraction(d, a) for a, d in zip(nat.a_prscrbrs, nat.d_rows)]
    nat["reference_state_suppression_clms"] = nat.a_clms - nat.a_state_rows_sum.fillna(0)
    nat["volume_band"] = [(_volume_band(a) if not pd.isna(a) else None) for a in nat.a_clms]
    _add_bound_check(nat)
    _write_csv(nat, out / "national_reconciliation.csv")

    # State reconciliation.
    st = con.execute("""
        WITH d AS (
            SELECT brnd_name, gnrc_name, state_code AS geo_code, sum(tot_clms) AS d_clms,
                   sum(tot_30day_fills) AS d_fills, sum(tot_drug_cst) AS d_cost, count(*) AS d_rows
            FROM detail JOIN scope USING (brnd_name, gnrc_name) WHERE scope.in_scope GROUP BY ALL),
        a AS (
            SELECT g.brnd_name, g.gnrc_name, g.geo_code, g.geo_desc, g.tot_clms AS a_clms, g.tot_30day_fills AS a_fills,
                   g.tot_drug_cst AS a_cost, g.tot_prscrbrs AS a_prscrbrs, g.tot_benes AS a_benes_published
            FROM geo g JOIN scope USING (brnd_name, gnrc_name) WHERE g.geo_level = 'State' AND scope.in_scope)
        SELECT coalesce(a.brnd_name, d.brnd_name) AS brnd_name, coalesce(a.gnrc_name, d.gnrc_name) AS gnrc_name,
               coalesce(a.geo_code, d.geo_code) AS geo_code, a.geo_desc,
               a.a_clms, d.d_clms, a.a_fills, d.d_fills, a.a_cost, d.d_cost, a.a_prscrbrs, d.d_rows, a.a_benes_published
        FROM a FULL OUTER JOIN d ON a.brnd_name = d.brnd_name AND a.gnrc_name = d.gnrc_name AND a.geo_code = d.geo_code
    """).df()
    st = st.merge(decisions[["brnd_name", "gnrc_name", "atc_class", "group", "combination"]], on=["brnd_name", "gnrc_name"],
                  how="left", validate="many_to_one")
    st.insert(0, "data_year", year)
    st["geo_category"] = [_geo_category(c, cfg) for c in st.geo_code]
    st["status"] = [_status(a, d) for a, d in zip(st.a_clms, st.d_clms)]
    st["d_clms"] = st["d_clms"].fillna(0)
    st["d_rows"] = st["d_rows"].fillna(0)
    st["gap_clms"] = st.a_clms - st.d_clms
    st["retained_clms"] = [_fraction(d, a) for a, d in zip(st.a_clms, st.d_clms)]
    st["retained_cost"] = [_fraction(d, a) for a, d in zip(st.a_cost, st.d_cost)]
    st["prescriber_coverage"] = [_fraction(d, a) for a, d in zip(st.a_prscrbrs, st.d_rows)]
    st["volume_band"] = [(_volume_band(a) if not pd.isna(a) else None) for a in st.a_clms]
    _add_bound_check(st)
    st = st.sort_values(["geo_code", "atc_class", "group", "brnd_name", "gnrc_name"]).reset_index(drop=True)
    _write_csv(st, out / "state_reconciliation.csv")

    # Well-matched states (check 2).
    sm = st[st.geo_category == "state or DC"]
    bad = sm[sm.status.isin([STATUS_NEGATIVE, STATUS_NO_REFERENCE])]
    failing = {code: sorted(set(g.status)) for code, g in bad.groupby("geo_code")}
    present = set(sm.geo_code)
    without_cells = [c for c in cfg["well_matched_codes"] if c not in present]
    well = [c for c in cfg["well_matched_codes"] if c in present and c not in failing]

    # Exception ledger.
    ledger = []
    for frame, level in ((nat, "National"), (st, "State")):
        for r in frame[frame.status != STATUS_MATCHED].itertuples(index=False):
            reason = {
                STATUS_NO_DETAIL: "published total present; no public provider-drug row for this label and geography",
                STATUS_NEGATIVE: "detail sum exceeds the published total; check scope, attribution or revision",
                STATUS_NO_REFERENCE: "public detail present but no published total for this label and geography",
                STATUS_ZERO_REFERENCE: "published total is zero, so the retained fraction is undefined",
            }[r.status]
            ledger.append({
                "data_year": year, "geo_level": level, "geo_code": r.geo_code, "brnd_name": r.brnd_name,
                "gnrc_name": r.gnrc_name, "atc_class": r.atc_class, "group": r.group, "status": r.status,
                "a_clms": None if pd.isna(r.a_clms) else r.a_clms, "d_clms": r.d_clms, "reason": reason,
                "evaluable": r.status in (STATUS_NO_DETAIL, STATUS_NEGATIVE),
            })
    for frame, level in ((nat, "National"), (st, "State")):
        viol = frame[(frame.bound_ok == False) & frame.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL])]  # noqa: E712
        for r in viol.itertuples(index=False):
            ledger.append({
                "data_year": year, "geo_level": level, "geo_code": r.geo_code, "brnd_name": r.brnd_name,
                "gnrc_name": r.gnrc_name, "atc_class": r.atc_class, "group": r.group, "status": "outside suppression bounds",
                "a_clms": r.a_clms, "d_clms": r.d_clms,
                "reason": ("gap is not between the number of missing prescriber rows and ten times that number, so the "
                           "10-claim rule alone does not explain it"),
                "evaluable": True,
            })
    for r in norm_diag.itertuples(index=False):
        in_sc = decisions.loc[(decisions.brnd_name == r.brnd_name) & (decisions.gnrc_name == r.gnrc_name), "in_scope"]
        ledger.append({
            "data_year": year, "geo_level": "National", "geo_code": "National", "brnd_name": r.brnd_name,
            "gnrc_name": r.gnrc_name, "atc_class": None, "group": None,
            "status": "detail label absent from national reference",
            "a_clms": None, "d_clms": None,
            "reason": ("matches reference label only after case/space normalization: "
                       f"{r.ref_brnd_name} | {r.ref_gnrc_name}") if isinstance(r.ref_brnd_name, str)
                      else "no reference label even after case/space normalization",
            "evaluable": False, "in_scope": bool(in_sc.iloc[0]) if len(in_sc) else None,
        })
    ledger_df = pd.DataFrame(ledger)
    _write_csv(ledger_df, out / "exception_ledger.csv")
    with open(out / "exception_ledger.jsonl", "w", encoding="utf-8") as fh:
        for row in ledger:
            fh.write(json.dumps({k: (None if isinstance(v, float) and pd.isna(v) else v) for k, v in row.items()}) + "\n")

    # Summaries.
    thresholds = cfg["fraction_thresholds"]
    nat_eval = nat[nat.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL, STATUS_NEGATIVE])]
    by_class = []
    for key, g in nat_eval.groupby("atc_class"):
        by_class.append({"atc_class": key, "labels": int(len(g)), "a_clms": float(g.a_clms.sum()),
                         "d_clms": float(g.d_clms.sum()), "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum()),
                         "median_label_retained": float(g.retained_clms.median()),
                         "a_cost": float(g.a_cost.sum()), "d_cost": float(g.d_cost.fillna(0).sum()),
                         "weighted_retained_cost": float(g.d_cost.fillna(0).sum() / g.a_cost.sum())})
    by_group = []
    for (cls, grp), g in nat_eval.groupby(["atc_class", "group"]):
        by_group.append({"atc_class": cls, "group": grp, "labels": int(len(g)), "a_clms": float(g.a_clms.sum()),
                         "d_clms": float(g.d_clms.sum()), "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum()),
                         "median_label_retained": float(g.retained_clms.median()),
                         "min_label_retained": float(g.retained_clms.min()),
                         "max_label_retained": float(g.retained_clms.max())})
    _write_csv(pd.DataFrame(by_group), out / "national_by_group.csv")
    bands = []
    for band, g in nat_eval.groupby("volume_band", sort=False):
        bands.append({"volume_band": band, "labels": int(len(g)), "a_clms": float(g.a_clms.sum()),
                      "d_clms": float(g.d_clms.sum()), "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum()),
                      "median_label_retained": float(g.retained_clms.median()),
                      "labels_no_public_detail": int((g.status == STATUS_NO_DETAIL).sum())})
    order = {(_volume_band(lo)): i for i, (lo, _) in enumerate(VOLUME_BANDS)}
    bands = sorted(bands, key=lambda b: order.get(b["volume_band"], 99))
    _write_csv(pd.DataFrame(bands), out / "national_by_volume_band.csv")

    sw = st[(st.geo_category == "state or DC") & st.geo_code.isin(well) &
            st.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL, STATUS_NEGATIVE])]
    state_rows = []
    for code, g in sw.groupby("geo_code"):
        rec = {"geo_code": code, "geo_desc": g.geo_desc.dropna().iloc[0] if g.geo_desc.notna().any() else None,
               "cells": int(len(g)), "a_clms": float(g.a_clms.sum()), "d_clms": float(g.d_clms.sum()),
               "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum()),
               "median_cell_retained": float(g.retained_clms.median()),
               "cells_no_public_detail": int((g.status == STATUS_NO_DETAIL).sum())}
        for cls, gc in g.groupby("atc_class"):
            rec[f"weighted_retained_{cls}"] = float(gc.d_clms.sum() / gc.a_clms.sum())
        state_rows.append(rec)
    state_df = pd.DataFrame(state_rows, columns=None if state_rows else
                            ["geo_code", "geo_desc", "cells", "a_clms", "d_clms", "weighted_retained",
                             "median_cell_retained", "cells_no_public_detail"]).sort_values("geo_code")
    _write_csv(state_df, out / "state_summary.csv")

    other = st[(st.geo_category != "state or DC") & st.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL, STATUS_NEGATIVE])]
    other_rows = []
    for (cat, code), g in other.groupby(["geo_category", "geo_code"]):
        other_rows.append({"geo_category": cat, "geo_code": code, "cells": int(len(g)), "a_clms": float(g.a_clms.sum()),
                           "d_clms": float(g.d_clms.sum()), "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum())})
    _write_csv(pd.DataFrame(other_rows, columns=None if other_rows else
                            ["geo_category", "geo_code", "cells", "a_clms", "d_clms", "weighted_retained"]),
               out / "other_geography_summary.csv")

    # Group shares and rank shifts (secondary).
    shares, ranks = _shares_and_ranks(nat_eval, sw, well, cfg)
    _write_csv(shares, out / "group_shares.csv")
    _write_csv(ranks, out / "rank_shifts.csv")

    # Reference construction check.
    ref_check = {
        "labels_with_retained_lt_1": int((nat_eval.retained_clms < 1).sum()),
        "labels_evaluable": int(len(nat_eval)),
        "labels_with_detail_rows_lt_prescribers": int((nat_eval.d_rows < nat_eval.a_prscrbrs).sum()),
        "interpretation": ("The published totals exceed the detail sums for most labels and the published prescriber "
                           "counts exceed the number of detail rows, so the reference is not a copy of the detail file."),
    }

    def _bounds(frame):
        f = frame[frame.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL]) & frame.bound_ok.notna()]
        m = f.missing_prescriber_rows
        return {"cells_checked": int(len(f)), "within_bounds": int((f.bound_ok == True).sum()),  # noqa: E712
                "outside_bounds": int((f.bound_ok == False).sum()),  # noqa: E712
                "share_within": float((f.bound_ok == True).mean()) if len(f) else None,  # noqa: E712
                # The upper bound can fail only when the published total exceeds ten times the
                # number of missing rows; the lower bound can fail only when detail rows exist.
                "upper_bound_could_fail": int((f.a_clms > 10 * m).sum()),
                "lower_bound_could_fail": int(((f.d_clms > 0) & (m >= 1)).sum()),
                "gap_at_lower_bound": int(((f.gap_clms == m) & (m >= 1)).sum()),
                "gap_at_upper_bound": int(((f.gap_clms == 10 * m) & (m >= 1)).sum())}

    summary = {
        "data_year": year,
        "run_id": run_id,
        "generated_at_utc": utc_now(),
        "source_sha256": build.get("source_sha256"),
        "scope_mode": scope_mode,
        "scope": {"labels_total": int(len(decisions)), "labels_in_scope": n_scope,
                  "in_scope_by_class": decisions[decisions.in_scope].groupby("atc_class").size().to_dict()},
        "key_coverage": {"detail_labels": key_cov[0], "reference_national_labels": key_cov[1],
                         "detail_labels_missing_from_reference": key_cov[2],
                         "reference_labels_without_detail": key_cov[3],
                         "detail_labels_missing_from_reference_matching_after_normalization":
                             int(norm_diag.ref_brnd_name.notna().sum())},
        "national": {
            "cells": int(len(nat)),
            "status_counts": nat.status.value_counts().to_dict(),
            "a_clms": float(nat_eval.a_clms.sum()), "d_clms": float(nat_eval.d_clms.sum()),
            "gap_clms": float(nat_eval.a_clms.sum() - nat_eval.d_clms.sum()),
            "weighted_retained": float(nat_eval.d_clms.sum() / nat_eval.a_clms.sum()),
            "weighted_retained_cost": float(nat_eval.d_cost.fillna(0).sum() / nat_eval.a_cost.sum()),
            "label_retained_distribution": _quantiles(nat_eval.retained_clms),
            "label_retained_bands": _bands(nat_eval.retained_clms, thresholds),
            "prescriber_coverage_distribution": _quantiles(nat_eval.prescriber_coverage),
            "reference_state_suppression_clms": float(nat_eval.reference_state_suppression_clms.sum()),
            "labels_with_reference_state_suppression": int((nat_eval.reference_state_suppression_clms > 0).sum()),
            "by_class": by_class,
        },
        "states": {
            "well_matched_codes": well,
            "failing_codes": failing,
            "codes_without_in_scope_cells": without_cells,
            "cells": int(len(sw)),
            "status_counts": sw.status.value_counts().to_dict(),
            "a_clms": float(sw.a_clms.sum()), "d_clms": float(sw.d_clms.sum()),
            "weighted_retained": float(sw.d_clms.sum() / sw.a_clms.sum()) if len(sw) else None,
            "cell_retained_distribution": _quantiles(sw.retained_clms),
            "cell_retained_bands": _bands(sw.retained_clms, thresholds),
            "state_weighted_retained_distribution": _quantiles(state_df.weighted_retained),
            "all_state_level_status_counts": st.status.value_counts().to_dict(),
        },
        "reference_check": ref_check,
        "suppression_bound_check": {"national": _bounds(nat), "states_well_matched": _bounds(sw),
                                    "all_state_level": _bounds(st)},
        "exceptions": ledger_df.status.value_counts().to_dict() if len(ledger_df) else {},
        "outputs": {p.name: rel(p) for p in sorted(out.glob("*")) if p.is_file()},
    }
    write_json(out / "summary.json", summary)
    print(json.dumps({k: summary[k] for k in ("scope", "key_coverage")}, indent=1))
    print("national weighted retained:", round(summary["national"]["weighted_retained"], 4))
    return summary


def _rank(series: pd.Series) -> pd.Series:
    return series.rank(ascending=False, method="average")


def _shares_and_ranks(nat_eval: pd.DataFrame, sw: pd.DataFrame, well: list[str], cfg: dict):
    rows = []
    single_class = lambda c: isinstance(c, str) and "+" not in c
    for geo, frame in [("National", nat_eval)] + [(code, sw[sw.geo_code == code]) for code in well]:
        if frame.empty:
            continue
        frame = frame[frame.atc_class.map(single_class).astype(bool)]
        for cls, gc in frame.groupby("atc_class"):
            tot_a, tot_d = gc.a_clms.sum(), gc.d_clms.sum()
            for grp, gg in gc.groupby("group"):
                share_a = gg.a_clms.sum() / tot_a if tot_a else None
                share_d = gg.d_clms.sum() / tot_d if tot_d else None
                rows.append({"geo_code": geo, "atc_class": cls, "group": grp,
                             "a_clms": float(gg.a_clms.sum()), "d_clms": float(gg.d_clms.sum()),
                             "class_a_clms": float(tot_a), "class_d_clms": float(tot_d),
                             "share_published": share_a, "share_detail": share_d,
                             "share_difference_pp": None if share_a is None or share_d is None else 100 * (share_d - share_a)})
    shares = pd.DataFrame(rows)
    rank_rows = []
    flag = cfg["rank_shift_flag"]
    states = shares[shares.geo_code != "National"]
    for (cls, grp), g in states.groupby(["atc_class", "group"]):
        g = g.dropna(subset=["share_published", "share_detail"]).copy()
        if len(g) < 3:
            continue
        g["rank_published"] = _rank(g.share_published)
        g["rank_detail"] = _rank(g.share_detail)
        g["shift"] = (g.rank_detail - g.rank_published).abs()
        rho = g.rank_published.corr(g.rank_detail)
        tau = _kendall_tau_b(g.share_published.tolist(), g.share_detail.tolist())
        top_a = set(g.nsmallest(10, "rank_published").geo_code)
        top_d = set(g.nsmallest(10, "rank_detail").geo_code)
        worst = g.sort_values(["shift", "geo_code"], ascending=[False, True]).iloc[0]
        rank_rows.append({"atc_class": cls, "group": grp, "jurisdictions": int(len(g)), "spearman": float(rho), "kendall_tau_b": float(tau),
                          "max_abs_rank_shift": float(g["shift"].max()),
                          f"jurisdictions_shift_ge_{flag}": int((g["shift"] >= flag).sum()),
                          "top10_overlap": len(top_a & top_d),
                          "largest_shift_geo_code": worst.geo_code,
                          "largest_shift_rank_published": float(worst.rank_published),
                          "largest_shift_rank_detail": float(worst.rank_detail),
                          "median_abs_share_difference_pp": float(g.share_difference_pp.abs().median()),
                          "max_abs_share_difference_pp": float(g.share_difference_pp.abs().max())})
        for r in g.itertuples(index=False):
            idx = shares.index[(shares.geo_code == r.geo_code) & (shares.atc_class == cls) & (shares.group == grp)]
            shares.loc[idx, "rank_published"] = r.rank_published
            shares.loc[idx, "rank_detail"] = r.rank_detail
    return shares, pd.DataFrame(rank_rows)


def provider_reconciliation(year: int, run_id: str) -> dict:
    """Supplementary: per-NPI totals in the By Provider file against summed detail (all drugs)."""
    wdir = WAREHOUSE / f"dy{year}"
    prov = wdir / "provider.parquet"
    if not prov.exists():
        return {}
    out = RESULTS / f"dy{year}"
    con = connect()
    con.execute(f"CREATE VIEW detail AS SELECT * FROM read_parquet('{wdir / 'provider_drug.parquet'}')")
    con.execute(f"CREATE VIEW geo AS SELECT * FROM read_parquet('{wdir / 'geography_drug.parquet'}')")
    con.execute(f"CREATE VIEW provider AS SELECT * FROM read_parquet('{prov}')")
    per = con.execute("""
        WITH d AS (SELECT npi, sum(tot_clms) AS d_clms, count(*) AS d_rows FROM detail GROUP BY npi)
        SELECT coalesce(p.npi, d.npi) AS npi, p.entity_code, p.tot_clms AS p_clms, d.d_clms, d.d_rows,
               (p.npi IS NULL) AS detail_only, (d.npi IS NULL) AS provider_only
        FROM provider p FULL OUTER JOIN d ON p.npi = d.npi
    """).df()
    both = per[~per.detail_only & ~per.provider_only].copy()
    both["retained"] = both.d_clms / both.p_clms
    nat_ref = con.execute("SELECT sum(tot_clms) FROM geo WHERE geo_level = 'National'").fetchone()[0]
    by_entity = []
    for ent, g in per.groupby(per.entity_code.fillna("not in provider file")):
        by_entity.append({"entity_code": ent, "npis": int(len(g)), "p_clms": float(g.p_clms.fillna(0).sum()),
                          "d_clms": float(g.d_clms.fillna(0).sum()),
                          "weighted_retained": float(g.d_clms.fillna(0).sum() / g.p_clms.sum()) if g.p_clms.sum() else None})
    res = {
        "data_year": year, "run_id": run_id,
        "npis_in_provider_file": int((~per.detail_only).sum()),
        "npis_in_detail_file": int((~per.provider_only).sum()),
        "npis_detail_only": int(per.detail_only.sum()),
        "npis_provider_only": int(per.provider_only.sum()),
        "provider_file_claims": float(per.p_clms.fillna(0).sum()),
        "detail_file_claims": float(per.d_clms.fillna(0).sum()),
        "geography_national_claims_all_labels": float(nat_ref),
        "weighted_retained_vs_provider_file": float(per.d_clms.fillna(0).sum() / per.p_clms.fillna(0).sum()),
        "npi_retained_distribution": _quantiles(both.retained),
        "npis_with_detail_gt_provider_total": int((both.d_clms > both.p_clms).sum()),
        "claims_of_npis_without_detail_rows": float(per.loc[per.provider_only, "p_clms"].sum()),
        "claims_in_unpublished_rows_of_npis_with_detail": float((both.p_clms - both.d_clms).sum()),
        "geography_minus_provider_file_claims": float(nat_ref - per.p_clms.fillna(0).sum()),
        "by_entity_code": by_entity,
        "note": ("All drugs together. The By Provider file is a supplementary reconciliation and is not used as a "
                 "denominator for any drug-level fraction."),
    }
    write_json(out / "provider_reconciliation.json", res)
    return res


def replication(years: list[int], run_id: str) -> dict:
    """Year-by-year comparison without pooling. Labels are compared on exact published keys."""
    frames = []
    for y in years:
        p = RESULTS / f"dy{y}" / "national_reconciliation.csv"
        if p.exists():
            frames.append(pd.read_csv(p, keep_default_na=True))
    if len(frames) < 2:
        return {}
    allnat = pd.concat(frames, ignore_index=True)
    allnat = allnat[allnat.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL, STATUS_NEGATIVE])]
    wide = allnat.pivot_table(index=["brnd_name", "gnrc_name"], columns="data_year", values="retained_clms")
    present = allnat.groupby(["brnd_name", "gnrc_name"]).data_year.apply(lambda s: ";".join(str(int(x)) for x in sorted(s)))
    cont = present.rename("years_present").reset_index()
    groups = allnat.drop_duplicates(["brnd_name", "gnrc_name"], keep="first")[["brnd_name", "gnrc_name", "atc_class", "group"]]
    cont = cont.merge(groups, on=["brnd_name", "gnrc_name"], how="left", validate="one_to_one")
    for y in sorted(set(allnat.data_year)):
        cont = cont.merge(wide[y].rename(f"retained_{int(y)}").reset_index(), on=["brnd_name", "gnrc_name"], how="left")
    _write_csv(cont.sort_values(["atc_class", "group", "brnd_name", "gnrc_name"]), RESULTS / "replication" / "label_continuity.csv")
    yrs = sorted(int(y) for y in set(allnat.data_year))
    common = cont.dropna(subset=[f"retained_{y}" for y in yrs])
    corr = {}
    for i, y1 in enumerate(yrs):
        for y2 in yrs[i + 1:]:
            corr[f"{y1}_vs_{y2}"] = float(common[f"retained_{y1}"].rank().corr(common[f"retained_{y2}"].rank()))
    per_year = []
    for y in yrs:
        g = allnat[allnat.data_year == y]
        per_year.append({"data_year": y, "labels": int(len(g)), "weighted_retained": float(g.d_clms.sum() / g.a_clms.sum()),
                         "median_label_retained": float(g.retained_clms.median()),
                         "labels_no_public_detail": int((g.status == STATUS_NO_DETAIL).sum())})
        for cls, gc in g.groupby("atc_class"):
            per_year[-1][f"weighted_retained_{cls}"] = float(gc.d_clms.sum() / gc.a_clms.sum())
    by_group = (allnat.groupby(["data_year", "atc_class", "group"])
                .apply(lambda g: pd.Series({"labels": len(g), "a_clms": g.a_clms.sum(), "d_clms": g.d_clms.sum(),
                                            "weighted_retained": g.d_clms.sum() / g.a_clms.sum()}), include_groups=False)
                .reset_index())
    _write_csv(by_group, RESULTS / "replication" / "group_by_year.csv")
    res = {
        "run_id": run_id, "years": yrs,
        "labels_by_presence": cont.years_present.value_counts().to_dict(),
        "labels_in_all_years": int(len(common)),
        "spearman_label_retained_between_years": corr,
        "per_year": per_year,
        "note": "Each year was analyzed separately with its own label mapping; no pooled series was built.",
    }
    write_json(RESULTS / "replication" / "replication_summary.json", res)
    return res


def exploratory_claims_per_prescriber(year: int, run_id: str) -> dict:
    """Post hoc (analysis plan, amendment 5): retained fraction against published claims per prescriber."""
    d = RESULTS / f"dy{year}"
    n = pd.read_csv(d / "national_reconciliation.csv")
    n = n[n.status.isin([STATUS_MATCHED, STATUS_NO_DETAIL, STATUS_NEGATIVE])].copy()
    n["claims_per_prescriber"] = n.a_clms / n.a_prscrbrs
    groups = (n.groupby(["atc_class", "group"])
              .apply(lambda x: pd.Series({"labels": len(x), "claims_per_prescriber": x.a_clms.sum() / x.a_prscrbrs.sum(),
                                          "weighted_retained": x.d_clms.sum() / x.a_clms.sum()}), include_groups=False)
              .reset_index().sort_values("claims_per_prescriber"))
    _write_csv(groups, d / "exploratory_claims_per_prescriber.csv")
    res = {
        "data_year": year, "run_id": run_id, "status": "post hoc exploratory (analysis plan amendment 5)",
        "labels": int(len(n)),
        "spearman_label_claims_per_prescriber_vs_retained": float(n.claims_per_prescriber.rank().corr(n.retained_clms.rank())),
        "spearman_label_total_claims_vs_retained": float(n.a_clms.rank().corr(n.retained_clms.rank())),
        "spearman_group_claims_per_prescriber_vs_retained": float(
            groups.claims_per_prescriber.rank().corr(groups.weighted_retained.rank())),
        "groups": int(len(groups)),
    }
    write_json(d / "exploratory_claims_per_prescriber.json", res)
    return res
