"""Shared paths, hashing and small I/O helpers."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import tomllib
from pathlib import Path

ROOT = Path(os.environ.get("PSAUDIT_ROOT", Path(__file__).resolve().parents[2]))
CONFIG = ROOT / "config"
DATA = ROOT / "data"
RAW = DATA / "raw"
MANIFEST_DIR = DATA / "manifest"
# A rerun can write to separate warehouse and results folders for comparison.
WAREHOUSE = Path(os.environ.get("PSAUDIT_WAREHOUSE", DATA / "warehouse"))
RESULTS = Path(os.environ.get("PSAUDIT_RESULTS", ROOT / "results"))
LOGS = ROOT / "logs"
DOCS = ROOT / "docs"
EVIDENCE = ROOT / "evidence"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def run_id() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256_file(path: Path, chunk: int = 8 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            block = fh.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def load_toml(name: str) -> dict:
    with open(CONFIG / name, "rb") as fh:
        return tomllib.load(fh)


def read_json(path: Path, default=None):
    if not path.exists():
        return default
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, sort_keys=False, default=str)
        fh.write("\n")
    tmp.replace(path)


def rel(path: Path) -> str:
    """Project-relative path for manifests (no machine-specific prefixes)."""
    try:
        return str(Path(path).resolve().relative_to(ROOT.resolve()))
    except ValueError:
        return str(path)
