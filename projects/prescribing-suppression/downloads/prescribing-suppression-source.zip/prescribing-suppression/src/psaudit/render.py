"""Render stage: public tables, figures, workbook, Tableau exports, evidence register,
report, manuscript and the static project page."""

from __future__ import annotations

import json
import shutil

import pandas as pd

from psaudit import figures
from psaudit.common import RESULTS, ROOT, load_toml, read_json, utc_now, write_json
from psaudit.public import PUBLIC, build_public
from psaudit.workbook import write_workbook

FIG_DIR = RESULTS / "figures"
EXPORTS = ROOT / "exports"


def _state_names(year: int) -> dict[str, str]:
    s = pd.read_csv(RESULTS / f"dy{year}" / "state_summary.csv", dtype={"geo_code": str})
    return dict(zip(s.geo_code, s.geo_desc))


def render_figures(cfg: dict) -> list[str]:
    y = cfg["primary_year"]
    d = RESULTS / f"dy{y}"
    paths = []
    nat = pd.read_csv(PUBLIC / f"dy{y}" / "national_reconciliation.csv", dtype={"geo_code": str})
    weighted = read_json(d / "summary.json")["national"]["weighted_retained"]
    paths += figures.fig_retained_vs_volume(nat, FIG_DIR, y, weighted)
    states = pd.read_csv(d / "state_summary.csv", dtype={"geo_code": str})
    paths += figures.fig_state_retained(states, FIG_DIR, y)
    ranks = pd.read_csv(d / "rank_shifts.csv")
    paths += figures.fig_rank_agreement(ranks, FIG_DIR, y, cfg["rank_shift_flag"])
    shares = pd.read_csv(d / "group_shares.csv", dtype={"geo_code": str})
    shares["geo_desc"] = shares.geo_code.map(_state_names(y))
    paths += figures.fig_group_dumbbell(shares, "A10A", FIG_DIR, y)
    rep = read_json(RESULTS / "replication" / "replication_summary.json")
    if rep:
        paths += figures.fig_replication(pd.DataFrame(rep["per_year"]), FIG_DIR)
    return [str(p.relative_to(ROOT)) for p in paths]


def tableau_exports(cfg: dict) -> list[str]:
    """Flat CSVs with an explicit grain for Tableau or any BI tool (see docs/tableau_spec.md)."""
    out = EXPORTS / "tableau"
    out.mkdir(parents=True, exist_ok=True)
    written = []
    frames = []
    for y in [cfg["primary_year"], *cfg["replication_years"]]:
        p = PUBLIC / f"dy{y}" / "state_reconciliation.csv"
        if p.exists():
            frames.append(pd.read_csv(p, dtype={"geo_code": str}))
    if frames:
        cells = pd.concat(frames, ignore_index=True)
        keep = ["data_year", "geo_code", "geo_desc", "geo_category", "atc_class", "group", "brnd_name", "gnrc_name",
                "status", "bound_ok", "a_clms", "a_cost", "retained_band", "values_withheld"]
        cells[keep].to_csv(out / "tableau_state_label_cells.csv", index=False, lineterminator="\n", float_format="%.15g")
        written.append("exports/tableau/tableau_state_label_cells.csv")
    frames = []
    for y in [cfg["primary_year"], *cfg["replication_years"]]:
        p = PUBLIC / f"dy{y}" / "group_shares.csv"
        if p.exists():
            f = pd.read_csv(p, dtype={"geo_code": str})
            f.insert(0, "data_year", y)
            frames.append(f)
    if frames:
        pd.concat(frames, ignore_index=True).to_csv(out / "tableau_group_shares.csv", index=False, lineterminator="\n",
                                                    float_format="%.15g")
        written.append("exports/tableau/tableau_group_shares.csv")
    return written


def render_all() -> dict:
    cfg = load_toml("analysis.toml")
    years = [cfg["primary_year"], *cfg["replication_years"]]
    disclosure = build_public(years)
    from psaudit.public import public_audit

    audit = [public_audit(y) for y in years]
    write_json(PUBLIC / "public_audit.json", {"checked_at_utc": utc_now(), "years": audit})
    if any(a["narrowed_below_protection"] for a in audit):
        raise RuntimeError(f"public tables pin withheld values: {audit}")
    figs = render_figures(cfg)
    manifest = read_json(ROOT / "data" / "manifest" / "source_manifest.json")
    wb = write_workbook(PUBLIC, EXPORTS / f"prescribing_suppression_reconciliation_{cfg['primary_year']}.xlsx",
                        year=cfg["primary_year"], sources=manifest["files"], replication_dir=PUBLIC / "replication")
    tab = tableau_exports(cfg)
    from psaudit import evidence

    claims = evidence.build_claims(cfg)
    from psaudit import documents

    docs = documents.render_documents(cfg, claims)
    res = {"rendered_at_utc": utc_now(), "figures": figs, "workbook": str(wb.relative_to(ROOT)), "tableau": tab,
           "disclosure": disclosure, "documents": docs, "renderer": documents.RENDERER}
    write_json(RESULTS / "render_summary.json", res)
    print(json.dumps({k: res[k] for k in ("figures", "workbook", "tableau", "documents")}, indent=1))
    return res
