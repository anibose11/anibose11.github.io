"""Additional files for the journal submission (written beside the manuscript)."""

from __future__ import annotations

import csv
import shutil
from pathlib import Path

import pandas as pd

from psaudit.common import DOCS, ROOT, read_json

OUT = ROOT / "manuscript" / "additional_files"


def build_additional_files(years: list[int]) -> list[str]:
    OUT.mkdir(parents=True, exist_ok=True)
    written = []

    # 1. Source manifest as CSV.
    m = read_json(ROOT / "data" / "manifest" / "source_manifest.json")
    cols = ["kind", "data_year", "release_year", "role", "dataset_uuid", "catalog_modified", "url", "resolved_url",
            "http_status", "content_type", "last_modified", "etag", "bytes", "sha256", "accessed_at_utc", "local_path"]
    p = OUT / "Additional_file_1_source_manifest.csv"
    with open(p, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        for f in m["files"]:
            w.writerow({k: f.get(k, "") for k in cols})
    written.append(p)

    # 2. Analysis plan, lock record and contribution decision.
    lock = read_json(DOCS / "analysis_plan.lock.json")
    text = ["# Additional file 2: analysis plan, lock record and contribution decision", "",
            f"Plan locked at {lock['locked_at_utc']} with SHA-256 {lock['sha256']} (of the plan as first written; "
            "amendments were appended afterwards and are dated).", "",
            (DOCS / "analysis_plan.md").read_text(encoding="utf-8"), "", "---", "",
            (DOCS / "contribution_decision.md").read_text(encoding="utf-8")]
    p = OUT / "Additional_file_2_analysis_plan.md"
    p.write_text("\n".join(text), encoding="utf-8")
    written.append(p)

    # 3. Scope decisions for all years.
    frames = [pd.read_csv(ROOT / "exports" / "public" / f"dy{y}" / "mapping_decisions.csv") for y in years]
    p = OUT / "Additional_file_3_scope_decisions.csv"
    pd.concat(frames, ignore_index=True).to_csv(p, index=False, lineterminator="\n")
    written.append(p)

    # 4. Reconciliation workbook.
    src = ROOT / "exports" / f"prescribing_suppression_reconciliation_{years[0]}.xlsx"
    p = OUT / "Additional_file_4_reconciliation_workbook.xlsx"
    shutil.copy(src, p)
    written.append(p)

    # 5. Match and exception ledger, all years (public rule applied).
    frames = [pd.read_csv(ROOT / "exports" / "public" / f"dy{y}" / "reconciliation_ledger.csv", dtype={"geo_code": str})
              for y in years]
    p = OUT / "Additional_file_5_reconciliation_ledger.csv"
    pd.concat(frames, ignore_index=True).to_csv(p, index=False, lineterminator="\n", float_format="%.15g")
    written.append(p)

    # 6. Source archive.
    src_zip = ROOT / "deliverables" / "stage" / "site" / "projects" / "prescribing-suppression" / "downloads" / \
        "prescribing-suppression-source.zip"
    if src_zip.exists():
        p = OUT / "Additional_file_6_source_code.zip"
        shutil.copy(src_zip, p)
        written.append(p)
    return [str(x.relative_to(ROOT)) for x in written]


FIGURE_FILES = {1: "fig1_retained_vs_volume_2024", 2: "fig2_state_retained_2024", 3: "fig3_rank_agreement_2024",
                4: "fig4_a10a_share_2024"}
SUBMISSION = ROOT / "manuscript" / "submission"


def build_submission_package() -> dict:
    """Everything the BMC submission form asks for, in one folder and one zip (not submitted)."""
    import zipfile

    from psaudit.common import RESULTS, sha256_file

    if SUBMISSION.exists():
        shutil.rmtree(SUBMISSION)
    SUBMISSION.mkdir(parents=True)
    shutil.copy(ROOT / "manuscript" / "manuscript.docx", SUBMISSION / "Manuscript.docx")
    shutil.copy(ROOT / "manuscript" / "cover_letter.docx", SUBMISSION / "Cover_letter.docx")
    for n, stem in FIGURE_FILES.items():
        for ext in ("png", "pdf"):
            shutil.copy(RESULTS / "figures" / f"{stem}.{ext}", SUBMISSION / f"Figure_{n}.{ext}")
    for p in sorted(OUT.glob("Additional_file_*")):
        shutil.copy(p, SUBMISSION / p.name)
    files = sorted(p for p in SUBMISSION.iterdir() if p.is_file())
    dest = ROOT / "deliverables" / "06-prescribing-suppression-BMC-SUBMISSION.zip"
    entries = [(f"BMC-submission/upload/{p.name}", p) for p in files]
    entries.append(("BMC-submission/not_for_upload/Submission_checklist.md", ROOT / "manuscript" / "submission_checklist.md"))
    revision_note = ROOT / "handoff" / "EDITORIAL-REVISION-2026-10-12.md"
    if revision_note.exists():
        entries.append(("BMC-submission/not_for_upload/EDITORIAL-REVISION-2026-10-12.md", revision_note))
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for arc, p in entries:
            info = zipfile.ZipInfo(arc, date_time=(2026, 10, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, p.read_bytes())
    return {"folder": str(SUBMISSION.relative_to(ROOT)), "files": [p.name for p in files],
            "zip": str(dest.relative_to(ROOT)), "zip_bytes": dest.stat().st_size, "zip_sha256": sha256_file(dest)}
